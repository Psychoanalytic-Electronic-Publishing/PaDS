'********************
' March 2022
' This code has been put in TFS file BusinessLogic\ExcelMacros\CashbookMacro.vb to allow change tracking
'*******************
'3/3/22     James Woosnam   SIR5439 - Change amounts to Native in pivot & add curreny as column
'Option Explicit

Sub cmdSetDefault_Click()

    FormatPivot "Default"
End Sub
Sub cmdSetPEP_Click()

    FormatPivot "PEP"
End Sub
Public Function FormatPivot(strFormatType As String)
    '***************************************************
    '2022 - Code in TFS see top
    '******************************************************
    On Error GoTo ProcedureError

    Dim pvt As Excel.PivotTable
    Dim fld As Excel.PivotField
    Dim wkb As Excel.Workbook
    Dim pi As Excel.PivotItem

    Set wkb = ActiveWorkbook
    
    Set pvt = wkb.Sheets("Pivot").PivotTables("Pivot")
    
    On Error Resume Next

    For Each fld In pvt.PivotFields
        fld.Orientation = xlHidden
    Next
    For Each fld In pvt.DataFields
        fld.Orientation = xlHidden
    Next
    On Error GoTo ProcedureError

    Select Case strFormatType
        Case "Default"
            '***************************************************
            '2022 - Code in TFS see top
            '******************************************************

            pvt.PivotFields("Currency").Orientation = xlColumnField
            pvt.PivotFields("Currency").Position = 1
            pvt.PivotFields("Quarter").Orientation = xlPageField
            pvt.PivotFields("Year").Orientation = xlPageField
            pvt.PivotFields("Product").Orientation = xlRowField

            pvt.PivotFields("Quantity").Orientation = xlDataField
            pvt.AddDataField pvt.PivotFields("AnountInNative"), "Sum of AnountInNative", xlSum
            pvt.RowGrand = False

            With pvt.DataPivotField
                .Orientation = xlColumnField
                .Position = 2
            End With
            For Each fld In Sheets("Pivot").PivotTables("Pivot").DataFields
                fld.Function = xlSum
                If InStr(fld.Name, "Quantity") <> 0 Then
                    fld.NumberFormat = "#,##0"
                Else
                    fld.NumberFormat = "#,##0.00"
                End If

            Next
            With wkb.Sheets("Pivot").PageSetup
                .PrintTitleRows = ""
                .PrintTitleColumns = ""
                .Zoom = False
                .FitToPagesWide = 1
                .FitToPagesTall = False
            End With
            wkb.Sheets("Pivot").Columns("A:X").EntireColumn.AutoFit

        '****

        Case "PEP"
            '***************************************************
            '2022 - Code in TFS see top
            '******************************************************
            pvt.PivotFields("Currency").Orientation = xlColumnField
            pvt.PivotFields("Quarter").Orientation = xlPageField
            pvt.PivotFields("Year").Orientation = xlPageField
            pvt.PivotFields("ProductCode").Orientation = xlRowField
            pvt.PivotFields("RateType").Orientation = xlRowField
            pvt.PivotFields("SubscriberCategory").Orientation = xlRowField
            pvt.PivotFields("ProductRate").Orientation = xlRowField
            pvt.PivotFields("ProductCodeQuantity").Orientation = xlDataField
            '3/3/22     James Woosnam   SIR5439 - Change amounts to Native in pivot & add curreny as column
            pvt.AddDataField ActiveSheet.PivotTables("Pivot").PivotFields("AnountInNative"), "Sum of AnountInNative", xlSum
        '31/5/12    James Woosnam   Line "pvt.PivotFields("Data").Orientation = xlColumnField" replaced as doesn't work in 2007 pivot tables
            pvt.DataPivotField.Orientation = xlColumnField
            pvt.PivotFields("Date").NumberFormat = "D-MMM-YY"
            pvt.RowGrand = False

            For Each fld In Sheets("Pivot").PivotTables("Pivot").DataFields
                fld.Function = xlSum
                If InStr(fld.Name, "ProductCodeQuantity") <> 0 Then
                    fld.NumberFormat = "#,##0"
                Else
                    fld.NumberFormat = "#,##0"
                End If

            Next

            With wkb.Sheets("Pivot").PageSetup
                .PrintTitleRows = ""
                .PrintTitleColumns = ""
                .Zoom = False
                .FitToPagesWide = 1
                .FitToPagesTall = False
            End With
            wkb.Sheets("Pivot").Columns("A:X").EntireColumn.AutoFit

            wkb.Sheets("Pivot").Select
            wkb.Sheets("Pivot").Cells(5, 3).Select
            On Error Resume Next
            wkb.Sheets("Pivot").Cells.Find(What:="total", After:=ActiveCell, LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlNext, MatchCase:=False).Activate
            If Err = 0 Then Selection.Delete
            On Error Resume Next
            wkb.Sheets("Pivot").Cells.Find(What:="total", After:=ActiveCell, LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlNext, MatchCase:=False).Activate
            If Err = 0 Then Selection.Delete
            On Error GoTo ProcedureError

    End Select
    wkb.Sheets("Pivot").Select
    wkb.Sheets("Pivot").Cells(5, 3).Select

    On Error Resume Next
    wkb.Sheets("Pivot").Shapes("cmdDefault").Select
    If Err <> 0 Then
        'Assume button not there so add it
        wkb.Sheets("Pivot").Buttons.Add(1, 1, 60, 20).Select
        wkb.Parent.Selection.Name = "cmdDefault"
    End If
    On Error GoTo ProcedureError
    wkb.Parent.Selection.OnAction = "cmdSetDefault_Click"
    wkb.Parent.Selection.Characters.Text = "Default"
    wkb.Parent.Selection.ShapeRange.Left = 0
    wkb.Parent.Selection.ShapeRange.Top = 20
    wkb.Parent.Selection.ShapeRange.Width = 50
    wkb.Parent.Selection.ShapeRange.Height = 15
    Range(Sheets("Criteria").Range("PivotStart").Value).Select

    On Error Resume Next
    wkb.Sheets("Pivot").Shapes("cmdPEP2").Select
    If Err <> 0 Then
        'Assume button not there so add it
        wkb.Sheets("Pivot").Buttons.Add(1, 1, 60, 20).Select
        wkb.Parent.Selection.Name = "cmdPEP2"
    End If
    On Error GoTo ProcedureError
    wkb.Parent.Selection.OnAction = "cmdSetPEP_Click"
    wkb.Parent.Selection.Characters.Text = "PEP"
    wkb.Parent.Selection.ShapeRange.Left = 51
    wkb.Parent.Selection.ShapeRange.Top = 20
    wkb.Parent.Selection.ShapeRange.Width = 50
    wkb.Parent.Selection.ShapeRange.Height = 15
ProcedureExit:
    Exit Function

ProcedureError:
    Select Case Err.Number
        Case Else
            GlobalErr Err.Number, Err.Description, "FormatPivot"
        Resume ProcedureExit
            Resume
    End Select

End Function

Public Function GlobalErr(lngErrNumber As Long, strErrString As String, Optional strErrLocation As Variant)

    If IsMissing(strErrLocation) Then
        strErrLocation = "In Report Template"
    End If

    Sheets("Criteria").Range("a10").Value = "UNEXPECTED ERROR: " & lngErrNumber _
                & "-" & strErrString _
                & "-" & strErrLocation
End Function







