begin tran
insert into LanguageTranslation (
TranslationNo 
,PageNumber
,LanguageName 
,LanguageText
,LastUpdatedDateTime
,LastUpdatedByUserId)
select
l.TranslationNo 
,l.PageNumber
,ln.LanguageName 
,l.LanguageText 
,GETDATE()
,'Zedra'
FROM  LanguageTranslation l
	CROSS JOIN (SELECT LanguageName='Spanish' UNION SELECT LanguageName='French') ln
	LEFT JOIN LanguageTranslation mT
	ON mt.TranslationNo = l.TranslationNo
	AND mt.PageNumber = l.PageNumber
	and mt.LanguageName = ln.LanguageName
where l.LanguageName='english'
and mt.LanguageTranslationId is null
select * from LanguageTranslation where TranslationNo = 1
and 1=2



SELECT 
l.LanguageTranslationId
,l.TranslationNo 
,l.PageNumber
,EnglishText = (select LanguageText from LanguageTranslation l2 where l2.TranslationNo = l.TranslationNo and l2.LanguageName='English')
,l.LanguageName 
,l.LanguageText 
FROM  LanguageTranslation l
where TranslationNo<10
ORDER BY 
case when l.PageNumber=0 then 0 else 1 end
,pagenumber
,(select LanguageText from LanguageTranslation l2 where l2.TranslationNo = l.TranslationNo and l2.LanguageName='English') 
,TranslationNo


--SELECT        TOP (200) TranslationNo, PageNumber, LanguageName, LanguageText
--FROM            LanguageTranslation AS l
--WHERE        (LanguageText =
--                             (SELECT        LanguageText
--                               FROM            LanguageTranslation AS LanguageTranslation_1
--                               WHERE        (TranslationNo = l.TranslationNo) AND (LanguageName = 'English') AND (l.LanguageName <> 'English')))
--ORDER BY TranslationNo DESC, LanguageName, LanguageText

commit tran