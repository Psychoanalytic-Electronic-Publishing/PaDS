/*
For every sub collects order and special affiliation info
@RetentionYears - will Obfuscate subs who havn't ordered or subscribered for xx years 
@DoRemove - 1 will Obfuscate or delete subs with ......
			***Which subs and the batch size is controled by subs in #SubsToRemove below  xx

30786
30823 - sunday pm
20817 - sent on friday
30707 - sunday pm after removing those logged on or created this year
*/
BEGIN TRAN
DECLARE 
	@DoRemove BIT = 1
	,@RetentionYears INT = 15
	,@PEPSpecialGroups VARCHAR(200) = '57860,49337,23370,64188'  
	,@DeleteAllOrdersBeforeDate DATETIME = '01-jan-2004'
--49337-American Psychological Association - Division 39
--57860 Int'l Psychoanalytical Studies Organization (IPSO)
--23370 Sociedade Brasileira De
--64188 Sociedad Argentina de Psicoanalisis
DECLARE @BatchLogId INT = 0
		,@RemoveMessage VARCHAR(MAX)
--DELETE OLD Orders
IF @DoRemove =1
BEGIN
	EXEC sp028InsertBatchLog @BatchLogType= 'Remove Data',@Description='',@BatchJobId=NULL,@SubmittedByUserSessionId=NULL,@BatchLogId =@BatchLogId OUTPUT
	select 
	so.OrderNumber  
	into #ord

	from SalesOrder so
	where So.OrderDate < @DeleteAllOrdersBeforeDate
	SELECT @RemoveMessage = CAST(COUNT(*) AS VARCHAR) + ' Orders to remove'	FROM #ord;Print @RemoveMessage ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
	select @RemoveMessage
	delete Cashbook from Cashbook c where c.OrderNumber  in (select OrderNumber from #ord)
	SELECT @RemoveMessage = CAST(@@ROWCOUNT  AS VARCHAR) + ' Cashbook to removed linked to orders' ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
	delete Cashbook from Cashbook c where c.EntryDate < @DeleteAllOrdersBeforeDate
	SELECT @RemoveMessage = CAST(@@ROWCOUNT  AS VARCHAR) + ' Cashbook to removed before date' ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage

	delete from SalesOrderLinePart where OrderNumber in (select OrderNumber from #ord)
	delete from SalesOrderLine where OrderNumber in (select OrderNumber from #ord)
	delete from SalesOrder where OrderNumber in (select OrderNumber from #ord)
	SELECT @RemoveMessage = CAST(@@ROWCOUNT  AS VARCHAR) + ' Orders to removed' ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
	drop table #ord
END
select @BatchLogId
select b.BatchLogId 
	,l.DateTime 
	,l.BatchLogLineText 
from BatchLog b
	left join BatchLogLine l
	on l.BatchLogId = b.BatchLogId 
where b.BatchlogId = @BatchLogId 
order by l.DateTime 


select
s.SubscriberId 
,s.SubscriberName 
,s.EntityType 
,s.SubscriberStatus 

,CreatedDateTime = cast(MAX(ISNULL(s.CreatedDateTime,'01-jan-1900') ) as datetime)
,WebUserLastLoggedOn = cast(MAX(ISNULL(s.WebUserLastLoggedOn,'01-jan-1900')) as datetime)
,DaysBetweenCreateAndLastLogon = MAX(DATEDIFF(DAY,s.CreatedDateTime,s.WebUserLastLoggedOn))
,CreatedYear = Year(MAX(s.CreatedDateTime ))
,CreatedByUserId = MAX(s.CreatedByUserId )
,LastUpdatedDateTime = MAX(s.LastUpdatedDateTime )
,[Last IJP Order Date] = max(CASE WHEN so.companyid = 1 THEN so.orderdate ELSE NULL END)
,[Last PEP Order Date] = max(CASE WHEN so.companyid = 2 THEN so.orderdate ELSE NULL END)
,[Years Since Last IJP Order] = DATEDIFF(YEAR, max(CASE WHEN so.companyid = 1 THEN so.orderdate ELSE NULL END),GETDATE())
,[Years Since Last PEP Order] = DATEDIFF(YEAR,max(CASE WHEN so.companyid = 2 THEN so.orderdate ELSE NULL END),GETDATE())
,[Last IJP Sub Date] = max(CASE WHEN soSub.companyid = 1 THEN soSub.orderdate ELSE NULL END)
,[Last PEP Sub Date] = max(CASE WHEN soSub.companyid = 2 THEN soSub.orderdate ELSE NULL END)
,[Years Since Last IJP Sub] = DATEDIFF(YEAR, max(CASE WHEN soSub.companyid = 1 THEN soSub.orderdate ELSE NULL END),GETDATE())
,[Years Since Last PEP Sub] = DATEDIFF(YEAR,max(CASE WHEN soSub.companyid = 2 THEN soSub.orderdate ELSE NULL END),GETDATE())
,[Current and in PEP Special Groups] = CASE WHEN EXISTS (SELECT * FROM SubscriberAffiliate sa WHERE sa.ChildSubscriberID=s.SubscriberId AND s.SubscriberStatus = 'Current' AND sa.ParentSubscriberID  IN(57860,49337,23370,64188)) THEN 1 ELSE 0 END
INTO  #Subs
from Subscriber s
	left join SalesOrderLine solSub
		inner join SalesOrder soSub
		on soSub.OrderNumber = solSub.OrderNumber 
	on solSub.SubscriberId = s.SubscriberId 
	LEFT join SalesOrder so
	on so.SubscriberId = s.SubscriberId 


--where s.SubscriberStatus = 'current'
--and sol.OrderNumber is not null
group by
s.EntityType 
,s.SubscriberId 
,s.SubscriberName
,s.SubscriberStatus 
--having max(so.orderdate) < dateadd(year,-1,getdate())
order by 
s.EntityType desc
,s.SubscriberName
,max(so.orderdate)


--Select Subs to be removed
	SELECT -- top 35000
		s.SubscriberId 
	INTO #SubsToRemove
	FROM Subscriber s
		INNER JOIN #Subs d
		ON d.SubscriberId = s.SubscriberId 
	WHERE 
	( d.[Years Since Last IJP Order] IS NULL 
	AND d.[Years Since Last PEP Order] is NULL
	AND d.[Years Since Last IJP Sub] IS NULL 
	AND d.[Years Since Last PEP Sub] is NULL
	AND d.[Current and in PEP Special Groups] =0
	) --no orders or subs and not PEP special group
	AND s.SubscriberName NOT LIKE '%xxx%'  --ignore those already Obfuscated
	AND s.SubscriberId NOT IN (30000,29001,29002,64921)  --64921 - Brazil Federation Group
	AND s.SubscriberId NOT IN (select r.RightsToId  from RemoteUserRights r where r.RightsType = 'subscriber') 
	AND (s.EntityType <> 'Organisation' OR (s.EntityType = 'Organisation' AND s.SubscriberStatus<>'Current'))
	AND (s.CreatedByUserId  <> 'Athena' OR (s.CreatedByUserId = 'Athena' AND s.SubscriberStatus<>'Current'))
	AND (d.CreatedDateTime  < '01-jan-2019'  OR (s.CreatedDateTime >= '01-jan-2019' AND s.SubscriberStatus<>'Current'))
	AND (d.WebUserLastLoggedOn  < '01-jan-2019'  OR (s.WebUserLastLoggedOn >= '01-jan-2019' AND s.SubscriberStatus<>'Current'))
	
--Output subs to be removed
	SELECT 
		What='Subs to remove'
		,*
	FROM #Subs s
	WHERE SubscriberId IN (SELECT SubscriberId FROM #SubsToRemove )

	--and SubscriberStatus = 'current'
	--and CreatedDateTime > dateadd(month,-12,getdate())
	order by CreatedDateTime desc

--Summary
select
s.EntityType 
,TotalNo = count(*)
,TotalCurrent = sum(CASE WHEN s.SubscriberStatus = 'Current' THEN 1 ELSE 0 END)
,TotalNonCurrent = sum(CASE WHEN s.SubscriberStatus <> 'Current' THEN 1 ELSE 0 END)
,NoIJPorPEPOrderOrSub = sum(CASE WHEN d.[Years Since Last IJP Order] IS NULL AND d.[Years Since Last PEP Order] is NULL AND d.[Years Since Last IJP Sub] IS NULL AND d.[Years Since Last PEP Sub] is NULL THEN 1 ELSE 0 END)
,RedundantIJPSubscriber = sum(CASE WHEN d.[Years Since Last IJP Order] > @RetentionYears AND d.[Years Since Last IJP Sub] > @RetentionYears THEN 1 ELSE 0 END)
,RedundantPEPSubs = sum(CASE WHEN d.[Years Since Last PEP Order] > @RetentionYears AND d.[Years Since Last IJP Sub] > @RetentionYears THEN 1 ELSE 0 END)
,RedundantPEPandIJPSubs = sum(CASE WHEN d.[Years Since Last PEP Order] > @RetentionYears or d.[Years Since Last IJP Order] > @RetentionYears AND d.[Years Since Last PEP Sub] > @RetentionYears or d.[Years Since Last IJP Sub] > @RetentionYears THEN 1 ELSE 0 END)
,InPEPSpecialGroup = sum(CASE WHEN d.[Current and in PEP Special Groups] =1 THEN 1 ELSE 0 END)
,SubsToBeRemovedCount = (SELECT COUNT(*) FROM #SubsToRemove)
from Subscriber s
	inner join  #Subs d
	on d.SubscriberId = s.SubscriberId 
group by
s.EntityType 
order by
s.EntityType desc



IF @DoRemove =1
BEGIN
	DECLARE @SubsciberIdToRemove INT
		,@DELETECount INT =0
		,@ObfuscateCount INT =0

	SELECT @RemoveMessage = CAST(COUNT(*) AS VARCHAR) + ' Subscibers to remove'	FROM #SubsToRemove;Print @RemoveMessage ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage

	DECLARE cur CURSOR FOR
	SELECT SubscriberId 
	FROM #SubsToRemove

	Open cur 
	FETCH cur INTO @SubsciberIdToRemove
	DECLARE @LastWrite INT = 0
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		BEGIN TRY
			EXEC sp119DeleteOrObfuscateSubscriber @SubscriberId= @SubsciberIdToRemove, @RunByUserId=1,@ReturnMessage=@RemoveMessage OUTPUT
			IF PATINDEX('%delete%',@RemoveMessage) >0 
				SET @DELETECount += 1
			ELSE
				SET @ObfuscateCount += 1
			--EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
			IF (@DELETECount + @ObfuscateCount) = 5
				OR (@DELETECount + @ObfuscateCount) >= @LastWrite + 200
			BEGIN
			SET @RemoveMessage = CAST(@DELETECount AS VARCHAR) + ' Deleted, ' + CAST(@ObfuscateCount AS VARCHAR) + ' Obfuscated So Far ';Print @RemoveMessage ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
				SET @LastWrite += 200
			END
		END TRY
		BEGIN Catch
			SET @RemoveMessage = 'Remove For SubscriberId:' + CAST(@SubsciberIdToRemove AS VARCHAR) + ' failed:' + ERROR_MESSAGE();Print @RemoveMessage ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
		END Catch

		FETCH cur INTO @SubsciberIdToRemove
	END
		SET @RemoveMessage = CAST(@DELETECount AS VARCHAR) + ' Deleted in total';Print @RemoveMessage ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
		SET @RemoveMessage = CAST(@ObfuscateCount AS VARCHAR) + ' Obfuscated in total';Print @RemoveMessage ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
		EXEC sp029UpdateBatchLog @BatchLogId,'Complete','Complete'

	CLOSE cur 
	DEALLOCATE cur 
END

select
s.EntityType 
,TotalNo = count(*)
,TotalCurrent = sum(CASE WHEN s.SubscriberStatus = 'Current' THEN 1 ELSE 0 END)
,TotalNonCurrent = sum(CASE WHEN s.SubscriberStatus <> 'Current' THEN 1 ELSE 0 END)
,NoIJPorPEPOrderOrSub = sum(CASE WHEN d.[Years Since Last IJP Order] IS NULL AND d.[Years Since Last PEP Order] is NULL AND d.[Years Since Last IJP Sub] IS NULL AND d.[Years Since Last PEP Sub] is NULL THEN 1 ELSE 0 END)
,RedundantIJPSubscriber = sum(CASE WHEN d.[Years Since Last IJP Order] > @RetentionYears AND d.[Years Since Last IJP Sub] > @RetentionYears THEN 1 ELSE 0 END)
,RedundantPEPSubs = sum(CASE WHEN d.[Years Since Last PEP Order] > @RetentionYears AND d.[Years Since Last IJP Sub] > @RetentionYears THEN 1 ELSE 0 END)
,RedundantPEPandIJPSubs = sum(CASE WHEN d.[Years Since Last PEP Order] > @RetentionYears or d.[Years Since Last IJP Order] > @RetentionYears AND d.[Years Since Last PEP Sub] > @RetentionYears or d.[Years Since Last IJP Sub] > @RetentionYears THEN 1 ELSE 0 END)
,InPEPSpecialGroup = sum(CASE WHEN d.[Current and in PEP Special Groups] =1 THEN 1 ELSE 0 END)
,SubsToBeRemovedCount = (SELECT COUNT(*) FROM #SubsToRemove)

from Subscriber s
	inner join  #Subs d
	on d.SubscriberId = s.SubscriberId 
group by
s.EntityType 
order by
s.EntityType desc


--select * from #Subs 
--order by SubscriberId 

DROP TABLE #SubsToRemove
DROP TABLE #Subs

select b.BatchLogId 
	,l.DateTime 
	,l.BatchLogLineText 
from BatchLog b
	left join BatchLogLine l
	on l.BatchLogId = b.BatchLogId 
where b.BatchlogId = @BatchLogId 
order by l.DateTime 
rollback TRAN




 