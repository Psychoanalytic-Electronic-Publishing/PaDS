begin tran
ALTER TABLE ContentSet DROP COLUMN LastUpdatedDateTime, LastUpdatedByUserId
ALTER TABLE ContentSetSource DROP COLUMN LastUpdatedDateTime, LastUpdatedByUserId
ALTER TABLE ContentSetSourceItem DROP COLUMN LastUpdatedDateTime, LastUpdatedByUserId
ALTER TABLE Lookup DROP COLUMN LastUpdatedDateTime, LastUpdatedByUserId
ALTER TABLE ProductAffiliateRate DROP COLUMN LastUpdatedDateTime, LastUpdatedByUserId
ALTER TABLE ProductContentSet DROP COLUMN LastUpdatedDateTime, LastUpdatedByUserId
ALTER TABLE ProductQualifyingProduct DROP COLUMN LastUpdatedDateTime, LastUpdatedByUserId
ALTER TABLE RemoteUserRights DROP COLUMN LastUpdatedDateTime, LastUpdatedByUserId
ALTER TABLE SalesOrderLinePart DROP COLUMN LastUpdatedDateTime, LastUpdatedByUserId
ALTER TABLE stblParameters DROP COLUMN LastUpdatedDateTime, LastUpdatedByUserId
ALTER TABLE SubscriberAffiliate DROP COLUMN LastUpdatedDateTime, LastUpdatedByUserId
ALTER TABLE SubscriberImportBatch DROP COLUMN LastUpdatedDateTime, LastUpdatedByUserId



commit tran