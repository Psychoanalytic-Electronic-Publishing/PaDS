IF  exists (select * from dbo.sysobjects where id = object_id(N'sp601PopulateActivityLog') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp601PopulateActivityLog
GO
CREATE  PROCEDURE sp601PopulateActivityLog (
		@BatchLogId INT = NULL
)
AS
--12/8/21	James Woosnam	Re-arranged to reduce the amount of time the transaction is open for and to optimise some of the queries so as not to lock front end
--21/3/22	James Woosnam	SIR5463 - Change AffiliateRateSubscriber to ReportingParentSubscriber
--20/4/22	James Woosnam	SIR5486 - Use vw433SalesOrderReportingParent and don't add if no reporting parent

DECLARE @Message VARCHAR(MAX) = ''
		,@RowCount INT = 0
		,@ThrowError BIT = 0
		,@NewLine VARCHAR(10) = '<br>'

DECLARE @UserActionLogLastPEPWebLogId INT = NULL
	,@UserActionLogLastPEPWebSessionLogIdForAbstract INT = NULL
	,@UserActionLogLastPEPWebSessionLogIdForSearch INT = NULL
	,@MaxUserActionLogIdBeforeInserts INT = NULL
	,@UserActionLogStartFromDateTime DATETIME = NULL


BEGIN TRY
	SELECT @UserActionLogStartFromDateTime = ParameterValue FROM stblParameters WHERE ParameterName = 'UserActionLogStartFromDateTime'
	IF @UserActionLogStartFromDateTime IS NULL SET @UserActionLogStartFromDateTime ='01-FEB-2021'
	SELECT @MaxUserActionLogIdBeforeInserts = ISNULL(MAX(UserActionLogId),0) FROM UserActionLog
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@MaxUserActionLogIdBeforeInserts=' +CAST(@MaxUserActionLogIdBeforeInserts AS VARCHAR) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	SELECT 
		us.UserSessionId 
		,UserId = MAX(us.UserId )
		,UserName = MAX(us.UserName )
		,SubscriberId = MAX(CASE WHEN usd.DataItemName = 'SubscriberId' THEN usd.DataItemValue ELSE '0' END)
		,SubscriberName = CAST(NULL AS VARCHAR(150))
		,OrderNumber = MAX(CASE WHEN usd.DataItemName  = 'SubscriptionOrderNumber' THEN usd.DataItemValue ELSE '0' END)
		,LoggedInMethod = MAX(CASE WHEN usd.DataItemName  = 'LoggedInMethod' THEN usd.DataItemValue ELSE '0' END)
		,UserType = MAX(CASE WHEN usd.DataItemName = 'UserType' THEN usd.DataItemValue ELSE '0' END)
		,ReportingParentSubscriberName =CAST(NULL AS VARCHAR(150))
		,ReportingParentSubscriberId = CAST(NULL AS INT)
	INTO #SessOrder
	FROM UserSession us  With (nolock)
		LEFT JOIN UserSessionData usd  With (nolock)
		ON usd.UserSessionId = us.UserSessionId 
	WHERE us.UserId <> -1
	AND us.LastAccessedDate >= @UserActionLogStartFromDateTime
	AND us.LastAccessedDate >= DATEADD(DAY,-14,ISNULL((SELECT DateTime FROM UserActionLog WHERE UserActionLogId = @MaxUserActionLogIdBeforeInserts),@UserActionLogStartFromDateTime))
	GROUP BY
		us.UserSessionId 
		,us.UserId 
		,us.UserName 
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #SessOrder records added';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	UPDATE #SessOrder
	SET SubscriberName = s.SubscriberName
		,ReportingParentSubscriberId = so.ReportingParentSubscriberId
		,ReportingParentSubscriberName = rps.SubscriberName 
	FROM #SessOrder sess
		LEFT JOIN Subscriber s
		ON s.SubscriberId = sess.SubscriberId
--20/4/22	James Woosnam	SIR5486 - Use vw433SalesOrderReportingParent 
		LEFT JOIN vw433SalesOrderReportingParent so
			LEFT JOIN Subscriber rps
			ON rps.SubscriberId = so.ReportingParentSubscriberId
		ON so.OrderNumber = sess.OrderNumber
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #SessOrder records updated';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	DELETE FROM #SessOrder WHERE ReportingParentSubscriberId IS NULL
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #SessOrder deleted as ReportingParentSubscriberId IS NULL';EXEC sp029UpdateBatchLog @BatchLogId, @Message

--20/9/21	james Woosnam	SIR5325 - No longer user parameters as can get from FromLogRecordWithId in UserActionLog
	DELETE FROM stblParameters WHERE ParameterName IN ( 'UserActionLogLastPEPWebLogId','UserActionLogLastPEPWebSessionLogId')


	SELECT * INTO #UAL FROM UserActionLog WHERE 1=2
--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add Requests from PEPwebUsageLog
	SELECT @UserActionLogLastPEPWebLogId = ISNULL(MAX(FromLogRecordWithId),0) FROM UserActionLog WHERE ActionType IN ('No_License','Request')
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@UserActionLogLastPEPWebLogId=' +CAST(@UserActionLogLastPEPWebLogId AS VARCHAR(20)) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	INSERT INTO #UAL (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Publisher_ID
		,Section_Type
		,ItemId
	)

	SELECT
		FromLogRecordWithId = CAST(l.PEPWebUsageLogId AS VARCHAR(20))
		,l.UserSessionId 
		,l.DateTime 
		,MonthStartDate = '01-' + FORMAT(l.dateTime,'MMM-yyyy')
		,ActionType =  CASE WHEN l.LogonStatus='Failed' THEN 'No_License'
						ELSE 'Request' END
		,so.UserId 
		,so.SubscriberId 
		,so.SubscriberName 
		,Institution_Id = so.ReportingParentSubscriberId
		,Institution_Name = so.ReportingParentSubscriberName 
		,Access_Type = CASE WHEN l.AdditionalDetails like '%universal access%' THEN 'OA_Gold' ELSE 'Controlled' END --OA_Gold (Gold Open Access) , Controlled
		,Access_Method = 'Regular'
		,Publisher_ID = 'xxxx'
		,Section_Type = 'Artical' --Identifies the type of section that was accessed by the user, including Article, Book, Chapter, Other and Section. Used primarily for reporting on book usage where content is delivered by section.
		,ItemId =l.documentId
	FROM PEPWebUsageLog l
		INNER JOIN #SessOrder so
		ON so.UserSessionId = l.UserSessionId
	where 1=1
	and l.PEPWebUsageLogId >@UserActionLogLastPEPWebLogId
	AND l.DateTime >= @UserActionLogStartFromDateTime
	AND isnumeric(l.username)=1
	AND l.ActionType IN ( 'Authorise')
--20/9/21	james Woosnam	SIR5325 - Stop getting Abstarct from PEPWebUsageLog as un-reliable
	AND l.ReasonForCheck  IN ('DocumentView')
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAL records added for FullRead/Request';EXEC sp029UpdateBatchLog @BatchLogId, @Message

--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add Abstract Actions from PEPWebSessionLog
--20/9/21	james Woosnam	SIR5325 - Get Abstarct from PEPWebSessionLog
	SELECT @UserActionLogLastPEPWebSessionLogIdForAbstract = ISNULL(MAX(FromLogRecordWithId),0) FROM UserActionLog WHERE ActionType IN ('Investigation')
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@UserActionLogLastPEPWebSessionLogIdForAbstract=' +CAST(@UserActionLogLastPEPWebSessionLogIdForAbstract AS VARCHAR(20)) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message
	INSERT INTO #UAL (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Publisher_ID
		,Section_Type
		,ItemId
	)

	SELECT
		FromLogRecordWithId = CAST(l.PEPWebSessionLogId AS VARCHAR(20))
		,UserSessionId = l.UserSessionId 
		,DateTime = l.LastUpdate
		,MonthStartDate = '01-' + FORMAT(l.LastUpdate,'MMM-yyyy')
		,ActionType = 'Investigation'
		,UserId = so.UserId 
		,SubscriberId = so.SubscriberId
		,SubscriberName = so.SubscriberName
		,Institution_Id = so.ReportingParentSubscriberId
		,Institution_Name = so.ReportingParentSubscriberName
		,Access_Type = 'Controlled'
		,Access_Method = 'Regular'
		,Publisher_ID = 'xxxx'
		,Section_Type = 'Artical' --Identifies the type of section that was accessed by the user, including Article, Book, Chapter, Other and Section. Used primarily for reporting on book usage where content is delivered by section.
		,ItemId =l.ItemOfInterest 
	FROM PEPWebSessionLog l
		INNER JOIN #SessOrder so
		ON so.UserSessionId = l.UserSessionId 
	where 1=1
	AND l.Endpoint = '/Documents/Abstracts/{documentID}/'
	and l.PEPWebSessionLogId  >@UserActionLogLastPEPWebSessionLogIdForAbstract
	AND l.LastUpdate >= @UserActionLogStartFromDateTime
	SET @RowCount = @@ROWCOUNT 
	SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAL Abstract/Investigation records added';EXEC sp029UpdateBatchLog @BatchLogId, @Message

--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
	DELETE FROM #UAL 
	WHERE UserActionLogId IN (
			SELECT DISTINCT
				l2.UserActionLogId 
			FROM #UAL l
				INNER JOIN #UAL l2
				ON l2.UserSessionId = l.UserSessionId 
				AND l2.ActionType = l.ActionType 
				AND l2.Access_Type = l.Access_Type 
				AND l2.Access_Method = l.Access_Method 
				AND l2.ItemId = l.ItemId 
				AND l2.DateTime BETWEEN DATEADD(SECOND,-30,l.DateTime) AND l.DateTime 
				AND l2.UserActionLogId <> l.UserActionLogId 
			WHERE l.UserActionLogId > @MaxUserActionLogIdBeforeInserts
			)
	SET @RowCount = @@ROWCOUNT ;SET @Message =  CAST(@RowCount AS VARCHAR) + ' #UAL rows deleted as within 30seconds of duplicate';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	UPDATE #UAL
	SET 
			Data_Type = CAST(ISNULL(c.Data_Type ,b.Data_Type) AS VARCHAR(50)) --Article, Book, Book_Segment, Database, Dataset, Journal, Multimedia, Newspaper_or_Newsletter, Other, Platform, Report, Repository_Item, and Thesis_or_Dissertation
			,TitleId = ISNULL(c.PEPCode,b.PEPCode)
			,TitleName = ISNULL(c.Title,b.Title)
			,ItemId = ISNULL(d.documentID,l.ItemId )
			,ItemName = ISNULL(d.documentRef ,b.title )
			,YOP = ISNULL(d.year ,b.pub_year)
			,ISSN = ISNULL(c.ISSN,b.ISSN)
			,ISBN = ISNULL(c.ISBN,b.ISBN)
			,Language = ISNULL(c.language,b.language)
	FROM #UAL l
			LEFT JOIN ContentDocuments d
				LEFT JOIN (
					SELECT j.PEPCode 
						,j.sourceType 
						,j.Title 
						,j.ISSN 
						,ISBN = CAST('' AS VARCHAR(50))
						,j.language 
						,Data_Type = CAST('Journal' AS VARCHAR(50))
					FROM ContentJournals j
					UNION
					SELECT v.PEPCode 
						,v.sourceType 
						,v.Title 
						,v.ISSN 
						,ISBN = CAST('' AS VARCHAR(50))
						,v.language 
						,Data_Type = CAST('Multimedia' AS VARCHAR(50))
					FROM ContentVideos v
					) c
				ON c.PEPCode = d.PEPCode 
			ON d.documentID = l.ItemId  
			LEFT JOIN (
				SELECT b.PEPCode 
					,b.sourceType 
					,b.documentID 
					,b.Title 
					,b.ISSN 
					,ISBN = b.ISBN13 
					,b.language
					,Data_Type = 'Book' --Might be book????  Book_Segment  A book segment (e.g. chapter, section, etc.). Note that Data_Type Book_Segment is only applicable for Item Reports when the book segment is the item, in Title Reports this is represented by the Section_Type.
					,b.pub_year
				FROM ContentBooks b
				) b
		on b.documentID = l.ItemId   
		or replace(l.ItemId ,'.','') like b.PEPCode + '%'
	WHERE ISNULL(l.ItemId,'')<>''
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAL records updated with Document details';EXEC sp029UpdateBatchLog @BatchLogId, @Message


--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add additional Investigation for each request
	INSERT INTO #UAL (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type
		,Publisher_ID
		,Section_Type
		,TitleId
		,TitleName
		,ItemId
		,ItemName
		,YOP
		,ISSN
		,ISBN
		,[Language]
	)
	SELECT
		FromLogRecordWithId = CAST(FromLogRecordWithId AS VARCHAR(20))
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType='Investigation'
		,UserId
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type
		,Publisher_ID
		,Section_Type
		,TitleId
		,TitleName
		,ItemId
		,ItemName
		,YOP
		,ISSN
		,ISBN
		,[Language]
	FROM #UAL 
	WHERE ActionType = 'Request'
	SET @RowCount = @@ROWCOUNT 
	SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAL Investigations records added for copy Requests';EXEC sp029UpdateBatchLog @BatchLogId, @Message


--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add Search Actions
	SELECT @UserActionLogLastPEPWebSessionLogIdForSearch = ISNULL(MAX(FromLogRecordWithId),0) FROM UserActionLog WHERE ActionType IN ('Search')
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@UserActionLogLastPEPWebSessionLogIdForSearch=' +CAST(@UserActionLogLastPEPWebSessionLogIdForSearch AS VARCHAR(20)) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	INSERT INTO #UAL (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type 
	)
	SELECT
		FromLogRecordWithId = CAST(l.PEPWebSessionLogId AS VARCHAR(20))
		,l.UserSessionId 
		,l.LastUpdate 
		,MonthStartDate = '01-' + FORMAT(l.LastUpdate,'MMM-yyyy')
		,ActionType = 'Search'
		,so.UserId 
		,so.SubscriberId 
		,so.SubscriberName 
		,Institution_Id = so.ReportingParentSubscriberId
		,Institution_Name = so.ReportingParentSubscriberName
		,Access_Type = 'Controlled' 
		,Access_Method = 'Regular'
		,Data_Type ='Database'
	FROM PEPWebSessionLog l
		INNER JOIN #SessOrder so
		ON so.UserSessionId = l.UserSessionId 
	where 1=1
	AND l.Endpoint = '/Database/Search/'
	AND l.Params LIKE '%user=true%'
	and l.PEPWebSessionLogId  >@UserActionLogLastPEPWebSessionLogIdForSearch
	AND l.LastUpdate >= @UserActionLogStartFromDateTime
	SET @RowCount = @@ROWCOUNT 
	SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAL Search records added';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	UPDATE #UAL 
	set		LoggedInMethod = (SELECT max(CAST(usd.DataItemValue AS VARCHAR(100)))  FROM UserSessionData usd where usd.DataItemName='LoggedInMethod' AND CAST(usd.UserSessionId AS VARCHAR(50))=UserSessionId )
			,UserType = (SELECT max(CAST(usd.DataItemValue AS VARCHAR(100)))  FROM UserSessionData usd where usd.DataItemName='UserType' AND CAST(usd.UserSessionId AS VARCHAR(50))=UserSessionId )
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAL records updated with UserSession Details';EXEC sp029UpdateBatchLog @BatchLogId, @Message


END TRY
BEGIN CATCH
	
	SELECT @Message ='sp601PopulateActivityLog Failed:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE();EXEC sp029UpdateBatchLog @BatchLogId, @Message
	RAISERROR ('%s', 18, 1,@Message)
	RETURN
END CATCH

BEGIN TRY
	INSERT INTO UserActionLog (
			FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,LoggedInMethod
		,UserType
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type
		,Publisher_ID
		,Section_Type
		,TitleId
		,TitleName
		,ItemId
		,ItemName
		,YOP
		,ISSN
		,ISBN
		,[Language])
	SELECT 
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,LoggedInMethod
		,UserType
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type
		,Publisher_ID
		,Section_Type
		,TitleId
		,TitleName
		,ItemId
		,ItemName
		,YOP
		,ISSN
		,ISBN
		,[Language]
	FROM #UAL 
	SET @RowCount = @@ROWCOUNT 
	SET @Message = CAST(@RowCount AS VARCHAR) + ' UserActionLog rows added from #UAL';EXEC sp029UpdateBatchLog @BatchLogId, @Message

END TRY
BEGIN CATCH
	SELECT @Message ='Add UserActionLog records Failed:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE() ;EXEC sp029UpdateBatchLog @BatchLogId, @Message
	RAISERROR ('%s', 18, 1,@Message)
END CATCH	
GO
GRANT EXECUTE ON sp601PopulateActivityLog to PaDSSQLServerUser
