if exists (select * from dbo.sysobjects where id = object_id(N'sp118CreateProposedSubscriber') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp118CreateProposedSubscriber
GO

CREATE PROCEDURE sp118CreateProposedSubscriber(
				@OriginalSubscriberId INT
				,@UserName20 VARCHAR(20)
				,@NewSubscriberId INT OUTPUT
				)
AS				
--Modification History
--22/6/11 - James Woosnam - Change insert subscriber address to use NewIdCol value
--7/7/11	James Woosnam	Do not copy ('Redundant','Deleted') addresses to proposed subscriber 
--12/3/12   Julian Gates  - Add code to add all potential address types to #SubscriberAddress temp table
--20/3/15	Julian Gates	SIR3785 - Add IsSpanishIJPESSubscriber
--19/11/19	James Woosnam	SIR4763 - Nullify WebUser fields
--6/1/20   James Woosnam    SIR4094 - Change end date to 31-Dec-4949 from 01-Jan-2020
--10/1/20	James Woosnam	SIR4977 - If exists switch user to proposed sub

DECLARE @Message varchar(8000) = ''
DECLARE @ErrorFound INT = 0
EXEC sp005GetNextTableNumber 'Subscriber',@NewSubscriberId OUTPUT
BEGIN TRAN
BEGIN TRY
	BEGIN TRY

		INSERT INTO Subscriber 
		SELECT SubscriberId = @NewSubscriberId
			  ,SubscriberName
			  ,SubscriberStatus = 'Proposed'
			  ,EntityType
			  ,PrimaryCountryId
			  ,SubscriberCategory
			  ,IsAccount
			  ,ReportCategory
			  ,VATNumber
			  ,MailMethod
			  ,DefaultPostalAddressId
			  ,IsReceiveMail
			  ,UpdateToSubscriberId = @OriginalSubscriberId 
			  ,ContactName
			  ,FirstName
			  ,LastName
			  ,Title
			  ,Salutation
			  ,Position
			  ,Qualifications
			  ,MembershipType
			  ,IsTrainingAnalyst
			  ,IsChildAnalyst
			  ,IsRetired
			  ,GeographicalStatus
			  ,Spare1
			  ,Spare2
			  ,Spare3
			  ,Notes
			  ,CreatedDateTime
			  ,CreatedByUserId
			  ,LastUpdatedDateTime = GETDATE()
			  ,LastUpdatedByUserId = @UserName20 
			  ,MetapressId
			  ,IsSpanishIJPESSubscriber
			  ,IsReportingParentOverride
		FROM Subscriber
		WHERE SubscriberId = @OriginalSubscriberId
	END TRY
	BEGIN CATCH
		SET @Message = 'Subscriber Insert Failed - ' + ERROR_MESSAGE()
		RAISERROR (@Message, 16, 1)
		SET @ErrorFound = 1
	END CATCH

	IF @ErrorFound = 0
	BEGIN TRY
		INSERT INTO SubscriberAffiliate
		SELECT ParentSubscriberID
			  ,@NewSubscriberId 
			  ,StartDate
			  ,EndDate
			  ,AffiliateReferenceID
			  ,SubscriberCategory
			  ,LastUpdatedDateTime = GETDATE()
			  ,LastUpdatedByUserId = @UserName20 
        FROM SubscriberAffiliate
		WHERE ChildSubscriberId = @OriginalSubscriberId
	END TRY
	BEGIN CATCH
		SET @Message = 'SubscriberAffiliate Insert Failed - ' + ERROR_MESSAGE()
		RAISERROR (@Message, 16, 1)
		SET @ErrorFound = 1
	END CATCH

	IF @ErrorFound = 0
	BEGIN TRY
		--Add affiliation to orginal record so that Individual users can see it
		INSERT INTO SubscriberAffiliate
		VALUES ( @OriginalSubscriberId 
			  ,@NewSubscriberId 
			  ,GETDATE()
--6/1/20   James Woosnam    SIR4094 - Change end date to 31-Dec-4949 from 01-Jan-2020
			  ,'31-dec-4949'
			  ,@NewSubscriberId
			  ,	NULL
			  , GETDATE()
			  , @UserName20 
			  )
	END TRY
	BEGIN CATCH
		SET @Message = 'SubscriberAffiliate Insert Failed - ' + ERROR_MESSAGE()
		RAISERROR (@Message, 16, 1)
		SET @ErrorFound = 1
	END CATCH

--Company Account
	IF @ErrorFound = 0
	BEGIN TRY
		INSERT INTO CompanyAccount 
		SELECT 
			@NewSubscriberId 
			,CompanyId
			,AccountNumber
			,CompanyAccountStatus
			,AccountType
			,DiscountRateID
			,RateType
			,BillingAddressId
			,Notes
			,RequireReceipt
			,RequireInvoice
			,CreatedDateTime
			,CreatedByUserId 
			  ,LastUpdatedDateTime = GETDATE()
			  ,LastUpdatedByUserId = @UserName20 
		FROM CompanyAccount
		WHERE SubscriberId = @OriginalSubscriberId

	END TRY
	BEGIN CATCH
		SET @Message = 'CompanyAccount Insert Failed - ' + ERROR_MESSAGE()
		RAISERROR (@Message, 16, 1)
		SET @ErrorFound = 1
	END CATCH
	
--Address
--22/6/11 - James Woosnam - Change insert subscriber address to use NewIdCol value
	IF @ErrorFound = 0
	BEGIN TRY
		--Add affiliation to orginal record so that Individual users can see it
		SELECT SubscriberAddressId
			  ,SubscriberId
			  ,AddressType
			  ,AddressDescription
			  ,AddressText
			  ,CountryId
			  ,InvalidAddress
			  ,Address1
			  ,Address2
			  ,Address3
			  ,Address4
			  ,Town
			  ,County
			  ,PostCode
			  ,Notes
			  ,CreatedDateTime
			  ,CreatedByUserId
			  ,LastUpdatedDateTime
			  ,LastUpdatedByUserId
			  ,UpdateExistingOrdersDeliveryAddress = ISNULL(UpdateExistingOrdersDeliveryAddress,0)
		INTO #SubscriberAddress			  
 		FROM SubscriberAddress
		WHERE SubscriberId = @OriginalSubscriberId
--7/7/11	James Woosnam	Do not copy ('Redundant','Deleted') addresses to proposed subscriber 		
		AND SubscriberAddress.AddressDescription NOT IN ('Redundant','Deleted')
		
--12/3/12   Julian Gates  - Add code to add all potential address types to #SubscriberAddress temp table
		INSERT INTO #SubscriberAddress
		SELECT
				SubscriberAddressId = 0
			  ,SubscriberId = @OriginalSubscriberId
			  ,AddressType = at.AddressType 
			  ,AddressDescription = at.AddressDescription 
			  ,AddressText = ''
			  ,CountryId = (SELECT MAX(CountryId) FROM #SubscriberAddress)
			  ,InvalidAddress = NULL 
			  ,Address1 = NULL 
			  ,Address2 = NULL 
			  ,Address3 = NULL 
			  ,Address4 = NULL 
			  ,Town = NULL 
			  ,County = NULL 
			  ,PostCode = NULL 
			  ,Notes = ''
			  ,CreatedDateTime = GETDATE()
			  ,CreatedByUserId = @UserName20
			  ,LastUpdatedDateTime = GETDATE()
			  ,LastUpdatedByUserId = @UserName20
			  ,UpdateExistingOrdersDeliveryAddress=0
		FROM Subscriber s
			CROSS JOIN (SELECT AddressType = 'Email'
							,AddressDescription = 'Main'
					) at
			LEFT JOIN #SubscriberAddress sa
			ON at.AddressDescription = sa.AddressDescription 
			and at.AddressType = sa.AddressType 
		WHERE s.SubscriberId = @OriginalSubscriberId
		AND sa.AddressDescription IS NULL		
							
		ALTER TABLE #SubscriberAddress ADD
			NewIdCol int NOT NULL IDENTITY (1, 1)

		DECLARE @FirstNewSubscriberAddressId INT = 0
		EXEC sp005GetNextTableNumber 'SubscriberAddress',@FirstNewSubscriberAddressId OUTPUT
		INSERT INTO SubscriberAddress (
				SubscriberAddressId
			  ,SubscriberId
			  ,AddressType
			  ,AddressDescription
			  ,AddressText
			  ,CountryId
			  ,InvalidAddress
			  ,Address1
			  ,Address2
			  ,Address3
			  ,Address4
			  ,Town
			  ,County
			  ,PostCode
			  ,Notes
			  ,CreatedDateTime
			  ,CreatedByUserId
			  ,LastUpdatedDateTime
			  ,LastUpdatedByUserId
			  ,UpdateExistingOrdersDeliveryAddress 
		)
		SELECT 
				@FirstNewSubscriberAddressId + NewIdCol
			  ,@NewSubscriberId 
			  ,AddressType
			  ,AddressDescription
			  ,AddressText
			  ,CountryId
			  ,InvalidAddress
			  ,Address1
			  ,Address2
			  ,Address3
			  ,Address4
			  ,Town
			  ,County
			  ,PostCode
			  ,Notes
			  ,CreatedDateTime
			  ,CreatedByUserId
			  ,LastUpdatedDateTime = GETDATE()
			  ,LastUpdatedByUserId = @UserName20 
			  ,UpdateExistingOrdersDeliveryAddress 
		FROM #SubscriberAddress
		
		UPDATE stblTableNumber SET LastNumber = @FirstNewSubscriberAddressId + (SELECT MAX(NewIdCol) FROM #SubscriberAddress)
		WHERE TableName = 'SubscriberAddress'
		
	END TRY
	BEGIN CATCH
		SET @Message = 'SubscriberAddress Insert Failed - ' + ERROR_MESSAGE()
		RAISERROR (@Message, 16, 1)
		SET @ErrorFound = 1
	END CATCH

--Remote User
--10/1/20	James Woosnam	SIR4977 - If exists switch user to proposed sub
	IF @ErrorFound = 0
	BEGIN TRY
--3/8/21	James Woosnam	SIR5285 - If the subscriber has multiple users then online editting is not allowed.  This shouldn't be the case for Individual subscribers, but could be for group users, in which case editing online doesn't make sense.
		SET @Message = ''
		SELECT  @Message = ISNULL('SubscriberId:' + CAST(@OriginalSubscriberId as VARCHAR) + '(' + MIN(s.subscriberName) + ') be has multiple users therefore can''t be editted online.','')
		FROM RemoteUser ru
			INNER JOIN RemoteUserRights ror
				INNER JOIN Subscriber s
				ON s.SubscriberId = ror.RightsToId 
			ON ror.UserId = ru.UserId 
		WHERE ror.RightsToId = @OriginalSubscriberId 
		AND ru.UserStatus in ('Active','Proposed')
		GROUP BY ror.RightsToId 
		HAVING COUNT(*) >1
		IF @Message <> '' 
			RAISERROR (@Message, 16, 1)

		UPDATE RemoteUser 
		SET UserNameBeforeProposed = UserName 
		FROM RemoteUser ru
			INNER JOIN RemoteUserRights ror
			ON ror.UserId = ru.UserId 
			AND ror.RightsToId = @OriginalSubscriberId 

		UPDATE RemoteUserRights
		SET RightsToId = @NewSubscriberId 
		WHERE RightsToId = @OriginalSubscriberId 

	END TRY
	BEGIN CATCH
		SET @Message = 'RemoteUser Update Failed - ' + ERROR_MESSAGE()
		RAISERROR (@Message, 16, 1)
		SET @ErrorFound = 1
	END CATCH

	COMMIT TRAN
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SET @Message = 'sp118CreateProposedSubscriber Failed - ' + ERROR_MESSAGE()
	RAISERROR (@Message, 16, 1)
END CATCH


GO

Grant EXECUTE ON sp118CreateProposedSubscriber to PaDSSQLServerUser
