if exists (select * from dbo.sysobjects where id = object_id(N'sp148SalesOrderLists') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure sp148SalesOrderLists
Go
CREATE PROCEDURE sp148SalesOrderLists
(
			@OrderNumber int
			,@ListType VARCHAR(20) = 'Subscribers'--'Subscribers','Products'
			,@MainFilter VARCHAR(50) = ''
			)				
AS
--05/05/20	Julian Gates Initial Version
--1/8/20	James Woosnam	SIR5051 - Use all if no delivery area
--4/1/21	Julian Gates SIR5156 - Only show Current and Proposed Subscribers in list.
--19/8/21	James Woosnam	SIR5237 - Add Affiliate rate details
--7/11/21	James Woosnam	SIR5362 - Only hide associated products if the parent hasn't been purchased in this order
IF @ListType = 'Subscribers'
BEGIN
	SELECT TOP 100 PERCENT 
		so.OrderNumber 
		,s.SubscriberId 
		,s.SubscriberName 
		,SubIdAndName = s.SubscriberName + ' (' + CAST(s.SubscriberId AS VARCHAR) +')'
		,Included = CASE WHEN sol.SubscriberId IS NULL THEN 0 ELSE 1 END
		,IncludedYN = CASE WHEN sol.SubscriberId IS NULL THEN 'N' ELSE 'Y' END
		,DeliveryAddressId = ISNULL(sol.DeliveryAddressId , s.DefaultPostalAddressId  )
		,DeliveryAddress = dbo.f530SubscriberAddressDisplay( ISNULL(sol.DeliveryAddressId , s.DefaultPostalAddressId  ),'SingleLine')
		,ProductRateId = pr.ProductRateId 
		,ProductRateDescription = FORMAT(pr.ProductRate,'N2') + pr.SubscriberCategory 
		,Quantity = ISNULL(sol.Quantity ,null)
		,sol.AmountProduct 
		,AssociatedProductCode = assProd.ProductCode 
		,HasAssociatedProduct = CASE WHEN assProd.ProductCode is NULL THEN 0 ELSE 1 END
		,IncludesAssociatedProduct = CASE WHEN (SELECT MAX(sol2.OrderNumber)  
											FROM SalesOrderLine sol2 
											WHERE sol2.SubscriberId = s.SubscriberId 
											AND sol2.ProductCode = assProd.ProductCode 
											AND sol2.OrderNumber = so.OrderNumber  
											) IS NULL THEN 0 ELSE 1 END
		,AssociatedProductAmount = (SELECT SUM(sol2.AmountProduct)  
											FROM SalesOrderLine sol2 
											WHERE sol2.SubscriberId = s.SubscriberId 
											AND sol2.ProductCode = assProd.ProductCode 
											AND sol2.OrderNumber = so.OrderNumber  
											)
		,sol.SalesOrderLineID
		,sol.IsCancel 
		,sol.CancelledDate 
--23/8/21	James Woosnam	SIR5237 - Add as a HotFix
		,AffiliateRateSubscriberId = NULL
		,AffiliateRateSubscriberName = NULL
		,IsShipped = CAST(CASE WHEN p.ShippedProductFlag = 1 OR assProd.ShippedProductFlag=1 THEN 1 ELSE 0 END AS BIT)
	FROM SalesOrder so
		INNER JOIN Product p
			LEFT JOIN Product assProd
			On assProd.ProductCode = p.AssociatedProductCode 
		On p.ProductCode = so.PrimaryProductCode 
		INNER JOIN Company c
		ON c.CompanyId = so.CompanyId 
		INNER JOIN CompanyAccount ca
		ON ca.SubscriberId = so.SubscriberId 
		AND ca.CompanyId = so.CompanyId 
		INNER JOIN SubscriberAffiliate sa
		ON sa.ParentSubscriberID = so.SubscriberId 
--14/1/21	James Woosnam	Add Date criteria to Affiliate join
		AND getdate() between sa.StartDate AND sa.EndDate 
		LEFT JOIN SalesOrderLine sol
		ON so.OrderNumber = sol.OrderNumber 
		AND sol.ProductCode = so.PrimaryProductCode 
		AND (sol.SubscriberId = sa.ChildSubscriberID OR sol.SubscriberId IS NULL)
		LEFT JOIN Subscriber s
		ON s.SubscriberId = ISNULL(sa.ChildSubscriberId,sol.SubscriberId )
		LEFT JOIN SubscriberAffiliate compAffil
		ON compAffil.ChildSubscriberID = s.SubscriberId 
		AND compAffil.ParentSubscriberID = c.GroupParentSubscriberId 
		AND getdate() BETWEEN compAffil.StartDate AND compAffil.EndDate 
		LEFT JOIN ProductRate pr
		ON pr.ProductRateId = ISNULL(sol.ProductRateId ,(SELECT MIN(pr.ProductRateId )
													FROM Productrate pr
														LEFT JOIN DespatchDeliveryArea dda
														on dda.CountryID = s.PrimaryCountryId 
														AND dda.CompanyId = so.CompanyId 
													WHERE pr.ProductCode = so.primaryProductCode 
													AND pr.CurrencyCode = so.CurrencyCode 
													AND pr.AccountType  = ca.AccountType 
													AND pr.SubscriberCategory   = ISNULL(compAffil.SubscriberCategory,'Ordinary')
--1/8/20	James Woosnam	SIR5051 - Use all if no delivery area
													AND (pr.DeliveryArea = dda.DespatchDeliveryArea
																				OR (pr.DeliveryArea <> dda.DespatchDeliveryArea
																					AND pr.DeliveryArea = 'All')
														)
													)
													)
	WHERE so.OrderNumber = @OrderNumber
	AND s.SubscriberStatus IN ('Current','Proposed')
	AND (s.SubscriberName like '%' + @MainFilter + '%' OR @MainFilter='')
	AND (so.SalesOrderStatus like '%partial%' OR sol.SalesOrderLineID is not null) --only show ordered lines once confirmed
	ORDER BY so.OrderNumber
			, CASE WHEN sol.SubscriberId IS NULL THEN 0 ELSE 1 END DESC
			, s.SubscriberName
END
IF @ListType = 'Products'
BEGIN
	SELECT p.ProductCode 
		,ProductDescription = p.ProductCode + '-' + p.ProductName 
		,Included = CASE WHEN sol.OrderNumber IS NULL THEN 0 ELSE 1 END
		,ProductRateId = pr.ProductRateId 
		,Quantity=ISNULL(sol.Quantity ,null)
		,sol.AmountProduct 
		,HasAssociatedProduct = CASE WHEN assProd.ProductCode is NULL THEN 0 ELSE 1 END
		,IncludesAssociatedProduct = CASE WHEN (SELECT MAX(sol2.OrderNumber)  
											FROM SalesOrderLine sol2 
											WHERE sol2.ProductCode = assProd.ProductCode 
											AND sol2.OrderNumber = so.OrderNumber  
											) IS NULL THEN 0 ELSE 1 END
		,AssociatedProductAmount = (SELECT SUM(sol2.AmountProduct)  
											FROM SalesOrderLine sol2 
											WHERE sol2.SubscriberId = s.SubscriberId 
											AND sol2.ProductCode = assProd.ProductCode 
											AND sol2.OrderNumber = so.OrderNumber  
											)
		,sol.SalesOrderLineID
		,sol.IsCancel 
		,sol.CancelledDate 	
--19/8/21	James Woosnam	SIR5237 - Add Affiliate rate details
		,AffiliateRateSubscriberId = AffRrSub.SubscriberId 
		,AffiliateRateSubscriberName = AffRrSub.SubscriberName 
		,IsShipped = CAST(CASE WHEN p.ShippedProductFlag = 1 OR assProd.ShippedProductFlag=1 THEN 1 ELSE 0 END AS BIT)
	FROM Product p
		LEFT JOIN Product assProd
		On assProd.ProductCode = p.AssociatedProductCode 
		INNER JOIN SalesOrder so
		ON so.OrderNumber = @OrderNumber 
		AND so.CompanyId = p.CompanyID 
		INNER JOIN Subscriber s
		ON s.SubscriberId = so.SubscriberId 
		LEFT JOIN SalesOrderLine sol
			LEFT JOIN Subscriber AffRrSub
			On AffRrSub.SubscriberId = sol.AffiliateRateSubscriberId 
		ON sol.OrderNumber = so.OrderNumber 
		AND sol.ProductCode = p.ProductCode 
		INNER JOIN Company c
		ON c.CompanyId = so.CompanyId 
		INNER JOIN CompanyAccount ca
		ON ca.SubscriberId = so.SubscriberId 
		AND ca.CompanyId = so.CompanyId 
		LEFT JOIN SubscriberAffiliate compAffil
		ON compAffil.ChildSubscriberID = so.SubscriberId 
		AND compAffil.ParentSubscriberID = c.GroupParentSubscriberId 
		LEFT JOIN ProductRate pr
		ON pr.ProductRateId = ISNULL(sol.ProductRateId ,(SELECT MIN(pr.ProductRateId )
													FROM Productrate pr
														LEFT JOIN DespatchDeliveryArea dda
														on dda.CountryID = s.PrimaryCountryId 
														AND dda.CompanyId = so.CompanyId 
													WHERE pr.ProductCode = p.ProductCode 
													AND pr.CurrencyCode = so.CurrencyCode 
													AND pr.AccountType  = ca.AccountType 
													AND pr.SubscriberCategory   = ISNULL(compAffil.SubscriberCategory,'Ordinary')
													AND pr.DeliveryArea   = ISNULL(dda.DespatchDeliveryArea    ,'All')
													)
													)
	WHERE p.ProductStatus = 'Current'
	AND p.IsParent = 1
	AND p.ProductCode NOT IN (SELECT ap.AssociatedProductCode FROM Product ap WHERE ap.ProductStatus = 'Current'	AND ap.IsParent = 1 AND ISNULL(ap.AssociatedProductCode ,'') <> '' 
--7/11/21	James Woosnam	SIR5362 - Only hide associated products if the parent hasn't been purchased in this order
						AND ap.ProductCode in (SELECT sol2.productcode from SalesOrderLine sol2 where sol2.OrderNumber = so.OrderNumber) )
	AND (p.ProductCode + '-' + p.ProductName  like '%' + @MainFilter + '%' OR @MainFilter='')
	AND (so.SalesOrderStatus like '%partial%' OR sol.SalesOrderLineID is not null) --only show ordered lines once confirmed
	ORDER BY 
		CASE WHEN sol.OrderNumber IS NULL THEN 0 ELSE 1 END DESC
		,p.ProductName 
END
Go
GRANT EXECUTE ON sp148SalesOrderLists TO PaDSSQLServerUser

