if exists (select * from dbo.sysobjects where id = object_id(N'fn508ProductRateDependantsDesc') and xtype in (N'FN', N'IF', N'TF'))
drop function fn508ProductRateDependantsDesc
GO

CREATE FUNCTION fn508ProductRateDependantsDesc ( @ProductRateId INT)
RETURNS Varchar(MAX)
AS
BEGIN
DECLARE @Out VARCHAR(MAX) = ''
	,@OutQual VARCHAR(MAX)=''
	,@OutAffl VARCHAR(MAX)=''
	,@OutOrders VARCHAR(MAX)=''
	,@Desc VARCHAR(MAX)=''

DECLARE curQ CURSOR FOR
SELECT pDesc = q.QualifyingProductCode + '('
				+ CASE WHEN EXISTS(SELECT p.ProductCode FROM Product p WHERE p.ProductCode = q.QualifyingProductCode AND p.AssociatedProductCode = q.ProductCode ) THEN ' Is Associated, so will be shown for sale seperately if not bought with ' + q.QualifyingProductCode   ELSE '' END 
				+ CASE WHEN q.MustBuyFlag = 1 THEN ' MustBuy' ELSE '' END 
				+ CASE WHEN q.CheckAgainstOrderType IS NOT NULL THEN ' Check Against:' + q.CheckAgainstOrderType  ELSE '' END 
				+ CASE WHEN q.TerminatedSubscriptionsGracePeriodMonths IS NOT NULL THEN ' Grace Period:' + CONVERT(VARCHAR,q.TerminatedSubscriptionsGracePeriodMonths)  ELSE '' END 
				+ ')'
FROM ProductQualifyingProduct q
WHERE q.ProductRateId = @ProductRateId 
ORDER BY q.QualifyingProductCode 
Open curQ 
FETCH curQ INTO @Desc
WHILE @@FETCH_STATUS = 0 
BEGIN
	SET @OutQual +=  CASE WHEN @OutQual='' THEN '' ELSE ', ' END + @Desc
	FETCH curQ INTO @Desc
END
CLOSE curQ 
DEALLOCATE curQ 
IF @OutQual<> '' SET @Out += 'Qualifiers:' + @OutQual


DECLARE curA CURSOR FOR
SELECT pDesc = s.SubscriberName 
FROM ProductAffiliateRate  a
	inner join Subscriber s
	ON s.SubscriberId = a.GroupSubscriberId 
WHERE a.ProductRateId = @ProductRateId 
ORDER BY s.SubscriberName 
Open curA 
FETCH curA INTO @Desc
WHILE @@FETCH_STATUS = 0 
BEGIN
	SET @OutAffl +=  CASE WHEN @OutAffl='' THEN '' ELSE ', ' END + @Desc
	FETCH curA INTO @Desc
END
CLOSE curA 
DEALLOCATE curA 

IF @OutAffl<> '' SET @Out += ' Affiliates:' +  @OutAffl

DECLARE @OrderCount INT = 0
SELECT
	@OrderCount = COUNT(DISTINCT so.OrderNumber)
FROM SalesOrderLine sol
	INNER JOIN SalesOrder so
	ON so.OrderNumber = sol.OrderNumber 
	AND so.SalesOrderStatus IN ('Complete','Confirmed')
WHERE sol.ProductRateId = @ProductRateId 
AND sol.IsCancel = 0

IF @OrderCount <> 0 SET @Out +=  ' Used in ' + FORMAT(@OrderCount,'#,##0') + ' Complete/Confirmed orders'

RETURN ( @Out)

END
go
GRant EXECUTE ON fn508ProductRateDependantsDesc to PaDSSQLServerUser

/*
select 
*
FROM (
select
	pr.ProductCode 
	,pr.ProductRateId 
	,dd=dbo.fn508ProductRateDependantsDesc(pr.ProductRateId )
from ProductRate pr) pr
--where dd <> ''
where pr.ProductCode = 'pepwebs'
 */