if exists (select * from dbo.sysobjects where id = object_id(N'sp102GetSubscriberDespatchInfo') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp102GetSubscriberDespatchInfo
GO
CREATE PROCEDURE sp102GetSubscriberDespatchInfo ( 
		@SubscriberId INT = NULL
		)

AS
SELECT so.OrderDate 
	,so.OrderNumber
	,ParentProductCode = pP.ProductCode 
	,ParentProductName = pP.ProductName 
	,ChildProductCode = pc.ProductCode 
	,ChildProductName = pC.ProductName 
	,ChildReleaseDate = pC.ReleaseDate
	,DueBy = DATEADD(MONTH,3,pC.ReleaseDate)
	,solp.DateDespatched 
	,solp.AddressText 
	,sol.SalesOrderLineId
FROM SalesOrderLine sol
	INNER JOIN SalesOrder so
	ON so.OrderNumber = sol.OrderNumber 
	And (so.SalesOrderStatus IN ('Confirmed','Complete')
			OR (so.SalesOrderStatus = 'RemotePartial' 
				AND so.AmountGross <= (SELECT SUM(Amount) 
							FROM Cashbook
							WHERE OrderNumber =  so.OrderNumber
							AND CashbookStatus = 'Confirmed')))
	AND ISNULL(so.IsOrderSuspended,0)<> 1

	INNER JOIN Product pP
		INNER JOIN Product pC
		ON pC.ParentProductCode = pP.ProductCode 
	ON pP.ProductCode = sol.ProductCode
	LEFT JOIN SalesOrderLinePart solp
	ON solp.SalesOrderLineID = sol.SalesOrderLineID 
	AND solp.ProductCode = pC.ProductCode 
WHERE 1=1
AND sol.SubscriberId = @SubscriberId 
AND pP.ShippedProductFlag = 1
AND pP.ProductCode = pC.ParentProductCode 
and pP.ProductCode IN (SELECT TOP 20 
							pC2.ParentProductCode 
						FROM Product pC2
							INNER JOIN Product pP2
							ON pP2.ProductCode = pC2.ParentProductCode 
						WHERE pC2.ParentProductCode IS NOT NULL
						AND pP2.ProductStatus = 'Current'
						AND pC2.ParentProductCode = sol.ProductCode 
						GROUP BY pC2.ParentProductCode 
						HAVING COUNT(*) > 1
						ORDER BY MAX(pP2.ReleaseDate) desc
						)
ORDER BY
	so.OrderNumber 
	,pP.ReleaseDate 
	,pP.ProductName
	,pC.ReleaseDate 
	,pC.ProductName
	
GO
GRant EXECUTE ON sp102GetSubscriberDespatchInfo to PaDSSQLServerUser


