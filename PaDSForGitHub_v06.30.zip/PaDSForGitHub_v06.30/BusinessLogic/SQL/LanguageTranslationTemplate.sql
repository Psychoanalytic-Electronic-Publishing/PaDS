﻿DECLARE @Message VARCHAR(MAX)=''
	,@RowCount VARCHAR
	,@BatchLogId INT
	,@SQL VARCHAR(MAX) =''
exec sp028InsertBatchLog @BatchLogType ='PopLanguageTranslation',@Description='',@BatchJobId=NULL, @BatchLogId=@BatchLogId OUTPUT
SET @sql = 'select * INTO  [PaDSTempAndArchive]..LanguageTranslationBeforeUpdate' + FORMAT(GETDATE(),'yyyy_MM_dd_HHmmss') + ' from LanguageTranslation '
EXEC(@sql)
	SET @RowCount = @@ROWCOUNT ;SET @Message = @RowCount + ' LanguageTranslation rows copied to [PaDSTempAndArchive]..LanguageTranslationBeforeUpdateyyyy_MM_dd_HHmmss';PRINT @Message;exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Message

BEGIN TRAN
BEGIN TRY

	SELECT * INTO #LT FROM LanguageTranslation WHERE 1=2

	SET IDENTITY_INSERT #LT on
--Insert Lines Go Here
	SET IDENTITY_INSERT #LT off
	SET @Message = CONVERT(VARCHAR,(SELECT COUNT(*) FROM LanguageTranslation)) + ' LanguageTranslation rows inserted into #LT';PRINT @Message;exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Message

	DECLARE @FirstTranslation VARCHAR(50) = ''
	SET @FirstTranslation =(SELECT MIN(CAST(l.TranslationNo as VARCHAR) + '-' + l.LanguageName + '-' + l.LanguageText )
	FROM LanguageTranslation l
		INNER JOIN #LT n
		on n.LanguageTranslationId = l.LanguageTranslationId
	where l.LanguageText <> n.LanguageText
	AND n.LastUpdatedDateTime < ISNULL(l.LastUpdatedDateTime,CAST('21-jun-2022' as DATETIME)) )
	IF @FirstTranslation <> ''
	BEGIN
		SET @Message = 'It looks like you are trying to overwrite a newer translation, first one is:' + @FirstTranslation 
		RAISERROR (@Message, 16, 1)
		RETURN
	END
	DELETE FROM LanguageTranslation
	WHERE LanguageTranslationId NOT IN (SELECT LanguageTranslationId FROM #LT)
	SET @RowCount = @@ROWCOUNT ;SET @Message = @RowCount + ' LanguageTranslation rows Deleted';PRINT @Message;exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Message

	UPDATE LanguageTranslation
	SET LanguageText = n.LanguageText
		,LastUpdatedByUserId = n.LastUpdatedDateTime 
		,LastUpdatedDateTime = n.LastUpdatedDateTime 
	FROM LanguageTranslation l
		INNER JOIN #LT n
		on n.LanguageTranslationId = l.LanguageTranslationId
	where l.LanguageText <> n.LanguageText
	AND n.LastUpdatedDateTime >= ISNULL(l.LastUpdatedDateTime,CAST('21-jun-2022' as DATETIME)) 
	SET @RowCount = @@ROWCOUNT ;SET @Message = @RowCount + ' LanguageTranslation rows Updated';PRINT @Message;exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Message

	set IDENTITY_INSERT LanguageTranslation ON
	INSERT INTO LanguageTranslation 
	(LanguageTranslationId,TranslationNo,PageNumber,LanguageName,LanguageText,LastUpdatedDateTime,LastUpdatedByUserId)
	SELECT n.*
	FROM #LT n
		LEFT JOIN LanguageTranslation l
		on n.LanguageTranslationId = l.LanguageTranslationId
	WHERE l.LanguageTranslationId IS NULL
	SET @RowCount = @@ROWCOUNT ;SET @Message = @RowCount + ' LanguageTranslation rows Inserted';PRINT @Message;exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Message
	set IDENTITY_INSERT LanguageTranslation off

	DROP TABLE #LT
	commit TRAN
	exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage='Complete',@BatchLogStatus='Complete'
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SET @Message = 'LanguageTranslationPopulation Failed - ' + ERROR_MESSAGE()
	exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Message,@BatchLogStatus='Failed'
	RAISERROR (@Message, 16, 1)
END CATCH