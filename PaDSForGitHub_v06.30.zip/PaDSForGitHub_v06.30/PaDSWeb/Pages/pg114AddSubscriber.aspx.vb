﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.Subscriber
'Modification History
'07/04/20   Julian Gates   Initial New version
'17/02/21   Julian Gates    SIR5166 - Removed old asp page links

Partial Class Pages_pg114AddSubscriber
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    ReadOnly Property HasRemoteUserRights As Boolean
        Get
            If uPage.db.DLookup("Count(*)", "RemoteUserRights", "RightsType = 'Subscriber' AND UserId=" & uPage.UserSession.UserId) > 1 Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Add Subscriber ", "")
        Try
            If Page.IsPostBack Then

            Else
                If Me.uPage.IsValid Then
                    ReadRecord()
                End If
                Me.EntityType.SelectedValue = "Person"
                Me.FirstName.Focus()
            End If
        Catch ex As Exception
            uPage.PageError = "An unexpected error has occured.  Please contact support." & ex.ToString
        End Try

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

    End Sub

    Sub PageSetup()
        uPage.pageTitle = "Add New Subscriber"
        Me.pageHeaderTitle.Text = uPage.pageTitle

        Select Case Me.EntityType.SelectedValue
            Case "Person"
                Me.OrganisationRow.Visible = False
                Me.FirstNameRow.Visible = True
                Me.LastNameRow.Visible = True
                Me.FirstName.Focus()
            Case "Organisation"
                Me.OrganisationRow.Visible = True
                Me.FirstNameRow.Visible = False
                Me.LastNameRow.Visible = False
                Me.SubscriberName.Focus()
        End Select

        Me.PrimaryAffiliationSubscriberIdRow.Visible = HasRemoteUserRights
    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else
                Select Case Me.EntityType.SelectedValue
                    Case "Person"
                        Me.uPage.FieldValidateMandatory(Me.FirstName)
                        Me.uPage.FieldValidateMandatory(Me.LastName)
                    Case "Organisation"
                        If Me.SubscriberName.Text = Nothing Then
                            Me.uPage.PageError = "Organisation is mandatory"
                        End If
                End Select
                Me.uPage.DropDownValidateMandatory(Me.SubscriberCategory)
                Me.uPage.DropDownValidateMandatory(Me.CountryId)
                If HasRemoteUserRights Then
                    Me.uPage.DropDownValidateMandatory(Me.PrimaryAffiliationSubscriberId)
                End If
        End Select

        Return Me.uPage.IsValid
    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        'populate dropdowns
        Me.uPage.PopulateRadioButtonListFromLookup(Me.EntityType, "EntityType")

        Dim Sql = "SELECT Country.CountryId as Value" _
                            & "     ,Country.CountryName As Text" _
                            & " FROM Country" _
                            & " ORDER BY Country.CountryName"
        Me.uPage.PopulateDropDownListFromSQL(Me.CountryId, Sql, uPage.db.DBConnection, "<--Select-->")

        Sql = "SELECT LookupItemKey As Value" _
                            & ", Name As Text" _
                            & " FROM Lookup" _
                            & " WHERE LookupName = 'SubscriberCategory'" _
                            & " AND Lookup.LookupStatus = 'Active'" _
                            & " AND CompanyId = " & uPage.db.DLookup("RightsToId", "RemoteUserRights", "RightsType = 'Company' AND UserId=" & uPage.UserSession.UserId) _
                            & " ORDER BY DisplayOrder,Name,LookupItemKey"
        Me.uPage.PopulateDropDownListFromSQL(Me.SubscriberCategory, Sql, uPage.db.DBConnection, "<--Select-->")

        If HasRemoteUserRights Then
            Sql = "SELECT SubscriberId as Value" _
                     & ",SubscriberName As Text" _
                     & " FROM Subscriber" _
                     & "    INNER JOIN RemoteUserRights" _
                     & "	ON RemoteUserRights.RightsToId = Subscriber.SubscriberId" _
                     & "	AND RemoteUserRights.RightsType = 'Subscriber'" _
                     & " WHERE RemoteUserRights.UserId =" & uPage.UserSession.UserId _
                     & " ORDER BY SubscriberName"
            Me.uPage.PopulateDropDownListFromSQL(Me.PrimaryAffiliationSubscriberId, Sql, uPage.db.DBConnection, "<--Select-->")
        Else
            Me.txtPrimaryAffiliationSubscriberId.Value = uPage.db.DLookup("RightsToId", "RemoteUserRights", "RightsType = 'Subscriber' AND UserId=" & uPage.UserSession.UserId)
        End If

    End Sub

    Sub SaveRecord()
        If Me.IsPageValidForStatus("") Then
            Dim Subscriber As New BusinessLogic.Subscriber(Me.uPage.db, Me.uPage.UserSession)
            Try
                uPage.db.BeginTran()
                Try
                    Dim primaryAffiliationSubscriberId As String = Nothing
                    If HasRemoteUserRights Then
                        primaryAffiliationSubscriberId = Me.PrimaryAffiliationSubscriberId.SelectedValue
                    Else
                        primaryAffiliationSubscriberId = txtPrimaryAffiliationSubscriberId.Value
                    End If
                    Subscriber.AdminAdd(Me.EntityType.Text _
                                                  , Me.FirstName.Text _
                                                  , Me.LastName.Text _
                                                  , Me.SubscriberName.Text _
                                                  , Me.CountryId.SelectedValue _
                                                  , Me.SubscriberCategory.SelectedValue _
                                                  , primaryAffiliationSubscriberId)

                    uPage.db.CommitTran()
                Catch ex As Exception
                    uPage.db.RollbackTran()
                    Throw ex
                End Try

            Catch ex As Exception
                Me.uPage.PageError = "An unexpected error has occured. Please contact support." & ex.ToString
            End Try

            If Me.uPage.IsValid Then
                Response.Redirect("../pages/pg113SubscriberMaint.aspx?InfoMsg=Subcriber details has been saved&SubscriberId=" & Subscriber.SubscriberId)
            End If
        End If
    End Sub

    Protected Sub SaveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        Try
            If Me.IsPageValidForStatus("") Then SaveRecord()
        Catch ex As Exception
            Me.uPage.PageError = "An unexpected error has occured. Please contact support." & ex.ToString
        End Try
    End Sub

    Protected Sub BackBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        Response.Redirect("../pages/pg110SubscriberSelect.aspx")
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        Me.uPage.PagePreRender()

    End Sub
End Class
