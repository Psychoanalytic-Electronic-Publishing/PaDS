﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web
Imports BusinessLogic
'Modification History
'30/08/2022    Julian Gates   Initial Version

Partial Class Pages_pg290EmailDistributionSelect
    Inherits System.Web.UI.Page
    Dim EmailDistribution As EmailDistribution = Nothing
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Bulk Emails List", "")
        Me.pageHeaderTitle.Text = "Bulk Emails List"

        If Page.IsPostBack Then

        Else
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        GridSetup()

    End Sub

    Sub PageSetup()

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub GridSetup()
        Try
            Dim Sql As String = ""
            Sql = "SELECT ed.EmailDistributionId"
            Sql += " ,ed.EmailName"
            Sql += " ,ed.EmailDistributionStatus"
            Sql += " ,ed.EmailSubject"
            Sql += " ,c.CompanyName"
            Sql += " ,ed.SubscriberSourceType"
            Sql += " ,filters= CASE WHEN ed.SubscribedToProductCodes is null then '' else '; Products:' + ed.SubscribedToProductCodes END"
            Sql += " + CASE WHEN ed.SubscriberCategoryFilter is null then '' else '; SubCategory:' + ed.SubscriberCategoryFilter END"
            Sql += " + CASE WHEN ed.CountryIdFilter is null then '' else '; SubCountry:' + cy.CountryName  END"
            Sql += " FROM EmailDistribution ed"
            Sql += "    INNER JOIN " & uPage.CompanyTable("c", uPage.UserSession.UserId)
            Sql += "    ON c.CompanyId = ed.CompanyId"
            Sql += "   LEFT JOIN country cy"
            Sql += "   ON cy.CountryID = CountryIdFilter"
            Sql += " WHERE 1=1"
            Sql += " ORDER BY EmailDistributionId Desc, EmailName, EmailDistributionStatus"
            Me.EmailDistributionDatasource.SelectCommand = Sql

            'Populate dropdown fields
            CType(Me.EmailDistributionGridView.Columns("EmailDistributionStatus"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL("SELECT Lookup.LookupItemKey" _
                                                                                                                                                            & "    , Lookup.Name" _
                                                                                                                                                            & " FROM Lookup" _
                                                                                                                                                            & " WHERE LookupName = 'EmailDistributStatus'" _
                                                                                                                                                            & " AND LookupStatus = 'Active'" _
                                                                                                                                                            & " ORDER BY DisplayOrder,Name,LookupItemKey"
                                                                                                                                                           )
            'show filter row menu
            Me.EmailDistributionGridView.Settings.ShowFilterRowMenu = True

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Protected Sub AddNewBtn_Click(sender As Object, e As EventArgs) Handles AddNewBtn.Click
        Response.Redirect("../Pages/pg291EmailDistributionMaint.aspx?PageMode=Add")
    End Sub
End Class
