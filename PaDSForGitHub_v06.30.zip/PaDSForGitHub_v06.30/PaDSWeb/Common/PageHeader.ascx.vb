'Modification History
'04/02/2016   Julian Gates   SIR4070 - Add Update User link for CompanyAdmin users
'01/03/22     Julian Gates   SIR5443 - Add Smart Search functionality

Partial Class PageHeader
    Inherits System.Web.UI.UserControl
    Dim pg As Object
    Dim uPage As UserPage
    Public pageTitle, pageErrorMessage, pageInfoMessage, userName As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        pg = Me.Parent.NamingContainer.Page
        uPage = pg.uPage
        pageTitle = pg.uPage.pageTitle


        BuildHeader()
        Me.lblMenuBar.Text = uPage.OutputMenu(uPage.UserSession.LoggedIn)
    End Sub

    Sub BuildHeader()
        Dim tRow As New WebControls.TableRow
        Dim cell As New WebControls.TableCell
        'Show read only message if On secondary server
        If uPage.UserSession.Data("IsReadOnlyOnSecondary") Then
            cell.Text = "<span class=''hmTitle1''>(Read Only)</span>"
            tRow.Cells.Add(cell)
        End If
        cell = New TableCell()
        cell.Text = "<span class=''hmTitle1''>PaDS</span>"
        cell.HorizontalAlign = HorizontalAlign.Center
        cell.Width = 200
        tRow.Cells.Add(cell)
        cell = New TableCell()
        Dim tb As New TextBox
        tb.Width = "250"
        tb.ID = "QuickLink"
        tb.CssClass = "fldEntry"
        cell.HorizontalAlign = HorizontalAlign.Right
        cell.Controls.Add(tb)
        Dim bt As New Button
        bt.Text = "Search"
        bt.ID = "SmartSearchBtn"
        AddHandler bt.Command, AddressOf SmartSearch
        cell.Controls.Add(bt)
        cell.HorizontalAlign = HorizontalAlign.Right
        tRow.Cells.Add(cell)
        cell = New TableCell()
        cell.Text = "<span class=""fldView"">User: " & uPage.UserSession.UserName & " <a href='../Pages/pg070Logon.aspx?Action=Logout'>Logout</a></span>"
        cell.HorizontalAlign = HorizontalAlign.Right
        tRow.Cells.Add(cell)
        '04/02/2016     Julian Gates    SIR4070 - Add Update User link for CompanyAdmin users
        Select Case Me.uPage.UserSession.AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins
                cell = New TableCell()
                cell.Text = "<span class=""fldView""><a href ='../Pages/pg061UserMaint.aspx?PageMode=Update&UserId=" & uPage.UserSession.UserId & "' title=""Update your password"">Update</a></span>"
                cell.HorizontalAlign = HorizontalAlign.Center
                tRow.Cells.Add(cell)
        End Select
        Me.HeaderTbl.Rows.Add(tRow)
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        pageErrorMessage = uPage.PageError
        pageInfoMessage = uPage.InfoMessage
        Me.uPage.UserSession.SessionCookie.Save(Me.Response)
    End Sub

    Sub SmartSearch(sender As Object, e As System.Web.UI.WebControls.CommandEventArgs)
        '28/2/22    James Woosnam   SIR5443 - Add SmartSearch
        Dim tb As TextBox = Me.HeaderTbl.FindControl("Quicklink")
        uPage.FieldValidateMandatory(tb)
        If uPage.IsValid Then
            uPage.SmartSearch(tb.Text)
        End If
    End Sub
End Class
