﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls

'Modification History
'22/6/12    Julian Gates  Trap error in PopulateDropDownListFromSQL put out message if value is invalid
'28/02/22   Julian Gates    SIR5391 - Add Sub FieldValidateFirstLastNameInput

Public Class WebForm

    'Public CurrentUserInternalContact As BusinessLogic.CurrentUserInternalContact
    Private _ShowFullError As Boolean = False
    Public Property ShowFullError() As Boolean
        Get
            Try
                Me._ShowFullError = Boolean.Parse(Me.db.GetParameterValue("ShowFullError"))
            Catch generatedExceptionName As Exception
                Me._ShowFullError = False
            End Try
            Return Me._ShowFullError
        End Get
        Set(ByVal value As Boolean)
            Me._ShowFullError = value
        End Set
    End Property
    Public AdditionalInfoForlog As String = ""

    Public IsValid As Boolean = True
    '    Public UserName As String = ""
    Private MainContent As ContentPlaceHolder
    Private CurrentPage As System.Web.UI.Page
    Private UserSession As BusinessLogic.UserSession
    Public db As BusinessLogic.Database

    Private _FocusControl As System.Web.UI.Control
    Public Property FocusControl() As System.Web.UI.Control
        Get
            Return Me._FocusControl
        End Get
        Set(ByVal value As System.Web.UI.Control)
            Me._FocusControl = value
        End Set
    End Property

    Public ReadOnly Property DatabaseName() As String
        Get
            Try
                Return Me.db.DBConnection.Database
            Catch ex As Exception
                Return "**Not Found**"
            End Try
        End Get
    End Property

    Public Sub New(ByVal MainContent As ContentPlaceHolder)
        Me.MainContent = MainContent
    End Sub
    Public Sub New(ByVal CurrentPage As System.Web.UI.Page)
        Me.CurrentPage = CurrentPage
    End Sub

    Public Sub New(ByVal MainContent As ContentPlaceHolder, ByVal db As BusinessLogic.Database, ByVal CurrentPage As System.Web.UI.Page, UserSession As BusinessLogic.UserSession)
        Me.MainContent = MainContent
        Me.db = db
        Me.CurrentPage = CurrentPage
        Me.UserSession = UserSession
    End Sub


    Public Sub PopulatePageFieldsFromDataRow(ByVal dRow As DataRow)
        Dim myColumn As DataColumn
        Dim theControl As Control
        For Each myColumn In dRow.Table.Columns
            theControl = MainContent.FindControl(myColumn.ColumnName)
            If Not (theControl Is Nothing) Then
                Try
                    Dim myControl As WebControls.TextBox = theControl
                    If dRow.Item(myColumn.ColumnName) Is System.DBNull.Value Then
                        myControl.Text = ""
                    Else
                        myControl.Text = dRow.Item(myColumn.ColumnName)
                    End If
                Catch ex1 As Exception
                    Try
                        Dim myControl As WebControls.CheckBox = theControl
                        myControl.Checked = dRow.Item(myColumn.ColumnName)

                    Catch ex2 As Exception
                        Try
                            Dim myControl As WebControls.DropDownList = theControl
                            '   myControl.Items.FindByText(dRow.Item(myColumn.ColumnName)).Selected = True
                            myControl.SelectedValue = dRow.Item(myColumn.ColumnName)
                        Catch ex3 As Exception
                            Try
                                Dim myControl As HtmlControls.HtmlInputHidden = theControl
                                If dRow.Item(myColumn.ColumnName) Is System.DBNull.Value Then
                                    myControl.Value = ""
                                Else
                                    myControl.Value = dRow.Item(myColumn.ColumnName)
                                End If
                            Catch ex4 As Exception
                                Try
                                    Dim myControl As WebControls.Label = theControl
                                    If dRow.Item(myColumn.ColumnName) Is System.DBNull.Value Then
                                        myControl.Text = ""
                                    Else
                                        myControl.Text = dRow.Item(myColumn.ColumnName)
                                    End If
                                Catch ex5 As Exception
                                    Try
                                        Dim myControl As WebControls.HyperLink = theControl
                                        If dRow.Item(myColumn.ColumnName) Is System.DBNull.Value Then
                                            myControl.Text = ""
                                        Else
                                            myControl.Text = dRow.Item(myColumn.ColumnName)
                                        End If
                                    Catch ex6 As Exception
                                    End Try
                                End Try
                            End Try
                        End Try
                    End Try
                End Try
            End If
        Next
    End Sub

    Public Sub PopulateDataRowFromPageFields(ByVal dRow As DataRow)
        Dim myColumn As DataColumn
        Dim theControl As Control
        For Each myColumn In dRow.Table.Columns
            theControl = MainContent.FindControl(myColumn.ColumnName)
            If Not (theControl Is Nothing) Then
                Try
                    Dim myControl As WebControls.TextBox = theControl
                    If myControl.Text = "" Then
                        If Not db.IsDBNull(dRow.Item(myColumn.ColumnName)) Then
                            dRow.Item(myColumn.ColumnName) = System.DBNull.Value
                        End If
                    Else
                        If myControl.Text <> db.IsDBNull(dRow.Item(myColumn.ColumnName), "") Then
                            dRow.Item(myColumn.ColumnName) = myControl.Text
                        End If
                    End If
                Catch ex1 As Exception
                    Try
                        Dim myControl As WebControls.CheckBox = theControl
                        If dRow.Item(myColumn.ColumnName) <> myControl.Checked Then
                            dRow.Item(myColumn.ColumnName) = myControl.Checked

                        End If
                    Catch ex2 As Exception
                        Try
                            Dim myControl As WebControls.DropDownList = theControl
                            If myControl.SelectedValue = "" Then
                                If Not db.IsDBNull(dRow.Item(myColumn.ColumnName)) Then
                                    dRow.Item(myColumn.ColumnName) = System.DBNull.Value
                                End If
                            Else
                                If myControl.SelectedValue <> db.IsDBNull(dRow.Item(myColumn.ColumnName), "") Then
                                    dRow.Item(myColumn.ColumnName) = myControl.SelectedValue
                                End If
                            End If
                        Catch ex3 As Exception
                            Try
                                Dim myControl As HtmlControls.HtmlInputHidden = theControl
                                If myControl.Value = "" Then
                                    If Not db.IsDBNull(dRow.Item(myColumn.ColumnName)) Then
                                        dRow.Item(myColumn.ColumnName) = System.DBNull.Value
                                    End If
                                Else
                                    If myControl.Value <> db.IsDBNull(dRow.Item(myColumn.ColumnName), "") Then
                                        dRow.Item(myColumn.ColumnName) = myControl.Value
                                    End If
                                End If
                            Catch ex4 As Exception
                                Try
                                    Dim myControl As WebControls.Label = theControl
                                    If myControl.Text = "" Then
                                        If Not db.IsDBNull(dRow.Item(myColumn.ColumnName)) Then
                                            dRow.Item(myColumn.ColumnName) = System.DBNull.Value
                                        End If
                                    Else
                                        If myControl.Text <> db.IsDBNull(dRow.Item(myColumn.ColumnName), "") Then
                                            dRow.Item(myColumn.ColumnName) = myControl.Text
                                        End If
                                    End If
                                Catch ex5 As Exception
                                End Try
                            End Try
                        End Try
                    End Try

                End Try
            End If
        Next
    End Sub

    Public Sub PopulateDropDownListFromLookup(ByVal theDropdown As DropDownList, ByVal lookupName As String)
        PopulateDropDownListFromLookup(theDropdown, lookupName, String.Empty)
    End Sub

    Public Sub PopulateDropDownListFromLookup(ByVal theDropdown As DropDownList, ByVal lookupName As String, ByVal initialValue As String)
        'Populates a asp Dropdown list from the lookup table using the PopulateDropDownListFromSql 
        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria
        Dim commandText As String = ("SELECT LookupItemKey Value" & " ,Name Text" & " FROM Lookup" & " WHERE Lookup.LookUpName = '") + lookupName & "'" & " AND Lookup.LookupStatus = 'Active' ORDER BY DisplayOrder, Name,LookupItemKey"
        PopulateDropDownListFromSQL(theDropdown, commandText, initialValue)
    End Sub

    Public Sub PopulateDropDownListFromSQL(ByVal theDropdown As DropDownList, ByVal SQL As String)
        PopulateDropDownListFromSQL(theDropdown, SQL, String.Empty)
    End Sub

    Public Sub PopulateDropDownListFromSQL(ByVal theDropdown As DropDownList, ByVal SQL As String, ByVal initialValue As String)
        PopulateDropDownListFromSQL(theDropdown, SQL, initialValue, Me.db.DBConnection, Me.db.DBTransaction)
    End Sub
    Public Sub PopulateDropDownListFromSQL(ByVal theDropdown As DropDownList, ByVal SQL As String, ByVal initialValue As String, ByVal dbConnection As SqlConnection, ByVal dbTransaction As SqlTransaction)
        'Populates a asp Dropdown list using SQL query 

        Dim commandText As String = SQL
        Dim tbl As DataTable = db.GetDataTableFromSQL(SQL)

        tbl.Columns.Add(New DataColumn("OrderBy"))
        If (initialValue IsNot Nothing) Then
            Dim blankRowFound As Boolean = False
            Dim rowNo As Integer = 1
            For Each row In tbl.Rows
                If CStr(row("Value")) = "" Then
                    blankRowFound = True
                End If
                row("OrderBy") = rowNo.ToString("00000")
                rowNo += 1
            Next

            If Not blankRowFound Then
                Dim row As DataRow = tbl.NewRow
                Select Case tbl.Columns("Value").DataType.Name
                    Case "Int32"
                        row("Value") = 0
                    Case Else
                        row("Value") = ""
                End Select
                row("Text") = initialValue
                row("OrderBy") = CInt(0).ToString("00000")

                tbl.Rows.Add(row)
            End If
        End If
        Dim vw As New DataView(tbl, "", "OrderBy", DataViewRowState.CurrentRows)
        '    Dim dr As SqlDataReader = New SqlCommand(commandText, dbConnection).ExecuteReader()
        Try
            theDropdown.DataSource = vw
            theDropdown.DataValueField = "Value"
            theDropdown.DataTextField = "Text"
            theDropdown.DataBind()
            '            If (initialValue IsNot Nothing) Then
            'theDropdown.Items.Insert(0, New System.Web.UI.WebControls.ListItem(initialValue, String.Empty))
            'E'nd If
        Catch ex As Exception
            '22/6/12    Julian Gates  Trap error put out message if value is invalid
            If ex.Message.Contains("has a SelectedValue which is invalid because ") Then
                Me.AddPageError("'" & theDropdown.ID & "' has a value that is no longer valid and has been cleared.")
                Try
                    theDropdown.SelectedIndex = 0
                Catch ex1 As Exception
                End Try
            Else
                Throw New Exception(("Drop down list not built for " & theDropdown.ID & ". - ") + ex.Message, New Exception(("SQL:" & commandText) + ex.ToString()))
            End If

        Finally
            '      dr.Close()
        End Try


    End Sub

    Public Sub PopulateListBoxFromLookup(ByRef theListBox As ListBox, ByVal lookupName As String, Optional ByVal initialValue As String = Nothing)
        'Populates a asp list box from the lookup table using the PopulateListBoxFromSql 
        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria
        Dim commandText As String = ("SELECT LookupItemKey Value" & " ,Name Text" & " FROM Lookup" & " WHERE Lookup.LookUpName = '") + lookupName & "'" & " AND Lookup.LookupStatus = 'Active' ORDER BY DisplayOrder,Name,LookupItemKey"


        PopulateListBoxFromSql(theListBox, commandText, initialValue)
    End Sub


    Public Sub PopulateListBoxFromSql(ByRef theListBox As ListBox, ByVal SQL As String, ByVal initialValue As String)
        'Populates a asp list box using SQL query 

        Dim commandText As String = SQL

        Dim dr As SqlDataReader = New SqlCommand(commandText, Me.db.DBConnection, Me.db.DBTransaction).ExecuteReader()
        Try
            theListBox.DataSource = dr
            theListBox.DataValueField = "Value"
            theListBox.DataTextField = "Text"
            theListBox.DataBind()
            If (initialValue IsNot Nothing) Then
                theListBox.Items.Insert(0, New System.Web.UI.WebControls.ListItem(initialValue, String.Empty))
            End If
        Catch ex As Exception
            Throw New Exception(("List box not built for " & theListBox.ID & ". - ") + ex.Message, New Exception(("SQL:" & commandText) + ex.ToString()))
        Finally
            dr.Close()
        End Try
    End Sub

    Public Sub PopulateRadioButtonListFromLookup(ByRef theRadioButtonList As RadioButtonList, ByVal lookupName As String)
        'Populates a asp list box from the lookup table using the PopulateListBoxFromSql 
        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria
        Dim commandText As String = ("SELECT LookupItemKey Value" & " ,Name Text" & " FROM Lookup" & " WHERE Lookup.LookUpName = '") + lookupName & "'" & " AND Lookup.LookupStatus = 'Active' ORDER BY DisplayOrder,Name,LookupItemKey"


        PopulateRadioButtonListFromSql(theRadioButtonList, commandText)
    End Sub


    Public Sub PopulateRadioButtonListFromSql(ByRef theRadioButtonList As RadioButtonList, ByVal SQL As String)
        'Populates a asp list box using SQL query 

        Dim commandText As String = SQL

        Dim dr As SqlDataReader = New SqlCommand(commandText, Me.db.DBConnection, Me.db.DBTransaction).ExecuteReader()
        Try
            theRadioButtonList.DataSource = dr
            theRadioButtonList.DataValueField = "Value"
            theRadioButtonList.DataTextField = "Text"
            theRadioButtonList.DataBind()
        Catch ex As Exception
            Throw New Exception(("Radio Button List not built for " & theRadioButtonList.ID & ". - ") + ex.Message, New Exception(("SQL:" & commandText) + ex.ToString()))
        Finally
            dr.Close()
        End Try
    End Sub


    Public Function GetListDatatable(ByVal PageNumber As Integer _
                                    , ByRef RecordsPerPage As TextBox _
                                    , ByRef PageNumberPlace As PlaceHolder _
                                    , ByVal cmd As SqlCommand _
                                    , ByVal ShowLastPageNumber As Boolean
                                    ) As DataTable
        Dim i As Integer = 0
        Dim totalPageCount As Integer = 0
        Dim lclPageNumber As Integer = 0
        Dim lclRecordsPerPage As Integer = 0
        Dim totalRecordCount As Integer = 0
        'Dim ExportSQL As [String] = SQL
        Dim listTable As New DataTable("List")
        'Default page number and records per page if invalid 
        Try
            lclPageNumber = PageNumber
        Catch generatedExceptionName As Exception
            lclPageNumber = 1
        End Try
        Me.FieldValidateNumber(RecordsPerPage, True, "Records per Page")
        Try
            lclRecordsPerPage = Integer.Parse(RecordsPerPage.Text)
        Catch e As Exception
            lclRecordsPerPage = 5
        End Try
        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RecordsRequired", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                      , (Integer.Parse(RecordsPerPage.Text) * PageNumber) + 2))

        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReturnTotalRecordCount", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                      , 1))

        Dim listReader As SqlDataReader = Nothing
        Try
            listReader = cmd.ExecuteReader()
        Catch ex As Exception
            Throw New Exception("Open List SQL failed.", ex)
        End Try
        Try
            Dim schema As DataTable = listReader.GetSchemaTable()

            'Use the datareader schema to create columns in the datatable 
            For Each row As DataRow In schema.Rows
                listTable.Columns.Add(DirectCast(row("ColumnName"), String), DirectCast(row("datatype"), System.Type))
            Next


            'loop through the dataread until we have got to the begining of the required page 
            For i = 1 To ((lclPageNumber - 1) * lclRecordsPerPage)
                If Not listReader.Read() Then
                    Return listTable
                Else
                End If
            Next
            Dim RecordCount As Integer = 0
            If listReader.Read() Then
                totalRecordCount = CInt(listReader("TotalRecordCount"))
                RecordCount = 1
                'Read through a page worth of data populating the lsit table 
                Do
                    totalRecordCount = CInt(listReader("TotalRecordCount"))
                    Dim newRow As DataRow = listTable.NewRow()
                    For Each columnRow As DataRow In schema.Rows

                        newRow(DirectCast(columnRow("ColumnName"), String)) = listReader(DirectCast(columnRow("ColumnName"), String))
                    Next
                    listTable.Rows.Add(newRow)
                    RecordCount += 1
                Loop While Not (RecordCount > (lclPageNumber * lclRecordsPerPage) Or Not listReader.Read())
                If Not ShowLastPageNumber Then
                    'This query is too complex to count so just add a page two 
                    totalPageCount = lclPageNumber
                Else
                    totalPageCount = totalRecordCount / lclRecordsPerPage
                    If CDbl(totalRecordCount) / lclRecordsPerPage > totalPageCount Then
                        totalPageCount = totalPageCount + 1
                    End If
                End If
            Else
                totalPageCount = 1
            End If


            'Add Page numbering from 1 to the page number plus 2 

            For i = 1 To lclPageNumber + 2
                If i <= totalPageCount And i > 0 Then
                    If i = lclPageNumber + 2 Then
                        i = totalPageCount
                        Dim lb As New Label()
                        lb.Text = ".."
                        PageNumberPlace.Controls.Add(lb)
                    End If

                    If i = 1 Or Not (i < lclPageNumber - 1) Then
                        Dim hLink As New HyperLink()
                        hLink.NavigateUrl = "javascript:" & "GotoPage(" & i & ")"

                        Dim lb As New Label()
                        lb = New Label()
                        lb.Text = i.ToString()
                        If i = lclPageNumber Then
                            hLink.CssClass = "pageNumCurrent"
                        Else
                            hLink.CssClass = "pageNum"
                        End If
                        hLink.Controls.Add(lb)
                        PageNumberPlace.Controls.Add(hLink)
                    End If
                    If i = lclPageNumber - 2 Then
                        Dim lb As New Label()
                        lb = New Label()
                        lb.Text = ".."
                        PageNumberPlace.Controls.Add(lb)
                    End If
                End If
            Next
            'Show next buttom of ShowLastPageNumber = false 
            If Not ShowLastPageNumber Then
                If listReader.Read() Then
                    Dim hLink As New HyperLink()
                    hLink = New HyperLink()
                    hLink.NavigateUrl = "javascript:" & "GotoPage(" & totalPageCount + 1 & ")"

                    Dim lb As New Label()
                    lb.Text = "Next-->"
                    hLink.CssClass = "pageNum"
                    hLink.Controls.Add(lb)
                    PageNumberPlace.Controls.Add(hLink)
                End If
            End If


            Return listTable
        Catch ex As Exception
            Throw ex
        Finally
            listReader.Close()

        End Try
    End Function

    Private _ErrorMessages As DataTable = Nothing
    Public ReadOnly Property PageErrors() As DataTable
        Get
            If Me._ErrorMessages Is Nothing Then
                Me._ErrorMessages = New DataTable()
                Me._ErrorMessages.Columns.Add(New DataColumn("ErrorMessage"))
            End If
            Return Me._ErrorMessages
        End Get
    End Property
    Public Sub AddPageError(ByVal Ex As Exception)
        Dim NewErrorMessage As String = ""

        NewErrorMessage = Ex.Message.Replace("UserError:", "")

        If Me.ShowFullError Then
            NewErrorMessage += Environment.NewLine
            NewErrorMessage += "****************User error Above, Full Below*************************************************" & Environment.NewLine
            NewErrorMessage += Ex.ToString()
            If (Ex.InnerException IsNot Nothing) Then
                NewErrorMessage += Ex.InnerException.ToString()
            End If
        End If
        Me.AddPageError(NewErrorMessage, Ex.ToString) '4/11/20 - pass full error for log
    End Sub
    Public Sub ClearPageErrors()
        Me._ErrorMessages = Nothing
    End Sub
    Public Sub AddPageError(ByVal NewErrorMessage As String, Optional FullErrorForLog As String = "")
        AdditionalInfoForlog += NewErrorMessage & IIf(FullErrorForLog <> "", Environment.NewLine & FullErrorForLog, "") '17/11/21 - Beef up session logging
        Dim row As DataRow = Me.PageErrors.NewRow()
        row("ErrorMessage") = NewErrorMessage
        Try
            If Not NewErrorMessage.Contains("Thread was being aborted") Then
                Me.LogErrorMessage(New Exception(NewErrorMessage & Environment.NewLine & FullErrorForLog)) '4/11/20 add ful error
            End If
        Catch ex1 As Exception
        End Try

        Me.PageErrors.Rows.Add(row)
        Me.IsValid = False
    End Sub
    Public Sub LogErrorMessage(ByVal exToLog As Exception, Optional SendEmailForUnExpected As Boolean = True)
        '13/2/20    James Woosnam   SIR5017 - LogErrorMessage Check querystring for username if there isn't one, write querystring to stacktrace
        Dim sql As String = ""
        sql = "SELECT *"
        sql += " FROM stblErrorMessageLog"
        sql += " WHERE 1=2"
        Dim da As New SqlClient.SqlDataAdapter(sql, db.DBConnection)
        Dim tbl As New DataTable
        da.Fill(tbl)
        da.UpdateCommand = New SqlClient.SqlCommandBuilder(da).GetUpdateCommand()

        Dim row As DataRow = tbl.NewRow
        row("DateTime") = Now()
        Try
            row("UserId") = IIf(Me.UserSession.UserId = Nothing, -1, Me.UserSession.UserId)
        Catch ex As Exception
            row("UserId") = -1
        End Try
        Try
            If Me.UserSession.UserName Is Nothing Then

                If Me.CurrentPage.Request.QueryString("UserName") <> "" Then
                    row("UserName") = Me.CurrentPage.Request.QueryString("UserName")
                Else
                    row("UserName") = "????"
                End If
            Else
                row("UserName") = Me.UserSession.UserName
            End If
        Catch ex As Exception
            row("UserName") = "????"
        End Try
        Try
            row("Page") = Me.CurrentPage.Request.Item("Path_Info")
        Catch ex As Exception
            row("Page") = "????"
        End Try
        Try
            row("ErrorMessage") = exToLog.Message
            Try
                If (exToLog.InnerException IsNot Nothing) Then
                    row("ErrorMessage") += exToLog.InnerException.ToString()
                End If
                If Me.CurrentPage IsNot Nothing Then
                    row("ErrorMessage") += Environment.NewLine & " Page ClientID:" & CurrentPage.ClientID
                    row("ErrorMessage") += Environment.NewLine & " ClientQueryString:" & CurrentPage.ClientQueryString
                End If
                If Me.UserSession IsNot Nothing Then
                    row("ErrorMessage") += Environment.NewLine & " User:" & UserSession.UserId & "-" & UserSession.UserName
                    row("ErrorMessage") += Environment.NewLine & " UserSessionId:" & UserSession.UserSessionId
                End If
            Catch ex As Exception
            End Try

            Try
                If CStr(row("ErrorMessage")).Contains("Unexpected") And SendEmailForUnExpected Then
                    Try
                        Dim email As New BusinessLogic.Email(db)
                        email.SendErrorEmail("PADS Page Error", row("ErrorMessage"))
                    Catch ex As Exception
                        Me.LogErrorMessage(New Exception("Send Error Email in LogErrorMessage failed:" & ex.Message), False)
                    End Try

                End If
            Catch ex As Exception
            End Try
        Catch ex As Exception
            row("ErrorMessage") = "????"
        End Try
        Try
            If exToLog.Source Is Nothing Then
                row("Source") = "???"
            Else
                row("Source") = exToLog.Source
            End If
        Catch ex As Exception
            row("Source") = "????"
        End Try
        Try
            If exToLog.StackTrace Is Nothing Then
                row("StackTrace") = "QueryString:" & Me.CurrentPage.Request.QueryString.ToString
            Else
                row("StackTrace") = exToLog.StackTrace
            End If
        Catch ex As Exception
            row("StackTrace") = "????"
        End Try
        Try
            tbl.Rows.Add(row)
            da.Update(tbl)
        Catch ex As Exception
            Dim msg As String = ex.ToString
        End Try
    End Sub
    Private _InfoMessages As DataTable = Nothing
    Public ReadOnly Property InfoMessages() As DataTable
        Get
            If Me._InfoMessages Is Nothing Then
                Me._InfoMessages = New DataTable()
                Me._InfoMessages.Columns.Add(New DataColumn("InfoMessage"))
            End If
            Return Me._InfoMessages
        End Get
    End Property


    Public Sub AddInfoMessage(ByVal NewInfoMessage As String)
        Dim row As DataRow = Me.InfoMessages.NewRow()
        row("InfoMessage") = NewInfoMessage
        Me.InfoMessages.Rows.Add(row)
    End Sub

    Private Sub FieldErrorControl(ByRef inputField As WebControl)
        FieldErrorControl(inputField, String.Empty)
    End Sub

    Public Sub FieldErrorControl(ByRef inputField As DropDownList, ByVal errorMessage As String)
        Dim wcInputField As WebControl = DirectCast(inputField, WebControl)
        FieldErrorControl(wcInputField, errorMessage)
        inputField = DirectCast(wcInputField, DropDownList)
    End Sub

    Public Sub FieldErrorControl(ByRef inputField As TextBox, ByVal errorMessage As String)
        Dim wcInputField As WebControl = DirectCast(inputField, WebControl)
        FieldErrorControl(wcInputField, errorMessage)
        inputField = DirectCast(wcInputField, TextBox)
    End Sub

    Public Sub FieldErrorControl(ByRef inputField As ListBox, ByVal errorMessage As String)
        Dim wcInputField As WebControl = DirectCast(inputField, WebControl)
        FieldErrorControl(wcInputField, errorMessage)
        inputField = DirectCast(wcInputField, ListBox)
    End Sub

    Public Sub FieldErrorControl(ByRef inputField As CheckBox, ByVal errorMessage As String)
        Dim wcInputField As WebControl = DirectCast(inputField, WebControl)
        FieldErrorControl(wcInputField, errorMessage)
        inputField = DirectCast(wcInputField, CheckBox)
    End Sub

    Public Sub FieldErrorControl(ByRef inputField As WebControl, ByVal errorMessage As String)
        '****************************************** 
        'Sets error message and control background color 
        '****************************************** 
        inputField.CssClass = "fldEntryError"
        If (errorMessage IsNot Nothing) Then

            Me.AddPageError(errorMessage)
        End If
        Me.IsValid = False
    End Sub

    Public Sub DropDownValidateMandatory(ByRef inputField As DropDownList)
        DropDownValidateMandatory(inputField, String.Empty)
    End Sub

    Public Sub DropDownValidateMandatory(ByRef inputField As DropDownList, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If

        If String.IsNullOrEmpty(inputField.SelectedValue) Or inputField.SelectedValue = "0" Then
            FieldErrorControl(inputField, FriendlyName & " is mandatory")
        Else
            inputField.CssClass = "fldEntry"
        End If
    End Sub
    Public Sub DropDownValidateMandatory(ByRef inputField As DropDownList, ByVal EnglishFriendlyName As String, FullSpanishMsg As String)
        Select Case Me.UserSession.DisplayLanguage
            Case BusinessLogic.UserSession.DisplayLanguages.English
                Me.DropDownValidateMandatory(inputField, EnglishFriendlyName)
            Case BusinessLogic.UserSession.DisplayLanguages.Spanish
                If String.IsNullOrEmpty(inputField.SelectedValue) Or inputField.SelectedValue = "0" Then
                    FieldErrorControl(inputField, FullSpanishMsg)
                Else
                    inputField.CssClass = "fldEntry"
                End If
        End Select
    End Sub
    Public Sub FieldValidateMandatory(ByRef inputField As TextBox)
        FieldValidateMandatory(inputField, String.Empty)
    End Sub
    Public Sub FieldValidateMandatory(ByRef inputField As TextBox, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If

        If String.IsNullOrEmpty(inputField.Text.Trim()) Then
            FieldErrorControl(inputField, FriendlyName & " is mandatory")
        Else
            inputField.CssClass = "fldEntry"
        End If
    End Sub
    Public Sub FieldValidateMandatory(ByRef inputField As TextBox, ByVal EnglishFriendlyName As String, FullSpanishMsg As String)
        Select Case Me.UserSession.DisplayLanguage
            Case BusinessLogic.UserSession.DisplayLanguages.English
                Me.FieldValidateMandatory(inputField, EnglishFriendlyName)
            Case BusinessLogic.UserSession.DisplayLanguages.Spanish
                If String.IsNullOrEmpty(inputField.Text.Trim()) Then
                    FieldErrorControl(inputField, FullSpanishMsg)
                Else
                    inputField.CssClass = "fldEntry"
                End If
        End Select
    End Sub

    Public Sub ListBoxValidateMandatory(ByRef inputField As System.Web.UI.WebControls.ListBox, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If

        If String.IsNullOrEmpty(inputField.SelectedValue) Then
            FieldErrorControl(inputField, FriendlyName & " is mandatory")
        Else
            inputField.CssClass = "fldEntry"
        End If
    End Sub
    Public Sub FieldValidateMandatory(ByRef inputField As System.Web.UI.WebControls.RadioButtonList, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If

        If String.IsNullOrEmpty(inputField.SelectedValue) Then
            FieldErrorControl(inputField, FriendlyName & " is mandatory")
        Else
            inputField.CssClass = "fldEntry"
        End If
    End Sub
    Public Sub FieldValidateMandatory(ByRef inputField As System.Web.UI.WebControls.RadioButtonList, ByVal EnglishFriendlyName As String, FullSpanishMsg As String)
        Select Case Me.UserSession.DisplayLanguage
            Case BusinessLogic.UserSession.DisplayLanguages.English
                Me.FieldValidateMandatory(inputField, EnglishFriendlyName)
            Case BusinessLogic.UserSession.DisplayLanguages.Spanish
                If String.IsNullOrEmpty(inputField.Text.Trim()) Then
                    FieldErrorControl(inputField, FullSpanishMsg)
                Else
                    inputField.CssClass = "fldEntry"
                End If
        End Select

    End Sub
    Public Sub CheckBoxValidateMandatory(ByRef inputField As System.Web.UI.WebControls.CheckBox, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If

        If inputField.Checked = False Then
            FieldErrorControl(inputField, FriendlyName & " is mandatory")
        Else
            inputField.CssClass = "fldEntry"
        End If
    End Sub

    Private Function FriendlyNameFromFieldName(ByVal FieldName As String) As String
        Dim sOut As String = Nothing
        Dim StdCode As New BusinessLogic.StdCode()
        ' sOut = StdCode.InsertCapitalSpaces(FieldName); 
        sOut = FieldName
        sOut = sOut.Replace("_", " ")
        Return sOut
    End Function

    Public Sub FieldValidateNumber(ByRef inputField As System.Web.UI.WebControls.TextBox, ByVal Mandatory As Boolean)
        FieldValidateNumber(inputField, Mandatory, String.Empty)
    End Sub

    Public Sub FieldValidateNumber(ByRef inputField As System.Web.UI.WebControls.TextBox)
        FieldValidateNumber(inputField, False, String.Empty)
    End Sub

    Public Sub FieldValidateNumber(ByRef inputField As System.Web.UI.WebControls.TextBox, ByVal Mandatory As Boolean, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If
        If inputField.Text <> String.Empty Then
            If Not IsNumeric(inputField.Text) Then
                FieldErrorControl(inputField, FriendlyName & " must be a numerical value")
            Else
                inputField.CssClass = "pageField"
            End If
        Else
            If Mandatory = True Then
                FieldErrorControl(inputField, FriendlyName & " is mandatory")
            Else
                inputField.CssClass = "pageField"
            End If
        End If
    End Sub

    Public Shared Function IsNumeric(ByVal strNumber As String) As Boolean
        If Not String.IsNullOrEmpty(strNumber) Then
            Dim dummyOut As New Double()
            Dim cultureInfo As New System.Globalization.CultureInfo("en-US", True)

            Return [Double].TryParse(strNumber, System.Globalization.NumberStyles.Any, cultureInfo.NumberFormat, dummyOut)
        Else

            Return False
        End If
    End Function

    Public Sub FieldValidateDate(ByRef inputField As System.Web.UI.WebControls.TextBox, ByVal Mandatory As Boolean, ByVal FriendlyName As String)
        If Mandatory And String.IsNullOrEmpty(inputField.Text) Then
            Me.FieldValidateMandatory(inputField)
        End If
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If
        If Not String.IsNullOrEmpty(inputField.Text) Then
            If Not IsValidDate(inputField.Text) Then
                FieldErrorControl(inputField, FriendlyName & " must be a date")
            Else
                inputField.Text = FormatDate(inputField.Text)
                inputField.CssClass = "pageField"

            End If
        Else
            inputField.CssClass = "pageField"
        End If
    End Sub
    '28/02/22   Julian Gates    SIR5391 - Add Sub FieldValidateFirstLastNameInput
    Public Sub FieldValidateFirstLastNameInput(ByRef inputField As System.Web.UI.WebControls.TextBox, ByVal EnglishFriendlyName As String, ByVal SpanishFriendlyName As String)
        Try
            If String.IsNullOrEmpty(EnglishFriendlyName) Then
                EnglishFriendlyName = FriendlyNameFromFieldName(inputField.ID)
            End If
            If Not String.IsNullOrEmpty(inputField.Text) Then
                Dim sChars As String = Me.db.GetParameterValue("InvalidFirstLastNameCharacters")
                Dim sValue As String = db.IsDBNull(inputField.Text, "")
                Dim InvalidChars As String = Nothing
                For iCtr As Integer = 0 To sValue.Length - 1
                    Dim sChar As String = sValue.Substring(iCtr, 1)
                    If sChars.Contains(sChar) Then
                        InvalidChars += sChar & " "
                    End If
                Next
                If InvalidChars <> Nothing Then
                    Select Case Me.UserSession.DisplayLanguage
                        Case BusinessLogic.UserSession.DisplayLanguages.English
                            FieldErrorControl(inputField, EnglishFriendlyName & " contains characters " & InvalidChars & " which are invalid.")
                        Case BusinessLogic.UserSession.DisplayLanguages.Spanish
                            FieldErrorControl(inputField, SpanishFriendlyName & " contiene caracteres " & InvalidChars & " que no son válidos.")
                    End Select
                Else
                    inputField.CssClass = "fldEntry"
                End If
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub


    Public Function BitAsYesNo(ByVal BitValue As String) As String
        If Me.db.IsDBNull(BitValue) Then
            Return ""
        End If
        If BitValue = "True" Then
            Return "Yes"
        Else

            Return "No"
        End If
    End Function


    Public Function FormatDate(ByVal dateValue As String) As String
        '****************************************** 
        'Sets input date value to correct format 
        '****************************************** 
        Select Case dateValue.[GetType]().ToString()
            Case "String"
                If String.IsNullOrEmpty(DirectCast(dateValue, String)) Then
                    Return dateValue
                End If

                Exit Select
        End Select
        If Object.ReferenceEquals(dateValue, System.DBNull.Value) Or dateValue Is Nothing Then
        Else
            Dim dtDateValue As DateTime = DateTime.Parse(dateValue)
            If Me.IsValidDate(dateValue) Then
                Dim dateOnly As DateTime = DateTime.Parse(dtDateValue.ToString("dd-MMM-yyyy"))
                If dtDateValue > dateOnly Then
                    dateValue = dtDateValue.ToString("dd-MMM-yyyy HH:mm:ss")
                Else
                    dateValue = dateOnly.ToString("dd-MMM-yyyy")

                End If
            End If
        End If

        Return dateValue
    End Function


    Public Function IsValidDate(ByVal myDate As Object) As Boolean
        Dim dtResult As DateTime
        Return DateTime.TryParse(DirectCast(myDate, String), dtResult)
    End Function

    'public String GetBeginsWithFilter(TextBox FltrControl) 
    '{ 
    ' String Filter = ""; 
    ' if (FltrControl.Text.Trim() != "") 
    ' { 
    ' Filter = FltrControl.Text.Replace("'", "''''").Trim(); 
    ' } 
    ' return Filter; 
    '} 

    'public string GetBeginsWithSearch(string SearchString, bool BeginsWith) 
    '{ 
    ' if (BeginsWith) 
    ' { 
    ' return SearchString + "%"; 
    ' } 
    ' else 
    ' { 
    ' return "%" + SearchString + "%"; 
    ' } 
    '} 
    Public Function GetBeginsWithFilter(ByVal FltrControl As TextBox) As [String]
        Return GetBeginsWithFilter(FltrControl, False)
    End Function

    Public Function GetBeginsWithFilter(ByVal FltrControl As TextBox, ByVal BeginsWithChk As CheckBox) As [String]
        Return GetBeginsWithFilter(FltrControl, BeginsWithChk.Checked)
    End Function
    Public Function GetBeginsWithFilter(ByVal FltrControl As TextBox, ByVal BeginsWithChecked As [Boolean]) As [String]
        Dim Filter As [String] = ""
        If FltrControl.Text.Trim() <> "" Then
            If BeginsWithChecked Then
                Filter = "" & FltrControl.Text.Replace("'", "''''").Trim() & "%"
            Else
                Filter = "%" & FltrControl.Text.Replace("'", "''''").Trim() & "%"
            End If
        End If
        Return Filter
    End Function


    Public Sub Page_PreRender(ByVal sender As Object, ByVal e As EventArgs)
        If (Me.FocusControl IsNot Nothing) Then
            If Me.FocusControl.Visible = True Then
                'Dim s As String = "<script type='text/javascript' language='javascript'>document.getElementById('ctl00_MainContent_" & Me.FocusControl.ID & "').focus()</script>"
                'Me.CurrentPage.RegisterStartupScript("focus", s)
            End If

        End If
        If Me.IsValid Then
            CurrentPage.MaintainScrollPositionOnPostBack = True
        Else
            CurrentPage.MaintainScrollPositionOnPostBack = False
        End If
    End Sub

    Public Sub HandlePageError()
        '****************************************** 
        'Handles errors that occur on the page and are caught by 
        'Page_Error 
        '****************************************** 
        Dim strHTML As String = ""
        Dim strBody As String = ""
        Dim ex As Exception = CurrentPage.Server.GetLastError()
        'Create Email Error Report 
        Dim strSubject As String = "PaDS error:"
        '& ex.Message 
        'Create HTML error report. 
        strHTML = "<html><header>"
        strHTML += "<style type='text/css'>.redTable {border:1px solid red;} .blueTable {border:1px solid darkblue;}</style>"
        strHTML += "</header><body>"
        strHTML += "<table border='0' width='755'>"
        strHTML += "<tr>" & "<td colspan='2'>" & "<h1><font color='darkblue'>PaDS Error Report</FONT></h1><hr color='#C0C0C0' width='100%'></td>"
        strHTML += "</tr>"
        strHTML += "</table>"

        strHTML += "<br />"

        strHTML += "<table border='0' width='755' class='redTable' cellpadding='5' cellspacing='0'>"
        strHTML += "<tr>" & "<td>" & "<p>An Error has occurred on this page, if requested please send the section in blue to Zedra Solutions.<br />" & "If you require immediate assistance then contact customer services on 01962 738884.<br />"
        strHTML += ("Or email <a href=""mailto:support@zedra.co.uk" & "?subject=") + strSubject + strBody & """ >Support@Zedra.co.uk</a><BR>"
        strHTML += "Please select back button to return to application.</p></td>"
        strHTML += "</tr>"
        strHTML += "</table>"

        strHTML += "<br />"

        strHTML += "<table border='0' width='755' class='blueTable' cellpadding='5' cellspacing='0'>"
        strHTML += ("<tr>" & "<td width='150' valign='top'><p><font color='darkblue'><b>Error On Page:</p></b></font></td>" & "<td><p>") + CurrentPage.Request.FilePath & "</p></td>"
        strHTML += "</tr>"
        strHTML += ("<tr>" & "<td width='150' valign='top'><p><font color='darkblue'><b>User:</p></b></font></td>" & "<td><p>") + System.Security.Principal.WindowsIdentity.GetCurrent().Name & "</p></td>"
        strHTML += "</tr>"
        strHTML += ("<tr>" & "<td valign='top'><p><font color='darkblue'><b>Error Message:</p></b></font></td>" & "<td><p>") + ex.Message.Replace(Environment.NewLine, "<br />") & "</p></td>"
        strHTML += "</tr>"
        Try
            strHTML += ("<tr>" & "<td valign='top'><p><font color='darkblue'><b>Cause Message:</p></b></font></td>" & "<td><p>") + ex.InnerException.Message.Replace(Environment.NewLine, "<br />") & "</p></td>"
            strHTML += "</tr>"
        Catch
        End Try
        strHTML += ("<tr>" & "<td valign='top'><p><font color='darkblue'><b>Source:</p></b></font></td>" & "<td><p>") + ex.Source.Replace(Environment.NewLine, "<br />") & "</p><br /></td>"
        strHTML += "</tr>"
        strHTML += ("<tr>" & "<td valign='top'><p><font color='darkblue'><b>StackTrace:</p></b></font></td>" & "<td><p>") + ex.StackTrace.Replace(Environment.NewLine, "<br />") & "</p></td>"
        strHTML += "</tr>"

        strBody = strHTML
        strBody += "</table></body></html>"

        Dim sEMailFailureMessage As String = ""
        Try
            Dim email As New BusinessLogic.Email(Me.db)
            email.SendErrorEmail(strSubject, strBody)
        Catch ex1 As Exception
            sEMailFailureMessage = "Error Email Failed:" & ex1.ToString()
        End Try

        If Not String.IsNullOrEmpty(sEMailFailureMessage) Then
            strHTML += ("<tr>" & "<td valign='top'><p><font color='darkblue'><b>Email Failure:</p></b></font></td>" & "<td><p>") + sEMailFailureMessage & "</p></td>"
            strHTML += "</tr>"
        End If
        strHTML += "</table>"

        strHTML += "<table border='0' width='755' >"
        strHTML += "<tr>" & "<td><input type='button' value='<< Back' onClick='history.go(-1)'></td>"
        strHTML += "</tr>"
        strHTML += "</table>"
        strHTML += "</body></html>"
        'Prepare Comment for SessionLog 
        Dim strLogComment As String = Nothing
        strLogComment = "Error on Page:" & CurrentPage.Request.FilePath
        strLogComment = (strLogComment & " User:") + System.Security.Principal.WindowsIdentity.GetCurrent().Name & vbLf
        strLogComment = (strLogComment & " Error:") + ex.ToString()

        'If we don't want to show the standard error page then we can do the line below and 
        'output want ever we like via a response write or go to our own error page. 
        CurrentPage.Server.ClearError()
        CurrentPage.Response.Write(strHTML)
        'try and write the error out to the log 
        Try
            'Me.WriteSessionLog("PageError", strLogComment) 
            Dim LogName As String = "PaDSApplicationLog"
            Dim SourceName As String = "PaDS"
            If (Not System.Diagnostics.EventLog.SourceExists(SourceName)) Then
                System.Diagnostics.EventLog.CreateEventSource(SourceName, LogName)
            End If
            Dim NewLog As New System.Diagnostics.EventLog()
            NewLog.Source = SourceName
            NewLog.WriteEntry(strLogComment, System.Diagnostics.EventLogEntryType.[Error])
        Catch generatedExceptionName As Exception
            'don't worry if we can't do it 
        End Try
    End Sub

    Public Function ClientNoteHasAttachments(ByVal ClientNoteId As String) As Boolean
        Dim FileFolder As [String] = System.IO.Path.Combine(Me.db.GetParameterValue("ClientNoteFileFolder"), [String].Format("{0:000000}", Integer.Parse(ClientNoteId)))
        If System.IO.Directory.Exists(FileFolder) Then
            Dim directory As New System.IO.DirectoryInfo(FileFolder)
            Dim aryFiles As System.IO.FileInfo() = directory.GetFiles("*")
            If aryFiles.Length > 0 Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If
    End Function

    Public Sub PopulateDataTableFromPageTable(ByRef tblData As DataTable, ByVal tblPage As System.Web.UI.WebControls.Table, ByVal KeyFieldName As String)
        'Assumptions 
        ' - The row has an ID of an interger relating to the records being updated 
        ' - the ID Each control containing data that is being updated must caontain the column name and the ID. 
        For Each rowtblPage As System.Web.UI.WebControls.TableRow In tblPage.Rows
            Dim dataRow As DataRow = Nothing
            Dim Dummy As Int32
            Dim result As [Boolean] = Int32.TryParse(rowtblPage.ID, Dummy)
            If result Then
                For Each rowtblRow As DataRow In tblData.Rows
                    If CInt(rowtblRow(KeyFieldName)) = Int32.Parse(rowtblPage.ID) Then
                        dataRow = rowtblRow
                        Exit For
                    End If
                Next
                For Each cell As System.Web.UI.WebControls.TableCell In rowtblPage.Cells
                    For Each cntl As Control In cell.Controls
                        If (cntl.ID IsNot Nothing) Then
                            'If is has an id then it is a form control 
                            For Each col As DataColumn In tblData.Columns
                                If cntl.ID.Contains(col.ColumnName) Then
                                    Select Case cntl.ToString()
                                        Case "System.Web.UI.WebControls.TextBox"
                                            Dim tb As System.Web.UI.WebControls.TextBox = DirectCast(cntl, System.Web.UI.WebControls.TextBox)
                                            dataRow(col.ColumnName) = tb.Text
                                            Exit Select
                                        Case "System.Web.UI.WebControls.DropDownList"
                                            Dim dd As System.Web.UI.WebControls.DropDownList = DirectCast(cntl, System.Web.UI.WebControls.DropDownList)
                                            dataRow(col.ColumnName) = dd.SelectedValue
                                            Exit Select
                                        Case "System.Web.UI.WebControls.ListBox"
                                            Dim lb As System.Web.UI.WebControls.ListBox = DirectCast(cntl, System.Web.UI.WebControls.ListBox)
                                            dataRow(col.ColumnName) = lb.SelectedValue
                                            Exit Select
                                        Case "System.Web.UI.WebControls.CheckBox"
                                            Dim cb As System.Web.UI.WebControls.CheckBox = DirectCast(cntl, System.Web.UI.WebControls.CheckBox)
                                            dataRow(col.ColumnName) = cb.Checked
                                            Exit Select
                                        Case Else
                                            Throw New Exception("Control:" & cntl.ToString() & " not handled")

                                    End Select
                                End If
                            Next
                        End If
                    Next
                Next

            End If
        Next
    End Sub

    Public Function IsValidDocument(ByVal directoryPath As String) As Boolean
        If IO.File.Exists(directoryPath) Then
            Return True
        Else
            Return False
        End If
    End Function

    '07/04/10  Julian Gates  SIR2176 - Add file read only validation
    Public Function FileIsReadOnly(ByVal FileName As String) As Boolean
        Dim myFile As New IO.FileInfo(FileName)
        If (IO.File.GetAttributes(myFile.ToString()) And IO.FileAttributes.ReadOnly) = IO.FileAttributes.ReadOnly Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Sub OpenPopupWorkbook(ByRef Workbook As SpreadsheetGear.IWorkbook)
        Me.OpenPopupWorkbook(Workbook, Me.db.IsDBNull(Replace(Workbook.FullName, " ", ""), "data"))

    End Sub
    Public Sub OpenPopupWorkbook(ByRef Workbook As SpreadsheetGear.IWorkbook, FileName As String)
        'Saves ans streams Excel workbook to a popup window
        Try
            Me.CurrentPage.Response.Clear()
            Me.CurrentPage.ContentType = "application/vnd.ms-excel"
            Me.CurrentPage.Response.AddHeader("Content-Disposition", "attachment; filename=" & FileName & ".xlsx")
            Workbook.SaveToStream(Me.CurrentPage.Response.OutputStream, SpreadsheetGear.FileFormat.Excel8)
            Me.CurrentPage.Response.End()
        Catch ex As Exception
            Throw New Exception("Workbook Export Failed:" & ex.Message)
        End Try
    End Sub
    Public Sub PopOpenFileBytes(FileName As String, FileBytes As Byte())
        Try
            Me.CurrentPage.Response.Clear()
            Me.CurrentPage.ContentType = "application/vnd.ms-excel"

            Me.CurrentPage.Response.AddHeader("Content-Disposition", "attachment; filename=" & FileName.Replace(" ", ""))
            Me.CurrentPage.Response.BinaryWrite(FileBytes)

        Catch ex As Exception
            Throw New Exception("PopOpenFileBytes Failed:" & ex.Message)
        End Try

        '03/07/12 Julian Gates  Moved  Me.CurrentPage.Response.End() out of try catch statement
        If Me.IsValid Then
            Me.CurrentPage.Response.End()
        End If
    End Sub
    Public Function LinkButtonText(ByVal buttonText As String) As String

        Dim buttonTextOutput As String = ""
        buttonTextOutput = "<span><span><span><span><span><span>" _
                            & "<span>" & buttonText & "&nbsp;&nbsp;<img height=""14"" src=""../Images/LinkButtons/arrow.gif"" width=""5"" border=""0"" alt=""""/></span>" _
                            & " </span></span></span></span></span></span>"

        Return buttonTextOutput

    End Function

    Function GetImportFileText(ByVal FileName As String) As String
        Dim reader As System.IO.StreamReader = Nothing
        Dim fileText As String = ""

        If System.IO.File.Exists(FileName) Then
            Try
                reader = New System.IO.StreamReader(FileName, System.Text.Encoding.Default)
                fileText = reader.ReadToEnd()
            Catch ex As Exception
                Throw New Exception(ex.Message)
            Finally
                reader.Close()
            End Try
        Else
            Throw New Exception("File " & FileName & " not found")
        End If

        Return fileText
    End Function

    'Spanish Validation controls
    Public Sub FieldValidateMandatoryESP(ByRef inputField As TextBox)
        FieldValidateMandatory(inputField, String.Empty)
    End Sub
    Public Sub FieldValidateMandatoryESP(ByRef inputField As TextBox, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If

        If String.IsNullOrEmpty(inputField.Text.Trim()) Then
            FieldErrorControl(inputField, FriendlyName)
        Else
            inputField.CssClass = "fldEntry"
        End If
    End Sub

    Public Sub DropDownValidateMandatoryESP(ByRef inputField As DropDownList)
        DropDownValidateMandatory(inputField, String.Empty)
    End Sub

    Public Sub DropDownValidateMandatoryESP(ByRef inputField As DropDownList, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If

        If String.IsNullOrEmpty(inputField.SelectedValue) Then
            FieldErrorControl(inputField, FriendlyName)
        Else
            inputField.CssClass = "fldEntry"
        End If
    End Sub
    Public Function GetPopupInfo(ByVal PopupText As String) As String
        If PopupText = "" Then
            Return ""
        Else
            Return GetPopupHTML(PopupText, " <img src='../images/icons/info.gif?v001 'border='0'/>", "tt")
        End If
    End Function
    Public Function GetPopupWarning(ByVal PopupText As String) As String
        If PopupText = "" Then
            Return ""
        Else
            Return GetPopupHTML(PopupText, " <img src='../images/icons/warning.gif?v001 'border='0'/>", "ttWarn")
        End If
    End Function
    Public Function GetPopupHTML(ByVal PopupText As String, ByVal LinkText As String, ByVal ttClass As String, Optional ByVal LinkHref As String = "") As String
        If PopupText = "" Then
            Return ""
        End If
        If LinkHref = "" Then
            LinkHref = "#"
        End If
        Return "<a href=""" & LinkHref & """ class=""" & ttClass & """>" & LinkText & "<span class='tooltip'><span class='top'></span><span class='middle'>" & PopupText & "</span><span class='bottom'></span></span></a>"
    End Function

End Class
