﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.UserSession

'Modification History
'17/01/11  Julian Gates   Initial version
'12/05/11  Julian Gates   SIR2428 - Set UserSession.Data("HasCurrentSubscription") in GetWebProductList() to be used in pg232RemoteOrder to hide PEPWEB24
'21/6/11   James Woosnam  SIR2445 - The above change is now reversed as this is now hanlded in sp236WebProducts
'22/6/11   Julian Gates   SIR2459 - Add new IsSubscriberValidForOrdering error message functionality.
'05/3/12   Julian Gates   Removed Ajax roundpanels
'08/3/12   Julian Gates   SIR2631 - Add code to hide product renewal link until user has updated subscriber details
'03/10/14   Julian Gates    SIR3621 - Add IsReceiveEmail as read only yes no value.
'30/03/15   Julian Gates    SIR3785 - Show spanish order button and subscribed to product in spanish.
'04/07/17   Julian Gates    Remove IJP-es spanish product text and orden button
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields
'29/10/19   Julian Gates    SIR4768 - Removed VATNumber, MailMethod, Operating system.
'29/10/19   Julian Gates    SIR4763 - Remove WebUserName
'30/10/19   Julian Gates    SIR4768 - Add Subscriptions list
'31/10/19   Julian Gates    SIR4949 - Change Order buttons to be PEP and IJP versions.
'25/11/19   Julian Gates    SIR4957 - Remove Subscription list
'15/1/20    James Woosnam   SIR4970 - show renewal link for any product recurring by month.
'10/2/20    James Woosnam   SIR4937 - Show Subscriber Category in affiliate list
'28/4/20    Julian Gates    SIR5032 - Add spanish translation
'3/2/20     James Woosnam   SIR5094 - Only show 'Current' subscriber affiliate parents
'8/7/20     Julian Gates    SIR5097 - Remove Subscriber Category from BuildAffiliations grid and Subscriber details section.
'12/11/20   Julian Gates    SIR5148 - Make Subscribed to product code read only and not a link in GetWebProductList
'02/02/21   Julian Gates    SIR5186 - Add SubscriberId in small font to top right of Subscriber deatails panel.
'13/1/22    james Woosnam   SIR5388 - Remove IsReceiveMailYesNo control 
'07/02/22   James Woosnam   SIR5418 - Add IJP Purchase/Despatch Use Review Info section

Partial Class Pages_pg101Home
    Inherits System.Web.UI.Page
    Dim pageMode As String = ""
    Dim StdCode As New BusinessLogic.StdCode()

    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                Me._Subscriber = New BusinessLogic.Subscriber(Me.Master.UserSession.Data("SubscriberId"), Me.Master.db, Me.Master.UserSession)
                '9/2/21     James Woosnam   SIR5186 - Logout if tryinh to open a mergered sub, due to auto open from cookie
                If Not {BusinessLogic.Subscriber.SubscriberStates.Current, BusinessLogic.Subscriber.SubscriberStates.Proposed}.Contains(_Subscriber.SubscriberStatus) Then
                    Me.Master.SessionLogout()
                End If
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property
    Public Property DisplayLanguage As BusinessLogic.UserSession.DisplayLanguages
        Get
            Return Me.Master.UserSession.DisplayLanguage
        End Get
        Set(value As BusinessLogic.UserSession.DisplayLanguages)
            Me.Master.UserSession.DisplayLanguage = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Master.Initilise("Home", "01", "")
        Master.ShowLanguageRBL = True

        If Page.IsPostBack Then
            pageMode = "Update"
        Else
            pageMode = "Update"
            If Me.Master.WebForm.IsValid Then
                ReadRecord()
            End If
            ' Me.UserAccountName.Focus()
        End If
    End Sub

    Sub PageSetup()

        Me.Master.PageTitle = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Home" _
                               , "Inicio")

        Me.UpdateDetailsBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Change Your Details", "Cambiar su información")
        Me.UpdateDetailsBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Change Your Details", "Cambiar su información")

        Me.NewIJPOrderBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "New IJP Order", "Nueva compra en IJP")
        Me.NewIJPOrderBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Create new IJP order", "Crear nuevo pedido de IJP")

        Me.NewPEPOrderBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "New PEP Order", "Nueva compra en PEP")
        Me.NewPEPOrderBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Create new PEP order", "Crear nuevo pedido de PEP")

        '22/6/11   Julian Gates   SIR2459 - Add new IsSubscriberValidForOrdering error message functionality.
        If Me.Subscriber.IsSubscriberValidForOrdering() <> "" Then
            Me.IsSubscriberValidForOrderingError.Text = "<b>" & IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "WARNING: Subscriber Details Missing", "PRECAUCIÓN: Los detalles del suscriptor no se han encontrado") & "</b> <br>" & Me.Subscriber.IsSubscriberValidForOrdering()
            Me.TableRowIsSubscriberValidForOrdering.Visible = True
            Me.NewPEPOrderBtn.Enabled = False
            Me.NewIJPOrderBtn.Enabled = False
            Me.NewPEPOrderImageBtn.Enabled = False
            Me.NewIJPOrderImageBtn.Enabled = False
        Else
            Me.TableRowIsSubscriberValidForOrdering.Visible = False
            Me.NewPEPOrderBtn.Enabled = True
            Me.NewIJPOrderBtn.Enabled = True
            Me.NewPEPOrderImageBtn.Enabled = True
            Me.NewIJPOrderImageBtn.Enabled = True
        End If
        GetPEPWebProductRenewalNotification()
        GetWebProductList()
        GetDespatchInfo()
        Me.DespatchInfoRow.Visible = Me.DespatchInfoTable.Rows.Count <> 0
        Me.NotReceivedBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Not Received", "No Recibido")
        Me.NotReceivedBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Open Feedback Form", "Abrir formulario de comentarios")
        '17/2/22    James Woosnam   SIR5418 - Affiliations no longer required
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        '    ViewState("MainDataSet") = Me.Subscriber.MainDataset
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        'Read all data from dataset into page fields
        If pageMode = "Update" Then
            Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.Subscriber.SubscriberRow)
            Me.EmailMain.Text = Me.Subscriber.GetAddressText("Email")

            'Show Billing address
            If Me.Subscriber.GetAddressText("Postal", "Billing") Is Nothing Then
                Me.BillingMain.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "#### Currently No Billing Address ####" _
                               , "#### Actualmente no tiene dirección de facturación ####")
            Else
                Me.BillingMain.Text = Me.Subscriber.GetAddressText("Postal", "Billing").Replace(",", ", ")
            End If

            'Show mailing address
            If Me.Subscriber.GetAddressText("Postal", "Main") Is Nothing Then
                Me.PostalMain.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "#### Currently No Postal Address ####" _
                               , "#### Actualmente no tiene dirección de envío ####")
            Else
                Me.PostalMain.Text = Me.Subscriber.GetAddressText("Postal", "Main").Replace(",", ", ")
            End If
            If Me.BillingMain.Text = Me.PostalMain.Text Then Me.BillingMain.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "As above", "Como anteriormente")
            '13/1/22    james Woosnam   SIR5388 - Remove IsReceiveMailYesNo control 

        End If
    End Sub

    Protected Sub UpdateDetailsBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateDetailsBtn.Click
        Response.Redirect("../pages/pg112SubscriberDetailsMaint.aspx?" & Me.Master.UserSession.QueryString)
    End Sub

    Protected Sub NotReceivedBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles NotReceivedBtn.Click
        Response.Redirect("../pages/pg105IJPDespatchFeedbackForm.aspx?" & Me.Master.UserSession.QueryString)
    End Sub


    Sub GetPEPWebProductRenewalNotification()
        '************************************************************************
        ' Shows a renewal notification if web product subscriptions have or are going to expire soon.
        '************************************************************************

        Dim strSQL As String = ""
        Try

            Dim cmd As New SqlCommand("sp235WebProducts", Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                      , Me.Master.UserSession.Data("SubscriberId")))

            Dim tbl As DataTable = Me.Master.db.GetDataTableFromSQL(cmd)

            If tbl.Rows.Count = 0 Then
                Exit Sub
            End If
            For Each row As DataRow In tbl.Rows
                Dim tRow As New TableRow()
                Dim tCell As New TableCell()
                Dim SubEndDate As Date = row("CurrentSubscriptionEndDate")
                If SubEndDate > CDate("1/1/1990") Then
                    Dim strOrderType As String = ""
                    strOrderType = Me.Master.db.DLookup("OrderType", "SalesOrder", "OrderNumber=" & row("CurrentSubscriptionOrderNumber"))
                    Select Case strOrderType
                        Case "Individual", "IndividualRemote"
                            '15/1/20    James Woosnam   SIR4970 - show renewal link for any product recurring by month.
                            '01/10/20	Jmes Woosnam	SIR5118 - Exclude products with DisableAutoRenewalFlag set to true
                            Dim prd As New BusinessLogic.Product(row("PrimaryProductCode"), Master.db, Master.UserSession)
                            If Master.db.IsDBNull(prd.ProductRow("RecurringSubscriptionUnitType"), "").ToString.ToLower = "months" _
                                And Not Master.db.IsDBNull(prd.ProductRow("DisableAutoRenewalFlag"), False) _
                                Then
                                tRow = New TableRow()
                                tCell = New TableCell()
                                tCell.CssClass = "productLink" ' "fldView"
                                If Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.Spanish Then
                                    tCell.Text = "Observe por favor: Su suscripción al " & row("DisplayProductName") & IIf(SubEndDate < Now(), " expiró el:", " caducará el:") & SubEndDate.ToString("dd-MMM-yy HH:mm:ss") & "."
                                    tCell.Text += " Seleccione el enlaceabajo para renovar ahora."
                                    If Me.Subscriber.IsSubscriberValidForOrdering() = "" Then
                                        tCell.Text += " <a href='../Pages/pg232RemoteOrder.aspx?&PageMode=RenewOrder&ProductCode=" & row("ProductCode") & "&" & Me.Master.UserSession.QueryString & "'>Haga clic aquí</a> para renovar."
                                    Else
                                        tCell.Text += " Actualice sus datos de suscriptor para ver el enlace de renovación."
                                    End If

                                Else
                                    tCell.Text = "Please Note: Your subscription to the " & row("DisplayProductName") & IIf(SubEndDate < Now(), " expired on:", " will expire on:") & SubEndDate.ToString("dd-MMM-yy HH:mm:ss") & "."
                                    If Me.Subscriber.IsSubscriberValidForOrdering() = "" Then
                                        tCell.Text += " <a href='../Pages/pg232RemoteOrder.aspx?&PageMode=RenewOrder&ProductCode=" & row("ProductCode") & "&" & Me.Master.UserSession.QueryString & "'>Click Here</a> to renew."
                                    Else
                                        tCell.Text += " Update your subscriber details to see renewal link."
                                    End If
                                End If


                                tCell.VerticalAlign = VerticalAlign.Top
                                tRow.Cells.Add(tCell)
                                Me.ProductRenewalNotification.Rows.Add(tRow)

                                Me.TableRowProductRenewalNotification.Visible = True
                            End If

                    End Select
                End If

            Next

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "An Unexpected error has occured.  Please contact support." _
                               , "Un error inesperado ha ocurrido. Por favor contacte a soporte."), ex))

        End Try

    End Sub


    Sub GetWebProductList()
        Dim strSQL As String = ""
        '13/1/22    James Woosnam   SIR5400 - Remove old PEP combination check
        Dim productCombinationMissing As Boolean = False
        Dim productCodes As String = ""
        Dim orderNumbers As String = ""
        Dim emailText As String = ""

        Try
            Dim cmd As New SqlCommand("sp237GetSubscriberPEPWebSubscriptions", Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                      , Me.Master.UserSession.Data("SubscriberId")))

            Dim tbl As DataTable = Me.Master.db.GetDataTableFromSQL(cmd)

            If tbl.Rows.Count > 0 Then
                Dim tRow As New TableRow()
                tRow.CssClass = "fldPrompt"
                Dim tCell As New TableCell()
                tCell.Text = "Product"
                tCell.ColumnSpan = 2
                tRow.Cells.Add(tCell)
                tCell = New TableCell()
                tCell.Text = "Ordered Via"
                tRow.Cells.Add(tCell)
                tCell = New TableCell()
                tCell.Text = "Expires"
                tRow.Cells.Add(tCell)
                Me.WebProductList.Rows.Add(tRow)

                For Each row As DataRow In tbl.Rows
                    If Me.Master.db.IsDBNull(row("ProductName"), "") <> "" Then
                        tRow = New TableRow()
                        tCell = New TableCell()
                        tCell.Text = row("ProductCode")
                        tRow.Cells.Add(tCell)
                        '12/11/20   Julian Gates    SIR5148 - Make Subscribed to product code read only and not a link.
                        tCell = New TableCell()
                        tCell.Text = row("DisplayProductName")
                        tRow.Cells.Add(tCell)
                        tCell = New TableCell()
                        tCell.Text = row("OrderedViaName")
                        tRow.Cells.Add(tCell)
                        tCell = New TableCell()
                        tRow.Cells.Add(tCell)
                        tCell.Text = CDate(row("RecurringSubscriptionEndDate")).ToString("dd-MMM-yy HH:mm:ss        ")
                        Me.WebProductList.Rows.Add(tRow)
                        Me.WebProductListRow.Visible = True
                    End If
                Next
            End If



        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                          , "An Unexpected error has occured.  Please contact support." _
                          , "Un error inesperado ha ocurrido. Por favor contacte a soporte."), ex))
        End Try
    End Sub
    Sub GetDespatchInfo()
        Try
            Dim cmd As New SqlCommand("sp102GetSubscriberDespatchInfo", Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                      , Me.Master.UserSession.Data("SubscriberId")))

            Dim tbl As DataTable = Me.Master.db.GetDataTableFromSQL(cmd)
            If tbl.Rows.Count = 0 Then Exit Sub
            If tbl.Rows.Count > 0 Then
                Dim DaysIssueDueAfterDespatch As Integer = Master.db.GetParameterValue("DaysIssueDueAfterDespatch", 90)
                Dim tRow As New TableRow()
                tRow.CssClass = "fldPrompt"
                Dim tCell As New TableCell()
                tCell = New TableCell()
                tCell.Text = IIf(Me.DisplayLanguage = DisplayLanguages.English, "Ordered", "Ordenado")
                tRow.Cells.Add(tCell)
                '*******
                tCell = New TableCell()
                tCell.Text = IIf(Me.DisplayLanguage = DisplayLanguages.English, "Journal", "Diario")
                tRow.Cells.Add(tCell)
                '*******
                tCell = New TableCell()
                tCell.Text = IIf(Me.DisplayLanguage = DisplayLanguages.English, "Issue", "Issue")
                tRow.Cells.Add(tCell)
                '*******
                tCell = New TableCell()
                tCell.Text = IIf(Me.DisplayLanguage = DisplayLanguages.English, "Should arrive before", "Fecha de llegada prevista")
                tCell.HorizontalAlign = HorizontalAlign.Center
                Dim sPopUp As String = IIf(Me.DisplayLanguage = DisplayLanguages.English, "<i>Further Info: </i><br>The date, before which, the journal should arrive. This is the planned/actual ship date plus " & DaysIssueDueAfterDespatch & " days.", "<i>Informacion adicional: </i><br>La fecha antes de la cual debe llegar el diario..  Esta es la fecha de envío planificada/real más " & DaysIssueDueAfterDespatch & " días.")
                tCell.Text += Me.Master.WebForm.GetPopupInfo(sPopUp)
                tRow.Cells.Add(tCell)
                '*******
                tCell = New TableCell()
                ' tCell.Text = IIf(Me.DisplayLanguage = DisplayLanguages.English, "Sent to", "Enviado a")
                tRow.Cells.Add(tCell)
                '*******
                Me.DespatchInfoTable.Rows.Add(tRow)
                Dim LastLineKey As String = ""
                Dim lastAddress As String = ""
                For Each row As DataRow In tbl.Rows
                    tRow = New TableRow()
                    tRow.CssClass = "fldView"
                    tCell = New TableCell()
                    If row("ParentProductCode") & row("OrderNumber") <> LastLineKey Then
                        tCell.Text = CDate(row("OrderDate")).ToString("dd-MMM-yy")
                        tRow.Cells.Add(tCell)
                        tRow.Cells.Add(tCell)
                        '*******
                        tCell = New TableCell()
                        tCell.Text = row("ParentProductName")
                    Else
                        tCell.ColumnSpan = 2
                    End If
                    tRow.Cells.Add(tCell)
                    '*******
                    tCell = New TableCell()
                    tCell.Text = row("ChildProductName")
                    tRow.Cells.Add(tCell)
                    '*******
                    tCell = New TableCell()
                    If Master.db.IsDBNull(row("DateDespatched"), Nothing) = Nothing Then
                        tCell.CssClass = "despatchFooterTextSmall"
                        tCell.Text = IIf(Me.DisplayLanguage = DisplayLanguages.English, "Not sent yet", "Aún no enviado")
                    Else
                        tCell.Text = CDate(Master.db.IsDBNull(row("DateDespatched"), row("ChildReleaseDate"))).AddDays(DaysIssueDueAfterDespatch).ToString("dd-MMM-yy")
                        tCell.ToolTip = IIf(Me.DisplayLanguage = DisplayLanguages.English, "The date, before which, the journal should arrive. This is the planned/actual ship date plus " & DaysIssueDueAfterDespatch & " days.", "La fecha antes de la cual debe llegar el diario..  Esta es la fecha de envío planificada/real más " & DaysIssueDueAfterDespatch & " días.")
                    End If
                    tCell.HorizontalAlign = HorizontalAlign.Center
                    tRow.Cells.Add(tCell)
                    '*******
                    tCell = New TableCell()
                    Dim address As String = Master.db.IsDBNull(row("AddressText"), "")
                    tCell = New TableCell()
                    tCell.Text = IIf(address = "", "", IIf(address = lastAddress, "<span class=""fldPrompt"">" & IIf(Me.DisplayLanguage = DisplayLanguages.English, "Sent to", "Enviado a") & "</span>:<span class=""despatchAddressTextSmall"">" & IIf(Me.DisplayLanguage = DisplayLanguages.English, " As above", "Como anteriormente") & "</span>", ""))
                    tRow.Cells.Add(tCell)
                    Me.DespatchInfoTable.Rows.Add(tRow)
                    If Not Master.db.IsDBNull(row("AddressText")) AndAlso row("AddressText") <> lastAddress Then
                        tRow = New TableRow()
                        tCell = New TableCell()
                        tCell.ColumnSpan = 2
                        tRow.Cells.Add(tCell)
                        '*******
                        tCell = New TableCell()
                        tCell.ColumnSpan = 3
                        tCell.Text = "<span class=""fldPrompt"">&nbsp;&nbsp;" & IIf(Me.DisplayLanguage = DisplayLanguages.English, "Sent to", "Enviado a ") & ": </span><span class=""despatchAddressTextSmall"">" & address & "</span>"
                        tCell.Wrap = True
                        tRow.Cells.Add(tCell)
                        Me.DespatchInfoTable.Rows.Add(tRow)
                    End If
                    LastLineKey = row("ParentProductCode") & row("OrderNumber")
                    lastAddress = address
                Next
                tRow = New TableRow()
                tCell = New TableCell()
                tCell.CssClass = "despatchFooterTextSmall"
                tCell.Text = IIf(Me.DisplayLanguage = DisplayLanguages.English, "All future Despatches will go to:", "Todos los Envíos futuros irán a:") & Me.PostalMain.Text
                tCell.ColumnSpan = 5
                tRow.Cells.Add(tCell)
                Me.DespatchInfoTable.Rows.Add(tRow)
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                          , "An Unexpected error has occured.  Please contact support." _
                          , "Un error inesperado ha ocurrido. Por favor contacte a soporte."), ex))
        End Try
    End Sub


    '31/10/19   Julian Gates    SIR4949 - Change Order buttons to be PEP and IJP versions.
    Protected Sub NewPEPOrderBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles NewPEPOrderBtn.Click, NewPEPOrderImageBtn.Click
        Try
            Dim vw As New DataView(Me.Subscriber.CompanyAccount, "CompanyId=2", "", DataViewRowState.CurrentRows)
            If vw.Count = 0 Then Subscriber.AddCompanyAccount(2, "Individual", 4, "Full", Subscriber.SubscriberRow("DefaultPostalAddressId"))
            vw = New DataView(Me.Subscriber.SubscriberAffiliate, "ParentSubscriberId=29002", "", DataViewRowState.CurrentRows)
            Dim vwForCat As New DataView(Me.Subscriber.SubscriberAffiliate, "ParentSubscriberId=29001", "", DataViewRowState.CurrentRows)
            Dim SubscriberCategory As String = Nothing
            If vwForCat.Count > 0 Then SubscriberCategory = Master.db.IsDBNull(vwForCat(0)("SubscriberCategory"), "Ordinary")
            If vw.Count = 0 Then Subscriber.AddSubscriberAffiliate(29002, "", SubscriberCategory)
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "An Unexpected error has occured.  Please contact support." _
                               , "Un error inesperado ha ocurrido. Por favor contacte a soporte."), ex))
        End Try

        If Master.WebForm.IsValid Then Response.Redirect("../Pages/pg232RemoteOrder.aspx?PageMode=NewOrder&CompanyId=2&" & Me.Master.UserSession.QueryString)
    End Sub

    Protected Sub NewIJPOrderBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles NewIJPOrderBtn.Click, NewIJPOrderImageBtn.Click
        Try
            Dim vw As New DataView(Me.Subscriber.CompanyAccount, "CompanyId=1", "", DataViewRowState.CurrentRows)
            If vw.Count = 0 Then Subscriber.AddCompanyAccount(1, "Individual", 4, "Full", Subscriber.SubscriberRow("DefaultPostalAddressId"))
            vw = New DataView(Me.Subscriber.SubscriberAffiliate, "ParentSubscriberId=29001", "", DataViewRowState.CurrentRows)
            Dim vwForCat As New DataView(Me.Subscriber.SubscriberAffiliate, "ParentSubscriberId=29002", "", DataViewRowState.CurrentRows)
            Dim SubscriberCategory As String = Nothing
            If vwForCat.Count > 0 Then SubscriberCategory = Master.db.IsDBNull(vwForCat(0)("SubscriberCategory"), "Ordinary")
            If vw.Count = 0 Then Subscriber.AddSubscriberAffiliate(29001, "", SubscriberCategory)
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "An Unexpected error has occured.  Please contact support." _
                               , "Un error inesperado ha ocurrido. Por favor contacte a soporte."), ex))
        End Try

        If Master.WebForm.IsValid Then Response.Redirect("../Pages/pg232RemoteOrder.aspx?PageMode=NewOrder&CompanyId=1&" & Me.Master.UserSession.QueryString)
    End Sub

    Function SubscriberTable(ByVal strAliasName As String) As String

        SubscriberTable = " Subscriber " & strAliasName _
            & " INNER JOIN SubscriberAffiliate SAJoin" _
            & " ON SAJoin.ChildSubscriberId = " & strAliasName & ".SubscriberId" _
            & " AND SAJoin.ParentSubscriberId IN (0" & Me.Master.UserSession.Data("AuthorisedSubscribers") & ")" _
            & " AND " & StdCode.vFQ(Now(), "D") & " Between SAJoin.StartDate AND SAJoin.EndDate"
    End Function

    Private Sub OpenPEPWeb_Click(sender As Object, e As EventArgs) Handles OpenPEPWeb.Click
        Try
            Dim peps As New BusinessLogic.PEPSecurity(Master.db, New BusinessLogic.StdCode().GetIPAddress(Request), Master.UserSession)
            peps.CompleteAuthentication(Me.Subscriber.RemoteUser, Me.Master.WebForm.AdditionalInfoForlog)

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "An Unexpected error has occured.  Please contact support." _
                               , "Un error inesperado ha ocurrido. Por favor contacte a soporte."), ex))

        End Try
        If Me.Master.WebForm.IsValid Then
            Response.Redirect(Master.db.GetParameterValue("PEPWeb2021URL") & "?sessionId=" & Master.UserSession.UserSessionId)
        End If
    End Sub

    Private Sub IJPOnPEPLink_Click(sender As Object, e As EventArgs) Handles IJPOnPEPLink.Click
        Try
            Dim peps As New BusinessLogic.PEPSecurity(Master.db, New BusinessLogic.StdCode().GetIPAddress(Request), Master.UserSession)
            peps.CompleteAuthentication(Me.Subscriber.RemoteUser, Me.Master.WebForm.AdditionalInfoForlog)

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "An Unexpected error has occured.  Please contact support." _
                               , "Un error inesperado ha ocurrido. Por favor contacte a soporte."), ex))

        End Try
        If Me.Master.WebForm.IsValid Then
            Response.Redirect(Master.db.GetParameterValue("PEPWeb2021URL") & "/browse/IJP/volumes?sessionId=" & Master.UserSession.UserSessionId)
        End If
    End Sub
End Class
