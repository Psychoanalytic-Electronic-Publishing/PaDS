﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'20/04/2020    Julian Gates   Initial Version
'18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified

Partial Class Pages_pg260LookupList
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Public Enum LookupStatus
        Active = 1
        Inactive = 2
    End Enum
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Lookup List", "")
        Me.pageHeaderTitle.Text = "Lookup List"

        If Page.IsPostBack Then

        Else

        End If
        GridSetup()

    End Sub

    Sub GridSetup()
        Try
            'Populate dropdown fields
            CType(Me.MainTableGridView.Columns("LookupStatus"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = [Enum].GetValues(GetType(LookupStatus))
            CType(Me.MainTableGridView.Columns("LookupName"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL("Select Distinct LookupName As Value ,LookupName As Text From Lookup")
            CType(Me.MainTableGridView.Columns("CompanyId"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL("Select CompanyId As Value ,CompanyName As Text From Company")
            CType(Me.MainTableGridView.Columns("MaintenanceGroup"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL("Select Distinct MaintenanceGroup As Value ,MaintenanceGroup As Text From Lookup")

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        uPage.PagePreRender()
    End Sub
    Protected Sub MainTableGridView_InitNewRow(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInitNewRowEventArgs) Handles MainTableGridView.InitNewRow

        Dim lookupNameCombo As GridViewDataComboBoxColumn = TryCast(MainTableGridView.Columns("LookupName"), GridViewDataComboBoxColumn)
        lookupNameCombo.PropertiesComboBox.ValueType = GetType(String)

        If lookupNameCombo.PropertiesComboBox.Items.Count = 0 Then
            For Each row As DataRow In Me.uPage.db.GetDataTableFromSQL("Select Distinct LookupName As Value ,LookupName As Text From Lookup").Rows
                lookupNameCombo.PropertiesComboBox.Items.Add(row("Text"), row("Value"))
            Next
        End If
        lookupNameCombo.ReadOnly = False
    End Sub

    Protected Sub MainTableGridView_RowUpdated(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataUpdatedEventArgs) Handles MainTableGridView.RowUpdated
        Dim combo1 As GridViewDataComboBoxColumn = TryCast(MainTableGridView.Columns("LookupName"), GridViewDataComboBoxColumn)
        combo1.Visible = True

        '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
        e.NewValues("LastUpdatedDateTime") = Now()
        e.NewValues("LastUpdatedByUserId") = uPage.UserSession.UserName20
    End Sub

    Protected Sub MainTableGridView_RowInserting(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInsertingEventArgs) Handles MainTableGridView.RowInserting
        '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
        e.NewValues("LastUpdatedDateTime") = Now()
        e.NewValues("LastUpdatedByUserId") = uPage.UserSession.UserName20
    End Sub

    Protected Sub MainTableGridView_ItemUpdating(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataUpdatingEventArgs) Handles MainTableGridView.RowUpdating
        e.NewValues("LastUpdatedDateTime") = Now()
        e.NewValues("LastUpdatedByUserId") = uPage.UserSession.UserName20
    End Sub
End Class
