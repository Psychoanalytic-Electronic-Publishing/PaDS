﻿Imports System.Data
Imports System.Data.SqlClient
'Modification History
'21/09/21  Julian Gates   Initial version
Partial Class pages_pg163BatchJobList
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Public ListTableHtml As String = ""
    Public PageHtml As String = ""
    Dim ds As New DataSet
    Dim tbl As DataTable

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Batch Job Display", "")
        Me.pageHeaderTitle.Text = "Batch Job Display"

        If Not Page.IsPostBack Then
            txtRecordsToShow.Text = 20
            Me.txtPageNumber.Text = 1
            If Request.QueryString("FltrBatchJobId") <> "" Then
                Me.FltrBatchJobId.Value = Request.QueryString("FltrBatchJobId")
            End If

            Me.FltrFromActualStartDate.Text = "01-Jan-20"
            Me.FltrToActualStartDate.Text = "31-Dec-25"

            'Populate all dropdown fields
            Dim sql As String = ""
            sql = "SELECT DISTINCT Value"
            sql += "      ,Text"
            sql += " FROM (SELECT TOP 10000 Value=BatchJobName"
            sql += "      ,Text=BatchJobName"
            sql += "      ,BatchJobId"
            sql += " FROM BatchJob  With (NoLock)"
            sql += " WHERE CreatedDateTime > DATEADD(year,-1,GETDATE())"
            sql += " ORDER BY BatchJobId DESC) logs"
            sql += " ORDER BY Text"
            uPage.PopulateDropDownListFromSQL(Me.FltrBatchJobName, sql, uPage.PrimaryConnection, "<--All-->")

            sql = "SELECT DISTINCT Value"
            sql += "      ,Text"
            sql += " FROM (SELECT TOP 10000 Value=BatchJobStatus"
            sql += "      ,Text=BatchJobStatus"
            sql += "      ,BatchJobId"
            sql += " FROM BatchJob  With (NoLock)"
            sql += " WHERE CreatedDateTime > DATEADD(year,-1,GETDATE())"
            sql += " ORDER BY BatchJobId DESC) logs"
            sql += " ORDER BY Text"
            uPage.PopulateDropDownListFromSQL(Me.FltrBatchJobStatus, sql, uPage.PrimaryConnection, "<--All-->")
            BuildGrid()
        Else
            If Left(Me.txtCommandData.Value, 5) = "Pause" Then
                UpdateBatchJobRecord(Mid(Me.txtCommandData.Value, 6), "PendingPaused")
            End If
            If Left(Me.txtCommandData.Value, 6) = "Resume" Then
                UpdateBatchJobRecord(Mid(Me.txtCommandData.Value, 7), "Pending")
            End If

            If Me.txtGotoPageNum.Value <> "" Then
                Me.txtPageNumber.Text = Me.txtGotoPageNum.Value
                BuildGrid()
            End If
        End If
    End Sub

    Sub UpdateBatchJobRecord(ByVal locId As String, ByVal StatusValue As String)
        Dim SQL As String = Nothing
        SQL = "UPDATE BatchJob"
        SQL += " SET BatchJobStatus = '" & StatusValue & "'"
        SQL += " WHERE BatchJob.BatchJobId = " & locId

        Dim cmdUpdate As New SqlCommand(SQL, uPage.PrimaryConnection)
        cmdUpdate.ExecuteNonQuery()

        Me.txtCommandData.Value = ""
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub
    Private Sub BuildGrid()
        Dim strCmd As String = ""
        Dim strHtml As String = ""
        Dim strCommandText As String = ""

        Me.txtRecordsToShow.Text = uPage.ValidateRecordsToShow(Me.txtRecordsToShow.Text)

        strCmd = "sp163BatchJobDisplay "
        strCmd += CStr(CLng(Me.txtRecordsToShow.Text) * CLng(Me.txtPageNumber.Text))
        strCmd += " ,'" & Me.FltrBatchJobName.SelectedValue & "'"
        strCmd += " ,'" & Me.FltrBatchJobStatus.SelectedValue & "'"
        If Me.FltrFromActualStartDate.Text <> "" And IsDate(FltrFromActualStartDate.Text) Then
            strCmd += " ," & uPage.StdCode.vFQ(FltrFromActualStartDate.Text, "d")
        End If
        If Me.FltrToActualStartDate.Text <> "" And IsDate(FltrToActualStartDate.Text) Then
            strCmd += " ," & uPage.StdCode.vFQ(FltrToActualStartDate.Text, "d")
        End If

        Dim BatchJobReader As SqlDataReader = New SqlCommand(strCmd, uPage.PrimaryConnection).ExecuteReader
        uPage.SetupDataList(Me.txtPageNumber.Text, Me.txtRecordsToShow.Text, BatchJobReader, Me.lblPaging.Text)

        'Create DataGrid by looping through Records
        If BatchJobReader.HasRows Then
            Do
                strHtml += "<tr>"
                strHtml += "<td><a href=""../pages/pg164BatchJobMaint.aspx?BatchJobId=" & BatchJobReader("BatchJobId") & """>" & BatchJobReader("BatchJobName") & "</a></td>"
                strHtml += "<td>"
                strHtml += "<table border=""0"" cellpadding=""2""><tr>"
                strHtml += "<td>" & BatchJobReader("BatchJobStatus") & "</td>"
                Select Case BatchJobReader("BatchJobStatus")
                    Case "Pending", "PendingPaused"
                        Dim buttonText As String = Nothing
                        Select Case BatchJobReader("BatchJobStatus")
                            Case "Pending"
                                buttonText = "Pause"
                            Case "PendingPaused"
                                buttonText = "Resume"
                        End Select
                        strHtml += "<td>" _
                            & "<a href='javascript:ConfirmSubmitCommandData(""Are you sure you want change the status?"",""" & buttonText & BatchJobReader("BatchJobId") _
                            & """)' title='Update Batch Job Status'>" & buttonText & "</a>" _
                            & "</td>"
                    Case Else
                        strHtml += "<td>&nbsp;</td>"
                End Select
                strHtml += "</td>"
                strHtml += "</tr></table>"
                strHtml += "<td>" & BatchJobReader("ScheduledStartDateTime") & "</td>"
                strHtml += "<td>" & BatchJobReader("ActualStartDateTime") & "</td>"
                strHtml += "<td>" & BatchJobReader("EndDateTime") & "</td>"
                strHtml += "<td>" & BatchJobReader("RescheduleDelaySeconds") & "</td>"
                strHtml += "<td>" & BatchJobReader("ReScheduleFrom") & "</td>"
                Dim BatchLogId As Integer = BatchJobReader("BatchLogId")
                Select Case BatchLogId
                    Case 0
                        strHtml += "<td><a href=""../pages/pg160BatchLogList.aspx"">Logs</a></td>"
                    Case Else
                        strHtml += "<td><a href=""../pages/pg161BatchLogLines.aspx?BatchLogId=" & BatchLogId & """>" & BatchLogId & "(" & BatchJobReader("BatchLogStatus") & ")</a></td>"
                End Select
                strHtml += "</tr>"
            Loop Until Not BatchJobReader.Read()
        Else
            uPage.PageError = "No records match your selection critieria"
        End If
        BatchJobReader.Close()
        'Assign grid to Label
        lblGridView.Text = strHtml
    End Sub
    Private Sub btnFilter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFilter.Click
        BuildGrid()
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub
    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        uPage.PageUnload()
    End Sub
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        uPage.PagePreRender()
    End Sub
    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub
    Private Sub FltrBatchJobName_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FltrBatchJobName.SelectedIndexChanged
        BuildGrid()
        uPage.FocusControl = Me.FltrBatchJobName
    End Sub
    Private Sub FltrBatchJobStatus_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FltrBatchJobStatus.SelectedIndexChanged
        BuildGrid()
        uPage.FocusControl = Me.FltrBatchJobStatus
    End Sub
End Class