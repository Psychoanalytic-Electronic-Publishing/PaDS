﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.Subscriber
Imports System.Environment
'Modification History
'16/04/20  Julian Gates   Initial New version
'27/12/20   James Woosnam   SIR5170 - Use correct flag for mark despatched
'17/02/21   Julian Gates    SIR5166 - Removed old asp page links
'04/11/21   Julian Gates    SIR5354 - Only show non InActive Subscribers in despatch list

Partial Class Pages_pg180OrderDespatch
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Order Despatch", "")

        'Only allow update by AuthorityLevel Admin users
        Select Case Me.uPage.UserSession.AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
            Case Else
                Response.Redirect("../Pages/pg100HomeAdmin.aspx?InfoMsg=Your userid does not allow you access to this page.")
        End Select

        Try
            If Page.IsPostBack Then

            Else
                If Me.uPage.IsValid Then
                    ReadRecord()
                End If
            End If
        Catch ex As Exception
            uPage.PageError = "An unexpected error has occured.  Please contact support." & ex.ToString
        End Try

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        SubsGridSetup()

    End Sub

    Sub PageSetup()

        uPage.pageTitle = "Order Despatch"
        Me.pageHeaderTitle.Text = uPage.pageTitle

        Me.DespatchDeliveryAreaRow.Visible = Me.ProductCode.SelectedValue <> "" And DespatchDeliveryArea.Items.Count > 1
        Me.UndespatchedOnlyRow.Visible = Me.ProductCode.SelectedValue <> ""
        Me.MarkAsDesptachedRow.Visible = Me.ProductCode.SelectedValue <> ""
        Me.DespatchBtnRow.Visible = Me.ProductCode.SelectedValue <> ""
        If Me.ProductCode.SelectedValue <> "" Then
            Me.SubsListTable.Visible = True
        End If
        Me.TimedPanel.Visible = IsNumeric(ViewState("BatchJobId"))
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        'populate dropdowns
        Dim sql As String = "SELECT  Product.ProductCode As Value" _
                            & "		,ParentProduct.ProductCode + ' ' + Product.productCode" _
                            & "	 + ' - ' + Product.ProductName As Text" _
                            & " From Product " _
                            & "		INNER JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                            & "		ON Company.CompanyId = Product.CompanyId" _
                            & "		INNER JOIN Product ParentProduct" _
                            & "		ON ParentProduct.ProductCode = Product.ParentProductCode" _
                            & " WHERE Product.ReleaseDate  <= GetDate() " _
                            & "	And ParentProduct.ShippedProductFlag  =1" _
                            & "	And ParentProduct.ProductStatus  ='Current'" _
                            & " Order by ParentProduct.ProductCode, Product.productCode"
        Me.uPage.PopulateDropDownListFromSQL(Me.ProductCode, sql, uPage.db.DBConnection, "<--Select-->")

    End Sub


    Protected Sub ProductCode_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ProductCode.SelectedIndexChanged
        If ProductCode.SelectedValue <> "" Then

            ViewState("CompanyID") = uPage.db.DLookup("CompanyID", "Product", "ProductCode='" & Me.ProductCode.SelectedValue & "'")

            Dim Sql As String = "SELECT DespatchDeliveryArea as Value" _
                  & "	,DespatchDeliveryArea As Text" _
                  & " FROM DespatchDeliveryArea" _
                  & " WHERE CompanyId = " & ViewState("CompanyID") _
                  & " GROUP BY  DespatchDeliveryArea" _
                  & " ORDER BY 1"
            Me.uPage.PopulateDropDownListFromSQL(Me.DespatchDeliveryArea, Sql, uPage.db.DBConnection)
            Me.SubsGridSetup()
        End If
    End Sub

    Protected Sub DespatchBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DespatchBtn.Click
        Try
            Me.uPage.DropDownValidateMandatory(Me.ProductCode, "Product To Despatch")
            If Me.DespatchDeliveryAreaRow.Visible Then
                Me.uPage.DropDownValidateMandatory(Me.DespatchDeliveryArea, "Despatch Delivery Area")
            End If
            If Not uPage.IsValid Then Exit Sub
            Dim SalesOrder As New BusinessLogic.SalesOrder(uPage.db, uPage.UserSession)
            '27/12/20   James Woosnam   SIR5170 - Use correct flag for mark despatched
            '8/2/22     James           Move GetDespatchSQL function in SalesOrder Class

            ViewState("BatchJobId") = SalesOrder.SubmitDespatchSalesOrder(Me.DespatchDeliveryArea.SelectedValue _
                                                , Not Me.MarkAsDesptached.Checked _
                                                , Me.ProductCode.SelectedValue
                                                )
            Me.UpdateTimer.Enabled = True

        Catch ex As Exception
            Me.uPage.PageError = "An unexpected Error has occured. Please contact support." & ex.ToString
        End Try

    End Sub
    Protected Sub UpdateTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateTimer.Tick
        Try
            If IsNumeric(ViewState("BatchJobId")) Then
                Dim BatchLog As New BusinessLogic.BatchLog(uPage.db)
                Me.BatchLogLines.Text = BatchLog.GetBatchLogLinesHTML(ViewState("BatchJobId"))
                Select Case uPage.db.IsDBNull(uPage.db.DLookup("MAX(BatchLogStatus)", "BatchLog", "BatchJobId=" & ViewState("BatchJobId")), "")
                    Case "Failed"
                        Me.UpdateTimer.Enabled = False
                    Case "Complete"
                        Me.UpdateTimer.Enabled = False
                        Me.uPage.InfoMessage = "Despatch Complete"
                    Case Else
                        Me.UpdateTimer.Enabled = True
                End Select
            Else
                Me.UpdateTimer.Enabled = False
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub
    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
    End Sub

    Sub SubsGridSetup()
        Dim Sql As String = ""
        Try
            If Me.ProductCode.SelectedValue = "" Then Exit Sub
            Dim so As New BusinessLogic.SalesOrder(uPage.db, uPage.UserSession)
            Me.SubsDatasource.SelectCommand = so.GetDespatchSubscriberSQL(so.DespatchSQLPurposes.Grid, Me.ProductCode.SelectedValue, Me.DespatchDeliveryArea.SelectedValue, Me.UndespatchedOnly.Checked)
            Me.SubsDatasource.DataBind()
            Me.SubsGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString & Sql
        End Try
    End Sub
End Class
