﻿Imports System.Data.SqlClient
Imports System.Data
Imports BusinessLogic.ReportPEPUsage
'Modification History
'24/09/21   Julian Gates    Initial version
'21/4/22	Julian Gates	SIR5467 - Set Batch Log line to top align in page.

Partial Class Pages_pg466PEPUsageReport
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim _tblGroups As DataTable = Nothing
    Dim Rep As BusinessLogic.ReportPEPUsage = Nothing
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "PEP Usage Report", "")
        Me.pageHeaderTitle.Text = "PEP Usage Report"

        Rep = New BusinessLogic.ReportPEPUsage(Me.StartMonth.SelectedValue, Me.EndMonth.SelectedValue, Me.ReportType.SelectedValue, uPage.db, uPage.UserSession.UserSessionIdGUID)

        If Page.IsPostBack Then

        Else
            ReadRecord()
            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            'Default date field values
            Dim Sep2021Index As Integer = 0
            Dim periods As DataTable = uPage.db.GetDataTableFromSQL("SELECT DISTINCT Month FROM PEPUsageSummary ORDER BY Month")
            For Each r As DataRow In periods.Rows
                Me.StartMonth.Items.Add(New ListItem(r("Month")))
                If r("Month") = "2021-09 Sep" Then Sep2021Index = Me.StartMonth.Items.Count - 1
            Next
            Me.StartMonth.SelectedIndex = Sep2021Index 'Set start to sep 2021, until we get 24 months after sep 21, then just last 24 months
            If Me.StartMonth.Items.Count > 7 + (24) Then Me.StartMonth.SelectedIndex = Me.StartMonth.Items.Count - 24
            For Each r As DataRowView In New DataView(periods, "", "Month Desc", DataViewRowState.CurrentRows)
                Me.EndMonth.Items.Add(New ListItem(r("Month")))
            Next
            Me.EndMonth.SelectedIndex = 0

            If Request.QueryString("ReportType") <> "" And Request.QueryString("ReportingParentSubscriberId") <> "" Then
                Me.ReportType.SelectedValue = PEPUsageReportTypes.PEPUsageSingleReportingParentDetail
                Rep.PEPUsageReportType = PEPUsageReportTypes.PEPUsageSingleReportingParentDetail
                Me.ReportingParentSubscriberId.SelectedValue = Request.QueryString("ReportingParentSubscriberId")
            End If
        End If
    End Sub

    Sub PageSetup()
        SelectReportingParentSubscriberRow.Visible = Rep.PEPUsageReportType = PEPUsageReportTypes.PEPUsageSingleReportingParentDetail
        ReportingParentSummaryTable.Visible = Rep.PEPUsageReportType = PEPUsageReportTypes.PEPUsageDetailByReportingParent
        ReportingParentSummaryHeader.Visible = Rep.PEPUsageReportType = PEPUsageReportTypes.PEPUsageDetailByReportingParent

        Select Case Rep.PEPUsageReportType
            Case PEPUsageReportTypes.PEPUsageDetailByReportingParent

                BuildReportingParentSummaryGridHTML(uPage.db.GetDataTableFromSQL(New BusinessLogic.ReportPEPUsage(Me.StartMonth.SelectedValue, Me.EndMonth.SelectedValue, PEPUsageReportTypes.PEPUsageSummaryByReportingParent, uPage.db, uPage.UserSession.UserSessionIdGUID).SQL))
            Case PEPUsageReportTypes.PEPUsageSingleReportingParentDetail
                Me.ReportingParentSubscriberId.Focus()
        End Select
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************



        'Populate all dropdown fields
        Dim dropDownIntialValue As String = "<---------Select--------->"
        uPage.PopulateDropDownListFromSQL(Me.ReportingParentSubscriberId, "SELECT DISTINCT Value = ReportingParentSubscriberId" _
                                                             & "    ,Text = ReportingParentSubscriberName" _
                                                             & " FROM PEPUsageSummary " _
                                                             & " ORDER BY ReportingParentSubscriberName" _
                                                             , uPage.PrimaryConnection, dropDownIntialValue
                                                             )

    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        PageSetup()
        uPage.PagePreRender()
    End Sub


    Private Sub SubmitBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubmitBtn.Click
        Try
            Dim SubId As Integer = 0
            Select Case Rep.PEPUsageReportType
                Case BusinessLogic.ReportPEPUsage.PEPUsageReportTypes.PEPUsageSingleReportingParentDetail
                    uPage.DropDownValidateMandatory(Me.ReportingParentSubscriberId)
                    SubId = Me.ReportingParentSubscriberId.SelectedValue
            End Select
            If Me.uPage.IsValid Then
                Rep.Submit(SubId)
                ViewState("BatchJobId") = Rep.BatchJob.BatchJobId
            End If

        Catch ex As Exception
            uPage.PageError = "There was an unexpected problem generating this report.  Please contact support." & ex.ToString
        End Try

        If uPage.IsValid Then
            UpdateTimer_Tick(sender, e)
        End If
    End Sub
    Private Sub ClearBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub

    Sub BuildReportingParentSummaryGridHTML(ByVal tbl As DataTable)
        Dim rowcount As Integer = Nothing
        Try
            For Each row As DataRow In tbl.Rows
                If rowcount > 50 Then
                    Exit For
                End If
                Dim tr As New HtmlTableRow
                Dim td As New HtmlTableCell
                Dim hLink As New HyperLink
                hLink.NavigateUrl = Request.ServerVariables("Path_Info") & "?ReportType=SingleReportingParentDetail&ReportingParentSubscriberId=" & row("ReportingParentSubscriberId")
                hLink.Text = row("ReportingParentSubscriberName")
                hLink.ToolTip = "Open report for " & row("ReportingParentSubscriberName")
                td.Controls.Add(hLink)
                tr.Cells.Add(td)
                td = New HtmlTableCell
                If Not uPage.db.IsDBNull(row("UserActivitySessionCount")) Then
                    td.InnerHtml = CType(row("UserActivitySessionCount"), Decimal).ToString("#,##0")
                    td.Align = "Right"
                End If
                tr.Cells.Add(td)
                td = New HtmlTableCell
                If Not uPage.db.IsDBNull(row("AbstractCount")) Then
                    td.InnerHtml = CType(row("AbstractCount"), Decimal).ToString("#,##0")
                    td.Align = "Right"
                End If
                tr.Cells.Add(td)
                td = New HtmlTableCell
                If Not uPage.db.IsDBNull(row("ReadCount")) Then
                    td.InnerHtml = CType(row("ReadCount"), Decimal).ToString("#,##0")
                    td.Align = "Right"
                End If
                tr.Cells.Add(td)
                td = New HtmlTableCell
                If Not uPage.db.IsDBNull(row("SearchCount")) Then
                    td.InnerHtml = CType(row("SearchCount"), Decimal).ToString("#,##0")
                    td.Align = "Right"
                End If
                tr.Cells.Add(td)
                td = New HtmlTableCell
                If Not uPage.db.IsDBNull(row("RecordCount")) Then
                    td.InnerHtml = CType(row("RecordCount"), Decimal).ToString("#,##0")
                    td.Align = "Right"
                End If
                tr.Cells.Add(td)

                Me.ReportingParentSummaryTable.Rows.Add(tr)
                rowcount += 1
            Next

        Catch ex As Exception
            uPage.PageError = "There was an unexpected problem generating ReportingParent Summary Grid." & ex.ToString
        End Try
    End Sub

    Private Sub SubmitPopulatePEPUsageBtn_Click(sender As Object, e As EventArgs) Handles SubmitPopulatePEPUsageBtn.Click
        Try
            Rep.SubmitPopulatePEPUsage()
            ViewState("BatchJobId") = Rep.BatchJob.BatchJobId

        Catch ex As Exception
            uPage.PageError = "SubmitPopulatePEPUsageBtn_Click failed:" & ex.Message
        End Try
        If uPage.IsValid Then
            UpdateTimer_Tick(sender, e)
        End If
    End Sub
    Protected Sub UpdateTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateTimer.Tick
        Try
            If IsNumeric(ViewState("BatchJobId")) Then
                Me.TimedPanel.Visible = True
                Dim BatchLog As New BusinessLogic.BatchLog(uPage.db)
                Me.BatchLogLines.Text = BatchLog.GetBatchLogLinesHTML(ViewState("BatchJobId"))
                Select Case uPage.db.IsDBNull(uPage.db.DLookup("MAX(BatchLogStatus)", "BatchLog", "BatchJobId=" & ViewState("BatchJobId")), "")
                    Case "Failed"
                        Me.UpdateTimer.Enabled = False
                    Case "Complete"
                        Me.UpdateTimer.Enabled = False
                        '      Response.Redirect("pg483SubscriberImportFileLoad.aspx?SubscriberImportBatchId=" & Me.SubscriberImportBatchId.Text )
                    Case Else
                        Me.UpdateTimer.Enabled = True
                End Select
            Else
                Me.UpdateTimer.Enabled = False
                Me.TimedPanel.Visible = False
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub
End Class
