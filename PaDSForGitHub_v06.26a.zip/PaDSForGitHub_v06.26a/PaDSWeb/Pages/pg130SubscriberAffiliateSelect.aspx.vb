﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'07/02/2020    Julian Gates   Initial Version

Partial Class Pages_pg130SubscriberAffiliateSelect
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Subscriber Affiliate and List", "")
        Me.pageHeaderTitle.Text = "Subscriber Affiliate and List"

        If Page.IsPostBack Then

        Else
            If Request.QueryString("SubscriberId") <> "" Then
                Me.ParentSubscriberId.Text = Request.QueryString("SubscriberId")
                Me.SubscriberName.Text = uPage.db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & Request.QueryString("SubscriberId"))
            End If

        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        GridSetup()

    End Sub

    Sub PageSetup()
        Me.ParentSubscriberId.NavigateUrl = "../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & Me.ParentSubscriberId.Text
        Me.ParentSubscriberId.ToolTip = "View Parent Subscriber"
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub GridSetup()
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT s.SubscriberId" & sCR
            Sql += " ,s.SubscriberName" & sCR
            Sql += " ,s.EntityType " & sCR
            Sql += " ,s.SubscriberStatus" & sCR
            Sql += " ,sa.StartDate" & sCR
            Sql += " ,sa.EndDate" & sCR
            Sql += " ,sa.AffiliateReferenceId" & sCR
            Sql += " ,ps.SubscriberId AS ParentSubscriberId" & sCR
            Sql += " ,ps.SubscriberName AS ParentSubscriberName" & sCR
            Sql += " ,ps.SubscriberStatus AS ParentSubscriberStatus" & sCR
            Sql += " FROM Subscriber ps" & sCR
            Sql += "    LEFT JOIN SubscriberAffiliate sa" & sCR
            Sql += "        INNER JOIN " & uPage.SubscriberTable("s") & sCR
            Sql += "        ON s.SubscriberId = sa.ChildSubscriberId" & sCR
            Sql += "        AND s.SubscriberStatus in ('Proposed','Current')" & sCR
            Sql += "    ON sa.ParentSubscriberId = ps.SubscriberId"
            Sql += " WHERE ps.SubscriberId = " & Me.ParentSubscriberId.Text
            If Me.AccentSubscriberNameSearch.Text <> "" Then
                '17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .
                Sql += " AND CAST(s.SubscriberName AS NVARCHAR(150)) Like N'%" & Me.AccentSubscriberNameSearch.Text & "%'  COLLATE SQL_Latin1_General_CP1_CI_AI" & sCR
            End If
            Sql += " ORDER BY s.SubscriberName" & sCR

            Me.SubscriberAffiliateDatasource.SelectCommand = Sql
            Me.SubscriberAffiliateDatasource.DataBind()
            Me.SubscriberAffiliateGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Protected Sub AddNewBtn_Click(sender As Object, e As EventArgs) Handles AddNewBtn.Click
        Response.Redirect("../Pages/pg131SubscriberAffiliateMaint.aspx?PageMode=Add&ParentSubscriberId=" & Me.ParentSubscriberId.Text)
    End Sub

    Protected Sub AccentSubscriberNameSearchBtn_Click(sender As Object, e As EventArgs) Handles AccentSubscriberNameSearchBtn.Click
        Me.GridSetup()
    End Sub
    Protected Sub ClearSearchBtn_Click(sender As Object, e As EventArgs) Handles ClearSearchBtn.Click
        Response.Redirect("pg130SubscriberAffiliateSelect.aspx?SubscriberId=" & Me.ParentSubscriberId.Text)
    End Sub
    Protected Sub ExportXLSBtn_Click(sender As Object, e As EventArgs) Handles ExportXLSBtn.Click
        Try
            'Remove Update column from Export
            Me.SubscriberAffiliateGridView.Columns("ParentSubscriberId").Visible = False
            Me.SubscriberAffiliateGridExport.WriteXlsxToResponse()
        Catch ex As System.Threading.ThreadAbortException
            'do nothing, ignore
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
End Class
