﻿

DECLARE @NewDBVersion varchar(10)
DECLARE @OldDBVersion varchar(10)
DECLARE @CurrentDBVersion varchar(10)
DECLARE @SQL as varchar(8000)
DECLARE @ProcName Varchar(50)
DECLARE @ServerName varchar(100)
DECLARE @DBName varchar(100)= DB_Name()
DECLARE @Message VARCHAR(2000)
DECLARE @RowCount INT
DECLARE @v sql_variant 
DECLARE @IsAtClient BIT = 0
DECLARE @LookupId INT

IF PATINDEX('%zedra%',@@ServerName) = 0
	SET @IsAtClient = 1

SELECT @ServerName = CASE WHEN @IsAtClient = 1 THEN 'PaDS01' ELSE  @@ServerName END

DECLARE @RunningAtClient BIT = ( SELECT CASE WHEN PATINDEX('%zedra%',@ServerName)=0 THEN 1 ELSE 0 END )

SET @OldDBVersion = '2.8'
SET @NewDBVersion = '2.9'
 
IF NOT EXISTS(SELECT * FROM stblParameters WHERE ParameterName = 'DatabaseVersion') INSERT INTO stblParameters(ParameterName,ParameterType,UserID,ParameterValue) SELECT 'DatabaseVersion','System','All','01.00'  
SELECT @CurrentDBVersion = ParameterValue FROM dbo.stblParameters WHERE ParameterName = 'DatabaseVersion'
SELECT 'Current Version: ' + @CurrentDBVersion

IF NOT (@CurrentDBVersion = @OldDBVersion OR  @CurrentDBVersion = @NewDBVersion)
OR @CurrentDBVersion IS NULL
BEGIN
	SELECT 'Current DB Version ' + ISNULL(@CurrentDBVersion,'EMPTY') + ' does not match'
END
ELSE
BEGIN
BEGIN TRANSACTION 
BEGIN TRY
print 'xx'
	--SIR5391 Add InvalidFirstLastNameCharacters Param
	IF NOT EXISTS(SELECT * from stblParameters WHERE ParameterName = 'InvalidFirstLastNameCharacters')
	BEGIN
		INSERT INTO stblParameters 
		VALUES('InvalidFirstLastNameCharacters','System','All','!@#$%&*()+{}[]:"|\:/?±§~£™¢§¶•ªº≠=''',NULL,NULL)
	END

	--SIR5457  *********
	SELECT *
	INTO #AllContent
	FROM (
		SELECT
		    SourceType = 'Journal' 
			,c.PEPCode 
			,c.embargoYears 
            ,c.accessClassification
            ,c.PEPRelease
		FROM ContentJournals c
		UNION
		SELECT
		    SourceType = 'Book' 
			,c.PEPCode 
			,c.embargoYears 
            ,c.accessClassification
            ,c.PEPRelease
		FROM ContentBooks c
		UNION
		SELECT
		    SourceType = 'Video' 
			,c.PEPCode 
			,c.embargoYears 
            ,c.accessClassification
            ,c.PEPRelease
		FROM ContentVideos c
	) c

	SET @SQL ='
	USE PaDS_PEP_Usage
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name=''PEPUsage'' and c.name = ''ArchiveOrCurrent'')
	BEGIN
		
		ALTER TABLE PEPUsage ADD ArchiveOrCurrent VARCHAR(20)
		EXECUTE(''UPDATE PEPUsage 
		SET ArchiveOrCurrent = CASE 
								WHEN u.DateTime <''''22-jan-2022'''' AND u.DocumentYear>= 2021-c.embargoYears THEN ''''Current''''
								WHEN u.DateTime >=''''22-jan-2022'''' AND u.DocumentYear>= 2022-c.embargoYears THEN ''''Current''''
							ELSE ''''Archive'''' END
		FROM PEPUsage u
			INNER JOIN #AllContent c
			ON c.PEPCode = u.PEPCode '')

	END
	USE ' + @DBName 
	EXECUTE(@SQL)
--SIR5463
	SET @SQL ='
	USE PaDS_PEP_Usage
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name=''PEPUsage'' and c.name = ''ReportingParentSubscriberName'')
	BEGIN
		EXECUTE sp_rename N''dbo.PEPUsage.AffiliateRateSubscriberName'', N''Tmp_ReportingParentSubscriberName'', ''COLUMN'' 
		EXECUTE sp_rename N''dbo.PEPUsage.AffiliateRateSubscriberId'', N''Tmp_ReportingParentSubscriberId_1'', ''COLUMN'' 
		EXECUTE sp_rename N''dbo.PEPUsage.AffiliateRateType'', N''Tmp_ReportingParentType_2'', ''COLUMN'' 
		EXECUTE sp_rename N''dbo.PEPUsage.Tmp_ReportingParentSubscriberName'', N''ReportingParentSubscriberName'', ''COLUMN'' 
		EXECUTE sp_rename N''dbo.PEPUsage.Tmp_ReportingParentSubscriberId_1'', N''ReportingParentSubscriberId'', ''COLUMN'' 
		EXECUTE sp_rename N''dbo.PEPUsage.Tmp_ReportingParentType_2'', N''ReportingParentType'', ''COLUMN'' 
	END
	USE ' + @DBName 
	EXECUTE(@SQL)
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name='Subscriber' and c.name = 'IsReportingParentOverride')
	BEGIN
		ALTER TABLE Subscriber Add IsReportingParentOverride BIT 
		SET @SQL = 'UPDATE Subscriber SET IsReportingParentOverride = 1 WHERE SubscriberId In (71754 --Brazilian Psychoanalytic Society of Rio de Janeiro  (SPRJ Rio I)
																							,9494	--Societa Psicoanalitica Italiana - SPI
																							,9494	--Societa Psicoanalitica Italiana - SPI
																							,9522	--Swiss Psychoanalytical Society
																							,0)
				SELECT DISTINCT	
				o.OrderNumber 
				,o.AffiliateRateSubscriberId
				,o.AffiliateRateSubscriberName
				,o.AffiliateRateType
				INTO [PaDSTempAndArchive].[dbo].vw430SalesDetailsBackupFroAffiliateToParent
				FROM vw430SalesDetails o
					'
		EXECUTE(@SQL)

	END

	SET @SQL ='
	USE PaDS_PEP_Usage
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS WHERE Name =''PEPUsageSummary'') 
	BEGIN
		CREATE TABLE dbo.PEPUsageSummary(
			PEPUsageSummaryId INT IDENTITY(1,1),
			Year varchar(30) NULL,
			Quarter varchar(30) NULL,
			Month varchar(30) NULL,
			UserName varchar(200) NULL,
			UserFullName varchar(200) NULL,
			ReportingParentSubscriberName varchar(150) NULL,
			ReportingParentSubscriberId int NULL,
			ReportingParentType varchar(20) NULL,
			OrderNumber int NULL,
			UserCountry varchar(100) NULL,
			LoggedInMethod varchar(50) NULL,
			DocumentId varchar(50) NULL,
			documentRef varchar(200) NULL,
			PEPCode varchar(200) NULL,
			DocumentVolume varchar(200) NULL,
			DocumentYear varchar(4) NULL,
			authorMast varchar(200) NULL,
			UserActivitySessionCount int NULL,
			AbstractCount int NULL,
			ReadCount int NULL,
			SearchCount int NULL,
		 CONSTRAINT PK_PEPUsageSummary PRIMARY KEY CLUSTERED 
		(
			PEPUsageSummaryId ASC
		)
		) 
		CREATE NONCLUSTERED INDEX IX_PEPUsageSummary_Month_ReportingParentSubscriberId ON dbo.PEPUsageSummary
		(
			Month
			,ReportingParentSubscriberId
		) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

	END
	USE ' + @DBName 
	EXECUTE(@SQL)

	SET @SQL ='
	USE PaDS_Logs
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name=''UserActionLog'' and c.name = ''OrderNumber'')
	BEGIN		
		ALTER TABLE UserActionLog ADD OrderNumber INT
	END
	USE ' + @DBName 
	EXECUTE(@SQL)

--SIR5458

	UPDATE EmailDistributionLog
	SET OrderNumber=sol.OrderNumber
		,SalesOrderLineId=sol.SalesOrderLineID
	FROM EmailDistributionLog l
		INNER JOIN (	select OrderNumber=sol.OrderNumber
		,SalesOrderLineId=sol.SalesOrderLineID
		,l.EmailDistributionLogId 
	FROM (select * from EmailDistributionLog where  OrderNumber is null and EmailName like 'SalesOrder:%' and  EmailName not like '%test%') l
					INNER JOIN SalesOrderLine sol
					ON sol.OrderNumber=CAST(REPLACE(l.EmailName,'SalesOrder:','') as int)
					AND sol.SubscriberId=l.SubscriberId) sol
		ON sol.EmailDistributionLogId = l.EmailDistributionLogId 
	WHERE l.OrderNumber is null


	----**************************
	--Set New DB Version
	
	Update stblParameters
	SET ParameterValue =CAST( @NewDBVersion AS VARCHAR)
	WHERE ParameterName = 'DatabaseVersion'
	
--*************   END TRANSACTION *********************
Commit TRAN
SELECT 'Transaction Commited'
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SELECT 'Transaction Rolled Back'
	SELECT @Message = 'DBUpgrade Failed - Line:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE()
	
	RAISERROR ('%s', 18, 1,@Message)

END CATCH

END
