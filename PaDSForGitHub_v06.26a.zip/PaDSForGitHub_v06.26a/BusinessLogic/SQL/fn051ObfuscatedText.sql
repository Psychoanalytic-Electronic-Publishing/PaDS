if exists (select * from dbo.sysobjects where id = object_id(N'fn051ObfuscatedText') and xtype in (N'FN', N'IF', N'TF'))
drop function fn051ObfuscatedText
GO
CREATE FUNCTION fn051ObfuscatedText( @InText VARCHAR(MAX))
RETURNS Varchar(MAX)
AS
BEGIN
--19/5/19	James Woosnam	Initial Version
DECLARE @Out Varchar(MAX)=''

IF LEN(@InText) = 0
BEGIN
	RETURN @Out
END
DECLARE @ChrPos INT = 1

WHILE @ChrPos <= LEN(@InText)
BEGIN
	IF ASCII(SUBSTRING(@InText,@ChrPos,1)) BETWEEN 65 AND 90 
		SET @Out+='X' --Upper Case 
	ELSE
		IF ASCII(SUBSTRING(@InText,@ChrPos,1)) BETWEEN 97 AND 122 
			SET @Out+='x' --lower Case 
		ELSE
			SET @Out+=SUBSTRING(@InText,@ChrPos,1) --all other characters
	SET @ChrPos +=1
END

RETURN ( @Out)

END

GO

 