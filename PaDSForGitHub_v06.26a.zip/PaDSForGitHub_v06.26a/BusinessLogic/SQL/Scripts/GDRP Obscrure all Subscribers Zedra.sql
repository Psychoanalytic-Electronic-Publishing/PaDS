BEGIN TRAN
DECLARE 
	@DoRemove BIT = 1

DECLARE @BatchLogId INT = 0
		,@RemoveMessage VARCHAR(MAX)

select --top 5000
	s.SubscriberId 
INTO #SubsToRemove
from Subscriber s
where s.SubscriberId not in (select s2.SubscriberId  from Subscriber s2 
							where s2.SubscriberName like '%woosnam%'
							or s2.SubscriberName like '%gates%'
							)
and s.EntityType = 'Person'
and left(isnull(s.Notes,''),5) <> 'Obfus'
order by s.LastUpdatedDateTime 

IF @DoRemove =1
BEGIN
	EXEC sp028InsertBatchLog @BatchLogType= 'Remove Data',@Description='',@BatchJobId=NULL,@SubmittedByUserSessionId=NULL,@BatchLogId =@BatchLogId OUTPUT
	DECLARE @SubsciberIdToRemove INT
		,@DELETECount INT =0
		,@ObfuscateCount INT =0

	SELECT @RemoveMessage = CAST(COUNT(*) AS VARCHAR) + ' Subscibers to remove'	FROM #SubsToRemove;Print @RemoveMessage ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage

	DECLARE cur CURSOR FOR
	SELECT SubscriberId 
	FROM #SubsToRemove

	Open cur 
	FETCH cur INTO @SubsciberIdToRemove
	DECLARE @LastWrite INT = 0
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		BEGIN TRY
			EXEC sp119DeleteOrObfuscateSubscriber @SubscriberId= @SubsciberIdToRemove, @RunByUserId=1,@ReturnMessage=@RemoveMessage OUTPUT
			IF PATINDEX('%delete%',@RemoveMessage) >0 
				SET @DELETECount += 1
			ELSE
				SET @ObfuscateCount += 1
			--EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
			IF (@DELETECount + @ObfuscateCount) = 5
				OR (@DELETECount + @ObfuscateCount) >= @LastWrite + 200
			BEGIN
			SET @RemoveMessage = CAST(@DELETECount AS VARCHAR) + ' Deleted, ' + CAST(@ObfuscateCount AS VARCHAR) + ' Obfuscated So Far ';Print @RemoveMessage ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
				SET @LastWrite += 200
			END
		END TRY
		BEGIN Catch
			SET @RemoveMessage = 'Remove For SubscriberId:' + CAST(@SubsciberIdToRemove AS VARCHAR) + ' failed:' + ERROR_MESSAGE();Print @RemoveMessage ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
		END Catch

		FETCH cur INTO @SubsciberIdToRemove
	END
		SET @RemoveMessage = CAST(@DELETECount AS VARCHAR) + ' Deleted in total';Print @RemoveMessage ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
		SET @RemoveMessage = CAST(@ObfuscateCount AS VARCHAR) + ' Obfuscated in total';Print @RemoveMessage ;EXEC sp029UpdateBatchLog @BatchLogId,@RemoveMessage
		EXEC sp029UpdateBatchLog @BatchLogId,'Complete','Complete'

	CLOSE cur 
	DEALLOCATE cur 
END




--select * from #Subs 
--order by SubscriberId 

DROP TABLE #SubsToRemove


select b.BatchLogId 
	,l.DateTime 
	,l.BatchLogLineText 
from BatchLog b
	left join BatchLogLine l
	on l.BatchLogId = b.BatchLogId 
where b.BatchlogId = @BatchLogId 
order by l.DateTime 
commit TRAN




 