IF  exists (select * from dbo.sysobjects where id = object_id(N'sp457GetPEPUsageView') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp457GetPEPUsageView 
GO
CREATE  PROCEDURE sp457GetPEPUsageView (
					@StartMonth VARCHAR(20) = '2021-09 Sep'
					,@EndMonth VARCHAR(20) = '4949-12 Dec'
					,@ViewType VARCHAR(50) = 'SummaryByReportingParent'
					,@ReportingParentSubscriberId INT = NULL --American Psychological Association - Division 39
)
AS
--16/3/22	James Woosnam	SIR5457 - Add ArchiveOrCurrent
--21/3/22	James Woosnam	SIR5463 - Remove By Day grouping
--21/3/22	James Woosnam	SIR5463 - Change AffiliateRateSubscriber to ReportingParentSubscriber
DECLARE @Message VARCHAR(MAX) = ''

IF @ViewType = 'SummaryByReportingParent'
BEGIN
	SELECT
		u.ReportingParentSubscriberId 
		,u.ReportingParentSubscriberName
		,UserActivitySessionCount = ISNULL(sum(u.UserActivitySessionCount ),0)
		,AbstractCount = ISNULL(SUM(u.AbstractCount),0)
		,ReadCount = ISNULL(SUM(u.ReadCount),0)
		,SearchCount = ISNULL(SUM(u.SearchCount),0)
		,TurnAwayCount = ISNULL(SUM(u.TurnAwayCount),0) --27/11/21	James	SIR5374 - Add TurnAwayCount
		,RecordCount = COUNT(*)
	FROM PEPUsageSummary u
	WHERE u.Month BETWEEN @StartMonth AND @EndMonth 
	GROUP BY
		u.ReportingParentSubscriberId
		,u.ReportingParentSubscriberName 
	ORDER BY 
		ISNULL(SUM(u.ReadCount),0) desc
		,u.ReportingParentSubscriberName 
END

IF @ViewType = 'DetailByReportingParent'
BEGIN
	SELECT
		ReportingParentSubscriberName
		,ReportingParentSubscriberId
		,ReportingParentType
		,LoggedInMethod
--		,DateDay
		,Year
		,Quarter
		,Month
		,UserCountry
		,PEPCode
		,DocumentVolume
		,DocumentYear
		,ArchiveOrCurrent--16/3/22	James Woosnam	SIR5457 - Add ArchiveOrCurrent
		--,authorMast
		--,DocumentId
		--,documentRef		
		,UserActivitySessionCount = ISNULL(sum(u.UserActivitySessionCount ),0)
		,AbstractCount = ISNULL(SUM(u.AbstractCount),0)
		,ReadCount = ISNULL(SUM(u.ReadCount),0)
		,SearchCount = ISNULL(SUM(u.SearchCount),0)
		,TurnAwayCount = ISNULL(SUM(u.TurnAwayCount),0) --27/11/21	James	SIR5374 - Add TurnAwayCount
	FROM PEPUsageSummary u
	WHERE u.Month BETWEEN @StartMonth AND @EndMonth 
	GROUP BY
		ReportingParentSubscriberName
		,ReportingParentSubscriberId
		,ReportingParentType
		,LoggedInMethod
--		,DateDay
		,Year
		,Quarter
		,Month
		,UserCountry
		,PEPCode
		,DocumentVolume
		,DocumentYear
		,ArchiveOrCurrent--16/3/22	James Woosnam	SIR5457 - Add ArchiveOrCurrent
		--,authorMast
		--,DocumentId
		--,documentRef	
	ORDER BY 
		ReportingParentSubscriberName 
		--,DateDay
		,PEPCode
END
IF @ViewType = 'SingleReportingParentDetail'
BEGIN
	IF @ReportingParentSubscriberId IS NULL 
	BEGIN
		SELECT @Message ='ViewType:' + @ViewType + ' requires @ReportingParentSubscriberId'
		RAISERROR ('%s', 18, 1,@Message)
	END
	SELECT
		ReportingParentSubscriberName
		,ReportingParentSubscriberId
		,ReportingParentType
		,UserName
		,UserFullName
--		,DateDay
		,Year
		,Quarter
		,Month
		,OrderNumber
		,UserCountry
		,LoggedInMethod
		,DocumentId
		,documentRef
		,PEPCode
		,DocumentVolume
		,DocumentYear
		,authorMast
		,ArchiveOrCurrent--16/3/22	James Woosnam	SIR5457 - Add ArchiveOrCurrent
		,UserActivitySessionCount = ISNULL(sum(u.UserActivitySessionCount ),0)
		,AbstractCount = ISNULL(SUM(u.AbstractCount),0)
		,ReadCount = ISNULL(SUM(u.ReadCount),0)
		,SearchCount = ISNULL(SUM(u.SearchCount),0)
		,TurnAwayCount = ISNULL(SUM(u.TurnAwayCount),0) --27/11/21	James	SIR5374 - Add TurnAwayCount
	FROM PEPUsageSummary u
	WHERE u.Month BETWEEN @StartMonth AND @EndMonth 
	AND u.ReportingParentSubscriberId = @ReportingParentSubscriberId
	GROUP BY
		ReportingParentSubscriberName
		,ReportingParentSubscriberId
		,ReportingParentType
		,UserName
		,UserFullName
--		,DateDay
		,Year
		,Quarter
		,Month
		,OrderNumber
		,UserCountry
		,LoggedInMethod
		,DocumentId
		,documentRef
		,PEPCode
		,DocumentVolume
		,DocumentYear
		,authorMast
		,ArchiveOrCurrent--16/3/22	James Woosnam	SIR5457 - Add ArchiveOrCurrent
	ORDER BY 
		ReportingParentSubscriberName 
		,UserFullName 
END
GO
GRANT  EXECUTE ON sp457GetPEPUsageView TO PaDSSQLServerUser

--EXEC sp457GetPEPUsageView @ViewType = 'SummaryByReportingParent'
--EXEC sp457GetPEPUsageView @ViewType = 'DetailByReportingParent'
--EXEC sp457GetPEPUsageView @ViewType = 'SingleReportingParentDetail'	,@ReportingParentSubscriberId=49337