if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp160BatchLogList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].sp160BatchLogList
GO

CREATE  PROCEDURE sp160BatchLogList (
				@FltrBatchLogType VARCHAR(20)= ''
				,@FltrDescription VARCHAR(50)= ''
				,@FltrBatchLogStatus VARCHAR(20)= ''
				,@FltrUserName VARCHAR(50)= ''
				,@RecordsRequired INT   = 1000 	--Number of recods to return
				,@ReturnTotalRecordCount INT = 0 --1 if we need to count all records
				)
AS
-- =============================================
-- Author:		Julian Gates
-- Create date: 18 Feb 2011
-- Description:	GetsBatchLogList
-- Modification History
-- 12/03/21	Julian Gates	Add UserSession Join and Username filter
-- 21/04/22 Julian Gates	Update @RecordsRequired to 1000 from 50
-- =============================================
set nocount on
set arithignore on
DECLARE @ReturnError INT
DECLARE @From VARCHAR(2000)
DECLARE @Where VARCHAR(2000)
DECLARE @Columns VARCHAR(2000)
DECLARE @SQL VARCHAR(4000)
DECLARE @LF Varchar(5)
DECLARE @Records INT
DECLARE @RecordCount INT

SET @LF = CHAR(13) + CHAR(10)
SET @Where ='WHERE 1=1'

-- Filter on paramaters, if passed in
If ISNULL(@FltrBatchLogType	,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND BatchLog.BatchLogType = ''' + @FltrBatchLogType + '''' + @LF
END	

If ISNULL(@FltrDescription	,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND BatchLog.Description Like ''' + @FltrDescription + '''' + @LF
END	

If ISNULL(@FltrBatchLogStatus	,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND BatchLog.BatchLogStatus = ''' + @FltrBatchLogStatus + '''' + @LF
END	

If ISNULL(@FltrUserName	,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND us.UserName Like ''' + @FltrUserName + '''' + @LF
END	

SET @From = '		
	FROM BatchLog 
	LEFT JOIN UserSession us     
		ON us.UserSessionId = BatchLog.SubmittedByUserSessionId ' 
	+ @Where

IF @ReturnTotalRecordCount = 1
BEGIN
	--Count records into Temp table
	CREATE TABLE #RecordCount(RecordCount INT)

	SET @SQL = '
	INSERT INTO #RecordCount
	SELECT (SELECT Count1=COUNT(*)  

				FROM (Select 1 Num ' + @From + ') ResultSet)
	'			
	execute (@SQL)
	SELECT @RecordCount = RecordCount
	FROM #RecordCount
END
ELSE
BEGIN
	SELECT @RecordCount = -1
END
Print 100
Print @SQL
--select columns to show
SELECT @Columns = '
	SELECT Distinct Top '  + CAST(@RecordsRequired as VARCHAR) + '
		TotalRecordCount = ' + CAST(@RecordCount as VARCHAR) 

		
SET @Columns = @Columns + '
		,BatchLogId 
		,BatchLogType 
		,Description 
		,BatchLogStatus 
		,DateTime
		,SubmittedByUserSessionId 
		,EndDateTime
		,us.UserId
		,us.UserName
'

SET @From = @From + '
		ORDER BY BatchLogId DESC'

--Now Run the query
SET @SQL =  @Columns
			+ @From
print @SQL
execute (@SQL)
SELECT @ReturnError = @@Error, @Records= @@ROWCOUNT 
IF @ReturnError <> 0
BEGIN
	SELECT ReturnError=@ReturnError
		,ReturnMessage=master..sysmessages.description 
		from master..sysmessages where error=@returnerror
	RETURN
END	
set nocount off
set arithignore off

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO