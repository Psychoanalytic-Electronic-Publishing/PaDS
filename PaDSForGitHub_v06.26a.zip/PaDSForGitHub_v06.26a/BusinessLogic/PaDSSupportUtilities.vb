﻿'Modifications
'============
'Mar 2014   James Woosnam   Initial Version
'25/3/14    James Wosonam   SIR3483 - Add support for PaDSDatabaseBackups
'26/9/16    James Woosnam   SIR4184 - Add ExecuteCopyECHOLiveDBsToECHOTest and associated subs/fucntions
'29/9/16    Julian Gates    Add Subs ReBuildPaDSTableIndexes and ReBuildECHOwebTableIndexes
'12/1/18    James Woosnam   SIR4293 - ExecuteCopyECHOLiveDBsToECHOTest Ad option to use selected snapshot as basis for test
'25/5/18    James Woosnam   SIR4634 - Change CopyPaDSDatabaseToSecondary to do incremental backups and leave some old backup DBs.
'24/03/20	Julian Gates    SIR5049 - Add ReBuildPaDSTableIndexes
'22/02/21   Julian Gates    Add PEPWebSessionLog to copy
'11/03/21   Julian Gates    Add UserActionLog to copy
'7/7/21     James Woosnam   SIR5280 - Only restore the full backup and the last incremental backup in RestoreDatabaseForCopyToSecondary
'20/12/21   James Woosnam   SIR5355 - RunAuditAndCleanUpJobs - Put processing into sp045RunAuditAndCleanUpJobs
'08/04/22   Julian Gates    SIR5478 - Change CheckFreeDiskSpace to check all DBs on Pads01 and Pads02 using SQL dB query.

Imports System.Data
Imports System.IO
Imports System.Data.SqlClient
Public Class PaDSSupportUtilities
    Dim BatchJobId As Integer = Nothing
    Dim Logfile As LogFile = Nothing
    Dim BatchLog As BatchLog = Nothing

    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property

    Dim StartUpPath As String = Nothing

    Sub New(ByVal db As Database)
        Me.db = db
    End Sub
    Public Sub TidyBackupDirectory(DBNameToBackup As String,
                                       BackupDirUNCName As String,
                                       DatabaseBackupRetentionDays As Integer,
                                        ByRef DebugInfo As String
                                   )
        Dim dirName As String = Nothing
        Try
            dirName = IO.Path.GetDirectoryName(IO.Path.Combine(BackupDirUNCName, "xx.xxx"))
            Dim fileCount As Integer = Nothing
            For Each file As IO.FileInfo In New IO.DirectoryInfo(dirName).GetFiles()
                If file.CreationTime < Now.AddDays(DatabaseBackupRetentionDays * -1) And file.Name.ToLower.Contains(DBNameToBackup.ToLower) Then
                    file.Delete()
                    fileCount += 1
                    DebugInfo += "Old Backup File:" & file.Name & " Deleted" & vbCrLf
                End If
            Next
            DebugInfo += "Deleted " & fileCount & " files from:" & dirName & vbCrLf
        Catch ex As Exception
            DebugInfo += "FAILED delete old backup files from:" & dirName & " Error:" & ex.Message
        End Try
    End Sub
    Private Function GetDefaultSQLBackupDirectory() As String
        Dim sql As String
        sql = "exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'BackupDirectory'"
        Return db.GetDataTableFromSQL(sql).Rows(0)("Data").ToString.ToLower ' For ECHOweb use "C:\ECHOweb\Backups"
    End Function
    Enum BackupTypes
        Full
        Diff
    End Enum
    Public Sub BackupDatabase(DBNameToBackup As String,
                                  ByRef DebugInfo As String,
                                   SQLBackupDir As String,
                                   Optional ByRef BackupFileName As String = Nothing,
                                   Optional IsCopyBackup As Boolean = False,
                                  Optional BackupType As BackupTypes = BackupTypes.Full)
        Try
            'CopyFromUNCDirName = \\10.10.10.250\Backups\  DatabaseBackupRetentionDays
            Try
                '24/5/17    James Woosnam   Timeout set to parameter value or 2400 if missing
                db.CommandTimeout = db.GetParameterValue("DBCommandTimeoutForDBBackup") '13/9/15  set timout to 20 miuntes
            Catch ex As Exception
                DebugInfo += "Error:" & ex.Message & " CommandTimeout in BackupDatabase set to 2400 secs" & vbCrLf
                db.CommandTimeout = 2400
            End Try
            'get backup DIR
            Dim sql As String = ""
            If SQLBackupDir = Nothing Then SQLBackupDir = GetDefaultSQLBackupDirectory()

            Dim SQLInstanceName As String = db.GetDataTableFromSQL("select @@SERVERNAME").Rows(0)(0)
            If BackupFileName Is Nothing Then
                BackupFileName = DBNameToBackup & Now().ToString("yyyy_MM_dd_HHmm") & ".bak"
            End If
            sql = "BACKUP DATABASE " & DBNameToBackup
            sql += " TO  DISK = N'" & IO.Path.Combine(SQLBackupDir, BackupFileName) & "'"
            sql += " WITH NOFORMAT, INIT,  NAME = N'" & DBNameToBackup & " " & BackupType.ToString & " Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10"
            If IsCopyBackup Then
                sql += ", COPY_ONLY"
            End If
            Select Case BackupType
                Case BackupTypes.Diff
                    sql += ", DIFFERENTIAL"
            End Select
            DebugInfo += "Backup SQL:" & vbCrLf & sql & vbCrLf

            Me.db.ExecuteSQL(sql)
            DebugInfo += vbCrLf
            DebugInfo += "DB Backup Succeeded" & vbCrLf
            DebugInfo += vbCrLf


        Catch ex As Exception
            Throw New Exception("BackupDatabase Failed:" & ex.Message & vbCrLf & "DEBUG INFO" & vbCrLf & DebugInfo)
        End Try
    End Sub
    Public Sub RestoreDatabaseForCopyToSecondary(SourceDBName As String,
                                   TargetDBName As String,
                                  ByRef DebugInfo As String,
                                   BackupFileNameTemplate As String,
                                   SecondaryDatabaseBackupDirectory As IO.DirectoryInfo,
                                   TransferBackupNo As Integer)
        'Assumptions: The source database logical file name must be the same as the DB name and the log file must be the database name _log 
        Try
            DebugInfo += vbCrLf
            db.CommandTimeout = 1200 '13/9/15  set timout to 20 miuntes
            'get backup DIR
            Dim sql As String = ""

            sql = "USE MASTER" & vbCrLf
            sql += "IF EXISTS(select name from sysdatabases where name='" & TargetDBName & "') ALTER Database " & TargetDBName & " SET SINGLE_USER WITH ROLLBACK IMMEDIATE" & vbCrLf
            sql += "DECLARE @DataFile VARCHAR(500) = CAST((select serverproperty('InstanceDefaultDataPath'))  AS VARCHAR(500)) + '" & TargetDBName & ".mdf'" & vbCrLf
            sql += "Declare @LogFile VARCHAR(500) = CAST((select serverproperty('InstanceDefaultLogPath'))  AS VARCHAR(500)) + '" & TargetDBName & ".ldf'" & vbCrLf
            For backupNo As Integer = 0 To TransferBackupNo
                '7/7/21     James Woosnam   SIR5280 - Only restore the full backup and the last incremental backup in RestoreDatabaseForCopyToSecondary
                '27/07/21   James Woosnam   SIR5280 - Because of the 7/7/21 change, only the full & 1 diff files are require which saves lots of diskspace. 
                If backupNo <> TransferBackupNo And backupNo <> 0 Then
                    DebugInfo += "Skipped #" & backupNo & ", "
                Else
                    Dim SQLBackupFile As New IO.FileInfo(IO.Path.Combine(SecondaryDatabaseBackupDirectory.FullName,
                                                                        BackupFileNameTemplate.Replace("TYPE", IIf(backupNo = 0, "Full", "Diff"))))
                    Select Case backupNo
                        Case 0
                            sql += "RESTORE DATABASE " & TargetDBName & " FROM  DISK = '" & SQLBackupFile.FullName & "'" & vbCrLf
                            sql += "  With FILE = 1" & vbCrLf
                            sql += "	,MOVE '" & SourceDBName & "' TO @DataFile" & vbCrLf
                            sql += "	,MOVE '" & SourceDBName & "_log' TO @LogFile" & vbCrLf
                            sql += "	,NOUNLOAD"
                            sql += ",STATS = 10"
                        Case Else
                            sql += "RESTORE DATABASE " & TargetDBName & " FROM  DISK = '" & SQLBackupFile.FullName & "'" & vbCrLf
                            sql += "  With FILE = 1"
                            sql += ",NOUNLOAD"
                            sql += ",STATS = 5"

                    End Select
                    If backupNo <> TransferBackupNo Then
                        sql += ",NORECOVERY"
                    End If
                    sql += vbCrLf
                End If

            Next

            DebugInfo += "Restore SQL:" & vbCrLf & sql & vbCrLf

            Me.db.ExecuteSQL(sql)
            DebugInfo += vbCrLf
            DebugInfo += "DB Restore Succeeded" & vbCrLf
            DebugInfo += vbCrLf
            If SourceDBName <> TargetDBName Then
                sql = "ALTER DATABASE " & TargetDBName & " MODIFY FILE (NAME = " & SourceDBName & " ,NEWNAME= " & TargetDBName & ")" & vbCrLf
                sql += "ALTER DATABASE " & TargetDBName & " MODIFY FILE (NAME = " & SourceDBName & "_Log ,NEWNAME= " & TargetDBName & "_Log)" & vbCrLf '30/9/06 JW Rename log file
            End If
            sql += "ALTER Database " & TargetDBName & " SET MULTI_USER" & vbCrLf
            sql += "USE " & TargetDBName & vbCrLf
            DebugInfo += "Post Restore tidyup SQL:" & vbCrLf & sql & vbCrLf

            Me.db.ExecuteSQL(sql)
            DebugInfo += "Post Restore tidyup Succeeded"


        Catch ex As Exception
            Throw New Exception("RestoreDatabaseForCopyLiveToTest Failed:" & ex.Message & vbCrLf & "DEBUG INFO" & vbCrLf & DebugInfo)
        End Try
    End Sub
    Public Sub SubmitPaDSDatabaseBackups()

        Dim batchjob As New BusinessLogic.BatchJob(Me.db)

        batchjob.CreateBatchJobEntry("PaDSDatabaseBackups", Me.db)

    End Sub
    Public Sub ExecutePaDSDatabaseBackups()
        Dim BatchLog As New BatchLog("PaDSDatabaseBackups" _
                                    , "PaDSDatabaseBackups" _
                                    , Me.db)
        '20/4/15    James Wosonam   Move UNC DIR name to parameter, tidy up copde, zip ECHO and ECHOweb DB backups, using ionic.zip, and copy to copy DIR
        Dim msg As String = ""
        Dim AtLEastOneFailureOccured As Boolean = False
        Try
            Dim DatabaseBackupRetentionDays As Integer = db.GetParameterValue("DatabaseBackupRetentionDays")
            BatchLog.Update("DatabaseBackupRetentionDays=" & DatabaseBackupRetentionDays)
            Dim SQLBackupDir As String = db.GetParameterValue("DatabaseBackupDirectory") ' this will error if not present
            Dim SQLBackupDirUNC As String = db.GetParameterValue("DatabaseBackupDirectoryUNC")
            Dim SQKBackupCopyToDirUNC As String = db.GetParameterValue("DatabaseBackupCopyToDir")
            Dim DBNameToBackup As String = Nothing
            Try
                BatchLog.Update("ECHOConenction:" & Me.db.DBConnection.ToString)

                Dim SuppUtlisECHO As New BusinessLogic.PaDSSupportUtilities(db)
                '12/10/16   James Woosnam   SIR4241 - BackupFileName must be nothing otherwise it doesn't get set in BackupDatabase
                Dim BackupFileName As String = Nothing
                Try
                    DBNameToBackup = db.DBConnection.Database
                    msg = ""
                    SuppUtlisECHO.BackupDatabase(DBNameToBackup, msg, SQLBackupDir, BackupFileName)
                    SuppUtlisECHO.TidyBackupDirectory(DBNameToBackup, SQLBackupDirUNC, DatabaseBackupRetentionDays, msg)
                    BatchLog.Update(DBNameToBackup & " Backup Complete." & vbCrLf & msg)
                Catch ex As Exception
                    BatchLog.Update(DBNameToBackup & " Backup Failed:" & ex.Message)
                    AtLEastOneFailureOccured = True
                End Try

                Try
                    'try to zip backup file and copy to ECHO directory
                    'Open the zip file if it exists, else create a new one 
                    Dim zipFileName As String = IO.Path.Combine(SQLBackupDirUNC, BackupFileName.Replace(".bak", ".zip"))
                    'Dim zip As System.IO.Packaging.Package = System.IO.Packaging.ZipPackage.Open(zipFileName, IO.FileMode.OpenOrCreate, IO.FileAccess.ReadWrite)
                    Using zip As Ionic.Zip.ZipFile = New Ionic.Zip.ZipFile()
                        '9/3/16     James Woosnam   Update UseZip64WhenSaving as save was failing
                        zip.UseZip64WhenSaving = Ionic.Zip.Zip64Option.Always
                        zip.AddFile(IO.Path.Combine(SQLBackupDirUNC, BackupFileName))
                        zip.Save(zipFileName)
                    End Using

                    BatchLog.Update(DBNameToBackup & " zip creation Complete.")
                    Try
                        IO.File.Move(zipFileName, IO.Path.Combine(SQKBackupCopyToDirUNC, IO.Path.GetFileName(zipFileName)))
                    Catch ex As Exception
                        Throw New Exception("Move zip file failed:" & ex.Message)
                    End Try
                    msg = ""
                    SuppUtlisECHO.TidyBackupDirectory(DBNameToBackup, SQKBackupCopyToDirUNC, 1, msg)
                    BatchLog.Update(DBNameToBackup & " move zip file to " & SQKBackupCopyToDirUNC & " Complete." & vbCrLf & msg)
                Catch ex As Exception
                    BatchLog.Update(DBNameToBackup & " zip and move Backup Failed:" & ex.Message)
                    AtLEastOneFailureOccured = True
                End Try
                Try
                    msg = ""
                    DBNameToBackup = db.GetParameterValue("DatamartDBName")
                    SuppUtlisECHO.BackupDatabase(DBNameToBackup, msg, SQLBackupDir)
                    SuppUtlisECHO.TidyBackupDirectory(DBNameToBackup, SQLBackupDirUNC, DatabaseBackupRetentionDays, msg)
                    BatchLog.Update(DBNameToBackup & " Backup Complete." & vbCrLf & msg)
                Catch ex As Exception
                    BatchLog.Update(DBNameToBackup & " Backup Failed:" & ex.Message)
                    AtLEastOneFailureOccured = True
                End Try
                Try
                    msg = ""
                    DBNameToBackup = "ECHO_Audit"
                    SuppUtlisECHO.BackupDatabase(DBNameToBackup, msg, SQLBackupDir)
                    '12/4/17    James Woosnam   Do tidy after backup as there is now space to have 2 audit backs at the same time.
                    SuppUtlisECHO.TidyBackupDirectory(DBNameToBackup, SQLBackupDirUNC, 1, msg)
                    BatchLog.Update(DBNameToBackup & " Backup Complete." & vbCrLf & msg)
                Catch ex As Exception
                    BatchLog.Update(DBNameToBackup & " Backup Failed:" & ex.Message)
                    AtLEastOneFailureOccured = True
                End Try
            Catch ex As Exception
                Throw ex
            End Try



            If AtLEastOneFailureOccured Then
                BatchLog.Update("At least one failure occured see eariler batchlog.", "Failed")
                Throw New Exception("AtLEastOneFailureOccured")
            Else
                BatchLog.Update("All Backups Complete", "Complete")
            End If

        Catch ex As Exception
            BatchLog.Update("Backup Failed:" & ex.Message, "Failed")
            Try
                Dim em As New BusinessLogic.Email(db)
                em.SendErrorEmail("ECHO BACKUPS Failed", "Error:" & ex.Message & Environment.NewLine & BatchLog.GetBatchLogLinesAsText)
            Catch ex1 As Exception
            End Try
            Throw New Exception("**ECHO BACKUPS Failed - See bacth log for more details:" & ex.Message)
        End Try
    End Sub
    Public Sub ProcessSQLFile(FileName As String)
        Me.ProcessSQLFile(FileName, db)
    End Sub
    Public Sub ProcessSQLFile(FileName As String, dbToUse As Database)
        Try
            Dim dbSQL As String = ""
            Dim fileReader As System.IO.StreamReader = System.IO.File.OpenText(FileName)
            Try
                Dim sqlLine As String = Nothing
                Dim sqlBit As String = Nothing
                Dim SQLSectionNo As Integer = 1
                sqlLine = fileReader.ReadLine

                Do While sqlLine IsNot Nothing
                    Dim GOFound As Boolean = False
                    If sqlLine.Length >= 2 Then
                        If sqlLine.Substring(0, 2).ToUpper = "GO" Then
                            GOFound = True
                        End If
                    End If
                    If GOFound Then
                        Try
                            dbToUse.ExecuteSQL(sqlBit)
                        Catch ex As Exception
                            Throw New Exception("ProcessSQLFile failed:" & ex.Message & " SQLSection:" & SQLSectionNo & " Begins:" & Left(sqlBit, 10))
                        End Try
                        sqlBit = Nothing
                        SQLSectionNo += 1
                    Else
                        sqlBit += sqlLine & vbCrLf
                    End If
                    sqlLine = fileReader.ReadLine
                Loop
                If sqlBit IsNot Nothing Then
                    Try
                        db.ExecuteSQL(sqlBit)
                    Catch ex As Exception
                        Throw New Exception("ProcessSQLFile failed:" & ex.Message & " SQLSection:" & SQLSectionNo & " Begins:" & Left(sqlBit, 10))
                    End Try
                End If

            Catch ex As Exception
                Throw ex
            Finally
                fileReader.Close()
            End Try


        Catch ex As Exception
            Throw New Exception("SQLFile:" & IO.Path.GetFileNameWithoutExtension(FileName) & " Failed.  " & ex.Message)
        End Try

    End Sub
    Sub RunDatabaseSQL(DatabaseSQLDirectory As String, ByRef Messages As String, ByRef ErrorMessage As String)
        Try
            Dim inFile As System.IO.StreamReader = New System.IO.StreamReader(IO.Path.Combine(DatabaseSQLDirectory, "install.bat"))
            Dim line As String
            Try
                Dim baseDBName As String = db.DBConnection.Database.ToUpper
                line = inFile.ReadLine
                Do While Not line Is Nothing
                    Dim fileName As String = ""
                    Try

                        Dim linePrefix As String = "osql -E -d %2 -S %1 -i %3"
                        If line.Length > linePrefix.Length Then
                            If line.Substring(0, linePrefix.Length) = linePrefix Then
                                fileName = line.Substring(linePrefix.Length, line.Length - linePrefix.Length)
                            End If
                        End If
                        If fileName <> "" Then
                            Me.ProcessSQLFile(IO.Path.Combine(DatabaseSQLDirectory, fileName))
                            Messages += "SQL File:" & fileName & " Complete" & vbCrLf
                        End If
                    Catch ex As Exception
                        Messages += "SQL File:" & fileName & " Failed:" & ex.Message & ". Processing continued" & vbCrLf
                        ErrorMessage += "SQL File:" & fileName & " Failed:" & ex.Message & "  Processing continued" & vbCrLf
                    End Try
                    line = inFile.ReadLine
                Loop

            Catch ex As Exception
                Throw ex
            Finally
                'close the file eben if there is an error
                inFile.Close()
            End Try
        Catch ex As Exception
            Throw New Exception("RunDatabaseSQL Failed:" & ex.Message)
        End Try
    End Sub

    '24/03/20	Julian Gates SIR5049 - Add ReBuildPaDSTableIndexes
    Public Sub ReBuildPaDSTableIndexes(BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.ReBuildPaDSTableIndexes(Parameters.GetValue("DBName"))
    End Sub

    Public Sub ReBuildPaDSTableIndexes(DBName As String)
        Dim batchLog As New BatchLog("ReBuildPaDSTableIndexes", "@DBName=" & DBName & ", @ServerName=" & Me.db.DBConnection.DataSource, Me.db, Me.BatchJobId)

        Try
            Dim cmd As New SqlCommand("sp006RebuildIndexes", db.DBConnection, db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandTimeout = 36000
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DBName", System.Data.SqlDbType.VarChar, 100, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, DBName))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LogMessage", System.Data.SqlDbType.VarChar, -1, ParameterDirection.Output, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, ""))
            cmd.ExecuteNonQuery()
            Try
                batchLog.Update(cmd.Parameters("@LogMessage").Value)
            Catch ex As Exception
                Throw ex
            End Try
            batchLog.Update("sp006RebuildIndexes Complete", "Complete")

        Catch ex As Exception
            batchLog.Update(ex.ToString, "Failed")
            Throw New Exception(ex.ToString)
        End Try

    End Sub
    Public Sub RunAuditAndCleanUpJobs(BatchJobId As Integer)
        Me.BatchJobId = BatchJobId
        '5/12/19    James Woosnam   SIR4769 - Add RunAuditAndCleanUpJobs
        '22/2/21    James Woosnam   Commented out PEPWebUsageLog clean up as needed for Counter 
        '20/12/21   James Woosnam   SIR5355 - RunAuditAndCleanUpJobs - Put processing into sp045RunAuditAndCleanUpJobs
        '9/2/22     James Woosnam   SIR5432 - SessionLog moved to own DB
        Dim sql As String = ""
        Dim batchLog As New BatchLog("RunAuditAndCleanUpJobs", "", Me.db, Me.BatchJobId)
        Try
            Dim cmd As New SqlCommand("sp045RunAuditAndCleanUpJobs", db.DBConnection, db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandTimeout = 36000
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchLogId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, batchLog.BatchLogId))
            cmd.ExecuteNonQuery()
            '25/1/22    James Woosnam   Shrink DB file after clear out to maintain 10GB limit
            Dim dbName As String = db.DBConnection.Database
            Try
                Dim ShrinkLogFileToGB As Integer = db.GetParameterValue("ShrinkLogFileToGB", 8)
                db.ExecuteSQL("USE PaDS_Logs")
                Dim fileName As String = db.GetDataTableFromSQL("SELECT FileName=file_name(1)").Rows(0)(0)
                sql = "
	USE PaDS_Logs
	DBCC SHRINKFILE (N'" & fileName & "' , " & ShrinkLogFileToGB & "000)
     "
                db.ExecuteSQL(sql)
                batchLog.Update("PaDS_Log DB File shrunk to GB:" & ShrinkLogFileToGB)
            Catch ex As Exception
                batchLog.Update("PaDS_Log DB File shrink failed:" & ex.Message & " SQL:" & sql)
            Finally
                db.ExecuteSQL("USE " & dbName)
            End Try

            '9/2/22 James   SIR5432 - SessionLog moved to own DB
            Try
                Dim ShrinkLogFileToGB As Integer = db.GetParameterValue("ShrinkLogFileToGB", 8)
                db.ExecuteSQL("USE PaDS_SessionLog")
                Dim fileName As String = db.GetDataTableFromSQL("SELECT FileName=file_name(1)").Rows(0)(0)
                sql = "
	USE PaDS_SessionLog
	DBCC SHRINKFILE (N'" & fileName & "' , " & ShrinkLogFileToGB & "000)
     "
                db.ExecuteSQL(sql)
                batchLog.Update("PaDS_SessionLog DB File shrunk to GB:" & ShrinkLogFileToGB)
            Catch ex As Exception
                batchLog.Update("PaDS_SessionLog DB File shrink failed:" & ex.Message & " SQL:" & sql)
            Finally
                db.ExecuteSQL("USE " & dbName)
            End Try
            batchLog.Update("Complete", "Complete")

        Catch ex As Exception
            Dim sMsg As String = ex.Message & System.Environment.NewLine & sql
            batchLog.Update(sMsg, "Failed")
            Try
                Dim em As New Email(db)
                em.SendErrorEmail("RunAuditAndCleanUpJobs Failed", sMsg)
            Catch ex1 As Exception
            End Try
            Throw New Exception("RunAuditAndCleanUpJobs Failed:" & sMsg, ex)
        End Try
    End Sub
    Public Sub CopyPaDSDatabaseToSecondary(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId

        Me.CopyPaDSDatabaseToSecondary(Parameters.GetValue("SecondaryConnectionString"))
    End Sub


    Public Sub CopyPaDSDatabaseToSecondary(SecondaryConnectionString As String)
        '22/5/18    James Woosnam   SIR4634 - Change CopyPaDSDatabaseToSecondary so that only the main DB is copied every hour and only copy the new PaDS_Log records
        '25/5/18    James Woosnam   SIR4634 - Change CopyPaDSDatabaseToSecondary to do incremental backups and leave some old backup DBs.
        '22/02/21   Julian Gates    Add PEPWebSessionLog to copy
        Dim msg As String = ""
        Dim ErrMsg As String = ""
        Dim sql As String = ""
        Dim batchLog As New BatchLog("CopyPaDSDatabaseToSecondary", "", Me.db, Me.BatchJobId)
        Try
            Dim IsInFailover As Boolean = False
            Try
                Dim FailoverThisIsMasterServer As String = db.GetParameterValue("FailoverThisIsMasterServer")
                IsInFailover = CBool(FailoverThisIsMasterServer)
                If IsInFailover Then
                    Throw New Exception("Server is in failover, this job can't be run")
                End If
            Catch ex As Exception
            End Try
            Dim PrimaryDatabaseBackupDirectory As String = db.GetParameterValue("PrimaryDatabaseBackupDirectory") ' this will error if not present
            Dim PrimaryDatabaseBackupDirectoryUNC As String = db.GetParameterValue("PrimaryDatabaseBackupDirectoryUNC") ' this will error if not present
            Dim SecondaryDatabaseBackupDirectory As String = db.GetParameterValue("SecondaryDatabaseBackupDirectory") ' this will error if not present
            Dim SecondaryDatabaseBackupDirectoryUNC As String = db.GetParameterValue("SecondaryDatabaseBackupDirectoryUNC") ' this will error if not present
            Dim SQLFileDirectory As String = db.GetParameterValue("SQLFileDirectory") ' this will error if not present
            Dim dbSecondary As New Database(SecondaryConnectionString)
            Dim UtilsOnSecondary As New PaDSSupportUtilities(dbSecondary)
            Dim OriginalDBName As String = dbSecondary.DBConnection.Database

            'Remove excess fat from PaDS_Live
            '21/9/19    James Woosnam   In SHRINKFILE below use actual DB name
            '27/10/20   James Woosnam   Don't delete session log as now needed to reporting
            'select u.UserSessionId into #usToDel from UserSession u where u.LastAccessedDate  < dateadd(day,-7,getdate())
            'delete from UserSessionData  where UserSessionId in (select UserSessionId from #usToDel)
            'delete UserSessionData from UserSessionData d left join usersession u on u.UserSessionId = d.UserSessionId where u.UserSessionId is null
            'delete from UserSession where UserSessionId in (select UserSessionId from #usToDel)
            '22/02/21   Julian Gates    Add PEPWebSessionLog to copy
            '11/03/21   Julian Gates    Add UserActionLog to copy
            sql = "
                    select b.BatchLogId into #BlTodel from BatchLog b where b.DateTime < dateadd(month,-6,getdate())
                    delete from BatchLogLine where BatchLogId in (select BatchLogId from #BlTodel)
                    delete from BatchLog where BatchLogId in (select BatchLogId from #BlTodel)

                    delete from BatchJob  where ActualStartDateTime< dateadd(month,-6,getdate()) 


                    DBCC SHRINKFILE (N'" & db.DBConnection.Database & "' , 0, TRUNCATEONLY)
                    DBCC SHRINKFILE (N'" & db.DBConnection.Database & "_log' , 100)
                    "
            db.ExecuteSQL(sql)
            batchLog.Update("Old records deleted from BatchJob, BatchLog and UserSession, and Pads DB shrunk.  ")

            Dim PaDS_DBNameToBackup As String = ""
            Dim PaDS_backupFile As IO.FileInfo = Nothing

            Dim DBNameTimeSuffice As String = Now.ToString("yyyyMMddHHmmss")

            Dim TransferBackupNo As Integer = 0
            Try
                TransferBackupNo = db.GetParameterValue("TransferBackupNo")
            Catch ex As Exception
                db.SetParameterValue("TransferBackupNo", TransferBackupNo)
            End Try
            Dim TransferBackupsNoOfBeforeFull As Integer = 0
            Try
                TransferBackupsNoOfBeforeFull = db.GetParameterValue("TransferBackupsNoOfBeforeFull")
            Catch ex As Exception
                TransferBackupsNoOfBeforeFull = 48
                db.SetParameterValue("TransferBackupsNoOfBeforeFull", TransferBackupsNoOfBeforeFull)
            End Try
            If TransferBackupNo >= TransferBackupsNoOfBeforeFull Then
                'set trnsfer No back to 0 to trigger a full backup
                TransferBackupNo = 0
                db.SetParameterValue("TransferBackupNo", TransferBackupNo)
            End If

            Dim backupType As BackupTypes = BackupTypes.Diff
            Select Case TransferBackupNo
                Case 0
                    backupType = BackupTypes.Full
            End Select
            'Backup Main PaDS
            PaDS_DBNameToBackup = db.DBConnection.Database
            '27/07/21   James Woosnam   SIR5280 - Because of the 7/7/21 change, only the full & 1 diff files are require which saves lots of diskspace. 
            Dim PaDS_backupFileNameTemplate As String = PaDS_DBNameToBackup & "TransferBackupTYPE.bak"
            PaDS_backupFile = New IO.FileInfo(IO.Path.Combine(PrimaryDatabaseBackupDirectory, PaDS_backupFileNameTemplate.Replace("TYPE", backupType.ToString)))
            If PaDS_backupFile.Exists Then PaDS_backupFile.Delete()
            Me.BackupDatabase(PaDS_DBNameToBackup, msg, PrimaryDatabaseBackupDirectory, PaDS_backupFile.Name, False, backupType)
            batchLog.Update(PaDS_backupFile.Name & " backed up.  " & msg)
            msg = ""

            'Copy new PaDS logs records
            '6/10/21    James Woosnam   Copy log records to new PaDS_Logs_Backup DB.  Using the PaDS_Logs DB failed if there had been a short failover as records would have been added out of sync
            Try
                '2/11/2021  James   Stop CopyMissingRecords stoping whole backup
                Me.CopyMissingRecords("AuditLog", "AuditLogId", "Pads_Logs_Backup", dbSecondary, batchLog)
                Me.CopyMissingRecords("PEPWebUsageLog", "PEPWebUsageLogId", "Pads_Logs_Backup", dbSecondary, batchLog)
                Me.CopyMissingRecords("SessionLog", "SessionLogId", "Pads_Logs_Backup", dbSecondary, batchLog)
                Me.CopyMissingRecords("AuditTableLog", "AuditTableLogId", "Pads_Logs_Backup", dbSecondary, batchLog)
                Me.CopyMissingRecords("PEPWebSessionLog", "PEPWebSessionLogId", "Pads_Logs_Backup", dbSecondary, batchLog)
                Me.CopyMissingRecords("UserActionLog", "UserActionLogId", "Pads_Logs_Backup", dbSecondary, batchLog)
                Me.CopyMissingRecords("PEPUsage", "PEPUsageId", "Pads_Logs_Backup", dbSecondary, batchLog)

            Catch ex As Exception
                batchLog.Update("CopyMissingRecords Failed:" & ex.Message & " ** Process Continued **")
            End Try

            'Copy and restore main pads DB
            IO.File.Copy(IO.Path.Combine(PrimaryDatabaseBackupDirectoryUNC, PaDS_backupFile.Name), IO.Path.Combine(SecondaryDatabaseBackupDirectoryUNC, PaDS_backupFile.Name), True)
            batchLog.Update(PaDS_backupFile.Name & " file copied to secondary")
            UtilsOnSecondary.RestoreDatabaseForCopyToSecondary(PaDS_DBNameToBackup, PaDS_DBNameToBackup & DBNameTimeSuffice, msg, PaDS_backupFileNameTemplate, New IO.DirectoryInfo(SecondaryDatabaseBackupDirectory), TransferBackupNo)
            batchLog.Update(PaDS_backupFile.Name & " restored on Secondary.  " & msg)
            msg = ""

            msg = ""
            dbSecondary.ExecuteSQL("USE " & OriginalDBName)

            db.SetParameterValue("RunningSecondaryDBRestore", "True")
            'Set Pads_Live to single user, rename to "Before", and then renme restord DB to PaDS_Live
            sql = "
                    ALTER Database " & PaDS_DBNameToBackup & " SET SINGLE_USER WITH ROLLBACK IMMEDIATE
                    ALTER Database " & PaDS_DBNameToBackup & " MODIFY NAME = " & PaDS_DBNameToBackup & "Before" & DBNameTimeSuffice & "
                    ALTER Database " & PaDS_DBNameToBackup & DBNameTimeSuffice & " MODIFY NAME = " & PaDS_DBNameToBackup & "
                    USE " & PaDS_DBNameToBackup & "
                    ALTER Database " & PaDS_DBNameToBackup & "Before" & DBNameTimeSuffice & " SET MULTI_USER

                    "
            batchLog.Update("Before Databases Renamed.  ")
            '8/11/21    James Woosnam   Ensure that DB rename does not leave DB in single user mode.
            Try
                dbSecondary.ExecuteSQL(sql)
                batchLog.Update("After Databases Renamed.  ")
            Catch ex As Exception
                Throw New Exception("Rename Database Failed:" & ex.Message)
            Finally
                sql = "
                    USE " & PaDS_DBNameToBackup & "
                    ALTER Database " & PaDS_DBNameToBackup & "Before" & DBNameTimeSuffice & " SET MULTI_USER
                     "
                Try
                    dbSecondary.ExecuteSQL(sql) ' this may fail if this name doesn't exist yet due to failure above
                Catch ex As Exception
                End Try
            End Try

            db.SetParameterValue("RunningSecondaryDBRestore", "False")
            'Now that restore and rename finished update TransferBackupNo
            db.SetParameterValue("TransferBackupNo", TransferBackupNo + 1)

            batchLog.Update("Before Databases Drop.  ")
            'This SQL will delete all, but some (see SQL), previously restord PaDS_LiveBefore20% databases 
            Dim str As New System.IO.StreamReader(IO.Path.Combine(SQLFileDirectory, "DeleteOldTransferDatabaes.sql"))
            Try
                sql = str.ReadToEnd
            Catch ex As Exception
                Throw ex
            Finally
                str.Close()
            End Try
            '21/9/19    James Woosnam   Replace Pads_Live with actual db name 
            dbSecondary.ExecuteSQL(sql.ToLower.Replace("pads_live", OriginalDBName))
            batchLog.Update("After Databases Drop.  ")

            Dim fileReader As System.IO.StreamReader = System.IO.File.OpenText(IO.Path.Combine(SQLFileDirectory, "CreateUsersAndRoleseplaceServerName.sql"))
            Try
                sql = fileReader.ReadToEnd
            Catch ex As Exception
                Throw ex
            Finally
                fileReader.Close()
            End Try
            Dim UserIdServer As String = IIf(dbSecondary.DBConnection.DataSource.ToLower.Contains("zedra"), "zedra", dbSecondary.DBConnection.DataSource)
            '21/9/19    James Woosnam   Replace Pads_Live with actual db name 
            dbSecondary.ExecuteSQL(sql.ToLower.Replace("servername", UserIdServer).Replace("pads_live", OriginalDBName))
            batchLog.Update("CreateUsersAndRoleseplaceServerName run on " & dbSecondary.DBConnection.DataSource)
            dbSecondary.ExecuteSQL("USE " & OriginalDBName)

            Try
                UtilsOnSecondary.RunDatabaseSQL(SQLFileDirectory, msg, ErrMsg)
                batchLog.Update("RunDatabaseSQL:" & msg)

            Catch ex As Exception
                batchLog.Update("RunDatabaseSQL:" & msg)
                batchLog.Update("RunDatabaseSQL Failed:" & ErrMsg)
                Throw ex
            End Try
            msg = ""

            dbSecondary.SetParameterValue("FailoverThisIsMasterServer", "0")
            dbSecondary.SetParameterValue("FailoverThisIsMasterServerDesc", "DB Copied from Primary:" & Now.ToString("dd-MMM-yy HH:mm:ss"))
            dbSecondary.ExecuteSQL("EXEC sp510GrantObjectRights @MakeReadOnly=1")
            batchLog.Update("Secondary DB set to ReadOnly")

            batchLog.Update("CopyPaDSDatabaseToSecondary Complete", "Complete")
        Catch ex As Exception
            '17/6/19    James Woosnam   Send email if this fails.
            Dim sMsg As String = ex.Message & IIf(msg <> "", " DebugInfo:" & msg, "")
            batchLog.Update(sMsg, "Failed")
            Try
                Dim em As New Email(db)
                em.SendErrorEmail("PaDS Backup Copy Failed", sMsg)
            Catch ex1 As Exception
            End Try
            Throw New Exception("CopyPaDSDatabaseToSecondary Failed:" & sMsg, ex)
        End Try
    End Sub
    Public Sub CopyMissingRecords(TableName As String, IdColName As String, CopyToDBName As String, dbSec As Database, BatchLog As BatchLog)
        Dim sql As String = Nothing
        Try
            Dim lastCOpiedId As Integer = dbSec.DLookup("ISNULL(MAX(" & IdColName & "),0)", CopyToDBName & ".dbo." & TableName, "")
            Dim primTbl As DataTable = db.GetDataTableFromSQL("SELECT * FROM " & TableName & " WHERE " & IdColName & ">" & lastCOpiedId)
            BatchLog.Update(primTbl.Rows.Count & " " & TableName & " records to copy")
            dbSec.BeginTran()
            Try
                dbSec.ExecuteSQL("USE " & CopyToDBName)
                dbSec.ExecuteSQL("SET IDENTITY_INSERT " & TableName & " ON;")
                '            da.Fill(secTbl)
                Dim colNames As String = ""
                '           Dim IdColPos As Integer = 0
                For Each col As DataColumn In primTbl.Columns
                    colNames += IIf(colNames = "", "", ",") & col.ColumnName
                Next

                For Each row As DataRow In primTbl.Rows
                    Dim sqlValues As String = ""
                    For Each col As DataColumn In primTbl.Columns
                        Select Case col.DataType.ToString
                            Case "System.DateTime"
                                sqlValues += IIf(sqlValues = "", "", ",") & db.vFQ(db.IsDBNull(row(col.ColumnName), "01-jan-1900"), "d")
                            Case Else
                                sqlValues += IIf(sqlValues = "", "", ",") & "'" & CStr(db.IsDBNull(row(col.ColumnName), "")).Replace("'", "''") & "'"
                        End Select
                    Next
                    sql = "INSERT INTO " & TableName
                    sql += " (" & colNames & ")"
                    sql += " VALUES(" & sqlValues & ")"
                    dbSec.ExecuteSQL(sql)
                Next

                dbSec.ExecuteSQL("SET IDENTITY_INSERT " & TableName & " off;")
                dbSec.CommitTran()
                BatchLog.Update(primTbl.Rows.Count & " " & TableName & " records to copied")
            Catch ex As Exception
                dbSec.RollbackTran()
                Throw ex
            End Try

        Catch ex As Exception
            '2/11/2021  James   Send email if fails
            Dim msg As String = TableName & " CopyMissingRecords failed:" & ex.Message
            msg += Environment.NewLine & "Last SQL:" & sql
            Try
                Dim em As New Email(db)
                em.SendErrorEmail("PaDS: Copy Log records to secondary failed", msg)
            Catch ex1 As Exception
                msg += Environment.NewLine & "Send Error Email Failed:" & ex1.Message
                msg += Environment.NewLine & "This may be because the PaDS_Logs_Backup database has growth past 10GB limit, in which case it needs to be backed up and cleared.  See Admin Manual Section: 8.	BACKUP, SECONDARY SERVER & ARCHIVE"

            End Try
            BatchLog.Update(msg)
            Throw New Exception(msg)
        End Try
    End Sub

    Public Sub CheckFreeDiskSpace(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.CheckFreeDiskSpace(Parameters.GetValue("SecondaryConnectionString"))
    End Sub
    '08/04/22   Julian Gates    SIR5478 - Change CheckFreeDiskSpace to check all DBs on Pads01 and Pads02 using SQL dB query.
    Public Sub CheckFreeDiskSpace(SecondaryConnectionString As String)
        Dim BatchLog As New BatchLog("CheckFreeDiskSpace" _
                                    , "CheckFreeDiskSpace" _
                                    , Me.db, Me.BatchJobId)
        Try
            Dim allDrives As DriveInfo() = DriveInfo.GetDrives()
            Dim minimumDiskSpaceAllowed As String = db.GetParameterValue("MinimumDiskSpaceAllowed")
            BatchLog.Update("MinimumDiskSpaceAllowed=" & (minimumDiskSpaceAllowed / 1024 / 1000000).ToString("#,##0.0") & "GB")
            For Each d As DriveInfo In allDrives
                Dim msg As String = d.Name
                If d.IsReady Then
                    msg += " Size=" & (d.TotalSize / 1024 / 1000000).ToString("#,##0.0") & "GB"
                    msg += " Free Space:" & (d.TotalFreeSpace / 1024 / 1000000).ToString("#,##0.0") & "GB"

                    If d.TotalFreeSpace <= CLng(minimumDiskSpaceAllowed) Then
                        msg += " ****** Below Minimum *****"
                        Dim email As New BusinessLogic.Email(db)
                        email.SendErrorEmail("PaDS Check Drive Space", "PaDS dirve: " & msg & "GB which is below the minimum " & Format(CLng(minimumDiskSpaceAllowed) / 1073741824, "0.00") & "GB, please check.")
                    End If
                Else
                    msg += " Not Ready"
                End If
                BatchLog.Update(msg)
            Next
            BatchLog.Update("Check Drive Space Complete")

            Dim dBSQL As String = "SELECT"
            dBSQL += " DatabaseName = d.name"
            dBSQL += " ,FileLogicalName = f.name"
            dBSQL += " ,FileLocation = f.physical_name"
            dBSQL += " ,FileSizeKB = f.size * 8"
            dBSQL += " FROM [master].sys.databases d"
            dBSQL += "  LEFT JOIN [master].sys.master_files f"
            dBSQL += "  ON f.database_id = d.database_id"
            dBSQL += " WHERE d.name like 'PaDS%'"
            dBSQL += " ORDER BY 1"

            Dim primDBsTbl As DataTable = db.GetDataTableFromSQL(dBSQL)

            'Now check PaDS primary DB and Logs file max size
            Dim maxDBFileSizeAllowed As String = db.GetParameterValue("MaxDBFileSizeAllowed")
            Dim msg1 As String = Nothing
            Dim filesInfoMsg As String = Nothing
            BatchLog.Update("Start PaDS01 Check DB & Log file size are less than MaxDBFileSizeAllowed=" & (maxDBFileSizeAllowed / 1024 / 1000000).ToString("#,##0.0") & "GB")

            For Each row As DataRow In primDBsTbl.Rows
                If db.IsDBNull(row("FileSizeKB"), 0) >= CLng(maxDBFileSizeAllowed) Then
                    msg1 += row("DatabaseName") & " File " & row("FileLogicalName") & " in directory " & row("FileLocation") & " is currently " & (CLng(db.IsDBNull(row("FileSizeKB"), 0)) / 1024 / 1024).ToString("#,##0.0") & "GB and is above MaxDBFileSizeAllowed=" & (maxDBFileSizeAllowed / 1024 / 1000000).ToString("#,##0.0") & "GB" & vbCrLf
                End If
                filesInfoMsg += row("DatabaseName") & " File " & row("FileLogicalName") & " in directory " & row("FileLocation") & " is currently <b>" & (CLng(db.IsDBNull(row("FileSizeKB"), 0)) / 1024 / 1024).ToString("#,##0.0") & "GB</b>" & Environment.NewLine
            Next
            If msg1 <> Nothing Then
                BatchLog.Update(msg1)
                Dim email As New BusinessLogic.Email(db)
                email.SendErrorEmail("PaDS01 Check DB file size check", msg1)
            End If

            BatchLog.Update(filesInfoMsg & Environment.NewLine & "End Check of PaDS01 DB & Log file size")
            BatchLog.Update("Complete", "Complete")

            'Now check PaDS02 DB file size check is below max size only run on live not test.
            If Me.db.GetParameterValue("ServerDescription") <> "Amazon Test Server" Then
                Dim dbSecondary As New Database(SecondaryConnectionString)
                Dim secDBsTbl As DataTable = dbSecondary.GetDataTableFromSQL(dBSQL)

                maxDBFileSizeAllowed = db.GetParameterValue("MaxDBFileSizeAllowed")
                msg1 = Nothing
                filesInfoMsg = Nothing
                BatchLog.Update("Start PaDS02 Check DB & Log file size are less than MaxDBFileSizeAllowed=" & (maxDBFileSizeAllowed / 1024 / 1000000).ToString("#,##0.0") & "GB")
                For Each row As DataRow In secDBsTbl.Rows
                    If dbSecondary.IsDBNull(row("FileSizeKB"), 0) >= CLng(maxDBFileSizeAllowed) Then
                        msg1 += row("DatabaseName") & " File " & row("FileLogicalName") & " in directory " & row("FileLocation") & " is currently " & (CLng(dbSecondary.IsDBNull(row("FileSizeKB"), 0)) / 1024 / 1024).ToString("#,##0.0") & "GB and is above MaxDBFileSizeAllowed=" & (maxDBFileSizeAllowed / 1024 / 1000000).ToString("#,##0.0") & "GB" & vbCrLf
                    End If
                    filesInfoMsg += row("DatabaseName") & " File " & row("FileLogicalName") & " in directory " & row("FileLocation") & " is currently <b>" & (CLng(dbSecondary.IsDBNull(row("FileSizeKB"), 0)) / 1024 / 1024).ToString("#,##0.0") & "GB</b>" & Environment.NewLine
                Next
                If msg1 <> Nothing Then
                    BatchLog.Update(msg1)
                    Dim email As New BusinessLogic.Email(db)
                    email.SendErrorEmail("PaDS02 Check DB file size check", msg1)
                End If

                BatchLog.Update(filesInfoMsg & Environment.NewLine & "End Check of PaDS02 DB & Log file size")
                BatchLog.Update("Complete", "Complete")
            End If
        Catch ex As Exception
            BatchLog.Update("Failed:" & ex.Message, "Failed")

            Dim email As New BusinessLogic.Email(db)
            email.SendErrorEmail("PaDS Check Drive Space Failed", "PaDS01 Check Free Disk Space Failed. Error: " & ex.Message)
        End Try

    End Sub
#Region "AuditTableLogTriggers"
    Public Sub BuildTriggers(SQlSourceDirecotry As String, TestDataDirectory As String, Application As String, ByRef Message As String)

        Dim FullSQL As String = ""
        Dim DropTriggersSQL As String = ""

        GetTriggerSQL(SQlSourceDirecotry, TestDataDirectory, Application, Message, FullSQL, DropTriggersSQL)
        Dim strFileName As String = IO.Path.Combine(SQlSourceDirecotry, "AuditTableLogTriggers.SQL")
        Dim outputFile As System.IO.StreamWriter = New System.IO.StreamWriter(strFileName, False)
        Try
            outputFile.Write(FullSQL)
        Catch ex As Exception
            Throw ex
        Finally
            outputFile.Close()
        End Try
    End Sub

    Private Sub GetTriggerSQL(SQlSourceDirecotry As String,
                                    TestDataDirectory As String,
                                    Application As String,
                                    ByRef Message As String,
                                    ByRef FullSQL As String,
                                    ByRef DropTriggersSQL As String)

        Dim sqlDrop As String = ""
        Dim strTableName As String = ""
        Dim strFamilyName As String = ""
        Dim strFamilyKeySQL As String = ""
        Try
            Dim tblApp As DataTable = New StdCode().ImportCSVAsDataTable("ApplicationTables", IO.Path.Combine(TestDataDirectory, "ApplicationTables.csv"))
            Dim vw As New DataView(tblApp, "Application='" & Application & "' AND TriggerRequired='TRUE'", "TableName", DataViewRowState.CurrentRows)

            For Each row As DataRowView In vw
                strTableName = db.IsDBNull(row("TableName"), "")
                strFamilyName = db.IsDBNull(row("TriggerFamily"), "")
                strFamilyKeySQL = db.IsDBNull(row("TriggerFamilyKey"), "")

                Dim tblDef As DataTable = db.GetDataTableFromSQL("Select * FROM [" & strTableName & "] WHERE 1=2")
                sqlDrop = ""
                sqlDrop += "if exists (select * from sysobjects where id = object_id(N'[dbo].[trg" & strTableName & "UpdateAudit]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)" & vbCrLf
                sqlDrop += "DROP TRIGGER trg" & strTableName & "UpdateAudit" & vbCrLf
                sqlDrop += "Go" & vbCrLf
                FullSQL += sqlDrop
                DropTriggersSQL += sqlDrop
                '************
                'Update
                '***********
                FullSQL += "CREATE TRIGGER trg" & strTableName & "UpdateAudit ON [" & strTableName & "]" & vbCrLf
                FullSQL += "FOR Update" & vbCrLf
                FullSQL += "AS" & vbCrLf
                FullSQL += "DECLARE @AuditDate DateTime" & vbCrLf
                FullSQL += "DECLARE @TableAuditFlag BIT" & vbCrLf
                FullSQL += "" & vbCrLf

                FullSQL += "--Only do this is flag set" & vbCrLf
                FullSQL += "SELECT @TableAuditFlag = ISNULL(dbo.fn017GetParameter('TableAuditFlag'),1)" & vbCrLf
                FullSQL += "IF @TableAuditFlag <> 0" & vbCrLf
                FullSQL += "BEGIN" & vbCrLf

                FullSQL += "--Set the date" & vbCrLf
                FullSQL += "SET @AuditDate = GetDate()" & vbCrLf


                FullSQL += "INSERT INTO AuditTableLog" & vbCrLf

                FullSQL += "(ServerName, DatabaseName, TableName , AuditDate ,UpdatedByUserId ,UpdatedRecordFamily, UpdatedRecordFamilyKey, UpdatedRecordKey, ModificationType,BeforeDescription, AfterDescription )" & vbCrLf
                FullSQL += "SELECT ServerName = @@SERVERNAME" & vbCrLf
                FullSQL += "     ,DatabaseName = db_name()" & vbCrLf
                FullSQL += "     ,TableName = '" & strTableName & "'" & vbCrLf
                FullSQL += "     ,AuditDate = @AuditDate" & vbCrLf
                FullSQL += "     ,UpdatedByUserUserId = CASE WHEN AuditData.LastUpdatedDateTime < DATEADD(MINUTE,-1,GETDATE()) THEN system_user ELSE AuditData.LastUpdatedByUserId END" & vbCrLf
                FullSQL += "     ,'" & strFamilyName & "'" & vbCrLf
                If strFamilyKeySQL = "UseTableKey" Then
                    FullSQL += "     ,LEFT("
                    For Each col As DataRowView In New DataView(Me.DBKeyColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                        FullSQL += "      convert( varchar(200),  AuditData.[" & col("ColumnName") & "]  ) + ';' +" & vbCrLf
                    Next
                    FullSQL = Left(FullSQL, Len(FullSQL) - 9) & ",50)" & vbCrLf
                Else
                    FullSQL += "     ,LEFT(" & strFamilyKeySQL & ",50)" & vbCrLf
                End If
                FullSQL += "     ,LEFT("

                For Each col As DataRowView In New DataView(Me.DBKeyColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                    FullSQL += "      convert( varchar(200),  AuditData.[" & col("ColumnName") & "]  ) + ';' +" & vbCrLf
                Next
                FullSQL = Left(FullSQL, Len(FullSQL) - 9) & ",100)" & vbCrLf
                FullSQL += "     ,'Update'" & vbCrLf
                'BEFORE IMMFAge
                FullSQL += "     ," & vbCrLf
                For Each col As DataRowView In New DataView(Me.DBColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                    FullSQL += GetTriggerSelectForColumn(col, "DELETED", Message)
                Next
                FullSQL = Left(FullSQL, Len(FullSQL) - 9) & vbCrLf
                FullSQL += "  " & vbCrLf
                'AFTER IMMFAge
                FullSQL += "     ," & vbCrLf
                For Each col As DataRowView In New DataView(Me.DBColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                    FullSQL += GetTriggerSelectForColumn(col, "AuditData", Message)
                Next
                FullSQL = Left(FullSQL, Len(FullSQL) - 9) & vbCrLf
                FullSQL += "  " & vbCrLf
                '*****
                FullSQL += " FROM INSERTED AuditData" & vbCrLf
                FullSQL += "    LEFT JOIN DELETED" & vbCrLf
                FullSQL += "    ON 1=1" & vbCrLf
                For Each col As DataRowView In New DataView(Me.DBKeyColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                    FullSQL += "         AND DELETED.[" & col("ColumnName") & "] = AuditData.[" & col("ColumnName") & "]" & vbCrLf
                Next
                FullSQL += " WHERE" & vbCrLf

                'Begore IMMFAge
                FullSQL += "     LEFT(" & vbCrLf
                For Each col As DataRowView In New DataView(Me.DBColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                    FullSQL += GetTriggerSelectForColumn(col, "DELETED", Message)
                Next
                FullSQL = Left(FullSQL, Len(FullSQL) - 9) & vbCrLf
                FullSQL += "    ,5000   )" & vbCrLf
                FullSQL += "  <>" & vbCrLf
                'After IMMFAge
                FullSQL += "     LEFT(" & vbCrLf
                For Each col As DataRowView In New DataView(Me.DBColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                    FullSQL += GetTriggerSelectForColumn(col, "AuditData", Message)
                Next
                FullSQL = Left(FullSQL, Len(FullSQL) - 9) & vbCrLf
                FullSQL += "    ,5000   )" & vbCrLf
                FullSQL += "END --Aduit flag check" & vbCrLf
                FullSQL += "GO" & vbCrLf

                '******************************************************************
                '    Delete Triggers
                '******************************************************************
                sqlDrop = ""
                sqlDrop += "if exists (select * from sysobjects where id = object_id(N'[dbo].[trg" & strTableName & "DeleteAudit]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)" & vbCrLf
                sqlDrop += "DROP TRIGGER trg" & strTableName & "DeleteAudit" & vbCrLf
                sqlDrop += "Go" & vbCrLf
                FullSQL += sqlDrop
                DropTriggersSQL += sqlDrop
                FullSQL += "CREATE TRIGGER trg" & strTableName & "DeleteAudit ON [" & strTableName & "]" & vbCrLf
                FullSQL += "FOR Delete" & vbCrLf
                FullSQL += "AS" & vbCrLf
                FullSQL += "DECLARE @AuditDate DateTime" & vbCrLf
                FullSQL += "DECLARE @TableAuditFlag BIT" & vbCrLf
                FullSQL += "" & vbCrLf

                FullSQL += "--Only do this is flag set" & vbCrLf
                FullSQL += "SELECT @TableAuditFlag = ISNULL(dbo.fn017GetParameter('TableAuditFlag'),1)" & vbCrLf
                FullSQL += "IF @TableAuditFlag <> 0" & vbCrLf
                FullSQL += "BEGIN" & vbCrLf

                FullSQL += "--Set the date" & vbCrLf
                FullSQL += "SET @AuditDate = GetDate()" & vbCrLf

                FullSQL += "INSERT INTO AuditTableLog" & vbCrLf
                FullSQL += "(ServerName, DatabaseName, TableName , AuditDate ,UpdatedByUserId ,UpdatedRecordFamily, UpdatedRecordFamilyKey, UpdatedRecordKey, ModificationType,BeforeDescription, AfterDescription )" & vbCrLf
                FullSQL += "SELECT  @@SERVERNAME" & vbCrLf
                FullSQL += "     ,db_name()" & vbCrLf
                FullSQL += "     ,'" & strTableName & "'" & vbCrLf
                FullSQL += "     ,@AuditDate" & vbCrLf
                FullSQL += "     ,UpdatedByUserUserId = CASE WHEN AuditData.LastUpdatedDateTime < DATEADD(MINUTE,-1,GETDATE()) THEN Current_User ELSE AuditData.LastUpdatedByUserId END" & vbCrLf
                FullSQL += "     ,'" & strFamilyName & "'" & vbCrLf
                If strFamilyKeySQL = "UseTableKey" Then
                    FullSQL += "     ,LEFT("
                    For Each col As DataRowView In New DataView(Me.DBKeyColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                        FullSQL += "      convert( varchar(200),  AuditData.[" & col("ColumnName") & "]  ) + ';' +" & vbCrLf
                    Next
                    FullSQL = Left(FullSQL, Len(FullSQL) - 9) & ",50)" & vbCrLf
                Else
                    FullSQL += "     ,LEFT(" & strFamilyKeySQL.Replace("INSERTED", "DELETED") & ",50)" & vbCrLf
                End If
                FullSQL += "     ,LEFT("


                For Each col As DataRowView In New DataView(Me.DBKeyColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                    FullSQL += "      convert( varchar(200),  AuditData.[" & col("ColumnName") & "]  ) + ';' +" & vbCrLf
                Next
                FullSQL = Left(FullSQL, Len(FullSQL) - 9) & ",100)" & vbCrLf
                FullSQL += "     ,'Delete'" & vbCrLf
                'BEFORE IMMFAge
                FullSQL += "     ," & vbCrLf
                For Each col As DataRowView In New DataView(Me.DBColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                    FullSQL += GetTriggerSelectForColumn(col, "AuditData", Message)
                Next
                FullSQL = Left(FullSQL, Len(FullSQL) - 9) & vbCrLf
                FullSQL += "  " & vbCrLf
                FullSQL += ",NULL" & vbCrLf 'After IMMFAge
                FullSQL += " FROM DELETED AuditData" & vbCrLf
                FullSQL += "END --Aduit flag check" & vbCrLf
                FullSQL += "GO" & vbCrLf

                '******************************************************************
                'Insert Triggers
                '******************************************************************
                sqlDrop = ""
                sqlDrop += "if exists (select * from sysobjects where id = object_id(N'[dbo].[trg" & strTableName & "InsertAudit]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)" & vbCrLf
                sqlDrop += "DROP TRIGGER trg" & strTableName & "InsertAudit" & vbCrLf
                sqlDrop += "Go" & vbCrLf
                FullSQL += sqlDrop
                DropTriggersSQL += sqlDrop
                FullSQL += "CREATE TRIGGER trg" & strTableName & "InsertAudit ON [" & strTableName & "]" & vbCrLf
                FullSQL += "FOR Insert" & vbCrLf
                FullSQL += "AS" & vbCrLf
                FullSQL += "DECLARE @AuditDate DateTime" & vbCrLf
                FullSQL += "DECLARE @TableAuditFlag BIT" & vbCrLf
                FullSQL += "" & vbCrLf

                FullSQL += "--Only do this is flag set" & vbCrLf
                FullSQL += "SELECT @TableAuditFlag = ISNULL(dbo.fn017GetParameter('TableAuditFlag'),1)" & vbCrLf
                FullSQL += "IF @TableAuditFlag <> 0" & vbCrLf
                FullSQL += "BEGIN" & vbCrLf

                FullSQL += "--Set the date" & vbCrLf
                FullSQL += "SET @AuditDate = GetDate()" & vbCrLf

                FullSQL += "INSERT INTO AuditTableLog" & vbCrLf
                FullSQL += "(ServerName, DatabaseName, TableName , AuditDate ,UpdatedByUserId ,UpdatedRecordFamily, UpdatedRecordFamilyKey, UpdatedRecordKey, ModificationType,BeforeDescription, AfterDescription )" & vbCrLf
                FullSQL += "SELECT  @@SERVERNAME" & vbCrLf
                FullSQL += "     ,db_name()" & vbCrLf
                FullSQL += "     ,'" & strTableName & "'" & vbCrLf
                FullSQL += "     ,@AuditDate" & vbCrLf
                FullSQL += "     ,UpdatedByUserUserId = CASE WHEN AuditData.LastUpdatedDateTime < DATEADD(MINUTE,-1,GETDATE()) THEN Current_User ELSE AuditData.LastUpdatedByUserId END" & vbCrLf
                FullSQL += "     ,'" & strFamilyName & "'" & vbCrLf
                If strFamilyKeySQL = "UseTableKey" Then
                    FullSQL += "     ,LEFT("
                    For Each col As DataRowView In New DataView(Me.DBKeyColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                        FullSQL += "      convert( varchar(200),  AuditData.[" & col("ColumnName") & "]  ) + ';' +" & vbCrLf
                    Next
                    FullSQL = Left(FullSQL, Len(FullSQL) - 9) & ",50)" & vbCrLf
                Else
                    FullSQL += "     ,LEFT(" & strFamilyKeySQL & ",50)" & vbCrLf
                End If
                FullSQL += "     ,LEFT("
                For Each col As DataRowView In New DataView(Me.DBKeyColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                    FullSQL += "      convert( varchar(200),  AuditData.[" & col("ColumnName") & "]  ) + ';' +" & vbCrLf
                Next
                FullSQL = Left(FullSQL, Len(FullSQL) - 9) & ",100)" & vbCrLf
                FullSQL += "      ,'Insert'" & vbCrLf
                FullSQL += "      ,NULL" & vbCrLf ' Before IMMFAge
                'AFTER IMMFAge
                FullSQL += "     ," & vbCrLf
                For Each col As DataRowView In New DataView(Me.DBColumns, "TableName = '" & strTableName & "'", "OrdinalPosition", DataViewRowState.CurrentRows)
                    FullSQL += GetTriggerSelectForColumn(col, "AuditData", Message)
                Next
                FullSQL = Left(FullSQL, Len(FullSQL) - 9) & vbCrLf
                FullSQL += "   " & vbCrLf

                FullSQL += " FROM INSERTED AuditData" & vbCrLf
                FullSQL += "END --Aduit flag check" & vbCrLf
                FullSQL += "GO" & vbCrLf



            Next



        Catch ex As Exception
            Throw New Exception("Buil Triggers Faield:" & ex.ToString)

        End Try

    End Sub

    '5/3/18     James   ****** The Excluded Trigger Columns are also mentioned in fn050GetColumnNames
    Public TriggersExcludedColumns As String() = {"LastLogonDateTime", "PasswordRetryAttempts", "LastLogonAttemptDate"}

    Function GetTriggerSelectForColumn(col As DataRowView, strTableType As String, ByRef Message As String) As String

        Dim strDelimiter As String
        Dim ColName As String = col("ColumnName")
        If TriggersExcludedColumns.Contains(ColName) Then
            '5/3/18     James Woosnam   Exclude some columns
            Return ""
        End If
        strDelimiter = "|"
        If ColName.ToLower <> "timestampid" Then

            Select Case col("DataType").ToString.ToLower
                Case "text", "ntext" ' Text feild so do nothing
                Case "varchar", "nvarchar", "char", "nchar" ' Text feild so do nothing
                    Return "      CASE  WHEN " & strTableType & ".[" & ColName & "] IS NULL  THEN '' ELSE " & strTableType & ".[" & ColName & "]  END + '" & strDelimiter & "' +" & vbCrLf
                Case "datetime", "datetime2" ' dates
                    Return "      CASE  WHEN " & strTableType & ".[" & ColName & "] IS NULL  THEN '' ELSE CONVERT(VARCHAR," & strTableType & ".[" & ColName & "],120) END  + '" & strDelimiter & "' +" & vbCrLf
                Case "int", "bigint", "bit", "float", "money", "numeric", "tinyint", "real", "decimal" ' numbers"
                    Return "      CASE  WHEN " & strTableType & ".[" & ColName & "] IS NULL  THEN '' ELSE cast( " & strTableType & ".[" & ColName & "] AS VARCHAR) END   + '" & strDelimiter & "' +" & vbCrLf
                Case "uniqueidentifier"
                    Return "      CASE  WHEN " & strTableType & ".[" & ColName & "] IS NULL  THEN '' ELSE CONVERT(VARCHAR(36)," & strTableType & ".[" & ColName & "])  END + '" & strDelimiter & "' +" & vbCrLf
                Case "timestamp"
                    'just ignore any timestamp cols
                Case Else
                    If Not Message.Contains(col("DataType").ToString) Then
                        Message += "Unknown Type:" & col("DataType").ToString & " (" & ColName & ")" & vbCrLf
                    End If
            End Select

        End If
        Return ""

    End Function
    Dim _DBColums As DataTable = Nothing
    Function DBColumns() As DataTable
        If Me._DBColums Is Nothing Then
            Dim sql As String = ""
            sql = "SELECT TableName =  Table_Name"
            sql += "    ,ColumnName = Column_Name"
            sql += "    ,OrdinalPosition = Ordinal_Position"
            sql += "    ,DataType = Data_Type"
            sql += " FROM INFORMATION_SCHEMA.COLUMNS"
            '20/10/20     James   ****** The Excluded Trigger Columns are also mentioned in fn042GetColumnNames - KEEP IN SYNC
            sql += " WHERE Column_Name      NOT IN ('LastUpdatedDateTime','LastUpdatedByUserId', 'PasswordRetryAttempts', 'LastLoggedOn','PEPWebClientSettings')" 'don't count as change if the time has changed
            sql += " ORDER BY Ordinal_Position"
            Me._DBColums = db.GetDataTableFromSQL(sql)

        End If

        Return Me._DBColums
    End Function
    Dim _DBKeyColums As DataTable = Nothing
    Function DBKeyColumns() As DataTable
        If Me._DBKeyColums Is Nothing Then
            Dim sql As String = ""
            sql = "SELECT TableName =  c.Table_Name"
            sql += "    ,ColumnName = c.Column_Name"
            sql += "    ,OrdinalPosition = c.Ordinal_Position"
            sql += " FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS pk "
            sql += " 	INNER JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE c"
            sql += " 	ON c.TABLE_NAME = pk.TABLE_NAME "
            sql += " 	AND  c.CONSTRAINT_NAME = pk.CONSTRAINT_NAME"
            sql += " WHERE pk.CONSTRAINT_TYPE = 'PRIMARY KEY'"
            sql += " ORDER BY c.Ordinal_Position"
            Me._DBKeyColums = db.GetDataTableFromSQL(sql)

        End If

        Return Me._DBKeyColums
    End Function

#End Region




End Class
