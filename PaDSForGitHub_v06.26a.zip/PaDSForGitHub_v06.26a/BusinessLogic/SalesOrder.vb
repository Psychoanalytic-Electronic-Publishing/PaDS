﻿'Updates
'======
'22/5/11        James Woosnam   HotFix - Open Logs with UserSession
'2/6/11         James Woosnam   Set Order Date to date part only
'5/6/11         James Woosnam   In Add if the sub doesn't have an account for the company then add one
'14/09/12       Julian Gates    SIR2865 - Check if subscriber address exists before writing to database in Sub AddSalesOrderLines
'14/05/15       Julian Gates    SIR3838 - Add new SendEmailReceipt() to send email using SalesOrder data
'28/10/15       Julian Gates    SIR3987 - In sub AddSalesOrderLines if selected products contains "PEPWEBS", "PEPWEB" set as PrimaryProductCode
'03/06/16       Julian Gates    Fix Amount formatting to stop rounding in SendEmailReceipt
'18/09/19       Julian Gates    SIR4916 - Update SalesOrderLine to cancelled if Order cancelled in Save
'11/10/19       Julian Gates    SIR4916 - Update Recurring Subscription Dates
'25/11/19       Julian Gates    SIR4942 - Get UserName from RemoteUser and remove web user password
'16/1/20        James Woosnam   SIR4995 - Remove postal address in SendEmailReceipt as not used
'21/08/20       Julian Gates    SIR5099 - Add last Updated fields to ExecuteDespatchSalesOrder
'27/12/20   James Woosnam   SIR5170 - Only mark complete, when all lines shipped
'3/11/21    James Woosnam   SIR5338 - If IsOrderSuspended has been set TerminateOrderSessions
'2/12/21    James Woosnam   SIR5359 - Populate SubscriberAddressId & AddressText in Despatch
'31/1/22    James Woosnam   SIR5422 - PopulateAndSubmitBlockConfirmationEmail Allow for ' hypen in names by using @ parameters and put in transaction so doesn't part populate log, and correct SQL left join to email log
'07/03/22   Julian Gates    SIR5456 - Change @EmailBody to be -1 to match VarChar(Max) in DB.

Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class SalesOrder
#Region "Class Properties"

    Public MainDataset As New DataSet
    Dim _OrderNumber As Long
    Dim UserSession As UserSession

    Public Property OrderNumber() As Integer
        Get
            If Me._OrderNumber = Nothing Then
                If MainDataset.Tables("SalesOrder") IsNot Nothing Then
                    Me._OrderNumber = Me.SalesOrderRow("OrderNumber")
                End If
            End If
            Return Me._OrderNumber
        End Get
        Set(ByVal Value As Integer)
            _OrderNumber = Value
        End Set
    End Property

    Private ReadOnly Property SalesOrder() As DataTable
        Get
            If Me.MainDataset.Tables("SalesOrder") Is Nothing Then
                Me.daSalesOrder.Fill(Me.MainDataset, "SalesOrder")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("SalesOrder").Columns("OrderNumber")}
            Me.MainDataset.Tables("SalesOrder").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("SalesOrder")
        End Get
    End Property
    Private _daSalesOrder As SqlDataAdapter
    Private ReadOnly Property daSalesOrder() As SqlDataAdapter
        Get
            If Me._daSalesOrder Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM SalesOrder"
                sql += " WHERE OrderNumber=" & Me.OrderNumber
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daSalesOrder = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daSalesOrder)
                _daSalesOrder.UpdateCommand = cmdBld.GetUpdateCommand()
                _daSalesOrder.InsertCommand = cmdBld.GetInsertCommand()
                _daSalesOrder.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daSalesOrder.InsertCommand.Transaction = Me.db.DBTransaction
                _daSalesOrder.UpdateCommand.Transaction = Me.db.DBTransaction
                _daSalesOrder.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daSalesOrder
        End Get
    End Property

    Public ReadOnly Property SalesOrderRow() As DataRow
        Get
            If Me.SalesOrder.Rows.Count = 0 Then
                Me.daSalesOrder.Fill(Me.MainDataset.Tables("SalesOrder"))
                If Me.SalesOrder.Rows.Count = 0 Then
                    Throw New Exception("UserError: OrderNumber:" & Me.OrderNumber & " can't be found")
                End If
            End If
            Return Me.SalesOrder.Rows(0)
        End Get
    End Property

    Private Sub Initilise()
        Dim xx As Integer = 0
        Me.MainDataset = New DataSet
        Me._daSalesOrder = Nothing
        Me._daSalesOrderLine = Nothing
        xx = Me.SalesOrder.Rows.Count
        xx = Me.SalesOrderLine.Rows.Count

    End Sub

    Public ReadOnly Property SalesOrderLine() As DataTable
        Get
            If Me.MainDataset.Tables("SalesOrderLine") Is Nothing Then
                daSalesOrderLine.Fill(Me.MainDataset, "SalesOrderLine")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("SalesOrderLine").Columns("SalesOrderLineId")}
            Me.MainDataset.Tables("SalesOrderLine").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("SalesOrderLine")
        End Get
    End Property

    Private _daSalesOrderLine As SqlDataAdapter
    Private ReadOnly Property daSalesOrderLine() As SqlDataAdapter
        Get
            If Me._daSalesOrderLine Is Nothing Then
                Dim sql As String = ""
                sql = "SELECT *"
                sql += " FROM SalesOrderLine"
                sql += " WHERE OrderNumber = " & Me.OrderNumber
                sql += " ORDER BY SalesOrderLineId"
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daSalesOrderLine = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daSalesOrderLine)
                _daSalesOrderLine.UpdateCommand = cmdBld.GetUpdateCommand()
                _daSalesOrderLine.InsertCommand = cmdBld.GetInsertCommand()
                _daSalesOrderLine.DeleteCommand = cmdBld.GetDeleteCommand()

            End If

            If Not Me.db.DBTransaction Is Nothing Then
                _daSalesOrderLine.InsertCommand.Transaction = Me.db.DBTransaction
                _daSalesOrderLine.UpdateCommand.Transaction = Me.db.DBTransaction
                _daSalesOrderLine.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daSalesOrderLine
        End Get
    End Property

    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property
#End Region

    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.OrderNumber = 0
    End Sub

    Sub New(ByVal OrderNumber As Integer, ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.OrderNumber = OrderNumber
        Me.Initilise()
    End Sub

    Public Sub Save()
        '05/1/21    James Woosnam   SIR5153 - Delete code which deleted SalesOrderLines as not required as done in AddSalesOrderline and only use current rows in for each loops
        Dim sql As String = ""
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Dim logs As New BusinessLogic.Logs(db, Me.UserSession)

            Select Case Me.SalesOrderRow.RowState
                Case DataRowState.Added, DataRowState.Modified
                    SalesOrderRow("LastUpdatedDateTime") = Now()
                    SalesOrderRow("LastUpdatedByUserId") = UserSession.UserName20
                    Try
                        logs.WriteAuditLog("SalesOrder", SalesOrderRow("OrderNumber"), UserSession.UserId, UserSession.UserName, Me.SalesOrderRow.RowState.ToString(), "")
                    Catch ex As Exception
                    End Try
            End Select


            '11/10/2019 Julian Gates    SIR4916 - Update Recurring Subscription Dates
            '22/10/20   James Woosnam   SIR5099 - Update recurring dates and order totals in vb before .updates to minimise audit log entries
            With SalesOrderRow
                .Item("AmountNet") = 0
                .Item("TotalQuantity") = 0
                For Each rSOL As DataRowView In New DataView(Me.SalesOrderLine, "", "", DataViewRowState.CurrentRows)
                    .Item("AmountNet") += db.IsDBNull(rSOL("AmountProduct"), 0)
                    .Item("TotalQuantity") += db.IsDBNull(rSOL("Quantity"), 0)
                Next
                .Item("AmountDiscount") = Math.Round(.Item("AmountNet") * .Item("PercentDiscount"), 2)
                Dim amtBeforeVAT As Decimal = .Item("AmountNet") - .Item("AmountDiscount") + .Item("AmountCarriage")
                .Item("AmountVAT") = Math.Round(amtBeforeVAT * .Item("PercentVat"), 2)
                .Item("AmountGross") = amtBeforeVAT + .Item("AmountVAT")

            End With
            '31/10/20   James Woosnam   SIR5145 - set IsPaid in vb to smplify audit
            Dim totalCashbook As Decimal = db.IsDBNull(db.DLookup("SUM(Amount)", "Cashbook", "OrderNumber=" & Me.OrderNumber), 0)
            SalesOrderRow("IsPaid") = totalCashbook >= SalesOrderRow("AmountGross")

            Dim undespatchedOrderLineCount As Integer = 0
            If Me.SalesOrderLine IsNot Nothing Then
                For Each row As DataRow In Me.MainDataset.Tables("SalesOrderLine").Rows
                    Select Case row.RowState
                        Case DataRowState.Added, DataRowState.Modified
                            row("LastUpdatedDateTime") = Now()
                            row("LastUpdatedByUserId") = UserSession.UserName20
                            Try
                                logs.WriteAuditLog("SalesOrderLine", row("OrderNumber") & "," & row("SalesOrderLineId"), UserSession.UserId, UserSession.UserName, row.RowState.ToString(), "")
                            Catch ex As Exception
                            End Try
                    End Select
                Next
                '18/09/2019 Julian Gates    SIR4916 - Update SalesOrderLine to cancelled if Order cancelled
                If Me.SalesOrderRow.Item("SalesOrderStatus") = "Cancelled" Then
                    For Each row As DataRow In Me.MainDataset.Tables("SalesOrderLine").Rows
                        row("IsCancel") = 1
                        '27/10/2020 Julian Gates   Bug fix - Also Update SalesOrderLine CancelledDate if Order cancelled
                        row("CancelledDate") = db.IsDBNull(Me.SalesOrderRow.Item("CancelledDate"), Now())
                    Next
                End If

                Dim SubscriptionStartDateForAdd As Date = db.IsDBNull(SalesOrderRow("SubscriptionStartDateForAdd"), SalesOrderRow("OrderDate"))
                For Each rSOL As DataRowView In New DataView(Me.SalesOrderLine, "", "", DataViewRowState.CurrentRows)
                    Dim prd As New Product(rSOL("ProductCode"), db, UserSession)
                    If db.IsDBNull(prd.ProductRow("RecurringSubscriptionFlag"), False) Then
                        If SubscriptionStartDateForAdd <> CType(db.IsDBNull(rSOL("RecurringSubscriptionStartDate"), "01-jan-1900"), Date) Then
                            rSOL("RecurringSubscriptionStartDate") = SubscriptionStartDateForAdd
                            rSOL("RecurringSubscriptionEndDate") = db.GetDataTableFromSQL("SELECT RecurringSubscriptionEndDate = dbo.fn236GetRecurringSubscriptionEndDate('" & prd.ProductCode & "'," & db.vFQ(SubscriptionStartDateForAdd, "D") & ")").Rows(0)(0)
                            If CDate(rSOL("RecurringSubscriptionStartDate")) >= CDate(rSOL("RecurringSubscriptionEndDate")) Then
                                Throw New Exception("Invalid Product Definition: The recurring end date(" & CDate(rSOL("RecurringSubscriptionEndDate")).ToString("dd-MMM-yy") & ") is before the start Date (" & CDate(rSOL("RecurringSubscriptionEndDate")).ToString("dd-MMM-yy") & ")")
                            End If
                        End If
                    End If
                    '31/10/20   James Woosnam   SIR5145 - Do 'Complete' processing in vb
                    '10/3/22    James           Ignore cancelled order lines
                    If prd.ProductRow("ShippedProductFlag") And Me.SalesOrderRow("SalesOrderStatus") = "Confirmed" And Not CType(db.IsDBNull(rSOL("IsCancel"), False), Boolean) Then
                        'SalesOrderLinePart is only created when a child product is shipped
                        '27/12/20   James Woosnam   SIR5170 - Onlt mark complete, when all lines shipped
                        sql = "
								    SELECT LinesShippedCount = COUNT(DISTINCT solp.ProductCode )
										    ,TotalProductsToShipChildCount = (SELECT COUNT(*) FROM Product WHERE ParentProductCode = MAX(sol.ProductCode) )
                                    FROM SalesOrderLine sol
									    LEFT JOIN SalesOrderLinePart solp
									    ON solp.SalesOrderLineID = sol.SalesOrderLineID 
                                    WHERE sol.SalesOrderLineID = " & rSOL("SalesOrderLineID") & "
								    GROUP BY sol.SalesOrderLineID  "
                        'If line hasn't been despatched then add to undespatched count
                        Dim r As DataRow = db.GetDataTableFromSQL(sql)(0)
                        undespatchedOrderLineCount += r("TotalProductsToShipChildCount") - r("LinesShippedCount")
                    End If
                Next
                Me.daSalesOrderLine.Update(Me.MainDataset, "SalesOrderLine")
            End If
            '18/8/21   James Woosnam   SIR5237 - If rate came via an ProductAffiliateRate then populate AffiliateRateSubscriberId.
            '11/10/21   James Woosnam   SIR5341 - Code below moved from pg143 as it needs to run for remote orders, also only for Individual, Partial orders
            If Me.SalesOrderRow("OrderType").ToString.Contains("Individual") Then
                sql = "UPDATE SalesOrderLine
                        SET AffiliateRateSubscriberId = par.GroupSubscriberId 
                        FROM SalesOrderLine sol
                            INNER JOIN Salesorder so
                            ON so.OrderNumber = sol.OrderNumber
	                        INNER JOIN ProductRate pr
	                            LEFT JOIN ProductAffiliateRate par
	                            ON par.ProductRateId = pr.ProductRateId
	                        ON pr.ProductRateId = sol.ProductRateId 
                        WHERE so.SalesOrderStatus IN ('Partial','RemotePartial')
                        AND sol.OrderNumber =  " & Me.OrderNumber
                db.ExecuteSQL(sql)
            End If
            '3/11/21    James Woosnam   SIR5338 - If IsOrderSuspended has been set TerminateOrderSessions
            If Me.SalesOrderRow.RowState <> DataRowState.Added AndAlso db.IsDBNull(Me.SalesOrderRow("IsOrderSuspended", DataRowVersion.Current), False) AndAlso db.IsDBNull(Me.SalesOrderRow("IsOrderSuspended", DataRowVersion.Original), False) <> Me.SalesOrderRow("IsOrderSuspended", DataRowVersion.Current) Then
                Me.TerminateOrderSessions()
            End If
            '31/10/20   James Woosnam   SIR5145 - Do 'Complete' processing in vb
            If Me.SalesOrderRow("SalesOrderStatus") = "Confirmed" Then
                '31/10/20   set complete in vb to smplify audit
                If SalesOrderRow("IsPaid") And undespatchedOrderLineCount = 0 Then Me.SalesOrderRow("SalesOrderStatus") = "Complete"
            End If
            Me.daSalesOrder.Update(Me.MainDataset, "SalesOrder")


            Dim al As New AuditLog(db, UserSession)
            '1/1/20 James Woosnam   SIR5145- For orders with more than 10 lines don't do secondary audit as causing timeout.  Big orders are only entered by admin
            If Me.SalesOrderLine.Rows.Count < 10 Then
                al.WriteAuditLog(AuditLog.RecordTables.SalesOrder, Me.OrderNumber)
            End If

            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try
    End Sub
    Public Sub AdminOrderAdd(ByVal SubscriberId As Integer,
                       ByVal OrderType As String,
                       ByVal CompanyId As Integer
                       )
        Dim row As DataRow = Me.SalesOrder.NewRow
        row("OrderNumber") = db.GetNextNumber("SalesOrder")
        row("OrderType") = OrderType
        row("OrderDate") = Now.Date
        row("SubscriberId") = SubscriberId
        row("CompanyId") = CompanyId
        row("SalesOrderStatus") = "Partial"
        row("TotalQuantity") = 0
        row("AmountNet") = 0
        row("AmountDiscount") = 0
        row("PercentDiscount") = 0
        row("AmountCarriage") = 0
        row("PercentVAT") = 0
        row("AmountVAT") = 0
        row("AmountGross") = 0
        row("CreatedDateTime") = Now()
        row("CreatedByUserId") = UserSession.UserName20
        row("LastUpdatedDateTime") = Now()
        row("LastUpdatedByUserId") = UserSession.UserName20

        Me.SalesOrder.Rows.Add(row)

        Me.OrderNumber = row("OrderNumber")
    End Sub
    Private Sub AddNewOrderRow(ByVal ProductCode As String,
                       SubscriberId As Integer,
                       OrderType As String,
                       SalesOrderStatus As String,
                       CurrencyCode As String)
        Dim row As DataRow = Me.SalesOrder.NewRow
        row("OrderNumber") = db.GetNextNumber("SalesOrder")
        row("OrderType") = OrderType
        '2/6/11     James Woosnam   Set Order Date to date part only
        row("OrderDate") = Now.Date
        Dim CompanyId As Integer = db.DLookup("CompanyId", "Product", "ProductCode='" & ProductCode & "'")
        Dim Subscriber As New BusinessLogic.Subscriber(SubscriberId, db, UserSession)
        '5/6/11     James Woosnam   In Add if the sub doesn't have an account for the company then add one
        If db.IsDBNull(Subscriber.CompanyAccountRow(CompanyId)) Then
            Subscriber.AddCompanyAccount(CompanyId, IIf(OrderType = "Block", "Society", "Individual"), 4, "Full", Subscriber.SubscriberRow("DefaultPostalAddressId"))
        End If
        row("SubscriberId") = SubscriberId
        row("PrimaryProductCode") = ProductCode
        row("CurrencyCode") = CurrencyCode
        row("CompanyId") = CompanyId
        row("OrderedByName") = Left(UserSession.Data("UserFullName"), 50)
        row("SalesOrderStatus") = SalesOrderStatus
        row("TotalQuantity") = 0
        row("AmountNet") = 0
        row("AmountDiscount") = 0
        row("PercentDiscount") = 0
        row("AmountCarriage") = 0
        row("PercentVAT") = 0
        row("AmountVAT") = 0
        row("AmountGross") = 0
        row("CreatedDateTime") = Now()
        row("CreatedByUserId") = UserSession.UserName20
        row("LastUpdatedDateTime") = Now()
        row("LastUpdatedByUserId") = UserSession.UserName20

        Me.SalesOrder.Rows.Add(row)

        Me.OrderNumber = row("OrderNumber")
    End Sub
    Public Sub Add(ByVal ProductCode As String,
                       SubscriberId As Integer,
                       OrderType As String,
                       SalesOrderStatus As String,
                       CurrencyCode As String,
                       SubscriptionStartDateForAdd As Date)
        '11/11/19   James Woosnam   SIR4760 - Add a more generic Add and use in original Add
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Me.AddNewOrderRow(ProductCode,
                            SubscriberId,
                            OrderType,
                            SalesOrderStatus,
                            CurrencyCode)
            If SubscriptionStartDateForAdd <> Nothing Then Me.SalesOrderRow("SubscriptionStartDateForAdd") = SubscriptionStartDateForAdd

            Me.Save()
            If TranStartedHere Then

                db.CommitTran()
            End If
        Catch ex As Exception
            If TranStartedHere Then
                db.RollbackTran()
            End If
            Throw New Exception("UserError: Add Sales Order failed", ex)
        End Try
    End Sub
    Public Sub Add(ByVal SelectedProducts As DataTable)

        Dim message As String = ""
        If SelectedProducts.Rows.Count = 0 Then
            message += "At least one product must be selected " & System.Environment.NewLine
        End If
        If message <> "" Then
            message = message.Substring(0, message.Length - System.Environment.NewLine.Length)
            Throw New Exception("UserError: Add Sales Order Failed:" & System.Environment.NewLine & message)
        End If
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            '11/11/19   James Woosnam   SIR4760 - Use new add, set primary product to forst for now and update in sales order line add
            Me.AddNewOrderRow(SelectedProducts.Rows(0)("ProductCode"),
                        UserSession.Data("SubscriberId"),
                        "IndividualRemote",
                        "RemotePartial",
                        SelectedProducts.Rows(0)("CurrencyCode"))

            Me.AddSalesOrderLines(SelectedProducts)

            Me.Save()
            If TranStartedHere Then
                db.CommitTran()
            End If
        Catch ex As Exception
            If TranStartedHere Then
                db.RollbackTran()
            End If
            Throw New Exception("UserError: Add Sales Order failed", ex)
        End Try
    End Sub
    Sub AddSalesOrderLines(ByVal SelectedProducts As DataTable)
        'Add salesorder lines
        Dim recurringSubscriptionStartDate As Date = CDate("01-Jan-1900")
        Dim PrimaryProductUpdated As Boolean = False
        For Each rowData As DataRow In Me.SalesOrderLine.Rows
            Dim NotSelected As Boolean = True
            For Each rowSelected As DataRow In SelectedProducts.Rows
                If rowSelected("ProductCode") = rowData("ProductCode") Then
                    NotSelected = False
                    Exit For
                End If
            Next
            'If we havn't selected one of the rows already in the order then delete the row from the order
            If NotSelected Then
                rowData.Delete()
            End If
        Next

        '28/10/15   Julian Gates    SIR3987 - If selected products contains "PEPWEBS", "PEPWEB" set as PrimaryProductCode
        Dim primaryProductFound As Boolean = False
        For Each rowSelected As DataRow In SelectedProducts.Rows
            Select Case db.IsDBNull(rowSelected("ProductCode"), "").ToString.ToUpper
                Case "PEPWEBS", "PEPWEB"
                    Me.SalesOrderRow("PrimaryProductCode") = rowSelected("ProductCode")
                    primaryProductFound = True
                    Exit For
            End Select
        Next
        '5/1/21     James Woosnam   SIR5153 - Delete code which deleted SalesOrderLines as not required as done in AddSalesOrderline
        'if no primary product found then set non zero product as primary
        If Not primaryProductFound Then
            For Each rowSelected As DataRow In SelectedProducts.Rows
                If db.IsDBNull(rowSelected("ProductRate"), 0) <> 0 Then
                    Me.SalesOrderRow("PrimaryProductCode") = rowSelected("ProductCode")
                    primaryProductFound = True
                    Exit For
                End If
            Next
        End If

        For Each rowSelected As DataRow In SelectedProducts.Rows
            If Not PrimaryProductUpdated Then
                If Not primaryProductFound Then
                    Me.SalesOrderRow("PrimaryProductCode") = rowSelected("PrimaryProductCode")
                End If
                Me.SalesOrderRow("CurrencyCode") = rowSelected("CurrencyCode")
                Me.SalesOrderRow("SubscriptionStartDateForAdd") = rowSelected("NewRecurringSubscriptionStartDate")
                PrimaryProductUpdated = True
            End If
            Dim AlreadyInOrder As Boolean = False
            For Each rowData As DataRow In Me.SalesOrderLine.Rows
                If Not rowData.RowState = DataRowState.Deleted Then
                    If rowSelected("ProductCode") = rowData("ProductCode") Then
                        'If the product is already in the order then jsut do nothing
                        AlreadyInOrder = True
                        Exit For
                    End If
                End If
            Next
            If Not AlreadyInOrder Then
                'Add the product
                Dim newSalesOrderRow As DataRow = Me.SalesOrderLine.NewRow
                newSalesOrderRow("OrderNumber") = Me.OrderNumber
                newSalesOrderRow("SalesOrderLineId") = Me.db.GetNextNumber("SalesOrderLine")
                newSalesOrderRow("SubscriberId") = UserSession.Data("SubscriberId")
                newSalesOrderRow("ProductCode") = rowSelected("ProductCode")
                newSalesOrderRow("CreatedDateTime") = Now()
                newSalesOrderRow("CreatedByUserId") = UserSession.UserName20
                newSalesOrderRow("RecurringSubscriptionStartDate") = rowSelected("NewRecurringSubscriptionStartDate")
                newSalesOrderRow("RecurringSubscriptionEndDate") = rowSelected("NewRecurringSubscriptionEndDate")
                newSalesOrderRow("ProductRateId") = rowSelected("ProductRateId")
                '14/09/12 Julian Gates SIR2865 - Check if subscriber address exists before writing to database
                Dim subscriberAddressId As String = db.DLookup("SubscriberAddressId", "SubscriberAddress", "SubscriberId=" & UserSession.Data("SubscriberId") & " And AddressType='Postal' And AddressDescription='Main'", True)
                If subscriberAddressId = Nothing Then
                    newSalesOrderRow("DeliveryAddressId") = System.DBNull.Value
                Else
                    newSalesOrderRow("DeliveryAddressId") = subscriberAddressId
                End If
                newSalesOrderRow("ProductRate") = rowSelected("ProductRate")
                newSalesOrderRow("Quantity") = 1
                newSalesOrderRow("AmountProduct") = newSalesOrderRow("Quantity") * rowSelected("ProductRate")
                newSalesOrderRow("LastUpdatedDateTime") = Now()
                newSalesOrderRow("LastUpdatedByUserId") = UserSession.UserName20
                Me.SalesOrderLine.Rows.Add(newSalesOrderRow)
            End If
        Next
    End Sub

    Public Sub AddNewSalesOrderLine(Product As Product,
                                        SubscriberId As Integer,
                                        ProductRateId As Integer,
                                        RecurringStartDate As Date)

        Dim newSalesOrderRow As DataRow = Me.SalesOrderLine.NewRow
        newSalesOrderRow("OrderNumber") = Me.OrderNumber
        newSalesOrderRow("SalesOrderLineId") = Me.db.GetNextNumber("SalesOrderLine")
        newSalesOrderRow("SubscriberId") = UserSession.Data("SubscriberId")
        newSalesOrderRow("ProductCode") = Product.ProductCode
        newSalesOrderRow("CreatedDateTime") = Now()
        newSalesOrderRow("CreatedByUserId") = UserSession.UserName20
        newSalesOrderRow("RecurringSubscriptionStartDate") = RecurringStartDate
        newSalesOrderRow("RecurringSubscriptionEndDate") = Product.GetRecurringEndDate(RecurringStartDate)
        newSalesOrderRow("ProductRateId") = ProductRateId
        '14/09/12 Julian Gates SIR2865 - Check if subscriber address exists before writing to database
        Dim subscriberAddressId As String = db.DLookup("SubscriberAddressId", "SubscriberAddress", "SubscriberId=" & UserSession.Data("SubscriberId") & " And AddressType='Postal' And AddressDescription='Main'", True)
        If subscriberAddressId = Nothing Then
            newSalesOrderRow("DeliveryAddressId") = System.DBNull.Value
        Else
            newSalesOrderRow("DeliveryAddressId") = subscriberAddressId
        End If

        newSalesOrderRow("ProductRate") = db.DLookup("ProductRate", "ProductRate", "ProductRateId=" & ProductRateId)
        newSalesOrderRow("Quantity") = 1
        newSalesOrderRow("AmountProduct") = newSalesOrderRow("Quantity") * newSalesOrderRow("ProductRate")
        newSalesOrderRow("LastUpdatedDateTime") = Now()
        newSalesOrderRow("LastUpdatedByUserId") = UserSession.UserName20
        Me.SalesOrderLine.Rows.Add(newSalesOrderRow)
    End Sub
    Enum DespatchSQLPurposes
        Grid
        FileColumns
        FileFrom
    End Enum
    Public Function GetDespatchSubscriberSQL(SQLPurpose As DespatchSQLPurposes, ProductCode As String, DespatchDeliveryArea As String, UndespatchedOnly As Boolean) As String
        '8/2/22     James           Move GetDespatchSubscriberSQL function in SalesOrder Class
        Dim Sql As String = ""
        Dim newLine As String = Environment.NewLine
        If ProductCode = "" Then Return Sql
        Select Case SQLPurpose
            Case DespatchSQLPurposes.Grid
                Sql = "Select  SalesOrderLine.SubscriberId" & newLine
                Sql += "    ,s.SubscriberName" & newLine
                Sql += "    ,so.OrderNumber" & newLine
                Sql += "    ,so.OrderDate" & newLine
                Sql += "    ,DateDespatched = solp.DateDespatched"
            Case DespatchSQLPurposes.FileColumns
                Sql = "Select  SalesOrderLine.SubscriberId" & newLine
                Sql += "    ,ISNULL(FirstName,'') As FirstName" & newLine
                Sql += "    ,ISNULL(LastName,'') As LastName" & newLine
                Sql += "    ,EntityType" & newLine
                Sql += "    ,ChildProduct.ProductCode" & newLine
                Sql += "    ,SalesOrderLine.OrderNumber" & newLine
                Sql += "    ,sa.Address1" & newLine
                Sql += "    ,sa.Address2" & newLine
                Sql += "    ,sa.Address3" & newLine
                Sql += "    ,sa.Address4" & newLine
                Sql += "    ,sa.Town" & newLine
                Sql += "    ,sa.County" & newLine
                Sql += "    ,sa.PostCode" & newLine
                Sql += "    ,c.CountryName" & newLine
                Sql += "    ,SalesOrderLine.Quantity" & newLine
                Sql += "    ,Email.AddressText As EmailAddress" & newLine

        End Select
        Select Case SQLPurpose
            Case DespatchSQLPurposes.Grid, DespatchSQLPurposes.FileFrom
                Sql += " FROM SalesOrderLine SalesOrderLine" & newLine
                Sql += "	INNER JOIN Subscriber s" & newLine
                Sql += "    ON s.SubscriberId = SalesOrderLine.SubscriberId" & newLine
                Sql += "    INNER JOIN SalesOrder so" & newLine
                Sql += "    On so.OrderNumber = SalesOrderLine.OrderNumber" & newLine
                Sql += "    AND so.SalesOrderStatus = 'Confirmed'" & newLine
                Sql += "    LEFT JOIN SubscriberAddress sa" & newLine
                Sql += "    	LEFT JOIN Country c" & newLine
                Sql += "    	ON c.CountryId = sa.CountryId" & newLine
                Sql += "    ON sa.SubscriberAddressId = SalesOrderLine.DeliveryAddressID" & newLine
                Sql += "    Left JOIN SubscriberAddress Email" & newLine
                Sql += "    ON Email.SubscriberId = SalesOrderLine.SubscriberID" & newLine
                Sql += "    AND Email.AddressType = 'Email'" & newLine
                Sql += "    AND Email.AddressDescription = 'Main' " & newLine

                Sql += "    INNER JOIN Product ChildProduct" & newLine
                Sql += "    ON ChildProduct.ParentProductCode = SalesOrderLine.ProductCode" & newLine
                Sql += "    AND ChildProduct.ReleaseDate <= GetDate()" & newLine
                Sql += "    INNER JOIN Product ParentProduct" & newLine
                Sql += "    ON ParentProduct.ProductCode = ChildProduct.ParentProductCode" & newLine
                Sql += "    LEFT JOIN SalesOrderLinePart solp" & newLine
                Sql += "    ON solp.SalesOrderLineId = SalesOrderLine.SalesOrderLineID" & newLine
                Sql += "    AND solp.OrderNumber = SalesOrderLine.OrderNumber" & newLine
                Sql += "    AND solp.ProductCode = ChildProduct.ProductCode" & newLine
                If DespatchDeliveryArea <> "" Then
                    Sql += "    INNER JOIN DespatchDeliveryArea dda"
                    Sql += "    On dda.CountryId = sa.CountryId"
                    Sql += "	AND dda.CompanyId = so.CompanyId"
                    Sql += "	And dda.DespatchDeliveryArea = '" & DespatchDeliveryArea & "'"
                End If

                Sql += " WHERE SalesOrderLine.IsCancel = 0"
                Sql += " AND so.SalesOrderStatus = 'Confirmed'" & newLine
                Sql += " AND ChildProduct.ProductCode = '" & ProductCode & "'" & newLine

                If UndespatchedOnly Then
                    Sql += " AND solp.OrderNumber Is Null"
                End If
                '04/11/21   Julian Gates    SIR5354 - Only show non InActive Subscribers in despatch list 
                Sql += " AND s.SubscriberStatus <> 'InActive'"
        End Select


        Return Sql
    End Function
    Public Function SubmitDespatchSalesOrder(ByVal DespatchDeliveryArea As String _
                                            , ByVal ReportOnly As Boolean _
                                            , ByVal ProductCode As String) As Integer
        'Sumbits the job and returns the BatchJobId
        Dim BatchJobId As Integer = 0
        Try
            Dim BatchJob As BusinessLogic.BatchJob = Nothing
            BatchJob = New BusinessLogic.BatchJob(Me.db)
            BatchJob.SubmittedByUserSessionId = Me.UserSession.UserSessionIdGUID
            BatchJob.Parameters.Add("SubscribersToDespatchSQLColumns", GetDespatchSubscriberSQL(Me.DespatchSQLPurposes.FileColumns, ProductCode, DespatchDeliveryArea, Not ReportOnly))
            BatchJob.Parameters.Add("SubscribersToDespatchSQLFrom", GetDespatchSubscriberSQL(Me.DespatchSQLPurposes.FileFrom, ProductCode, DespatchDeliveryArea, Not ReportOnly))
            BatchJob.Parameters.Add("DespatchDeliveryArea", DespatchDeliveryArea)
            BatchJob.Parameters.Add("ProductCode", ProductCode)
            BatchJob.Parameters.Add("ReportOnly", ReportOnly)
            '21/1/21    James Woosnam   Add SecondaryConnectionString as it is needed for writing secondary audit log
            BatchJob.Parameters.Add("SecondaryConnectionString", db.SecondaryConnectionString)
            BatchJob.CreateBatchJobEntry("DespatchSalesOrder", db)
            BatchJobId = BatchJob.BatchJobId
        Catch ex As Exception
            Throw ex
        End Try
        Return BatchJobId
    End Function
    Public Sub ExecuteDespatchSalesOrder(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Try
            Me.ExecuteDespatchSalesOrder(BatchJobId _
                                             , CStr(Parameters.GetValue("SubscribersToDespatchSQLColumns")) _
                                             , CStr(Parameters.GetValue("SubscribersToDespatchSQLFrom")) _
                                             , CStr(Parameters.GetValue("DespatchDeliveryArea")) _
                                             , CBool(Parameters.GetValue("ReportOnly")) _
                                             , CStr(Parameters.GetValue("ProductCode")) _
                                             , New Guid(CStr(Parameters.GetValue("SubmittedByUserSessionId"))))
        Catch ex As Exception
            Throw ex
        End Try

    End Sub
    Public Sub ExecuteDespatchSalesOrder(ByVal BatchJobId As Integer _
                                             , ByVal SubscribersToDespatchSQLColumns As String _
                                             , ByVal SubscribersToDespatchSQLFrom As String _
                                             , ByVal DespatchDeliveryArea As String _
                                             , ByVal ReportOnly As Boolean _
                                             , ByVal ProductCode As String _
                                             , ByVal SubmittedByUserSessionId As Guid)
        Try
            Dim BatchLog = New BusinessLogic.BatchLog("DespatchSalesOrder" _
                                             , "ReportOnly=" & ReportOnly.ToString _
                                             , Me.db _
                                             , BatchJobId _
                                             , Me.UserSession.UserSessionIdGUID
                                             )
            Dim sql As String = ""

            sql = SubscribersToDespatchSQLColumns & SubscribersToDespatchSQLFrom
            'CSV Report
            Dim report As New BusinessLogic.ReportGeneric("MailingCSV", "GenericCSV", db, SubmittedByUserSessionId)
            report.Execute("", sql, sql, BatchLog)
            'Excel Report
            report = New BusinessLogic.ReportGeneric("MailingExcel", "GenericExcel", db, SubmittedByUserSessionId)
            report.Execute("GenericExcel.xlsx", sql, sql, BatchLog)
            BatchLog.Update("Report Created")

            '21/08/20   Julian Gates    SIR5099 - Add last Updated fields to ExecuteDespatchSalesOrder
            If Not ReportOnly Then
                Dim tbl As DataTable = db.GetDataTableFromSQL("SELECT DISTINCT SalesOrderLine.OrderNumber " & SubscribersToDespatchSQLFrom)
                '2/12/21    James Woosnam   SIR5359 - Populate SubscriberAddressId & AddressText in Despatch
                sql = "INSERT INTO SalesOrderLinePart" _
                        & "         ( OrderNumber" _
                        & "         , SalesOrderLineID" _
                        & "         , ProductCode" _
                        & "         , Quantity" _
                        & "         , DateDespatched" _
                        & "			, DespatchDeliveryArea" _
                        & "			, SubscriberAddressId" _
                        & "			, AddressText" _
                        & "			, LastUpdatedDateTime" _
                        & "			, LastUpdatedByUserId)" _
                        & " SELECT SalesOrderLine.OrderNumber" _
                        & "			,SalesOrderLine.SalesOrderLineId" _
                        & "         , ChildProduct.ProductCode" _
                        & "         , SalesOrderLine.Quantity" _
                        & "         , GetDate()" _
                        & "			, @DespatchDeliveryArea" _
                        & "			, sa.SubscriberAddressId" _
                        & "			, sa.AddressText" _
                        & "         , GetDate()" _
                        & "         , '" & Me.UserSession.UserName & "'" _
                        & SubscribersToDespatchSQLFrom
                Dim cmd As New SqlCommand(sql, db.DBConnection, db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DespatchDeliveryArea", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, DespatchDeliveryArea))
                cmd.ExecuteNonQuery()
                BatchLog.Update("SalesOrderLinePart lines written")

                Dim orderNos As String = ""
                For Each row As DataRow In tbl.Rows
                    Dim so As New SalesOrder(row("OrderNumber"), db, UserSession)
                    so.Save() '31/10/20 - this will set order to Complete if appropriate
                    orderNos += IIf(orderNos = "", "", ",") & so.OrderNumber
                Next
                BatchLog.Update("Orders saved to mark Complete if appropriate:" & orderNos)

                BatchLog.Update("Order Complete processing finished")
            End If
            BatchLog.Update("Despatch Complete", "Complete")
        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    '14/05/15   Julian Gates    SIR3838 - Add new SendEmailReceipt() to send email using SalesOrder data
    '03/06/16   Julian Gates    Fix Amount formatting to stop rounding
    '25/11/19   Julian Gates    SIR4942 - Get UserName from RemoteUser and remove web user password
    '12/07/21   Julian Gates    SIR5281 - Use DisplayProductName in SendEmailReceipt
    '11/4/22    James Woosnam   SIR5447 - Send Receipt Email for each product in Order
    Public Sub SendEmailReceipt()
        Dim row As DataRow = Nothing
        Try
            Dim sText As String = Nothing
            Dim sql As String = Nothing
            Dim receiptFile As String = Nothing
            '16/1/20    James Woosnam   SIR4995 - Remove postal address in SendEmailReceipt as not used
            '18/2/20    James Woosnam   SIR5024 - By default show the billing address on the receipt, else show the main(postal) address

            sql = "
    Select 
        SalesOrder.OrderNumber 
        ,sol.SalesOrderLineId
        ,Amount = SalesOrder.AmountGross
        ,Subscriber.Title
        ,Subscriber.FirstName
        ,Subscriber.LastName
        ,WebUserName = ru.UserName
        ,dbo.f530SubscriberAddressDisplay(SubscriberAddress.SubscriberAddressId ,'Multiline') AS Address
        ,Country.CountryName
        ,Email.AddressText As EmailAddress
        ,ProductName = ISNULL(Product.ProductName,'None')
        ,ProductCode = ISNULL(Product.ProductCode,'None')
        ,DisplayProductName = ISNULL(Product.DisplayProductName,'None')
     FROM SalesOrder
            INNER JOIN SalesOrderLine sol
			ON sol.OrderNumber = SalesOrder.OrderNumber
            INNER JOIN Subscriber  
                LEFT JOIN RemoteUserRights rur
                    INNER JOIN RemoteUser ru
                    ON rur.UserId = ru.UserId
                ON rur.rightsToId = Subscriber.SubscriberId
            ON Subscriber.SubscriberId = SalesOrder.SubscriberId 
	        INNER JOIN Product  
	        ON Product.ProductCode = sol.ProductCode 
            LEFT JOIN SubscriberAddress  
	            INNER JOIN Country  
	            ON Country.CountryId = SubscriberAddress.CountryId 
            ON SubscriberAddress.SubscriberAddressId = (SELECT MAX(ISNULL(sab.SubscriberAddressId,sap.SubscriberAddressId) )
                                                        FROM Subscriber s 
														    LEFT JOIN SubscriberAddress saB
														    ON saB.SubscriberId = s.SubscriberId 
														    AND saB.AddressType = 'Postal'
														    AND saB.AddressDescription = 'Billing'
														    LEFT JOIN SubscriberAddress saP
														    ON saP.SubscriberId = s.SubscriberId 
														    AND saP.AddressType = 'Postal'
														    AND saP.AddressDescription = 'Main'	
													    WHERE s.SubscriberId = Subscriber.SubscriberId )
            LEFT JOIN SubscriberAddress Email
            ON Email.SubscriberId = Subscriber.SubscriberId 
            AND Email.AddressType = 'Email' 
            AND Email.AddressDescription = 'Main' 
     WHERE SalesOrder.OrderType <> 'Block'
    AND SalesOrder.OrderNumber = " & Me.OrderNumber

            Dim tbl As DataTable = db.GetDataTableFromSQL(sql)

            If tbl.Rows.Count = 0 Then
                Throw New Exception("No sales order details found in SendReceiptEmail")
            End If
            For Each row In tbl.Rows
                '11/4/22    James Woosnam   SIR5447 - Send Receipt Email for each product in Order
                Try
                    receiptFile = db.GetParameterValue("ReportTemplateDirectory") & "\EmailReceipt" & Me.SalesOrderRow("CompanyId") & "_" & row("ProductCode") & ".htm"
                    'see if template is available for product
                    If System.IO.File.Exists(receiptFile) Then
                        sText = New BusinessLogic.StdCode().GetFileText(receiptFile)
                    Else
                        'use default template if product one not found
                        sText = New BusinessLogic.StdCode().GetFileText(db.GetParameterValue("ReportTemplateDirectory") & "\EmailReceipt" & Me.SalesOrderRow("CompanyId") & ".htm")
                    End If

                    Dim productName As String = Nothing
                    'output primary product name first
                    productName = row("DisplayProductName")

                    For Each col As DataColumn In tbl.Columns
                        If col.ColumnName = "Amount" Then
                            '03/06/16   Julian Gates    Fix Amount formatting to stop rounding
                            sText = sText.Replace("[Amount]", db.IsDBNull(Double.Parse(row(col.ColumnName)).ToString("N2"), ""))
                        Else
                            'populate ProductName field in Template with DisplayProductName
                            If col.ColumnName = "ProductName" Then
                                sText = sText.Replace("[" & col.ColumnName & "]", db.IsDBNull(row("DisplayProductName"), ""))
                            Else
                                sText = sText.Replace("[" & col.ColumnName & "]", db.IsDBNull(row(col.ColumnName), ""))
                            End If
                        End If
                    Next

                    Dim email As New BusinessLogic.Email(db)
                    Dim strEmailToAddress As String = row("EmailAddress")
                    If Not Me.db.IsOnLiveServer Then
                        Dim TestEmail As String = ""
                        Try
                            TestEmail = db.GetParameterValue("PEPRenewalEmailTestToAddress")
                        Catch ex As Exception
                            TestEmail = "Support@zedra.co.uk"
                        End Try
                        email.SendTo = strEmailToAddress.Substring(0, strEmailToAddress.IndexOf("@")) & TestEmail.Substring(TestEmail.IndexOf("@"), TestEmail.Length - TestEmail.IndexOf("@"))
                    Else
                        email.SendTo = strEmailToAddress
                    End If

                    email.Subject = "PaDS Receipt Email"
                    email.BCC = db.GetParameterValue("ReceiptBCCEmailAddressForCompanyId:" & Me.SalesOrderRow("CompanyId"))
                    email.From = db.GetParameterValue("EmailFromForCompanyId:" & Me.SalesOrderRow("CompanyId"))
                    email.IsBodyHTML = True
                    email.Body = sText
                    email.Send()
                    '11/4/22    James Woosnam    SIR5458 - AddToSubscriberEmailToDitributionLog 
                    Dim emailing As New BusinessLogic.Emailing(db)
                    Dim newEmailDistributionLogId As Integer = emailing.AddToSubscriberEmailToDitributionLog(EmailName:="OrderReceipt:" & row("ProductCode"),
                                                                    EmailSubject:=email.Subject,
                                                                    EmailBody:=email.Body,
                                                                    SendToEmailAddress:=strEmailToAddress,
                                                                    SubscriberId:=Me.SalesOrderRow("SubscriberId"),
                                                                    CompanyId:=Me.SalesOrderRow("CompanyId"),
                                                                    OrderNumber:=Me.OrderNumber,
                                                                    SalesOrderLineId:=row("SalesOrderLineId"),
                                                                    EmailDistributionStatus:="Successfull")

                Catch ex As Exception
                    Throw New Exception("SendEmailReceipt Failed for OrderNumber:" & Me.OrderNumber & " Prod:" & row("ProductCode") & ":" & ex.Message, ex)

                End Try

            Next

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Dim _ConfirmationEmailName As String = Nothing
    Public Property ConfirmationEmailName As String
        Get
            If _ConfirmationEmailName = Nothing Then
                _ConfirmationEmailName = "SalesOrder:" & Me.OrderNumber
            End If
            Return _ConfirmationEmailName
        End Get
        Set(value As String)
            _ConfirmationEmailName = value
        End Set
    End Property
    Public Sub PopulateAndSubmitBlockConfirmationEmail(Optional SendTestEmailToCurrentUserAndSubscriberId As Integer = 0)
        '15/12/21   James Woosnam   SIR5381 - Initial version of PopulateAndSubmitBlockConfirmationEmail
        '31/1/22    James Woosnam   SIR5422 - PopulateAndSubmitBlockConfirmationEmail Allow for ' hypen in names by using @ parameters and put in transaction so doesn't part populate log, and correct SQL left join to email log
        '07/03/22   Julian Gates    SIR5456 - Change @EmailBody to be -1 to match VarChar(Max) in DB.
        Try
            If SendTestEmailToCurrentUserAndSubscriberId <> 0 Then Me.ConfirmationEmailName = ConfirmationEmailName & "TEST" & Now.ToString("yyMMddHHmmss")
            Dim sText As String = Nothing
            Dim sql As String = Nothing
            Dim receiptFile As String = Nothing
            sql = "
    SELECT 
        so.OrderNumber 
        ,Amount = so.AmountGross
        ,s.Title
        ,s.FirstName
        ,s.LastName
        ,s.SubscriberId
        ,s.SubscriberName
        ,WebUserName = ru.UserName
        ,dbo.f530SubscriberAddressDisplay(Delivery.SubscriberAddressId ,'Multiline') AS Address
        ,Country.CountryName
        ,Email.AddressText As EmailAddress
        ,p.ProductName
        ,p.ProductCode
        ,p.DisplayProductName
        ,so.CompanyId
        ,OrdererSubscriberName = os.SubscriberName
        ,sol.SalesOrderLineId
     FROM SalesOrderLine sol
	    INNER JOIN SalesOrder so
            INNER JOIN Subscriber os
            ON os.SubscriberId = so.SubscriberId
	    ON so.OrderNumber = sol.OrderNumber 
        INNER JOIN Subscriber s
            LEFT JOIN RemoteUserRights rur
                INNER JOIN RemoteUser ru
                ON rur.UserId = ru.UserId
            ON rur.rightsToId = s.SubscriberId
        ON s.SubscriberId = sol.SubscriberId 
	    INNER JOIN Product p
	    ON p.ProductCode = sol.ProductCode 
        LEFT JOIN SubscriberAddress Delivery 
	        INNER JOIN Country  
	        ON Country.CountryId = Delivery.CountryId 
        ON Delivery.SubscriberAddressId = sol.DeliveryAddressId 
        LEFT JOIN SubscriberAddress Email
        ON Email.SubscriberId = s.SubscriberId 
        AND Email.AddressType = 'Email' 
        AND Email.AddressDescription = 'Main' 
        LEFT JOIN EmailDistributionLog e
        ON e.EmailName = '" & Me.ConfirmationEmailName & "'
        AND e.SubscriberId = sol.SubscriberId
        AND e.EmailDistributionStatus IN ('Successfull','NotSent')
     WHERE so.OrderNumber =" & Me.OrderNumber & "
     AND sol.IsCancel = 0
     --If SendTestEmailToCurrentUserAndSubscriberId<>0 then just that sub, otherwise exclude if already emailed
         " & IIf(SendTestEmailToCurrentUserAndSubscriberId = 0, " AND e.EmailDistributionLogId IS NULL", " AND sol.SubscriberId = " & SendTestEmailToCurrentUserAndSubscriberId) & "
     ORDER BY s.SubscriberName"

            Dim tbl As DataTable = db.GetDataTableFromSQL(sql)

            If tbl.Rows.Count = 0 Then
                Throw New Exception("There are no order lines that require sending.  It may be that the batch process is not running.")
            End If
            db.BeginTran()

            Try
                For Each row As DataRow In tbl.Rows
                    Try
                        receiptFile = db.GetParameterValue("ReportTemplateDirectory") & "\EmailReceipt" & Me.SalesOrderRow("CompanyId") & "_" & row("ProductCode") & ".htm"
                        'see if template is available for product
                        If Not System.IO.File.Exists(receiptFile) Then Throw New Exception("receiptFile:" & receiptFile & " can't be found")
                        If db.IsDBNull(row("EmailAddress"), "") = "" Then Throw New Exception("EmailAddress is blank")
                        Dim sBody As String = New BusinessLogic.StdCode().GetFileText(receiptFile)
                        For Each col As DataColumn In tbl.Columns
                            If col.ColumnName = "Amount" Then
                                '03/06/16   Julian Gates    Fix Amount formatting to stop rounding
                                sBody = sBody.Replace("[Amount]", db.IsDBNull(Double.Parse(row(col.ColumnName)).ToString("N2"), ""))
                            Else
                                'populate ProductName field in Template with DisplayProductName
                                If col.ColumnName = "ProductName" Then
                                    sBody = sBody.Replace("[" & col.ColumnName & "]", db.IsDBNull(row("DisplayProductName"), ""))
                                Else
                                    sBody = sBody.Replace("[" & col.ColumnName & "]", db.IsDBNull(row(col.ColumnName), ""))
                                End If
                            End If
                        Next

                        Dim sendToEmail As String = row("EmailAddress")
                        If SendTestEmailToCurrentUserAndSubscriberId <> 0 Then
                            sendToEmail = db.DLookup("EmailAddress", "RemoteUser", "UserId=" & Me.UserSession.UserId)
                        End If

                        'Status:          This must initially be set to NotSent
                        'EmailName:       Unique name for this batch of emails, used when invoking Ron from Test harness.
                        'TemplateFileName:Name of the template HTM file for this email that is stored in the main terms and conditions folder.  Fields from the table will be merged in to this file is surrounded by {{FieldName}}.  May need to check the text source as sometimes words can put in HTML between the {{ and the field name.
                        'EmailAddress:    This must be populated
                        'EmailSortOrder:  Can be use to dictate the order that the emails are sent, If NULL uses EmailDistributionLogId
                        '31/1/22    James Woosnam   SIR5422 - PopulateAndSubmitBlockConfirmationEmail Allow for ' hypen in names by using @ parameters and put in transaction so doesn't part populate log, and correct SQL left join to email log
                        sql = "
    INSERT INTO EmailDistributionLog (EmailDistributionStatus,EmailName,EmailFromAccount,EmailSubject,EmailBody,EmailAddress,EmailSortOrder,EmailFooterSystemText,TemplateFileName,SubscriberId,SubscriberName,FirstName,LastName,OrderNumber,SalesOrderLineId)
    SELECT EmailDistributionStatus='NotSent'
        ,EmailName='" & ConfirmationEmailName & "'
        ,EmailFromAccount='" & db.GetParameterValue("EmailFromForCompanyId:" & row("CompanyId")) & "'
        ,EmailSubject='Confirmation of " & row("DisplayProductName") & " via " & row("OrdererSubscriberName") & "'
        ,EmailBody = @EmailBody
        ,EmailAddress = @EmailAddress
        ,EmailSortOrder=1
        ,EmailFooterSystemText = '" & row("SubscriberId") & "-" & Me.OrderNumber & "'
        ,TemplateFileName = ''
        ,SubscriberId = " & row("SubscriberId") & "
        ,SubscriberName = @SubscriberName
        ,FirstName = @FirstName
        ,LastName = @LastName
        ,OrderNumber = " & row("OrderNumber") & "
        ,SalesOrderLineId = " & row("SalesOrderLineId") & "
    "
                        '07/03/22   Julian Gates    SIR5456 - Change @EmailBody to be -1 to match VarChar(Max) in DB.
                        Dim cmd As New SqlClient.SqlCommand(sql, db.DBConnection, db.DBTransaction)
                        cmd.Parameters.Add("@EmailAddress", System.Data.SqlDbType.VarChar, 100).Value = sendToEmail
                        cmd.Parameters.Add("@EmailBody", System.Data.SqlDbType.VarChar, -1).Value = sBody
                        cmd.Parameters.Add("@SubscriberName", System.Data.SqlDbType.VarChar, 150).Value = db.IsDBNull(row("SubscriberName"), "")
                        cmd.Parameters.Add("@FirstName", System.Data.SqlDbType.VarChar, 25).Value = db.IsDBNull(row("FirstName"), "")
                        cmd.Parameters.Add("@LastName", System.Data.SqlDbType.VarChar, 50).Value = db.IsDBNull(row("LastName"), "")
                        cmd.ExecuteNonQuery()

                    Catch ex As Exception
                        Throw New Exception("Creating EmailDistributionLog for SubscriberId:" & row("SubscriberId") & " failed:" & ex.Message)
                    End Try
                Next

                Dim emailing As New Emailing(db, UserSession)
                emailing.Submit(EmailName:=ConfirmationEmailName, EmailFromAccount:=db.GetParameterValue("EmailFromForCompanyId:" & tbl.Rows(0)("CompanyId")), NoOfEmailsInBatch:=80)
                Me.ConfirmationEmailName = "" 'reset so it forgets TEST version

                db.CommitTran()
            Catch ex As Exception
                db.RollbackTran()
                Throw ex
            End Try
        Catch ex As Exception

            Throw New Exception("PopulateAndSubmitBlockConfirmationEmail failed:" & ex.Message)
        End Try
    End Sub
    Public Sub AddSalesOrderLineRates()
        '1/8/20	James Woosnam	SIR5051 - Use this to add rates in order maint 3
        Try
            Dim sql As String = "
    UPDATE SalesOrderLine 
    set 
    ProductRateId = pr.ProductRateId 
    ,ProductRate = pr.ProductRate 
    From SalesOrderline sol
	    INNER JOIN SalesOrder so
	    ON so.OrderNumber = sol.OrderNumber 
	    INNER JOIN CompanyAccount
		    INNER JOIN Company
		    On Company.CompanyId = CompanyAccount.CompanyId
	    ON CompanyAccount.SubscriberId = so.Subscriberid
	    AND CompanyAccount.CompanyId = so.CompanyId
	    INNER JOIN SubscriberAffiliate
		    INNER JOIN Subscriber
		    ON Subscriber.SubscriberId = SubscriberAffiliate.ChildSubscriberid
	    ON SubscriberAffiliate.ParentSubscriberId = so.SubscriberID
	    AND GETDATE() BETWEEN SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate
	    LEFT JOIN DespatchDeliveryArea
	    On DespatchDeliveryArea.CountryId = Subscriber.PrimaryCountryId
	    AND DespatchDeliveryArea.CompanyId = so.CompanyId
	    INNER JOIN SubscriberAffiliate CompanyAffiliation
	    ON CompanyAffiliation.parentSubscriberId =  Company.GroupParentSubscriberId
	    AND CompanyAffiliation.ChildSubscriberId = SubscriberAffiliate.ChildSubscriberId
    --1/8/20	James Woosnam	SIR5051 - Use all is no delivery area
	    LEFT JOIN ProductRate pr
	    ON pr.ProductRateId = (SELECT MAX(ProductRate.ProductRateId )
						    FROM ProductRate 
						    WHERE ProductRate.ProductCode = sol.ProductCode
						    AND ProductRate.CurrencyCode = so.CurrencyCode
						    AND ProductRate.RateType = CompanyAccount.RateType
						    AND ProductRate.AccountType = CompanyAccount.AccountType
						    AND ProductRate.SubscriberCategory = CompanyAffiliation.SubscriberCategory
						    AND (ProductRate.DeliveryArea = DespatchDeliveryArea.DespatchDeliveryArea
							    OR (ProductRate.DeliveryArea <> DespatchDeliveryArea.DespatchDeliveryArea
								    AND ProductRate.DeliveryArea = 'All')
							    )
						    )		
    WHERE sol.ordernumber = " & Me.OrderNumber & "
    AND sol.ProductRateId IS NULL
    "
            db.ExecuteSQL(sql)
        Catch ex As Exception
            Throw New Exception("AddSalesOrderLineRates failed:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub CancelSalesOrderLine(SalesOrderLineId As Integer)
        Try
            For Each row As DataRow In Me.SalesOrderLine.Rows
                If row("SalesOrderLineId") = SalesOrderLineId Then
                    row("IsCancel") = True
                    row("CancelledDate") = Now()
                    Me.Save()
                    Exit Sub
                End If
            Next

        Catch ex As Exception
            Throw New Exception("CancelSalesOrderLine failed:" & ex.Message, ex)

        End Try
    End Sub
    Public Sub TerminateOrderSessions()
        '3/11/21    James Woosnam   SIR5338 - Terminate all sessions attached to this order
        'This doesn't need to be in a transaction as it is called for save and is in onw SQL command
        Try
            Dim sql As String = ""
            sql += " UPDATE UserSessionData"
            sql += " SET DataItemValue ="
            sql += "        Case "
            sql += "        WHEN DataItemName = 'LoggedIn' THEN 'False'"
            sql += "        WHEN DataItemName = 'Expires' AND CONVERT(DATETIME,DataItemValue) > GETDATE() THEN CONVERT(VARCHAR, GETDATE(),22)"
            sql += "        ELSE DataItemValue END"
            sql += " FROM UserSessionData"
            sql += " WHERE UserSessionId In (SELECT UserSessionId FROM UserSessionData us WHERE us.DataItemName = 'SubscriptionOrderNumber' And us.DataItemValue = " & Me.OrderNumber & ")"
            sql += " AND DataItemName IN ('LoggedIn','Expires')"
            db.ExecuteSQL(sql)
        Catch ex As Exception
            Throw New Exception("Suspend Order Sessions failed:" & ex.Message, ex)
        End Try
    End Sub
End Class
