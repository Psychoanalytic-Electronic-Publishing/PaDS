﻿'Modification History
'Jan 11     James Woosnam   Initial version
'29/7/11    Julian Gates    SIR2470 - Add new functionality to send renewal reminders for all web products
'01/05/12   Julian Gates    SIR2670 - Add new field ProductGroupingName to AddOrUpdateRenewalReminderLog.
'07/01/22   Julian Gates    SIR5262 - Enter dummy log entry for missing email subscriber for AddOrUpdateRenewalReminderLog.

Public Class SendRenewalEmail
    Inherits BatchJobBase
#Region "Class Properties"
    Dim BatchJobId As Integer = Nothing
    Dim SentEmailsCount As Integer = 0

#End Region

    Public Sub New(ByVal JobName As String, ByVal db As BusinessLogic.Database)
        MyBase.New(JobName, db)
    End Sub

    Public Overloads Sub Submit()

        Dim batchjob As New BusinessLogic.BatchJob(Me.db)

        batchjob.CreateBatchJobEntry("SendRenewalEmail", Me.db)

    End Sub

    Public Overloads Sub Execute(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.Execute()
    End Sub

    Public Overloads Sub Execute()

        Me.BatchLog = New BatchLog("SendRenewalEmail" _
                                     , "" _
                                     , Me.db _
                                     , Me.BatchJobId)

        Try
            SendProductRenewalNotification()
            BatchLog.Update(SentEmailsCount & " emails sent in total")
            '5/4/11 James Wosonam   Email is no longer required as Pads checks takes in renewals and will fail if no renewals for 3 days
            'Try
            '    Dim email As New BusinessLogic.Email(db)
            '    email.SendErrorEmail("PEP Renewals", "BatchLogId:" & Me.BatchLog.BatchLogId & ", " & SentEmailsCount & " emails sent in total")
            'Catch ex As Exception
            'End Try
            BatchLog.Update("Complete", "Complete")
        Catch ex As Exception
            BatchLog.Update("SendRenewalEmail Failed:" & ex.ToString, "Failed")
            Throw New Exception("SendRenewalEmail Failed:" & ex.ToString)
        End Try
    End Sub
    Public Sub SendProductRenewalNotification()
        Dim Body As String = ""
        Dim Subject As String = ""
        Dim sql As String = "EXEC sp236SubscribersRequiringReminders"
        Dim stdCode As New BusinessLogic.StdCode
        Dim tblSubscribers As DataTable = Me.db.GetDataTableFromSQL(sql)
        BatchLog.Update(tblSubscribers.Rows.Count & " emails to be sent")
        For Each rowSubscriber As DataRow In tblSubscribers.Rows
            Dim ReminderType As String = CStr(rowSubscriber("ReminderType")).ToUpper
            Select Case ReminderType
                Case "FIRST"
                    Subject = " Your WEB Product subscription is due to expire in 6 weeks"
                    Body = stdCode.GetFileText(db.GetParameterValue("TermsConditionsDirectoryPhysicalPath") & "PEPRenewalReminderFirstEmailText.htm")
                Case "SECOND"
                    Subject = " Your WEB Product subscription is due to expire in 2 weeks"
                    Body = stdCode.GetFileText(db.GetParameterValue("TermsConditionsDirectoryPhysicalPath") & "PEPRenewalReminderSecondEmailText.htm")
                Case Else
                    Throw New Exception("Invalid reminder type:'" & ReminderType & "'")
            End Select
            If Body = "" Then
                Throw New Exception("Can't find HTML body file PEPRenewalReminderEmailText.htm or file is empty")
            End If

            '29/7/11 Julian Gates SIR2470 - Add new functionality to send renewal reminders for all web products
            Body = Body.Replace("{{ProductGroupingName}}", rowSubscriber("ProductGroupingName"))
            Body = Body.Replace("{{CurrentSubscriptionEndDate}}", CDate(rowSubscriber("CurrentSubscriptionEndDate")).ToString("dd-MMM-yyyy"))
            Body = Body.Replace("{{SystemText}}", "SubscriberId: " & rowSubscriber("SubscriberId") & " Order: " & rowSubscriber("CurrentSubscriptionOrderNumber"))

            Try
                '07/01/22   Julian Gates    SIR5262 - If email address missing send notification to support and create dummy log entry
                If db.IsDBNull(rowSubscriber("EmailAddress"), "") = "" Then
                    Subject = " Send Product Renewal Notification for " & ReminderType & " was unable to be sent"
                    Body = String.Format("Email Address Blank for SubscriberId:{0} OrderId:{1}", rowSubscriber("SubscriberId"), rowSubscriber("CurrentSubscriptionOrderNumber"))
                    SendMissingAddressToSupportEMail(Subject, Body)
                    AddOrUpdateRenewalReminderLog(rowSubscriber("CurrentSubscriptionOrderNumber"), rowSubscriber("SubscriberId"), ReminderType, rowSubscriber("ProductGroupingName"))
                    BatchLog.Update(" SID:" & rowSubscriber("SubscriberId") & " " & rowSubscriber("ReminderType") & " email was not sent as has missing email address.")
                Else
                    Dim email As String = rowSubscriber("EmailAddress")

                    SendRenewalEmail(Subject, Body, email)
                    '11/4/22    James Woosnam    SIR5458 - AddToSubscriberEmailToDitributionLog 
                    Dim emailing As New BusinessLogic.Emailing(db)
                    Dim newEmailDistributionLogId As Integer = emailing.AddToSubscriberEmailToDitributionLog(EmailName:="RenewalReminder" & rowSubscriber("ReminderType"),
                                                                                    EmailSubject:=Subject,
                                                                                    EmailBody:=Body,
                                                                                    SendToEmailAddress:=email,
                                                                                    SubscriberId:=rowSubscriber("SubscriberId"),
                                                                                    CompanyId:=db.DLookup("CompanyId", "SalesOrder", "OrderNumber=" & rowSubscriber("CurrentSubscriptionOrderNumber")),
                                                                                    OrderNumber:=rowSubscriber("CurrentSubscriptionOrderNumber"),
                                                                                    SalesOrderLineId:=rowSubscriber("SalesOrderLineId"),
                                                                                    EmailDistributionStatus:="Successfull")

                    AddOrUpdateRenewalReminderLog(rowSubscriber("CurrentSubscriptionOrderNumber"), rowSubscriber("SubscriberId"), ReminderType, rowSubscriber("ProductGroupingName"), email)

                    BatchLog.Update(email & " SID:" & rowSubscriber("SubscriberId") & rowSubscriber("ReminderType") & " email sent.")
                    SentEmailsCount += 1
                End If
            Catch ex As Exception
                Throw New Exception("Subscription renewal email failed " & ex.ToString)
            End Try
        Next

    End Sub

    Public Sub SendRenewalEmail(ByVal strSubject As String _
                                , ByVal strMessage As String _
                                , ByRef strEmailToAddress As String
                                )

        'Sends reminder email to subscriber and blind copy to PEP.
        Dim email As New BusinessLogic.Email(db)
        If Not Me.db.IsOnLiveServer Then
            Dim TestEmail As String = ""
            Try
                TestEmail = db.GetParameterValue("PEPRenewalEmailTestToAddress")
            Catch ex As Exception
                TestEmail = "Support@zedra.co.uk"
            End Try
            strEmailToAddress = strEmailToAddress.Substring(0, strEmailToAddress.IndexOf("@")) & TestEmail.Substring(TestEmail.IndexOf("@"), TestEmail.Length - TestEmail.IndexOf("@"))
        End If
        email.SendTo = strEmailToAddress
        email.From = "sales@psychoanalystdatabase.com"
        'newMessage.From = "support@zedra.co.uk"
        If db.IsOnLiveServer Then
            email.BCC = db.GetParameterValue("PEPRenewalEmailBCCAddress")
        End If
        email.Subject = strSubject

        email.IsBodyHTML = True

        email.Body = strMessage

        email.Send()

    End Sub
    Sub SendMissingAddressToSupportEMail(ByVal strSubject As String, ByVal strMessage As String)
        Try
            Dim email As New BusinessLogic.Email(Me.db)
            email.IsBodyHTML = True
            email.SendErrorEmail(strSubject, strMessage)

        Catch ex As Exception
            Throw New Exception(strMessage & "<BR>" & "Email Failed:" & "<BR>" & ex.ToString)
        End Try
    End Sub

    Public Sub AddOrUpdateRenewalReminderLog(ByVal OrderNumber As Integer _
                                            , ByVal SubscriberId As Integer _
                                            , ByVal ReminderType As String _
                                            , ByVal ProductGroupingName As String _
                                            , Optional ByVal EmailAddress As String = "" _
                                            )

        'Adds or updates RenewalReminderLog if email sent
        Dim sql As String = ""
        Dim cmdAddOrUpdate As New SqlClient.SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
        Try
            '07/01/22   Julian Gates    SIR5262 - Enter dummy log entry for missing email subscriber for AddOrUpdateRenewalReminderLog.
            If EmailAddress = "" Then
                sql = "INSERT INTO RenewalReminderLog ("
                sql += "  OrderNumber"
                sql += " , SubscriberId"
                sql += " , EmailAddress"
                sql += " , FirstReminderSentDate"
                sql += " , ProductGroupingName)"

                sql += "VALUES("
                sql += " @OrderNumber"
                sql += ",@SubscriberId"
                sql += ",'MISSING'"
                sql += ",NULL"
                sql += ",@ProductGroupingName"
                sql += ")"
            Else
                Select Case ReminderType
                    Case "FIRST"
                        sql = "INSERT INTO RenewalReminderLog ("
                        sql += "  OrderNumber"
                        sql += " , SubscriberId"
                        sql += " , EmailAddress"
                        sql += " , FirstReminderSentDate"
                        sql += " , ProductGroupingName)"

                        sql += "VALUES("
                        sql += " @OrderNumber"
                        sql += ",@SubscriberId"
                        sql += ",@EmailAddress"
                        sql += ",GetDate()"
                        sql += ",@ProductGroupingName"
                        sql += ")"
                        cmdAddOrUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailAddress", System.Data.SqlDbType.VarChar, 500, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current _
                                                                                         , EmailAddress))

                    Case "SECOND"
                        sql = "UPDATE RenewalReminderLog"
                        sql += " SET SecondReminderSentDate = GetDate()"
                        sql += " WHERE OrderNumber =@OrderNumber"
                        sql += " AND SubscriberId =@SubscriberId"
                        sql += " AND ProductGroupingName =@ProductGroupingName"
                End Select
            End If
            cmdAddOrUpdate.CommandText = sql
            cmdAddOrUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OrderNumber", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current _
                                                                                    , OrderNumber))
            cmdAddOrUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current _
                                                                                    , SubscriberId))
            cmdAddOrUpdate.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProductGroupingName", System.Data.SqlDbType.VarChar, 25, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current _
                                                                                , ProductGroupingName))

            cmdAddOrUpdate.ExecuteNonQuery()

        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Sub

End Class
