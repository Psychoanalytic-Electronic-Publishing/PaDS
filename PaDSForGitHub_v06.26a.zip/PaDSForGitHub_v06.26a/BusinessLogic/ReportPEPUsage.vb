﻿'Modification History
'Feb 2018       James Woosnam   SIR4571 - Initial Version
'21/3/22	    James Woosnam	SIR5463 - Change AffiliateRate to ReportingParent
Imports System.Data.SqlClient

Public Class ReportPEPUsage
    Inherits ReportSSG
#Region "Class Properties"
    Dim BatchJobId As Integer = Nothing
    Dim StartMonth As String = Nothing
    Dim EndMonth As String = Nothing
    Public PEPUsageReportType As PEPUsageReportTypes = Nothing
    Public ReportingParentSubscriberId As Integer = Nothing
    Enum PEPUsageReportTypes
        PEPUsageSummaryByReportingParent
        PEPUsageDetailByReportingParent
        PEPUsageSingleReportingParentDetail
    End Enum



#End Region
    Public Sub New(ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New(db, SubmittedByUserSessionId)
    End Sub
    Public Sub New(ByVal StartMonth As String, ByVal EndMonth As String, PEPUsageReportType As PEPUsageReportTypes, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New(PEPUsageReportType.ToString, "Excel", db, SubmittedByUserSessionId)
        Me.PEPUsageReportType = PEPUsageReportType
        Me.StartMonth = StartMonth
        Me.EndMonth = EndMonth
    End Sub

    'BatchJob  Submit & Execute not required for now
    Public Overloads Sub Submit(ReportingParentSubscriberId As Integer)
        Me.ReportingParentSubscriberId = ReportingParentSubscriberId

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSessionId
        BatchJob.Parameters.Add("ReportName", Me.PEPUsageReportType)
        BatchJob.Parameters.Add("PEPUsageReportType", Me.PEPUsageReportType)
        BatchJob.Parameters.Add("StartMonth", StartMonth)
        BatchJob.Parameters.Add("EndMonth", EndMonth)
        BatchJob.Parameters.Add("ReportingParentSubscriberId", ReportingParentSubscriberId)
        BatchJob.CreateBatchJobEntry("PEPUsageReport", Me.db)

    End Sub

    Public Overloads Sub Execute(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.JobParameters = Parameters
        Me.StartMonth = Parameters.GetValue("StartMonth")
        Me.EndMonth = Parameters.GetValue("EndMonth")
        Me.EndMonth = Parameters.GetValue("EndMonth")
        Me.PEPUsageReportType = Parameters.GetValue("PEPUsageReportType")
        Me.ReportName = Me.PEPUsageReportType.ToString
        Me.ReportType = "Excel"
        Me.BuildReport(Parameters.GetValue("ReportingParentSubscriberId"))
    End Sub
    Public ReadOnly Property SQL As String
        Get
            If Me.ReportSQL = "" Then
                Me.ReportSQL = "EXEC sp457GetPEPUsageView 
                    @StartMonth = " & db.vFQ(StartMonth, "s") & "
					,@EndMonth = " & db.vFQ(EndMonth, "s") & "
					,@ViewType = '" & Me.PEPUsageReportType.ToString.Replace("PEPUsage", "") & "'"
                If ReportingParentSubscriberId <> Nothing Then Me.ReportSQL += ",@ReportingParentSubscriberId=" & ReportingParentSubscriberId
            End If
            Return Me.ReportSQL
        End Get

    End Property
    Public Sub BuildReport(ReportingParentSubscriberId As Integer, Optional ByVal InBatchLog As BatchLog = Nothing)
        Me.ReportingParentSubscriberId = ReportingParentSubscriberId
        Dim batchLogCreatedHere As Boolean = False
        If InBatchLog Is Nothing Then
            Me.BatchLog = New BatchLog("Report-" & Me.ReportName _
                                          , ";StartMonth=" & Me.StartMonth _
                                         & ";EndMonth=" & Me.EndMonth _
                                         , Me.db _
                                         , BatchJobId _
                                         , Me.SubmittedByUserSessionId)
            batchLogCreatedHere = True
        Else
            Me.BatchLog = InBatchLog
        End If
        Try
            MyBase.Execute(Me.BatchLog)

            Dim ReportingParentSubscriberName As String = db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & ReportingParentSubscriberId)


            Dim HeaderSQL As String = "SELECT
                 StartMonth = '" & Me.StartMonth & "'
                 ,EndMonth = '" & Me.EndMonth & "'
                 ,Title = 'PEP Usage " & IIf(Me.PEPUsageReportType = PEPUsageReportTypes.PEPUsageDetailByReportingParent, " ReportingParent Summary", " for " & ReportingParentSubscriberName) & "'
"
            BatchLog.Update("HeaderSQL:" & HeaderSQL)


            Dim repPiv As New BusinessLogic.ReportGeneric(Me.ReportName, "GenericPivot", db, New Guid(CStr(JobParameters.GetValue("SubmittedByUserSessionId"))))
            BatchLog.Update("ReportName:" & Me.ReportName)
            repPiv.FileName = Me.PEPUsageReportType.ToString & " " & IIf(ReportingParentSubscriberId <> 0, ReportingParentSubscriberName & " ", "") & StartMonth & " To " & EndMonth
            BatchLog.Update("FileName:" & repPiv.FileName)

            repPiv.Execute(Me.ReportName & ".xltm", HeaderSQL, SQL, BatchLog)

            If batchLogCreatedHere Then
                BatchLog.Update("Process Complete", "Complete")
            End If
        Catch ex As Exception
            BatchLog.Update("Report Failed:" & ex.Message, "Failed")
            Throw New Exception("Report Failed:" & ex.Message, ex)

        End Try
    End Sub


    Dim _ReportData As DataTable = Nothing

    'ReadOnly Property ReportData() As DataTable
    '    Get
    '        Try
    '            If _ReportData Is Nothing Then

    '                _ReportData = db.GetDataTableFromSQL(Me.ReportSQL)
    '            End If

    '            Return _ReportData
    '        Catch ex As Exception
    '            Throw New Exception("GetDataTable failed:" & ex.Message)
    '        End Try
    '    End Get
    'End Property
    Public Sub SubmitPopulatePEPUsage()
        Try
            Dim BatchJob As New BusinessLogic.BatchJob(db)
            BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSession.UserSessionIdGUID
            BatchJob.CreateBatchJobEntry("PopulatePEPUsage", db)
        Catch ex As Exception
            Throw New Exception("SubmitPopulatePEPUsage failed:" & ex.Message)
        End Try
    End Sub
    Public Sub ExecutePopulatePEPUsage(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        BatchLog = New BatchLog("PopulatePEPUsage", "", Me.db, BatchJobId)

        Try
            Dim PEPWebCont As New PEPwebContent(db, Me.SubmittedByUserSession)
            If db.IsOnLiveServer Then PEPWebCont.ExecuteGetPEPWebSessionLog(Me.BatchJobId, Parameters)
            BatchLog.Update("sp456PopulatePEPUsage Starting")
            Dim cmd As New SqlCommand("sp456PopulatePEPUsage", db.DBConnection, db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandTimeout = 36000
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchLogId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      BatchLog.BatchLogId))
            cmd.ExecuteNonQuery()

            BatchLog.Update("PopulatePEPUsage Complete", "Complete")

        Catch ex As Exception
            BatchLog.Update("PopulatePEPUsage failed:" & ex.Message, "Failed")
            Throw New Exception(ex.ToString)
        End Try

    End Sub
End Class
