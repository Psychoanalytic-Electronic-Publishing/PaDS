﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class ContentSet
    'May 2020   James Woosnam   SIR5039 - Initial Version
    '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified also add UserSession to class

#Region "Class Properties"
    Public MainDataset As New DataSet
    Public ReadonlyDataset As New DataSet
    Dim UserSession As UserSession

    Dim _ContentSetId As Long = Nothing
    Public Property ContentSetId() As Integer
        Get
            If Me._ContentSetId = Nothing Then
                If Me.MainDataset.Tables.Count > 0 Then
                    Me._ContentSetId = Me.ContentSetRow("ContentSetId")
                End If
            End If
            Return Me._ContentSetId
        End Get
        Set(ByVal value As Integer)
            _ContentSetId = value
        End Set
    End Property
    Public ReadOnly Property ContentSetName As String
        Get

            Return Me.ContentSetRow("ContentSetName")
        End Get
    End Property
    Public Enum ContentSetStates
        Initial
        Active
        InActive
    End Enum
    Public Property ContentSetStatus() As ContentSetStates
        Get
            Return [Enum].Parse(GetType(ContentSetStates), Me.ContentSetRow("ContentSetStatus"))
        End Get
        Set(ByVal value As ContentSetStates)
            Me.ContentSetRow("ContentSetStatus") = value.ToString
        End Set
    End Property
    Public Enum ContentSetSourceTypes
        NotSelected
        Journal
        Book
        Video
    End Enum

    Private Sub Initilise()
        Dim xx As Integer = 0
        Me.MainDataset = New DataSet
        Me._daContentSet = Nothing
        Me._daContentSetSource = Nothing
        xx = Me.ContentSet.Rows.Count
        xx = Me.ContentSetSource.Rows.Count
    End Sub

    Private _db As Database = Nothing
    Public Property db() As Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As Database)

            Me._db = value
        End Set
    End Property
#End Region

#Region "DependantTables"
    '***********************************************
    'ContentSet
    Public ReadOnly Property ContentSet() As DataTable
        Get
            If Me.MainDataset.Tables("ContentSet") Is Nothing Then
                Me.daContentSet.Fill(Me.MainDataset, "ContentSet")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("ContentSet").Columns("ContentSetId")}
            Me.MainDataset.Tables("ContentSet").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("ContentSet")
        End Get
    End Property
    Private _daContentSet As SqlDataAdapter

    Private ReadOnly Property daContentSet() As SqlDataAdapter
        Get
            If Me._daContentSet Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM ContentSet"
                sql += " WHERE ContentSetId=" & Me.ContentSetId
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daContentSet = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daContentSet)
                _daContentSet.UpdateCommand = cmdBld.GetUpdateCommand()
                _daContentSet.InsertCommand = cmdBld.GetInsertCommand()
                _daContentSet.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daContentSet.InsertCommand.Transaction = Me.db.DBTransaction
                _daContentSet.UpdateCommand.Transaction = Me.db.DBTransaction
                _daContentSet.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daContentSet
        End Get
    End Property

    Public ReadOnly Property ContentSetRow() As DataRow
        Get
            If Me.ContentSet.Rows.Count = 0 Then
                Me.daContentSet.Fill(Me.MainDataset.Tables("ContentSet"))
                If Me.ContentSet.Rows.Count = 0 Then
                    Throw New Exception("UserError: ContentSetId:" & Me.ContentSetId & " can't be found")
                End If
            End If
            Return Me.ContentSet.Rows(0)
        End Get
    End Property


    '***********************************************
    'ContentSetSource
    Public ReadOnly Property ContentSetSource() As DataTable
        Get
            If Me.MainDataset.Tables("ContentSetSource") Is Nothing Then
                Me.daContentSetSource.Fill(Me.MainDataset, "ContentSetSource")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("ContentSetSource").Columns("ContentSetSourceId")}
            Me.MainDataset.Tables("ContentSetSource").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("ContentSetSource")
        End Get
    End Property
    Private _daContentSetSource As SqlDataAdapter
    Public ReadOnly Property daContentSetSource() As SqlDataAdapter
        Get
            If Me._daContentSetSource Is Nothing Then
                Dim sql As String = ""
                sql = "SELECT *"
                sql += " FROM ContentSetSource"
                sql += " WHERE ContentSetId = " & Me.ContentSetId
                sql += " ORDER BY ContentSetSourceId"
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daContentSetSource = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daContentSetSource)
                _daContentSetSource.UpdateCommand = cmdBld.GetUpdateCommand()
                _daContentSetSource.InsertCommand = cmdBld.GetInsertCommand()
                _daContentSetSource.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daContentSetSource.InsertCommand.Transaction = Me.db.DBTransaction
                _daContentSetSource.UpdateCommand.Transaction = Me.db.DBTransaction
                _daContentSetSource.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daContentSetSource
        End Get
    End Property
    Public Function ContentSetSourceRow(ByVal ContentSetSourceType As ContentSetSourceTypes) As DataRow
        Me.ContentSetId = ContentSetId
        For Each row As DataRow In Me.ContentSetSource.Rows
            If row("SourceType") = ContentSetSourceType.ToString Then
                Return row
            End If
        Next
        Return Nothing
    End Function

    '***********************************************

    '***********************************************
    'ContentSetSourceItem
    Public ReadOnly Property ContentSetSourceItem() As DataTable
        Get
            If Me.MainDataset.Tables("ContentSetSourceItem") Is Nothing Then
                Me.daContentSetSourceItem.Fill(Me.MainDataset, "ContentSetSourceItem")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("ContentSetSourceItem").Columns("ContentSetSourceItemId")}
            Me.MainDataset.Tables("ContentSetSourceItem").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("ContentSetSourceItem")
        End Get
    End Property
    Private _daContentSetSourceItem As SqlDataAdapter
    Public ReadOnly Property daContentSetSourceItem() As SqlDataAdapter
        Get
            If Me._daContentSetSourceItem Is Nothing Then
                Dim sql As String = ""
                sql = "SELECT *"
                sql += " FROM ContentSetSourceItem"
                sql += " WHERE ContentSetSourceId in (SELECT ContentSetSourceId FROM ContentSetSource WHERE  ContentSetId = " & Me.ContentSetId & ")"
                sql += " ORDER BY ContentSetSourceItemId"
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daContentSetSourceItem = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daContentSetSourceItem)
                _daContentSetSourceItem.UpdateCommand = cmdBld.GetUpdateCommand()
                _daContentSetSourceItem.InsertCommand = cmdBld.GetInsertCommand()
                _daContentSetSourceItem.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daContentSetSourceItem.InsertCommand.Transaction = Me.db.DBTransaction
                _daContentSetSourceItem.UpdateCommand.Transaction = Me.db.DBTransaction
                _daContentSetSourceItem.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daContentSetSourceItem
        End Get
    End Property
    Public Function GetSourceItemsSQL(SourceType As ContentSetSourceTypes) As String
        Dim sql As String = ""
        Select Case SourceType
            Case ContentSetSourceTypes.Journal
                sql = "
                SELECT
	                value = ISNULL(cssi.DocumentId,cj.PEPCode + CASE WHEN cv.PEPCode IS NULL THEN '' ELSE '.' + cv.vol END)
	                ,text = ISNULL(cssi.DocumentId,cj.PEPCode + CASE WHEN cv.PEPCode IS NULL THEN '' ELSE '.' + cv.vol END)
                        + '-' + ISNULL(cd.documentRef,cj.title + CASE WHEN cv.PEPCode IS NULL THEN '' ELSE '- Volume:' + cv.vol + ' ' + cv.year END)
                FROM ContentSetSourceItem cssi
	                INNER JOIN ContentSetSource css
	                ON css.ContentSetSourceId = cssi.ContentSetSourceId 
	                LEFT JOIN ContentJournals cj
	                ON cj.PEPCode = cssi.ContentCode 
	                LEFT JOIN ContentVolumes cv
	                ON cv.PEPCode = cssi.ContentCode 
	                AND cv.vol = cssi.Volume 
                    LEFT JOIN ContentDocuments cd
	                ON cd.documentID = cssi.DocumentId 
                WHERE css.SourceType = 'Journal'
                AND css.ContentSetId = " & Me.ContentSetId & "
                ORDER BY 2"
            Case Else
                sql = "
                SELECT
	                value = cssi.ContentCode
	                ,text = cssi.ContentCode + '-' + ISNULL(cd.Title,'')
                FROM ContentSetSourceItem cssi
	                INNER JOIN ContentSetSource css
	                ON css.ContentSetSourceId = cssi.ContentSetSourceId 
	                LEFT JOIN Content" & SourceType.ToString & "s cd
	                ON cd.PEPCode = cssi.ContentCode 
                WHERE css.SourceType = '" & SourceType.ToString & "'
                AND css.ContentSetId = " & Me.ContentSetId & "
                ORDER BY 2"

        End Select
        Return sql
    End Function


    '***********************************************
    'ContentSetAccessClassification
    Public ReadOnly Property ContentSetAccessClassification() As DataTable
        Get
            If Me.MainDataset.Tables("ContentSetAccessClassification") Is Nothing Then
                Me.daContentSetAccessClassification.Fill(Me.MainDataset, "ContentSetAccessClassification")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("ContentSetAccessClassification").Columns("ContentSetAccessClassificationId")}
            Me.MainDataset.Tables("ContentSetAccessClassification").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("ContentSetAccessClassification")
        End Get
    End Property
    Private _daContentSetAccessClassification As SqlDataAdapter
    Public ReadOnly Property daContentSetAccessClassification() As SqlDataAdapter
        Get
            If Me._daContentSetAccessClassification Is Nothing Then
                Dim sql As String = ""
                sql = "SELECT *"
                sql += " FROM ContentSetAccessClassification"
                sql += " WHERE ContentSetId = " & Me.ContentSetId
                sql += " ORDER BY ContentSetAccessClassificationId"
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daContentSetAccessClassification = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daContentSetAccessClassification)
                _daContentSetAccessClassification.UpdateCommand = cmdBld.GetUpdateCommand()
                _daContentSetAccessClassification.InsertCommand = cmdBld.GetInsertCommand()
                _daContentSetAccessClassification.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daContentSetAccessClassification.InsertCommand.Transaction = Me.db.DBTransaction
                _daContentSetAccessClassification.UpdateCommand.Transaction = Me.db.DBTransaction
                _daContentSetAccessClassification.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daContentSetAccessClassification
        End Get
    End Property


    '***********************************************
#End Region

    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.ContentSetId = 0
    End Sub
    Sub New(ByVal ContentSetId As Integer, ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.ContentSetId = ContentSetId
        Me.Initilise()
    End Sub

#Region "Actions"
    Public Sub Save()
        Dim sql As String = ""
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
            Select Case Me.ContentSetRow.RowState
                Case DataRowState.Added, DataRowState.Modified
                    ContentSetRow("LastUpdatedDateTime") = Now()
                    ContentSetRow("LastUpdatedByUserId") = UserSession.UserName20
            End Select
            Me.daContentSet.Update(Me.MainDataset, "ContentSet")

            If Me.MainDataset.Tables("ContentSetSource") IsNot Nothing Then
                '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
                For Each row As DataRow In Me.MainDataset.Tables("ContentSetSource").Rows
                    Select Case row.RowState
                        Case DataRowState.Added, DataRowState.Modified
                            row("LastUpdatedDateTime") = Now()
                            row("LastUpdatedByUserId") = UserSession.UserName20
                    End Select
                Next
                Me.daContentSetSource.Update(Me.MainDataset, "ContentSetSource")
            End If
            If Me.MainDataset.Tables("ContentSetSourceItem") IsNot Nothing Then
                For Each row As DataRow In Me.MainDataset.Tables("ContentSetSourceItem").Rows
                    Select Case row.RowState
                        Case DataRowState.Added, DataRowState.Modified
                            row("LastUpdatedDateTime") = Now()
                            row("LastUpdatedByUserId") = UserSession.UserName20
                    End Select
                Next
                Me.daContentSetSourceItem.Update(Me.MainDataset, "ContentSetSourceItem")
            End If
            If Me.MainDataset.Tables("ContentSetAccessClassification") IsNot Nothing Then
                '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
                For Each row As DataRow In Me.MainDataset.Tables("ContentSetAccessClassification").Rows
                    Select Case row.RowState
                        Case DataRowState.Added, DataRowState.Modified
                            row("LastUpdatedDateTime") = Now()
                            row("LastUpdatedByUserId") = UserSession.UserName20
                    End Select
                Next
                Me.daContentSetAccessClassification.Update(Me.MainDataset, "ContentSetAccessClassification")
            End If
            If TranStartedHere Then
                Me.db.CommitTran()
            End If

        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try
    End Sub
    Public Sub AddContentSet(ByVal ContentSetName As String)

        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Dim row As DataRow = Me.ContentSet.NewRow
            row("ContentSetId") = 0
            row("ContentSetName") = ContentSetName
            row("ContentSetStatus") = "Initial"

            Me.ContentSet.Rows.Add(row)
            Me.daContentSet.Update(Me.MainDataset, "ContentSet")

            Me.ContentSetId = db.DLookup("IDENT_CURRENT('ContentSet')", "", "")
            Me.Initilise()

            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try
    End Sub

    Public Sub AddContentsetSource(SourceType As ContentSetSourceTypes)
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Dim r As DataRow = Me.ContentSetSource.NewRow
            r("ContentSetSourceId") = -1 * SourceType
            r("SourceType") = SourceType.ToString
            r("ContentSetId") = Me.ContentSetId
            Me.ContentSetSource.Rows.Add(r)

            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try

    End Sub
End Class

#End Region