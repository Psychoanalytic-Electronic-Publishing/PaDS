Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.Data
Imports System.Web.UI
'Modification History
'12/04/2006  Julian Gates   Add PopulateChkBoxListFromSQL sub as modification Primary430
'8/5/07     James Woosnam   Add AuthorisedUser
'02/01/08   Julian Gates    Modified Sub HandlePageError to show Pads instead of Nibs
'2/4/08     James Woosnam   SIR1503 - Add ExportDataTableAsXLSToBrowser Function
'3/4/08     Julian Gates    Add FormatDate function to format dates correctly.
'3/4/08     Julian Gates    Add New FieldValidateDate to format dates to British format.
'Apr 2010	Zedra			SIR2205	- Add failover code
'22/5/11        James Woosnam   HotFix - Add Session and Primary/Secondary Flags to Session Log
'5/6/11     James Woosnam   PopulateDropDownFromTable Additional tests to try to get it to work in all suituations
'26/6/12    Julian Gates    Trap error put out message if value is invalid in PopulateDropDownListFromSQL and PopulateDropDownFromTable
'12/01/16   Julian Gates    SIR4070 - Change Users link to go to new .Net version of User page
'14/01/16   Julian Gates    SIR4070 - Add IsValidSecurePassword function
'23/10/19   Julian Gates    SIR4943 - Only show Subscriber Renewal menu item for GroupRenewer in Output menu
'17/03/20   Julian Gates    SIR5037 - Add menus for GroupAdmin users
'26/03/20   Julian Gates    SIR5050 - Change Renewals to Renewals/Additions in menu
'17/8/20    James Woosnam   SIR5082 - Store SessionId in, and restored from, a new session cookie
'08/09/20   Julian Gates    Update Pads to DevExpress v19.2
'22/02/21   Julian Gates    Removed glngTargetWidth parameter
'26/02/21   Julian Gates    SIR5046 - Add Counter Reports in menu
'16/03/21   Julian Gates    SIR5213 - Show  Counter Reports menu if Me.UserSession.Data("ShowCounterReports") true
'28/02/22   Julian Gates    SIR5391 - Add Sub FieldValidateFirstLastNameInput
'08/4/22    Julian Gates    SIR5468 - If not SuperCompanyAdmins or CompanyAdmins or GroupAdmins then bounce to logon page
'05/09/22   Julian Gates    SIR5553 - Add DX dev express control functions.
'28/11/22   Julian Gates    SIR5600 - Add pg100homeadmin.aspx page for Group Admin users to download created Subscribers import file template.
'07/03/23   Julian Gates    SIR5622 - Add Trim to WebControls.TextBox section in PopulateDataRowFromPageFields

Public Class UserPage
    Public pageTitle As String = Nothing
    Public subMenuItemName As String = Nothing
    Private strConn As String = Nothing
    '    Private cntPrimary As System.Data.SqlClient.SqlConnection
    Public StdCode As New BusinessLogic.StdCode
    Public pstrInfoMessage As String = Nothing
    Public pstrErrMsg As String = Nothing
    Private currentPage As Object = Nothing
    Public IsValid As Boolean = True
    Public FinishedInitialLoad As Boolean = False
    Private cFocusControl As System.Web.UI.Control
    Public highestAuthorityGroup As String = Nothing
    Public currentUser As String = Nothing
    Dim html As String = Nothing
    Public metaDescription As String = Nothing
    Public menuId As String = Nothing
    Dim _UserSession As BusinessLogic.UserSession = Nothing
    Public Property UserSession() As BusinessLogic.UserSession
        Get
            Return Me._UserSession
        End Get
        Set(ByVal value As BusinessLogic.UserSession)

        End Set
    End Property
    Public ReadOnly Property IsWebServerPrimaryOrSecondary As String
        Get
            Return System.Configuration.ConfigurationManager.AppSettings("IsPrimaryOrSeconday")
        End Get
    End Property
    Public IsDatabaseServerPrimaryOrSecondary As String = "Unknown"
    Public IsReadOnlyOnSecondary As Boolean = False

    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            If Me._db Is Nothing Then
                Dim FailOver As New BusinessLogic.Failover()
                Me._db = New BusinessLogic.Database(FailOver.ChooseConnectionString(
                                                    System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringPrimary").ToString _
                                                    , System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringSecondary").ToString _
                                                    , System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringSecurityOnSecondary").ToString _
                                                    , "ASP.NET - UserPage.vb - " _
                                                    , Me.IsWebServerPrimaryOrSecondary))
                Me._db.SecondaryConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringSecondary").ToString
                Me.IsDatabaseServerPrimaryOrSecondary = FailOver.IsDatabaseServerPrimaryOrSecondary
                Me.IsReadOnlyOnSecondary = FailOver.IsReadOnlyOnSecondary
                Me._db.IsWebServerPrimaryOrSecondary = Me.IsWebServerPrimaryOrSecondary
                Me._db.IsDatabaseServerPrimaryOrSecondary = Me.IsDatabaseServerPrimaryOrSecondary
            End If
            Return (Me._db)
        End Get


        Set(ByVal value As BusinessLogic.Database)
            Me._db = value
        End Set
    End Property
    Public ReadOnly Property PrimaryConnection As SqlConnection
        Get
            Return db.DBConnection
        End Get
    End Property

    Public ReadOnly Property DatabaseName() As String
        Get
            Try
                Return Me.db.DBConnection.Database
            Catch ex As Exception
                Return "**Not Found**"
            End Try
        End Get
    End Property

    Public Sub New()
        'enables use of upage without loggin on
    End Sub
    Public Sub New(ByRef thePage As Object, ByVal strPageTitle As String, ByVal strSubMenuItemName As String, Optional ResetSessionCookieIfNotPostback As Boolean = False)
        '31/5/12    James Woosnam   VersionNumber moved into Database
        ' strVersion = "v04.01f (30th May 2012)"

        '8/5/07		James Woosnam	Only get UserName from query string
        '14/5/10    James Woosnam   Put in try catch and only allow thread abort errors through
        Try

            currentPage = thePage

            '29/3/18    James Woosnam   If not secure currection and on live then bounce to logon page
            If Not currentPage.Request.IsSecureConnection Then
                If Not currentPage.Server.MachineName.ToLower.Contains("zedra") Then
                    currentPage.Response.Redirect("https://" & currentPage.Request.Url.Authority & "/pages/pg070Logon.aspx")
                End If
            End If

            '17/8/20    James Woosnam   SIR5082 - Store SessionId in, and restored from, a new session cookie
            '*****Code below should be kept pretty much in sync between UserPage.new and Master.Initilise*******
            Me._UserSession = New BusinessLogic.UserSession(Me.db)
            Dim RedirectURL As String = Nothing
            Try
                Me._UserSession.RestoreFromCookie(currentPage.Request, RedirectURL, ResetSessionCookieIfNotPostback)
                Me.UserSession.Data("IsReadOnlyOnSecondary") = Me.IsReadOnlyOnSecondary
            Catch ex As Exception

                If ex.Message.Contains(" has timed out") Then
                    Me.WriteSessionLog("Session Timed Out")
                End If
            End Try
            If RedirectURL <> Nothing Then
                currentPage.Response.Redirect(RedirectURL)
                HttpContext.Current.ApplicationInstance.CompleteRequest()
            End If
            '*****Code above should be kept pretty much sync between UserPage.new and Master.Initilise*******

            If Not CBool(Me.UserSession.Data("LoggedIn")) Then
                Dim url As String = ""
                url = "../pages/pg070Logon.aspx?Action=Logout&" & Me.UserSession.QueryString

                currentPage.Response.Redirect(url)
            Else
                '08/4/22    Julian Gates   SIR5468 - If not SuperCompanyAdmins or CompanyAdmins or GroupAdmins then bounce to logon page
                Select Case Me.UserSession.AuthorityLevel
                    Case BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins
                        'all fine for SuperCompanyAdmins and CompanyAdmins
                    Case BusinessLogic.UserSession.AuthorityLevels.GroupRenewer
                        If currentPage.Request.Item("Path_Info").ToLower.Contains("pg100homeadmin") Then
                            'all fine coming from above pages for GroupRenewer.
                        Else
                            currentPage.Session.Abandon()
                            currentPage.Response.Redirect("../Pages/pg070Logon.aspx?Action=Logout&" & Me.UserSession.QueryString)
                        End If
                    Case BusinessLogic.UserSession.AuthorityLevels.GroupAdmins
                        '28/11/22   Julian Gates    SIR5600 - Add pg100homeadmin.aspx page for Group Admin users to download created Subscribers import file template.
                        If currentPage.Request.Item("Path_Info").ToLower.Contains("/pages/pg490groupsubscriberselect.aspx") _
                        Or currentPage.Request.Item("Path_Info").ToLower.Contains("/pages/pg491groupsubscriberupdate.aspx") _
                        Or currentPage.Request.Item("Path_Info").ToLower.Contains("/pages/pg600counterreports.aspx") _
                        Or currentPage.Request.Item("Path_Info").ToLower.Contains("/pages/pg100homeadmin.aspx") Then
                            'all fine coming from above pages for GroupAdmins.
                        Else
                            currentPage.Session.Abandon()
                            currentPage.Response.Redirect("../Pages/pg070Logon.aspx?Action=Logout&" & Me.UserSession.QueryString)
                        End If
                    Case Else
                        currentPage.Session.Abandon()
                        currentPage.Response.Redirect("../Pages/pg070Logon.aspx?Action=Logout&" & Me.UserSession.QueryString)
                End Select
            End If
            If currentPage.Request.QueryString.Item("LogCommand") = "Logout" Then
                currentPage.Session.Abandon()
                currentPage.Response.Redirect("../Pages/pg070Logon.aspx?Action=Logout&" & Me.UserSession.QueryString)
            End If

            '8/5/07     James Woosnam   Add AuthorisedUser
            'If Not Me.AuthorisedUser(sErrorMessage) Then
            '    currentPage.Response.Redirect("../Pages/pg070Logon.aspx?ErrorMessage=" & sErrorMessage)
            'End If

        Catch ex As Exception
            If ex.Message = "Thread was being aborted." Then
                'do nothing as this seems to happen after a redirect and appears to be ok.
            Else
                currentPage.Response.Redirect("../Pages/pg070Logon.aspx?ErrorMessage=" & ex.Message)

            End If
        End Try
        pageTitle = strPageTitle
        If Me.IsReadOnlyOnSecondary Then
            Me.InfoMessage = "PaDS Primary is temporarily unavailable.  PaDS must only be used for Reading, NOT writing"
        End If




        subMenuItemName = strSubMenuItemName
    End Sub
    Public ReadOnly Property PageHead As String
        Get
            Return "<!DOCTYPE html PUBLIC ""-//W3C//DTD XHTML 1.0 Transitional//EN"" ""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"">" & Chr(13) _
                    & "<HTML>" & Chr(13) _
                    & "<HEAD>" & Chr(13) _
                    & "<title>" & Me.pageTitle & "</title>" & Chr(13) _
                    & "<meta http-equiv='Content-Type' content='text/html;charset=utf-8'>" & Chr(13) _
                    & "<meta name='description' content=''>" & Chr(13) _
                    & "<meta name='keywords' content=''>" & Chr(13) _
                    & "<LINK href='../Common/PageStyle.css' type=text/css rel=stylesheet >" & Chr(13) _
                    & "<link rel='shortcut icon' href='../favicon.ico'/>" & Chr(13) _
                    & "  </HEAD>" _
                    & "  <BODY>"
        End Get
    End Property

    Public ReadOnly Property PageHeader(Optional ByVal pageStyle As String = Nothing) As String
        Get
            html = "<!DOCTYPE html PUBLIC ""-//W3C//DTD XHTML 1.0 Transitional//EN"" ""http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"">" & vbCrLf
            html += "<html>" & vbCrLf
            html += "   <head>" & vbCrLf
            html += "       <title>" & Me.pageTitle & "</title>" & vbCrLf
            html += "       <meta http-equiv='Content-Type' content='text/html;charset=utf-8'>" & vbCrLf
            html += "       <meta name='description' content='" & metaDescription & "'>" & vbCrLf
            html += "       <meta name='keywords' content=''>" & vbCrLf
            html += "       <link href='../Common/PageStyleNew.css' type='text/css' rel='stylesheet'>" & vbCrLf
            html += "       <script language='JavaScript' src='../Common/PopupWindow.js' type='text/javascript'></script>" & vbCrLf
            html += "       <link rel='shortcut icon' href='../favicon.ico'>" & vbCrLf
            html += "   </head>"
            html += "   <body onkeypress=""CaptureEnter()"">" & vbCrLf
            html += "<!--***** HEADER SECTION *****  -->" & vbCrLf
            html += "	<table border='0' width='320' cellpadding='0' cellspacing='0' align='center'>" & vbCrLf
            html += "		<tr>" & vbCrLf
            html += "			<td>" & vbCrLf
            html += "				<img height='8' src='../images/corners/topLCorner.gif' width='8' border='0' alt=''></td>" & vbCrLf
            html += "			<td><img height='8'  src='../images/corners/toprow.gif' width='100%' border='0' alt=''></td>" & vbCrLf
            html += "			<td><img height='8'  src='../images/corners/topRCorner.gif' width='8' border='0' alt=''></td> </tr>" & vbCrLf
            html += "		<tr>" & vbCrLf
            html += "			<td height='100%' class='outerHoldingBorderLeft'><!--OuterBorderLeft--></td>" & vbCrLf
            html += "			<td valign='top'>" & vbCrLf

            html += "				<table width='780' border='0' cellpadding='5' cellspacing='0' class='headerTable'>" & vbCrLf
            html += "					<tr>" & vbCrLf
            html += "						<td align='center'> " & vbCrLf
            html += "							<img src='../images/NewIJPLogoHeader.jpg' width=""77"" height=""79"" alt='IJPA Logo' ></img>" & vbCrLf
            html += "						</td>" & vbCrLf
            html += "						<td align='center'> " & vbCrLf
            html += "							<span class='hmTitle1'>PaDS</span>" & vbCrLf
            html += "							<br>" & vbCrLf
            html += "							<span class='hmTitle2'>Psychoanalysts Database System</span>" & vbCrLf
            html += "						    <br><br>" & vbCrLf
            html += "							<span class='UserName'>" & vbCrLf
            html += "							User:" & currentUser
            html += "							</span>&nbsp;" & vbCrLf

            '4/8/20     James Woosnam   SIR5105 - To Logout call pg070Logon with action Logout
            html += "							<a href='../Pages/pg070Logon.aspx?Action=Logout&" & Me.UserSession.QueryString & "'><img src='../images/icons/logoutBtn.gif' width=""74"" height=""18"" alt='Logout' ></img></a>" & vbCrLf
            html += "						<br>" & vbCrLf
            html += "						</td>" & vbCrLf
            html += "						<td align='center'> " & vbCrLf
            html += "							<img src='../images/NewPepLogoHeader.jpg' width=""66"" height=""77"" alt='PEP Logo' ></img>" & vbCrLf
            html += "						</td>" & vbCrLf
            html += "					</tr>" & vbCrLf
            html += "				</table>" & vbCrLf
            html += "			    <div class='navBar'>" & vbCrLf
            html += MainMenu()
            html += "               </div>" & vbCrLf
            html += "               <table cellspacing='0' cellpadding='3' width='100%' border='0'>" & vbCrLf
            html += "                   <tr>" & vbCrLf
            html += "                       <td>" & vbCrLf
            html += " 		                    <span class='pageTitle'>" & pageTitle & "</span>" & vbCrLf
            html += "                       </td>" & vbCrLf
            html += "                   </tr>" & vbCrLf
            html += "                   <tr>" & vbCrLf
            html += "                       <td vAlign='top'>" & currentPage.upage.PageError & "</td>" & vbCrLf
            html += "                   </tr>" & vbCrLf
            html += "                   <tr>" & vbCrLf
            html += "                       <td vAlign='top'>" & currentPage.upage.InfoMessage & "</TD>" & vbCrLf
            html += "                  </tr>" & vbCrLf
            html += "                </table>" & vbCrLf
            html += "   <!--***** END OF HEADER SECTION *****-->" & vbCrLf

            Return html
        End Get
    End Property

    Public ReadOnly Property MainMenu() As String
        Get
            '26/03/20   Julian Gates    SIR5050 - Change Renewals to Renewals/Additions in menu
            '26/02/21   Julian Gates    SIR5046 - Add Counter Reports in menu
            '16/03/21   Julian Gates    SIR5213 - Show  Counter Reports menu if Me.UserSession.Data("ShowCounterReports") true
            '01/02/22   Julian Gates    SIR5279 - If CounterReportsOnly only show counter reports
            Dim html As String = "&nbsp;"
            Select Case menuId
                Case "01a", "02a", "03a"
                    If UserSession.AuthorityLevel = BusinessLogic.UserSession.AuthorityLevels.GroupAdmins Then
                        html = "<table cellspacing=""0"" cellpadding=""0"" border=""0"" class=""menuTable"">" & Chr(13)
                        html += "   <tr>" & Chr(13)
                        html += "       <td>&nbsp;</td>" & Chr(13)
                        If Not CBool(Me.UserSession.Data("CounterReportsOnly")) Then
                            html += GetMainMenuItem("Subscribers", "pg490GroupSubscriberSelect.aspx?" & Me.UserSession.QueryString, "01a")
                            html += GetMenuSpacer()
                            html += GetMainMenuItem("Renewals/Additions", "pg462SubscriberRenewals.aspx?" & Me.UserSession.QueryString, "02a")
                        End If

                        If CBool(Me.UserSession.Data("ShowCounterReports")) Then
                            If Not CBool(Me.UserSession.Data("CounterReportsOnly")) Then html += GetMenuSpacer()
                            html += GetMainMenuItem("Counter Reports", "pg600CounterReports.aspx?" & Me.UserSession.QueryString, "03a")
                        End If

                        html += "       <td>&nbsp;</td>" & Chr(13)
                        html += "   </tr>" & Chr(13)
                        html += "</table>" & Chr(13)
                    End If
            End Select
            Return html
        End Get
    End Property

    Private Function GetMainMenuItem(ByVal MenuText As String, ByVal PageName As String, ByVal mainMenuId As String, Optional ByVal TitleText As String = "", Optional ByVal PageMode As String = "") As String
        Dim html As String = ""
        Dim menuBtnImage As String = ""
        Dim cssClass As String = ""
        Dim localTitleText As String = ""

        If menuId = mainMenuId Then
            menuBtnImage = "../images/MenuImages/over-btn.gif"
            cssClass = "cssnav2"
        Else
            menuBtnImage = "../images/MenuImages/menu-btn.gif"
            cssClass = "cssnav"
        End If
        If TitleText <> "" Then
            localTitleText = TitleText
        Else
            localTitleText = MenuText
        End If
        html += "        <td>"
        html += "            <div class='" & cssClass & "'>" & vbCrLf
        html += "                <a href=""" & PageName & """" _
                                    & " title=""Open " & localTitleText & """><img src=""" & menuBtnImage & """ alt=""" & MenuText & """/>" _
                                    & "<span>" & MenuText & "</span></a>" & vbCrLf
        html += "            </div>" & vbCrLf
        html += "        </td>" & vbCrLf
        Return html
    End Function

    Private Function GetMenuSpacer() As String
        Dim html As String = ""
        Dim spacerImage As String = ""

        spacerImage = "menuSpacer"

        html += "<td width='1' align='center'><img src='../images/MenuImages/" & spacerImage & ".gif' width='1' height='20' border='0'/></td>" & vbCrLf
        Return html
    End Function
    Public ReadOnly Property PageFooter(Optional ByVal pageStyle As String = Nothing) As String
        Get
            html = "<!--***** START OF FOOTER SECTION *****-->" & vbCrLf
            html += "               <table width='780' cellpadding='0' cellspacing='0' border='0'  bgcolor='#45A3D9'>" & vbCrLf
            html += "	                <tr>" & vbCrLf
            html += "		                <td align='right' width='11'><img height='27' src='../images/footCornL.gif' width='11' border='0' alt=''></td>" & vbCrLf
            html += "		                <td align='left'>" & vbCrLf
            html += "		                    <table width='100%' cellpadding='0' cellspacing='0' border='0'>" & vbCrLf
            html += "			                    <tr>" & vbCrLf
            html += "				                    <td align='left' width='250'>" & vbCrLf
            html += "					                    <span class='footerText'>Designed and built by </span><a href='http://www.zedra.co.uk' target='_blank'>Zedra Solutions</a>" & vbCrLf
            html += "				                    </td>" & vbCrLf
            html += "				                    <td align='right'>" & vbCrLf
            html += "					                    <span class='footerText'>" & vbCrLf
            html += "					                    Version:" & Me.db.PaDSVersion & vbCrLf
            html += "					                    </span>" & vbCrLf
            html += "				                    </td>" & vbCrLf
            html += "			                    </tr>" & vbCrLf
            html += "		                    </table>" & vbCrLf
            html += "	                    </td>" & vbCrLf
            html += "	                    <td width='11'><img height='27' src='../images/footCornR.gif' width='11' border='0' alt=''></td>" & vbCrLf
            html += "                   </tr>" & vbCrLf
            html += "               </table>" & vbCrLf
            html += "<!--***** END OF FOOTER SECTION *****-->" & vbCrLf

            html += "			</td>" & vbCrLf
            html += "			<td class='outerHoldingBorderRight'><!--OuterBorderRight--></td>" & vbCrLf
            html += "		<tr>" & vbCrLf
            html += "			<td><img height='8' src='../images/corners/botLCorner.gif' width='8' border='0' alt=''></td>" & vbCrLf
            html += "			<td><img height='8' src='../images/corners/botrow.gif' width='100%' border='0' alt=''></td>" & vbCrLf
            html += "			<td><img height='8' src='../images/corners/botRCorner.gif' width='8' border='0' alt=''></td>" & vbCrLf
            html += "		</tr>" & vbCrLf
            html += "	</table>" & vbCrLf
            Return html
        End Get
    End Property

    Function RemoveQueryStringParam(ByVal strParamName As String, ByVal strQueryString As String) As String
        'Removes the named parameter from a query string
        Dim lngStart As Integer = Nothing
        Dim lngEnd As Integer = Nothing

        lngStart = InStr(strQueryString, strParamName)
        If lngStart > 0 Then
            lngEnd = InStr(lngStart, strQueryString, "&")
            If lngEnd = 0 Then
                If lngStart <= 2 Then
                    RemoveQueryStringParam = ""
                Else
                    RemoveQueryStringParam = Left(strQueryString, lngStart - 1)
                End If
            Else
                RemoveQueryStringParam = Left(strQueryString, lngStart - 1) _
                       & Mid(strQueryString, lngEnd + 1)
            End If

        Else
            RemoveQueryStringParam = strQueryString
        End If


    End Function

    Public Sub PageUnload()
        'Close the connection String
        Try
            If db.DBConnection.State = ConnectionState.Open Then
                db.DBConnection.Close()
            End If
        Catch ex As Exception

        End Try
    End Sub
    Public AdditionalInfoForlog As String = ""
    Public Sub AddAdditionalInfoForlog(AdditionalInfo As String)
        Me.AdditionalInfoForlog += Environment.NewLine + AdditionalInfo
    End Sub
    Public Sub PagePreRender()
        If Not Me.FocusControl Is Nothing Then
            If Me.FocusControl.Visible = True Then
                Dim s As String = "<SCRIPT language='javascript'>document.getElementById('" & Me.FocusControl.ID & "').focus() </SCRIPT>"
                currentPage.RegisterStartupScript("focus", s)

            End If

        End If
        Try
            Dim ex As Exception = currentPage.Server.GetLastError()
            If ex IsNot Nothing Then Me.AddAdditionalInfoForlog("LastError:" & ex.ToString)
        Catch ex As Exception
        End Try
        '  If Not Me.currentPage.IsPostback Then            'Only so session log on first entry as every Ajax call is generateing a log
        WriteSessionLog("PageLoad", Me.AdditionalInfoForlog)
        '   End If
    End Sub
    Public Sub SetupDataList(ByVal strPageNumber As String _
                                , ByVal strRecordsPerPage As String _
                                , ByRef drData As SqlClient.SqlDataReader _
                                , ByRef strPageNumHTML As String)
        'Mod History
        '===========
        '15/12/04   James Woosnam   Page number code updated so that not all page numbers are shown
        Dim i As Integer
        Dim lngTotalPageCount, lngPageNumber, lngRecordsPerPage As Long

        Try
            lngPageNumber = CLng(strPageNumber)
        Catch ex As Exception
            lngPageNumber = 1
        End Try
        Try
            lngRecordsPerPage = CLng(strRecordsPerPage)
        Catch ex As Exception
            lngRecordsPerPage = 5
        End Try
        strPageNumHTML = ""
        If drData.Read() Then
            'See if the data rader has the total number of records
            Try
                If drData("NoDisplayRecordCount") = -1 Then
                    'This query is too complex to count so just add a page two
                    lngTotalPageCount = lngPageNumber + 1
                Else
                    lngTotalPageCount = drData("NoDisplayRecordCount") / lngRecordsPerPage
                    If CDbl(drData("NoDisplayRecordCount") / lngRecordsPerPage) > lngTotalPageCount Then
                        lngTotalPageCount = lngTotalPageCount + 1
                    End If
                End If

            Catch ex As Exception
                lngTotalPageCount = lngPageNumber
            End Try
            'Add Page numbering from 1 to the page number plus 2

            For i = 1 To lngPageNumber + 2
                If i <= lngTotalPageCount _
                And i > 0 Then
                    If i = lngPageNumber + 2 Then
                        i = lngTotalPageCount
                        strPageNumHTML = strPageNumHTML & ".."


                    End If
                    If i = 1 _
                    Or Not (i < lngPageNumber - 1) Then
                        strPageNumHTML = strPageNumHTML & "<A HREF='javascript:" _
                                   & "GotoPage(" & i & ")" _
                                   & "' >"
                        If i = lngPageNumber Then
                            strPageNumHTML = strPageNumHTML & "  <SPAN class=pageNumCurrent>" & i & "</SPAN>"
                        Else
                            strPageNumHTML = strPageNumHTML & "  <SPAN class=pageNum>" & i & "</SPAN>"
                        End If
                        strPageNumHTML = strPageNumHTML & "</A>&nbsp;"

                    End If
                    If i = lngPageNumber - 2 Then
                        strPageNumHTML = strPageNumHTML & ".."

                    End If

                End If
            Next
            'Move Data reader to begining of Page
            For i = 1 To ((lngPageNumber - 1) * lngRecordsPerPage) - 1
                drData.Read()
            Next
        End If
    End Sub
    Public Function GetListDatatable(ByVal strPageNumber As String _
                             , ByVal strRecordsPerPage As String _
                             , ByRef strPageNumHTML As String _
                             , ByVal SelectSQL As String _
                             , ByRef cnt As SqlConnection _
                             , Optional ByVal ShowAllPageLinks As Boolean = True
                             ) As DataTable
        Return Me.GetListDatatable(strPageNumber,
                        strRecordsPerPage,
                        strPageNumHTML,
                        New SqlCommand(SelectSQL, db.DBConnection, db.DBTransaction),
                        ShowAllPageLinks)

    End Function
    Public Function GetListDatatable(ByVal strPageNumber As String _
                             , ByVal strRecordsPerPage As String _
                             , ByRef strPageNumHTML As String _
                             , ByVal cmd As SqlCommand _
                             , Optional ByVal ShowAllPageLinks As Boolean = True
                             ) As DataTable
        'Mod History
        '===========
        '15/12/04   James Woosnam   Added to cater for some lists
        Dim i As Long
        Dim lngTotalPageCount, lngPageNumber, lngRecordsPerPage, lngTotalRecordCount As Long
        'Default page number and records per page if invalid
        Try
            lngPageNumber = CLng(strPageNumber)
        Catch ex As Exception
            lngPageNumber = 1
        End Try
        Try
            lngRecordsPerPage = CLng(strRecordsPerPage)
        Catch ex As Exception
            lngRecordsPerPage = 5
        End Try
        Dim listTable As New DataTable("List")

        Dim listReader As SqlDataReader = cmd.ExecuteReader
        Try
            Dim schema As DataTable = listReader.GetSchemaTable

            'Use the datareader schema to create columns in the datatable
            For Each row As DataRow In schema.Rows
                listTable.Columns.Add(row.Item("ColumnName"), row.Item("datatype"))
            Next


            'loop through the dataread until we have got to the begining of the required page
            For i = 1 To ((lngPageNumber - 1) * lngRecordsPerPage)
                If Not listReader.Read() Then
                    'Close reader before returning listTable
                    listReader.Close()
                    Return listTable
                Else
                    lngTotalRecordCount = lngTotalRecordCount + 1
                End If
            Next

            'Read through a page worth of data populating the lsit table
            Do While lngTotalRecordCount < (lngPageNumber * lngRecordsPerPage)
                If listReader.Read() Then
                    lngTotalRecordCount = lngTotalRecordCount + 1
                    Dim newRow As DataRow = listTable.NewRow
                    For Each columnRow As DataRow In schema.Rows

                        newRow.Item(columnRow.Item("ColumnName")) = listReader(columnRow.Item("ColumnName"))
                    Next
                    listTable.Rows.Add(newRow)
                Else
                    Exit Do
                End If
            Loop

            'If we want all page links we need to read to the end of the datareader
            If ShowAllPageLinks Then
                Do While listReader.Read()
                    lngTotalRecordCount = lngTotalRecordCount + 1
                Loop
            End If


            strPageNumHTML = ""
            If Not ShowAllPageLinks Then
                'This query is too complex to count so just add a page two
                lngTotalPageCount = lngPageNumber
            Else
                lngTotalPageCount = lngTotalRecordCount / lngRecordsPerPage
                If CDbl(lngTotalRecordCount / lngRecordsPerPage) > lngTotalPageCount Then
                    lngTotalPageCount = lngTotalPageCount + 1
                End If
            End If

            'Add Page numbering from 1 to the page number plus 2

            For i = 1 To lngPageNumber + 2
                If i <= lngTotalPageCount _
            And i > 0 Then
                    If i = lngPageNumber + 2 Then
                        i = lngTotalPageCount
                        strPageNumHTML = strPageNumHTML & ".."


                    End If
                    If i = 1 _
                Or Not (i < lngPageNumber - 1) Then
                        strPageNumHTML = strPageNumHTML & "<A HREF='javascript:" _
                               & "GotoPage(" & i & ")" _
                               & "' >"
                        If i = lngPageNumber Then
                            strPageNumHTML = strPageNumHTML & "  <SPAN class=pageNumCurrent>" & i & "</SPAN>"
                        Else
                            strPageNumHTML = strPageNumHTML & "  <SPAN class=pageNum>" & i & "</SPAN>"
                        End If
                        strPageNumHTML = strPageNumHTML & "</A>&nbsp;"

                    End If
                    If i = lngPageNumber - 2 Then
                        strPageNumHTML = strPageNumHTML & ".."

                    End If

                End If
            Next
            'Show next buttom of ShowAllPageLinks = false
            If Not ShowAllPageLinks Then
                If listReader.Read Then
                    strPageNumHTML = strPageNumHTML & "<A HREF='javascript:" _
                           & "GotoPage(" & lngTotalPageCount + 1 & ")" _
                           & "' >"
                    strPageNumHTML = strPageNumHTML & "  <SPAN class=pageNum>Next--></SPAN>"
                    strPageNumHTML = strPageNumHTML & "</A>"

                End If
            End If


        Catch ex As Exception
            Throw New Exception("GetListDatatable failed:" & ex.Message, ex)
        Finally
            listReader.Close()
        End Try
        Return listTable

    End Function
    Public Function GetListDatatableForOleDb(ByVal strPageNumber As String _
                             , ByVal strRecordsPerPage As String _
                             , ByRef strPageNumHTML As String _
                             , ByVal SelectSQL As String _
                             , ByRef cnt As OleDbConnection _
                             , Optional ByVal ShowAllPageLinks As Boolean = True
                             ) As DataTable
        'Mod History
        '===========
        '15/12/04   James Woosnam   Added to cater for some lists
        Dim i As Long
        Dim lngTotalPageCount, lngPageNumber, lngRecordsPerPage, lngTotalRecordCount As Long
        'Default page number and records per page if invalid
        Try
            lngPageNumber = CLng(strPageNumber)
        Catch ex As Exception
            lngPageNumber = 1
        End Try
        Try
            lngRecordsPerPage = CLng(strRecordsPerPage)
        Catch ex As Exception
            lngRecordsPerPage = 5
        End Try

        Dim listReader As OleDbDataReader = New OleDbCommand(SelectSQL, cnt).ExecuteReader

        Dim schema As DataTable = listReader.GetSchemaTable
        Dim listTable As New DataTable("List")

        'Use the datareader schema to create columns in the datatable
        For Each row As DataRow In schema.Rows
            listTable.Columns.Add(row.Item("ColumnName"), row.Item("datatype"))
        Next


        'loop through the dataread until we have got to the begining of the required page
        For i = 1 To ((lngPageNumber - 1) * lngRecordsPerPage)
            If Not listReader.Read() Then
                Return listTable
            Else
                lngTotalRecordCount = lngTotalRecordCount + 1
            End If
        Next

        'Read through a page worth of data populating the lsit table
        Do While lngTotalRecordCount < (lngPageNumber * lngRecordsPerPage)
            If listReader.Read() Then
                lngTotalRecordCount = lngTotalRecordCount + 1
                Dim newRow As DataRow = listTable.NewRow
                For Each columnRow As DataRow In schema.Rows

                    newRow.Item(columnRow.Item("ColumnName")) = listReader(columnRow.Item("ColumnName"))
                Next
                listTable.Rows.Add(newRow)
            Else
                Exit Do
            End If
        Loop

        'If we want all page links we need to read to the end of the datareader
        If ShowAllPageLinks Then
            Do While listReader.Read()
                lngTotalRecordCount = lngTotalRecordCount + 1
            Loop
        End If


        strPageNumHTML = ""
        If Not ShowAllPageLinks Then
            'This query is too complex to count so just add a page two
            lngTotalPageCount = lngPageNumber
        Else
            lngTotalPageCount = lngTotalRecordCount / lngRecordsPerPage
            If CDbl(lngTotalRecordCount / lngRecordsPerPage) > lngTotalPageCount Then
                lngTotalPageCount = lngTotalPageCount + 1
            End If
        End If

        'Add Page numbering from 1 to the page number plus 2

        For i = 1 To lngPageNumber + 2
            If i <= lngTotalPageCount _
            And i > 0 Then
                If i = lngPageNumber + 2 Then
                    i = lngTotalPageCount
                    strPageNumHTML = strPageNumHTML & ".."


                End If
                If i = 1 _
                Or Not (i < lngPageNumber - 1) Then
                    strPageNumHTML = strPageNumHTML & "<A HREF='javascript:" _
                               & "GotoPage(" & i & ")" _
                               & "' >"
                    If i = lngPageNumber Then
                        strPageNumHTML = strPageNumHTML & "  <SPAN class=pageNumCurrent>" & i & "</SPAN>"
                    Else
                        strPageNumHTML = strPageNumHTML & "  <SPAN class=pageNum>" & i & "</SPAN>"
                    End If
                    strPageNumHTML = strPageNumHTML & "</A>&nbsp;"

                End If
                If i = lngPageNumber - 2 Then
                    strPageNumHTML = strPageNumHTML & ".."

                End If

            End If
        Next
        'Show next buttom of ShowAllPageLinks = false
        If Not ShowAllPageLinks Then
            If listReader.Read Then
                strPageNumHTML = strPageNumHTML & "<A HREF='javascript:" _
                           & "GotoPage(" & lngTotalPageCount + 1 & ")" _
                           & "' >"
                strPageNumHTML = strPageNumHTML & "  <SPAN class=pageNum>Next--></SPAN>"
                strPageNumHTML = strPageNumHTML & "</A>"

            End If
        End If

        listReader.Close()
        Return listTable

    End Function
    Public Property PageError() As String
        Get
            Return pstrErrMsg
        End Get
        Set(ByVal Value As String)
            Me.AddAdditionalInfoForlog("Error:" & Value)

            If pstrErrMsg = "" Then
                ' pstrErrMsg = "<SPAN class=errMsgTitle>The following errors have been found:</SPAN>"
                pstrErrMsg = pstrErrMsg + "<UL>"
            End If
            pstrErrMsg = pstrErrMsg & "<SPAN class=errMsg><li>" & Value.Replace(vbCr, "<BR>") & "</SPAN>"
            Me.IsValid = False

        End Set
    End Property
    Public Sub PopulatePageFieldsFromDataRow(ByVal dRow As DataRow)
        Dim myColumn As DataColumn
        Dim theControl As Control
        For Each myColumn In dRow.Table.Columns
            theControl = currentPage.FindControl(myColumn.ColumnName)
            If Not (theControl Is Nothing) Then
                Try
                    Dim myControl As WebControls.TextBox = theControl
                    If dRow.Item(myColumn.ColumnName) Is System.DBNull.Value Then
                        myControl.Text = ""
                    Else
                        myControl.Text = dRow.Item(myColumn.ColumnName)
                    End If
                Catch ex1 As Exception
                    Try
                        Dim myControl As WebControls.CheckBox = theControl
                        myControl.Checked = dRow.Item(myColumn.ColumnName)

                    Catch ex2 As Exception
                        Try
                            Dim myControl As WebControls.DropDownList = theControl
                            '   myControl.Items.FindByText(dRow.Item(myColumn.ColumnName)).Selected = True
                            myControl.SelectedValue = dRow.Item(myColumn.ColumnName)
                        Catch ex3 As Exception
                            Try
                                Dim myControl As HtmlControls.HtmlInputHidden = theControl
                                If dRow.Item(myColumn.ColumnName) Is System.DBNull.Value Then
                                    myControl.Value = ""
                                Else
                                    myControl.Value = dRow.Item(myColumn.ColumnName)
                                End If
                            Catch ex4 As Exception
                                Try
                                    Dim myControl As WebControls.Label = theControl
                                    If dRow.Item(myColumn.ColumnName) Is System.DBNull.Value Then
                                        myControl.Text = ""
                                    Else
                                        myControl.Text = dRow.Item(myColumn.ColumnName)
                                    End If
                                Catch ex5 As Exception
                                    Try
                                        Dim myControl As WebControls.HyperLink = theControl
                                        If dRow.Item(myColumn.ColumnName) Is System.DBNull.Value Then
                                            myControl.Text = ""
                                        Else
                                            myControl.Text = dRow.Item(myColumn.ColumnName)
                                        End If
                                    Catch ex6 As Exception
                                    End Try
                                End Try
                            End Try
                        End Try
                    End Try
                End Try
            End If
        Next
    End Sub
    Public Sub PopulateDataRowFromPageFields(ByVal dRow As DataRow)
        '07/03/23   Julian Gates    SIR5622 - Add Trim to WebControls.TextBox section in PopulateDataRowFromPageFields
        Dim myColumn As DataColumn
        Dim theControl As Control
        For Each myColumn In dRow.Table.Columns
            theControl = currentPage.FindControl(myColumn.ColumnName)
            If Not (theControl Is Nothing) Then
                Try
                    Dim myControl As WebControls.TextBox = theControl
                    If myControl.Text = "" Then
                        dRow.Item(myColumn.ColumnName) = System.DBNull.Value
                    Else
                        dRow.Item(myColumn.ColumnName) = myControl.Text.Trim
                    End If
                Catch ex1 As Exception
                    Try
                        Dim myControl As WebControls.CheckBox = theControl
                        dRow.Item(myColumn.ColumnName) = myControl.Checked

                    Catch ex2 As Exception
                        Try
                            Dim myControl As WebControls.DropDownList = theControl
                            If myControl.SelectedValue = "" Then
                                dRow.Item(myColumn.ColumnName) = System.DBNull.Value
                            Else
                                dRow.Item(myColumn.ColumnName) = myControl.SelectedValue
                            End If
                        Catch ex3 As Exception
                            Try
                                Dim myControl As HtmlControls.HtmlInputHidden = theControl
                                If myControl.Value = "" Then
                                    dRow.Item(myColumn.ColumnName) = System.DBNull.Value
                                Else
                                    dRow.Item(myColumn.ColumnName) = myControl.Value
                                End If
                            Catch ex4 As Exception
                                Try
                                    Dim myControl As WebControls.Label = theControl
                                    If myControl.Text = "" Then
                                        dRow.Item(myColumn.ColumnName) = System.DBNull.Value
                                    Else
                                        dRow.Item(myColumn.ColumnName) = myControl.Text
                                    End If
                                Catch ex5 As Exception
                                End Try
                            End Try
                        End Try
                    End Try

                End Try
            End If
        Next
    End Sub

    Public Overloads Sub PopulateDropDownListFromSQL(ByRef theDropdown As WebControls.DropDownList _
                                        , ByVal SQL As String _
                                        , ByRef cnt As SqlConnection _
                                       , Optional ByVal initialValue As String = Nothing _
                                       , Optional ByVal CurrentValue As String = Nothing)
        'Populates a asp Dropdown list using SQL query

        Dim commandText As String = SQL

        Dim da As SqlDataAdapter = New SqlDataAdapter(commandText, cnt)
        Dim tbl As New DataTable
        da.Fill(tbl)

        Try
            PopulateDropDownFromTable(theDropdown, tbl, initialValue)
        Catch ex As Exception
            Throw New Exception("Drop down list not built from:'" & commandText & "'" & System.Environment.NewLine & ex.ToString)
        End Try
    End Sub

    Public Sub PopulateDropDownFromTable(ByRef theDropdown As WebControls.DropDownList _
                                      , ByVal tbl As DataTable _
                                      , Optional ByVal initialValue As String = Nothing)
        theDropdown.DataSource = tbl
        theDropdown.DataValueField = "Value"
        theDropdown.DataTextField = "Text"
        Try

            theDropdown.DataBind()
            If Not initialValue Is Nothing Then
                theDropdown.Items.Insert(0, New WebControls.ListItem(initialValue, String.Empty))
            End If
        Catch ex As Exception
            '15/06/12 Julian Gates - Catch error if dropdown value not matched
            If ex.Message.Contains("has a SelectedValue which is invalid because ") Then
                theDropdown.Items.Insert(0, New WebControls.ListItem(initialValue, String.Empty))
                Try
                    theDropdown.SelectedIndex = 0
                Catch ex1 As Exception
                End Try
            Else
                Throw New Exception(("Drop down list not built for " & theDropdown.ID & ". - ") + ex.Message, ex)
            End If
        End Try
    End Sub

    Public Overloads Sub PopulateDropDownListFromLookup(ByRef theDropdown As WebControls.DropDownList _
                                            , ByVal lookupName As String _
                                            , ByRef cnt As SqlConnection _
                                            , Optional ByVal initialValue As String = Nothing)
        'Populates a asp Dropdown list from the lookup table using the PopulateDropDownListFromSql
        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria
        Dim commandText As String =
            "SELECT LookupItemKey Value" _
            & "   ,Name Text" _
            & " FROM Lookup" _
            & " WHERE Lookup.LookUpName = '" & lookupName & "'" _
            & " AND Lookup.LookupStatus = 'Active'" _
            & " ORDER BY DisplayOrder,Name,LookupItemKey"

        PopulateDropDownListFromSQL(theDropdown, commandText, cnt, initialValue)

    End Sub
    'Public Overloads Sub PopulateDropDownListFromSQL(ByRef theDropdown As WebControls.DropDownList _
    '                                    , ByVal SQL As String _
    '                                    , ByRef cnt As SqlConnection _
    '                                    , Optional ByVal initialValue As String = Nothing _
    '                                   , Optional ByVal CurrentValue As Object = Nothing)
    '    'Populates a asp Dropdown list using SQL query

    '    Dim commandText As String = SQL

    '    Dim da As SqlDataAdapter = New SqlDataAdapter(commandText, cnt)
    '    Dim tbl As New DataTable
    '    da.Fill(tbl)
    '    Try
    '        PopulateDropDownFromTable(theDropdown, tbl, initialValue, CurrentValue)
    '    Catch ex As Exception
    '        '26/6/12    Julian Gates  Trap error put out message if value is invalid
    '        If ex.Message.Contains("has a SelectedValue which is invalid because ") Then
    '            Me.PageError = "'" & theDropdown.ID & "' has a value that is no longer valid and has been cleared."
    '            Try
    '                theDropdown.SelectedIndex = 0
    '            Catch ex1 As Exception
    '            End Try
    '        Else
    '            Throw New Exception("Drop down list not built from:'" & commandText & ex.ToString)
    '        End If

    '    End Try
    'End Sub
    'Public Sub PopulateDropDownFromTable(ByRef theDropdown As WebControls.DropDownList _
    '                                   , ByVal tbl As DataTable _
    '                                   , Optional ByVal initialValue As String = Nothing _
    '                                   , Optional ByVal CurrentValue As Object = Nothing)

    '    'Populates a asp Dropdown list using SQL query 
    '    '5/6/11     James Woosnam   PopulateDropDownFromTable Additional tests to try to get it to work in all suituations
    '    tbl.Columns.Add(New DataColumn("OrderBy"))
    '    If (initialValue IsNot Nothing) Then
    '        Dim blankRowFound As Boolean = False
    '        Dim rowNo As Integer = 1
    '        For Each row In tbl.Rows
    '            If CStr(row("Value")) = "" Then
    '                blankRowFound = True
    '            End If
    '            row("OrderBy") = rowNo.ToString("00000")
    '            rowNo += 1
    '        Next
    '        Dim currentValueFound As Boolean = False
    '        Try
    '            If CurrentValue Is Nothing Then
    '                CurrentValue = ""
    '            End If
    '            If db.IsDBNull(CurrentValue) Then
    '                Select Case CurrentValue.DataType.Name
    '                    Case "Int32", "Double"
    '                        CurrentValue = 0
    '                    Case Else
    '                        CurrentValue = ""
    '                End Select
    '            End If
    '        Catch ex As Exception
    '            CurrentValue = ""
    '        End Try
    '        For Each row As DataRow In tbl.Rows
    '            Try
    '                If row("Value") = CurrentValue Then
    '                    currentValueFound = True
    '                End If
    '            Catch
    '                currentValueFound = True
    '            End Try
    '        Next

    '        If Not blankRowFound Then
    '            Dim row As DataRow = tbl.NewRow
    '            Select Case tbl.Columns("Value").DataType.Name
    '                Case "Int32", "Double"
    '                    row("Value") = 0
    '                Case Else
    '                    row("Value") = ""
    '            End Select
    '            row("Text") = initialValue
    '            row("OrderBy") = CInt(0).ToString("00000")

    '            tbl.Rows.Add(row)
    '        End If
    '        If Not currentValueFound Then
    '            Dim row As DataRow = tbl.NewRow
    '            Select Case tbl.Columns("Value").DataType.Name
    '                Case "Int32"
    '                    row("Value") = IIf(CurrentValue Is Nothing, DBNull.Value, CurrentValue)
    '                Case Else
    '                    row("Value") = IIf(CurrentValue Is Nothing, DBNull.Value, CurrentValue)
    '            End Select
    '            row("Text") = initialValue + "2"
    '            row("OrderBy") = CInt(0).ToString("99999")

    '            tbl.Rows.Add(row)
    '        End If
    '    End If
    '    Dim vw As New DataView(tbl, "", "OrderBy", DataViewRowState.CurrentRows)
    '    '    Dim dr As SqlDataReader = New SqlCommand(commandText, dbConnection).ExecuteReader()
    '    Try
    '        theDropdown.DataSource = vw
    '        theDropdown.DataValueField = "Value"
    '        theDropdown.DataTextField = "Text"
    '        theDropdown.DataBind()
    '    Catch ex As Exception
    '        '26/6/12    Julian Gates  Trap error put out message if value is invalid
    '        If ex.Message.Contains("has a SelectedValue which is invalid because ") Then
    '            Me.PageError = "'" & theDropdown.ID & "' has a value that is no longer valid and has been cleared."
    '            Try
    '                theDropdown.SelectedIndex = 0
    '            Catch ex1 As Exception
    '            End Try
    '        Else
    '            Throw New Exception(("Drop down list not built for " & theDropdown.ID & ". - ") + ex.Message, ex)
    '        End If
    '    Finally
    '        '      dr.Close()
    '    End Try


    'End Sub
    '12/04/2006  Julian Gates   Add PopulateChkBoxListFromSQL sub as modification Primary430
    Public Sub PopulateChkBoxListFromSQL(ByRef theCheckBox As WebControls.CheckBoxList _
                                       , ByVal SQL As String _
                                       , ByRef cnt As SqlConnection _
                                       , Optional ByVal initialValue As String = Nothing)
        'Populates a asp Checkbox list using SQL query

        Dim commandText As String = SQL

        Dim dr As SqlDataReader = New SqlCommand(commandText, cnt).ExecuteReader
        theCheckBox.DataSource = dr
        theCheckBox.DataValueField = "Value"
        theCheckBox.DataTextField = "Text"
        Try

            theCheckBox.DataBind()
            If Not initialValue Is Nothing Then
                theCheckBox.Items.Insert(0, New WebControls.ListItem(initialValue, String.Empty))
            End If
        Catch ex As Exception
            Throw New Exception("Check Box list not built from:'" & commandText & ex.ToString)
        End Try
        dr.Close()
    End Sub

    Public Sub PopulateRadioButtonListFromLookup(ByRef theRadioButtonList As RadioButtonList, ByVal lookupName As String)
        'Populates a asp list box from the lookup table using the PopulateListBoxFromSql 
        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria
        Dim commandText As String = ("SELECT LookupItemKey Value" & " ,Name Text" & " FROM Lookup" & " WHERE Lookup.LookUpName = '") + lookupName & "'" & " AND Lookup.LookupStatus = 'Active' ORDER BY DisplayOrder,Name,LookupItemKey"


        PopulateRadioButtonListFromSql(theRadioButtonList, commandText)
    End Sub


    Public Sub PopulateRadioButtonListFromSql(ByRef theRadioButtonList As RadioButtonList, ByVal SQL As String)
        'Populates a asp list box using SQL query 

        Dim commandText As String = SQL

        Dim dr As SqlDataReader = New SqlCommand(commandText, Me.db.DBConnection, Me.db.DBTransaction).ExecuteReader()
        Try
            theRadioButtonList.DataSource = dr
            theRadioButtonList.DataValueField = "Value"
            theRadioButtonList.DataTextField = "Text"
            theRadioButtonList.DataBind()
        Catch ex As Exception
            Throw New Exception(("Radio Button List not built for " & theRadioButtonList.ID & ". - ") + ex.Message, New Exception(("SQL:" & commandText) + ex.ToString()))
        Finally
            dr.Close()
        End Try
    End Sub
    Public Sub PopulateListBoxFromLookup(ByRef theListBox As ListBox, ByVal lookupName As String, Optional ByVal initialValue As String = Nothing)
        'Populates a asp list box from the lookup table using the PopulateListBoxFromSql 
        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria
        Dim commandText As String = ("SELECT LookupItemKey Value" & " ,Name Text" & " FROM Lookup" & " WHERE Lookup.LookUpName = '") + lookupName & "'" & " AND Lookup.LookupStatus = 'Active' ORDER BY DisplayOrder,Name,LookupItemKey"


        PopulateListBoxFromSql(theListBox, commandText, initialValue)
    End Sub


    Public Sub PopulateListBoxFromSql(ByRef theListBox As ListBox, ByVal SQL As String, ByVal initialValue As String)
        'Populates a asp list box using SQL query 

        Dim commandText As String = SQL

        Dim dr As SqlDataReader = New SqlCommand(commandText, Me.db.DBConnection, Me.db.DBTransaction).ExecuteReader()
        Try
            theListBox.DataSource = dr
            theListBox.DataValueField = "Value"
            theListBox.DataTextField = "Text"
            theListBox.DataBind()
            If (initialValue IsNot Nothing) Then
                theListBox.Items.Insert(0, New System.Web.UI.WebControls.ListItem(initialValue, String.Empty))
            End If
        Catch ex As Exception
            Throw New Exception(("List box not built for " & theListBox.ID & ". - ") + ex.Message, New Exception(("SQL:" & commandText) + ex.ToString()))
        Finally
            dr.Close()
        End Try
    End Sub

    Public Sub HandlePageError()
        '******************************************
        'Handles errors that occur on the page and are caught by
        'Page_Error
        '******************************************
        '02/01/2008  Julian Gates Changed Nibs to PaDS in code below.
        Dim strHTML As String = Nothing
        Dim strBody As String = Nothing
        Dim ex As Exception = currentPage.server.getlastError()
        'Create Email Error Report
        Dim emailError As String = ""
        Dim strSubject As String = ""
        Try
            strSubject = "PaDS error:"
            strBody = "&body=Error on Page:" & currentPage.Request.FilePath
            strBody = strBody & "&body=User:" & System.Security.Principal.WindowsIdentity.GetCurrent.Name
            strBody = strBody & "    Error:" & ex.ToString
            Dim email As New BusinessLogic.Email(Me.db)
            'email.SendErrorEmail(strSubject, strBody)
        Catch ex1 As Exception
            emailError = ex1.ToString()
        End Try
        'Create HTML error report.
        strHTML = strHTML & "<TABLE border=0  width=755>"
        strHTML = strHTML & "<TR>" _
                          & "<TD colspan=2>" _
                          & "<H1><FONT COLOR='darkblue'>PaDS Error Report</FONT></H1><HR COLOR='#C0C0C0' width='100%'></TD>"
        strHTML = strHTML & "</TR>"
        strHTML = strHTML & "</TABLE>"

        strHTML = strHTML & "<BR>"

        strHTML = strHTML & "<TABLE border=1 width=755  Frame=box rules=none bordercolor='red' cellpadding=5 cellspacing=0>"
        strHTML = strHTML & "<TR>" _
                          & "<TD>" _
                          & "<P>An Error has occurred on this page, if requested please send the section in blue to Zedra Solutions.<br>" _
                          & "If you require immediate assistance then contact customer services on 01962 738884.<br>"
        strHTML = strHTML & "Or email <a href=""mailto:support@zedra.co.uk" _
                            & "?subject=" & strSubject _
                            & strBody & """ >Support@Zedra.co.uk</A><BR>"
        strHTML = strHTML & "Please select back button to return to PaDS application.</p></TD>"
        strHTML = strHTML & "</TR>"
        strHTML = strHTML & "</TABLE>"

        strHTML = strHTML & "<BR>"

        strHTML = strHTML & "<TABLE border=1 width=755 Frame=box rules=none bordercolor='darkblue'cellpadding=5 cellspacing=0>"
        strHTML = strHTML & "<TR>" _
                         & "<TD width=150 valign=top><P><FONT COLOR='darkblue'><b>Error On Page:</P></b></FONT></TD>" _
                         & "<TD><P>" & currentPage.Request.FilePath & "</P></TD>"
        strHTML = strHTML & "</TR>"
        strHTML = strHTML & "<TR>" _
                           & "<TD width=150 valign=top><P><FONT COLOR='darkblue'><b>User:</P></b></FONT></TD>" _
                           & "<TD><P>" & System.Security.Principal.WindowsIdentity.GetCurrent.Name & "</P></TD>"
        strHTML = strHTML & "</TR>"
        strHTML = strHTML & "<TR>" _
                         & "<TD valign=top><P><FONT COLOR='darkblue'><b>Error Message:</P></b></FONT></TD>" _
                         & "<TD><P>" & ex.Message & "</P></TD>"
        strHTML = strHTML & "</TR>"
        strHTML = strHTML & "<TR>" _
                         & "<TD valign=top><P><FONT COLOR='darkblue'><b>Source:</P></b></FONT></TD>" _
                         & "<TD><P>" & ex.Source & "</P><BR></TD>"
        strHTML = strHTML & "</TR>"
        strHTML = strHTML & "<TR>" _
                        & "<TD valign=top><P><FONT COLOR='darkblue'><b>StackTrace:</P></b></FONT></TD>" _
                        & "<TD><P>" & ex.StackTrace & "</P></TD>"
        strHTML = strHTML & "</TR>"
        If emailError <> "" Then
            strHTML = strHTML & "<TR>" _
                            & "<TD valign=top><P><FONT COLOR='darkblue'><b>Send Email Error:</P></b></FONT></TD>" _
                            & "<TD><P>" & emailError & "</P></TD>"
            strHTML = strHTML & "</TR>"
        End If
        strHTML = strHTML & "</TABLE>"

        strHTML = strHTML & "<TABLE border=0 width=755 >"
        strHTML = strHTML & "<TR>" _
                          & "<TD><input type=button value='<< Back' onClick='history.go(-1)'></TD>"
        strHTML = strHTML & "</TR>"
        strHTML = strHTML & "<TABLE>"

        'Prepare Comment for SessionLog
        Dim strLogComment As String = Nothing
        strLogComment = "Error on Page:" & currentPage.Request.FilePath
        strLogComment = strLogComment & "         User:" & System.Security.Principal.WindowsIdentity.GetCurrent.Name & vbCrLf
        strLogComment = strLogComment & "    Error:" & ex.ToString

        'If we don't want to show the standard error page then we can do the line below and 
        'output want ever we like via a response write or go to our own error page.
        currentPage.server.clearerror()
        currentPage.Response.Write(strHTML)
        'try and write the error out to the log
        Try
            'Me.WriteSessionLog("PageError", strLogComment)
            Dim LogName As String = "PadsApplicationLog"
            Dim SourceName As String = "PaDS"
            If (Not System.Diagnostics.EventLog.SourceExists(SourceName)) Then
                System.Diagnostics.EventLog.CreateEventSource(SourceName, LogName)
            End If
            Dim NewLog As New System.Diagnostics.EventLog
            NewLog.Source = SourceName
            NewLog.WriteEntry(strLogComment, System.Diagnostics.EventLogEntryType.Error)
        Catch ex1 As Exception
            'don't worry if we can't do it
        End Try
    End Sub
    Public Sub PopulateForeignKey(ByRef keyControl As HtmlControls.HtmlInputHidden _
                                    , ByRef dataControl As WebControls.TextBox _
                                    , ByRef link As WebControls.HyperLink _
                                    , ByVal sql As String)
        Me.UserSession.Data("ForeignKeySQL") = sql
        link.NavigateUrl = "javascript:OpenSearch(""" & keyControl.ID & """" _
                                                & ",""" & dataControl.ID & """)"

    End Sub
    Public Sub UpdateSpareFieldPrompts(ByVal spareFieldName As String)

        Dim theControl As Control
        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria
        Dim dr As SqlDataReader = New SqlCommand("Select LookupItemKey SpareFieldNumber" _
                  & "       ,Name SpareFieldPrompt" _
                  & " From lookup" _
                  & " Where LookupName = '" & spareFieldName & "'" _
                  & " AND LookupStatus = 'Active'" _
                  & " Order By DisplayOrder", db.DBConnection, db.DBTransaction).ExecuteReader

        Do While dr.Read()
            Try
                theControl = currentPage.FindControl("SpareFieldPrompt" & dr("SpareFieldNumber"))
                Dim myControl As WebControls.Label = theControl

                myControl.Text = dr("SpareFieldPrompt")
            Catch ex As Exception

            End Try
        Loop
        dr.Close()
    End Sub

    Public Function DateForSQLString(ByVal inDate As DateTime) As String
        Dim outString As String = "'" & inDate.ToString("yyyy-dd-MM HH:mm:ss") & "'"
        Return outString
    End Function

    Public Property FocusControl() As System.Web.UI.Control
        Get
            Return cFocusControl
        End Get
        Set(ByVal Value As System.Web.UI.Control)
            cFocusControl = Value
        End Set
    End Property

    Sub WriteSessionLog(Optional ByVal LogType As String = "PageLoad", Optional ByVal Comment As String = "")
        '*******************************************************************************************
        'Purpose:   Writes a record to the session log
        'Modification History
        'Who                When        What
        '===                ====        ===============
        'James Woosnam      20/10/04    Initial Version
        'James Woosnam      26/2/11     Delegated to BusinessLogic.Logs
        '22/5/11        James Woosnam   HotFix - Add Session and Primary/Secondary Flags to Session Log
        '*******************************************************************************************
        Dim logs As New BusinessLogic.Logs(db, Me.UserSession)
        Dim lPage As System.Web.UI.Page = Me.currentPage
        logs.WriteSessionLog(LogType _
                             , lPage.Request.Path _
                             , Me.pageTitle _
                             , Me.UserSession.UserId _
                             , Me.UserSession.UserName _
                             , New BusinessLogic.StdCode().GetIPAddress(lPage.Request) _
                             , Comment _
                             , IsReadOnlyOnSecondary _
                             , IsDatabaseServerPrimaryOrSecondary _
                             , IsWebServerPrimaryOrSecondary)

    End Sub
    Public Function ValidateRecordsToShow(ByVal recordsToShow As String) As String
        '*******************************************************************************************
        'Purpose:   Ensures that records to show value is a valid value.
        '*******************************************************************************************
        If recordsToShow = "" _
         Or Not IsNumeric(recordsToShow) Then
            ValidateRecordsToShow = "20"
        Else
            ValidateRecordsToShow = recordsToShow
        End If
    End Function
    Sub FieldErrorControl(ByRef inputField As System.Web.UI.WebControls.WebControl, Optional ByVal errorMessage As String = Nothing)
        '******************************************
        'Sets error message and control background color
        '******************************************
        inputField.CssClass = "fldEntryError"
        If Not errorMessage Is Nothing Then
            Me.PageError = errorMessage
        End If
        Me.IsValid = False
    End Sub

    Sub FieldValidateNumber(ByRef inputField As System.Web.UI.WebControls.TextBox, Optional ByVal Mandatory As Boolean = False)
        If Mandatory And inputField.Text = "" Then
            Me.FieldValidateMandatory(inputField)
        Else
            inputField.CssClass = "fldEntry"
        End If
        If inputField.Text <> "" Then
            If Not IsNumeric(inputField.Text) Then
                FieldErrorControl(inputField, inputField.ID & " must be a numerical value")
            Else
                inputField.CssClass = "fldEntry"
            End If
        End If
    End Sub
    Sub FieldValidateEmail(ByRef inputField As System.Web.UI.WebControls.TextBox, Optional ByVal Mandatory As Boolean = False)
        If Mandatory And inputField.Text = "" Then
            Me.FieldValidateMandatory(inputField)
        End If
        If inputField.Text <> "" Then
            If Not Me.StdCode.IsValidEmail(inputField.Text) Then
                FieldErrorControl(inputField, inputField.ID & " is not valid")
            Else
                inputField.CssClass = "fldEntry"
            End If

        End If
    End Sub
    '03/04/08 Julian Gates  Add New FieldValidateDate to format dates to British format
    Sub FieldValidateDate(ByRef inputField As System.Web.UI.WebControls.TextBox, Optional ByVal Mandatory As Boolean = False)
        If Mandatory And inputField.Text = "" Then
            Me.FieldValidateMandatory(inputField)
        End If
        If inputField.Text <> "" Then
            If Not Me.StdCode.IsValidDate(inputField.Text) Then
                FieldErrorControl(inputField, inputField.ID & " must be a date")
            Else
                inputField.Text = FormatDate(inputField.Text)
                inputField.CssClass = "fldEntry"
            End If
        End If
    End Sub
    Sub FieldValidateMandatory(ByRef inputField As System.Web.UI.WebControls.TextBox)
        If inputField.Text = "" Then
            FieldErrorControl(inputField, inputField.ID & " is mandatory")
        Else
            inputField.CssClass = "fldEntry"
        End If
    End Sub
    Sub DropDownValidateMandatory(ByRef inputField As System.Web.UI.WebControls.DropDownList, Optional ByVal FriendlyName As String = "")
        If FriendlyName = "" Then
            FriendlyName = inputField.ID
        End If

        If inputField.SelectedValue = "" Then
            FieldErrorControl(inputField, FriendlyName & " is mandatory")
        Else
            inputField.CssClass = "fldEntry"
        End If
    End Sub
    Sub FKValidateMandatory(ByRef inputFK As Object, ByVal FriendlyName As String)
        If inputFK.ForeignKeyHidden.Value = "" Then
            inputFK.ErrLabel.Visible = True
            Me.PageError = FriendlyName & " is mandatory"
            Me.IsValid = False
        End If
    End Sub
    Public Sub ListBoxValidateMandatory(ByRef inputField As System.Web.UI.WebControls.ListBox, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = inputField.ID
        End If

        If inputField.SelectedValue = "" Then
            FieldErrorControl(inputField, FriendlyName & " is mandatory")
        End If
    End Sub
    Public Function FormatMonetaryValueForDislpay(ByVal value As String) As String
        If Not IsNumeric(value) Then
            Return value
        End If
        Dim currValue As Decimal = CType(value, Decimal)
        Dim provider As System.IFormatProvider = Nothing
        'provider()
        Return currValue.ToString("N")

    End Function
    Public Property InfoMessage() As String
        Get
            Return pstrInfoMessage
        End Get
        Set(ByVal Value As String)
            Me.AddAdditionalInfoForlog("Info:" & Value)
            If pstrInfoMessage = "" Then
                ' pstrErrMsg = "<SPAN class=errMsgTitle>The following errors have been found:</SPAN>"
                pstrInfoMessage = pstrInfoMessage + "&nbsp;&nbsp;&nbsp;"
            End If
            pstrInfoMessage = pstrInfoMessage & "<SPAN class=infoMsg>" & Value.Replace(vbCr, "<BR>") & "</SPAN>"
        End Set
    End Property

    Public Function OutputMenu(ByVal loggedIn As Boolean) As String
        'Modificatiom History
        '20/11/2006  Hide Home and Admin links form homepage when user is not logged in as modification
        '23/10/19   Julian Gates    SIR4943 - Only show Subscriber Renewal menu item for GroupRenewer
        '05/02/2020 Julian Gates    SIR5007 - Change Subscriber, Order and Cashbook select page links.
        Dim strHTML As String = Nothing
        'If Not IsInGroup("User") Then
        strHTML = strHTML + "<!--  **** Menu Start **** -->" & Chr(13)
        strHTML += "<Table width='750' border='0'>" & Chr(13)
        strHTML += "	<TR>" & Chr(13)
        If loggedIn Then
            Select Case Me.UserSession.AuthorityLevel
                Case BusinessLogic.UserSession.AuthorityLevels.GroupRenewer
                Case Else
                    '20/11/2006  JGates  Moved Home to be shown only when user is logged in
                    strHTML += "		<TD  Class='Menu'><A href='../Pages/pg100HomeAdmin.aspx' Title='Home'>"
                    strHTML += "			  <SPAN id='Menu1' name='Menu1' Class='Menu' >Home</SPAN>" & Chr(13)
                    strHTML += "			</A>" & Chr(13)
                    strHTML += "		</TD>" & Chr(13)
                    strHTML += "		<TD  Class='Menu'><A href='../Pages/pg110SubscriberSelect.aspx' Title='Subscribers'>"
                    strHTML += "			  <SPAN id='Menu1' name='Menu1' Class='Menu' >Subscribers</SPAN>" & Chr(13)
                    strHTML += "			</A>" & Chr(13)
                    strHTML += "		</TD>" & Chr(13)
                    strHTML += "		<TD  Class='Menu'><A href='../Pages/pg140OrderSelect.aspx' Title='Order Search and List'>"
                    strHTML += "			  <SPAN id='Menu1' name='Menu1' Class='Menu' >Orders</SPAN>" & Chr(13)
                    strHTML += "			</A>" & Chr(13)
                    strHTML += "		</TD>" & Chr(13)
                    '28/1/16    James Woosnam   SIR4072 - Correctly apply security to menu
                    Select Case Me.UserSession.AuthorityLevel
                        Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                            strHTML += "		<TD  Class='Menu'><A href='../Pages/pg150CashbookSelect.aspx' Title='Cashbook Search and List'>"
                            strHTML += "			  <SPAN id='Menu1' name='Menu1' Class='Menu' >Cashbook</SPAN>" & Chr(13)
                            strHTML += "			</A>" & Chr(13)
                            strHTML += "		</TD>" & Chr(13)
                            strHTML += "		<TD  Class='Menu'><A href='../Pages/pg170BankDepositSelect.aspx' Title='Bank Deposits'>"
                            strHTML += "			  <SPAN id='Menu1' name='Menu1' Class='Menu' >Deposits</SPAN>" & Chr(13)
                            strHTML += "			</A>" & Chr(13)
                            strHTML += "		</TD>" & Chr(13)
                            strHTML += "		<TD  Class='Menu'><A href='../Pages/pg180OrderDespatch.aspx' Title='Despatch Orders'>"
                            strHTML += "			  <SPAN id='Menu1' name='Menu1' Class='Menu' >Despatch</SPAN>" & Chr(13)
                            strHTML += "			</A>" & Chr(13)
                            strHTML += "		</TD>" & Chr(13)
                    End Select
                    strHTML += "		<TD  Class='Menu'><A href='../Pages/pg482SubscriberInProgressImportsSelect.aspx' Title='Bulk Import Subscribers'>"
                    strHTML += "			  <SPAN id='Menu1' name='Menu1' Class='Menu' >Imports</SPAN>" & Chr(13)
                    strHTML += "			</A>" & Chr(13)
                    strHTML += "		</TD>" & Chr(13)
                    '28/1/16    James Woosnam   SIR4072 - Correctly apply security to menu
                    Select Case Me.UserSession.AuthorityLevel
                        Case BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                            '12/01/16   Julian Gates    SIR4070 - Change Users link to go to new .Net version of User page
                            strHTML += "		<TD  Class='Menu'><A href='../Pages/pg060UserSelect.aspx' Title='User List'>"
                            strHTML += "			  <SPAN id='Menu1' name='Menu1' Class='Menu' >Users</SPAN>" & Chr(13)
                            strHTML += "			</A>" & Chr(13)
                            strHTML += "		</TD>" & Chr(13)
                    End Select
                    '28/1/16    James Woosnam   SIR4072 - Correctly apply security to menu
                    strHTML += "		<td  Class='Menu'><a href='../Pages/pg450Reports.aspx' Title=""Create and Run Reports"">"
                    strHTML += "			  <span id='Menu1' name='Menu1' Class='Menu' >Reports</span>" & Chr(13)
                    strHTML += "			</a>" & Chr(13)
                    strHTML += "		</td>" & Chr(13)
            End Select
        Else
            '20/11/2006 Show single lines when not logged in
            strHTML = strHTML + "	<HR ALIGN=left SIZE=3 COLOR='#008000'>" & Chr(13)
            'End If
            strHTML = strHTML + "	</TR>" & Chr(13)
            strHTML = strHTML + "</TABLE>" & Chr(13)
            strHTML = strHTML + "<!--  **** Menu End **** -->" & Chr(13)
            'If IsInGroup("User") Then
            '    strHTML = strHTML + "<Table width=" & glngTargetPrintWidth & ">" & strLine
            '    strHTML = strHTML + "	<TR>" & strLine
            '    strHTML = strHTML + "	<HR ALIGN=left SIZE=3 COLOR='#008000'>" & strLine
            '    strHTML = strHTML + "	</TR>" & strLine
            '    strHTML = strHTML + "</TABLE>" & strLine
            '    strHTML = strHTML + "<!--  **** Menu End **** -->" & strLine
            '    Response.Write(strHTML)
        End If
        Return strHTML
    End Function

    Function CompanyTable(ByVal aliasName As String, ByVal userId As Integer) As String
        CompanyTable = "f530SecureCompany(" _
                 & userId _
                 & ")" _
             & " " & aliasName
    End Function

    Function CheckColumn(ByVal Name As String, ByVal dt As DataTable, Optional ByRef ErrorMessage As String = Nothing) As Boolean
        ErrorMessage = Nothing
        For col As Integer = 0 To dt.Columns.Count - 1
            If Name.ToUpper = dt.Columns(col).ColumnName.ToUpper Then
                Return True
            End If
        Next
        ErrorMessage += "Column '" & Name & "' missing"
        Return False
    End Function

    Function SubscriberTable(ByVal strAliasName As String) As String
        '7/2/20     James Woosnam   Put in sub query to remove duplicates
        SubscriberTable = " (SELECT DISTINCT " _
            & " s.*" _
            & " FROM Subscriber s" _
            & "     INNER JOIN SubscriberAffiliate SAJoin" _
            & "     ON SAJoin.ChildSubscriberId = s.SubscriberId" _
            & "     AND SAJoin.ParentSubscriberId IN (0" & Me.UserSession.Data("AuthorisedSubscribers") & ")" _
            & "     AND " & StdCode.vFQ(Now(), "D") & " Between SAJoin.StartDate AND SAJoin.EndDate" _
            & " ) " & strAliasName
    End Function

    Function GetMultiLineBuildingAddress(ByVal strBuildingStreet As String) As String()
        Try
            Dim strLineLeft As String = strBuildingStreet
            Dim lngPos As Integer = 0
            Dim lngNextPos As Integer = strLineLeft.IndexOf(vbCrLf, lngPos)
            Dim lngLineNo As Integer = 0
            Dim sOutAddress() As String = {"", "", "", ""}
            Do While lngNextPos > 0
                sOutAddress(lngLineNo) = strBuildingStreet.Substring(lngPos, lngNextPos - lngPos)
                strLineLeft = strBuildingStreet.Substring(lngNextPos + 2)
                lngPos = lngNextPos + 2
                lngNextPos = strBuildingStreet.IndexOf(vbCrLf, lngPos)
                lngLineNo = lngLineNo + 1
                If lngLineNo > 3 Then
                    Throw New Exception("Building Street can only be 4 lines")
                End If
            Loop
            If lngNextPos = -1 And strLineLeft.Length > 0 Then
                sOutAddress(lngLineNo) = strBuildingStreet.Substring(lngPos)
                lngLineNo = lngLineNo + 1
            End If
            Do While lngLineNo <= 3
                sOutAddress(lngLineNo) = Nothing
                lngLineNo = lngLineNo + 1
            Loop

            Return sOutAddress
        Catch ex As Exception
            Throw New Exception(ex.ToString)
        End Try
    End Function
    Public Sub ExportDataTableAsXLSToBrowser(ByVal tbl As DataTable, Optional ByVal TemplateLocation As String = Nothing, Optional ByVal OutFileName As String = "ExportData")
        '******************************************************
        'Description:	Exports data into a XLS file
        '******************************************************
        '2/4/08     James Woosnam   SIR1503 - Add ExportDataTableAsXLSToBrowser Function
        Try
            If tbl.Rows.Count = 0 Then
                Me.PageError = "Data not found"
            Else
                Dim i As Integer
                Dim workbook As SpreadsheetGear.IWorkbook
                If TemplateLocation = Nothing Then
                    workbook = SpreadsheetGear.Factory.GetWorkbook()
                Else
                    workbook = SpreadsheetGear.Factory.GetWorkbook(TemplateLocation)
                End If
                'Dim workbook As SpreadsheetGear.IWorkbook = SpreadsheetGear.Factory.GetWorkbook()
                Dim worksheet As SpreadsheetGear.IWorksheet = workbook.Worksheets(0)

                worksheet.Name = OutFileName

                For col As Integer = 0 To tbl.Columns.Count - 1
                    worksheet.Cells(0, col).Value = tbl.Columns(col).ColumnName
                Next
                i = 0
                For row As Integer = 0 To tbl.Rows.Count - 1
                    If Not tbl.Rows(row).RowState = DataRowState.Deleted Then
                        For col As Integer = 0 To tbl.Columns.Count - 1
                            worksheet.Cells(i + 1, col).Value = CStr(Me.StdCode.IsNull(tbl.Rows(row)(col), ""))
                        Next
                        i = i + 1
                    End If
                Next

                ' Auto size all worksheet columns which contain data
                worksheet.UsedRange.Columns.AutoFit()
                OutFileName = OutFileName.Replace(" ", "")
                If Right(OutFileName, 4).ToLower <> ".xlsx" Then
                    OutFileName += ".xlsx"
                End If
                ' Stream the Excel spreadsheet to the client.
                Me.currentPage.Response.Clear()
                Me.currentPage.Response.ContentType = "application/vnd.ms-excel"
                Me.currentPage.Response.AddHeader("Content-Disposition", "attachment; filename=" & OutFileName)
                workbook.SaveToStream(Me.currentPage.Response.OutputStream, SpreadsheetGear.FileFormat.OpenXMLWorkbook)
                Me.currentPage.Response.End()
            End If
        Catch e As Exception
            Throw New Exception(e.ToString)
        End Try
    End Sub

    Function FormatDate(ByVal dateValue As Object) As Object
        '******************************************
        'Sets input date value to correct format
        '******************************************
        Select Case dateValue.GetType.ToString
            Case "String"
                If dateValue = "" Then
                    Return dateValue
                End If
        End Select
        If dateValue Is System.DBNull.Value Or dateValue Is Nothing Then
        Else
            dateValue = CDate(dateValue).ToString("dd-MMM-yyyy HH:mm:ss")
            If StdCode.IsValidDate(dateValue) Or IsDate(dateValue) Then
                Dim dateOnly = CDate(dateValue).ToString("dd-MMM-yyyy")
                If CDate(dateValue) > dateOnly Then
                    dateValue = CDate(dateValue).ToString("dd-MMM-yyyy HH:mm:ss")
                Else
                    dateValue = dateOnly
                End If
            End If

        End If

        Return dateValue
    End Function

    Public Function GetBeginsWithSearch(ByVal SearchString As String, ByVal BeginsWith As Boolean) As String
        If IsNumeric(SearchString) Then
            Return SearchString
        Else
            If BeginsWith Then
                Return SearchString & "%"
            Else
                Return "%" & SearchString & "%"
            End If
        End If
    End Function

    Function GetProcessTime(ByVal dateTime As String, ByVal endDateTime As String) As String
        'Returns the Process time
        Dim processTime As System.TimeSpan

        If dateTime <> "" And endDateTime <> "" Then
            processTime = CDate(dateTime).Subtract(CDate(endDateTime))
            GetProcessTime = processTime.ToString.Replace("-", "")
        Else
            GetProcessTime = ""
        End If
    End Function

    Public Sub PopulateDataTableFromPageTable(ByRef tblData As DataTable, ByVal tblPage As System.Web.UI.WebControls.Table, ByVal KeyFieldName As String, Optional uniqueCntlID As Integer = Nothing)
        For Each rowtblPage As System.Web.UI.WebControls.TableRow In tblPage.Rows
            Dim dataRow As DataRow = Nothing
            Dim Dummy As Int32
            Dim result As [Boolean] = Int32.TryParse(rowtblPage.ID, Dummy)
            If result Then
                For Each rowtblRow As DataRow In tblData.Rows
                    If uniqueCntlID <> Nothing Then
                        If CInt(rowtblRow(KeyFieldName) & uniqueCntlID) = Int32.Parse(rowtblPage.ID) Then
                            dataRow = rowtblRow
                            Exit For
                        End If
                    Else
                        If CInt(rowtblRow(KeyFieldName)) = Int32.Parse(rowtblPage.ID) Then
                            dataRow = rowtblRow
                            Exit For
                        End If
                    End If
                Next
                If uniqueCntlID <> Nothing Then
                    uniqueCntlID += 1
                End If
                For Each cell As System.Web.UI.WebControls.TableCell In rowtblPage.Cells
                    For Each cntl As Control In cell.Controls
                        If (cntl.ID IsNot Nothing) Then
                            'If is has an id then it is a form control 
                            For Each col As DataColumn In tblData.Columns
                                If cntl.ID.Contains(col.ColumnName) Then
                                    Dim cValue As String = Nothing
                                    Select Case cntl.ToString()
                                        Case "System.Web.UI.WebControls.Label"
                                            Dim lb As System.Web.UI.WebControls.Label = DirectCast(cntl, System.Web.UI.WebControls.Label)
                                            cValue = lb.Text
                                            Exit Select
                                        Case "System.Web.UI.WebControls.TextBox"
                                            Dim tb As System.Web.UI.WebControls.TextBox = DirectCast(cntl, System.Web.UI.WebControls.TextBox)
                                            cValue = tb.Text
                                            Exit Select
                                        Case "System.Web.UI.WebControls.DropDownList"
                                            Dim dd As System.Web.UI.WebControls.DropDownList = DirectCast(cntl, System.Web.UI.WebControls.DropDownList)
                                            cValue = dd.SelectedValue
                                            Exit Select
                                        Case "System.Web.UI.WebControls.RadioButtonList"
                                            Dim rbl As System.Web.UI.WebControls.RadioButtonList = DirectCast(cntl, System.Web.UI.WebControls.RadioButtonList)
                                            cValue = rbl.SelectedValue
                                            Exit Select
                                        Case "System.Web.UI.WebControls.ListBox"
                                            Dim lb As System.Web.UI.WebControls.ListBox = DirectCast(cntl, System.Web.UI.WebControls.ListBox)
                                            cValue = lb.SelectedValue
                                            Exit Select
                                        Case "System.Web.UI.WebControls.CheckBox"
                                            Dim cb As System.Web.UI.WebControls.CheckBox = DirectCast(cntl, System.Web.UI.WebControls.CheckBox)
                                            cValue = cb.Checked
                                            Exit Select
                                        Case Else
                                            Throw New Exception("Control:" & cntl.ToString() & " not handled")

                                    End Select

                                    Select Case col.DataType.Name
                                        Case "Int32", "Double"
                                            If cValue = "" Then
                                                If col.AllowDBNull Then
                                                    dataRow(col.ColumnName) = System.DBNull.Value
                                                Else
                                                    Throw New Exception(col.ColumnName & " must have a value")
                                                End If
                                            Else
                                                If IsNumeric(cValue) Then
                                                    dataRow(col.ColumnName) = cValue
                                                Else
                                                    Throw New Exception(cValue & " is not a number and therefore can't be entered into " & col.ColumnName)
                                                End If
                                            End If
                                        Case "DateTime"
                                            If cValue = "" Then
                                                If col.AllowDBNull Then
                                                    dataRow(col.ColumnName) = System.DBNull.Value
                                                Else
                                                    Throw New Exception(col.ColumnName & " must have a value")
                                                End If
                                            Else
                                                If IsDate(cValue) Then
                                                    dataRow(col.ColumnName) = cValue
                                                Else
                                                    Throw New Exception(cValue & " is not a valid date and therefore can't be entered into " & col.ColumnName)
                                                End If
                                            End If
                                        Case Else
                                            If cValue = "" Then
                                                If col.AllowDBNull Then
                                                    dataRow(col.ColumnName) = System.DBNull.Value
                                                Else
                                                    Throw New Exception(col.ColumnName & " must have a value")
                                                End If
                                            Else
                                                dataRow(col.ColumnName) = cValue
                                            End If
                                    End Select
                                End If
                            Next
                        End If
                    Next
                Next

            End If
        Next
    End Sub

    Public Sub PopOpenFileBytes(FileName As String, FileBytes As Byte())
        Try
            Me.currentPage.Response.Clear()
            Me.currentPage.ContentType = "application/vnd.ms-excel"

            Me.currentPage.Response.AddHeader("Content-Disposition", "attachment; filename=" & FileName.Replace(" ", ""))
            Me.currentPage.Response.BinaryWrite(FileBytes)

        Catch ex As Exception
            Throw New Exception("PopOpenFileBytes Failed:" & ex.Message)
        End Try

        '03/07/12 Julian Gates  Moved  Me.CurrentPage.Response.End() out of try catch statement
        If Me.IsValid Then
            Me.currentPage.Response.End()
        End If
    End Sub
    Public Sub SmartSearch(SearchText As String)
        '28/2/22    James Woosnam   SIR5443 - Add SmartSearch
        Dim url As String = ""
        Try
            If SearchText = "" Then Throw New Exception("Search Text needs to be entered")
            SearchText = SearchText.Trim
            Dim searchTypes As String = "SOCU"
            Dim SingleSearchType As String = ""
            Dim searchNumber As Integer = 0
            Dim firstChar As String = Left(SearchText, 1).ToUpper
            If searchTypes.Contains(firstChar) AndAlso SearchText.Length > 1 AndAlso IsNumeric(Right(SearchText, SearchText.Length - 1)) Then
                SingleSearchType = firstChar
                searchNumber = Right(SearchText, SearchText.Length - 1)
            End If
            If IsNumeric(SearchText) Then searchNumber = SearchText

            If IsNumeric(searchNumber) And searchNumber <> 0 Then
                If (SingleSearchType = "" Or SingleSearchType = "S") AndAlso db.DLookup("SubscriberId", "Subscriber", "SubscriberId=" & searchNumber) IsNot Nothing Then
                    url = "pg111SubscriberDisplay.aspx?SubscriberId=" & searchNumber
                    Exit Try
                End If
                If (SingleSearchType = "" Or SingleSearchType = "U") AndAlso db.DLookup("UserId", "RemoteUser", "UserId=" & searchNumber) IsNot Nothing Then
                    url = "pg061UserMaint.aspx?UserId=" & searchNumber
                    Exit Try
                End If
                If (SingleSearchType = "" Or SingleSearchType = "O") AndAlso db.DLookup("OrderNumber", "SalesOrder", "OrderNumber=" & searchNumber) IsNot Nothing Then
                    url = "pg142OrderMaint2.aspx?OrderNumber=" & searchNumber
                    Exit Try
                End If
                If (SingleSearchType = "" Or SingleSearchType = "C") AndAlso db.DLookup("CashbooNumber", "Cashbook", "CashbooNumber=" & searchNumber) IsNot Nothing Then
                    url = "pg151CashbookMaint.aspx?CashbooNumber=" & searchNumber
                    Exit Try
                End If
                Me.PageError = "No matches for:" & SearchText
            Else
                Dim Id As Integer
                Dim t As DataTable = Nothing
                Dim sql As String = ""



                'SubscriberId or email
                sql = "SELECT * FROM Subscriber WHERE SubscriberStatus IN ('Current','Proposed') AND SubscriberName LIKE '%" & SearchText & "%'"
                t = db.GetDataTableFromSQL(sql)
                Select Case t.Rows.Count
                    Case 0
                    Case 1
                        url = "pg111SubscriberDisplay.aspx?SubscriberId=" & t.Rows(0)("SubscriberId")
                    Case Else
                        url = "pg110SubscriberSelect.aspx?SubscriberName=" & SearchText
                End Select
                If url <> "" Then Exit Try

                'Email address
                If SearchText.Contains("@") Or t.Rows.Count = 0 Then '@ is search or no matching subs found
                    sql = "SELECT * FROM remoteUser WHERE UserStatus IN ('Active','Emailed') AND EmailAddress LIKE '%" & SearchText & "%'"
                    t = db.GetDataTableFromSQL(sql)
                    Select Case t.Rows.Count
                        Case 0
                        Case 1
                            url = "pg061UserMaint.aspx?UserId=" & t.Rows(0)("UserId")
                        Case Else
                            url = "pg060UserSelect.aspx?EmailAddress=" & SearchText
                    End Select
                    If url <> "" Then Exit Try
                End If
                'Catch all
                url = "pg110SubscriberSelect.aspx?SubscriberName=" & SearchText

            End If
        Catch ex As Exception
            Me.PageError = "SmartSearch Failed:" & ex.Message
        End Try
        If Me.IsValid Then
            currentPage.Response.Redirect(url)
        End If
    End Sub

    '28/02/22   Julian Gates    SIR5391 - Add Sub FieldValidateFirstLastNameInput
    Public Sub FieldValidateFirstLastNameInput(ByRef inputField As System.Web.UI.WebControls.TextBox)
        Try
            If Not String.IsNullOrEmpty(inputField.Text) Then

                Dim sChars As String = Me.db.GetParameterValue("InvalidFirstLastNameCharacters")
                Dim sValue As String = db.IsDBNull(inputField.Text, "")
                Dim InvalidChars As String = Nothing
                For iCtr As Integer = 0 To sValue.Length - 1
                    Dim sChar As String = sValue.Substring(iCtr, 1)
                    If sChars.Contains(sChar) Then
                        InvalidChars += sChar & " "
                    End If
                Next
                If InvalidChars <> Nothing Then
                    FieldErrorControl(inputField, inputField.ID & " contains characters " & InvalidChars & " which are invalid.")
                Else
                    inputField.CssClass = "fldEntry"
                End If
            End If
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Function LookupSQL(ByVal lookupName As String) As String
        Dim sql As String
        sql = "SELECT LookupItemKey"
        sql += "      ,Name"
        sql += " FROM Lookup"
        sql += " WHERE LookupName = '" & lookupName & "'"
        sql += " AND Lookup.LookupStatus = 'Active'"
        sql += " ORDER BY DisplayOrder, Name,LookupItemKey"

        Return sql
    End Function

    Public Sub PopulateDevExpressDropDownListFromLookup(ByVal theDropdown As DevExpress.Web.ASPxComboBox, ByVal lookupName As String, ByVal initialValue As Object)
        'Populates a asp Dropdown list from the lookup table using the PopulateDropDownListFromSql 

        theDropdown.DropDownStyle = DevExpress.Web.DropDownStyle.DropDownList
        theDropdown.IncrementalFilteringMode = DevExpress.Web.IncrementalFilteringMode.Contains
        theDropdown.TextFormatString = ""
        PopulateDevExpressDropDownListFromSQL(theDropdown, LookupSQL(lookupName), initialValue)
    End Sub
    Public Sub PopulateXRadioListFromLookup(ByVal theRadioList As DevExpress.Web.ASPxRadioButtonList, ByVal LookupName As String, ByVal initialValue As Object)
        PopulateXRadioListFromSQL(theRadioList, LookupSQL(LookupName), initialValue)
    End Sub
    Public Sub PopulateXRadioListFromSQL(ByVal theRadioList As DevExpress.Web.ASPxRadioButtonList, ByVal SQL As String, ByVal initialValue As Object)
        Dim tbl As DataTable = db.GetDataTableFromSQL(SQL)
        Try

            theRadioList.ValueType = tbl.Columns(0).DataType
            theRadioList.TextField = tbl.Columns(1).ColumnName
            theRadioList.ValueField = tbl.Columns(0).ColumnName
            theRadioList.DataSource = tbl
            theRadioList.DataBind()
            If Not db.IsDBNull(initialValue) Then
                theRadioList.Value = initialValue
            End If
        Catch ex As Exception
            Throw New Exception(("Drop down list not built for " & theRadioList.ID & ". - ") + ex.Message, New Exception(("SQL:" & SQL) + ex.ToString()))
        End Try
    End Sub
    Public Sub PopulateXRadioListFromCommaSeperatedList(ByVal theRadioList As DevExpress.Web.ASPxRadioButtonList, ByVal CSLValues As String, ByVal initialValue As Object)
        'Populates a Dev Express multi list Dropdown list using SQL query 
        Try
            Dim values() As String = CSLValues.Split(",")
            theRadioList.DataSource = values
            theRadioList.DataBind()
            If Not db.IsDBNull(initialValue) Then
                theRadioList.Value = initialValue
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message, ex)
        End Try
    End Sub
    Public Sub PopulateDevExpressDropDownListFromView(ByVal theDropdown As DevExpress.Web.ASPxComboBox, ByVal vw As DataView, ByVal initialValue As Object)
        Try
            Dim tbl As DataTable = vw.Table
            If tbl.Columns.Count > 2 _
                And theDropdown.Columns.Count = 0 Then

                Dim iCol As Integer = 0
                For Each col As DataColumn In tbl.Columns
                    iCol += 1
                    If iCol > 1 Then
                        theDropdown.Columns.Add(New DevExpress.Web.ListBoxColumn(col.ToString))
                    End If
                Next
            End If
            theDropdown.ValueType = tbl.Columns(0).DataType
            theDropdown.TextField = tbl.Columns(1).ColumnName
            theDropdown.ValueField = tbl.Columns(0).ColumnName
            theDropdown.DataSource = vw
            theDropdown.DataBind()
            If Not db.IsDBNull(initialValue) Then
                theDropdown.Value = initialValue
            End If
        Catch ex As Exception
            Throw New Exception(("Drop down list not built for " & theDropdown.ID & ". - ") + ex.Message, ex)
        End Try
    End Sub
    Public Sub PopulateDevExpressDropDownListFromSQL(ByVal theDropdown As DevExpress.Web.ASPxComboBox, ByVal SQL As String, ByVal initialValue As Object)
        'Populates a Dev Express multi list Dropdown list using SQL query 
        Try
            Dim tbl As DataTable = db.GetDataTableFromSQL(SQL)
            PopulateDevExpressDropDownListFromView(theDropdown, New DataView(tbl, "", "", DataViewRowState.CurrentRows), initialValue)
        Catch ex As Exception
            Throw New Exception(ex.Message, New Exception(("SQL:" & SQL) + ex.ToString()))
        End Try

    End Sub
    Public Sub PopulateDevExpressDropDownListFromCommaSeperatedList(ByVal theDropdown As DevExpress.Web.ASPxComboBox, ByVal CSLValues As String, ByVal initialValue As Object)
        'Populates a Dev Express multi list Dropdown list using SQL query 
        Try
            Dim values() As String = CSLValues.Split(",")
            theDropdown.DataSource = values
            theDropdown.DataBind()
            If Not db.IsDBNull(initialValue) Then
                theDropdown.Value = initialValue
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message, ex)
        End Try

    End Sub
    Public Sub PopulateDevExpressListBoxFromLookup(ByVal theListBox As DevExpress.Web.ASPxListBox, ByVal lookupName As String, ByVal initialValue As Object)

        PopulateDevExpressListBoxSQL(theListBox, LookupSQL(lookupName), initialValue)
    End Sub
    Public Sub PopulateDevExpressListBoxSQL(ByVal theListBox As DevExpress.Web.ASPxListBox, ByVal SQL As String, ByVal initialValue As Object)
        'Populates a Dev Express list box list using SQL query 

        Dim tbl As DataTable = db.GetDataTableFromSQL(SQL)
        Try
            If tbl.Columns.Count > 2 _
                And theListBox.Columns.Count = 0 Then

                Dim iCol As Integer = 0
                For Each col As DataColumn In tbl.Columns
                    iCol += 1
                    If iCol > 1 Then
                        theListBox.Columns.Add(New DevExpress.Web.ListBoxColumn(col.ToString))
                    End If
                Next
            End If
            theListBox.ValueType = tbl.Columns(0).DataType
            theListBox.TextField = tbl.Columns(1).ColumnName
            theListBox.ValueField = tbl.Columns(0).ColumnName
            theListBox.DataSource = tbl
            theListBox.DataBind()
            theListBox.Rows = IIf(tbl.Rows.Count >= 10, 10, tbl.Rows.Count)
            If Not db.IsDBNull(initialValue) Then
                theListBox.Value = initialValue
            End If
        Catch ex As Exception
            Throw New Exception(("list box not built for " & theListBox.ID & ". - ") + ex.Message, New Exception(("SQL:" & SQL) + ex.ToString()))
        End Try
    End Sub
    Private Sub DXFieldErrorControl(ByRef inputField As WebControl)
        DXFieldErrorControl(inputField, String.Empty)
    End Sub

    Public Sub DXFieldErrorControl(ByRef inputField As DropDownList, ByVal errorMessage As String)
        Dim wcInputField As WebControl = DirectCast(inputField, WebControl)
        DXFieldErrorControl(wcInputField, errorMessage)
        inputField = DirectCast(wcInputField, DropDownList)
    End Sub

    Public Sub DXFieldErrorControl(ByRef inputField As TextBox, ByVal errorMessage As String)
        Dim wcInputField As WebControl = DirectCast(inputField, WebControl)
        DXFieldErrorControl(wcInputField, errorMessage)
        inputField = DirectCast(wcInputField, TextBox)
    End Sub

    Public Sub DXFieldErrorControl(ByRef inputField As ListBox, ByVal errorMessage As String)
        Dim wcInputField As WebControl = DirectCast(inputField, WebControl)
        DXFieldErrorControl(wcInputField, errorMessage)
        inputField = DirectCast(wcInputField, ListBox)
    End Sub

    Public Sub DXFieldErrorControl(ByRef inputField As CheckBox, ByVal errorMessage As String)
        Dim wcInputField As WebControl = DirectCast(inputField, WebControl)
        DXFieldErrorControl(wcInputField, errorMessage)
        inputField = DirectCast(wcInputField, CheckBox)
    End Sub

    Public Sub DXFieldErrorControl(ByRef inputField As WebControl, ByVal errorMessage As String, Optional IsWarning As Boolean = False)
        '****************************************** 
        'Sets error message and control background color 
        '****************************************** 
        inputField.CssClass = "fldEntryError"
        If (errorMessage IsNot Nothing) Then
            Me.PageError = errorMessage
        End If
    End Sub

    Public Sub DXCheckBoxValidateMandatory(ByRef inputField As DevExpress.Web.ASPxCheckBox, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If

        If inputField.Checked = False Then
            DXFieldErrorControl(inputField, FriendlyName & " is mandatory")
        Else
            inputField.CssClass = "pageField"
        End If
    End Sub

    Private Function FriendlyNameFromFieldName(ByVal FieldName As Object) As String
        Dim sOut As String = Nothing
        Dim StdCode As New BusinessLogic.StdCode()
        'sOut = StdCode.InsertCapitalSpaces(FieldName)
        sOut = FieldName
        sOut = sOut.Replace("_", " ")
        Return sOut
    End Function

    Public Sub DXFieldValidatePercent(ByRef inputField As DevExpress.Web.ASPxEditBase, ByVal Mandatory As Boolean)
        DXFieldValidatePercent(inputField, Mandatory, String.Empty)
    End Sub

    Public Sub DXFieldValidatePercent(ByRef inputField As DevExpress.Web.ASPxEditBase)
        DXFieldValidatePercent(inputField, False, String.Empty)
    End Sub

    Public Sub DXFieldValidatePercent(ByRef inputField As DevExpress.Web.ASPxEditBase, ByVal Mandatory As Boolean, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If
        If inputField.Value <> String.Empty Then
            If Not IsNumeric(inputField.Value.ToString.Replace("%", "")) Then
                DXFieldErrorControl(inputField, FriendlyName & " must be a numerical percentage value")
            Else
                inputField.CssClass = "pageField"
            End If
        Else
            If Mandatory = True Then
                DXFieldErrorControl(inputField, FriendlyName & " is mandatory")
            Else
                inputField.CssClass = "pageField"
            End If
        End If
    End Sub

    Public Sub DXFieldValidateNumber(ByRef inputField As DevExpress.Web.ASPxEditBase, ByVal Mandatory As Boolean)
        DXFieldValidateNumber(inputField, Mandatory, String.Empty)
    End Sub

    Public Sub DXFieldValidateNumber(ByRef inputField As DevExpress.Web.ASPxEditBase)
        DXFieldValidateNumber(inputField, False, String.Empty)
    End Sub

    Public Sub DXFieldValidateNumber(ByRef inputField As DevExpress.Web.ASPxEditBase, ByVal Mandatory As Boolean, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If
        If inputField.Value <> String.Empty Then
            If Not IsNumeric(inputField.Value) Then
                DXFieldErrorControl(inputField, FriendlyName & " must be a numerical value")
            Else
                inputField.CssClass = "pageField"
            End If
        Else
            If Mandatory = True Then
                DXFieldErrorControl(inputField, FriendlyName & " is mandatory")
            Else
                inputField.CssClass = "pageField"
            End If
        End If
    End Sub
    Public Sub DXFieldValidateMandatory(ByRef inputField As DevExpress.Web.ASPxEditBase)
        DXFieldValidateMandatory(inputField, String.Empty)
    End Sub
    Public Sub DXFieldValidateMandatory(ByRef inputField As DevExpress.Web.ASPxEditBase, ByVal FriendlyName As String)
        If String.IsNullOrEmpty(FriendlyName) Then
            FriendlyName = FriendlyNameFromFieldName(inputField.ID)
        End If

        If String.IsNullOrEmpty(inputField.Value) Then
            FieldErrorControl(inputField, FriendlyName & " is mandatory")
        Else
            inputField.CssClass = "pageField"
        End If
    End Sub


End Class

