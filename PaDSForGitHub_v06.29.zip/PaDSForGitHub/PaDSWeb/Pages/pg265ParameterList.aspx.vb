Imports System.Data.SqlClient
Imports System.Data
Partial Class pg265ParameterList
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    'Modification History
    '16/12/2021 Julian Gates  Initial version

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "PEP Parameters List", "")
        Me.pageHeaderTitle.Text = "PEP Parameters List"

        Dim emailAddress As String = uPage.db.IsDBNull(uPage.db.DLookup("EmailAddress", "RemoteUser", "UserId=" & Me.uPage.UserSession.UserId), "")
        If emailAddress.ToUpper.Contains("ZEDRA") Then
            'all fine
        Else
            Response.Redirect("pg100HomeAdmin.aspx?InfoMsg=You are not authourised to update Parameters")
        End If
        If Not Page.IsPostBack Then
            If Request.QueryString("InfoMsg") <> "" Then
                Me.InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            txtRecordsToShow.Text = 200
            Me.txtPageNumber.Text = 1
            BuildGrid()
        Else
            If Me.txtPrevRecordsToShow.Value <> Me.txtRecordsToShow.Text Then
                Me.txtPageNumber.Text = 1
                Me.txtPrevRecordsToShow.Value = Me.txtRecordsToShow.Text
            End If
            If Me.txtGotoPageNum.Value <> "" Then
                Me.txtPageNumber.Text = Me.txtGotoPageNum.Value
                Me.txtGotoPageNum.Value = ""
                BuildGrid()
            End If
        End If

    End Sub

    Private Sub BuildGrid()
        If Me.IsPageValidForStatus() Then
            Dim listSQL As String = Nothing
            Dim html As String = Nothing
            Try
                listSQL = "SELECT p.ParameterName" _
                        & "       ,p.ParameterValue" _
                        & " FROM stblParameters p" _
                        & " WHERE 1=1"

                Dim ds As New DataSet
                Dim da As New SqlDataAdapter(listSQL, uPage.PrimaryConnection)
                'Populate Dataset
                da.Fill(ds, "stblParameters")

                If Me.FltrParameterName.Text <> "" Then
                    listSQL += " AND p.ParameterName Like '%" & Me.FltrParameterName.Text & "%'"
        End If

                If Me.FltrParameterValue.Text <> "" Then
                    listSQL += " AND p.ParameterValue like '%" & Me.FltrParameterValue.Text & "%'"
                End If
                listSQL += "ORDER BY p.ParameterName Asc "

                Dim listTable As DataTable = uPage.GetListDatatable(Me.txtPageNumber.Text, Me.txtRecordsToShow.Text, Me.lblPaging.Text, listSQL, uPage.PrimaryConnection)

                If listTable.Rows.Count <> 0 Then
                    For Each row As DataRow In listTable.Rows
                        html += "<tr>"
                        html += "   <td><a href='../pages/pg266ParameterMaint.aspx" & "?PageMode=Update&ParameterName=" & uPage.db.IsDBNull(row("ParameterName"), "") _
                                & "' title='View/Update Parameter'>" & uPage.db.IsDBNull(row("ParameterName"), "") & "</a>" _
                                & " </td>"
                        html += "<td>" & row("ParameterValue") & "</td>"
                        html += "</tr>"
                    Next
                Else
                    uPage.PageError = "No records match your selection criteria"
                End If
            Catch e As Exception
                uPage.PageError = e.ToString
            End Try
            'Assign grid to Label
            lblGridView.Text = html
        End If
    End Sub
    Private Sub btnFilter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFilter.Click
        Me.txtPageNumber.Text = 1
        BuildGrid()
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub
    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        uPage.PagePreRender()
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        Select Case validatorStatus
            Case Else
                If txtRecordsToShow.Text = "" Then
                    uPage.FieldErrorControl(Me.txtRecordsToShow, "Max Records To Show is mandatory")
                End If
                If txtRecordsToShow.Text <> "" Then
                    If Not IsNumeric(Me.txtRecordsToShow.Text) Then
                        uPage.FieldErrorControl(Me.txtRecordsToShow, "Max Records To Show must be a numerical value")
                    End If
                End If
        End Select
        Return uPage.IsValid
    End Function
    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub AddNewBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddNewBtn.Click
        Response.Redirect("../pages/pg266ParameterMaint.aspx?PageMode=Add")
    End Sub
End Class
