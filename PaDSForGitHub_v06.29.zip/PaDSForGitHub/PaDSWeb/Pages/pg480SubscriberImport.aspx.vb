Imports System.Data.SqlClient
Imports System.Data
Imports BusinessLogic
Partial Class pg480SubscriberImport
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim dr As SqlDataReader
    Dim pageMode As String
    Dim commandText As String

    'Modification History
    '30/04/2007  Julian Gates   Initial Version
    '8/3/10     James Woosnam   SIR2179 - Include RetainedUserName in loaded file
    '8/3/10     James Woosnam   SIR2179 - Allow files to be re-imported into the same batch
    '24/9/10    Julian Gates    Reworked update Update subscriber link to not use popup window
    '17/02/11   Julian Gates    Removed Pending and Loaded ftp links as modification
    '21/02/11   Julian Gates    Add ImportFileName to Sub ValidateAndSaveData as modification
    '23/5/11    Julian Gates    SIR2434 - View Order link when Order Selection dropdown populated.
    '27/9/12    Julian Gates    SIR2874 - Add new function CheckAndValidateAdditionalProducts for Import Dup Check fuctionality.
    '16/10/12   Julian Gates    SIR2874 - Default to PEPWeb3y if Primary Product code for order is PepWeb
    '12/12/12   Julian Gates    Fix pg142OrderMaint2 link in sub BuildPartialOrdersDropdown() and sub BuildLoadedDataSummary()
    '06/03/13   Julian Gates    SIR2964 - Add code to FltrSubscriberName to handle single quotes in Sub BuildImportSummaryList().
    '31/07/15   Julian Gates    SIR3900 - Change validation and import code to look for City and State column names instead of Town and County from Import template.
    '09/02/16   Julian Gates    SIR4046 - Use Session("ImportFileName") from pg483SubscriberImportFileLoad page and add delete SubscriberImport also changed FileDropdown to a label control.
    '16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number and Fax fields and associated code
    '18/11/19   Julian Gates    Make Header fields read only and change back button link to pg483SubscriberImportFileLoad.aspx
    '26/11/19   James Woosnam   SIR4960 Import PrintedCopy
    '18/12/19   James Woosnam   SIR4979 Import EmailOptOut
    '24/1/20    James Woosnam   SIR5001 - Set new user to Active
    '14/10/21   James Woosnam   SIR5342 - Move subscriber import code to SubscriberImportBatch so import can be submitted and run as a batch job

    '#Region " Web Form Designer Generated Code "

    '    'This call is required by the Web Form Designer.
    '    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    '    End Sub

    '    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    '    'Do not delete or move it.
    '    Private designerPlaceholderDeclaration As System.Object

    '    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
    '        'CODEGEN: This method call is required by the Web Form Designer
    '        'Do not modify it using the code editor.
    '        InitializeComponent()
    '    End Sub

    '#End Region
    Private _SubscriberImportBatch As BusinessLogic.SubscriberImportBatch = Nothing
    Public Property SubscriberImportBatch() As BusinessLogic.SubscriberImportBatch
        Get
            If Me._SubscriberImportBatch Is Nothing Then
                Me._SubscriberImportBatch = New BusinessLogic.SubscriberImportBatch(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._SubscriberImportBatch
        End Get
        Set(ByVal value As BusinessLogic.SubscriberImportBatch)
            Me._SubscriberImportBatch = value
        End Set
    End Property
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        pageMode = Request.QueryString("PageMode")

        uPage = New UserPage(Me, "Subscriber Import", "")
        Me.pageHeaderTitle.Text = "Subscriber Import"
        If Request.QueryString("SubscriberImportBatchId") = "" Then
            uPage.PageError = "SubscriberImportBatchId must be passed in"
            Exit Sub
        End If

        Me.SubscriberImportBatch = New BusinessLogic.SubscriberImportBatch(Request.QueryString("SubscriberImportBatchId"), uPage.db, uPage.UserSession)
        If Not Page.IsPostBack Then
            txtRecordsToShow.Text = 100
            If Request.QueryString("PageNumber") <> "" Then
                Me.txtPageNumber.Text = Request.QueryString("PageNumber")
            Else
                Me.txtPageNumber.Text = 1
            End If


            ReadRecord()

        Else
            If Me.txtGotoPageNum.Value <> "" Then
                Me.txtPageNumber.Text = Me.txtGotoPageNum.Value
                Me.txtGotoPageNum.Value = ""
            End If
        End If
    End Sub

    Sub PageSetup()
        Me.GroupSubscriberIdLink.Visible = True
        Me.GroupSubscriberIdLink.NavigateUrl = "../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & Me.GroupSubscriberId.Text
        Me.OrderTr.Visible = Not uPage.db.IsDBNull(Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber"))
        Me.AdditionalProductsTr.Visible = Not uPage.db.IsDBNull(Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber"))
        Me.LoadAndCheckBtn.Visible = Me.SubscriberImportBatch.GetLastLogFrom({"File Loaded", "Status set to:Importing", "File Check Failed", "File Checked"}) = "Status set to:Importing"

        Me.ImportSummaryPanel.Visible = Not Me.LoadAndCheckBtn.Visible
        If Me.ImportSummaryPanel.Visible Then BuildImportSummaryList()
        Me.ReCheckBtn.Visible = True


        Me.ImportAsBatchJobBtn.Visible = Me.SubscriberImportBatch.GetLastLogFrom({"File Checked", "File Loaded", "File Check Failed"}) = "File Checked" And Not Me.LoadAndCheckBtn.Visible
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Dim dropDownIntialValue As String = "<---------Select--------->"



        Me.GroupSubscriberId.Text = Me.SubscriberImportBatch.SubscriberImportBatchRow("BlockSubscriberId")
        Me.GroupSubscriberIdLink.Text = uPage.StdCode.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & Me.GroupSubscriberId.Text, uPage.PrimaryConnection)
        Me.Company.Text = uPage.StdCode.DLookup("CompanyName", "Company", "CompanyId=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("CompanyId"), uPage.PrimaryConnection)

        If Not uPage.db.IsDBNull(Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber")) Then
            Me.OrderDesc.Text = uPage.db.DLookup("CAST(OrderNumber as VARCHAR) + ' - ' +  PrimaryProductCode", "SalesOrder", "OrderNumber=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber"))
            DefaultAdditionalProduct(Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber"))
        End If

        If Request.QueryString("SubscriberImportBatchId") <> "" Then
            Me.SubscriberImportBatchId.Text = Request.QueryString("SubscriberImportBatchId")


            '27/9/12    Julian Gates    SIR2874 - Read in saved  for AdditionalProductsCode Import Dup Check fuctionality.
            Dim additionalProductsCode As String = uPage.StdCode.DLookup("AdditionalProductsCode", "tmpSubscriberImport", "SubscriberImportBatchId=" & Request.QueryString("SubscriberImportBatchId"), uPage.PrimaryConnection)
            If additionalProductsCode <> Nothing Then
                Me.AdditionalProductsCode.Text = additionalProductsCode
            End If
            '27/9/12    Julian Gates    SIR2874 - Read in saved  for AdditionalProductsName Import Dup Check fuctionality.
            Dim additionalProductsName As String = uPage.StdCode.DLookup("AdditionalProductsName", "tmpSubscriberImport", "SubscriberImportBatchId=" & Request.QueryString("SubscriberImportBatchId"), uPage.PrimaryConnection)
            If additionalProductsName <> Nothing Then
                Me.AdditionalProductsName.Text = additionalProductsName
            End If

        End If

        If Request.QueryString("InfoMsg") <> "" Then
            uPage.InfoMessage = Request.QueryString("InfoMsg")
        End If
    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else

                If Me.GroupSubscriberId.Text = "" Then
                    uPage.FieldErrorControl(Me.GroupSubscriberId, "Group Subscriber ID is mandatory")
                    uPage.FocusControl = Me.GroupSubscriberId
                End If
                If Me.GroupSubscriberId.Text <> "" Then
                    If Not IsNumeric(Me.GroupSubscriberId.Text) Then
                        uPage.FieldErrorControl(Me.GroupSubscriberId, "Group Subscriber Id must be a numerical value")
                    End If
                End If
        End Select
        Return uPage.IsValid
    End Function

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub LoadAndCheckBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadAndCheckBtn.Click
        If Me.IsPageValidForStatus("") Then
            Me.SubscriberImportBatch.ImportFiletoDB(Me.AdditionalProductsCode.Text, Me.AdditionalProductsName.Text)

            Callsp483SubscriberImportStoredProcedure("Check")

        End If
    End Sub

    Private Sub BuildImportSummaryList()
        Dim html As String = Nothing
        '******************************************************
        'Description:	Builds and Displays a Import Summary Grid
        '******************************************************
        Dim strHtml As String = Nothing
        Dim strCommandText As String = Nothing

        Me.txtRecordsToShow.Text = uPage.ValidateRecordsToShow(Me.txtRecordsToShow.Text)

        strCommandText = "Select tmpSubscriberImport.*" _
                        & " From tmpSubscriberImport" _
                        & " WHERE tmpSubscriberImport.SubscriberImportBatchId =" & Me.SubscriberImportBatchId.Text
        '06/03/13   Julian Gates    SIR2964 - Add code to FltrSubscriberName to handle single quotes.
        If Me.FltrSubscriberName.Text <> "" Then
            strCommandText += "AND (tmpSubscriberImport.LastName Like '%" & Me.FltrSubscriberName.Text.Replace("'", "''") & "%' OR ISNULL(tmpSubscriberImport.MatchedSubscriberId,'') Like '%" & Me.FltrSubscriberName.Text.Replace("'", "''") & "%' OR ISNULL(tmpSubscriberImport.DuplicateSubscriberIdToUse,'') Like '%" & Me.FltrSubscriberName.Text.Replace("'", "''") & "%')"
        End If
        strCommandText += " ORDER BY CASE WHEN ISNULL(ErrorMessage,'')<>'' AND LEFT(ISNULL(ErrorMessage,''),LEN('Already subscribed')) <> 'Already subscribed' THEN 0 ELSE 1 END" ' if there is an error but not just an existing sub error
        strCommandText += "         ,CASE WHEN ISNULL(ProfileChanges,'')<>'' AND Status='Error' THEN 0 ELSE 1 END" 'if a profile change
        strCommandText += "         ,CASE WHEN LEFT(ISNULL(ErrorMessage,''),LEN('Already subscribed')) = 'Already subscribed' THEN 0 ELSE 1 END" 'if an existing subscription
        strCommandText += "         ,LastName, FirstName" 'name
        Dim t As DataTable = uPage.db.GetDataTableFromSQL(strCommandText)
        Dim ids As String = ""
        For Each r As DataRow In t.Rows
            ids += IIf(ids = "", "", ",") & r("SubscriberImportId")
        Next
        uPage.UserSession.Data("pg480SubscriberImportIds") = ids

        Dim listTable As DataTable = uPage.GetListDatatable(Me.txtPageNumber.Text, Me.txtRecordsToShow.Text, Me.lblPaging.Text, strCommandText, uPage.PrimaryConnection)
        Try
            If listTable.Rows.Count <> 0 Then
                For Each row As DataRow In listTable.Rows
                    strHtml = strHtml & "<TR>"
                    Dim subId As String = uPage.db.IsDBNull(row("MatchedSubscriberId"), uPage.db.IsDBNull(row("DuplicateSubscriberIdToUse"), ""))
                    If subId = "" Then
                        strHtml += "<TD Class=fldView>" & row("LastName") & ", " & uPage.StdCode.IsNull(row("FirstName"), "") & "</TD>"
                    Else
                        strHtml += "<TD><A href='../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & subId & "' Title='View Subscriber' Target='_blank'>" & row("LastName") & ", " & uPage.StdCode.IsNull(row("FirstName"), "") & " (" & subId & ")</A></TD>"
                    End If
                    strHtml += "<TD Class=fldView>" & row("SubscriberCategory") & "</TD>"
                    strHtml += "<TD Class=fldView>" & row("Status") & "</TD>"
                    strHtml += "<TD Class=fldView>" & row("OverwriteWebUserName") & "</TD>"
                    strHtml += "<TD align=center Class='lnkMaintNewxx'><A href='../pages/pg481SubscriberUpdate.aspx?PageMode=Update&SubscriberImportId=" & row("SubscriberImportId") & "' Title='Update Subscriber Record'>Update</A></TD>"
                    strHtml += "</TR>"
                    Dim sMessages As String = ""
                    If Not uPage.db.IsDBNull(row("ErrorMessage")) AndAlso row("ErrorMessage") <> "" Then
                        sMessages += "<span class='subImportNowErrorText'>ERRORS:" & row("ErrorMessage") & "</span>"
                    End If
                    If Not uPage.db.IsDBNull(row("ProfileChanges")) AndAlso row("ProfileChanges") <> "" Then
                        sMessages += "<span class='subImportNowText'>CHANGES:" & CStr(row("ProfileChanges")).Replace("||", "<br>") & "</span>"
                    End If
                    If sMessages <> "" Then
                        strHtml += "<TR>"
                        strHtml += "<TD></TD>"
                        strHtml += "<TD colspan='4' class=rowDivider>" _
                                & "<span class='errMsg'>"
                        strHtml += sMessages
                        strHtml += "</span>" _
                                & "</TD>" _
                                & "</TR>"
                    End If
                Next
            Else
                uPage.PageError = "No records match your selection criteria"
            End If
        Catch e As Exception
            uPage.PageError = e.Message
        End Try
        'Assign grid to Label
        Me.ImportSummaryLbl.Text = strHtml
    End Sub






    Private Sub btnFilter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.txtPageNumber.Text = 1
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Me.txtRecordsToShow.Text = 10
        Me.FltrSubscriberName.Text = ""
        uPage.FocusControl = Me.FltrSubscriberName
    End Sub

    'Private Sub ImportBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportBtn.Click
    '    '29/11/18	James Woosnam	SIR4760 - Move transaction out of sp to cover RemoteUser
    '    Try
    '        Me.SubscriberImportBatch.ExecuteActionSubscriberImportBatch(0, Me.AdditionalProductsCode.Text)
    '    Catch ex As Exception
    '        uPage.PageError = ex.ToString
    '    End Try
    '    If uPage.IsValid Then
    '        Response.Redirect("pg483SubscriberImportFileLoad.aspx?SubscriberImportBatchId=" & Me.SubscriberImportBatchId.Text )
    '    End If
    'End Sub
    Private Sub ImportAsBatchJobBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportAsBatchJobBtn.Click
        '29/11/18	James Woosnam	SIR4760 - Move transaction out of sp to cover RemoteUser
        '14/10/21   James Woosnam   SIR5342 - Move subscriber import code to SubscriberImportBatch so import can be submitted and run as a batch job
        Try
            Me.SubscriberImportBatch.SubmitActionSubscriberImportBatch(Me.AdditionalProductsCode.Text)
            ViewState("BatchJobId") = SubscriberImportBatch.BatchJob.BatchJobId

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
        If uPage.IsValid Then
            UpdateTimer_Tick(sender, e)
        End If
    End Sub
    Private Function Callsp483SubscriberImportStoredProcedure(ByVal RunMode As String) As Boolean
        '14/10/21   James Woosnam   SIR5342 - Move subscriber import code to SubscriberImportBatch so import can be submitted and run as a batch job
        Try
            Dim ReturnMessage As String = ""
            Me.SubscriberImportBatch.Callsp483SubscriberImportStoredProcedure(RunMode, Me.AdditionalProductsCode.Text, ReturnMessage)
            Return True
        Catch ex As Exception
            uPage.PageError = ex.Message
            Return ex.Message.Contains("See list for details") 'If the error message contains this warning then we can return true
        End Try
    End Function

    Private Sub ReCheckBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReCheckBtn.Click
        Callsp483SubscriberImportStoredProcedure("Check") 
    End Sub

    'Private Sub CompanyDropdown_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CompanyDropdown.SelectedIndexChanged
    '    Me.ImportBtn.Visible = False
    '    Me.ReCheckBtn.Visible = False
    '    Me.GroupSubscriberId.Text = ""
    '    uPage.FocusControl = Me.GroupSubscriberId
    'End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        PageSetup()
        uPage.PagePreRender()
    End Sub

    Private Sub FilterBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilterBtn.Click
        Me.txtPageNumber.Text = 1
    End Sub


    Private Sub BackBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        'Change back button redirect to pg483SubscriberImportFileLoad page.
        Response.Redirect("../pages/pg483SubscriberImportFileLoad.aspx?SubscriberImportBatchId=" & Me.SubscriberImportBatchId.Text)

    End Sub

    Private Sub AdditionalProductsCode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AdditionalProductsCode.TextChanged

        Dim errorMessage As String = Nothing
        If Me.AdditionalProductsCode.Text <> "" Then
            If CheckAndValidateAdditionalProducts(errorMessage) Then

            Else
                uPage.PageError = errorMessage
                uPage.FocusControl = Me.AdditionalProductsCode

            End If
        Else
            Me.AdditionalProductsName.Text = ""
        End If
    End Sub

    Function CheckAndValidateAdditionalProducts(Optional ByRef ErrorMessage As String = Nothing) As Boolean

        Dim productCode As String = ""
        Dim productsCodeOutput As String = ""
        Dim productsNameOutput As String = ""
        Dim comma As String = ""
        Dim localErrorMsg As String = ""
        For Each row As DataRow In New Product(uPage.db, uPage.UserSession).GetAdditionalProductsTable(Me.AdditionalProductsCode.Text).Rows
            Dim productName As String = uPage.StdCode.DLookup("ProductName", "Product", "ProductCode='" & row("ProductCode") & "' And ProductStatus='Current'", uPage.PrimaryConnection)
            If productName <> "" Then
                productsNameOutput += comma & "'" & productName + "'"
                productsCodeOutput += comma & "'" & row("ProductCode") + "'"
                comma = ", "
            Else
                localErrorMsg += "'" & row("ProductCode") & "' "
            End If
        Next
        If localErrorMsg <> "" Then
            ErrorMessage = "Entered Product(s) " & localErrorMsg & " are not valid product(s), please check and re-enter."
            Return False
        End If
        Me.AdditionalProductsCode.Text = productsCodeOutput
        Me.AdditionalProductsName.Text = productsNameOutput
        If IsNumeric(Me.SubscriberImportBatchId.Text) Then
            Try
                'Now update field on table, if this import hasn't been run yet this will just do nothing
                Dim sql As String = ""
                sql = "UPDATE tmpSubscriberImport"
                sql += " SET AdditionalProductsCode = '" & Me.AdditionalProductsCode.Text.Replace("'", "''") & "'"
                sql += "    , AdditionalProductsName = '" & Me.AdditionalProductsName.Text.Replace("'", "''") & "'"
                sql += " WHERE SubscriberImportBatchId=" & Me.SubscriberImportBatchId.Text
                Dim cmd As New SqlCommand(sql, uPage.db.DBConnection)
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                uPage.PageError = "Additional Products were not updated:" & ex.Message
            End Try
        End If
        Return True
    End Function

    Sub DefaultAdditionalProduct(ByVal OrderNumber As String)
        '16/10/12 Julian Gates  SIR2874 - Default to PEPWeb3y if Primary Product Code is Pepweb
        If Me.AdditionalProductsCode.Text = "" Then
            Dim primaryProductCode As String = uPage.StdCode.DLookup("PrimaryProductCode", "SalesOrder", "OrderNumber=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber"), uPage.PrimaryConnection)
            If primaryProductCode.ToLower = "pepweb" Then
                If Me.AdditionalProductsCode.Text = "" Then
                    Me.AdditionalProductsCode.Text = "PEPWeb3y"
                    Dim errorMessage As String = Nothing
                    If CheckAndValidateAdditionalProducts(errorMessage) Then
                    Else
                        uPage.PageError = errorMessage
                    End If
                End If
            End If
        End If
    End Sub
    Protected Sub UpdateTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateTimer.Tick
        Try
            If IsNumeric(ViewState("BatchJobId")) Then
                Me.TimedPanel.Visible = True
                Dim BatchLog As New BusinessLogic.BatchLog(uPage.db)
                Me.BatchLogLines.Text = BatchLog.GetBatchLogLinesHTML(ViewState("BatchJobId"))
                Select Case uPage.db.IsDBNull(uPage.db.DLookup("MAX(BatchLogStatus)", "BatchLog", "BatchJobId=" & ViewState("BatchJobId")), "")
                    Case "Failed"
                        Me.UpdateTimer.Enabled = False
                    Case "Complete"
                        Me.UpdateTimer.Enabled = False
                        '      Response.Redirect("pg483SubscriberImportFileLoad.aspx?SubscriberImportBatchId=" & Me.SubscriberImportBatchId.Text )
                    Case Else
                        Me.UpdateTimer.Enabled = True
                End Select
            Else
                Me.UpdateTimer.Enabled = False
                Me.TimedPanel.Visible = False
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub
End Class

