﻿Imports System.Data.SqlClient
Imports System.Data

'Modification History
'1/02/11  Julian Gates   Initial version
'31/3/11  James Woosnam   SIR2401 - Use the company specific address if available else use latest address
'25/3/11  Julian Gates   Fix date validation
'17/11/11   James Woosnam   Reworked all queries to dramatically improve performance
'03/10/14   Julian Gates    SIR3621 - Add IsReceive Mail field to Function GetSQL
'09/02/16   Julian Gates    SIR4045 - Change Town/County to City/State in SQLColumns to Function GetSQL
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number and Fax fields and associated code
'20/11/19   Julian Gates    SIR4952 - Add CreateSubscriberImportBatches checkbox
'20/11/19   James Woosnam   SIR4763 - Get UserName from RemoteUser
'25/11/19   James Woosnam   SIR4959 - Add optional Notes field and remove webusername and password fields
'2/12/19    James Woosnam   SIR4952 - Only show subs who order through selected group(s)
'13/1/22    james Woosnam   SIR5388 - Remove IsReceive Mail/EmailOpt Out column
'19/4/22    James Woosnam   SIR5477 - Exclude cancelled lines
'6/3/23     James Woosnam   SIR5561 - Remove WebUerName and password from template

Partial Class Pages_pg461SubscriberRenewalReport
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim _tblGroups As DataTable = Nothing
    Private ReadOnly Property tblGroups As DataTable
        Get
            If Me._tblGroups Is Nothing Then
                If ReportType.SelectedValue <> "Groups" Then
                    Return Nothing
                End If
                Select Case Me.DateCriteria.SelectedValue
                    Case "SingleDate"
                        If Me.OrderOnDate.Text = "" Then
                            Return Nothing
                        End If
                    Case "DateRange"
                        If Me.ExpireBetweenFromDate.Text = "" _
                            Or Me.ExpireBetweenToDate.Text = "" Then
                            Return Nothing
                        End If
                End Select
                Dim sql As String = ""
                sql = "  Select SalesOrder.OrderNumber" & vbCrLf
                sql += "	,SalesOrder.SubscriberId " & vbCrLf
                sql += "INTO #SalesOrders" & vbCrLf
                sql += "            FROM SalesOrder" & vbCrLf
                sql += "	INNER JOIN Product ParentProduct " & vbCrLf
                sql += "	On ParentProduct.ProductCode = SalesOrder.PrimaryProductCode" & vbCrLf
                sql += "	INNER JOIN SalesOrderLine sol" & vbCrLf
                sql += "	ON sol.OrderNumber = SalesOrder.OrderNumber " & vbCrLf
                sql += "	INNER JOIN Product ChildProduct 			" & vbCrLf
                sql += "	On ChildProduct.ParentProductCode = SalesOrder.PrimaryProductCode			" & vbCrLf
                sql += "	AND ChildProduct.ProductReportName = '" & Me.SubscribedToProduct.SelectedValue & "'" & vbCrLf
                sql += "	AND IsNull(ChildProduct.ProductReportName ,'') <> ''" & vbCrLf
                sql += "WHERE SalesOrder.SalesorderStatus IN ('Confirmed','Complete')	" & vbCrLf
                sql += "AND SalesOrder.OrderType = 'Block'			" & vbCrLf
                sql += "AND SalesOrder.OrderNumber = (Select MAX(SO.OrderNumber)" & vbCrLf
                sql += "				            FROM SalesOrder SO" & vbCrLf
                sql += "                            WHERE SO.SubscriberId = SalesOrder.SubscriberId" & vbCrLf
                sql += "				            AND SO.CompanyId = SalesOrder.CompanyId	" & vbCrLf
                sql += "				            AND SO.OrderType = SalesOrder.OrderType" & vbCrLf
                sql += "				            AND SO.OrderDate = SalesOrder.OrderDate" & vbCrLf
                sql += "				            AND SO.PrimaryProductCode = SalesOrder.PrimaryProductCode" & vbCrLf
                sql += "				            AND SO.SalesorderStatus = SalesOrder.SalesorderStatus)" & vbCrLf
                sql += "AND SalesOrder.CompanyId = " & Me.CompanyId.SelectedValue & vbCrLf
                '19/4/22    James Woosnam   SIR5477 - Exclude cancelled lines
                sql += " AND sol.IsCancel <> 1" & vbCrLf

                '17/11/19   James Woosnam   Fix date formatting which looks as though it has been incorrect for years!!
                If Me.OrderOnDate.Text <> "" Then
                    sql += " AND sol.RecurringSubscriptionStartDate = " & uPage.db.vFQ(CDate(Me.OrderOnDate.Text), "d") & vbCrLf
                Else
                    '31/01/08   Julian Gates   Change RecurringSubscriptionStartDate to RecurringSubscriptionEndDate to fix renewal report problem for groups SIR 1437.
                    If Me.ExpireBetweenFromDate.Text <> "" And Me.ExpireBetweenToDate.Text <> "" Then
                        sql += " And sol.RecurringSubscriptionEndDate BETWEEN " & uPage.db.vFQ(CDate(Me.ExpireBetweenFromDate.Text), "d") & " AND  " & uPage.db.vFQ(CDate(Me.ExpireBetweenToDate.Text), "d") & vbCrLf
                        sql += " AND ISNULL(ParentProduct.RecurringSubscriptionFlag,0) = 1" & vbCrLf
                    End If
                End If

                sql += "Select Distinct Subscriber.SubscriberName" & vbCrLf
                sql += "    ,Subscriber.SubscriberId " & vbCrLf
                sql += "From Subscriber" & vbCrLf
                sql += " 	INNER JOIN SubscriberAffiliate	" & vbCrLf
                sql += "	ON dbo.SubscriberAffiliate.ChildSubscriberID = dbo.Subscriber.SubscriberId		" & vbCrLf
                sql += "	INNER JOIN dbo.Company		" & vbCrLf
                sql += "	ON Company.GroupParentSubscriberId = SubscriberAffiliate.ParentSubscriberId" & vbCrLf
                sql += "	INNER JOIN #SalesOrders SalesOrder" & vbCrLf
                sql += "	ON SalesOrder.SubscriberId = Subscriber.SubscriberId " & vbCrLf
                sql += "Where Subscriber.EntityType = 'Organisation' " & vbCrLf
                sql += "And Company.CompanyId = " & Me.CompanyId.SelectedValue & vbCrLf
                sql += "Order By Subscriber.SubscriberName  " & vbCrLf
                Try
                    Me._tblGroups = uPage.db.GetDataTableFromSQL(sql)

                Catch ex As Exception
                    Throw New Exception("Build tblGroups failed:" & ex.Message)
                End Try
            End If
            Return Me._tblGroups
        End Get
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Subscriber Renewal Report", "")
        Me.pageHeaderTitle.Text = "Subscriber Renewal Report"

        If Page.IsPostBack Then

        Else
            ReadRecord()
            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            CreateSubscriberImportBatches.Checked = True
        End If
    End Sub

    Sub PageSetup()
        If CompanyId.SelectedValue <> "" Then
            Dim selectedProduct As String = Me.SubscribedToProduct.SelectedValue
            Dim sql As String = ""
            sql = "SELECT Value = ISNULL(Product.ProductReportName,'')" _
                & "	    ,Text = ISNULL(Product.ProductReportName,'')" _
                & "	FROM Product" _
                & "		INNER JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                & "		ON Company.CompanyId = Product.CompanyId" _
                & "		INNER JOIN Product Parent" _
                & "		On Parent.ProductCode = Product.ParentProductCode" _
                & " WHERE Product.IsForReporting <> 0" _
                & " AND Product.CompanyId = " & Me.CompanyId.SelectedValue _
                & "	GROUP BY Product.ProductReportName" _
                & " ORDER By Product.ProductReportName"
            uPage.PopulateDropDownListFromSQL(Me.SubscribedToProduct, sql, uPage.PrimaryConnection, "<----Select---->")
            Try
                Me.SubscribedToProduct.SelectedValue = selectedProduct
            Catch ex As Exception
            End Try
            Me.SubscribedToProduct.Visible = True
        Else
            Me.SubscribedToProduct.Visible = False
        End If
        Select Case DateCriteria.SelectedValue
            Case "SingleDate"
                Me.SingleDatePanel.Visible = True
                Me.DateRangePanel.Visible = False
            Case "DateRange"
                Me.SingleDatePanel.Visible = False
                Me.DateRangePanel.Visible = True
        End Select
        Select Case Me.ReportType.SelectedValue
            Case "Groups"
                Me.GroupsList.Visible = True
            Case Else
                Me.GroupsList.Visible = False
        End Select
        Me.SubmitReportBtn.Visible = True
        If IsNumeric(ViewState("BatchJobId")) Then
            Me.TimedPanel.Visible = True
        Else
            Me.TimedPanel.Visible = False
        End If

    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        'Populate all dropdown fields
        Dim dropDownIntialValue As String = "<---------Select--------->"
        uPage.PopulateDropDownListFromSQL(Me.CompanyId, "SELECT Company.CompanyId as Value" _
                                                            & "    ,Company.CompanyName as Text" _
                                                            & " FROM " & uPage.CompanyTable("Company", 31) _
                                                            & " ORDER BY 2" _
                                                            , uPage.PrimaryConnection, dropDownIntialValue _
                                                            )

        'Default company if only one 
        If Me.CompanyId.Items.Count = 2 Then
            Me.CompanyId.SelectedValue = Me.CompanyId.Items(1).Value
            Me.CompanyId.Items.Remove(CompanyId.Items.FindByText(dropDownIntialValue))
            Me.SubscribedToProduct.Visible = True
            Me.DateCriteria.Focus()
        End If

    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else
                If Me.ReportType.SelectedValue = "" Then
                    uPage.PageError = "Report Type is mandatory"
                End If

                If Me.CompanyId.SelectedValue = "" Then
                    uPage.FieldErrorControl(Me.CompanyId, "Company is mandatory")
                End If
                If Me.SubscribedToProduct.SelectedValue = "" Then
                    uPage.FieldErrorControl(Me.CompanyId, "Product must be selected")
                End If

                If Me.DateCriteria.SelectedValue = "" Then
                    uPage.PageError = "Date Criteria is mandatory"
                End If

                If Me.SingleDatePanel.Visible = True Then
                    If Me.OrderOnDate.Text.Trim = "" Then
                        uPage.PageError = "You must enter an Order on Date"
                    End If

                    If Me.OrderOnDate.Text.Trim <> "" Then
                        If Not uPage.StdCode.IsValidDate(Me.OrderOnDate.Text) Then
                            uPage.FieldErrorControl(Me.OrderOnDate, "Order On Date is an invalid date")
                        End If
                    End If
                End If

                If Me.DateRangePanel.Visible = True Then
                    If Me.ExpireBetweenFromDate.Text.Trim = "" _
                        And Me.ExpireBetweenToDate.Text.Trim = "" Then
                        uPage.PageError = "You must enter a Expire Between From and To date"
                    End If

                    If Me.ExpireBetweenFromDate.Text.Trim <> "" _
                        And Me.ExpireBetweenToDate.Text.Trim = "" Then
                        uPage.PageError = "You must enter a date in the From and To date fields"
                    End If

                    If Me.ExpireBetweenToDate.Text.Trim <> "" _
                        And Me.ExpireBetweenFromDate.Text.Trim = "" Then
                        uPage.PageError = "You must enter a date in the From and To date fields"
                    End If

                    If Me.ExpireBetweenFromDate.Text.Trim <> "" _
                        And Me.ExpireBetweenToDate.Text.Trim <> "" Then
                        If uPage.StdCode.IsValidDate(Me.ExpireBetweenFromDate.Text) _
                            And uPage.StdCode.IsValidDate(Me.ExpireBetweenToDate.Text) Then
                            If CDate(Me.ExpireBetweenFromDate.Text) > CDate(Me.ExpireBetweenToDate.Text) Then
                                uPage.FieldErrorControl(Me.ExpireBetweenFromDate, "Expire between From date must be less than To date")
                            End If
                        End If
                    End If

                    If Me.ExpireBetweenFromDate.Text.Trim <> "" Then
                        If Not uPage.StdCode.IsValidDate(Me.ExpireBetweenFromDate.Text) Then
                            uPage.FieldErrorControl(Me.ExpireBetweenFromDate, "Expire Between From Date is an invalid date")
                        End If
                    End If

                    If Me.ExpireBetweenToDate.Text.Trim <> "" Then
                        If Not uPage.StdCode.IsValidDate(Me.ExpireBetweenToDate.Text) Then
                            uPage.FieldErrorControl(Me.ExpireBetweenToDate, "Expire Between To Date is an invalid date")
                        End If
                    End If
                End If

                Select Case validatorStatus
                    Case "Groups"
                    Case Else
                        If Me.ReportType.SelectedValue = "Groups" Then
                            If Me.tblGroups IsNot Nothing Then
                                If GetSelectedGroupSubscribers.Rows.Count = 0 Then
                                    uPage.PageError = "You must select one Group Subscriber or more from Group Subscriber list"
                                End If
                            End If
                        End If
                End Select

        End Select
        Return uPage.IsValid
    End Function

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        PageSetup()
        uPage.PagePreRender()
    End Sub

    Private Sub SubmitReportBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubmitReportBtn.Click
        ViewState("BatchJobId") = "None"
        If Me.ReportType.SelectedValue = "Groups" Then
            If Not Me.GroupsList.Text.Contains("id=""cbxSubscribers") Then
                If Me.IsPageValidForStatus("Groups") Then
                    GetGroupsListHTML()
                End If
                Exit Sub
            End If
            If Not tblGroups Is Nothing Then
                If GetSelectedGroupSubscribers.Rows.Count = 0 Then
                    'might need to rebuild groups
                    If Me.IsPageValidForStatus("Groups") Then
                        GetGroupsListHTML()
                    Else
                        Exit Sub
                    End If
                End If
            End If
        End If
        If Me.IsPageValidForStatus("") Then
            Try
                Dim CompanyId As Integer = IIf(Me.CompanyId.Text = "", Nothing, Me.CompanyId.SelectedValue)
                Dim OrderOnDate As Date = IIf(Me.OrderOnDate.Text = "", Nothing, Me.OrderOnDate.Text)
                Dim ExpireBetweenFromDate As Date = IIf(Me.ExpireBetweenFromDate.Text = "", Nothing, Me.ExpireBetweenFromDate.Text)
                Dim ExpireBetweenToDate As Date = IIf(Me.ExpireBetweenToDate.Text = "", Nothing, Me.ExpireBetweenToDate.Text)

                Dim sql As String = ""
                sql = GetSQL(CompanyId _
                             , Me.SubscribedToProduct.SelectedValue _
                             , Me.DateCriteria.SelectedValue _
                             , Me.ReportType.SelectedValue _
                             , OrderOnDate _
                             , ExpireBetweenFromDate _
                             , ExpireBetweenToDate _
                             , Me.GetSelectedGroupSubscribers _
                            )
                '23/10/19   James Woosnam   SIR4945 - Use new class ReportSubscriberRenewal
                Dim report As BusinessLogic.ReportSubscriberRenewal = Nothing
                Dim singleBlockSubId As Integer = Nothing
                If Me.ReportType.SelectedValue = "Groups" Then
                    If Me.GetSelectedGroupSubscribers.Rows.Count = 1 Then
                        singleBlockSubId = Me.GetSelectedGroupSubscribers.Rows(0)("SubscriberId")
                    End If
                End If

                report = New BusinessLogic.ReportSubscriberRenewal(singleBlockSubId, Me.CompanyId.SelectedValue, sql, uPage.db, Me.uPage.UserSession.UserSessionIdGUID)
                report.Submit(CreateSubscriberImportBatches.Checked)

                ViewState("BatchJobId") = report.BatchJob.BatchJobId

                Me.InfoMsg.Text = "Report has been submitted as batchjob, if you wish to view the batchlog please use the Batchlog link in main menu."
                Me.UpdateTimer.Enabled = True
            Catch ex As Exception
                uPage.PageError = "There was an unexpected problem generating this report.  Please contact support." & ex.ToString
                Me.UpdateTimer.Enabled = False
            End Try
        End If
    End Sub

    Protected Sub DateCriteria_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DateCriteria.SelectedIndexChanged
        Select Case DateCriteria.SelectedValue
            Case "SingleDate"
                Me.OrderOnDate.Focus()
            Case "DateRange"
                Me.ExpireBetweenFromDate.Focus()
        End Select
        ViewState("BatchJobId") = "None"
    End Sub

    Protected Sub ReportType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ReportType.SelectedIndexChanged
        Me.GetGroupsListHTML()
        Me.CompanyId.Focus()
        ViewState("BatchJobId") = "None"
    End Sub

    Protected Sub CompanyId_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CompanyId.SelectedIndexChanged
        If CompanyId.SelectedValue <> "" Then
            Me.DateCriteria.Focus()
        End If
        ViewState("BatchJobId") = "None"
    End Sub


    Sub GetGroupsListHTML()
        'Builds a list of subscribers affiliated to selected company
        Select Case ReportType.SelectedValue
            Case "Groups"
            Case Else
                Exit Sub
        End Select
        Dim sql As String = ""
        Dim html As String = ""
        html += "<table width='300' border='1' cellpadding='5' class='selectTable'>"
        html += "  <tr>"
        html += "    <td colspan='2' class='fldTitle'>Group Subscribers</td>"
        html += "  </tr>"

        If Not Me.IsPageValidForStatus("Groups") Then
            html += "<tr><td colspan='2'  class='fldView'>Groups will not be shown until errors are corrected</td></tr>"
        Else
            Try

                If tblGroups.Rows.Count = 0 Then
                    html += "<tr><td colspan='2'  class='fldView'>No Groups found who meet these criteria</td></tr>"
                Else
                    For Each row As DataRow In tblGroups.Rows
                        html += "  <tr>"
                        html += "	    <td class='fldView'><a href='pg111SubscriberDisplay.aspx?SubscriberId=" & row("SubscriberId") & "' title='Go To Batch Log List' target='_blank'>" & uPage.StdCode.IsNull(row("SubscriberId"), "&nbsp;") & "</a></td>"
                        html += "	    <td class='fldView'>" & uPage.StdCode.IsNull(row("SubscriberName"), "&nbsp;") & "</td>"
                        html += "       <td><input id=""cbxSubscribers" & row("SubscriberId") & """ name=""cbxSubscribers" & row("SubscriberId") & """ type=""checkbox"""
                        For Each row1 As DataRow In GetSelectedGroupSubscribers.Rows
                            If uPage.StdCode.IsNull(row("SubscriberId"), "") = row1("SubscriberId") Then
                                html += " Checked "
                            End If
                        Next
                        html += "</input></td>"
                        html += "  </tr>"
                    Next
                End If

                Me.GroupsList.Text = html

            Catch ex As Exception
                uPage.PageError = "An Unexpected error has occured.  Please contact support" & ex.ToString
            End Try

        End If
        html += "</table>"
        Me.GroupsList.Text = html
    End Sub

    Function GetSelectedGroupSubscribers() As DataTable
        If tblGroups Is Nothing Then
            Return Nothing
        End If
        Dim SelectedGroupSubscribersTable As New DataTable("SelectedProductsTable")
        SelectedGroupSubscribersTable.Columns.Add("SubscriberId")
        Select Case Me.ReportType.SelectedValue
            Case "Groups", "Both"
                Try
                    For Each row As DataRow In tblGroups.Rows
                        If Request.Form.Item("cbxSubscribers" & row("SubscriberId")) = "on" Then
                            Dim row1 As DataRow = SelectedGroupSubscribersTable.NewRow
                            row1.Item("SubscriberId") = row("SubscriberId")
                            SelectedGroupSubscribersTable.Rows.Add(row1)
                        End If
                    Next
                Catch ex As Exception
                    uPage.PageError = "An Unexpected error has occured.  Please contact support" & ex.ToString
                End Try

        End Select
        Return SelectedGroupSubscribersTable
    End Function

    Protected Sub UpdateTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateTimer.Tick
        Try
            If IsNumeric(ViewState("BatchJobId")) Then
                Dim BatchLog As New BusinessLogic.BatchLog(uPage.db)
                Me.BatchLogLines.Text = BatchLog.GetBatchLogLinesHTML(ViewState("BatchJobId"))
                Select Case uPage.db.IsDBNull(uPage.db.DLookup("MAX(BatchLogStatus)", "BatchLog", "BatchJobId=" & ViewState("BatchJobId")), "")
                    Case "Complete", "Failed"
                        Me.UpdateTimer.Enabled = False
                    Case Else
                        Me.UpdateTimer.Enabled = True
                End Select
            Else
                Me.UpdateTimer.Enabled = False
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub
    Function GetSQL(ByVal CompanyId As Integer _
                    , ByVal SubscribedProduct As String _
                    , ByVal DateType As String _
                    , ByVal SubscriberRenewalReportType As String _
                    , ByVal OrderOnDate As Date _
                    , ByVal ExpireBetweenFromDate As Date _
                    , ByVal ExpireBetweenToDate As Date _
                    , ByVal SelectedGroupSubscribers As DataTable) As String

        Dim SQLColumns As String
        Dim SQLFrom As String
        Dim SQLWhere As String
        Dim SQLGroup As String
        Dim SQLOrderBy As String
        Dim sqlForTemp As String = Nothing
        Dim Line As String = System.Environment.NewLine
        Dim GroupSubscribers As String = " IN ("
        If SubscriberRenewalReportType = "Groups" Then
            For Each row As DataRow In SelectedGroupSubscribers.Rows
                GroupSubscribers += row("SubscriberId") & ","
            Next
            GroupSubscribers = GroupSubscribers.Substring(0, GroupSubscribers.Length - 1) & ")"
        End If

        sqlForTemp = "SELECT " & Line
        sqlForTemp += "      SalesOrder.OrderNumber" & Line
        sqlForTemp += "		,SalesOrderLine.SubscriberId" & Line
        sqlForTemp += "		,SalesORder.OrderType" & Line
        sqlForTemp += "		,OrderedBySubscriberId = OrderedBySubscriber.SubscriberId" & Line
        sqlForTemp += "		,OrderedBySubscriberName = OrderedBySubscriber.SubscriberName " & Line
        sqlForTemp += "INTO #SalesorderLine" & Line
        sqlForTemp += "FROM SalesorderLine " & Line
        sqlForTemp += "	INNER JOIN Salesorder " & Line
        sqlForTemp += "		INNER JOIN Subscriber OrderedBySubscriber " & Line
        sqlForTemp += "		On OrderedBySubscriber.SubscriberId = Salesorder.SubscriberId" & Line
        sqlForTemp += "	On SalesOrder.OrderNumber = SalesorderLine.OrderNumber" & Line
        sqlForTemp += "	AND SalesOrder.SalesorderStatus IN ('Confirmed','Complete')" & Line
        sqlForTemp += "	INNER JOIN Product ParentProduct " & Line
        sqlForTemp += "	On ParentProduct.ProductCode = SalesOrderLine.ProductCode" & Line
        sqlForTemp += "	INNER JOIN Product ChildProduct " & Line
        sqlForTemp += "	On ChildProduct.ParentProductCode = SalesOrderLine.ProductCode" & Line
        sqlForTemp += "	AND ChildProduct.ProductReportName = '" & SubscribedProduct & "'" & Line
        sqlForTemp += "	AND IsNull(ChildProduct.ProductReportName ,'') <> ''" & Line
        If SubscriberRenewalReportType = "Groups" Then
            '2/12/19    James Woosnam   SIR4952 - Only show subs who order through selected group(s)
            sqlForTemp = sqlForTemp + "     INNER JOIN SubscriberAffiliate SubAff" & Line _
                 & "        ON SubAff.ParentSubscriberId  " & GroupSubscribers & Line _
                 & "        AND SubAff.ChildSubscriberId = SalesorderLine.SubscriberId" & Line _
                 & "        AND SubAff.ParentSubscriberId = Salesorder.SubscriberId" & Line
        End If
        Select Case DateType
            Case "SingleDate"
                sqlForTemp += " WHERE SalesorderLine.RecurringSubscriptionStartDate = " & uPage.db.vFQ(OrderOnDate, "D")
            Case "DateRange"
                sqlForTemp += " WHERE SalesorderLine.RecurringSubscriptionEndDate BETWEEN " & uPage.db.vFQ(ExpireBetweenFromDate, "D") & " AND  " & uPage.db.vFQ(ExpireBetweenToDate, "D") _
                          & " AND ISNULL(ParentProduct.RecurringSubscriptionFlag,0) = 1" & Line _
                          & "		AND SalesOrderLine.RecurringSubscriptionEndDate = (Select MAX(sol.RecurringSubscriptionEndDate)" & Line _
                          & "									FROM SalesOrder SO" & Line _
                          & "										INNER JOIN SalesOrderLine sol" & Line _
                          & "										On sol.ordernumber = so.ordernumber" & Line _
                          & "									WHERE sol.SubscriberId = SalesOrderLine.SubscriberId " & Line _
                          & "									AND SO.CompanyId = SalesOrder.CompanyId" & Line _
                          & "									AND SO.OrderType = SalesOrder.OrderType" & Line _
                          & "									AND SO.PrimaryProductCode = SalesOrder.PrimaryProductCode" & Line _
                          & "									AND SO.SalesorderStatus = SalesOrder.SalesorderStatus)" & Line

            Case Else
                Throw New Exception("DateType:'" & DateType & "' not recongnised")
        End Select
        '19/4/22    James Woosnam   SIR5477 - Exclude cancelled lines
        sqlForTemp += " AND SalesorderLine.IsCancel <> 1" & Line

        If SubscriberRenewalReportType = "Individual" Then
            sqlForTemp += " AND SalesOrder.OrderType IN ('Individual','IndividualRemote')	" & Line
        End If

        SQLFrom = " FROM " & uPage.SubscriberTable("Subscriber") & Line

        SQLWhere = " WHERE Subscriber.SubscriberStatus='Current'" & Line
        '20/11/19   James Woosnam   SIR4763 - Get UserName from RemoteUser
        SQLFrom += "    LEFT JOIN RemoteUserRights rur" & Line
        SQLFrom += "         INNER JOIN RemoteUser ru" & Line
        SQLFrom += "         ON ru.UserId = rur.UserId" & Line
        SQLFrom += "    ON rur.RightsToId = Subscriber.SubscriberId" & Line
        SQLFrom += "    AND rur.RightsType = 'Subscriber'" & Line

        SQLFrom = SQLFrom + "	INNER JOIN SubscriberAffiliate" & Line _
             & "			INNER JOIN Company" & Line _
             & "			On Company.CompanyId = " & CompanyId & Line _
             & "			AND Company.GroupParentSubscriberId = SubscriberAffiliate.ParentSubscriberId" & Line _
             & "		ON SubscriberAffiliate.ChildSubscriberId = Subscriber.SubscriberId" & Line _
             & "		AND GetDate() BETWEEN SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate" & Line

        SQLFrom = SQLFrom + "	INNER JOIN #SalesorderLine SalesorderLine " & Line _
             & "		ON SalesorderLine.SubscriberId = Subscriber.SubscriberId" & Line _
             & "		" & Line

        '20/4/07	James Woosnam	Use RecurringSubscriptionStartDate instead of order date 		
        'Process new group subscribers list
        If SubscriberRenewalReportType = "Groups" Then
            SQLFrom = SQLFrom + "	INNER JOIN SubscriberAffiliate SubAff" & Line _
                 & "		ON SubAff.ParentSubscriberId  " & GroupSubscribers & Line _
                 & "		AND SubAff.ChildSubscriberId = SalesorderLine.SubscriberId" & Line
        End If
        If SubscriberRenewalReportType = "Individual" Then
            SQLWhere = SQLWhere + " AND SalesorderLine.OrderType IN ('Individual','IndividualRemote')	" & Line
        End If
        SQLGroup = " GROUP BY Subscriber.SubscriberId" & Line
        SQLColumns = "SELECT "
        If SubscriberRenewalReportType = "Groups" Then
            SQLColumns = SQLColumns & "	MIN(SubAff.AffiliateReferenceID) as AffiliateReferenceID" & Line
        Else
            SQLColumns = SQLColumns & "	'' as AffiliateReferenceID" & Line
        End If

        SQLColumns = SQLColumns & " ,SubscriberCategory = MIN(SubscriberAffiliate.SubscriberCategory) " & Line
        '24/10/2006  James Woosnam   Add SQL below to populate ParentSubscriberName in CSV
        SQLColumns = SQLColumns & "	,CASE WHEN MIN(SalesorderLine.OrderType) = 'Block' " & Line _
          & "							  THEN MIN(SalesorderLine.OrderedBySubscriberName) " & Line _
          & "							 ELSE '' END as ParentSubscriberName" & Line

        '03/10/14   Julian Gates    SIR3621 - Add IsReceive Mail field to Function GetSQL
        '09/02/16   Julian Gates    SIR4045 - Change Town/County to City/State in SQLColumns below
        '25/11/19   James Woosnam   SIR4959 - Add optional Notes field and remove webusername and password fields
        '12/12/19   James Woosnam   SIR4978 - Re-add blank webusername and password fields
        '13/1/22    james Woosnam   SIR5388 - Remove IsReceive Mail/EmailOpt Out column
        '6/3/23     James Woosnam   SIR5561 - Remove WebUerName and password from template
        SQLColumns = SQLColumns _
          & "		,MIN( Subscriber.FirstName) AS FirstName" & Line _
          & "		,MIN( Subscriber.LastName) AS LastName" & Line _
          & "		,MIN( SubscriberAddress.Address1) AS Address1" & Line _
          & "		,MIN( SubscriberAddress.Address2) AS Address2" & Line _
          & "		,MIN( SubscriberAddress.Address3) AS Address3" & Line _
          & "		,MIN( SubscriberAddress.Address4) As Address4" & Line _
          & "		,MIN( SubscriberAddress.Town) AS City" & Line _
          & "		,MIN( SubscriberAddress.County) As State" & Line _
          & "		,MIN( SubscriberAddress.PostCode) AS PostCode" & Line _
          & "		,MIN( Country.CountryName) As CountryName" & Line _
          & "		,MIN( Email.AddressText) As EmailAddress" & Line _
          & "		,'' As Notes" & Line

        '31/3/11    James Woosnam   SIR2401 - Use the company specific address if available else use latest address
        SQLFrom = SQLFrom _
         & "	Left JOIN SubscriberAddress" & Line _
          & " 		LEFT JOIN Country" & Line _
          & " 		ON Country.CountryId = SubscriberAddress.CountryId" & Line _
          & " 	ON SubscriberAddress.SubscriberAddressId = (SELECT top 1 sa.SubscriberAddressId" & Line _
          & " 											FROM SubscriberAddress sa" & Line _
          & "                                           WHERE(sa.SubscriberId = Subscriber.SubscriberId)" & Line _
          & "											AND sa.AddressType = 'Postal'" & Line _
          & " 											AND sa.AddressDescription <> 'Redundant'" & Line _
          & " 											Order BY CASE WHEN  sa.AddressDescription = Company.DefaultAddressDescription THEN 0 ELSE 1 End" & Line _
          & " 											    ,sa.LastUpdatedDateTime " & Line _
          & " 											)" & Line _
          & " 	Left JOIN SubscriberAddress Email" & Line _
          & " 	ON Email.SubscriberId = Subscriber.SubscriberID" & Line _
          & " 	AND Email.AddressType = 'Email'" & Line _
          & " 	AND Email.AddressDescription = 'Main'"

        SQLOrderBy = " ORDER BY  CASE WHEN MIN(SalesorderLine.OrderType) = 'Block' " & Line _
          & "							  THEN MIN(SalesorderLine.OrderedBySubscriberName) " & Line _
          & "							 ELSE '' END" & Line _
          & "                   ,MIN(Subscriber.SubscriberName)"
        Return sqlForTemp & SQLColumns & SQLFrom & SQLWhere & SQLGroup & SQLOrderBy


    End Function

    Protected Sub ExpireBetweenFromDate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ExpireBetweenFromDate.TextChanged
        Me._tblGroups = Nothing
        Me.ExpireBetweenToDate.Focus()
    End Sub

    Protected Sub ExpireBetweenToDate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ExpireBetweenToDate.TextChanged
        Me._tblGroups = Nothing
    End Sub
    Protected Sub OrderOnDate_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles OrderOnDate.TextChanged
        Me._tblGroups = Nothing
    End Sub

    Protected Sub SubscribedToProduct_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles SubscribedToProduct.SelectedIndexChanged
        Me._tblGroups = Nothing
    End Sub
End Class
