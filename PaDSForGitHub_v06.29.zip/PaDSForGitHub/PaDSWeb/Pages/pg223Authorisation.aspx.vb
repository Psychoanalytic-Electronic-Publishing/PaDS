﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'20/01/11  Julian Gates   Initial version
'28/01/14   Julian Gates    SIR3398 - Add functionality to order zero value products.
'19/03/15   Julian Gates    SIR3785 - Rework Prev button link to go to Spanish order page if IsSpanishIJPESSubscriber
'14/05/15   Julian Gates    SIR3838 - Call new Salesorder.SendEmailReceipt in ProcessZeroValueOrders for zero orders
'03/07/15   Julian Gates    SIR3895 - Call SendEmailReceipt for non zero value orders and update cashbook EmailReceiptDateTime field
'23/10/15   Julian Gates    SIR3895 - Change ProductLinkText message after credit card authorisation
'26/2/18    Julian Gates    SIR4588 - Add Payment card fields to AuthenticateCreditCard
'16/1/20    James Woosnam   SIR4995 -  Detect error correctly
'25/08/21   Julian Gates    SIR5305 - Change @p-e-p.org emails to @pep-web.org
'06/10/21   Julian Gates    SIR5334 - Rework text after confirmation and give user two logon options and cancel current sessions.
'17/1/22    James Woosnam   SIR5389 - Expire all sessions if product linked to a content set
'17/1/22    James Woosnam   SIR5411 - Reworked to put all visible settings in PageSetup and hide zeo value confirm after confirmation, also When zero value show additional message to encourage confirmation
'13/06/22   Julian Gates    SIR5512 - Change language translations to come from database table
'16/8/22    Julian Gates    SIR5516 - Don't show previous button when zero value order.
'28/2/23    James Woosnam   SIR5601 - Ensure that only the correct cashbook is used, and expire all sessions where required for both types of confirm, and remove redundant code
Partial Class Pages_pg223Authorisation
    Inherits System.Web.UI.Page
    Dim pageMode As String = ""
    Dim StdCode As New BusinessLogic.StdCode()
    Public End5AccessText As String = ""

    Private _SalesOrder As BusinessLogic.SalesOrder = Nothing
    Public Property SalesOrder() As BusinessLogic.SalesOrder
        Get
            If Me._SalesOrder Is Nothing Then
                Me._SalesOrder = New BusinessLogic.SalesOrder(Me.txtOrderNumber.Value, Me.Master.db, Me.Master.UserSession)
            End If
            Return Me._SalesOrder
        End Get
        Set(ByVal value As BusinessLogic.SalesOrder)
            Me._SalesOrder = value
        End Set
    End Property

    Private _Cashbook As BusinessLogic.Cashbook = Nothing
    Public Property Cashbook() As BusinessLogic.Cashbook
        Get
            If Me._Cashbook Is Nothing Then
                If ViewState("CashbookId") IsNot Nothing Then
                    Me._Cashbook = New BusinessLogic.Cashbook(CInt(ViewState("CashbookId")), Me.Master.db, Me.Master.UserSession)
                Else
                    Me._Cashbook = New BusinessLogic.Cashbook(Me.Master.db, Me.Master.UserSession)

                End If
            End If
            Return Me._Cashbook
        End Get
        Set(ByVal value As BusinessLogic.Cashbook)
            Me._Cashbook = value
        End Set
    End Property

    Public Property DisplayLanguage As BusinessLogic.UserSession.DisplayLanguages
        Get
            Return Me.Master.UserSession.DisplayLanguage
        End Get
        Set(value As BusinessLogic.UserSession.DisplayLanguages)
            Me.Master.UserSession.DisplayLanguage = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Master.Initilise("Order Confirmation", "06", "")
        Master.ShowLanguageRBL = True





        If Page.IsPostBack Then
            Me.SalesOrder.MainDataset = CType(ViewState("MainDataSet"), DataSet)
        Else
            If Request.QueryString("PageType") <> "" Then
                Me.txtPageType.Value = Request.QueryString("PageType")
            End If

            If Request.QueryString("OrderNumber") <> "" Then
                Me.txtOrderNumber.Value = Request.QueryString("OrderNumber")
            End If

            If Request.QueryString("ProductCode") <> "" Then
                Me.txtProductCode.Value = Request.QueryString("ProductCode")
            End If
            '28/2/23    James Woosnam   SIR5601 - Ensure that only the correct cashbook is used
            Dim ExistingCashbookId As Integer = Me.Master.WebForm.db.DLookup("CashbookId", "Cashbook", "SubscriberId=" & Me.Master.UserSession.Data("SubscriberId") & "AND CashbookStatus = 'Partial' AND CompanyId=" & Me.SalesOrder.SalesOrderRow("CompanyId") & " AND OrderNumber = " & Me.SalesOrder.SalesOrderRow("OrderNumber"))
            If ExistingCashbookId <> Nothing Then
                ViewState("CashbookId") = ExistingCashbookId
                pageMode = "Update"
            Else
                Me.Cashbook = New BusinessLogic.Cashbook(Master.db, Master.UserSession)
                pageMode = "Add"
            End If
            If Me.Master.WebForm.IsValid Then
                ReadRecord()
            End If
            Me.PaymentCardType.Focus()
        End If

        'Used to display animation when processing credit card and hide confirm button
        Me.progressImage.Style.Add("display", "none")
        ConfirmBtn.OnClientClick = "document.getElementById('" + progressImage.ClientID + "').style.display = ''; document.getElementById('" + ConfirmBtn.ClientID + "').style.display = 'none';"

    End Sub

    Sub PageSetup()
        '17/1/22    James Woosnam   SIR5411 - Reworked to put all visible settings in PageSetup and hide zeo value confirm after confirmation
        Me.Master.PageTitle = Master.GetTranslatedText(194, 223, "Order Confirmation")
        Me.CVNumberHelpLink.NavigateUrl = "javascript:CVNumberHelpPopupWindow(""../HelpFiles/CVNumberHelp.htm"")"

        Dim IsPEPWebOrder As Boolean = Master.db.DLookup("OrderNumber", "SalesOrderLine sol INNER JOIN ProductContentSet pcs ON pcs.ProductCode = sol.ProductCode", "OrderNumber = " & Me.OrderNumber.Text) IsNot Nothing
        Dim IsZeroValue As Boolean = Me.AmountGross.Text = "0.00"
        Dim IsConfirmed As Boolean = ({"Confirmed", "Complete"}.Contains(Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")) And IsZeroValue) Or (Me.Cashbook.CashbookId <> Nothing AndAlso Me.Cashbook.CashbookRow("CashbookStatus") = "Confirmed")

        If IsConfirmed Then
            If IsZeroValue Then
                Me.AuthorisationText.Text = Master.GetTranslatedText(172, 223 _
                                                    , "A confirmation email has been sent to your registered email address." _
                                                    , "Un correo electrónico de confirmación ha sido enviado a su dirección de correo electrónico.")
            Else
                Me.AuthorisationText.Text = Master.GetTranslatedText(173, 223 _
                              , "Your credit card has been authorised and your order has been placed.<br/> Please make a note of your order number. A confirmation email has been sent to your registered email address." _
                              , "Su tarjeta de crédito ha sido autorizada y su compra está siendo procesada. Por favor guarde su número de compra. Un correo electrónico de confirmación ha sido enviado a su dirección de correo electrónico.")

            End If
        Else
            '17/1/22    James Woosnam   SIR5411 - When zero value show additional message to encourage confirmation

            If IsZeroValue Then Me.AuthorisationText.Text = Master.GetTranslatedText(174, 223 _
                                                    , "Please use the ""Confirm"" Button to complete this order." _
                                                    , "Utilice el botón ""Confirmar"" para completar este pedido.")

        End If
        Me.WebProductLinkText.Text = ProductLinkText()

        Me.AuthorisationText.Visible = IsConfirmed Or IsZeroValue
        Me.ConfirmBtn.Visible = Not IsConfirmed And Not IsZeroValue
        Me.ConfirmZeroOrderBtn.Visible = Not IsConfirmed And IsZeroValue
        Me.WebProductLinkRow.Visible = IsConfirmed And IsPEPWebOrder
        Me.PaDSLogonBtn.Visible = IsConfirmed
        Me.PEPLogonBtn.Visible = IsPEPWebOrder And IsConfirmed
        '16/8/22    Julian Gates    SIR5516 - Don't show previous button when zero value order.
        Me.PrevBtn.Visible = Not IsConfirmed And Not IsZeroValue
        Me.InsertCreditCardDetailsPanel.Visible = Not IsConfirmed And Not IsZeroValue
        Me.WarningTable.Visible = IsConfirmed

        Me.ConfirmBtn.Text = Master.GetTranslatedText(64, 0, "Confirm")

        Me.ConfirmZeroOrderBtn.Text = Master.GetTranslatedText(64, 0, "Confirm")

        Me.PrevBtn.Text = Master.GetTranslatedText(176, 223 _
                               , "Prev" _
                               , "Atrás")

        Me.PaDSLogonBtn.Text = Master.GetTranslatedText(177, 223 _
                              , "PaDS Logon" _
                              , "PaDS Logon")

        Me.PEPLogonBtn.Text = Master.GetTranslatedText(178, 223 _
                              , "PEP Logon" _
                              , "PEP Logon")

        Me.CVNumberHelpLink.ToolTip = Master.GetTranslatedText(179, 223 _
                              , "What is the security code?" _
                              , "¿Qué es el Código de Seguridad?")
    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else

                Me.Master.WebForm.DropDownValidateMandatory(Me.PaymentCardType, Master.GetTranslatedText(166, 0, "Card Type"))
                Me.Master.WebForm.FieldValidateMandatory(Me.PaymentCardNumber, Master.GetTranslatedText(181, 223, "Card Number", "Es obligación escribir su Número de tarjeta"))

                Me.PaymentCardExpiryDate.CssClass = "pageField"
                Dim invalidExpiry As Boolean = False
                If Me.PaymentCardExpiryDate.Text = "" Then
                    invalidExpiry = True
                Else
                    If Len(Me.PaymentCardExpiryDate.Text) <> 5 Then
                        invalidExpiry = True
                    Else
                        Dim exParts() As String = Me.PaymentCardExpiryDate.Text.Split("-")
                        If exParts.Length <> 2 Then invalidExpiry = True
                        If Not invalidExpiry AndAlso Not IsDate(Left(Now.ToString("yyyy"), 2) & exParts(1) & "-" & exParts(0) & "-01") Then invalidExpiry = True
                    End If
                End If
                If invalidExpiry Then
                    Me.Master.WebForm.FieldErrorControl(Me.PaymentCardExpiryDate, Master.GetTranslatedText(184, 223, "Expiry must be MM-YY"))
                End If
                Me.Master.WebForm.FieldValidateMandatory(Me.PaymentCardName, Master.GetTranslatedText(169, 0, "Name on Card"))
                Me.PaymentCardCVNumber.CssClass = "pageField"
                Me.Master.WebForm.FieldValidateNumber(Me.PaymentCardCVNumber, True, "Security Code")
                If Me.PaymentCardCVNumber.Text <> "" _
                    And Me.PaymentCardType.SelectedValue <> "" Then
                    Select Case Me.PaymentCardType.SelectedValue
                        Case "American Express"
                            If Len(Me.PaymentCardCVNumber.Text) <> 4 Then
                                Me.Master.WebForm.FieldErrorControl(Me.PaymentCardCVNumber, Master.GetTranslatedText(187, 223 _
                                    , "Security Code for American Express must be 4 numbers form the front of your card" _
                                    , "El Código de Seguridad para American Express son los 4 números que aparecen en la cara frontal de su tarjeta."))
                            End If
                        Case Else
                            If Len(Me.PaymentCardCVNumber.Text) <> 3 Then
                                Me.Master.WebForm.FieldErrorControl(Me.PaymentCardCVNumber, String.Format(Master.GetTranslatedText(183, 223, "Security Code for {0} must be the last 3 numbers from the back of your card"), Me.PaymentCardType.SelectedValue))
                            End If
                    End Select
                End If

        End Select

        Return Me.Master.WebForm.IsValid

    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        If pageMode = "Update" Then
            Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.Cashbook.CashbookRow)
        End If

        'Read in Order Summary
        Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.SalesOrder.SalesOrderRow)
        Me.AmountGross.Text = Format(Me.SalesOrder.SalesOrderRow("AmountGross"), "0.00")

        'populate dropdowns
        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria and Order by
        '15/11/19   James Woosnam   SIR4949 - Hard code to PEP company (2) for CC transactions
        Me.Master.WebForm.PopulateDropDownListFromSQL(Me.PaymentCardType, "SELECT LookupItemKey as Value" _
                                                                    & "     , Name As Text" _
                                                                    & " FROM Lookup" _
                                                                    & " WHERE LookupName = 'RemoteCreditCardType'" _
                                                                    & " AND LookupStatus = 'Active'" _
                                                                    & " AND CompanyId = 2" _
                                                                    & " ORDER BY DisplayOrder,Name,LookupItemKey" _
                                                                    , "<--Select-->")

    End Sub

    Protected Sub ConfirmBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ConfirmBtn.Click
        'Calls ProcessCreditCard using javascript
    End Sub

    Protected Sub ConfirmZeroOrderBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ConfirmZeroOrderBtn.Click
        '28/01/14   Julian Gates    SIR3398 - Process zedro value orders
        ProcessZeroValueOrders()
    End Sub


    Protected Sub ProcessCreditCard(ByVal sender As Object, ByVal e As EventArgs)
        Try
            If Me.IsPageValidForStatus("") Then
                If Me.Cashbook.CashbookId = Nothing Then
                    Me.Cashbook.RemoteAdd(Me.txtOrderNumber.Value,
                                       Me.SalesOrder.SalesOrderRow,
                                       Me.PaymentCardType.Text,
                                       Me.PaymentCardNumber.Text,
                                       Me.PaymentCardName.Text,
                                       Me.PaymentCardExpiryDate.Text,
                                       Me.PaymentCardCVNumber.Text
                                       )
                    ViewState("CashbookId") = Me.Cashbook.CashbookId
                Else
                    Me.Master.WebForm.PopulateDataRowFromPageFields(Me.Cashbook.CashbookRow)
                    '19/5/11    James Woosnam   Update Cashbook currency and amaount as they are not on the page
                    Me.Cashbook.CashbookRow("CurrencyCode") = Me.SalesOrder.SalesOrderRow.Item("CurrencyCode")
                    Me.Cashbook.CashbookRow("Amount") = Me.SalesOrder.SalesOrderRow.Item("AmountGross")
                    Me.Cashbook.Save()
                End If

                'Call Cybersource from here
                Try
                    '26/2/18    Julian Gates    SIR4588 - Add Payment card fields to AuthenticateCreditCard
                    Me.Cashbook.AuthenticateCreditCard(Me.PaymentCardNumber.Text,
                                                        Me.PaymentCardCVNumber.Text)

                    Select Case Me.Cashbook.CashbookRow("CashbookStatus")
                        Case "Confirmed"
                            'The request succeeded

                            '03/07/15   Julian Gates    SIR3895 - Call SendEmailReceipt for non zero value orders and update cashbook EmailReceiptDateTime
                            'Call new SendEmailReceipt 
                            Me.SalesOrder.SendEmailReceipt()
                            Cashbook.CashbookRow("EmailReceiptDateTime") = Now()
                            Me.Cashbook.Save()
                        Case "Partial"
                            Me.Master.WebForm.AddPageError(Me.Cashbook.AuthorisationRejectMsg)

                        Case Else
                            Throw New Exception(Master.GetTranslatedText(188, 223 _
                                                    , "Unexpected cashbook status: " _
                                                    , "Estado inesperado del libro de caja: ") & Me.Cashbook.CashbookRow("CashbookStatus"))
                    End Select
                Catch ex As Exception
                    Me.Master.WebForm.AddPageError(New Exception(String.Format(Master.GetTranslatedText(189, 223 _
                    , "Credit Card authorisation has caused a system error, please wait 1 minute and try again." _
                    & " If authorisation is still failing Email PEP Sales on <a href='{0}'>{0}</a>.....", Master.db.GetParameterValue("PepSupportEmailAddress"))), ex))
                End Try
                Select Case Me.Cashbook.CashbookRow("CashbookStatus")
                    Case "Confirmed"
                        ExpireSessionsIfContentSet()
                End Select
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(Master.GetTranslatedText(190, 223 _
                                                    , "Credit authorisation failed: " _
                                                    , "La autorización de su tarjeta de crédito ha fallado: "), ex))
        End Try

    End Sub
    Sub ExpireSessionsIfContentSet()

        '17/1/22    James Woosnam   SIR5389 - Expire all sessions if ...product linked to a content set
        If Master.db.DLookup("OrderNumber", "SalesOrderLine sol INNER JOIN ProductContentSet pcs ON pcs.ProductCode = sol.ProductCode", "OrderNumber = " & Me.OrderNumber.Text) IsNot Nothing Then
            Dim ru As New BusinessLogic.RemoteUser(Master.UserSession.UserId, Master.db, Master.UserSession)
            ru.ExpireAllSessions()
        End If
    End Sub
    Sub ProcessZeroValueOrders()
        Try
            Me.SalesOrder.SalesOrderRow.Item("IsPaid") = 1
            Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus") = "Confirmed"
            Me.SalesOrder.Save()
            'Call new SendEmailReceipt in ProcessZeroValueOrders for zero orders
            Me.SalesOrder.SendEmailReceipt()
            ExpireSessionsIfContentSet()
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(Master.GetTranslatedText(191, 223 _
                                                    , "Zero value order confirmation failed: " _
                                                    , "La confirmación de compra de valor cero ha fallado: "), ex))
        End Try
        '16/1/20    James Woosnam   SIR4995 -  Detect error correctly
        If Me.Master.WebForm.IsValid Then

        End If
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.SalesOrder.MainDataset
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    Protected Sub PrevBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles PrevBtn.Click
        Dim sQry As String = ""
        sQry = Me.Master.UserSession.QueryString
        sQry += "&pageMode=" & Me.txtPageType.Value
        sQry += "&CompanyId=" & Me.SalesOrder.SalesOrderRow("CompanyId")
        Select Case Me.txtPageType.Value
            Case "NewOrder"
                Response.Redirect("../pages/pg232RemoteOrder.aspx?" & sQry)
            Case "RenewOrder"
                sQry += "&ProductCode=" & Me.txtProductCode.Value 'This is required to show correct product
                Response.Redirect("../pages/pg232RemoteOrder.aspx?" & sQry)
        End Select
    End Sub

    Protected Sub PaDSLogonBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles PaDSLogonBtn.Click
        If Master.WebForm.IsValid Then Response.Redirect("../Pages/pg070Logon.aspx")
    End Sub
    Protected Sub PEPLogonBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles PEPLogonBtn.Click
        If Master.WebForm.IsValid Then Response.Redirect(Me.Master.db.GetParameterValue("PEPWeb2021URL"))
    End Sub

    Protected Function ProductLinkText() As String
        '23/10/15   Julian Gates    SIR3895 - Change ProductLinkText message after credit card authorisation
        '06/10/21   Julian Gates    SIR5334 - Rework text below to give user two logon options.
        ProductLinkText = Master.GetTranslatedText(193, 223 _
                                                    , "If you have ordered a PEP web product, please select the PEP Logon button below to access it." _
                                                       & " You will have to enter your PaDS username and password into the appropriate boxes and you will then have immediate access." _
                                                       & "<br/><br/>Or select the PaDS Logon button below to re-login to PaDS to view or update your account details." _
                                                    , "Si ha pedido un producto web de PEP, seleccione el botón de inicio de sesión de PEP a continuación para acceder a él." _
                                                       & " Tendrá que ingresar su nombre de usuario y contraseña de PaDS en las casillas correspondientes y luego tendrá acceso inmediato." _
                                                       & "<br/><br/>O seleccione el botón Inicio de sesión de PaDS a continuación para volver a iniciar sesión en PaDS para ver o actualizar los detalles de su cuenta.")
        Return ProductLinkText
    End Function
End Class
