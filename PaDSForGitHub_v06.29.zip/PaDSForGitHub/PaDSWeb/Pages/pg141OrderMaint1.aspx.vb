﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.Subscriber
'Modification History
'21/04/20  Julian Gates   Initial New version

Partial Class Pages_pg141OrderMaint1
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                If ViewState("SubscriberId") IsNot Nothing Then
                    _Subscriber = New BusinessLogic.Subscriber(ViewState("SubscriberId"), Me.uPage.db, Me.uPage.UserSession)
                End If
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Add New Order ", "")
        Try
            If Page.IsPostBack Then
            Else
                If Request.QueryString("SubscriberId") <> "" Then
                    Try
                        ViewState("SubscriberId") = CInt(Request.QueryString("SubscriberId"))
                    Catch ex As Exception
                        Me.uPage.PageError = "Invalid Parameter has been passed in"
                    End Try
                End If
                If Me.uPage.IsValid Then
                    ReadRecord()
                End If
                Me.OrderType.Focus()
            End If
        Catch ex As Exception
            uPage.PageError = "An unexpected error has occured.  Please contact support." & ex.ToString
        End Try

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

    End Sub

    Sub PageSetup()
        uPage.pageTitle = "Add New Order"
        Me.pageHeaderTitle.Text = uPage.pageTitle

    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else
                Me.uPage.DropDownValidateMandatory(Me.OrderType, "Order Type")
                Me.uPage.DropDownValidateMandatory(Me.CompanyId, "Company")
        End Select

        Return Me.uPage.IsValid
    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Me.uPage.PopulatePageFieldsFromDataRow(Me.Subscriber.SubscriberRow)
        'populate dropdowns
        Me.uPage.PopulateDropDownListFromLookup(Me.OrderType, "OrderType", uPage.db.DBConnection, "<--Select-->")

        Dim Sql As String = "SELECT CompanyId As Value" _
                            & " ,CompanyName As Text" _
                            & " FROM " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                            & " ORDER BY 2"
        Me.uPage.PopulateDropDownListFromSQL(Me.CompanyId, Sql, uPage.db.DBConnection, "<--Select-->")
    End Sub

    Protected Sub NextBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles NextBtn.Click

        If Me.IsPageValidForStatus("") Then
            Dim Order As New BusinessLogic.SalesOrder(Me.uPage.db, Me.uPage.UserSession)
            Try
                uPage.db.BeginTran()
                Try
                    Order.AdminOrderAdd(CInt(Me.SubscriberId.Text) _
                                        , Me.OrderType.SelectedValue _
                                        , CInt(Me.CompanyId.SelectedValue)
                                        )
                    Order.Save()

                    uPage.db.CommitTran()
                Catch ex As Exception
                    uPage.db.RollbackTran()
                    Throw ex
                End Try

            Catch ex As Exception
                    Me.uPage.PageError = "An unexpected error has occured. Please contact support." & ex.ToString
            End Try
            If Me.uPage.IsValid Then
                Response.Redirect("../pages/pg142Ordermaint2.aspx?PageMode=Update&OrderNumber=" & Order.OrderNumber)
            End If
        End If
    End Sub

    Protected Sub BackBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        Response.Redirect("../pages/pg140OrderSelect.aspx")
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        Me.uPage.PagePreRender()

    End Sub
End Class
