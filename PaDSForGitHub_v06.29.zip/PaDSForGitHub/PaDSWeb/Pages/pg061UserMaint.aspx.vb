﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports BusinessLogic.UserSession
Imports BusinessLogic.RemoteUser



'Modification History
'13/01/2016     Julian Gates   Initial Version
'25/10/19   Julian Gates    SIR4763 - Rework user maint page to be used for all users.
'1/11/19    James Woosnam   SIR4766 - Add support for spoof link
'13/1/20    James Woosnam   SIR4977 - Disable Email address if same as username for Individuals
'14/1/20    Julian Gates    SIR4991 - Add Make Active and Reset Password button and associated code.
'23/9/20    Julian Gates    SIR5043 - Add BuildRemoteUserAutoLogon grid and AutoLogonType radio button control.
'20/08/20   Julian Gates    SIR5099 - Add Audit link
'12/11/20   Julian Gates    SIR5158 - Add User Logon History grid
'09/02/21   Julian Gates    SIR5176 - Add FederatedPersonId, SendVideoAlerts, SendJournalAlerts and PEPWebClientSettings.
'12/02/21   Julian Gates    SIR5193 - Add DirectMakeActiveBtn and MakeInactiveBtn when Status = Pending
'18/02/21   Julian Gates    SIR5193 - Only show IsValidEmail if Email Address has changed and add MaintainScrollPositionOnPostback to .aspx page
'18/02/21   Julian Gates    SIR5193 - Add SessionId to Logon History and link to Session Data page.
'15/03/21   Julian Gates    Allow Email Address to be empty if required and not applicable to Group Users.
'16/03/21   Julian Gates    SIR5213 - Add ShowCounterReports check box for Group Admin users.
'24/03/21   Julian Gates    SIR5217 - Add LastLoggedInMethod and LastAutoLoginGroupUserId and Clear Auto Logon button.
'08/04/21   Julian Gates    SIR5220 - Only show AutoLogonTypeTable for GroupUser
'20/04/21   Julian Gates    SIR5224 - Add LastAutoLoginRefreshDateTime field.
'20/05/21   Julian Gates    SIR5253 - Add IsModerator field.
'06/07/21   Julian Gates    Add LastAutoLoginGroupUserNameLink to Logons section
'18/8/21    James Woosnam   SIR5279 - Add CounterReportsOnly
'14/9/21    Julian Gates    SIR5316 - Add ProxyDomainsForCORS field.
'17/09/21   Julian Gates    SIR5309 - Add ViewLatestActivity link
'03/12/21   Julian Gates    SIR5360 - Add GetAutoLoginPeriodDetails to show days left on Auto Logon.
'17/1/22    James Woosnam   SIR5389 - For UserGroups add button to logout all associated sessions
'26/10/22   James Woosnam   SIR5582 - If email is being sent by a someone who is not the user then never add session 

Partial Class Pages_pg061UserMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim pageMode As String
    Private _RemoteUser As BusinessLogic.RemoteUser = Nothing
    Public Property RemoteUser() As BusinessLogic.RemoteUser
        Get
            If Me._RemoteUser Is Nothing Then
                Me._RemoteUser = New BusinessLogic.RemoteUser(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._RemoteUser
        End Get
        Set(ByVal value As BusinessLogic.RemoteUser)
            Me._RemoteUser = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "User Maintenance", "")
        Me.pageHeaderTitle.Text = "User Maintenance"

        pageMode = Request.QueryString("PageMode")
        Select Case pageMode
            Case "Add"
                Me.UserId.Text = 0
            Case Else
                pageMode = "Update"
                Me.UserId.Text = Request.QueryString("UserId")
        End Select
        Select Case Me.uPage.UserSession.AuthorityLevel
            Case AuthorityLevels.SuperCompanyAdmins
                'all fine
            Case AuthorityLevels.CompanyAdmins
                'only update own user
                If Me.UserId.Text <> Me.uPage.UserSession.UserId Then
                    Response.Redirect("pg100HomeAdmin.aspx?InfoMsg=You can only upate your user.")
                End If
            Case Else
                Response.Redirect("pg070Logon.aspx")
        End Select

        If Page.IsPostBack Then
            Me.RemoteUser.MainDataset = CType(ViewState("MainDataSetClass"), DataSet)

            If Left(Me.txtCommandData.Value, 10) = "DeleteRUAL" Then
                DeleteRemoteUserAutoLogonLineRecord(Mid(Me.txtCommandData.Value, 11))
            End If
            If Left(Me.txtCommandData.Value, 6) = "Delete" Then
                DeleteUserRightsLineRecord(Mid(Me.txtCommandData.Value, 7))
            End If
            BuildUserRightsGridHTML()
        Else
            Select Case pageMode
                Case "Add"
                    If Request.QueryString("EmailAddress") <> "" And Request.QueryString("SubscriberId") <> "" And Request.QueryString("AuthorityLevel") = "IndividualSubscriber" Then
                        Try
                            'Add new Individual remote user from Subscriber maint page.  Add here and rdirect
                            Me.RemoteUser = New BusinessLogic.RemoteUser(uPage.db, uPage.UserSession)
                            Me.RemoteUser.AddNewSubscriberUser(Request.QueryString("EmailAddress"), CInt(Request.QueryString("SubscriberId")), [Enum].Parse(GetType(AuthorityLevels), Request.QueryString("AuthorityLevel")))
                        Catch ex As Exception
                            Me.uPage.PageError = "Create new Remote User failed " & ex.ToString
                        End Try

                        If Me.uPage.IsValid Then
                            Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=This record has been successfully added.&UserId=" & Me.RemoteUser.UserId)
                        End If
                    Else
                        ReadRecord()

                    End If
                Case "Update"
                    Try
                        Me.RemoteUser = New BusinessLogic.RemoteUser(CInt(Me.UserId.Text), Me.uPage.db, Me.uPage.UserSession)
                    Catch ex As Exception
                        Me.uPage.PageError = "Failed to Read RemoteUser:" & ex.Message
                        Exit Sub
                    End Try
                    ReadRecord()
            End Select
            Me.UserName.Focus()

            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
        End If
        If pageMode = "Update" Then
            BuildRemoteUserAutoLogon()
        End If
    End Sub

    Sub PageSetup()
        Select Case pageMode
            Case "Add"
                Me.pageHeaderTitle.Text = "User Maint: Add User"
                Me.UserName.Focus()
                If Not Page.IsPostBack Then
                    Me.ValidUntil.Text = "01/01/3000"
                End If
                Me.UserIdTR.Visible = False
                Me.StatusTable.Visible = False
                Me.UserNameTR.Visible = False
                Me.OldEmailAddressTR.Visible = False
                Me.EmailAddress.Visible = True
                Me.SubscriberIdForAddTR.Visible = {"GroupAdmins", "GroupRenewer"}.Contains(Me.AuthorityLevel.SelectedValue)
                Me.EmailMandatory.Visible = Not Me.AuthorityLevel.SelectedValue.Contains("Group")
                Me.EmailAuthenticationSentDateTimeRO.Visible = False
                Me.EmailAuthenticationSentDateTimeTR.Visible = False
                Me.ValidUntilTR.Visible = False
                Me.PasswordRetryAttemptsTR.Visible = False
                Me.CreatedDateTimeTR.Visible = False
                Me.CreatedByUserIdTR.Visible = False
                Me.LastUpdatedDateTimeTR.Visible = False
                Me.LastUpdatedByUserIdTR.Visible = False
                Me.IsPasswordValidRow.Visible = False
                Me.ResetPasswordTR.Visible = False
                UserRightsheader.Visible = False
                Me.UserRightsTable.Visible = False
                Me.UserRightsAddTable.Visible = False
                Me.SpoofToPEPWebLk.Visible = False
                Me.SpoofToPaDSLk.Visible = False
                Me.AutoLogonTypeTable.Visible = False
                Me.SendAlertsTable.Visible = False
                Me.PEPWebClientSettingsTable.Visible = False
                Me.LogonDetailsTR.Visible = False
                Me.ExcludeUsageStatsFromReportsRow.Visible = False
                Me.IsModeratorRow.Visible = False
                Exit Sub
            Case "Update"
                uPage.pageTitle = "User Maint:" & RemoteUser.UserName
                Me.pageHeaderTitle.Text = uPage.pageTitle
                Me.RemoteUserAutoLogonHeaderRow.Visible = True
                Me.RemoteUserAutoLogonTableRow.Visible = True

                '20/08/20   Julian Gates    SIR5099 - Add Audit link
                Me.AuditLink.NavigateUrl = "../pages/pg040AuditLogDisplay.aspx?FltrUpdatedRecordFamily=RemoteUser&FltrUpdatedRecordFamilyKey=" & Me.RemoteUser.UserId
                Me.AuditLink.Text = "View Audit"
                Me.AuditLink.ToolTip = "View Audit for this record"
                Me.EmailMandatory.Visible = False
                '16/03/21   Julian Gates    SIR5213 - Show ShowCounterReports
                Me.ShowCounterReportsTR.Visible = RemoteUser.AuthorityLevel = AuthorityLevels.GroupAdmins
                '18/8/21    James Woosnam   SIR5279 - Add CounterReportsOnly
                Me.CounterReportsOnlyTR.Visible = RemoteUser.AuthorityLevel = AuthorityLevels.GroupAdmins And Me.ShowCounterReports.Checked
                '08/04/21   Julian Gates    SIR5220 - Only show AutoLogonTypeTable for GroupUser
                Me.AutoLogonTypeTable.Visible = RemoteUser.AuthorityLevel = AuthorityLevels.GroupUser
                Me.LogonDetailsTR.Visible = RemoteUser.AuthorityLevel <> AuthorityLevels.GroupUser
                Me.ExpireAllGroupSessionsTR.Visible = RemoteUser.AuthorityLevel = AuthorityLevels.GroupUser
                '06/07/21   Julian Gates    Add LastAutoLoginGroupUserNameLink to Logons section
                If Not uPage.db.IsDBNull(RemoteUser.RemoteUserRow("LastAutoLoginGroupUserId")) Then
                    Me.LastAutoLoginGroupUserNameLink.NavigateUrl = "../pages/pg061UserMaint.aspx?PageMode=Update&UserId=" & RemoteUser.RemoteUserRow("LastAutoLoginGroupUserId")
                    Me.LastAutoLoginGroupUserNameLink.Text = uPage.db.DLookup("UserFullName", "RemoteUser", "UserId=" & RemoteUser.RemoteUserRow("LastAutoLoginGroupUserId"))
                    Me.LastAutoLoginGroupUserNameLink.ToolTip = "View Last Auto Login Group User"
                End If
                '17/09/21   Julian Gates    SIR5309 - Add ViewLatestActivity link
                Select Case Me.RemoteUser.UserStatus
                    Case UserStates.Active, UserStates.Emailed
                        Me.ViewLatestActivityLink.NavigateUrl = "../pages/pg090SessionData.aspx?UserId=" & Me.RemoteUser.UserId
                        Me.ViewLatestActivityLink.Text = "View Latest Activity"
                        Me.ViewLatestActivityLink.ToolTip = "View Latest Activity for this User"
                End Select
                '08/02/23   Julian Gates    SIR5592 - Add CompanyAdmins and SuperCompanyAdmins username length validation on page load
                If RemoteUser.AuthorityLevel = AuthorityLevels.CompanyAdmins Or RemoteUser.AuthorityLevel = AuthorityLevels.SuperCompanyAdmins Then
                    If Me.UserName.Text.Count > 20 Then
                        Me.UserNameLengthValidationRow.Visible = True
                    End If
                End If
        End Select
        Dim HasAdminPermissions As Boolean = Me.uPage.UserSession.AuthorityLevel = AuthorityLevels.SuperCompanyAdmins
        Dim IsIndividualSub As Boolean = RemoteUser.AuthorityLevel = AuthorityLevels.IndividualSubscriber

        Me.UserName.Enabled = HasAdminPermissions
        Me.UserFullName.Enabled = HasAdminPermissions And Not IsIndividualSub
        Me.EmailAddress.Visible = True
        Me.EmailAddress.Enabled = Not IsIndividualSub Or Me.EmailAddress.Text.Trim <> Me.UserName.Text.Trim
        Me.OldEmailAddressTR.Visible = Me.OldEmailAddressRO.Text <> ""
        Me.EmailAuthenticationSentDateTimeTR.Visible = Not uPage.db.IsDBNull(RemoteUser.RemoteUserRow("EmailAuthenticationSentDateTime"))
        Me.ValidUntil.Enabled = HasAdminPermissions
        Me.AuthorityLevel.Enabled = HasAdminPermissions
        Me.PasswordRetryAttempts.Enabled = HasAdminPermissions
        Me.ResetPasswordChangeTR.Visible = Me.DoResetPassword.Checked
        Me.RevertToOldPasswordTR.Visible = Not uPage.db.IsDBNull(RemoteUser.RemoteUserRow("OldPassword"))
        Me.RevertToOldPasswordTR.Cells(0).InnerText = "Revert to password from before " & CDate(uPage.db.IsDBNull(RemoteUser.RemoteUserRow("OldPasswordFromDateTime"), "01-jan-1900")).ToString("dd-MMM-yyyy")
        Me.SendActivationEmailBtn.Visible = RemoteUser.UserStatus = UserStates.Active Or RemoteUser.UserStatus = UserStates.Emailed
        Me.MakeActiveBtn.Visible = RemoteUser.UserStatus = UserStates.Pending Or RemoteUser.UserStatus = UserStates.InActive
        Me.MakeInactiveBtn.Visible = RemoteUser.UserStatus = UserStates.Active Or RemoteUser.UserStatus = UserStates.Emailed Or RemoteUser.UserStatus = UserStates.Pending
        Me.MakeActiveResetPasswordBtn.Visible = RemoteUser.UserStatus = UserStates.Emailed
        Me.DirectMakeActiveBtn.Visible = RemoteUser.UserStatus = UserStates.Pending
        Me.UserRightsAddTable.Visible = HasAdminPermissions And Not IsIndividualSub

        Me.SaveBtn.Enabled = HasAdminPermissions
        '1/11/19    James Woosnam   SIR4766 - Add spoof link
        Me.SpoofToPaDSLk.Visible = HasAdminPermissions
        Me.SpoofToPEPWebLk.Visible = HasAdminPermissions
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        'Populate all dropdown fields
        Dim dropDownIntialValue As String = "<---------Select--------->"
        uPage.PopulateDropDownListFromLookup(Me.AuthorityLevel, "AuthorityLevel", uPage.PrimaryConnection, dropDownIntialValue)
        uPage.PopulateDropDownListFromLookup(Me.NewRightsType, "RightsType", uPage.PrimaryConnection, "<--Type-->")
        Select Case pageMode
            Case "Add"
                Me.AuthorityLevel.Items.Remove("IndividualSubscriber")
                Dim sql As String = ""
                sql = "SELECT Value=SubscriberId"
                sql += " , Text=SubscriberName"
                sql += " FROM Subscriber"
                sql += " WHERE SubscriberStatus='Current'"
                sql += " AND EntityType='Organisation'"
                sql += " Order BY SubscriberName"
                uPage.PopulateDropDownListFromSQL(Me.SubscriberIdForAdd, sql, uPage.PrimaryConnection, "", "<--Select Organisation-->")
                'If Request.QueryString("EmailAddress") <> "" And Request.QueryString("SubscriberId") <> "" And Request.QueryString("AuthorityLevel") <> "" Then
                If Request.QueryString("SubscriberId") <> "" And Request.QueryString("AuthorityLevel") <> "" Then
                    'This caters for asdding user direct from an organisation subscriber, the authority level can be changed before add
                    If Request.QueryString("EmailAddress") <> "" Then
                        Me.EmailAddress.Text = Request.QueryString("EmailAddress")
                    End If
                    Me.SubscriberIdForAdd.SelectedValue = Request.QueryString("SubscriberId")
                    Me.UserName.Text = Me.EmailAddress.Text.Trim
                    Me.UserFullName.Text = uPage.db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & Request.QueryString("SubscriberId"))
                    Me.AuthorityLevel.SelectedValue = Request.QueryString("AuthorityLevel")
                    For i As Integer = Me.AuthorityLevel.Items.Count - 1 To 0 Step -1
                        If Not AuthorityLevel.Items(i).Value.Contains("Group") Then Me.AuthorityLevel.Items.Remove(AuthorityLevel.Items(i).Value)
                    Next
                End If
            Case "Update"
                uPage.PopulatePageFieldsFromDataRow(RemoteUser.RemoteUserRow)
                Me.OldEmailAddressRO.Text = uPage.db.IsDBNull(RemoteUser.RemoteUserRow("OldEmailAddress"), "")
                If uPage.db.IsDBNull(RemoteUser.RemoteUserRow("EmailAuthenticationSentDateTime")) Then
                    Me.EmailAuthenticationSentDateTimeRO.Text = ""
                Else
                    Me.EmailAuthenticationSentDateTimeRO.Text = CDate(RemoteUser.RemoteUserRow("EmailAuthenticationSentDateTime")).ToString("dd-MMM-yy HH:mm:ss")

                End If
                BuildUserRightsGridHTML()
                '1/11/19    James Woosnam   SIR4766 - Add spoof link
                If uPage.UserSession.IsSpoofSession Or Me.AuthorityLevel.SelectedValue = "GroupUser" Then
                    Me.SpoofToPaDSLk.Text = "PaDS Spoof not available"
                    Me.SpoofToPaDSLk.Enabled = False
                    Me.SpoofToPEPWebLk.Text = "PEP Spoof not available"
                    Me.SpoofToPEPWebLk.Enabled = False
                End If
                Me.SpoofToPaDSLk.NavigateUrl = uPage.UserSession.SpoofToPaDSLogonURL(Me.RemoteUser.UserName)
                Me.SpoofToPEPWebLk.NavigateUrl = uPage.UserSession.SpoofToPEPWebLogonURL(Me.RemoteUser.UserName)
                'Me.AutoLogonType.SelectedValue = uPage.db.IsDBNull(RemoteUser.RemoteUserRow("AutoLogonType"), "None")
                'depending on authority level, restrict what it can be changed to 
                For i As Integer = Me.AuthorityLevel.Items.Count - 1 To 0 Step -1
                    If Me.AuthorityLevel.SelectedValue.Contains("Company") And Not AuthorityLevel.Items(i).Value.Contains("Company") Then
                        Me.AuthorityLevel.Items.Remove(AuthorityLevel.Items(i).Value)
                    Else
                        If Me.AuthorityLevel.SelectedValue.Contains("Group") And Not AuthorityLevel.Items(i).Value.Contains("Group") Then
                            Me.AuthorityLevel.Items.Remove(AuthorityLevel.Items(i).Value)
                        Else
                            If Me.AuthorityLevel.SelectedValue.Contains("IndividualSubscriber") And Not AuthorityLevel.Items(i).Value.Contains("IndividualSubscriber") Then
                                Me.AuthorityLevel.Items.Remove(AuthorityLevel.Items(i).Value)
                            Else
                                If Me.AuthorityLevel.SelectedValue = "User" And Not AuthorityLevel.Items(i).Value = "User" Then Me.AuthorityLevel.Items.Remove(AuthorityLevel.Items(i).Value)
                            End If
                        End If
                    End If
                Next
                If RemoteUser.PEPWebClientSettingsForDisplay IsNot Nothing Then
                    Me.PEPWebClientSettingsRO.Text = RemoteUser.PEPWebClientSettingsForDisplay
                End If
                If Not uPage.db.IsDBNull(RemoteUser.RemoteUserRow("LastAutoLoginRefreshDateTime")) Then
                    Me.LastAutoLoginRefreshDateTimeText.Text = GetAutoLoginPeriodDetails(RemoteUser.RemoteUserRow("LastAutoLoginRefreshDateTime"), 90)
                End If
        End Select

    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub
    Enum validatorStates
        None
        AddRights
        MakeActive
        MakeInActive
    End Enum
    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As validatorStates = validatorStates.None) As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case validatorStates.AddRights
                If Me.NewRightsType.SelectedValue = "" Then
                    uPage.FieldErrorControl(Me.NewRightsType, "New Rights Type is mandatory")
                End If
                uPage.FieldValidateNumber(Me.NewRightsTo, True)
                Select Case pageMode
                    Case "Update"
                        'check for duplicate rights
                        If Me.NewRightsType.SelectedValue <> "" And Me.NewRightsTo.Text <> "" Then
                            If uPage.StdCode.DLookup("UserId", "RemoteUserRights", "UserId='" & Me.UserId.Text & "' AND RightsType='" & Me.NewRightsType.SelectedValue & "' AND RightsToId=" & Me.NewRightsTo.Text, uPage.PrimaryConnection).ToString() <> "" Then
                                uPage.PageError = "Selected Type: '" & Me.NewRightsType.SelectedValue & "' and Rights To Id: '" & Me.NewRightsTo.Text & "' already exists For this User, Please choose another."
                            End If
                        End If
                End Select
            Case validatorStates.MakeActive
                If RemoteUser.RemoteUserRights.Rows.Count = 0 Then
                    Me.uPage.FieldErrorControl(Me.NewRightsType, "At least one rights record must be added before making active")
                End If
        End Select

        If Me.EmailAddress.Text.Trim = "" And Not UserConfirmEmailChange.Checked And Not pageMode = "Add" And Not Me.AuthorityLevel.SelectedValue = "GroupUser" Then
            uPage.FieldErrorControl(Me.EmailAddress, "Email address is empty.  Please confirm that email address is not needed")
            Me.EmailAddressChangeConfirmationRow.Visible = True
        End If
        If Me.EmailAddress.Text.Trim <> "" And validatorStatus <> validatorStates.MakeInActive Then
            Dim sql As String
            sql = "SELECT UserId"
            sql += "  FROM RemoteUser"
            sql += "    WHERE UserId <> " & Me.UserId.Text
            sql += "    AND UserStatus <>'InActive'"
            Dim cmd As New SqlCommand(sql & " AND EmailAddress=@EmailAddress", uPage.db.DBConnection, uPage.db.DBTransaction)
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailAddress", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      Me.EmailAddress.Text.Trim))
            Dim tbl As DataTable = uPage.db.GetDataTableFromSQL(cmd)
            If tbl.Rows.Count <> 0 Then
                uPage.FieldErrorControl(Me.EmailAddress, "This Email Address is already used on PaDS UserId:" & tbl.Rows(0)(0))
            Else
                '18/02/21   Julian Gates    SIR5193 - Only show IsValidEmail if Email Address has changed
                '04/03/21   Julian Gates    Hotfix, add pageMode = "Add" OrElse to code to stop 0 record error.
                If pageMode = "Add" OrElse Me.EmailAddress.Text.Trim <> uPage.db.IsDBNull(RemoteUser.RemoteUserRow("EmailAddress"), "") Then
                    If Not New BusinessLogic.StdCode().IsValidEmail(Me.EmailAddress.Text) And Not UserConfirmEmailChange.Checked Then
                        uPage.FieldErrorControl(Me.EmailAddress, "Email address looks syntatically incorrect.  Please confirm")
                        Me.EmailAddressChangeConfirmationRow.Visible = True
                    End If
                End If
            End If
        End If
        uPage.FieldValidateMandatory(Me.UserFullName)

        Select Case pageMode
            Case "Add"
                If Not Me.AuthorityLevel.SelectedValue.Contains("Group") Then
                    uPage.FieldValidateMandatory(Me.EmailAddress)
                End If
            Case "Update"
                If Me.UserName.Text = "" Then
                    uPage.FieldErrorControl(Me.UserName, "User Name Is mandatory")
                End If
                If Me.UserId.Text <> "" And validatorStatus <> validatorStates.MakeInActive Then
                    Dim sql As String
                    sql = "SELECT UserId"
                    sql += "  FROM RemoteUser"
                    sql += "    WHERE UserId <> " & Me.UserId.Text
                    sql += "    AND UserStatus <>'InActive'"
                    Dim cmd As New SqlCommand(sql & " AND UserName=@UserName", uPage.db.DBConnection, uPage.db.DBTransaction)
                    cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          Me.UserName.Text))
                    Dim tbl As DataTable = uPage.db.GetDataTableFromSQL(cmd)
                    If tbl.Rows.Count <> 0 Then
                        uPage.FieldErrorControl(Me.UserName, "This UserName is already used on PaDS UserId:" & tbl.Rows(0)(0))
                    End If
                End If
                uPage.FieldValidateDate(Me.ValidUntil, True)
                uPage.FieldValidateNumber(Me.PasswordRetryAttempts, False)
                Dim stdCd As New BusinessLogic.StdCode()
                For Each rowtblPage As TableRow In Me.RemoteUserAutoLogonTable.Rows
                    If rowtblPage.ID.Contains("ROW") Then 'skipp header row

                        Dim AutoDetailsId As String = rowtblPage.ID.Replace("ROW", "")
                        Dim msg As String = ""
                        Dim AutoLogonTypecl As TableCell = RemoteUserAutoLogonTable.FindControl(AutoDetailsId & "AutoLogonType")
                        Dim AutoLogonType As BusinessLogic.RemoteUser.AutoLogonTypes = [Enum].Parse(GetType(BusinessLogic.RemoteUser.AutoLogonTypes), AutoLogonTypecl.Text)

                        Select Case AutoLogonType
                            Case AutoLogonTypes.IPAddress
                                Dim tbMin As TextBox = RemoteUserAutoLogonTable.FindControl(AutoDetailsId & "MinIPAddress")
                                Dim tbMax As TextBox = RemoteUserAutoLogonTable.FindControl(AutoDetailsId & "MaxIPAddress")
                                Dim tbNotes As TextBox = RemoteUserAutoLogonTable.FindControl(AutoDetailsId & "Notes")

                                If tbMin IsNot Nothing Then
                                    If AutoDetailsId = 0 And tbMin.Text = "" And tbMax.Text = "" Then Exit Select 'If new row and both blank then just jump out of select
                                    If Not stdCd.IsValidIPAddress(tbMin.Text, msg) Then
                                        uPage.FieldErrorControl(tbMin, msg)
                                    End If
                                End If
                                If tbMax IsNot Nothing Then
                                    If Not stdCd.IsValidIPAddress(tbMax.Text, msg) Then
                                        uPage.FieldErrorControl(tbMax, msg)
                                    End If
                                End If
                                If Me.uPage.IsValid And tbMin IsNot Nothing Then
                                    If stdCd.GetIPAddressAsNumber(tbMin.Text) > stdCd.GetIPAddressAsNumber(tbMax.Text) Then
                                        uPage.FieldErrorControl(tbMin, "Min IP address must be less than max")
                                    End If
                                    Dim dupRU As BusinessLogic.RemoteUser = Nothing
                                    dupRU = Me.RemoteUser.GetRemoteUserFromIPAddress(tbMin.Text, AutoDetailsId)
                                    If dupRU IsNot Nothing Then
                                        uPage.FieldErrorControl(tbMin, "Min IP address overlaps with another IP address range in UserId:" & dupRU.UserId & " " & dupRU.UserName)
                                    End If
                                    dupRU = Me.RemoteUser.GetRemoteUserFromIPAddress(tbMax.Text, AutoDetailsId)
                                    If dupRU IsNot Nothing Then
                                        uPage.FieldErrorControl(tbMax, "Min IP address overlaps with another IP address range in UserId:" & dupRU.UserId & " " & dupRU.UserName)
                                    End If
                                End If
                                If Me.uPage.IsValid And tbMin IsNot Nothing Then

                                    Dim vw As New DataView(RemoteUser.RemoteUserAutoLogon, "RemoteUserAutoLogonId=" & AutoDetailsId, "", DataViewRowState.CurrentRows)
                                    If AutoDetailsId = 0 And vw.Count = 0 Then 'This is the new row and has been populated so add to table
                                        Dim newRow As DataRow = RemoteUser.RemoteUserAutoLogon.NewRow
                                        newRow("RemoteUserAutoLogonId") = 999999999
                                        newRow("UserId") = RemoteUser.UserId  '' Me.RemoteUser.UserId
                                        newRow("MinIPAddress") = tbMin.Text
                                        newRow("MaxIPAddress") = tbMax.Text
                                        newRow("Notes") = tbNotes.Text
                                        RemoteUser.RemoteUserAutoLogon.Rows.Add(newRow)
                                    Else
                                        vw(0)("MinIPAddress") = tbMin.Text
                                        vw(0)("MaxIPAddress") = tbMax.Text
                                        vw(0)("Notes") = tbNotes.Text
                                    End If
                                End If
                            Case AutoLogonTypes.ReferrerURL
                                Dim tbRefURL As TextBox = RemoteUserAutoLogonTable.FindControl(AutoDetailsId & "ReferrerURL")
                                Dim tbNotes As TextBox = RemoteUserAutoLogonTable.FindControl(AutoDetailsId & "Notes")
                                If tbRefURL IsNot Nothing Then
                                    If tbRefURL.Text = Nothing Then
                                        uPage.FieldErrorControl(tbRefURL, "Referrer URL must be populated")
                                    Else
                                        Dim dupRU As BusinessLogic.RemoteUser = Nothing
                                        dupRU = Me.RemoteUser.GetRemoteUserFromReferrerURL(tbRefURL.Text, AutoDetailsId)
                                        If dupRU IsNot Nothing Then
                                            uPage.FieldErrorControl(tbRefURL, "Entered Referrer URL " & tbRefURL.Text & " is used in UserId:" & dupRU.UserId & " " & dupRU.UserName)
                                        End If
                                    End If
                                End If
                                If Me.uPage.IsValid And tbRefURL IsNot Nothing Then

                                    Dim vw As New DataView(RemoteUser.RemoteUserAutoLogon, "RemoteUserAutoLogonId=" & AutoDetailsId, "", DataViewRowState.CurrentRows)
                                    If AutoDetailsId = 0 And vw.Count = 0 Then 'This is the new row and has been populated so add to table
                                        Dim newRow As DataRow = RemoteUser.RemoteUserAutoLogon.NewRow
                                        newRow("RemoteUserAutoLogonId") = 999999999
                                        newRow("UserId") = RemoteUser.UserId  '' Me.RemoteUser.UserId
                                        newRow("ReferrerURL") = tbRefURL.Text
                                        newRow("Notes") = tbNotes.Text
                                        RemoteUser.RemoteUserAutoLogon.Rows.Add(newRow)
                                    Else
                                        vw(0)("ReferrerURL") = tbRefURL.Text
                                        vw(0)("Notes") = tbNotes.Text
                                    End If
                                End If
                            Case AutoLogonTypes.Federated
                                Dim tbFederatedEntity As TextBox = RemoteUserAutoLogonTable.FindControl(AutoDetailsId & "FederatedEntity")
                                Dim tbFederatedScope As TextBox = RemoteUserAutoLogonTable.FindControl(AutoDetailsId & "FederatedScope")
                                Dim chkIsFederatedLinkRequired As CheckBox = RemoteUserAutoLogonTable.FindControl(AutoDetailsId & "IsFederatedLinkRequired")
                                Dim tbNotes As TextBox = RemoteUserAutoLogonTable.FindControl(AutoDetailsId & "Notes")

                                If tbFederatedEntity IsNot Nothing Then
                                    If tbFederatedEntity.Text = Nothing Then
                                        uPage.FieldErrorControl(tbFederatedEntity, "Federated Entity must be populated")
                                    Else
                                        Dim dupRU As BusinessLogic.RemoteUser = Nothing
                                        dupRU = Me.RemoteUser.GetRemoteUserFromFederatedEntityAndScope(tbFederatedEntity.Text, tbFederatedScope.Text, AutoDetailsId)
                                        If dupRU IsNot Nothing Then
                                            If tbFederatedEntity.Text <> Nothing And tbFederatedScope.Text = Nothing Then
                                                uPage.FieldErrorControl(tbFederatedEntity, "Entered Federated Entity " & tbFederatedEntity.Text & " is used in UserId:" & dupRU.UserId & " " & dupRU.UserName & ". It must be unique.")
                                            End If
                                            If tbFederatedEntity.Text <> Nothing And tbFederatedScope.Text <> Nothing Then
                                                uPage.FieldErrorControl(tbFederatedScope, "Entered Federated Entity " & tbFederatedEntity.Text & " and Federated Scope " & tbFederatedScope.Text & " is used in UserId:" & dupRU.UserId & " " & dupRU.UserName & ". It must be unique.")
                                            End If
                                        End If
                                    End If
                                End If
                                If Me.uPage.IsValid And tbFederatedEntity IsNot Nothing Then

                                    Dim vw As New DataView(RemoteUser.RemoteUserAutoLogon, "RemoteUserAutoLogonId=" & AutoDetailsId, "", DataViewRowState.CurrentRows)
                                    If AutoDetailsId = 0 And vw.Count = 0 Then 'This is the new row and has been populated so add to table
                                        Dim newRow As DataRow = RemoteUser.RemoteUserAutoLogon.NewRow
                                        newRow("RemoteUserAutoLogonId") = 999999999
                                        newRow("UserId") = RemoteUser.UserId  '' Me.RemoteUser.UserId
                                        newRow("FederatedEntity") = tbFederatedEntity.Text
                                        newRow("FederatedScope") = tbFederatedScope.Text
                                        newRow("IsFederatedLinkRequired") = chkIsFederatedLinkRequired.Checked
                                        newRow("Notes") = tbNotes.Text
                                        RemoteUser.RemoteUserAutoLogon.Rows.Add(newRow)
                                    Else
                                        vw(0)("FederatedEntity") = tbFederatedEntity.Text
                                        vw(0)("FederatedScope") = tbFederatedScope.Text
                                        vw(0)("IsFederatedLinkRequired") = chkIsFederatedLinkRequired.Checked
                                        vw(0)("Notes") = tbNotes.Text
                                    End If
                                End If
                        End Select
                        Dim chkIsActive As CheckBox = RemoteUserAutoLogonTable.FindControl(AutoDetailsId & "IsActive")
                        Dim vw2 As New DataView(RemoteUser.RemoteUserAutoLogon, "RemoteUserAutoLogonId=" & AutoDetailsId, "", DataViewRowState.CurrentRows)
                        vw2(0)("AutoLogonStatus") = IIf(chkIsActive.Checked, "Active", "InActive")

                    End If
                Next
        End Select

        If Me.AuthorityLevel.SelectedValue = "" Then
            uPage.FieldErrorControl(Me.AuthorityLevel, "Authority Level Is mandatory")
        End If
        If Me.SubscriberIdForAddTR.Visible Then uPage.DropDownValidateMandatory(Me.SubscriberIdForAdd, "Group (Organisation) Subscriber")
        Select Case pageMode
            Case "Update"
                If RemoteUser.AuthorityLevel = AuthorityLevels.GroupUser Then
                    If Me.AuthorityLevel.SelectedValue <> AuthorityLevels.GroupUser.ToString AndAlso RemoteUser.RemoteUserAutoLogon.Rows.Count > 0 Then
                        uPage.PageError = "You have changed Authority Level from GroupUser, you will need to remove all AutoLogon rows before changing Authority Level from GroupUser"
                    End If
                End If
        End Select
        Return uPage.IsValid
    End Function

    Sub SaveRecord()
        '******************************************************
        'Description:	Save the record either by updating
        '******************************************************
        Dim saveMessage As String = ""
        Try
            Select Case pageMode
                Case "Add"
                    'Add new RemoteUser
                    Me.RemoteUser.AddNew(Me.EmailAddress.Text.Trim,
                                           [Enum].Parse(GetType(AuthorityLevels), Me.AuthorityLevel.SelectedValue),
                                            Me.UserFullName.Text.Trim)
                    If Me.SubscriberIdForAddTR.Visible Then
                        RemoteUser.AddRights(RightsTypes.Subscriber, Me.SubscriberIdForAdd.SelectedValue)
                    ElseIf Request.QueryString("SubscriberId") <> "" Then
                        RemoteUser.AddRights(RightsTypes.Subscriber, Request.QueryString("SubscriberId"))
                    End If
                    Me.UserId.Text = Me.RemoteUser.UserId

                Case "Update"

                    If RemoteUser.EmailAddress <> Me.EmailAddress.Text.Trim Then
                        RemoteUser.RemoteUserRow("OldEmailAddress") = Me.RemoteUser.EmailAddress
                    End If
                    Me.uPage.PopulateDataRowFromPageFields(Me.RemoteUser.RemoteUserRow)
                    Me.RemoteUser.Save()

            End Select

        Catch ex As Exception
            If ex.InnerException Is Nothing Then
                uPage.PageError = "Save Failed:" & ex.Message
            Else
                uPage.PageError = "Save Failed:" & ex.Message & IIf(uPage.db.ShowFullError, ex.InnerException.Message, "")
            End If
        End Try

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSetClass") = Me.RemoteUser.MainDataset
        PageSetup()

        uPage.PagePreRender()
    End Sub

    Private Sub BackBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        Response.Redirect("../pages/pg060UserSelect.aspx")
    End Sub

    Sub BuildUserRightsGridHTML()
        '******************************************************
        'Description:	Builds and Displays User Rights Grid
        '******************************************************
        Select Case pageMode
            Case "Update"
                Dim strHtml As String = Nothing
                Dim strQuery As String = Nothing
                For Each row As DataRow In RemoteUser.RemoteUserRights.Rows
                    If Not row.RowState = DataRowState.Deleted Then
                        Dim tr As New HtmlTableRow
                        Dim td As New HtmlTableCell
                        strHtml += "<tr>"
                        If Me.uPage.UserSession.AuthorityLevel = AuthorityLevels.SuperCompanyAdmins _
                            And RemoteUser.AuthorityLevel <> AuthorityLevels.IndividualSubscriber Then
                            td.InnerHtml = "<span Class="" lnkMaintNew""><a href='javascript:ConfirmSubmitCommandData(""Are you sure you want to delete this record?"",""Delete" & row.Item("UserId") & "," & row.Item("RightsType") & "," & row.Item("RightsToId") _
                                        & """)' Title='Delete User Right record '><span class=hyperLinkButtonText>Delete</span></a></span>"

                        End If
                        tr.Cells.Add(td)
                        td = New HtmlTableCell
                        td.InnerHtml = "<p class="" fldView"">" & row.Item("RightsType") & "</p>"
                        tr.Cells.Add(td)
                        td = New HtmlTableCell
                        Select Case row.Item("RightsType")
                            Case "Subscriber"
                                td.InnerHtml = "<a href="" pg111SubscriberDisplay.aspx?SubscriberId=" & row.Item("RightsToId") _
                                                     & """>" _
                                                    & "<p class="" fldView"">" & row.Item("RightsToId") & "</a></p>"
                            Case Else
                                td.InnerHtml = "<p class="" fldView"">" & row.Item("RightsToId") & "</p>"
                        End Select
                        tr.Cells.Add(td)
                        td = New HtmlTableCell
                        td.InnerHtml = "<p class="" fldView"">" & uPage.StdCode.DLookup(row.Item("RightsType") & "Name", row.Item("RightsType"), row.Item("RightsType") & "Id=" & row.Item("RightsToId"), uPage.PrimaryConnection)
                        tr.Cells.Add(td)
                        Me.UserRightsTable.Rows.Add(tr)
                    End If
                Next
        End Select
    End Sub

    Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        Try
            If IsPageValidForStatus() Then

                SaveRecord()

            End If
        Catch ex As Exception
            Me.uPage.PageError = "Save  failed " & ex.Message

        End Try
        If Me.uPage.IsValid Then
            Select Case pageMode
                Case "Add"
                    Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=This record has been successfully Added and can now be completed by adding user rights&UserId=" & Me.UserId.Text)
                Case Else
                    Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=Record Saved&UserId=" & Me.UserId.Text)
            End Select
        End If
    End Sub
    Private Sub CancelBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelBtn.Click
        Select Case pageMode
            Case "Add"
                Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Add")
            Case Else
                Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&UserId=" & Me.UserId.Text)
        End Select
    End Sub
    Private Sub AddNewUserRightsBtnBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddNewUserRightsBtn.Click
        'Add New Line to Grid
        If IsPageValidForStatus(validatorStates.AddRights) Then
            RemoteUser.AddRights([Enum].Parse(GetType(RightsTypes), Me.NewRightsType.SelectedValue), Me.NewRightsTo.Text)
            Me.NewRightsType.ClearSelection()
            Me.NewRightsTo.Text = Nothing
            SaveRecord()
        End If
        If Me.uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=Record Saved&UserId=" & Me.UserId.Text)
        End If
    End Sub

    Sub DeleteUserRightsLineRecord(ByVal locKey As String)
        Dim rowKeys As String() = locKey.Split(New String() {","}, StringSplitOptions.None)

        For Each row As DataRow In RemoteUser.RemoteUserRights.Rows
            If row.Item("UserId") = rowKeys(0) _
                And row.Item("RightsType") = rowKeys(1) _
                And row.Item("RightsToId") = rowKeys(2) Then
                '21/10/20   Julian Gates    SIR5099 - Update Last Updated fields before delete to fix audit log
                row("LastUpdatedDateTime") = Now()
                row("LastUpdatedByUserId") = uPage.UserSession.UserName20
                Me.RemoteUser.Save()
                row.Delete()
                Exit For
            End If
        Next

        Me.txtCommandData.Value = ""
        SaveRecord()
        If Me.uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=Record Saved&UserId=" & Me.UserId.Text)
        End If
    End Sub

    Sub DeleteRemoteUserAutoLogonLineRecord(ByVal locKey As String)
        For Each row As DataRow In RemoteUser.RemoteUserAutoLogon.Rows
            If row.Item("RemoteUserAutoLogonId") = locKey Then
                row("LastUpdatedDateTime") = Now()
                row("LastUpdatedByUserId") = uPage.UserSession.UserName20
                Me.RemoteUser.Save()
                row.Delete()
                Exit For
            End If
        Next
        Me.txtCommandData.Value = ""
        SaveRecord()
        If Me.uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=Remote User Auto Logon row deleted&UserId=" & Me.UserId.Text)
        End If
    End Sub


    Private Sub SendActivationEmailBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SendActivationEmailBtn.Click
        Try
            'Send Activation email
            If IsPageValidForStatus() Then
                Me.SaveRecord()
                '26/10/22   James Woosnam   SIR5582 - If email is being sent by a someone who is not the user then never add session 
                Me.RemoteUser.ResetPasswordAndEmail(NeverAddSessionToQueryString:=True)
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try

        If uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsgPassword has been reset and email sent has been sent to user&UserId=" & Me.UserId.Text)
        End If
    End Sub

    Private Sub MakeInactiveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MakeInactiveBtn.Click
        If IsPageValidForStatus(validatorStates.MakeInActive) Then
            Me.UserStatus.Text = UserStates.InActive.ToString
            SaveRecord()
        End If
        If uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsgPassword has been reset and email sent has been sent to user&UserId=" & Me.UserId.Text)
        End If
    End Sub
    Private Sub MakeActiveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MakeActiveBtn.Click
        If IsPageValidForStatus(validatorStates.MakeActive) Then
            Me.UserStatus.Text = UserStates.Active.ToString
            '26/10/22   James Woosnam   If email is being sent by a someone who is not the user then never add session 
            RemoteUser.ResetPasswordAndEmail(NeverAddSessionToQueryString:=True)
            RemoteUser.Save()
            Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=Record Saved and Password Email Sent&UserId=" & Me.UserId.Text)

        End If
    End Sub
    Private Sub DirectMakeActiveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DirectMakeActiveBtn.Click
        If IsPageValidForStatus(validatorStates.MakeActive) Then
            Me.UserStatus.Text = UserStates.Active.ToString
            SaveRecord()
            Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=Record Saved&UserId=" & Me.UserId.Text)
        End If
    End Sub
    Private Sub ResetPasswordBtn_Click(sender As Object, e As EventArgs) Handles ResetPasswordBtn.Click
        Try
            Dim msg As String = ""
            If Not Me.RemoteUser.IsValidPassword(Me.NewPassword.Text, msg) Then
                uPage.FieldErrorControl(Me.NewPassword, msg)
            End If
            If Me.uPage.IsValid Then
                Me.RemoteUser.SetPassword(Me.NewPassword.Text)
                Me.RemoteUser.Save()
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try

        If uPage.IsValid Then Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=The password has been reset&UserId=" & Me.UserId.Text)
    End Sub

    Private Sub RevertToOldPasswordBtn_Click(sender As Object, e As EventArgs) Handles RevertToOldPasswordBtn.Click
        Dim dt As String = CDate(uPage.db.IsDBNull(RemoteUser.RemoteUserRow("OldPasswordFromDateTime"), "01-jan-1900")).ToString("dd-MMM-yyyy")
        Try
            If Me.uPage.IsValid Then
                Me.RemoteUser.RestoreOldPassword()
                Me.RemoteUser.Save()
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
        If uPage.IsValid Then Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=The password has been reverted to the one before " & dt & "&UserId=" & Me.UserId.Text)
    End Sub

    Private Sub MakeActiveResetPasswordBtn_Click(sender As Object, e As EventArgs) Handles MakeActiveResetPasswordBtn.Click
        Dim dt As String = CDate(uPage.db.IsDBNull(RemoteUser.RemoteUserRow("OldPasswordFromDateTime"), "01-jan-1900")).ToString("dd-MMM-yyyy")
        Try
            If Me.uPage.IsValid Then
                Me.RemoteUser.RestoreOldPassword()
                Me.RemoteUser.UserStatus = UserStates.Active
                Me.RemoteUser.Save()
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
        If uPage.IsValid Then Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=The user has been made Active and password has been reverted to the one before " & dt & "&UserId=" & Me.UserId.Text)
    End Sub
    Private Sub AddNewAutoLogon_Click(sender As Object, e As EventArgs) Handles AddNewAutoLogon.Click
        Try
            RemoteUser.AddAutoLogon(Me.NewAutoLogonType.SelectedValue) '
            AddRemoteUserAutoLogonRow(Me.RemoteUser.RemoteUserAutoLogon.Rows(RemoteUser.RemoteUserAutoLogon.Rows.Count - 1))

        Catch ex As Exception
            uPage.PageError = "AddNewAutoLogon_Click failed:" & ex.Message
        End Try
    End Sub
    '23/9/20    Julian Gates    SIR5043 - Add BuildRemoteUserAutoLogon
    Sub BuildRemoteUserAutoLogon()
        '******************************************************
        'Description:	Builds and Displays Remote User Auto Logon Details Grid
        '******************************************************

        For Each row As DataRow In RemoteUser.RemoteUserAutoLogon.Rows
            AddRemoteUserAutoLogonRow(row)
        Next
    End Sub
    Sub AddRemoteUserAutoLogonRow(row As DataRow)
        Dim AutoLogonType As BusinessLogic.RemoteUser.AutoLogonTypes = [Enum].Parse(GetType(BusinessLogic.RemoteUser.AutoLogonTypes), row("AutoLogonType"))
        Dim tb As New TextBox
        Dim tRow As New WebControls.TableRow
        Dim RowKey As String = row("RemoteUserAutoLogonId")
        tRow.ID = RowKey & "ROW"
        Dim cell As New WebControls.TableCell
        cell.ID = RowKey & "AutoLogonType"
        cell.Text = AutoLogonType.ToString
        tRow.Cells.Add(cell)

        cell = New TableCell
        Dim cb As New CheckBox
        cb.ID = RowKey & "IsActive"
        If Not Me.Page.IsPostBack Then
            cb.Checked = uPage.db.IsDBNull(row("AutoLogonStatus"), "InActive") = "Active"
            cb.EnableViewState = True
        End If
        cb.CssClass = "fldEntry"
        cell.Controls.Add(cb)

        tRow.Cells.Add(cell)
        tRow.Cells.Add(GetTextBoxCell("MinIPAddress", RowKey, row, 100))
        tRow.Cells.Add(GetTextBoxCell("MaxIPAddress", RowKey, row, 100))
        tRow.Cells.Add(GetTextBoxCell("ReferrerURL", RowKey, row, 300))
        tRow.Cells.Add(GetTextBoxCell("FederatedEntity", RowKey, row, 300))
        tRow.Cells.Add(GetTextBoxCell("FederatedScope", RowKey, row, 75))
        If AutoLogonType = AutoLogonTypes.Federated Then
            cell = New TableCell
            cb = New CheckBox
            cb.ID = RowKey & "IsFederatedLinkRequired"
            If Not Me.Page.IsPostBack Then
                cb.Checked = uPage.db.IsDBNull(row("IsFederatedLinkRequired"), False)
                cb.EnableViewState = True
            End If
            cb.CssClass = "fldEntry"
            cell.Controls.Add(cb)
            tRow.Cells.Add(cell)
        Else
            tRow.Cells.Add(New TableCell)

        End If


        tRow.Cells.Add(GetTextBoxCell("Notes", RowKey, row, 0))
        cell = New TableCell()
        If uPage.db.IsDBNull(row("RemoteUserAutoLogonId"), "-1") = "-1" Then
            cell.Text = ""
        Else
            Dim hLink As New HyperLink
            hLink.NavigateUrl = "javascript:ConfirmSubmitCommandData(""Are you sure you want to delete remote user auto logon row?"",""DeleteRUAL" & row("RemoteUserAutoLogonId") & """)"
            hLink.ToolTip = "Delete this Record"
            hLink.Text = "<img src='../images/deleteBtn.gif' alt='Delete' ></img>"
            cell.Controls.Add(hLink)
        End If
        tRow.Cells.Add(cell)
        Me.RemoteUserAutoLogonTable.Rows.Add(tRow)
    End Sub
    Function GetTextBoxCell(FieldName As String, RowKey As String, row As DataRow, BoxWidth As Integer) As TableCell
        Dim cell As New WebControls.TableCell
        'if New leave cell blank
        If uPage.db.IsDBNull(row(FieldName)) Then
            cell.Text = ""
        Else
            Dim tb As New TextBox

            cell = New WebControls.TableCell
            tb = New WebControls.TextBox

            tb.ID = RowKey & FieldName
            If Not Me.Page.IsPostBack Then
                tb.Text = row(FieldName)
                tb.EnableViewState = True
            End If
            If BoxWidth = 0 Then
                BoxWidth = tb.Text.Length * 10
                If BoxWidth < 100 Then BoxWidth = 100
            End If
            tb.Width = BoxWidth
            tb.CssClass = "fldEntry"
            cell.Controls.Add(tb)
        End If
        Return cell

    End Function

    Private Sub ClearAutoLogonDetailsBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearAutoLogonDetailsBtn.Click
        Try
            If IsPageValidForStatus() Then
                Me.RemoteUser.RemoteUserRow("FederatedPersonId") = System.DBNull.Value
                Me.RemoteUser.RemoteUserRow("LastLoggedInMethod") = System.DBNull.Value
                Me.RemoteUser.RemoteUserRow("LastAutoLoginGroupUserId") = System.DBNull.Value
                '20/04/21   Julian Gates    SIR5224 - Add LastAutoLoginRefreshDateTime
                Me.RemoteUser.RemoteUserRow("LastAutoLoginRefreshDateTime") = System.DBNull.Value
                RemoteUser.ExpireAllSessions()
                RemoteUser.Save()
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
        If uPage.IsValid Then Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=Record Saved, Logons Details have been cleared&UserId=" & Me.UserId.Text)
    End Sub

    Private Function GetAutoLoginPeriodDetails(ByVal AutoLogonStartDate As String, ByVal AutoLogonPeriod As Integer) As String
        Dim StartDate As DateTime = Convert.ToDateTime(AutoLogonStartDate)
        Dim EndDate As DateTime = StartDate.AddDays(AutoLogonPeriod)
        Dim CurrentDate As DateTime = System.DateTime.Now
        Try
            Dim days As Long = DateDiff("d", CurrentDate, EndDate)
            Dim hours As Long = DateDiff("h", CurrentDate, EndDate)

            If days > 0 Then
                Return AutoLogonStartDate & " this user's auto logon will end in <b>" & days.ToString & "</b> day(s) on the " & Convert.ToDateTime(EndDate)
            ElseIf days <= 0 Then
                If hours <= 24 And hours > 0 Then
                    Return AutoLogonStartDate & " this user's auto logon will end in <b>" & hours.ToString & "</b> hours on the " & Convert.ToDateTime(EndDate)
                ElseIf hours < 0 Then
                    Return "Auto logon last timed out on " & Convert.ToDateTime(EndDate)
                End If
            End If
        Catch ex As Exception
            Return AutoLogonStartDate
        End Try
    End Function

    Private Sub ExpireAllSessionsBtn_Click(sender As Object, e As EventArgs) Handles ExpireAllSessionsBtn.Click
        '17/1/22    James Woosnam   SIR5389 - For UserGroups add button to logout all associated sessions
        Try
            If IsPageValidForStatus() Then
                Me.RemoteUser.ExpireAllSessions()
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
        If uPage.IsValid Then Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=All associated sessions have been Expired&UserId=" & Me.UserId.Text)
    End Sub
End Class
