﻿Imports System.Data.SqlClient
Imports System.Data
Imports BusinessLogic.SubscriberImportBatch

'Modification History
'23/10/2019 Julian Gates  Initial version
'30/1/20    Julian Gates    SIR4996 - Change Page Title to Subscription Renewal or Addition
'30/1/20    Julian Gates    SIR4996 - Hide Rejected batches In Other Subscriber Order Batch list
'30/1/20    Julian Gates    SIR4996 - Remove "renewal" where it is used before "file - Change "Import" to "Order" in the page text
'12/02/20   Julian Gates    SIR5015 - Add CompanyId to the end of the SubscriberImportBlank template name and make some page text changes.
'26/03/20   Julian Gates    SIR5050 - Various text and page modifications.
'31/03/20   julian Gates    SIR5050 - Add additional page text modifications.
'09/02/23   Julian Gates    SIR5627 - Change page to show Template download buttons and download uploaded file button.

Partial Class Pages_pg462SubscriberRenewals
    Inherits System.Web.UI.Page
    Enum PageModes
        DefaultView
        AddBatchImport
        NoImportBatches
    End Enum
    Enum Company
        IJP = 1
        PEP = 2
    End Enum
    Property PageMode As PageModes
        Get
            If ViewState("PageMode") Is Nothing Then ViewState("PageMode") = PageModes.DefaultView
            Return ViewState("PageMode")
        End Get
        Set(value As PageModes)
            ViewState("PageMode") = value
        End Set
    End Property
    Private _SubscriberImportBatch As BusinessLogic.SubscriberImportBatch = Nothing
    Public Property SubscriberImportBatch() As BusinessLogic.SubscriberImportBatch
        Get
            If Me._SubscriberImportBatch Is Nothing Then
                If ViewState("SubscriberImportBatchId") Is Nothing Then
                    Me._SubscriberImportBatch = New BusinessLogic.SubscriberImportBatch(Me.Master.db, Me.Master.UserSession)
                Else
                    Me._SubscriberImportBatch = New BusinessLogic.SubscriberImportBatch(ViewState("SubscriberImportBatchId"), Me.Master.db, Me.Master.UserSession)
                End If
            End If
            Return Me._SubscriberImportBatch
        End Get
        Set(ByVal value As BusinessLogic.SubscriberImportBatch)
            Me._SubscriberImportBatch = value
        End Set
    End Property
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Master.Initilise("Home", "02a", "")

        Select Case Me.Master.UserSession.AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.GroupRenewer, BusinessLogic.UserSession.AuthorityLevels.GroupAdmins
                'all fine
            Case Else
                Response.Redirect("pg070Logon.aspx")
        End Select

        If Page.IsPostBack Then

            If Me.txtCommandData.Value = "Upload" Then
                Upload()
            End If
        Else
            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            If Request.QueryString("SubscriberImportBatchId") <> "" Then
                ViewState("SubscriberImportBatchId") = Request.QueryString("SubscriberImportBatchId")
            End If
            ReadRecord()
            If Me.tImportBatches.Rows.Count = 0 Then Me.PageMode = PageModes.NoImportBatches
        End If
    End Sub
    Sub PageSetup()
        '30/1/20    Julian Gates    SIR4996 - Change Page Title to Subscription Renewal or Addition
        Me.Master.PageTitle = Me.Master.UserSession.Data("GroupSubscriberName") & " - " & "Subscription Renewal or Addition"
        Me.ConfirmationRow.Visible = False
        Me.RenewalFileNotAvailableMsgRow.Visible = False
        Me.SubscriberRenewalDetailsRow.Visible = False
        Me.DownloadRow.Visible = False
        Me.UploadRow.Visible = False
        Me.InfoMsgTr.Visible = Me.InfoMsg.Text <> ""
        Me.BlankAddPnl.Visible = True
        Me.BatchDetailsPnl.Visible = Me.SubscriberImportBatch.SubscriberImportBatchId <> Nothing And Me.PageMode <> PageModes.AddBatchImport
        Me.RenewalFileNotAvailableMsgRow.Visible = Me.SubscriberImportBatch.SubscriberImportBatchId = Nothing
        Me.GetNewBatchTbl.Visible = Me.PageMode <> PageModes.AddBatchImport
        'Me.AddNewImportBatchTbl.Visible = Me.PageMode = PageModes.AddBatchImport
        BuildRenewalListTable()
        Me.BatchListPnl.Visible = Me.tImportBatches.Rows.Count > 1 And Me.PageMode <> PageModes.AddBatchImport
        If Me.SubscriberImportBatch.SubscriberImportBatchId <> Nothing Then
            Me.SubscriberRenewalDetailsRow.Visible = True
            Me.ConfirmationFileDownloadTr.Visible = Me.Master.db.IsDBNull(Me.SubscriberImportBatch.SubscriberImportBatchRow("ConfirmationFileStoreId"), Nothing) <> Nothing
            Me.MessagesTable.Visible = False
            Me.BatchDetailsHdr.InnerText = Me.SubscriberImportBatch.SubscriberImportBatchRow("SubscriberImportBatchName")

            Select Case Me.SubscriberImportBatch.SubscriberImportBatchStatus
                Case SubscriberImportBatchStates.Available
                    Me.DownloadRow.Visible = True
                    Me.UploadRow.Visible = False
                    Me.ConfirmationRow.Visible = False
                Case SubscriberImportBatchStates.Downloaded
                    Me.DownloadRow.Visible = True
                    Me.UploadRow.Visible = True
                    Me.ConfirmationRow.Visible = False
                Case SubscriberImportBatchStates.Uploading
                    Me.DownloadRow.Visible = True
                    Me.UploadRow.Visible = True
                    BuildMessageListList(Me.SubscriberImportBatch.ErrorMessages, MessageTypes.ErrorMessage)
                    BuildMessageListList(Me.SubscriberImportBatch.WarningMessages, MessageTypes.WarningMessage)
                    Me.ConfirmationRow.Visible = Me.SubscriberImportBatch.WarningMessages <> ""
                Case SubscriberImportBatchStates.Uploaded
                    Me.DownloadRow.Visible = True
                    Me.UploadRow.Visible = True
                Case Else
                    Me.DownloadRow.Visible = False
                    Me.UploadRow.Visible = False


            End Select
        End If
    End Sub
    Function RightsToSubscriberId() As Integer
        Return Me.Master.db.DLookup("RightsToId", "RemoteUserRights", "Userid = " & Me.Master.UserSession.UserId & " AND RightsType = 'Subscriber' ")
    End Function

    Dim _tImportBatches As DataTable
    ReadOnly Property ImportBatchesRow As DataRow
        Get
            For Each r As DataRow In tImportBatches.Rows
                If r("SubscriberImportBatchId") = Me.SubscriberImportBatch.SubscriberImportBatchId Then
                    Return r
                End If
            Next
            Return Nothing
        End Get
    End Property
    '30/1/20    SIR4996 - Add AND srb.SubscriberImportBatchStatus <> 'Rejected' to SQL below
    ReadOnly Property tImportBatches As DataTable
        Get
            If _tImportBatches Is Nothing Then
                Dim sql As String = ""
                sql = "SELECT srb.SubscriberImportBatchId"
                sql += "    ,srb.SubscriberImportBatchName"
                sql += "    ,c.CompanyName"
                sql += "    ,c.CompanyId"
                sql += "    ,srb.SubscriberImportBatchStatus"
                sql += "    ,LastActivity= MAX(srbl.LogDateTime)"
                sql += " FROM SubscriberImportBatch srb"
                sql += "     LEFT JOIN SubscriberImportBatchLog srbl"
                sql += "     On srbl.SubscriberImportBatchId = srb.SubscriberImportBatchId"
                sql += "     INNER JOIN Company c"
                sql += "     On c.Companyid = srb.Companyid"
                sql += " WHERE srb.BlockSubscriberId = " & RightsToSubscriberId()
                sql += " AND srbl.LogDateTime > DATEADD(YEAR,-2,GETDATE())"
                sql += " AND srb.SubscriberImportBatchStatus <> 'Rejected'"
                sql += " GROUP BY srb.SubscriberImportBatchId"
                sql += "    ,srb.SubscriberImportBatchName"
                sql += "    ,c.CompanyName"
                sql += "    ,c.CompanyId"
                sql += "    ,srb.SubscriberImportBatchStatus"
                sql += " ORDER BY c.CompanyId Desc"
                sql += " , srb.SubscriberImportBatchId desc"
                _tImportBatches = Me.Master.db.GetDataTableFromSQL(sql)
            End If
            Return _tImportBatches
        End Get
    End Property

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        If Me.tImportBatches.Rows.Count > 0 Then
            If ViewState("SubscriberImportBatchId") Is Nothing Then
                ViewState("SubscriberImportBatchId") = Me.tImportBatches.Rows(0)("SubscriberImportBatchId")
            End If

            Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.ImportBatchesRow)
            Me.ConfirmationFileDownloadLink.NavigateUrl = "pg100HomeAdmin.aspx?FileStoreId=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("ConfirmationFileStoreId") & "&" & Me.Master.UserSession.QueryString
        End If
    End Sub
    Sub BuildRenewalListTable()
        Try
            Dim lastCompanyNAme As String = Nothing
            If tImportBatches.Rows.Count > 1 Then
                For Each row As DataRow In tImportBatches.Rows
                    Dim tr As New TableRow
                    Dim td As TableCell = Nothing
                    td = New TableCell
                    If lastCompanyNAme <> row("CompanyName") Then
                        td.Text = row("CompanyName")
                        td.ColumnSpan = 4
                        tr.Cells.Add(td)
                        Me.RenewalListTable.Rows.Add(tr)
                        tr = New TableRow
                        td = New TableCell
                    End If
                    td.Width = 40
                    tr.Cells.Add(td)

                    td = New TableCell
                    Dim hp As New HyperLink
                    hp.NavigateUrl = Request.ServerVariables("Path_Info") & "?SubscriberImportBatchId=" & row("SubscriberImportBatchId") & "&" & Me.Master.UserSession.QueryString
                    hp.Text = row("SubscriberImportBatchName")
                    hp.CssClass = "productLink"
                    td.Controls.Add(hp)
                    tr.Cells.Add(td)

                    td = New TableCell
                    td.Text = CDate(row("LastActivity")).ToString("dd-MMM-yy")
                    td.Width = 60
                    tr.Cells.Add(td)
                    Me.RenewalListTable.Rows.Add(tr)
                    lastCompanyNAme = row("CompanyName")

                    td = New TableCell
                    td.Text = row("SubscriberImportBatchStatus")
                    tr.Cells.Add(td)
                    Me.RenewalListTable.Rows.Add(tr)
                    lastCompanyNAme = row("CompanyName")
                Next
                Me.BatchListPnl.Visible = True
            Else
                Me.BatchListPnl.Visible = False
            End If

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured. Please contact support", ex))
        End Try
    End Sub
    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub
    Private Sub DownloadBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DownloadBtn.Click
        Try
            If IsNumeric(Me.SubscriberImportBatch.SubscriberImportBatchRow("RenewalFileStoreId")) Then
                SubscriberImportBatch.UpdateStatus(SubscriberImportBatch.SubscriberImportBatchStates.Downloaded, Nothing, Nothing)
                Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.SubscriberImportBatch.SubscriberImportBatchRow)
                PageSetup()
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured. Please contact support", ex))
        End Try
        If Me.Master.WebForm.IsValid Then
            Response.Redirect("pg100HomeAdmin.aspx?FileStoreId=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("RenewalFileStoreId") & "&" & Me.Master.UserSession.QueryString)
        End If
    End Sub
    Private Sub DownloadUploadedFileBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DownloadUploadedFile.Click
        Try
            If IsNumeric(Me.SubscriberImportBatch.SubscriberImportBatchRow("RenewalFileStoreId")) Then
                SubscriberImportBatch.UpdateStatus(SubscriberImportBatch.SubscriberImportBatchStates.Uploaded, Nothing, Nothing)
                Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.SubscriberImportBatch.SubscriberImportBatchRow)
                PageSetup()
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured. Please contact support", ex))
        End Try
        If Me.Master.WebForm.IsValid Then
            Response.Redirect("pg100HomeAdmin.aspx?FileStoreId=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("RenewalFileStoreId") & "&" & Me.Master.UserSession.QueryString)
        End If
    End Sub
    Sub Upload()
        Try
            If Me.FileToUpload.HasFile Then
                Dim FileStore As New BusinessLogic.FileStore(Me.Master.db)
                FileStore.AddNewFile(FileToUpload.FileBytes, FileToUpload.FileName, "Uploaded by block user")
                ViewState("FileStoreId") = FileStore.FileStoreId
                Me.SubscriberImportBatch.UpdateStatus(BusinessLogic.SubscriberImportBatch.SubscriberImportBatchStates.Uploading, Nothing, Nothing)
                CompleteUpload(False, FileStore)
            Else
                Me.Master.WebForm.AddPageError("No file selected. Please Browse And Select your file.")
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured. Please contact support", ex))
        End Try
        Me.txtCommandData.Value = ""
    End Sub
    Sub CompleteUpload(IsConfirmed As Boolean, FileStore As BusinessLogic.FileStore)

        Me.SubscriberImportBatch.ValidateFile(FileStore)

        If Me.SubscriberImportBatch.ErrorMessages = "" Then
            Me.SubscriberImportBatch.SubscriberImportBatchRow("UploadedFileStoreId") = FileStore.FileStoreId
            If (Me.SubscriberImportBatch.WarningMessages = "" Or IsConfirmed) Then
                Me.SubscriberImportBatch.UpdateStatus(SubscriberImportBatchStates.Uploaded, Nothing, Nothing)
                Try
                    'Send email to Company informing of new upload
                    Me.SendRenewerUploadNotificationEmail()
                Catch ex As Exception
                    Try
                        Dim email As New BusinessLogic.Email(Master.db)
                        email.SendErrorEmail("SendRenewerUploadNotificationEmail in Pages_pg462SubscriberRenewals.CompleteUpload failed", ex.ToString)
                    Catch ex2 As Exception
                    End Try
                End Try
                Me.Master.WebForm.AddInfoMessage("Your file has been successfully Uploaded")
            End If
            Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.SubscriberImportBatch.SubscriberImportBatchRow)
        End If

    End Sub
    Private Sub ConfirmBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConfirmBtn.Click
        Try
            Dim filestore As New BusinessLogic.FileStore(ViewState("FileStoreId"), Me.Master.db)
            CompleteUpload(True, filestore)
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured. Please contact support", ex))
        End Try
    End Sub

    Sub BuildMessageListList(ByRef Messages As String, MessageType As MessageTypes)
        '09/09/22   Julian Gates   Limit Messages to only 2000 to stop page timimg out
        Try
            Dim tb As Table = Nothing
            Dim tr As TableRow = Nothing
            Dim style As String = ""
            Select Case MessageType
                Case MessageTypes.ErrorMessage
                    tb = Me.FileErrorList
                    style = "errMsgNoMargin"
                    tr = Me.ErrorsTableRow
                Case MessageTypes.WarningMessage
                    tb = Me.FileWarningList
                    style = "WaringMsgNoMargin"
                    tr = Me.WarningTableRow
            End Select
            If Messages <> Nothing Then
                If Messages.Length > 2000 Then Messages = Left(Messages, 2000)
                Dim tRow As New TableRow()
                Dim tCell As New TableCell()
                Dim lines As String() = Messages.Split(vbCrLf)
                Dim linesToShow As Integer

                tCell.Text = "<span Class='" & style & "'>"
                linesToShow = lines.Length - 1
                Dim i As Integer = 0
                Do While i < linesToShow
                    tCell.Text += " - " & lines(i) & "<br>"
                    i += 1
                Loop

                tCell.Text += "</span>"

                tRow.Cells.Add(tCell)
                tb.Rows.Add(tRow)
                tr.Visible = True
                Me.MessagesTable.Visible = True

            Else
                tr.Visible = False
            End If

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured. Please contact support", ex))
        End Try
    End Sub

    Private Sub RefreshPageBtn_Click(sender As Object, e As EventArgs) Handles RefreshPageBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?" & Me.Master.UserSession.QueryString)
    End Sub
    Private Sub GetNewPEPBatchBtn_Click(sender As Object, e As EventArgs) Handles GetNewPEPBatchBtn.Click
        AddBatchWithCriteria(Company.PEP)
    End Sub
    Private Sub GetNewIJPBatchBtn_Click(sender As Object, e As EventArgs) Handles GetNewIJPBatchBtn.Click
        AddBatchWithCriteria(Company.IJP)
    End Sub

    Sub AddBatchWithCriteria(ByVal CompanyId As Integer)
        Try
            '26/03/20   Julian Gates    SIR5050 - Remove Order from SubscriberImportBatchNameForAdd text.
            Dim SubscriberImportBatchNameForAdd As String = Me.SubscriberImportBatch.GetSubscriberImportBatchNameForAdd(CompanyId,
                                                                                                              RightsToSubscriberId,
                                                                                                              Me.Master.db.DLookup("CompanyShortName", "Company", "CompanyId=" & CompanyId) & " " & Now.ToString("MMM yyyy"))
            If Me.Master.WebForm.IsValid Then
                Dim sql As String = "select * from subscriberImportBatch where subscriberImportBatchName=@BatchName AND BlockSubscriberId=" & RightsToSubscriberId() & " "
                Dim cmd As New SqlClient.SqlCommand(sql, Master.db.DBConnection, Master.db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchName", System.Data.SqlDbType.VarChar, 100, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current _
                                                                             , SubscriberImportBatchNameForAdd))
                If Master.db.GetDataTableFromSQL(cmd).Rows.Count > 0 Then
                    Me.Master.WebForm.AddPageError("This description has already been used for your group, please modify.")
                End If
            End If
            '12/02/20   Julian Gates    SIR5015 - Add CompanyId to the end of the SubscriberImportBlank template name.
            If Me.Master.WebForm.IsValid Then
                Me.SubscriberImportBatch.AddNew(RightsToSubscriberId(), CompanyId, SubscriberImportBatchNameForAdd)
                Dim downloadFileName = "Download for " & SubscriberImportBatchNameForAdd
                Dim fileNameXLSTemplate As New IO.FileInfo(IO.Path.Combine(Me.Master.db.GetParameterValue("ReportTemplateDirectory"), "SubscriberImportBlank" & CompanyId & ".xlsx"))
                Dim wb As SpreadsheetGear.IWorkbook = SpreadsheetGear.Factory.GetWorkbook(fileNameXLSTemplate.FullName)
                Dim memoryStream As New System.IO.MemoryStream()
                wb.SaveToStream(memoryStream, SpreadsheetGear.FileFormat.OpenXMLWorkbook)
                SubscriberImportBatch.UpdateStatus(SubscriberImportBatchStates.Available, memoryStream.ToArray, downloadFileName)
                SubscriberImportBatch.UpdateStatus(SubscriberImportBatchStates.Downloaded, Nothing, Nothing)
                Dim wf As New WebForm(Me)
                Me.PageMode = PageModes.DefaultView
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured. Please contact support", ex))
        End Try
        '7/2/20     James Woosnam   SIR4996 - Open file from filestore and do outside try catch
        If Me.Master.WebForm.IsValid Then
            Response.Redirect("pg100HomeAdmin.aspx?FileStoreId=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("RenewalFileStoreId") & "&" & Me.Master.UserSession.QueryString)
        End If

    End Sub

    Public Sub SendRenewerUploadNotificationEmail()
        Try
            Dim email As New BusinessLogic.Email(Me.Master.db)
            email.Subject = "PaDS Subscriber Renewal Upload Notification"
            email.From = Me.Master.db.GetParameterValue("EmailFromForCompanyId:" & Me.SubscriberImportBatch.SubscriberImportBatchRow("CompanyId"))
            email.SendTo = Me.Master.db.DLookup("Email", "Company", "CompanyId=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("CompanyId"))

            Dim Body As String = ""
            Body = "A new subscriber file has been uploaded for Subscriber Order Batch Id " & Me.SubscriberImportBatch.SubscriberImportBatchRow("SubscriberImportBatchId") & " and Subscriber " & Me.Master.UserSession.Data("GroupSubscriberName") & "."

            email.Body = Body
            email.Send()
        Catch ex As Exception
            Throw New Exception("Renewal Upload Email failed", ex)
        End Try
    End Sub
End Class
