﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'09/04/2020     Julian Gates    Initial Version
'01/07/2021     Julian Gates    SIR5277 - Add UniversalContentRegPtrn update and testing functionality.

Partial Class Pages_pg270ContentSetSelect
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    ReadOnly Property UniversalContentRegPtrnParamValue As String
        Get
            Return uPage.db.GetParameterValue("UniversalContentRegPtrn")
        End Get
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Content Set List", "")
        Me.pageHeaderTitle.Text = "Content Set List"

        If Page.IsPostBack Then

        Else
            Me.UniversalContentRegPtrn.Text = Me.UniversalContentRegPtrnParamValue
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        GridSetup()

    End Sub

    Sub PageSetup()

    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else
                Me.uPage.FieldValidateMandatory(Me.UniversalContentRegPtrn)
        End Select

        Return Me.uPage.IsValid
    End Function

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub GridSetup()
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT cs.ContentSetId" & sCR
            Sql += " ,cs.ContentSetName" & sCR
            Sql += " ,cs.ContentSetStatus" & sCR
            Sql += " ,Journals = dbo.fn275ContentSetSourceDesc(cs.ContentSetId,'Journals')" & sCR
            Sql += " ,Books = dbo.fn275ContentSetSourceDesc(cs.ContentSetId,'Books')" & sCR
            Sql += " ,Videos = dbo.fn275ContentSetSourceDesc(cs.ContentSetId,'Videos')" & sCR
            Sql += " FROM ContentSet cs" & sCR
            'Sql += "    INNER JOIN ContentSetSource css" & sCR
            'Sql += "    ON cs.ContentSetId = css.ContentSetId" & sCR
            Sql += " WHERE 1 = 1" & sCR
            Sql += " ORDER BY cs.ContentSetId" & sCR

            Me.ContentSetDatasource.SelectCommand = Sql
            Me.ContentSetDatasource.DataBind()
            Me.ContentSetGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Protected Sub AddNewBtn_Click(sender As Object, e As EventArgs) Handles AddNewBtn.Click
        Response.Redirect("../Pages/pg271ContentSetMaint.aspx")
    End Sub
    Protected Sub UpdateBtn_Click(sender As Object, e As EventArgs) Handles UpdateBtn.Click
        Try
            If Me.IsPageValidForStatus("") Then
                uPage.db.SetParameterValue("UniversalContentRegPtrn", Me.UniversalContentRegPtrn.Text)
            End If
        Catch ex As Exception
            Me.uPage.PageError = "Update Universal Content Reg Ptrn failed" & ex.Message
        End Try

        If Me.uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=Universal Content Reg Ptrn saved")
        End If
    End Sub
    Protected Sub TestRegPatternBtn_Click(sender As Object, e As EventArgs) Handles TestRegPatternBtn.Click
        Try
            If System.Text.RegularExpressions.Regex.IsMatch(TestDocumentId.Text, Me.UniversalContentRegPtrn.Text) Then
                Me.uPage.PageError = "Value entered " & TestDocumentId.Text & " matches the pattern"
                Me.TestDocumentId.CssClass = "fldEntry"
            Else
                Me.uPage.FieldErrorControl(Me.TestDocumentId, "Value entered " & TestDocumentId.Text & " does Not match the pattern")
            End If
        Catch ex As Exception
            Me.uPage.PageError = "PEPWebUniversalContentAcessRegularExpression:'" & UniversalContentRegPtrnParamValue & "' failed:" & ex.Message
        End Try
    End Sub
End Class
