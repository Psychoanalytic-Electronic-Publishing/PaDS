﻿Public Class LogFile
    '26/9/16    James Woosnam   SIR4184 - Added to support ExecuteCopyECHOLiveDBsToECHOTest
    Dim StartTime As Date = Nothing
    Dim LastLogTime As Date = Nothing
    Public FileNamePrefix As String = Nothing
    Dim LogFileDir As String = Nothing
    Public LogFile As IO.FileInfo = Nothing
    Public NewMessageWithPrefix As String
    Sub New(ByVal LogFileDir As String, FileNamePrefix As String)
        Me.FileNamePrefix = FileNamePrefix
        Me.LogFileDir = LogFileDir
        Me.Initilise()
    End Sub
    Private Sub Initilise()
        Try
            If Me.StartTime = Nothing Then
                Me.StartTime = Now
            End If
            If Me.LastLogTime = Nothing Then
                Me.LastLogTime = Now()
            End If
            Dim logDir As New IO.DirectoryInfo(LogFileDir)
            If Not logDir.Exists Then
                logDir.Create()
            End If
            Dim fileName As String = Me.FileNamePrefix & "_Log_" & StartTime.ToString("yyyy_MM_dd")
            If Me.FileNamePrefix <> "Root" Then
                fileName += StartTime.ToString("_HHmmsss")
            End If
            fileName += ".txt"

            LogFile = New IO.FileInfo(IO.Path.Combine(logDir.FullName, fileName))
            If Not LogFile.Exists Then
                Me.Write("Log File Opened:" & Now.ToString("dd-MMM-yy HH:mm:ss") & ".Prefix:" & Me.FileNamePrefix & ". XXX-YYY XXX - Seconds since file created, YYY - seconds since last log")
            End If
        Catch ex As Exception
            Throw New Exception("LogFile Initilise Failed:" & ex.Message)
        End Try
    End Sub
    Sub Write(ByVal Message As String)
        Dim secsSinceStart As Integer = DateDiff(DateInterval.Second, Me.StartTime, Now())
        Dim secsSinceLast As Integer = DateDiff(DateInterval.Second, Me.LastLogTime, Now())
        NewMessageWithPrefix = secsSinceStart.ToString("000") & "-" & secsSinceLast.ToString("000") & ":   " & Message
        Try

            Dim logFileStream As IO.StreamWriter = New IO.StreamWriter(Me.LogFile.FullName, True)
            Try
                logFileStream.WriteLine(NewMessageWithPrefix)
            Catch ex As Exception
            Finally
                logFileStream.Close()
            End Try
            Me.LastLogTime = Now()
        Catch ex As Exception
            Throw New Exception("LogFile Write Failed:" & ex.Message)
        End Try

    End Sub
End Class
