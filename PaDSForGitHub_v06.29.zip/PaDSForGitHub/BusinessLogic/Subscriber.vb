﻿Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.VisualBasic
'Modification History
'30/3/11   Julian Gates   SIR2401 - Add UpdateExistingOrdersDeliveryAddress to Sub SaveSubscriberAddress
'22/5/11        James Woosnam   HotFix - Open Logs with UserSession
'23/5/11   Julian Gates SIR2436 - Populate CreatedByUserId in add subscriber with webusername when adding new remote subscriber.
'26/5/11   Julian Gates   Add CompanyAccountRow to get correct company account
'5/6/11    James Woosnam   If no CompanyAccount pass back a new row, as this is needed on Order Maint page
'13/6/11   Julian Gates - Add code to SetAddressText to handle Null values
'22/6/11   Julian Gates SIR2459 - Add IsSubscriberValidForOrdering function and add BillingAddressRow property
'23/6/11   Julian Gates - Add trim SaveSubscriberAddress to BuildingStreet parameter to remove any blank spaces
'28/11/11  Julian Gates - Add code to Sub SaveSubscriberAddress to stop truncation error if address rows too long
'24/09/12  Julian Gates  SIR2865 - Add warning for DefaultPostalAddressId in Function IsValidForOrdering
'26/2/13    Julian Gates    SIR3024 - Remove mandatory phone number validation
'03/10/14   Julian Gates    SIR3621 - Add IsReceiveMail to Sub Add
'19/03/15   Julian Gates    SIR3784 - Add IsSpanishIJPESSubscriber property to show Spanish error messages when adding new subscriber for IJP-es product.
'06/10/15   Julian Gates    SIR3784 - Remove County validation.
'30/03/16   Julian Gates    SIR4094 - Change default end date to 31/12/4949 in AddSubscriberAffiliation
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields and validation
'17/09/19   Julian Gates    SIR4915 - Add new MergeSubscriber Sub
'21/11/19   Julian Gates    SIR4942 - Get NewWebUserName from RemoteUser and remove password in SendUserIdChangedEmailOnMerge SQL
'2/12/19    James Woosnam   SIR4951 - Only send email if required
'13/1/20    James Woosnam   SIR4984 - Only add affiliate if not already present
'13/1/20    James Woosnam   SIR4977 - Change IsProposedSubscriber to HasOrIsAProposedSubscriber in SessionData
'16/1/20    James Woosnam   SIR4995 - DeleteOldRedundantAddresses change to update DefaultPostalAddress if redundant address deleted
'17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .
'7/1/21     James Woosnam   SIR5143 - New field IsBillingAddressRequired if false then billing address is no longer required and the fields can be left blank
'22/9/21    James Woosnam   SIR5329 - Only make proposed if possible duplicate found, LastName and first character of first name match
'07/10/21   Julian Gates    SIR5323 - Add RemoteUserRows to show multiple Users.
'21/4/22	Julian Gates	SIR5467 - Add @UserName20 parameter to RejectSubscriber()
'16/8/22    James Woosnam   SIR5518 - Only set New subscribers to proposed if country, last and first name are the same, not just first character of first name. 

Public Class Subscriber
#Region "Class Properties"
    Public MainDataset As New DataSet
    Dim _SubscriberId As Long
    Dim UserSession As UserSession
    Public Property SubscriberId() As Integer
        Get
            If Me._SubscriberId = Nothing Then
                If Me.MainDataset.Tables.Count <> 0 Then
                    Me._SubscriberId = Me.SubscriberRow("SubscriberId")
                End If
            End If
            Return Me._SubscriberId
        End Get
        Set(ByVal Value As Integer)
            _SubscriberId = Value
            'initilise dataset
            '   Me.Initilise()
        End Set
    End Property
    Public Enum SubscriberStates
        Proposed
        Current
        InActive
        Merged
        Rejected
    End Enum


    Public Property SubscriberStatus() As SubscriberStates
        Get
            Return [Enum].Parse(GetType(SubscriberStates), Me.SubscriberRow("SubscriberStatus"))
        End Get
        Set(ByVal value As SubscriberStates)
            Me.SubscriberRow("SubscriberStatus") = value.ToString
        End Set
    End Property
    Private ReadOnly Property Subscriber() As DataTable
        Get
            If Me.MainDataset.Tables("Subscriber") Is Nothing Then
                Me.daSubscriber.Fill(Me.MainDataset, "Subscriber")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("Subscriber").Columns("SubscriberId")}
            Me.MainDataset.Tables("Subscriber").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("Subscriber")
        End Get
    End Property
    Private _daSubscriber As SqlDataAdapter
    Private ReadOnly Property daSubscriber() As SqlDataAdapter
        Get
            If Me._daSubscriber Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM Subscriber"
                sql += " WHERE SubscriberId=" & Me.SubscriberId
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daSubscriber = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daSubscriber)
                _daSubscriber.UpdateCommand = cmdBld.GetUpdateCommand()
                _daSubscriber.InsertCommand = cmdBld.GetInsertCommand()
                _daSubscriber.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daSubscriber.InsertCommand.Transaction = Me.db.DBTransaction
                _daSubscriber.UpdateCommand.Transaction = Me.db.DBTransaction
                _daSubscriber.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daSubscriber
        End Get
    End Property

    Public ReadOnly Property SubscriberRow() As DataRow
        Get
            If Me.Subscriber.Rows.Count = 0 Then
                Me.daSubscriber.Fill(Me.MainDataset.Tables("Subscriber"))
                If Me.Subscriber.Rows.Count = 0 Then
                    Throw New Exception("UserError: SubscriberId:" & Me._SubscriberId & " can't be found")
                End If
            End If
            Return Me.Subscriber.Rows(0)
        End Get
    End Property

    Private Sub Initilise()
        Dim xx As Integer = 0
        MainDataset = New DataSet
        Me._daSubscriber = Nothing
        Me._daSubscriberAddress = Nothing
        Me._daSubscriberAffiliate = Nothing
        Me._daCompanyAccount = Nothing
        xx = Me.Subscriber.Rows.Count
        xx = Me.SubscriberAddress.Rows.Count
        xx = Me.SubscriberAffiliate.Rows.Count
        xx = Me.CompanyAccount.Rows.Count

    End Sub
    Public ReadOnly Property SubscriberName() As String
        Get
            If Me.Subscriber Is Nothing Then
                Return ""
            Else
                Return SubscriberRow("SubscriberName")
            End If
        End Get
    End Property

    Public ReadOnly Property SubscriberAddress() As DataTable
        Get
            If Me.MainDataset.Tables("SubscriberAddress") Is Nothing Then
                daSubscriberAddress.Fill(Me.MainDataset, "SubscriberAddress")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("SubscriberAddress").Columns("SubscriberAddressId")}
            Me.MainDataset.Tables("SubscriberAddress").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("SubscriberAddress")
        End Get
    End Property
    Private _daSubscriberAddress As SqlDataAdapter
    Private ReadOnly Property daSubscriberAddress() As SqlDataAdapter
        Get
            If Me._daSubscriberAddress Is Nothing Then
                Dim sql As String = ""
                sql = "SELECT *"
                sql += " FROM SubscriberAddress"
                sql += " WHERE SubscriberId = " & Me.SubscriberId
                sql += " ORDER BY SubscriberAddressId"
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daSubscriberAddress = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daSubscriberAddress)
                _daSubscriberAddress.UpdateCommand = cmdBld.GetUpdateCommand()
                _daSubscriberAddress.InsertCommand = cmdBld.GetInsertCommand()
                _daSubscriberAddress.DeleteCommand = cmdBld.GetDeleteCommand()

            End If

            If Not Me.db.DBTransaction Is Nothing Then
                _daSubscriberAddress.InsertCommand.Transaction = Me.db.DBTransaction
                _daSubscriberAddress.UpdateCommand.Transaction = Me.db.DBTransaction
                _daSubscriberAddress.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daSubscriberAddress
        End Get
    End Property

    Public Function GetAddressRow(ByVal AddressType As String, Optional ByVal AddressDescription As String = "Main") As DataRow
        For Each row As DataRow In SubscriberAddress.Rows
            If row("AddressType") = AddressType And row("AddressDescription") = AddressDescription Then
                Return row
            End If
        Next
        Return Nothing
    End Function
    Public ReadOnly Property BillingAddressRow As DataRow
        Get
            Dim lAddressRow As DataRow = Me.GetAddressRow("Postal", "Billing")
            If lAddressRow Is Nothing Then
                lAddressRow = Me.GetAddressRow("Postal", "Main")
            End If
            Return lAddressRow
        End Get
    End Property

    Public Function GetAddressText(ByVal AddressType As String, Optional ByVal AddressDescription As String = "Main", Optional ShowId As Boolean = False) As String
        For Each row As DataRow In SubscriberAddress.Rows
            If row("AddressType") = AddressType And row("AddressDescription") = AddressDescription Then
                Return db.IsDBNull(row("AddressText"), "") & IIf(ShowId, "(" & row("SubscriberAddressId") & ")", "")
            End If
        Next
        Return Nothing
    End Function

    '13/6/2011 Julian Gates Add code to SetAddressText to handle Null values
    Public Sub SetAddressText(ByVal AddressType As String, ByVal AddressValue As String, Optional ByVal AddressDescription As String = "Main")
        For Each row As DataRow In SubscriberAddress.Rows
            If row("AddressType") = AddressType And row("AddressDescription") = AddressDescription Then
                If AddressValue <> db.IsDBNull(row("AddressText"), "") Then
                    row("AddressText") = AddressValue
                End If
            End If
        Next
    End Sub

    Public Function IsDefaultAddress(ByVal AddressType As String, Optional ByVal AddressDescription As String = "Main") As Boolean
        For Each row As DataRow In SubscriberAddress.Rows
            If row("AddressType") = AddressType And row("AddressDescription") = AddressDescription Then
                If row("SubscriberAddressId") = db.IsDBNull(Me.SubscriberRow("DefaultPostalAddressId"), 0) Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function
    Public Function ParentAffiliateRow(ParentSubscriberId As Integer) As DataRow
        Dim row As DataRow = Nothing
        For Each row In Me.SubscriberAffiliate.Rows
            If row("ParentSubscriberId") = ParentSubscriberId Then
                Exit For
            End If
        Next
        Return row
    End Function

    Public ReadOnly Property SubscriberAffiliate() As DataTable
        Get
            If Me.MainDataset.Tables("SubscriberAffiliate") Is Nothing Then
                daSubscriberAffiliate.Fill(Me.MainDataset, "SubscriberAffiliate")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("SubscriberAffiliate").Columns("SubscriberAffiliateId")}
            Me.MainDataset.Tables("SubscriberAffiliate").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("SubscriberAffiliate")
        End Get
    End Property
    Private _daSubscriberAffiliate As SqlDataAdapter
    Private ReadOnly Property daSubscriberAffiliate() As SqlDataAdapter
        Get
            If Me._daSubscriberAffiliate Is Nothing Then
                Dim sql As String = ""
                sql = "SELECT *"
                sql += " FROM SubscriberAffiliate"
                sql += " WHERE ChildSubscriberId = " & Me.SubscriberId
                sql += " ORDER BY ParentSubscriberId"
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daSubscriberAffiliate = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daSubscriberAffiliate)
                _daSubscriberAffiliate.UpdateCommand = cmdBld.GetUpdateCommand()
                _daSubscriberAffiliate.InsertCommand = cmdBld.GetInsertCommand()
                _daSubscriberAffiliate.DeleteCommand = cmdBld.GetDeleteCommand()

            End If

            If Not Me.db.DBTransaction Is Nothing Then
                _daSubscriberAffiliate.InsertCommand.Transaction = Me.db.DBTransaction
                _daSubscriberAffiliate.UpdateCommand.Transaction = Me.db.DBTransaction
                _daSubscriberAffiliate.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daSubscriberAffiliate
        End Get
    End Property


    Public ReadOnly Property CompanyAccount() As DataTable
        Get
            If Me.MainDataset.Tables("CompanyAccount") Is Nothing Then
                daCompanyAccount.Fill(Me.MainDataset, "CompanyAccount")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("CompanyAccount").Columns("CompanyAccountId")}
            Me.MainDataset.Tables("CompanyAccount").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("CompanyAccount")
        End Get
    End Property
    Private _daCompanyAccount As SqlDataAdapter
    Private ReadOnly Property daCompanyAccount() As SqlDataAdapter
        Get
            If Me._daCompanyAccount Is Nothing Then
                Dim sql As String = ""
                sql = "SELECT *"
                sql += " FROM CompanyAccount"
                sql += " WHERE SubscriberId = " & Me.SubscriberId
                sql += " ORDER BY CompanyId"
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daCompanyAccount = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daCompanyAccount)
                _daCompanyAccount.UpdateCommand = cmdBld.GetUpdateCommand()
                _daCompanyAccount.InsertCommand = cmdBld.GetInsertCommand()
                _daCompanyAccount.DeleteCommand = cmdBld.GetDeleteCommand()

            End If

            If Not Me.db.DBTransaction Is Nothing Then
                _daCompanyAccount.InsertCommand.Transaction = Me.db.DBTransaction
                _daCompanyAccount.UpdateCommand.Transaction = Me.db.DBTransaction
                _daCompanyAccount.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daCompanyAccount
        End Get
    End Property

    '26/5/11   Julian Gates   Add CompanyAccountRow to get correct company account
    Public Function CompanyAccountRow(ByVal CompanyId As Integer) As DataRow
        For Each row As DataRow In CompanyAccount.Rows
            If row("CompanyId") = CompanyId Then
                Return row
            End If
        Next
        '5/6/11     James Woosnam   If no CompanyAccount pass back a new row, as this is needed on Order Maint page
        Return Me.CompanyAccount.NewRow
    End Function

    'Public ReadOnly Property CompanyAccountRow() As DataRow
    '    Get
    '        If Me.CompanyAccount.Rows.Count = 0 Then
    '            Me.daCompanyAccount.Fill(Me.MainDataset.Tables("CompanyAccount"))
    '            'If Me.CompanyAccount.Rows.Count = 0 Then
    '            '    Throw New Exception("UserError: Company Account can't be found")
    '            'End If
    '        End If
    '        Return Me.CompanyAccount.Rows(0)
    '    End Get
    'End Property

    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property

    Dim _IsSpanishIJPESSubscriber As Boolean
    Public Property IsSpanishIJPESSubscriber() As String
        'Jan 2020   James   This field might change the text on some pages to Spanish, but at present it never can be set to true and I am not sure it would work if is was true
        '           therefore it is redundant and should be removed.
        Get
            If Me._IsSpanishIJPESSubscriber = Nothing Then
                Me._IsSpanishIJPESSubscriber = False
            End If
            Return Me._IsSpanishIJPESSubscriber
        End Get
        Set(ByVal Value As String)
            _IsSpanishIJPESSubscriber = Value
        End Set
    End Property
    Dim _RemoteUser As RemoteUser = Nothing
    ReadOnly Property RemoteUser As RemoteUser
        Get
            If _RemoteUser Is Nothing Then
                Dim Sql As String = "
                    SELECT ru.UserId
                    FROM RemoteUser ru
                        INNER JOIN RemoteUserRights rur
                        ON rur.UserId = ru.UserId
                        AND rur.RightsType = 'Subscriber'
                    WHERE ru.AuthorityLevel IN ( 'IndividualSubscriber','GroupUser')
                    AND rur.RightsToId=" & SubscriberId
                Dim tbl As DataTable = db.GetDataTableFromSQL(Sql)
                If tbl.Rows.Count = 0 Then
                    Return Nothing
                End If
                Dim UserId As Integer = tbl.Rows(0)("UserId")
                _RemoteUser = New RemoteUser(UserId, db, Me.UserSession)
            End If
            Return _RemoteUser
        End Get
    End Property
    '07/10/21   Julian Gates    SIR5323 - Add RemoteUserRows to show multiple Users.
    ReadOnly Property RemoteUserRows As DataTable
        Get
            Dim Sql As String = "
                    SELECT *
                    FROM RemoteUser ru
                        INNER JOIN RemoteUserRights rur
                        ON rur.UserId = ru.UserId
                        AND rur.RightsType = 'Subscriber'
                    WHERE rur.RightsToId=" & SubscriberId
            Dim tbl As DataTable = db.GetDataTableFromSQL(Sql)
            If tbl.Rows.Count = 0 Then
                Return Nothing
            End If
            Return tbl
        End Get
    End Property

    ReadOnly Property IsCompanyGroupParentSubscriber As Boolean
        Get
            Dim Sql As String = "
                    SELECT c.GroupParentSubscriberId
                    FROM Company c
                    WHERE c.GroupParentSubscriberId =" & SubscriberId

            Dim tbl As DataTable = db.GetDataTableFromSQL(Sql)
            If tbl.Rows.Count = 0 Then
                Return False
            Else
                Return True
            End If
        End Get
    End Property
#End Region
    Sub New(ByVal db As BusinessLogic.Database)
        Me.db = db
        Me.SubscriberId = 0
    End Sub
    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.SubscriberId = 0
    End Sub
    Sub New(ByVal SubscriberId As Integer, ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.SubscriberId = SubscriberId
        Me.Initilise()
    End Sub
    Public Sub Save()
        Dim sql As String = ""
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Dim logs As New BusinessLogic.Logs(db, Me.UserSession)
            Select Case Me.SubscriberRow.RowState
                Case DataRowState.Added, DataRowState.Modified
                    Me.SubscriberRow("LastUpdatedDateTime") = Now()
                    Me.SubscriberRow("LastUpdatedByUserId") = UserSession.UserName20

                    Try
                        logs.WriteAuditLog("Subscriber", Me.SubscriberId, UserSession.UserId, UserSession.UserName, Me.SubscriberRow.RowState.ToString(), "")
                    Catch ex As Exception
                    End Try
            End Select

            Me.daSubscriber.Update(Me.MainDataset, "Subscriber")


            For Each row As DataRow In Me.MainDataset.Tables("SubscriberAddress").Rows
                Select Case row.RowState
                    Case DataRowState.Added, DataRowState.Modified
                        row("LastUpdatedDateTime") = Now()
                        row("LastUpdatedByUserId") = UserSession.UserName20
                        Try
                            logs.WriteAuditLog("SubscriberAddress", row("SubscriberAddressId"), UserSession.UserId, UserSession.UserName, row.RowState.ToString(), "")
                        Catch ex As Exception
                        End Try
                End Select
            Next
            Me.daSubscriberAddress.Update(Me.MainDataset, "SubscriberAddress")

            For Each row As DataRow In Me.MainDataset.Tables("SubscriberAffiliate").Rows
                Select Case row.RowState
                    Case DataRowState.Added, DataRowState.Modified
                        '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
                        row("LastUpdatedDateTime") = Now()
                        row("LastUpdatedByUserId") = UserSession.UserName20
                        Try
                            logs.WriteAuditLog("SubscriberAffiliate", row("ParentSubscriberId") & "," & row("ChildSubscriberId") & "," & row("StartDate").ToString(), UserSession.UserId, UserSession.UserName, row.RowState.ToString(), "")
                        Catch ex As Exception
                        End Try
                End Select
            Next
            Me.daSubscriberAffiliate.Update(Me.MainDataset, "SubscriberAffiliate")

            For Each row As DataRow In Me.MainDataset.Tables("CompanyAccount").Rows
                Select Case row.RowState
                    Case DataRowState.Added, DataRowState.Modified
                        row("LastUpdatedDateTime") = Now()
                        row("LastUpdatedByUserId") = UserSession.UserName20
                        Try
                            logs.WriteAuditLog("CompanyAccount", row("SubscriberId") & "," & row("CompanyId"), UserSession.UserId, UserSession.UserName, row.RowState.ToString(), "")
                        Catch ex As Exception
                        End Try
                End Select
            Next
            Me.daCompanyAccount.Update(Me.MainDataset, "CompanyAccount")

            Dim al As New AuditLog(db, UserSession)
            al.WriteAuditLog(AuditLog.RecordTables.Subscriber, Me.SubscriberId)

            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try
    End Sub

    Public Sub UserLogOut()
        Me.SubscriberId = Nothing
    End Sub

    '16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields
    '29/10/19   Julian Gates    SIR4763 - Remove VAT Number field.
    Public Sub Add(ByVal EmailAddress As String,
                        ByVal Title As String,
                        ByVal FirstName As String,
                        ByVal LastName As String,
                        ByVal BillingAddress As String,
                        ByVal Town As String,
                        ByVal County As String,
                        ByVal CountyUS As String,
                        ByVal PostCode As String,
                        ByVal CountryId As String,
                        ByVal CandidateStudent As Boolean,
                        ByVal PrimaryCompanyId As Integer,
                        ByVal IsReceiveMail As Boolean,
                        ByVal IsBillingAddressAndTitleRequired As Boolean
                        )
        '28/10/19	James Woosnam	SIR4763 - In Add don't pass userid & password and call  RemoteUser.AddNewIndividualSubscriber
        '7/1/21     James Woosnam   SIR5143 - New field IsBillingAddressAndTitleRequired if false then billing address is no longer required and the fields can be left blank
        Dim message As String = ""

        If FirstName = "" Then
            message += "First Name required" & System.Environment.NewLine
        End If
        If LastName = "" Then
            message += "Lastname required" & System.Environment.NewLine
        End If
        If EmailAddress = "" Then
            message += "Email Address required" & System.Environment.NewLine
        End If
        If IsBillingAddressAndTitleRequired Then
            If Title = "" Then
                message += "Title required" & System.Environment.NewLine
            End If
            If BillingAddress = "" Then
                message += "Billing Address required" & System.Environment.NewLine
            End If
            If CountryId = 11 Or CountryId = 56 Then 'US or Canada
                If CountyUS = "" Then
                    message += "State (US or Canada) required" & System.Environment.NewLine
                Else
                    County = CountyUS
                End If
            End If
            If PostCode = "" Then
                message += "Postcode required" & System.Environment.NewLine
            End If
            If CountryId = "" Then
                message += "Country required" & System.Environment.NewLine
            End If
        End If


        If message <> "" Then
            message = message.Substring(0, message.Length - System.Environment.NewLine.Length)
            Throw New Exception("UserError: Add Subscriber Failed:" & System.Environment.NewLine & message)
        End If

        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Dim row As DataRow = Me.Subscriber.NewRow
            row("SubscriberId") = db.GetNextNumber("Subscriber")
            row("EntityType") = "Person"
            '22/9/21    James Woosnam   SIR5329 - Only make proposed if possible duplicate found, LastName and first character of first name match
            '16/8/22    James Woosnam   SIR5518 - Only set New subscribers to proposed if country, last and first name are the same, not just first character of first name. 
            Dim PossibleDuplicateSubscriberId As Integer = db.IsDBNull(db.DLookup("SubscriberId", "Subscriber", "EntityType='Person' AND SubscriberStatus IN ('Proposed','Current') AND LastName='" & LastName & "' AND FirstName='" & FirstName & "' AND PrimaryCountryId=" & CountryId), 0)
            If PossibleDuplicateSubscriberId = 0 Then
                row("SubscriberStatus") = "Current"
            Else
                row("SubscriberStatus") = "Proposed"
            End If
            If Not CandidateStudent Then
                row("SubscriberCategory") = "Ordinary"
            Else
                row("SubscriberCategory") = "Student"
            End If
            '17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .
            row("SubscriberName") = Left(LastName & ", " & FirstName, 150)
            row("Title") = Title
            row("FirstName") = FirstName
            row("LastName") = LastName
            row("CreatedDateTime") = Now()
            row("CreatedByUserId") = Left(EmailAddress, 20)
            row("LastUpdatedDateTime") = Now()
            row("LastUpdatedByUserId") = Left(EmailAddress, 20)
            If CountryId <> "" Then
                row("PrimaryCountryId") = CountryId
            End If
            row("IsReceiveMail") = Not IsReceiveMail
            If IsSpanishIJPESSubscriber Then
                row("IsSpanishIJPESSubscriber") = True
            Else
                row("IsSpanishIJPESSubscriber") = False
            End If
            Me.Subscriber.Rows.Add(row)

            Me.daSubscriber.Update(Me.MainDataset, "Subscriber")

            '   Me.Save(True)
            Me.SubscriberId = row("SubscriberId")
            Me.Initilise()

            Me.SaveSimpleSubscriberAddress("Email", "Main", EmailAddress,)
            If BillingAddress <> "" Then Me.SavePostalSubscriberAddress("Main", BillingAddress, Town, County, PostCode, CountryId, "", True)
            '26/10/20   Julian Gates Add billing address as copy of main
            If BillingAddress <> "" Then Me.SavePostalSubscriberAddress("Billing", BillingAddress, Town, County, PostCode, CountryId, "", True)
            If BillingAddress <> "" Then Me.SubscriberRow("DefaultPostalAddressId") = db.DLookup("SubscriberAddressId", "SubscriberAddress", "SubscriberId=" & Me.SubscriberId & " AND AddressType='Postal' AND AddressDescription='Main'")
            Me.AddSubscriberAffiliate(db.GetParameterValue("SuperGroupSubscriberId"))
            Me.AddSubscriberAffiliate(db.DLookup("GroupParentSubscriberId", "Company", "CompanyId=" & PrimaryCompanyId), "", Me.SubscriberRow("SubscriberCategory"))
            '28/10/19	James Woosnam	SIR4763 - In Add don't pass userid & password and call RemoteUser.AddNewIndividualSubscriber
            Dim RemoteUser As New RemoteUser(db, UserSession)
            RemoteUser.AddNewSubscriberUser(EmailAddress, Me.SubscriberId, UserSession.AuthorityLevels.IndividualSubscriber)
            'Send activation email
            If Not RemoteUser.UserName.Contains("PaDSTest") Then RemoteUser.ResetPasswordAndEmail()

            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try
    End Sub

    Public Sub SaveSimpleSubscriberAddress(
                     ByVal AddressType As String _
                    , ByVal AddressDescription As String _
                    , ByVal AddressText As String _
                    , Optional ByVal Notes As String = ""
                    )
        If AddressType = "Postal" Then
            If Me.IsSpanishIJPESSubscriber Then
                Throw New Exception("Guardar Dirección Suscriptor Simple no puede usarse para una dirección postal ")
            Else
                Throw New Exception("SaveSimpleSubscriberAddress can not be used for a postal address")
            End If
        End If
        Me.SaveSubscriberAddress(AddressType, AddressDescription, AddressText, "", "", "", "", Nothing, Notes)
    End Sub
    Public Sub SavePostalSubscriberAddress(
                     ByVal AddressDescription As String _
                    , ByVal BuildingStreet As String _
                    , ByVal Town As String _
                    , ByVal County As String _
                    , ByVal Postcode As String _
                    , ByVal CountryId As Integer _
                    , Optional ByVal Notes As String = "" _
                    , Optional ByVal UpdateExistingOrdersDeliveryAddress As Boolean = False
                    )
        Me.SaveSubscriberAddress("Postal", AddressDescription, "", BuildingStreet, Town, County, Postcode, CountryId, Notes, UpdateExistingOrdersDeliveryAddress)

    End Sub
    Private Sub SaveSubscriberAddress(
                     ByVal AddressType As String _
                    , ByVal AddressDescription As String _
                    , ByVal AddressText As String _
                    , ByVal BuildingStreet As String _
                    , ByVal Town As String _
                    , ByVal County As String _
                    , ByVal Postcode As String _
                    , ByVal CountryId As Integer _
                    , Optional ByVal Notes As String = "" _
                    , Optional ByVal UpdateExistingOrdersDeliveryAddress As Boolean = False
                    )
        Dim rowToUpdate As DataRow = Nothing
        Dim IsNewAddress As Boolean = True
        For Each row As DataRow In Me.SubscriberAddress.Rows
            If row("AddressType") = AddressType _
                 And row("AddressDescription") = AddressDescription Then
                rowToUpdate = row
                IsNewAddress = False
            End If
        Next
        If IsNewAddress Then
            rowToUpdate = Me.SubscriberAddress.NewRow
            rowToUpdate("SubscriberAddressId") = Me.db.GetNextNumber("SubscriberAddress")
            rowToUpdate("SubscriberId") = Me.SubscriberId
            rowToUpdate("AddressType") = AddressType
            rowToUpdate("AddressDescription") = AddressDescription
        End If
        rowToUpdate("LastUpdatedDateTime") = Now()
        rowToUpdate("LastUpdatedByUserId") = UserSession.UserName20
        If AddressType = "Postal" Then
            If Not db.IsDBNull(rowToUpdate("CountryId"), 0) = CountryId Then
                rowToUpdate("CountryId") = CountryId
            End If
            Dim LineLeft As String = ""
            Dim Pos As Integer = 1
            Dim LineNo As Integer = 1
            Dim NextPos As Integer = 0
            '23/6/11 Julian Gates - Add trim to BuildingStreet parameter to remove any blank spaces
            LineLeft = BuildingStreet.Trim
            NextPos = InStr(Pos, LineLeft, vbCrLf)
            Do While NextPos > 0
                If Not db.IsDBNull(rowToUpdate("Address" & LineNo), "") = Mid(BuildingStreet, Pos, NextPos - Pos) Then
                    rowToUpdate("Address" & LineNo) = Mid(BuildingStreet, Pos, NextPos - Pos)
                End If
                LineLeft = Mid(BuildingStreet, NextPos + 2)
                Pos = NextPos + 2
                NextPos = InStr(Pos, BuildingStreet, vbCrLf)
                LineNo = LineNo + 1
                If LineNo > 4 Then
                    If Me.IsSpanishIJPESSubscriber Then
                        Throw New Exception("Su dirección sólo puede tener un máximo de 4 líneas")
                    Else
                        Throw New Exception("Building Street can only be 4 lines")
                    End If
                End If
            Loop

            '28/11/2011 Julian Gates Add code below to stop truncation error if address rows too long
            If NextPos = 0 And Len(LineLeft) > 50 Then
                If Me.IsSpanishIJPESSubscriber Then
                    Throw New Exception("Cada línea de su dirección debe tener menos de 50 caracteres")
                Else
                    Throw New Exception("Building Street Address individual lines must be less than 50 characters")
                End If
            Else
                If NextPos = 0 And Len(LineLeft) > 0 Then
                    If Not db.IsDBNull(rowToUpdate("Address" & LineNo), "") = Mid(BuildingStreet, Pos) Then
                        rowToUpdate("Address" & LineNo) = Mid(BuildingStreet, Pos)
                    End If
                    LineNo = LineNo + 1
                End If
                Do While LineNo <= 4
                    If Not rowToUpdate("Address" & LineNo) Is System.DBNull.Value Then
                        rowToUpdate("Address" & LineNo) = System.DBNull.Value
                    End If
                    LineNo = LineNo + 1
                Loop
            End If

            If Not db.IsDBNull(rowToUpdate("Town"), "") = Town Then
                rowToUpdate("Town") = Town
            End If
            If Not db.IsDBNull(rowToUpdate("PostCode"), "") = Postcode Then
                rowToUpdate("PostCode") = Postcode
            End If
            If Not db.IsDBNull(rowToUpdate("County"), "") = County Then
                rowToUpdate("County") = County
            End If
            '24/10/20   James Woosnam   SIR5099 - Do address text here to reduce audit log entries
            Dim addrTxt As String = ""
            addrTxt += AddAddressField(rowToUpdate("Address1"))
            addrTxt += AddAddressField(rowToUpdate("Address2"))
            addrTxt += AddAddressField(rowToUpdate("Address3"))
            addrTxt += AddAddressField(rowToUpdate("Address4"))
            addrTxt += AddAddressField(rowToUpdate("Town"))
            addrTxt += AddAddressField(rowToUpdate("County"))
            addrTxt += AddAddressField(rowToUpdate("Postcode"))
            addrTxt += AddAddressField(db.DLookup("CountryName", "Country", "CountryId=" & rowToUpdate("CountryId")))
            rowToUpdate("AddressText") = IIf(addrTxt = "", "", addrTxt.Substring(0, addrTxt.Length - 1))
        Else
            If Not db.IsDBNull(rowToUpdate("AddressText"), "") = AddressText Then
                rowToUpdate("AddressText") = AddressText
            End If
        End If

        If Not db.IsDBNull(rowToUpdate("Notes"), "") = Notes Then
            rowToUpdate("Notes") = Notes
        End If

        '30/3/11   Julian Gates   SIR2401 - Add UpdateExistingOrdersDeliveryAddress
        If Not UpdateExistingOrdersDeliveryAddress Then
            rowToUpdate("UpdateExistingOrdersDeliveryAddress") = False
        Else
            rowToUpdate("UpdateExistingOrdersDeliveryAddress") = True
        End If

        If IsNewAddress Then
            Me.SubscriberAddress.Rows.Add(rowToUpdate)
        End If
        Me.Save()

    End Sub
    'Public Sub AddSubscriberAffiliate(ByVal ParentSubscriberId As String, ByVal AffiliateReferenceId As String, ByVal SubscriberCategory As String)
    '    Me.AddSubscriberAffiliate(ParentSubscriberId, AffiliateReferenceId, SubscriberCategory)
    'End Sub
    Public Sub AddSubscriberAffiliate(ByVal ParentSubscriberId As String)
        Me.AddSubscriberAffiliate(ParentSubscriberId, "", "")
    End Sub
    Public Sub AddSubscriberAffiliate(ByVal ParentSubscriberId As String, ByVal AffiliateReferenceId As String, ByVal SubscriberCategory As String)
        '30/03/16   Julian Gates    SIR4094 - Change default end date to 31/12/4949 in AddSubscriberAffiliation
        Me.AddSubscriberAffiliate(ParentSubscriberId, AffiliateReferenceId, SubscriberCategory, Now().Date, CDate("31-Dec-4949"))
    End Sub

    Public Sub AddSubscriberAffiliate(ByVal ParentSubscriberId As String, ByVal AffiliateReferenceId As String, ByVal SubscriberCategory As String, ByVal StartDate As Date, ByVal EndDate As Date)
        '13/1/20    James Woosnam   SIR4984 - Only add affiliate if not already present
        For Each rAf As DataRow In Me.SubscriberAffiliate.Rows
            If rAf("ParentSubscriberId") = ParentSubscriberId _
                    And rAf("StartDate") <= Now.Date _
                    And rAf("EndDate") > Now Then
                'if already exists then just update and exit
                If AffiliateReferenceId <> "" Then rAf("AffiliateReferenceId") = AffiliateReferenceId
                If SubscriberCategory <> "" Then rAf("SubscriberCategory") = SubscriberCategory
                Me.Save()
                Exit Sub
            End If
        Next
        Dim row As DataRow = Me.SubscriberAffiliate.NewRow

        row("ParentSubscriberId") = ParentSubscriberId
        row("ChildSubscriberId") = Me.SubscriberId
        row("AffiliateReferenceId") = AffiliateReferenceId
        row("SubscriberCategory") = SubscriberCategory
        row("StartDate") = StartDate
        row("EndDate") = EndDate
        row("LastUpdatedDateTime") = Now()
        row("LastUpdatedByUserId") = Me.UserSession.UserName20
        Me.SubscriberAffiliate.Rows.Add(row)
        Me.Save()
    End Sub
    Public Sub AddCompanyAccount(ByVal CompanyId As String, ByVal AccountType As String, ByVal DiscountRateId As Integer, ByVal RateType As String, ByVal BillingAddressId As Integer)
        Dim row As DataRow = Me.CompanyAccount.NewRow

        row("CompanyAccountId") = -1 * CompanyId
        row("SubscriberId") = Me.SubscriberId
        row("CompanyId") = CompanyId
        row("CompanyAccountStatus") = "Live"
        row("CreatedDateTime") = Now()
        row("CreatedByUserId") = Me.UserSession.UserName20
        row("LastUpdatedDateTime") = Now()
        row("LastUpdatedByUserId") = Me.UserSession.UserName20
        row("AccountNumber") = Me.SubscriberId
        row("AccountType") = AccountType
        row("DiscountRateID") = DiscountRateId
        row("RateType") = RateType
        row("BillingAddressId") = BillingAddressId
        row("RequireReceipt") = False
        row("RequireInvoice") = False
        Me.CompanyAccount.Rows.Add(row)
        Me.Save()
        'ToDo:  WriteAuditLog("CompanyAccount", SubscriberId & " " & CompanyId, "Add", "SubscriberId CompanyId")
    End Sub
    Function AddAddressField(field As Object) As String
        If db.IsDBNull(field) Then Return ""
        Return field & ","
    End Function
    Public Sub CreateProposedSubscriber()
        Try
            '13/1/20    James Woosnam   SIR4977 - Change IsProposedSubscriber to HasOrIsAProposedSubscriber in SessionData
            If Me.UserSession.Data("HasOrIsAProposedSubscriber") Then
                Throw New Exception("A proposed subscriber can't be set up as this subscriber already has one")
            End If
            Dim cmd As New SqlCommand("sp118CreateProposedSubscriber", Me.db.DBConnection, Me.db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OriginalSubscriberId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.SubscriberId))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName20", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, UserSession.UserName20))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@NewSubscriberId", System.Data.SqlDbType.Int, 0, ParameterDirection.Output, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, 0))

            cmd.ExecuteNonQuery()
            Me.SubscriberId = cmd.Parameters("@NewSubscriberId").Value
            Me.Initilise()
            Me.UserSession.Data("SubscriberId") = Me.SubscriberId
            Me.UserSession.Data("HasOrIsAProposedSubscriber") = True
        Catch ex As Exception
            Throw ex
        End Try

    End Sub
    Public Sub DeleteOldRedundantAddresses()
        '2/12/19    James Woosnam   SIR4946 - Upgrade to delete every 2 months
        'mark all redundant addresses that have not been updated in last 18 months as deleted
        Dim batchLog As New BatchLog("MarkOldRedundantAddressesAsDeleted", "MarkOldRedundantAddressesAsDeleted", db)
        Try
            Dim sLine As String = System.Environment.NewLine
            Dim sql As String = ""
            '16/1/20    James Woosnam   SIR4995 - DeleteOldRedundantAddresses change to update DefaultPostalAddress if redundant address deleted
            sql = "
    DECLARE @DeletedCount INT
            ,@UpdatedCount INT
    --Delete Redundant Addresses
    DELETE From SubscriberAddress
    Where AddressDescription = 'Redundant'
    And LastUpdatedDateTime < DATEADD(MONTH,-2,GETDATE())
    SELECT @DeletedCount = @@ROWCOUNT
    --Update DefaultPostalAddress as removing address main have made it invalid
    UPDATE Subscriber
    SET DefaultPostalAddressId = ISNULL(saPost.SubscriberAddressId  ,saBill.SubscriberAddressId )
    FROM Subscriber s
	    LEFT JOIN SubscriberAddress  saPost
	    ON saPost.SubscriberId = s.SubscriberId 
        AND saPost.AddressType = 'Postal' 
        AND saPost.AddressDescription = 'Main' 
	    LEFT JOIN SubscriberAddress  saBill
	    ON saBill.SubscriberId = s.SubscriberId 
        AND saBill.AddressType = 'Postal' 
        AND saBill.AddressDescription = 'Billing' 
    WHERE (NOT EXISTS(SELECT * FROM SubscriberAddress sa1 WHERE sa1.SubscriberAddressId = s.DefaultPostalAddressId )
		    OR s.DefaultPostalAddressId IS NULL
		    )
    AND ISNULL(saPost.SubscriberAddressId  ,saBill.SubscriberAddressId ) IS NOT NULL
    SELECT @UpdatedCount = @@ROWCOUNT

    SELECT DeletedCount=@DeletedCount,UpdatedCount=@UpdatedCount
    "
            Dim row As DataRow = db.GetDataTableFromSQL(sql).Rows(0)
            batchLog.Update(row("DeletedCount") & " SubscriberAddress lines Deleted")
            batchLog.Update(row("UpdatedCount") & " Subscriber DefaultSubsriberAddressId set to Main or Billing address")
            batchLog.Update("Complete", "Complete")
        Catch ex As Exception
            batchLog.Update(ex.Message, "Failed")
        End Try

    End Sub

    Public Function IsSubscriberValidForOrdering() As String
        Dim message As String = ""

        If BillingAddressRow Is Nothing Then
            message += String.Format(UserSession.GetTranslatedText(272, 1, "WARNING: To order a product you need to add address details, please click ""{0}"" and add your address."), UserSession.GetTranslatedText(110, 101, "Change Your Details"))
        End If
        Dim issueFound As Boolean = False
        If db.IsDBNull(GetAddressText("Email"), "") = "" Then issueFound = True
        If db.IsDBNull(Subscriber.Rows(0)("FirstName"), "") = "" Then issueFound = True
        If db.IsDBNull(Subscriber.Rows(0)("LastName"), "") = "" Then issueFound = True

        If issueFound Then
            message += IIf(message <> "", "<BR>", "") & String.Format(UserSession.GetTranslatedText(271, 1, "There is data is missing from your subscriber details, please click ""{0}"" and then click Save to see missing details."), UserSession.GetTranslatedText(110, 101, "Change Your Details"))
        End If
        Return message
    End Function
    '17/09/19  Julian Gates   SIR4915 - Add new MergeSubscriber Sub
    Public Sub MergeSubscriber(ByVal MergeIntoSubscriberId As Integer, ByVal MergeFromSubscriberId As Integer, SendConfirmationEmail As Boolean)
        Try
            Dim cmd As New SqlCommand("sp113MergeSubscribers", db.DBConnection, db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@MergeIntoSubscriberId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                              , MergeIntoSubscriberId))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@MergeFromSubscriberId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                              , MergeFromSubscriberId))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                              , UserSession.UserId))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReturnCode", System.Data.SqlDbType.Int, 0, ParameterDirection.Output, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , 0))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ErrorMessage", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Output, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , ""))
            cmd.ExecuteNonQuery()

            If db.IsDBNull(cmd.Parameters("@ReturnCode").Value, 0) <> 0 Then
                Throw New Exception("sp113MergeSubscribers Failed:" & cmd.Parameters("@ErrorMessage").Value)
            Else
                '2/12/19    James Woosnam   SIR4951 - Only send email if required
                If SendConfirmationEmail Then SendUserIdChangedEmailOnMerge(MergeIntoSubscriberId)
            End If

        Catch ex As Exception
            Dim email As New BusinessLogic.Email(Me.db)
            email.SendErrorEmail("Failed Merge into SubscriberId " & MergeIntoSubscriberId & " Subscriber " & SubscriberName,
                                     "The sp113MergeSubscribers Failed for merge from SubscriberId " & MergeFromSubscriberId & " and merge to SubscriberId " & MergeIntoSubscriberId & ". Merge was executed by " & UserSession.UserName & "<br> Error:" & ex.ToString)
            Throw ex
        End Try
    End Sub
    Public Sub RejectSubscriber()
        '21/4/22	Julian Gates	SIR5467 - Add @UserName20 parameter to RejectSubscriber()
        Try
            Dim cmd As New SqlCommand("sp115RejectSubscriber", db.DBConnection, db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                              , SubscriberId))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName20", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                              , UserSession.UserName20))
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Dim email As New BusinessLogic.Email(Me.db)
            email.SendErrorEmail("Failed to reject SubscriberId " & SubscriberId,
                                     "The sp115RejectSubscriber Failed for merge from SubscriberId " & SubscriberId & ". Reject was executed by " & UserSession.UserName & "<br> Error:" & ex.ToString)
            Throw ex
        End Try
    End Sub
    Public Sub InActivateSubscriber()
        Try
            If Me.SubscriberStatus <> SubscriberStates.Current Then
                Throw New Exception("Only 'Current' Subscribers can be Inactivated.")
            End If
            Me.SubscriberStatus = SubscriberStates.InActive
            If Me.RemoteUser IsNot Nothing Then
                Me.RemoteUser.InActivate()
            End If
            Me.Save()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub SendUserIdChangedEmailOnMerge(ByVal MergeIntoSubscriberId As Integer)
        Try
            Dim sText As String = Nothing
            Dim sql As String = Nothing
            Dim receiptFile As String = Nothing
            Dim row As DataRow = Nothing
            '21/11/19   Julian Gates    SIR4942 - Get NewWebUserName from RemoteUser and remove password
            sql = "SELECT  Distinct " _
                      & "		NewWebUserName = ru.UserName" _
                      & "     ,IntoSubscriber.FirstName" _
                      & "     ,IntoSubscriber.LastName" _
                      & "	  ,EmailAddress = SubscriberAddress.AddressText" _
                      & "	FROM SubscriberAddress" _
                      & "		INNER JOIN Subscriber IntoSubscriber" _
                      & "		ON IntoSubscriber.SubscriberId = " & MergeIntoSubscriberId _
                      & "		AND IntoSubscriber.SubscriberId = SubscriberAddress.SubscriberId" _
                      & "       INNER JOIN RemoteUserRights rur" _
                      & "       ON rur.rightsToId = " & MergeIntoSubscriberId _
                      & "       INNER JOIN RemoteUser ru" _
                      & "       ON rur.UserId = ru.UserId" _
                      & " WHERE SubscriberAddress.AddressType = 'Email'" _
                      & " AND SubscriberAddress.AddressDescription = 'Main'"
            Dim tbl As DataTable = db.GetDataTableFromSQL(sql)

            If tbl.Rows.Count = 0 Then
                Throw New Exception("Merge successful, but can't find User information to send confirmation Email. This could happen if two propsed subscribers are created and they are merged in the wrong order.  The User record is left attached to the wrong subscriber.")
            End If
            row = tbl.Rows(0)


            sText = New BusinessLogic.StdCode().GetFileText(db.GetParameterValue("ReportTemplateDirectory") & "\PEPOnlineUpdateConfirmation.htm")

            For Each col As DataColumn In tbl.Columns
                sText = sText.Replace("[" & col.ColumnName & "]", db.IsDBNull(row(col.ColumnName), ""))
                sText = sText.Replace("[DateTime]", System.DateTime.Now())
            Next

            Dim email As New BusinessLogic.Email(db)
            Dim strEmailToAddress As String = row("EmailAddress")
            If Not Me.db.IsOnLiveServer Then
                Dim TestEmail As String = ""
                Try
                    TestEmail = db.GetParameterValue("PEPRenewalEmailTestToAddress")
                Catch ex As Exception
                    TestEmail = "Support@zedra.co.uk"
                End Try
                email.SendTo = strEmailToAddress.Substring(0, strEmailToAddress.IndexOf("@")) & TestEmail.Substring(TestEmail.IndexOf("@"), TestEmail.Length - TestEmail.IndexOf("@"))
            Else
                email.SendTo = strEmailToAddress
            End If

            email.Subject = "PaDS Online Update Confirmation"
            Try '12/9/21    dont fail if no Blind email address
                '1/4/22     James Woosnam   SIR5458 - Stop Blind Copy Emails
                If db.GetParameterValue("BlindCopyEmailAddress") <> "" Then email.BCC = db.GetParameterValue("BlindCopyEmailAddress")
            Catch ex As Exception
            End Try
            email.From = db.GetParameterValue("EmailFrom")
            email.Body = sText
            email.Send()
            '11/4/22    James Woosnam    SIR5458 - AddToSubscriberEmailToDitributionLog 
            Dim emailing As New BusinessLogic.EmailDistribution(db)
            Dim newEmailDistributionLogId As Integer = emailing.AddToSubscriberEmailToDitributionLog(EmailName:="Subscriber Update Confirmation",
                                                                EmailSubject:=email.Subject,
                                                                EmailBody:=email.Body,
                                                                SendToEmailAddress:=strEmailToAddress,
                                                                SubscriberId:=MergeIntoSubscriberId,
                                                                CompanyId:=0,
                                                                EmailDistributionStatus:="Successfull")
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Public Sub AdminAdd(ByVal EntityType As String,
                       ByVal FirstName As String,
                       ByVal LastName As String,
                       ByVal SubscriberName As String,
                       ByVal CountryId As String,
                       ByVal SubscriberCategory As String,
                       ByVal PrimaryAffiliationSubscriberId As String
                       )

        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Dim row As DataRow = Me.Subscriber.NewRow
            row("SubscriberId") = db.GetNextNumber("Subscriber")
            row("EntityType") = EntityType
            row("SubscriberStatus") = "Proposed"
            Select Case EntityType
                Case "Person"
                    row("FirstName") = FirstName
                    row("LastName") = LastName
                    row("SubscriberName") = Left(LastName & ", " & FirstName, 150)
                Case "Organisation"
                    row("SubscriberName") = SubscriberName
            End Select
            row("PrimaryCountryId") = CountryId
            row("SubscriberCategory") = SubscriberCategory
            row("CreatedDateTime") = Now()
            row("CreatedByUserId") = UserSession.UserName20
            row("LastUpdatedDateTime") = Now()
            row("LastUpdatedByUserId") = UserSession.UserName20

            Me.Subscriber.Rows.Add(row)
            Me.daSubscriber.Update(Me.MainDataset, "Subscriber")
            Me.SubscriberId = row("SubscriberId")
            Me.Initilise()

            Me.AddSubscriberAffiliate(db.GetParameterValue("SuperGroupSubscriberId"))
            If CLng(PrimaryAffiliationSubscriberId) <> CLng(db.GetParameterValue("SuperGroupSubscriberId")) Then
                Me.AddSubscriberAffiliate(PrimaryAffiliationSubscriberId, Me.SubscriberId, SubscriberCategory)
            End If

            Dim lngAssociatedCompanyGroupParentSubscriberId As Integer = Nothing
            Dim lngCompanyId As Integer = Nothing
            lngCompanyId = db.DLookup("RightsToId", "RemoteUserRights", "UserId=" & UserSession.UserId & " AND RightsType = 'Company'")
            lngAssociatedCompanyGroupParentSubscriberId = db.DLookup("GroupParentSubscriberId", "Company", "CompanyId=" & lngCompanyId)
            If Not db.IsDBNull(lngAssociatedCompanyGroupParentSubscriberId) Then
                If CLng(lngAssociatedCompanyGroupParentSubscriberId) <> CLng(db.GetParameterValue("SuperGroupSubscriberId")) _
                        And CLng(lngAssociatedCompanyGroupParentSubscriberId) <> CLng(PrimaryAffiliationSubscriberId) Then
                    Me.AddSubscriberAffiliate(lngAssociatedCompanyGroupParentSubscriberId, Me.SubscriberId, Me.SubscriberRow("SubscriberCategory"))
                End If
            End If


            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try
    End Sub
End Class
