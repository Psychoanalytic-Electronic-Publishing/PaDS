﻿

DECLARE @NewDBVersion varchar(10)
DECLARE @OldDBVersion varchar(10)
DECLARE @CurrentDBVersion varchar(10)
DECLARE @SQL as varchar(max)
DECLARE @ProcName Varchar(50)
DECLARE @ServerName varchar(100)
DECLARE @DBName varchar(100)= DB_Name()
DECLARE @Message VARCHAR(2000)
DECLARE @RowCount INT
DECLARE @v sql_variant 
DECLARE @IsAtClient BIT = 0
DECLARE @LookupId INT

IF PATINDEX('%zedra%',@@ServerName) = 0
	SET @IsAtClient = 1

SELECT @ServerName = CASE WHEN @IsAtClient = 1 THEN 'PaDS01' ELSE  @@ServerName END

DECLARE @RunningAtClient BIT = ( SELECT CASE WHEN PATINDEX('%zedra%',@ServerName)=0 THEN 1 ELSE 0 END )

SET @OldDBVersion = '2.8'
SET @NewDBVersion = '2.9'
 
IF NOT EXISTS(SELECT * FROM stblParameters WHERE ParameterName = 'DatabaseVersion') INSERT INTO stblParameters(ParameterName,ParameterType,UserID,ParameterValue) SELECT 'DatabaseVersion','System','All','01.00'  
SELECT @CurrentDBVersion = ParameterValue FROM dbo.stblParameters WHERE ParameterName = 'DatabaseVersion'
SELECT 'Current Version: ' + @CurrentDBVersion

IF NOT (@CurrentDBVersion = @OldDBVersion OR  @CurrentDBVersion = @NewDBVersion)
OR @CurrentDBVersion IS NULL
BEGIN
	SELECT 'Current DB Version ' + ISNULL(@CurrentDBVersion,'EMPTY') + ' does not match'
END
ELSE
BEGIN
BEGIN TRANSACTION 
BEGIN TRY
print '1'
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name='EmailDistribution' and c.name = 'OrderNumber')
	BEGIN
		ALTER TABLE EmailDistribution ADD
			OrderNumber INT NULL
		EXECUTE('UPDATE EmailDistribution SET OrderNumber = (SELECT MAX(OrderNumber) FROM EmailDistributionLog l WHERE EmailDistributionId = ed.EmailDistributionId) FROM EmailDistribution ed ')
	END
--SIR5514
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name='tmpSubscriberImport' and c.name = 'ProfileChanges')
	BEGIN
		ALTER TABLE tmpSubscriberImport ADD
			ProfileChanges VARCHAR(MAX) NULL
	END
--SIR5562 Add TermsAndConditionsHTML and ReceiptEmailHTML to Product table
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name='Product' and c.name = 'TermsAndConditionsHTML')
	BEGIN
		ALTER TABLE Product ADD
			TermsAndConditionsHTML nvarchar(max) NULL,
			ReceiptEmailHTML nvarchar(max) NULL
	END
--SIR5562 Populate Product TermsAndConditionsHTML and ReceiptEmailHTML fields with HTML
IF @DBName = 'PaDS_Test' 
BEGIN
	SET @SQL = 'UPDATE Product set TermsAndConditionsHTML = NULL,ReceiptEmailHTML = NULL'
	execute(@sql)
END

--JV104
	SET @SQL ='UPDATE Product 
		SET TermsAndConditionsHTML = ''<ol>
<li><span style="font-size: 10pt;"><strong>The&nbsp;</strong><strong>International Journal of Psychoanalysis</strong>&nbsp;(incorporating the International Review of Psycho-Analysis, founded in 1974 by Joseph Sandler), published by the Institute of Psychoanalysis, is a fully peer-reviewed&nbsp;<strong>journal</strong>&nbsp;normally published in print and paper form 6 times a year in February, April, June, August, October and December.&nbsp;</span></li>
</ol><ol start="2">
<li><span style="font-size: 10pt;"><strong>A JV104 subscription</strong> entitles you to an electronic subscription for the 2023 volume, which is now available via PEP-Web at <a href="https://pep-web.org/browse/IJP/volumes"><span style="color: #0000ff;">https://pep-web.org/browse/IJP/volumes</span></a></span></li>
</ol>
<p style="margin-left: 40px;"><span style="font-size: 10pt;">Use the username and password used with your order to login. Your subscription entitles you to access 2023 articles as they are published and to access all IJP volumes back to 2000. If you are also a PEP-Web subscriber, then you will be able to seamlessly switch between the PEP Archive volumes and IJP.</span></p>
<ol start="3">
<li><span style="font-size: 10pt;"><strong>If you have difficulties with login, please contact <a href="mailto:ijpdigitalaccess@iopa.org.uk"><span style="color: #0000ff;">ijpdigitalaccess@iopa.org.uk</span></a></strong></span></li>
</ol>
<p><span style="font-size: 10pt;"><strong>PLEASE NOTE – IF YOU ALSO WISH TO HAVE THE PAPER EDITION MAILED TO YOU, THEN YOU MUST ALSO ORDER PV104 – the Print. The additional cost is $35 per year.</strong></span></p>
<p><span style="font-size: 10pt;"><strong>Posted October 18, 2022</strong></span></p>''
			,ReceiptEmailHTML = ''<table>
<tbody>
<tr style="height: 23px;">
<td>
<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong>PaDS</strong><strong>&nbsp;- Psychoanalysts Database System</strong></span></span></p>

<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong><br /></strong></span></span></p>
</td>
</tr>
<tr style="height: 36px;">
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>To: {{Title}} {{FirstName}} {{LastName}}</strong><strong><br />{{Address}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>Our reference: {{OrderNumber}}</strong><strong><br />Product: {{ProductName}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Thank you for your recent order for the&nbsp;<strong>digital edition</strong>&nbsp;of the&nbsp;<em>International Journal of Psychoanalysis (IJP) Volume 104 (2023; JV104) placed by</em>&nbsp;{{OrdererSubscriberName}}.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">By a new agreement reached with its publishers this volume and all previous IJP volumes are now available to you via PEPWEB. Go to: <a href="https://pep-web.org/browse/IJP/volumes">https://pep-web.org/browse/IJP/volumes</a>.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">To read the full text you will need to log into PEPWEB. If you already are a PEPWEB user, you can use the same credentials as always. If you are unsure about your credentials, go to <a href="https://www.psychoanalystdatabase.com/">PaDS</a> (our online ordering system) and use the forgot username/password facility. Your email will be the one to which this email has been directed.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">For help logging in and support in using the system, please go to <a href="http://support.pep-web.org/ijp-on-pep-web/">IJP on PEPWEB welcome and help pages</a>.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Your subscription to IJP also entitles you to take part at no cost in our online conference study days</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><a href="http://www.theijp.org/ijp-zoom-study-meetings/">http://www.theijp.org/ijp-zoom-study-meetings/</a></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Your subscription to IJP will expire on December the 31<sup style="font-size: 10pt;">st</sup>, 2023.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>THIS LETTER CONFIRMS YOU HAVE PURCHASED A DIGITAL SUBSCRIPTION ONLY</strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">&nbsp;- If you have already ordered the print version you will receive a separate acknowledgement.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">&nbsp;- If you have not ordered the print version and wish to do so:&nbsp;</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">VISIT&nbsp;<a href="https://www.psychoanalystdatabase.com/pages/pg070Logon.aspx">https://www.psychoanalystdatabase.com/pages/pg070Logon.aspx</a>, ENTER YOUR USERNAME AND PASSWORD AND ORDER PV104 FOR $35 which covers all six issues. You must do this before February 15 to be sure copies are available. (Note - if you ordered both digital and print versions you will receive a separate additional note and need take no action)&nbsp;</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><em>Francis Grier, Editor of the International Journal of Psychoanalysis</em></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>This is an automated message. Replies to this email address are routed to an unmonitored inbox. Please see our <a href="http://support.pep-web.org/">support pages</a> for ways to get in touch. </em></strong></span></span></p>
<p><br /><span style="font-size: 10pt;"><span style="font-family: Verdana;"> Please note that PaDS through which your subscription has been processed is fully compliant with European GDPR (privacy) legislation. IJP and PEP will be passing your email and postal addresses (but no other details) to the IJP publishers, Taylor and Francis but they will not use it, except to mail your print copies (if requested) or to grant you access to their site, without asking you to agree. IJP and PEP may occasionally contact you in relation to renewing your subscription (as above) or to advise you of offers and updates of new material. To ensure you remain in contact, please enter any changes of address, when they occur, by logging into your record at&nbsp;<a href="http://www.psychoanalystdatabase.com/">www.psychoanalystdatabase.com</a>. There you will also see confirmation of this order and, if you wish, be able to opt out of further email.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Under the European GDPR regulations the data we have about you (email address, subscription details and mailing address if you have ordered anything that needs to be mailed) is on our secure database called PaDS. You have a right to inspect this information, to see how it is used and to ask for it be deleted - including if this is a subscription via a group and you leave it. See further details of how the privacy of your data is protected and what you can do at:&nbsp;<a href="https://eur01.safelinks.protection.outlook.com/?url=http%3A%2F%2Fsupport.pep-web.org%2Fsubscribe%2Fpads-and-its-data-protection-policy%2F&amp;data=02%7C01%7C%7C10671dbc658e43d0892408d7a5918422%7C1faf88fea9984c5b93c9210a11d9a5c2%7C0%7C0%7C637159916717170590&amp;sdata=M3r7xqfHuTucNpdOHmxZ48vquH0rH39ZwAh2F0nneW0%3D&amp;reserved=0">http://support.pep-web.org/subscribe/pads-and-its-data-protection-policy/</a></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">IJP uses your email address only to send information about your subscription. It is necessary for that purpose but we do not use it for any other.</span></span></p>
</td>
</tr>
</tbody>
</table>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">&nbsp;</span></span></p>
<br /><br />''
		WHERE ProductCode = ''JV104'' AND TermsAndConditionsHTML IS NULL AND ReceiptEmailHTML IS NULL'
	execute(@sql)

--IJP23CO4
	SET @SQL ='UPDATE Product 
		SET TermsAndConditionsHTML = ''<p style="font-weight: 400;">If you are a subscriber to the International Journal of Psychoanalysis for 2023 (JV104) you may join the IJP February 2023 conference. See:&nbsp;<a href="http://www.theijp.org/ijp-zoom-study-meetings/"><span style="color: #0000ff;">http://www.theijp.org/ijp-zoom-study-meetings/</span></a></p>
<p style="font-weight: 400;">There is no charge.</p>
<p style="font-weight: 400;">Your registration will be confirmed once you complete the&nbsp;form&nbsp;and you will be sent a Zoom link to join the meeting a week beforehand.</p>
<p style="font-weight: 400;"><strong>Posted November 25, 2022</strong>.</p>''
			,ReceiptEmailHTML = ''''
		WHERE ProductCode = ''IJP23CO4'' AND TermsAndConditionsHTML IS NULL AND ReceiptEmailHTML IS NULL'
	execute(@sql)

--IJOD
	SET @SQL ='UPDATE Product 
		SET TermsAndConditionsHTML = ''<ol>
<li><span style="font-size: 10pt;"><strong>IJP Open</strong> is an online portal based publication providing readers with the opportunity to view the papers submitted to the <em>International Journal of Psychoanalysis</em> before formal peer review, and the opportunity to participate in a peer discussion of those papers, engaging with and developing critical thought. Following extensive peer review via IJP Open and the <em>International Journal of Psychoanalysis’s </em>formal peer review process accepted papers will be published in the <em>International Journal of Psychoanalysis. </em></span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>The Institute of Psychoanalysis</strong> (112a Shirland Road, London, W9 2EQ, UK) is and shall remain the sole and exclusive owner of IJP Open.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>Registered readers to IJP Open (those who have logged on to IJP Open as readers via PADS) </strong>are non-transferable and are subject to the conditions of use set out below. Each registered reader is an authorized user.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>Logging in is for personal use only. </strong>The logon may not be used for teaching or other activities for a 3<sup>rd</sup> party (for example a university or public hospital) and access will not be possible from such computers in public institutions with an IP address logged in PEP’s systems.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>Comments and Ethics</strong>. Comments made by IJP Open registered readers will be signed with their username (except in the case of IJP formal peer reviewer reports) and posted directly without moderation or censorship. It is therefore enormously important that posted comments stay strictly within the ‘reviewing’ task of examining a paper with respect to the clarity, coherence, and substantiation of the author’s argument, and that comments remain respectful at all times. The Editorial board of IJP Open warns against posting ad hominem comments or sweeping statements without detailed substantiation. Such comments are clearly not acceptable for respectful intercollegiate dialogue and IJP Open reserves the right to delete unacceptable comments and exclude such commentators from the community of registered readers.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>Unless a user has obtained the rights to other content on PEP-Web access is only to papers published in IJP Open and to the discussion of these papers.</strong> No authorized user may assist anyone other than another authorized user to access <strong>IJP Open </strong>and is expressly prohibited from doing so in any way whatsoever. Usage is monitored. Any breach of this condition will result in immediate removal of Registered Reader rights.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>Each authorized user</strong> will select their own username and password on the Psychoanalystdatabase.com database (PaDS) site (or use any existing username and password they already have). Access to <strong>IJP Open </strong>will be via each individual’s username and password which are input into the relevant boxes on <a href="http://www.pep-web.org/login.php"><span style="color: #0000ff;">http://www.pep-web.org/login.php</span></a> and which can be modified by a user through PaDS:&nbsp;<a href="http://www.psychoanalystdatabase.com/"><span style="color: #0000ff;">www.psychoanalystdatabase.com</span></a>&nbsp; Users are liable for the security of their username and password and must not transfer it.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>IJP Open </strong>and the PaDS database require a user to have Internet access and an approved browser. There are no limits on use but users should log out when finished as not to do so may affect the performance of the system.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>Availability. </strong>PEP has contracted with its suppliers for IJP Open to be available from a link 24 hours a day 7 days a week subject to routine maintenance and in all reasonable circumstances.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>PEP-Web Archive Copyright. </strong>The PEP-Web Archive - the host platform as owned by PEP - is owned by PEP or its suppliers and is protected by United States copyright laws and international treaty provisions.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>IJP Open copyright. </strong></span></li>
</ol>
<ol>
    <li><span style="font-size: 10pt;"><strong>The Institute of Psychoanalysis</strong> (112a Shirland Road, London, W9 2EQ, UK) is and shall remain the sole and exclusive owner of IJP Open.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>Authors</strong> opting into IJP Open give the Institute of Psychoanalysis a non-exclusive license of copyright to post the submitted article for the purposes of open peer review and comment by registered readers on the IJP Open platform.&nbsp; If the article is subsequently accepted for publication in the <em>International Journal of Psychoanalysis</em>, then the author will be required to sign the <em>International Journal of Psychoanalysis</em>’ normal copyright form.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>The Author</strong> agrees to let the submitted article be seen and openly commented on by IJP Open Registered Readers. Comments will be seen by other users.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;">All <strong>IJP Open Registered Readers</strong> grant a non-exclusive license for any content they generate and post to IJP Open.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;">All copyright (electronic and other) of the text, images, and photographs of IJP Open submitted articles appearing on the ARCHIVE is retained by the article author. Saving the exceptions noted below, no portion of any of the text, images, or photographs may be reproduced or stored in any form without prior permission of the Copyright owners.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;">Authorized Uses. Authorized Users may make all use of IJP Open materials as is consistent with the Fair Use Provisions of United States and international law. Nothing in this Agreement is intended to limit in any way whatsoever any Authorized User&#39;s rights under the Fair Use provisions of United States or international law to use the Licensed Materials.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;">During the term of any Registered Reader the IJP Open Materials may be used for purposes of research, education or other non-commercial use as follows:</span><ol start="1">
					<li style="margin: 5pt 0pt 5pt 36pt; list-style-type: lower-roman;"><span style="font-family: Arial; font-size: 10pt;">Digitally Copy. Authorized Users may download and digitally copy a reasonable portion of the Licensed Materials for their own use only.</span></li><li style="margin: 5pt 0pt 5pt 36pt; list-style-type: lower-roman;"><span style="font-family: Arial; font-size: 10pt;">Print Copy. Authorized Users may print (one copy per user) reasonable potions of the Licensed Materials for their own use only.</span> </li></ol></li>

<li><span style="font-size: 10pt;"><strong>Termination. </strong>In the event of termination of subscription any material downloaded, printed, or otherwise stored as permitted in the preceding section should not continue to be available and as far as practicable must be destroyed..</span></li>
<li><span style="font-size: 10pt;"><strong>Commercial reproduction. </strong>No purchaser or user shall use any portion of the contents of PEP-Web in any form of commercial exploitation, including, but not limited to, commercial print or broadcast media, and no purchaser or user shall reproduce it as its own any material contained herein.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>LIMITATION OF LIABILITY.</strong> The authors, The Institute of Psychoanalysis and PEP disclaim any liability to any party for the accuracy, completeness, or availability of any of the material herein, or for any damages arising out of the use or non-use of said IJP Open material or any information contained therein.</span><br /><br /></li>
    
<li><span style="font-size: 10pt;"><strong>Copyright Warranty.</strong> Licensor warrants that it has the right to license the rights granted under this Agreement to use Licensed Materials, that it has obtained any and all necessary permissions from third parties to license the Licensed Materials, and that use of the Licensed Materials by Authorized Users in accordance with the terms of this Agreement shall not infringe the copyright of any third party. The Licensor shall indemnify and hold Licensee and Authorized Users harmless for any losses, claims, damages, awards, penalties, or injuries incurred, including reasonable attorney&#39;s fees, which arise from any claim by any third party of an alleged infringement of copyright or any other property right arising out of the use of the Licensed Materials by the Licensee or any Authorized User in accordance with the terms of this Agreement. This indemnity shall survive the termination of this agreement. NO LIMITATION OF LIABILITY SET FORTH ELSEWHERE IN THIS AGREEMENT IS APPLICABLE TO THIS INDEMNIFICATION.</span><br /><br /></li>
</ol>
<p><span style="font-size: 10pt;"><strong>Posted June 17, 2020</strong></span></p>''
			,ReceiptEmailHTML = ''<table width="100%" style="width: 719px; height: 581px;">
<tbody>
<tr>
<td>
<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong>PaDS</strong><strong> - Psychoanalysts Database System</strong></span></span></p>


<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong><br /></strong></span></span></p>

</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>To: {{Title}} {{FirstName}} {{LastName}}<br />{{Address}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>Our reference: {{OrderNumber}}<br /> Product: {{ProductName}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Thank you for placing your recent order for<em> International Journal of Psychoanalysis Open (IJP Open)</em>. This note is to acknowledge that order and the receipt of your payment of $ {{Amount}}. Your credit card has now been charged.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">You should have gained access as soon as you confirmed your payment.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Please note that your subscription to <em>IJP Open </em>will expire in 5 years from the day your order was placed. Six weeks and then two weeks prior to your expiration date, we will send you an automatic reminder to the email entered in PaDS.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">To learn of future offers and updates please enter any changes of address, when they occur, by logging into your record at <a href="http://www.psychoanalystdatabase.com/">www.psychoanalystdatabase.com</a>. There you will also see confirmation of this order.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Psychoanalytic Electronic Publishing, Inc.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Dr. Nadine Levinson</span></span></p>
<p><span style="font-family: Verdana; font-size: 10pt;">PO Box 6358</span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Laguna Niguel, CA 92607</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Email: <a href="mailto:Sales@pep-web.org">Sales@pep-web.org</a></span></span></p>
</td>
</tr>
</tbody>
</table>
<br />''
		WHERE ProductCode = ''IJOD'' AND TermsAndConditionsHTML IS NULL AND ReceiptEmailHTML IS NULL'
	execute(@sql)

--Video24
	SET @SQL ='UPDATE Product 
		SET TermsAndConditionsHTML = ''<ul>
</ul><ol>
<li><span style="font-family: Arial; font-size: 10pt;"><strong>Subscriptions to PEP-Web Video 24 are valid </strong>for 24 hours from the moment of authorized payment only. Support is available through the online tutorial only. See HELP at the bottom right of your screen when you are at: <a href="http://www.pep-web.org/"><span style="color: #0000ff;">http://www.pep-web.org/</span></a></span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Subscriptions are for personal use only. </strong>The subscription may not be used for teaching or other activities for a 3<sup style="font-size: 10pt;">rd</sup> party (for example a university or public hospital) and access will not be possible from such computers in public institutions with an IP address logged in PEP’s systems.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Access is to the most up-to-date version of the PEP-Web Archive located at<span style="text-decoration: underline;"> </span></strong><a href="http://www.pep-web.org/login.php"><span style="color: #0000ff;">http://www.pep-web.org/login.php</span></a><strong> BUT DOES NOT INCLUDE ACCESS TO THE JOURNALS, BOOKS, OR THE FREUD STANDARD EDITION.</strong></span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Refund Policy.</strong> PEP offers No REFUND for any reason once payment has been confirmed by the subscriber.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>You will select a</strong> username and password on the Psychoanalystdatabase.com (PaDS) registration page as part of the sign up/registration procedure. Access to PEP-Web will be via your individual username and password which are input into the relevant boxes on <a href="http://www.pep-web.org/login.php"><span style="color: #0000ff;">http://www.pep-web.org/login.php</span></a> and which can be modified by a user through PaDS: <a href="http://www.psychoanalystdatabase.com/"><strong><span style="color: #0000ff;">www.psychoanalystdatabase.com</span></strong></a><strong>. </strong>Users are liable for the security of their username and password and must not transfer it.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>PEP-Web and the PaDS database</strong> require a user to have Internet access and an approved browser. There are no limits on use, but users should log out when finished as not to do so may affect the performance of the system.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Availability. </strong>PEP has contracted its suppliers for PEP-Web to be available from a link 24 hours a day 7 days a week subject to routine maintenance and in all reasonable circumstances.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Copyright. </strong>The PEP-Web Archive is owned by PEP or its suppliers and is protected by United States copyright laws and international treaty provisions.</span><ol>
<li><p style="margin: 5pt 0pt;"><span style="font-size: 10pt; font-family: Arial;">All copyright (electronic and other) of the text, images, photographs, and videos of the publications appearing on the PEP-Web is retained by the original publishers of the Journals, Books, or Videos. Saving the exceptions noted below, no portion of any of the text, images, photographs, or videos may be reproduced or stored in any form without prior permission of the Copyright owners</span></p></li>

<li><p style="margin: 5pt 0pt;"><span style="font-family: Arial; font-size: 10pt;">Authorized Uses. Authorized Users may make all use of the Licensed Materials as is consistent with the Fair Use Provisions of United States and international law. Nothing in this Agreement is intended to limit in any way whatsoever any Authorized User&#39;s rights under the Fair Use provisions of United States or international law to use the Licensed Material</span></p></li>

<li><p style="margin: 5pt 0pt;"><span style="font-family: Arial; font-size: 10pt;">During the term of any subscription the Licensed Materials may be used for purposes of research, education or other non-commercial use as follows: </span></p><ol start="1">
			</ol><ol start="1">
				</ol><ol start="1">
					<li style="margin: 5pt 0pt 5pt 36pt; list-style-type: lower-roman; font-size: 12pt;"><span style="font-family: Arial; font-size: 10pt;">Digitally Copy. Authorized Users may download and digitally copy a reasonable portion of the Licensed Materials for their own use only. </span></li><li style="margin: 5pt 0pt 5pt 36pt; list-style-type: lower-roman; font-size: 12pt;"><span><span style="font-family: Arial; font-size: 10pt;">Print Copy. Authorized Users may print (one copy per user) reasonable potions of the Licensed Materials for their own use only.</span> </span></li></ol><br /></li>
</ol>
</li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Commercial reproduction. </strong>No purchaser or user shall use any portion of the contents of PEP-Web in any form of commercial exploitation, including, but not limited to, commercial print or broadcast media, and no purchaser or user shall reproduce it as its own any material contained herein.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>LIMITATION OF LIABILITY.</strong> The publishers of the publications appearing on the PEP-Web Archive and PEP disclaim any liability to any party for the accuracy, completeness or availability of any of the material herein, or for any damages arising out of the use or non-use of said material or any information contained therein.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Copyright Warranty.</strong> Licensor warrants that it has the right to license the rights granted under this Agreement to use Licensed Materials, that it has obtained any and all necessary permissions from third parties to license the Licensed Materials, and that use of the Licensed Materials by Authorized Users in accordance with the terms of this Agreement shall not infringe the copyright of any third party. The Licensor shall indemnify and hold Licensee and Authorized Users harmless for any losses, claims, damages, awards, penalties, or injuries incurred, including reasonable attorney&#39;s fees, which arise from any claim by any third party of an alleged infringement of copyright or any other property right arising out of the use of the Licensed Materials by the Licensee or any Authorized User in accordance with the terms of this Agreement. This indemnity shall survive the termination of this agreement. NO LIMITATION OF LIABILITY SET FORTH ELSEWHERE IN THIS AGREEMENT IS APPLICABLE TO THIS INDEMNIFICATION.</span><br /><br /></li>
</ol>
<p><strong>Posted 21 Feb 2023</strong></p>''
			,ReceiptEmailHTML = ''<table width="100%">
<tbody>
<tr style="height: 23px;">
<td>
<p><span style="font-family: Verdana;"><strong><span style="color: #0000ff;">PaDS - Psychoanalysts Database System</span></strong></span></p>

<p><span style="font-family: Verdana;"><strong><span style="color: #0000ff;"><br /></span></strong></span></p>
</td>
</tr>
<tr style="height: 36px;">
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>To: {{Title}} {{FirstName}} {{LastName}}<br />{{Address}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>Our reference: {{OrderNumber}}<br /> Product: {{ProductName}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Thank you for placing your recent order for a 24-Hour Video Pass to PEP-Web Archive. This note is to acknowledge that order and the receipt of your payment of $ {{Amount}}. If applicable, your credit card has now been charged.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">You should have gained access as soon as you confirmed your payment.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">If you require help to log in or if you need guidance in using the platform, please visit our <a href="http://support.pep-web.org/welcome-to-pep-web/">Welcome Page</a>.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Please note that your 24-Hour Pass to PEP-Web expires approximately 24 hours from the time your order was placed.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">To learn of future offers and updates please enter any changes of address, when they occur, by logging into your record at <a href="http://www.psychoanalystdatabase.com/">www.psychoanalystdatabase.com</a>. There you will also see confirmation of this order.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">We hope you enjoy PEP-Web!</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>The PEP Customer Support Team</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>This is an automated message. Replies to this email address are routed to an unmonitored inbox. Please see our <a href="http://support.pep-web.org/">support pages</a> for ways to get in touch</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>GDPR Policy</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Under the European GDPR regulations the data we have about you (email address, subscription details and mailing address if you have ordered anything that needs to be mailed) is on our secure database called PADS. You have a right to inspect this information, to see how it is used and to ask for it be deleted - including if this is a subscription via a group and you leave it. See further details of how the privacy of your data is protected and what you can do at:&nbsp;<a href="https://eur01.safelinks.protection.outlook.com/?url=http%3A%2F%2Fsupport.pep-web.org%2Fsubscribe%2Fpads-and-its-data-protection-policy%2F&amp;data=02%7C01%7C%7C10671dbc658e43d0892408d7a5918422%7C1faf88fea9984c5b93c9210a11d9a5c2%7C0%7C0%7C637159916717170590&amp;sdata=M3r7xqfHuTucNpdOHmxZ48vquH0rH39ZwAh2F0nneW0%3D&amp;reserved=0">http://support.pep-web.org/subscribe/pads-and-its-data-protection-policy/</a></span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 8pt;"><span style="font-family: Verdana;">TO UNSUBSCRIBE FROM MAILING LIST:</span></span></p>
<p><span style="font-size: 8pt;"><span style="font-family: Verdana;">PEP uses your email address only to send information about your subscription. If you wish to unsubscribe from this mailing list, log into </span><a href="http://www.psychoanalystdatabase.com/" style="font-family: Verdana;">www.psychoanalystdatabase.com</a><span style="font-family: Verdana;"> and tick the relevant box.</span></span></p>
<p><span style="font-family: Verdana;"><span style="font-size: 8pt;">&nbsp;</span></span></p>
<p>&nbsp;</p>
</td>
</tr>
</tbody>
</table>''
		WHERE ProductCode = ''Video24'' AND TermsAndConditionsHTML IS NULL AND ReceiptEmailHTML IS NULL'
	execute(@sql)

--PEPWEBS
	SET @SQL ='UPDATE Product 
		SET TermsAndConditionsHTML = ''<ol>
<li><span style="font-size: 10pt;"><strong>Subscriptions to the PEP-Web Archive are valid </strong>for twelve months from date of purchase are non-transferable and subject to the conditions of use set out below. <strong>&nbsp;</strong>Each subscriber is an authorized user.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Subscriptions are for personal use only. </strong>The subscription may not be used for teaching or other activities for a 3<sup>rd</sup> party (for example a university or public hospital) and access will not be possible from such computers in public institutions with an IP address logged in PEP’s systems.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Access is to the most up-to-date version of PEP-Web located at </strong><a href="http://www.pep-web.org/login.php"><span style="color: #0000ff;">http://www.pep-web.org/login.php</span></a>&nbsp;<strong>and is only for those who have paid the relevant fees and are registered with PEP (authorized users).</strong> No authorized user may assist anyone other than another authorized user to access PEP-Web and is expressly prohibited from doing so in any way whatsoever. Usage is monitored. Any breach of this condition will result in immediate removal of access rights without compensation and in the imposition of a liability to indemnify PEP for any lost subscription fees.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Content.</strong><strong>PEP-Web stays approximately three years behind current journal content</strong>. However, due to contractual obligations, there are a few Journals that are five years behind current journal content.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Additional Fees.</strong> PEP intends to keep the annual subscription to PEP-Web stable, increasing by inflation only if necessary. However, if a period of over a week goes by without renewal, applicable late fees will be charged. If more than two years have lapsed, the subscriber must pay the entry fee again at the current rate. Further information may be obtained from <a href="mailto:sales@pep-web.org"><span style="color: #0000ff;">sales@pep-web.org</span></a>.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Refund Policy.</strong> Once a subscription is purchased, PEP offers NO REFUND. This policy includes any refund for anyone who joins as an individual and then is subsequently joined through their institute or organization. PEP recommends that you check with any such groups to which you are affiliated prior to subscribing. Should your organization subsequently join PEP, you may let your individual subscription lapse on the originally agreed date and continue on with your affiliated group.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Each authorized user</strong> will either be assigned a username and password on the <a href="http://www.psychoanalystdatabase.com/"><span style="color: #0000ff;">www.Psychoanalystdatabase.com</span></a> (PaDS) site if being added by your organization or will select their own username and password if they are registering as an individual subscriber. Access to PEP-Web will be via each individual’s username and password which are input into the relevant boxes on </span><span style="font-size: 10pt;"><a href="http://www.pep-web.org/login.php"><span style="color: #0000ff;">http://www.pep-web.org/login.php</span></a> and which can be modified by a user through PaDS:<a href="http://www.psychoanalystdatabase.com/"><span style="color: #0000ff;">www.psychoanalystdatabase.com</span></a> Users are liable for the security of their user name and password and must not transfer it.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Authorized Individual Users</strong> paying individual rates are entitled to free direct support from PEP Customer Support, by contacting support@pep-web.org for one month following the renewal of their subscription - to ensure they can log on and access articles. Subsequent support incidents may be charged at PEP&#39;s discretion. PEP-Web and the PaDS database require a user to have Internet access and an approved browser. There are no limits on use but users should log out when finished as not to do so may affect the performance of the system.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Availability. </strong>PEP has contracted its suppliers for PEP-Web to be available from a link 24 hours a day 7 days a week subject to routine maintenance and in all reasonable circumstances.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Copyright. </strong>The PEP-Web Archive is owned by PEP or its suppliers and is protected by United States copyright laws and international treaty provisions</span><ol>
<li style="margin-left: 40px;"><span style="font-size: 10pt;">All copyright (electronic and other) of the text, images, photographs, and videos of the publications appearing on PEP-Web is retained by the original publishers of the Journals, Books, or Videos. Saving the exceptions noted below, no portion of any of the text, images, photographs, or videos may be reproduced or stored in any form without prior permission of the Copyright owners.</span><br /><br /></li>
<li style="margin-left: 40px;"><span style="font-size: 10pt;">Authorized Uses. Authorized Users may make all use of the Licensed Materials as is consistent with the Fair Use Provisions of United States and international law. Nothing in this Agreement is intended to limit in any way whatsoever any Authorized User&#39;s rights under the Fair Use provisions of United States or international law to use the Licensed Materials.</span><br /><br /></li>
<li style="margin-left: 40px;"><span style="font-size: 10pt;">During the term of any subscription the Licensed Materials may be used for purposes of research, education or other non-commercial use as follows:</span><br /><br /></li>
</ol>

<ol style="margin-left: 40px;">
					<li style="margin: 5pt 0pt 5pt 36pt; list-style-type: lower-roman;"><span style="font-family: Arial; font-size: 10pt;">Digitally Copy. Authorized Users may download and digitally copy a reasonable portion of the Licensed Materials for their own use only.</span></li><li style="margin: 5pt 0pt 5pt 36pt; list-style-type: lower-roman;"><span style="font-family: Arial; font-size: 10pt;">Print Copy. Authorized Users may print (one copy per user) reasonable potions of the Licensed Materials for their own use only.</span> </li></ol>


</li>

<li><span style="font-size: 10pt;"><strong>Termination. </strong>In the event of termination of subscription any material downloaded, printed or otherwise stored as permitted in the preceding section should not continue to be available and as far as practicable must be destroyed. Subsequent subscription to PEP-Web will require payment of an entry fee.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Commercial reproduction. </strong>No purchaser or user shall use any portion of the contents of PEP-Web in any form of commercial exploitation, including, but not limited to, commercial print or broadcast media, and no purchaser or user shall reproduce it as its own any material contained herein.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>LIMITATION OF LIABILITY.</strong> The publishers of the publications appearing on the PEP-Web Archive and PEP disclaim any liability to any party for the accuracy, completeness or availability of any of the material herein, or for any damages arising out of the use or non-use of said material or any information contained therein.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Copyright Warranty.</strong> Licensor warrants that it has the right to license the rights granted under this Agreement to use Licensed Materials, that it has obtained any and all necessary permissions from third parties to license the Licensed Materials, and that use of the Licensed Materials by Authorized Users in accordance with the terms of this Agreement shall not infringe the copyright of any third party. The Licensor shall indemnify and hold Licensee and Authorized Users harmless for any losses, claims, damages, awards, penalties, or injuries incurred, including reasonable attorney&#39;s fees, which arise from any claim by any third party of an alleged infringement of copyright or any other property right arising out of the use of the Licensed Materials by the Licensee or any Authorized User in accordance with the terms of this Agreement. This indemnity shall survive the termination of this agreement. NO LIMITATION OF LIABILITY SET FORTH ELSEWHERE IN THIS AGREEMENT IS APPLICABLE TO THIS INDEMNIFICATION.</span><br /><br /></li>
</ol>
<p><span style="font-size: 10pt;"><strong>Posted February 22, 2021 </strong></span></p>''
			,ReceiptEmailHTML = ''<table width="100%">
<tbody>
<tr>
<td>
<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong>PaDS</strong><strong> - Psychoanalysts Database System</strong></span></span></p>

<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong><br /></strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>To: {{Title}} {{FirstName}} {{LastName}}<br />{{Address}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>Our reference: {{OrderNumber}}<br /> Product: {{ProductName}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Thank you for placing your recent order for a one year subscription to PEP-Web Archive. This note is to acknowledge that order and the receipt of your payment of $ {{Amount}}. Your credit card has now been charged.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">You should have gained access as soon as you confirmed your payment.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">If you require help to log in or if you need guidance in using the platform, please visit our <a href="http://support.pep-web.org/welcome-to-pep-web/">Welcome Page</a>.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Please note that your subscription to PEP-Web Archive will expire in 12 months from the day your order was placed. Six weeks and then two weeks prior to your expiration date, we will send you an automatic reminder to the email entered in PaDS.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">If you do not renew on time, late fees may apply. </span></span><br /><br /><span style="font-size: 10pt;"><span style="font-family: Verdana;">To learn of future offers and updates please enter any changes of address, when they occur, by logging into your record at <a href="http://www.psychoanalystdatabase.com/">www.psychoanalystdatabase.com</a>. There you will also see confirmation of this order.</span></span></p>
</td>
</tr>
</tbody>
</table>
<p><span style="font-family: Verdana; font-size: 12pt;"><strong><span style="color: #0000ff;">Psychoanalytic Electronic Publishing – further details</span></strong></span></p>
<ul>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">PEP-Web URL: <a href="https://www.pep-web.org/">https://www.pep-web.org</a></span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">If you are unsure how to log in or use PEP-Web, please consult our new Help website (<a href="http://support.pep-web.org/">http://support.pep-web.org/</a>). There is a lot of advice there on how to improve your use and viewing of PEP-Web.</span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">In 2022 you will notice that we have added an additional year of all our journals, so they are all more up-to-date. For information about embargoed content, see <a href="http://support.pep-web.org/embargoed-content/">http://support.pep-web.org/embargoed-content/</a></span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">You can now connect with us on Facebook (<a href="https://www.facebook.com/pepweb/">https://www.facebook.com/pepweb/</a>) or Twitter (<a href="https://twitter.com/PEPWeb">https://twitter.com/PEPWeb</a>).</span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">By using PEP, you consent to its term and conditions. Specifically, you must not lend your access codes and you must use it and print out from it only for <strong>your personal use</strong>. Breach of the conditions carries penalties.</span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>NEW CONTENT EMAIL ALERTS:</strong> You can now sign up at <a href="http://pep-web.org/login.php?requested=alerts.php">pep-web.org/php?requested=alerts.php</a> to be automatically notified by email whenever new content is added to PEP-Web.</span></span></li>
</ul>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">We hope you enjoy PEP-Web!</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>The PEP Customer Support Team</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>This is an automated message. Replies to this email address are routed to an unmonitored inbox. Please see our <a href="http://support.pep-web.org/">support pages</a> for ways to get in touch</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>&nbsp;</em></strong></span></span><strong style="font-family: Verdana; font-size: 10pt;"><em>GDPR Policy</em></strong></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Under the European GDPR regulations the data we have about you (email address, subscription details and mailing address if you have ordered anything that needs to be mailed) is on our secure database called PADS. You have a right to inspect this information, to see how it is used and to ask for it be deleted - including if this is a subscription via a group and you leave it. See further details of how the privacy of your data is protected and what you can do at:&nbsp;<a href="https://eur01.safelinks.protection.outlook.com/?url=http%3A%2F%2Fsupport.pep-web.org%2Fsubscribe%2Fpads-and-its-data-protection-policy%2F&amp;data=02%7C01%7C%7C10671dbc658e43d0892408d7a5918422%7C1faf88fea9984c5b93c9210a11d9a5c2%7C0%7C0%7C637159916717170590&amp;sdata=M3r7xqfHuTucNpdOHmxZ48vquH0rH39ZwAh2F0nneW0%3D&amp;reserved=0">http://support.pep-web.org/subscribe/pads-and-its-data-protection-policy/</a></span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 8pt;"><span style="font-family: Verdana;">TO UNSUBSCRIBE FROM MAILING LIST:</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><span style="font-size: 8pt;">PEP uses your email address only to send information about your subscription. If you wish to unsubscribe from this mailing list, log into <a href="http://www.psychoanalystdatabase.com/">www.psychoanalystdatabase.com</a> and tick the relevant box.</span></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>&nbsp;</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">&nbsp;</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">&nbsp;</span></span></p>
<p><span style="font-size: 10pt;">&nbsp;</span></p>''
		WHERE ProductCode = ''PEPWEBS'' AND TermsAndConditionsHTML IS NULL AND ReceiptEmailHTML IS NULL'
	execute(@sql)

--PEPWEB24
	SET @SQL ='UPDATE Product 
		SET TermsAndConditionsHTML = ''<ol>
<li><span style="font-size: 10pt;"><strong>Subscriptions to PEP-Web Journal 24 are valid </strong>for 24 hours from the moment of authorized payment only. Support is available through the online tutorial only. See HELP at the bottom right of your screen when you are at: <a href="http://www.pep-web.org/"><span style="color: #0000ff;">http://www.pep-web.org/</span></a></span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Subscriptions are for personal use only. </strong>The subscription may not be used for teaching or other activities for a 3<sup>rd</sup> party (for example a university or public hospital) and access will not be possible from such computers in public institutions with an IP address logged in PEP’s systems.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Access is to the most up-to-date version of the PEP-Web Archive located at </strong><a href="http://www.pep-web.org/login.php"><span style="color: #0000ff;">http://www.pep-web.org/login.php</span></a><strong> BUT DOES NOT INCLUDE ACCESS TO THE BOOKS, THE FREUD STANDARD EDITION, OR VIDEOS. Please also note that PEP-Web is always approximately 3 years behind the current date.&nbsp;</strong><strong>However, due to contractual obligations, there are a few Journals that are five years behind current journal content. </strong>The PEP Literature Search does expose articles written in the last three years (or 5 years where relevant), but you will only be able to view the abstract or a paragraph or small portion of those articles.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Refund Policy.</strong> PEP offers No REFUND for any reason once payment has been confirmed by the subscriber.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Printing. </strong>You are permitted to print up to 20 papers for your own personal use. You may not make further copies or hold electronic copies or use this material in an institutional teaching context. Usage is monitored. Any breach of this condition will result in immediate removal of access rights without compensation and in the imposition of a liability to indemnify PEP for any lost subscription fees.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>You will select a</strong> username and password on the Psychoanalystdatabase.com (PaDS) registration page as part of the sign up/registration procedure. Access to PEP-Web will be via your individual username and password which are input into the relevant boxes on <a href="http://www.pep-web.org/login.php"><span style="color: #0000ff;">http://www.pep-web.org/login.php</span></a> and which can be modified by a user through PaDS: <a href="http://www.psychoanalystdatabase.com/"><strong><span style="color: #0000ff;">www.psychoanalystdatabase.com</span></strong></a><strong>. </strong>Users are liable for the security of their username and password and must not transfer it.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>PEP-Web and the PaDS database</strong> require a user to have Internet access and an approved browser. There are no limits on use, but users should log out when finished as not to do so may affect the performance of the system.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Availability. </strong>PEP has contracted its supplier for PEP-Web to be available from a link 24 hours a day 7 days a week subject to routine maintenance and in all reasonable circumstances.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Copyright. </strong>The PEP-Web Archive is owned by PEP or its suppliers and is protected by United States copyright laws and international treaty provisions.</span><br /><br /><ol>
<li><span style="font-size: 10pt;">All copyright (electronic and other) of the text, images, photographs, and videos of the publications appearing on the PEP-Web is retained by the original publishers of the Journals, Books, or Videos. Saving the exceptions noted below, no portion of any of the text, images, photographs, or videos may be reproduced or stored in any form without prior permission of the Copyright owners.</span><br /><br /></li>
<li><span style="font-size: 10pt;">Authorized Uses. Authorized Users may make all use of the Licensed Materials as is consistent with the Fair Use Provisions of United States and international law. Nothing in this Agreement is intended to limit in any way whatsoever any Authorized User&#39;s rights under the Fair Use provisions of United States or international law to use the Licensed Materials.</span><br /><br /></li>
<li><span style="font-size: 10pt;">During the term of any subscription the Licensed Materials may be used for purposes of research, education or other non-commercial use as follows:</span><br /><br /></li>
</ol>
<ol start="1">
					<li style="margin: 5pt 0pt 5pt 36pt; list-style-type: lower-roman;"><span style="font-family: Arial; font-size: 10pt;">Digitally Copy. Authorized Users may download and digitally copy a reasonable portion of the Licensed Materials for their own use only.</span></li><li style="margin: 5pt 0pt 5pt 36pt; list-style-type: lower-roman;"><span style="font-family: Arial; font-size: 10pt;">Print Copy. Authorized Users may print (one copy per user) reasonable potions of the Licensed Materials for their own use only.</span> </li></ol></li>

<li><span style="font-size: 10pt;"><strong>Commercial reproduction. </strong>No purchaser or user shall use any portion of the contents of PEP-Web in any form of commercial exploitation, including, but not limited to, commercial print or broadcast media, and no purchaser or user shall reproduce it as its own any material contained herein.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>LIMITATION OF LIABILITY.</strong> The publishers of the publications appearing on the PEP-Web Archive and PEP disclaim any liability to any party for the accuracy, completeness or availability of any of the material herein, or for any damages arising out of the use or non-use of said material or any information contained therein.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Copyright Warranty.</strong> Licensor warrants that it has the right to license the rights granted under this Agreement to use Licensed Materials, that it has obtained any and all necessary permissions from third parties to license the Licensed Materials, and that use of the Licensed Materials by Authorized Users in accordance with the terms of this Agreement shall not infringe the copyright of any third party. The Licensor shall indemnify and hold Licensee and Authorized Users harmless for any losses, claims, damages, awards, penalties, or injuries incurred, including reasonable attorney&#39;s fees, which arise from any claim by any third party of an alleged infringement of copyright or any other property right arising out of the use of the Licensed Materials by the Licensee or any Authorized User in accordance with the terms of this Agreement. This indemnity shall survive the termination of this agreement. NO LIMITATION OF LIABILITY SET FORTH ELSEWHERE IN THIS AGREEMENT IS APPLICABLE TO THIS INDEMNIFICATION</span></li>
</ol>
<p><br /></p><p><span style="font-size: 10pt;"><strong>Posted May 17, 2016</strong></span></p>''
			,ReceiptEmailHTML = ''<table width="100%">
<tbody>
<tr>
<td>
<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong>PaDS</strong><strong> - Psychoanalysts Database System</strong></span></span></p>

<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong><br /></strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>To: {{Title}} {{FirstName}} {{LastName}}<br />{{Address}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>Our reference: {{OrderNumber}}<br /> Product: {{ProductName}}</strong></span></span></p>

<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><br /></strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Thank you for placing your recent order for a 24 Hour Pass to PEP-Web Archive. This note is to acknowledge that order and the receipt of your payment of $ {{Amount}}. Your credit card has now been charged.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">You should have gained access as soon as you confirmed your payment.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">If you require help to log in or if you need guidance in using the platform, please visit our <a href="http://support.pep-web.org/welcome-to-pep-web/">Welcome Page</a>.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Please note that your 24 Hour Pass to PEP-Web expires approximately 24 hours from the time your order was placed.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">To learn of future offers and updates please enter any changes of address, when they occur, by logging into your record at <a href="http://www.psychoanalystdatabase.com/">www.psychoanalystdatabase.com</a>. There you will also see confirmation of this order.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">We hope you enjoy PEP-Web!</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>The PEP Customer Support Team</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>This is an automated message. Replies to this email address are routed to an unmonitored inbox. Please see our <a href="http://support.pep-web.org/">support pages</a> for ways to get in touch</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>GDPR Policy</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Under the European GDPR regulations the data we have about you (email address, subscription details and mailing address if you have ordered anything that needs to be mailed) is on our secure database called PADS. You have a right to inspect this information, to see how it is used and to ask for it be deleted - including if this is a subscription via a group and you leave it. See further details of how the privacy of your data is protected and what you can do at:&nbsp;<a href="https://eur01.safelinks.protection.outlook.com/?url=http%3A%2F%2Fsupport.pep-web.org%2Fsubscribe%2Fpads-and-its-data-protection-policy%2F&amp;data=02%7C01%7C%7C10671dbc658e43d0892408d7a5918422%7C1faf88fea9984c5b93c9210a11d9a5c2%7C0%7C0%7C637159916717170590&amp;sdata=M3r7xqfHuTucNpdOHmxZ48vquH0rH39ZwAh2F0nneW0%3D&amp;reserved=0">http://support.pep-web.org/subscribe/pads-and-its-data-protection-policy/</a></span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 8pt;"><span style="font-family: Verdana;">TO UNSUBSCRIBE FROM MAILING LIST:</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><span style="font-size: 8pt;">PEP uses your email address only to send information about your subscription. If you wish to unsubscribe from this mailing list, log into <a href="http://www.psychoanalystdatabase.com/">www.psychoanalystdatabase.com</a> and tick the relevant box.</span></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">&nbsp;</span></span></p>
</td>
</tr>
</tbody>
</table>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">&nbsp;</span></span></p>''
		WHERE ProductCode = ''PEPWEB24'' AND TermsAndConditionsHTML IS NULL AND ReceiptEmailHTML IS NULL'
	execute(@sql)

--Pepweb3y
	SET @SQL ='UPDATE Product 
		SET TermsAndConditionsHTML = ''<table width="663">
<tbody>
<tr>
<td>
<ol>
<li><span style="font-family: Arial; font-size: 10pt;"><strong>Subscriptions to the PEP-Web Archive for 3 year are valid </strong>for THIRTY-SIX MONTHS from the date of purchase, are non-transferable and subject to the conditions of use set out below. <strong>&nbsp;</strong>Each subscriber is an authorized user.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>No refunds </strong>will be offered to users for any reason.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Subscribers are not obliged to renew their subscription but if they wish to continue to subscribe at preferential rates must do so before their subscription expires</strong>. (There is no reason to delay renewal as their new subscription will run from the last day of the old) and may be renewed up to 6 weeks prior to expiration.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Use is for personal study and research by the authorized user only. </strong>A subscription may not be used for teaching, research or activities for a 3</span><sup>rd</sup><span style="font-size: 10pt;"> party – e.g. a university. They are not therefore available for use on university and other computers with an IP address registered in PEP’s systems.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Access is to the most up-to-date version of the PEP-Web Archive located at </strong><a href="http://www.pep-web.org/login.php"><span style="color: #0000ff;">http://www.pep-web.org/login.php</span></a>&nbsp;<strong>and is only for those who have paid the relevant fees and are registered with PEP (authorized users).</strong> No authorized user may assist anyone other than another authorized user to access PEP-Web and is expressly prohibited from doing so in any way whatsoever. Usage is monitored. Any breach of this condition will result in immediate removal of access rights without compensation and in the imposition of a liability to indemnify PEP for any lost subscription fees.</span><br /><br /></li>

<li><span style="font-size: 10pt;">PEP-Web stays approximately three years behind current journal content. However, due to contractual obligations, there are a few Journals that are five years behind current journal content.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Additional Fees.</strong> There are no additional fees; however, if a period of under a year goes by without renewal, the subscription will be backdated to the original subscription date. &nbsp; If more than a year has lapsed, the member must pay for the years missed at the current rate.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Each authorized user</strong> will be assigned a web username and password on the Psychoanalystdatabase.com database (PaDS). Access to PEP-Web will be via each individual’s username and password which are input into the relevant boxes on <a href="http://www.pep-web.org/login.php"><span style="color: #0000ff;">http://www.pep-web.org/login.php</span></a> and which can be modified by a user through PaDS: <a href="https://www.psychoanalystdatabase.com/pages/pg100home.asp.%2520"><span style="color: #0000ff;">http://www.psychoanalystdatabase.com/pages/pg100home.asp.</span></a> Users are liable for the security of their username and password and must not transfer it. Users should keep their email address up-to-date on PaDS.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Authorized Users</strong> are not normally entitled to support from PEP Customer Support. Difficulties should be reported through the relevant group administrator for PEP.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>There are no limits on use</strong> but users should log out when finished as not to do so may affect the performance of the system.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Availability. </strong>PEP has contracted with supplier for PEP-Web to be available from a link 24 hours a day 7 days a week subject to routine maintenance and in all reasonable circumstances.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Copyright. </strong>The PEP-Web is owned by PEP or its suppliers and is protected by United States copyright laws and international treaty provisions.</span><ol>
<li><span style="font-family: Arial; font-size: 10pt;">All copyright (electronic and other) of the text, images, and photographs of the publications appearing on PEP-Web is retained by the original publishers of the Journals or Books. Saving the exceptions noted below, no portion of any of the text, images or photographs may be reproduced or stored in any form without prior permission of the Copyright owners.</span></li>
<li><span style="font-family: Arial; font-size: 10pt;">Authorized Uses. Authorized Users may make all use of the Licensed Materials as is consistent with the Fair Use Provisions of United States and international law. Nothing in this Agreement is intended to limit in any way whatsoever any Authorized User&#39;s rights under the Fair Use provisions of United States or international law to use the Licensed Materials.</span></li>
<li><p style="margin: 5pt 0pt;"><span style="font-family: Arial; font-size: 10pt;">During the term of any subscription the Licensed Materials may be used for purposes of research, education or other non-commercial use as follows: </span></p><ol start="1">
			</ol><ol start="1">
				</ol><ol start="1">
					<li style="margin: 5pt 0pt 5pt 36pt; list-style-type: lower-roman; font-size: 12pt;"><span style="font-family: Arial; font-size: 10pt;">Digitally Copy. Authorized Users may download and digitally copy a reasonable portion of the Licensed Materials for their own use only. </span></li><li style="margin: 5pt 0pt 5pt 36pt; list-style-type: lower-roman; font-size: 12pt;"><span><span style="font-family: Arial; font-size: 10pt;">Print Copy. Authorized Users may print (one copy per user) reasonable potions of the Licensed Materials for their own use only.</span> </span></li></ol><br /></li>
</ol>
</li>
<li><span style="font-family: Arial; font-size: 10pt;"><strong>Termination. </strong>In the event of termination of subscription any material downloaded, printed or otherwise stored as permitted in the preceding section should not continue to be available and as far as practicable must be destroyed. Subsequent subscription to PEP-Web will require payment as noted in #7 above.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Commercial reproduction. </strong>No purchaser or user shall use any portion of the contents of PEP-Web in any form of commercial exploitation, including, but not limited to, commercial print or broadcast media, and no purchaser or user shall reproduce it as its own any material contained herein.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>LIMITATION OF LIABILITY.</strong> The publishers of the publications appearing on the PEP-Web Archive and PEP disclaim any liability to any party for the accuracy, completeness or availability of any of the material herein, or for any damages arising out of the use or non-use of said material or any information contained therein.</span><br /><br /></li>

<li><span style="font-family: Arial; font-size: 10pt;"><strong>Copyright Warranty.</strong> Licensor warrants that it has the right to license the rights granted under this Agreement to use Licensed Materials, that it has obtained any and all necessary permissions from third parties to license the Licensed Materials, and that use of the Licensed Materials by Authorized Users in accordance with the terms of this Agreement shall not infringe the copyright of any third party. The Licensor shall indemnify and hold Licensee and Authorized Users harmless for any losses, claims, damages, awards, penalties, or injuries incurred, including reasonable attorney&#39;s fees, which arise from any claim by any third party of an alleged infringement of copyright or any other property right arising out of the use of the Licensed Materials by the Licensee or any Authorized User in accordance with the terms of this Agreement. This indemnity shall survive the termination of this agreement. NO LIMITATION OF LIABILITY SET FORTH ELSEWHERE IN THIS AGREEMENT IS APPLICABLE TO THIS INDEMNIFICATION.</span><br /><br /></li>
</ol>
<p><span style="font-family: Arial; font-size: 10pt;"><strong>Posted August 11, 2015</strong></span></p>
</td>
</tr>
</tbody>
</table>''
			,ReceiptEmailHTML = ''<table width="100%">
<tbody>
<tr>
<td>
<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong>PaDS</strong><strong> - Psychoanalysts Database System</strong></span></span></p>

<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong><br /></strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>To: {{Title}} {{FirstName}} {{LastName}}<br />{{Address}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>Our reference: {{OrderNumber}}<br /> Product: {{ProductName}}</strong></span></span></p>

<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><br /></strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Thank you for placing your recent order for a three-year subscription to PEP-Web Archive. This note is to acknowledge that order and the receipt of your payment of $ {{Amount}}. Your credit card has now been charged.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">You should have gained access as soon as you confirmed your payment.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">If you require help to log in or if you need guidance in using the platform, please visit our <a href="http://support.pep-web.org/welcome-to-pep-web/">Welcome Page</a>.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Please note that your subscription to PEP-Web Archive will expire in 36 months from the day your order was placed. For renewing subscribers that placed their order early, your subscription will run from the day your old one expires. Six weeks and then two weeks prior to your expiration date, we will send you an automatic reminder to the email entered in PaDS.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">If you do not renew on time, late fees may apply.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">To learn of future offers and updates please enter any changes of address, when they occur, by logging into your record at <a href="http://www.psychoanalystdatabase.com/">www.psychoanalystdatabase.com</a>. There you will also see confirmation of this order.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">&nbsp;</span></span><strong style="font-family: Verdana;"><span style="color: #0000ff;">Psychoanalytic Electronic Publishing – further details</span></strong></p>
<ul>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">PEP-Web URL: <a href="https://www.pep-web.org/">https://www.pep-web.org</a></span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">If you are unsure how to log in or use PEP-Web, please consult our new Help website (<a href="http://support.pep-web.org/">http://support.pep-web.org/</a>). There is a lot of advice there on how to improve your use and viewing of PEP-Web.</span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">In 2022 you will notice that we have added an additional year of all our journals, so they are all more up-to-date. For information about embargoed content, see <a href="http://support.pep-web.org/embargoed-content/">http://support.pep-web.org/embargoed-content/</a></span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">You can now connect with us on Facebook (<a href="https://www.facebook.com/pepweb/">https://www.facebook.com/pepweb/</a>) or Twitter (<a href="https://twitter.com/PEPWeb">https://twitter.com/PEPWeb</a>).</span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">By using PEP, you consent to its term and conditions. Specifically, you must not lend your access codes and you must use it and print out from it only for <strong>your personal use</strong>. Breach of the conditions carries penalties.</span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>NEW CONTENT EMAIL ALERTS:</strong> You can now sign up at <a href="http://pep-web.org/login.php?requested=alerts.php">pep-web.org/php?requested=alerts.php</a> to be automatically notified by email whenever new content is added to PEP-Web.</span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">For any questions or difficulties regarding PEP-Web, please contact your subscription administrator.</span></span></li>
</ul>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">We hope you enjoy PEP-Web!</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>The PEP Customer Support Team</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>This is an automated message. Replies to this email address are routed to an unmonitored inbox. Please see our <a href="http://support.pep-web.org/">support pages</a> for ways to get in touch</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>GDPR Policy</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Under the European GDPR regulations the data we have about you (email address, subscription details and mailing address if you have ordered anything that needs to be mailed) is on our secure database called PADS. You have a right to inspect this information, to see how it is used and to ask for it be deleted - including if this is a subscription via a group and you leave it. See further details of how the privacy of your data is protected and what you can do at:&nbsp;<a href="https://eur01.safelinks.protection.outlook.com/?url=http%3A%2F%2Fsupport.pep-web.org%2Fsubscribe%2Fpads-and-its-data-protection-policy%2F&amp;data=02%7C01%7C%7C10671dbc658e43d0892408d7a5918422%7C1faf88fea9984c5b93c9210a11d9a5c2%7C0%7C0%7C637159916717170590&amp;sdata=M3r7xqfHuTucNpdOHmxZ48vquH0rH39ZwAh2F0nneW0%3D&amp;reserved=0">http://support.pep-web.org/subscribe/pads-and-its-data-protection-policy/</a></span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 8pt;"><span style="font-family: Verdana;">TO UNSUBSCRIBE FROM MAILING LIST:</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><span style="font-size: 8pt;">PEP uses your email address only to send information about your subscription. If you wish to unsubscribe from this mailing list, log into <a href="http://www.psychoanalystdatabase.com/">www.psychoanalystdatabase.com</a> and tick the relevant box.</span></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>&nbsp;</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">&nbsp;</span></span></p>
</td>
</tr>
</tbody>
</table>''
		WHERE ProductCode = ''Pepweb3y'' AND TermsAndConditionsHTML IS NULL AND ReceiptEmailHTML IS NULL'
	execute(@sql)

--PV104
	SET @SQL ='UPDATE Product 
		SET TermsAndConditionsHTML = ''<ol><li><span style="font-size: 12pt;"><span style="font-size: 10pt;"><strong>The&nbsp;</strong><strong>International Journal of Psychoanalysis</strong>(incorporating the International Review of Psycho-Analysis, founded in 1974 by Joseph Sandler), published by the Institute of Psychoanalysis, is a fully peer-reviewed&nbsp;<strong>journal</strong>normally published in print and paper form 6 times a year in February, April, June, August, October and December.</span></span></li>
<li><span style="font-size: 10pt;"><strong>A PV104 subscription</strong> entitles you to be mailed all six issues of the paper version of the 2023 volume, provided you are already a digital subscriber.</span></li>
<li><span style="font-size: 10pt;"><strong>Orders made after February 15, 2023 are subject to stock availability and cannot be guaranteed</strong></span></li>
</ol><p><span style="font-size: 10pt;"><strong>Posted October 18, 2022</strong></span></p>''
		,ReceiptEmailHTML = ''<table>
<tbody>
<tr>
<td>
<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong>PaDS</strong><strong>&nbsp;- Psychoanalysts Database System</strong></span></span></p>

<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong><br /></strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>To: {{Title}} {{FirstName}} {{LastName}}</strong><strong><br />{{Address}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>Our reference: {{OrderNumber}}</strong><strong><br />Product: {{ProductName}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Thank you for placing your recent order for the&nbsp;<strong>print edition</strong>&nbsp;of the&nbsp;<em>International Journal of Psychoanalysis (IJP) Volume 104 (2023; PV104</em><strong><em>) </em></strong><em>placed by {{OrdererSubscriberName}}.</em></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">IJP is a fully peer-reviewed journal normally published in digital and print 6 times a year in February, April, June, August, October and December -&nbsp;<strong>but note that it can take up to 8 weeks from the publication date for print copies to be delivered to you.&nbsp;</strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>If you need to change the address to which your journals are sent at any time, please visit your account at </strong>to <a href="https://www.psychoanalystdatabase.com/">PaDS</a>, <strong>This is quick and much the most reliable way to do it.&nbsp;Do also arrange forwarding for your old address.&nbsp; </strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">For any questions or difficulties regarding non-arrival of print copies, please contact&nbsp;<a href="mailto:missingijpcopies@iopa.org.uk?subject=PV103">missingijpcopies@iopa.org.uk</a>.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><em>Francis Grier, Editor of the International Journal of Psychoanalysis</em></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>This is an automated message. Replies to this email address are routed to an unmonitored inbox. Please see our <a href="http://support.pep-web.org/">support pages</a> for ways to get in touch. </em></strong></span></span></p>
</td>
</tr>
</tbody>
</table>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">&nbsp;</span></span></p>''
		WHERE ProductCode = ''PV104'' AND TermsAndConditionsHTML IS NULL AND ReceiptEmailHTML IS NULL'
	execute(@sql)

--PEPWeb
	SET @SQL ='UPDATE Product 
		SET TermsAndConditionsHTML = ''<ol>
<li><span style="font-size: 10pt;"><strong>Subscriptions to the PEP-Web Archive for Group Users are valid </strong>for twelve months from date of purchase and are non-transferable and subject to the conditions of use set out below. <strong>&nbsp;</strong>Each subscriber is an authorized user.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Refund Policy.</strong> PEP offers NO REFUND for any reason once payment has been confirmed by the subscriber.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Use is for personal study and research by the authorized user only. </strong>A subscription may not be used for teaching or other activities for a 3<sup>rd</sup> party (for example a university or public hospital) and access will not be possible from such computers in public institutions with an IP address logged in PEP’s systems.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Access is to the most up-to-date version of the PEP-Web located at </strong><a href="http://www.pep-web.org/login.php"><span style="color: #0000ff;">http://www.pep-web.org/login.php</span></a>&nbsp;<strong>and is only for those who have paid the relevant fees and are registered with PEP (authorized users).</strong> No authorized user may assist anyone other than another authorized user to access PEP-Web and is expressly prohibited from doing so in any way whatsoever. Usage is monitored. Any breach of this condition will result in immediate removal of access rights without compensation and in the imposition of a liability to indemnify PEP for any lost subscription fees.</span><br /><br /></li>

<li><span style="font-size: 10pt;">The PEP-Web stays approximately three years behind current journal content. However, due to contractual obligations, there are a few Journals that are five years behind current journal content.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Additional Fees.</strong> There are no additional fees. A Group user <strong>may not start and stop their PEP-Web subscription, or there may be additional fees.</strong></span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Renewal: The subscription is renewed each year prior to expiration of the user’s current subscription.&nbsp; Should a Group subscriber let their subscription lapse and then rejoin,&nbsp;their subscription will be backdated to the original subscription date if less than a year.&nbsp;If the subscription has lapsed for more than a year, then the renewal payment for the total period of time the subscription has lapsed must be paid for in order to rejoin.</strong></span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Each authorized user</strong> will be assigned a username and password on the&nbsp;<a href="http://www.psychoanalystdatabase.com/"><span style="color: #0000ff;">www.Psychoanalystdatabase.com</span></a> (PaDS) by their group organization. Access to PEP-Web will be via each individual’s username and password which are input into the relevant boxes on <a href="http://www.pep-web.org/login.php"><span style="color: #0000ff;">http://www.pep-web.org/login.php</span></a> and which can be modified by a user through PaDS: <a href="http://www.psychoanalystdatabase.com/"><span style="color: #0000ff;">www.psychoanalystdatabase.com</span></a> Users are liable for the security of their username and password and must not transfer it.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Authorized Users</strong> are <strong>not</strong> entitled to support from <strong>PEP Customer Support.</strong> Difficulties should be reported directly to your Group Administrator.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>There are no limits on use</strong> but users should log out when finished as not to do so may affect the performance of the system.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Availability. </strong>PEP has contracted its supplier for PEP-Web to be available from a link 24 hours a day 7 days a week subject to routine maintenance and in all reasonable circumstances.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Copyright. </strong>The PEP-Web Archive is owned by PEP or its suppliers and is protected by United States copyright laws and international treaty provisions.</span><br /><br /><ol>
<li><span style="font-size: 10pt;">All copyright (electronic and other) of the text, images, photographs, and videos of the publications appearing on PEP-Web is retained by the original publishers of the Journals, Books, or Videos. Saving the exceptions noted below, no portion of any of the text, images, photographs, or videos may be reproduced or stored in any form without prior permission of the Copyright owners.</span><br /><br /></li>
<li><span style="font-size: 10pt;">Authorized Uses. Authorized Users may make all use of the Licensed Materials as is consistent with the Fair Use Provisions of United States and international law. Nothing in this Agreement is intended to limit in any way whatsoever any Authorized User&#39;s rights under the Fair Use provisions of United States or international law to use the Licensed Materials.</span><br /><br /></li>
<li><span style="font-size: 10pt;">During the term of any subscription the Licensed Materials may be used for purposes of research, education, or other non-commercial use as follows:</span><br /><br /></li>
</ol>

<ol start="1">
					<li style="margin: 5pt 0pt 5pt 36pt; list-style-type: lower-roman;"><span style="font-family: Arial; font-size: 10pt;">Digitally Copy. Authorized Users may download and digitally copy a reasonable portion of the Licensed Materials for their own use only.</span></li><li style="margin: 5pt 0pt 5pt 36pt; list-style-type: lower-roman;"><span style="font-family: Arial; font-size: 10pt;">Print Copy. Authorized Users may print (one copy per user) reasonable potions of the Licensed Materials for their own use only.</span> </li></ol></li>

<li><span style="font-size: 10pt;"><strong>Termination. </strong>In the event of termination of subscription any material downloaded, printed, or otherwise stored as permitted in the preceding section should not continue to be available and as far as practicable must be destroyed. Subsequent subscription to PEP-Web will require payment as noted in #7 above.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Commercial reproduction. </strong>No purchaser or user shall use any portion of the contents of PEP-Web in any form of commercial exploitation, including, but not limited to, commercial print or broadcast media, and no purchaser or user shall reproduce it as its own any material contained herein.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>LIMITATION OF LIABILITY.</strong> The publishers of the publications appearing on the PEP-Web Archive and PEP disclaim any liability to any party for the accuracy, completeness or availability of any of the material herein, or for any damages arising out of the use or non-use of said material or any information contained therein.</span><br /><br /></li>

<li><span style="font-size: 10pt;"><strong>Copyright Warranty.</strong> Licensor warrants that it has the right to license the rights granted under this Agreement to use Licensed Materials, that it has obtained any and all necessary permissions from third parties to license the Licensed Materials, and that use of the Licensed Materials by Authorized Users in accordance with the terms of this Agreement shall not infringe the copyright of any third party. The Licensor shall indemnify and hold Licensee and Authorized Users harmless for any losses, claims, damages, awards, penalties, or injuries incurred, including reasonable attorney&#39;s fees, which arise from any claim by any third party of an alleged infringement of copyright or any other property right arising out of the use of the Licensed Materials by the Licensee or any Authorized User in accordance with the terms of this Agreement. This indemnity shall survive the termination of this agreement. NO LIMITATION OF LIABILITY SET FORTH ELSEWHERE IN THIS AGREEMENT IS APPLICABLE TO THIS INDEMNIFICATION.</span><br /><br /></li>
</ol>
<p><strong>Posted August 28, 2015</strong></p>''
			,ReceiptEmailHTML = ''<table width="100%">
<tbody>
<tr style="height: 23px;">
<td>
<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong>PaDS</strong><strong> - Psychoanalysts Database System</strong></span></span></p>

<p><span style="font-family: Verdana;"><span style="color: #0000ff;"><strong><br /></strong></span></span></p>
</td>
</tr>
<tr style="height: 36px;">
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>To: {{Title}} {{FirstName}} {{LastName}}<br />{{Address}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>Our reference: {{OrderNumber}}<br /> Product: {{ProductName}}</strong></span></span></p>

<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><br /></strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Thank you for placing your recent order for a one year subscription to PEP-Web Archive. This note is to acknowledge that order and the receipt of your payment of $ {{Amount}}. Your credit card has now been charged.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">You should have gained access as soon as you confirmed your payment.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">If you require help to log in or if you need guidance in using the platform, please visit our <a href="http://support.pep-web.org/welcome-to-pep-web/">Welcome Page</a>.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Please note that for new subscribers your subscription to PEP-Web Archive will expire in 12 months from the day your order was placed. For renewing subscribers that placed their order early, your subscription will run from the day your old one expires. Six weeks and then two weeks prior to your expiration date, we will send you an automatic reminder to the email entered in PaDS.</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">If you do not renew on time, late fees may apply.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">To learn of future offers and updates please enter any changes of address, when they occur, by logging into your record at <a href="http://www.psychoanalystdatabase.com/">www.psychoanalystdatabase.com</a>. There you will also see confirmation of this order.</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">&nbsp;</span></span><strong style="font-family: Verdana;"><span style="color: #0000ff;">Psychoanalytic Electronic Publishing – further details</span></strong></p>
<ul>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">PEP-Web URL: <a href="https://www.pep-web.org/">https://www.pep-web.org</a></span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">If you are unsure how to log in or use PEP-Web, please consult our new Help website (<a href="http://support.pep-web.org/">http://support.pep-web.org/</a>). There is a lot of advice there on how to improve your use and viewing of PEP-Web.</span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">In 2022 you will notice that we have added an additional year of all our journals, so they are all more up-to-date. For information about embargoed content, see <a href="http://support.pep-web.org/embargoed-content/">http://support.pep-web.org/embargoed-content/</a></span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">You can now connect with us on Facebook (<a href="https://www.facebook.com/pepweb/">https://www.facebook.com/pepweb/</a>) or Twitter (<a href="https://twitter.com/PEPWeb">https://twitter.com/PEPWeb</a>).</span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">By using PEP, you consent to its term and conditions. Specifically, you must not lend your access codes and you must use it and print out from it only for <strong>your personal use</strong>. Breach of the conditions carries penalties.</span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>NEW CONTENT EMAIL ALERTS:</strong> You can now sign up at <a href="http://pep-web.org/login.php?requested=alerts.php">pep-web.org/php?requested=alerts.php</a> to be automatically notified by email whenever new content is added to PEP-Web.</span></span></li>
<li><span style="font-size: 10pt;"><span style="font-family: Verdana;">For any questions or difficulties regarding PEP-Web, please contact your subscription administrator.</span></span></li>
</ul>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">We hope you enjoy PEP-Web!</span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>The PEP Customer Support Team</em></strong></span></span></p>
<p><strong style="font-family: Verdana; font-size: 10pt;"><em>This is an automated message. Replies to this email address are routed to an unmonitored inbox. Please see our <a href="http://support.pep-web.org/">support pages</a> for ways to get in touch</em></strong></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>GDPR Policy</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Under the European GDPR regulations the data we have about you (email address, subscription details and mailing address if you have ordered anything that needs to be mailed) is on our secure database called PADS. You have a right to inspect this information, to see how it is used and to ask for it be deleted - including if this is a subscription via a group and you leave it. See further details of how the privacy of your data is protected and what you can do at:&nbsp;<a href="https://eur01.safelinks.protection.outlook.com/?url=http%3A%2F%2Fsupport.pep-web.org%2Fsubscribe%2Fpads-and-its-data-protection-policy%2F&amp;data=02%7C01%7C%7C10671dbc658e43d0892408d7a5918422%7C1faf88fea9984c5b93c9210a11d9a5c2%7C0%7C0%7C637159916717170590&amp;sdata=M3r7xqfHuTucNpdOHmxZ48vquH0rH39ZwAh2F0nneW0%3D&amp;reserved=0">http://support.pep-web.org/subscribe/pads-and-its-data-protection-policy/</a></span></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 8pt;"><span style="font-family: Verdana;">TO UNSUBSCRIBE FROM MAILING LIST:</span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><span style="font-size: 8pt;">PEP uses your email address only to send information about your subscription. If you wish to unsubscribe from this mailing list, log into <a href="http://www.psychoanalystdatabase.com/">www.psychoanalystdatabase.com</a> and tick the relevant box.</span></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>&nbsp;</em></strong></span></span></p>
</td>
</tr>
</tbody>
</table>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">&nbsp;</span></span></p>
<br /><br />''
		WHERE ProductCode = ''PEPWeb'' AND TermsAndConditionsHTML IS NULL AND ReceiptEmailHTML IS NULL'
	execute(@sql)

--SIR5555 Remove spaces from beginning and end of names and email adresses
	SET @SQL=''
	BEGIN
		set @SQL = '
		UPDATE RemoteUser SET UserName = RTRIM(LTRIM(UserName))	,EmailAddress = RTRIM(LTRIM(EmailAddress))
		UPDATE Subscriber SET SubscriberName = RTRIM(LTRIM(SubscriberName)),FirstName = RTRIM(LTRIM(FirstName)),LastName = RTRIM(LTRIM(LastName))
		UPDATE SubscriberAddress SET AddressText = RTRIM(LTRIM(AddressText)) WHERE AddressType = ''Email''
		'
	execute(@sql)
	END

	----**************************
	--Set New DB Version
	
	Update stblParameters
	SET ParameterValue =CAST( @NewDBVersion AS VARCHAR)
	WHERE ParameterName = 'DatabaseVersion'
	
--*************   END TRANSACTION *********************
Commit TRAN

SELECT 'Transaction Commited'
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SELECT 'Transaction Rolled Back'
	SELECT @Message = 'DBUpgrade Failed - Line:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE()
	
	RAISERROR ('%s', 18, 1,@Message)

END CATCH

END
