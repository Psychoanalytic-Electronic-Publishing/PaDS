/*

*/
if  exists (select * from sysobjects where id = object_id(N'vw440Cashbook') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP view vw440Cashbook --AS Select * from Company
go

CREATE VIEW vw440Cashbook
As
--31/10/06		James Woosnam	Set the BankedDate to a whole date in the report.  The cash report was using this as filter and therefore missing some trans.
--12/3/18		James Woosnam	SIR4596 - We looked at changes to this with a view to using the pivot for the fixed cashbook report, but David decided to leave it unchanged.
--								Issues: The month is based in Entry date which could be different to the banked date used for query criteria.  Entry date is switched to banked date once banked 
SELECT     Cashbook.SubscriberID
	, CompanyAccount.AccountType
	, Subscriber.SubscriberName + ' (' + cast(Subscriber.SubscriberId  as varchar) + ')' As AccountName
	, Cashbook.CompanyID
	, Company.CompanyName
	, Cashbook.CurrencyCode
	, Cashbook.OrderNumber
	, [Year]
	, [Quarter]
	, [Month]
	, CASE 
		WHEN ISNULL(Cashbook.BankDepositId,0) = 0 Then Cashbook.EntryDate 
		ELSE cast(Cast(BankDeposit.DateBanked As Varchar(11)) As DateTime)
	  END As [EntryDate]
--	,Cashbook.EntryDate As [EntryDate]
	, CASE ISNULL(CashBook.BankDepositId,0)
		WHEN 0 Then Cashbook.EntryDate 
--31/10/06		James Woosnam	Set the BankedDate to a whole date in the report.  The cash report was using this as filter and therefore missing some trans.
		ELSE cast(Cast(BankDeposit.DateBanked As Varchar(11)) As DateTime)
	  END As [BankedDate]
	, CASE ISNULL(CashBook.BankDepositId,0)
		WHEN 0 Then 'Not Banked' 
		ELSE 'Banked'
	  END As BankingStatus
	, Cashbook.EntryType 
	, Cashbook.PaymentType 
	, PaymentCardMerchant 
	,PaymentCardType
	, CASE Cashbook.PaymentType
		WHEN 'Cheque' Then ChequeNumber
		ELSE PaymentCardNumber 
	  END As AccountNumber 
	, Cashbook.Amount  AS AmountInNative
	, Cashbook.Amount *  Rate.ConversionRate AS AmountInBase
	,Cashbook.CashbookId
FROM  Cashbook 
	INNER JOIN Subscriber
	ON Subscriber.SubscriberId = Cashbook.SubscriberId
	INNER JOIN CompanyAccount
	ON CompanyAccount.SubscriberId = Cashbook.SubscriberId
	AND CompanyAccount.CompanyId = Cashbook.CompanyId
	INNER JOIN Company
	On Cashbook.CompanyId = Company.CompanyId
	Left Join BankDeposit
	On BankDeposit.BankDepositId = CashBook.BankDepositId
	Left Join CurrencyConversionRate Rate
	On Rate.CompanyId = Cashbook.CompanyId
	AND Rate.FromCurrencyCode = Cashbook.CurrencyCode
	AND Rate.ToCurrencyCode = Company.CurrencyCode
	AND Cashbook.[EntryDate] Between Rate.StartDate and Rate.EndDate
	LEFT JOIN ReportingCalendar
	ON ReportingCalendar.CalendarDate = Cashbook.[EntryDate]
WHERE CashbookStatus = 'Confirmed'
