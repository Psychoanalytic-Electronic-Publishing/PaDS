if exists (select * from dbo.sysobjects where id = object_id(N'sp483SubscriberImport') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp483SubscriberImport
GO
CREATE PROCEDURE sp483SubscriberImport(
						@SubscriberImportBatchId INT
						,@UserName varchar(50)
						,@RunMode varchar(20) = 'Check' --Check or Import
						,@AdditionalProducts AdditionalProducts READONLY  
						,@IndividualSubscriberImportId INT = 0
						,@ReturnCode INT OUTPUT
						,@ErrorMessage varchar(200) OUTPUT
						
									)
AS
--18/5/07	James Woosnam	SIR1155 Make Address1, Town, Postcode optional
--18/5/07	James Woosnam	SIR1156 - Update SubscriberCategory on Import
--13/6/07	James Woosnam	Create Affiliation to GroupSubscriberId if one not already present SIR1188
--25/9/07	James Woosnam	SIR1327 - Remove trailing spaces from email "Main"
--25/9/07	James Woosnam	SIR1327 - Change Work AddressDescription to "Work" not "Main"
--11/4/08	James Woosnam	SIR1517 - Set Order line address to the one just loaded.
--11/4/08 	James Woosnam	SIR1524 - Detect and handle dupliacte subscriptions
--23/4/08	James Woosnam	Use DefaultPostalAddressId in check for update default adddress 
--14/7/08	James Woosnam	SIR1554	- Add Completed Orders into query
--29/10/08	James Woosnam	SIR1616 - Add logic to check whether logged on in last 12 months, overwrite if havn't 
--							and imported userid and password are not blank.
--25/3/09	James Woosnam	SIR1827 - Only do WebUser check if there is a new webuserName
--5/3/10	James Woosnam	SIR2179 - Do WebUserName checks on Check not in Import
--28/9/10	James Woosnam	SIR2293 - Only show indivifual error message for individual
--14/10/10	James Woosnam	SIR2299 - Check Overwrite Username action at end
--8/2/11	James Woosnam	HotFix - Only Current and Propsed Subs			
--30/3/11	James Woosnam	SIR2401 - Find @CompanyAddressDescription
--1/10/12	James Woosnam	SIR2874 - Also look for duplicate subscriptions for products in @AdditionalProducts list
--2/12/13	James Woosnam	Put 2 Update statements in If so doesn't run if error found
--10/12/15	James Woosnam	SIR4020 - Always set OverwriteWebUserName to No for IJP
--10/12/15	James Woosnam	SIR4020 - Check username for a new user (not matched) has not been used.  Only do if user going to be overwritten
--16/05/19  Julian Gates    SIR4759 - Removed Home and work telephone and fax numbers
--8/11/19	James Woosnam	SIR4760 - Reworked for Remote User
--4/12/19    James Woosnam   SIR4950 - Collate by SQL_Latin1_General_CP1_CI_AI and convert subscriber name to NVARCHAR
--18/12/19	James Woosnam	SIR4979- Use EmailOpt Out to update subscriber.IsReceiveMail
--29/1/20	Julian Gates	SIR4936 - Change No Town to No City
--12/2/20	James Woosnam	SIR5014 - Always truncate the subscriber name to 50 characters.  This means that the first name could be truncated but this wont be a problem if the last name is that long.
--17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .
--3/1/20	James Woosnam	SIR5133 - Check for duplicate email addresses
--13/1/22	James			SIR5388 - Always default IsReceiveMail to true
--22/11/22	James Woosnam	Convert UserName to UserId to use in CreatedByUserId fields which can only be 20 characters
--22/2/23	James Woosnam	SIR5559 - Match on email address to person, individual sub where only 1 match and adjust email dup check
--2/3/23	James Woosnam	SIR5560 - If existing sub via same group as import order then add to group only

DECLARE @ErrorCode INT
DECLARE @ErrorFound INT
DECLARE @ProcName varchar(50)
DECLARE @ROWCOUNT INT
DECLARE @Message VARCHAR(2000)
DECLARE @Today DATETIME
SET @ReturnCode = 0
SET @ErrorFound = 0
SET @ProcName = 'sp483SubscriberImport'

SET @Today = CAST(CONVERT(varchar(11),GETDATE(),13) as DATETIME)

--22/11/22	James Woosnam	Convert UserName to UserId to use in CreatedByUserId fields which can only be 20 characters
IF (SELECT UserId FROM RemoteUser WHERE UserName=@UserName ) IS NULL
BEGIN
	SELECT @Message = 'UserName ''' + @UserName + ''' can''t be matched to a user'
	RAISERROR ('%s', 18, 1,@Message)
	RETURN
END
SELECT @UserName =(SELECT UserId FROM RemoteUser WHERE UserName=@UserName )

If @ErrorFound = 0
BEGIN
	IF NOT EXISTS(SELECT TOP 1 	SubscriberImportBatchId
					FROM tmpSubscriberImport
					WHERE SubscriberImportBatchId = @SubscriberImportBatchId)
	BEGIN
		SET @ReturnCode = 1
		SET @ErrorFound = 1
		SET @ErrorMessage = 'No subscribers for batch:' + CAST(@SubscriberImportBatchId as varchar)

	END

END

--30/3/11	James Woosnam	SIR2401 - Find @CompanyAddressDescription
DECLARE @CompanyAddressDescription VARCHAR(20)
SELECT @CompanyAddressDescription = MAX(c.DefaultAddressDescription)
FROM tmpSubscriberImport t
	INNER JOIN Company c
	ON c.CompanyId = t.CompanyId  
WHERE SubscriberImportBatchId = @SubscriberImportBatchId
IF ISNULL(@CompanyAddressDescription,'') = '' 
BEGIN
	SET @ReturnCode = 3
	SET @ErrorFound = 1
	SET @ErrorMessage = 'The Company must be set up with a DefaultAddressDescription'
END



DECLARE @Line VARCHAR(2)
SET @Line = char(13) + CHAR(10)
--10/12/15	James Woosnam	SIR4020 - Always set OverwriteWebUserName to No for IJP
If @ErrorFound = 0
BEGIN
	UPDATE tmpSubscriberImport
	SET OverwriteWebUserName = 'No'
	FROM tmpSubscriberImport 
	WHERE tmpSubscriberImport.SubscriberImportBatchId = @SubscriberImportBatchId
	AND tmpSubscriberImport.CompanyId = 1
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END


If @ErrorFound = 0
BEGIN

	UPDATE tmpSubscriberImport
	SET ErrorMessage = LEFT(
--		CASE WHEN ISNULL(tmpSubscriberImport.AffiliateReferenceId,'') = '' THEN 'No AffiliateReferenceId<BR>' + @Line ELSE '' END
		CASE WHEN ISNULL(tmpSubscriberImport.SubscriberCategory,'') = '' THEN 'No Subscriber Catogory<BR>' + @Line 
			ELSE CASE WHEN dbo.fn485GetSubsciberCategory(tmpSubscriberImport.SubscriberCategory,tmpSubscriberImport.CompanyId) = 'Unknown' 
					THEN 'Invalid Subscriber Catogory<BR>' + @Line ELSE '' END 
			END
	+	CASE WHEN ISNULL(tmpSubscriberImport.FirstName,'') = '' THEN 'No FirstName<BR>' + @Line ELSE '' END
	+	CASE WHEN ISNULL(tmpSubscriberImport.LastName,'') = '' THEN 'No LastName<BR>' + @Line ELSE '' END
--18/5/07	James Woosnam	SIR1155 Make Address1, Town, Postcode optional
	+ 	CASE WHEN ISNULL(tmpSubscriberImport.Address1,'') = '' 
					AND ISNULL(tmpSubscriberImport.Town,'') = '' 
					AND ISNULL(tmpSubscriberImport.PostCode,'') = '' THEN ''
		ELSE
--29/1/20	Julian Gates	SIR4936 - Change No Town to No City
			CASE WHEN ISNULL(tmpSubscriberImport.Address1,'') = '' THEN 'No Address1<BR>' + @Line ELSE '' END
			+	CASE WHEN ISNULL(tmpSubscriberImport.Town,'') = '' THEN 'No City<BR>' + @Line ELSE '' END
			+	CASE WHEN ISNULL(tmpSubscriberImport.PostCode,'') = '' THEN 'No PostCode<BR>' + @Line ELSE '' END
		END
	+	CASE WHEN ISNULL(tmpSubscriberImport.CountryName,'') = '' THEN 'No CountryName<BR>' + @Line 
			ELSE CASE WHEN Country.CountryId IS NULL THEN 'Invalid Country Name<BR>' + @Line ELSE '' END 
			END
--AffiliateReferenceID
	+	CASE WHEN Subscriber.LastNAme <> tmpSubscriberImport.LastName THEN 'This record is matched to a subscriber ' + CAST(Subscriber.SubscriberId as varchar) + ' with a different last name''' + Subscriber.LastName + '''<BR>' + @Line ELSE '' END
--Duplicate Id
	+	CASE  WHEN ISNULL(DuplicateAction,'') = 'Selected' AND ISNULL(DuplicateSubscriberIdToUse,0)=0 THEN 'Duplicate has been found, but no duplicate has been selected<BR>' + @Line ELSE '' END
		,1000)
--22/2/23	James Woosnam	SIR5559 - Match on email address to person, individual sub where only 1 match 
		,MatchedSubscriberId = ISNULL(Subscriber.SubscriberId,(SELECT MAX(s.SubscriberId)
																FROM Subscriber s
																	INNER join SubscriberAddress em
																	ON em.SubscriberId = s.SubscriberId
																	AND em.AddressType = 'Email'
																	AND em.AddressDescription = 'Main'
																	AND em.AddressText =  tmpSubscriberImport.EmailAddress
																	LEFT JOIN RemoteUserRights ror
																		INNER JOIN RemoteUser u
																		ON u.UserId = ror.UserId 
																		AND u.UserStatus IN ('Active','Emailed')
																	ON ror.RightsToId = s.SubscriberId
																	AND ror.RightsType = 'Subscriber'
																WHERE s.SubscriberStatus IN ('Current','Proposed')
																AND s.EntityType = 'Person'
																AND (u.userId IS NULL OR (u.userId IS NOT NULL AND u.AuthorityLevel = 'IndividualSubscriber'))
																GROUP BY em.AddressText
																HAVING COUNT(*)=1
																))
	FROM tmpSubscriberImport 
		LEFT JOIN Country
		On Country.CountryName = tmpSubscriberImport.CountryName
		LEFT JOIN SubscriberAffiliate
			INNER JOIN Subscriber
			On Subscriber.SubscriberId = SubscriberAffiliate.ChildSubscriberId
--8/2/11	James Woosnam	HotFix - Only Current and Propsed Subs			
			AND Subscriber.SubscriberStatus in ('Current','Proposed')
		On SubscriberAffiliate.AffiliateReferenceID = tmpSubscriberImport.AffiliateReferenceID
		AND SubscriberAffiliate.ParentSubscriberID = tmpSubscriberImport.GroupSubscriberId
		AND @Today BETWEEN SubscriberAffiliate.StartDate and SubscriberAffiliate.EndDate
	WHERE tmpSubscriberImport.SubscriberImportBatchId = @SubscriberImportBatchId
	AND (tmpSubscriberImport.SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END


If @ErrorFound = 0
BEGIN
--Dup CHeck
	UPDATE tmpSubscriberImport
	SET ErrorMessage = LEFT(
			ISNULL(ErrorMessage,'') 
		+	'This lastname and first letter of the first name have duplicates<BR>' + @Line
			   ,1000)
		,DuplicateFound = 1 
	FROM tmpSubscriberImport 
	WHERE 0 < (SELECT COUNT(*)
			FROM Subscriber 
				LEFT JOIN SubscriberAffiliate
				On SubscriberAffiliate.ChildSubscriberId = Subscriber.SubscriberId
				AND SubscriberAffiliate.ParentSubscriberId = tmpSubscriberImport.GroupSubscriberId
				AND SubscriberAffiliate.AffiliateReferenceId = tmpSubscriberImport.AffiliateReferenceId
--4/12/19    James Woosnam   SIR4950 - Collate by SQL_Latin1_General_CP1_CI_AI and convert subscriber name to NVARCHAR
			WHERE CAST(Subscriber.LastName AS NVARCHAR(50)) = CAST(tmpSubscriberImport.LastName AS NVARCHAR(50)) COLLATE SQL_Latin1_General_CP1_CI_AI
			AND CAST(CASE WHEN LEN(ISNULL(Subscriber.FirstName,''))>0 THEN LEFT(Subscriber.FirstName,1) ELSE '' END AS NVARCHAR(50))
				= CAST(CASE WHEN LEN(ISNULL(tmpSubscriberImport.FirstName,''))>0 THEN LEFT(tmpSubscriberImport.FirstName,1) ELSE '' END  AS NVARCHAR(50))  COLLATE SQL_Latin1_General_CP1_CI_AI
			AND SubscriberAffiliate.ChildSubscriberId IS NULL
			AND Subscriber.SubscriberStatus IN ('Current','Proposed'))
	AND tmpSubscriberImport.SubscriberImportBatchId = @SubscriberImportBatchId
	AND ISNULL(tmpSubscriberImport.DuplicateAction,'') = ''
	AND MAtchedSubscriberId IS NULL
	AND (tmpSubscriberImport.SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END

--9/4/08	James Woosnam	SIR1524 - Show error if sub has aready ordered product
/*
The system will use the order header previously set up and linked to the import to try and find other orders for the specified 
product made by the subscriber.  If it is a recurring subscription product it will use the Subscription Start Date entered on the 
order see if the dates overlap. For non recurring products it will look for any previous order for the product.
*/
If @ErrorFound = 0
BEGIN
--2/3/23	James Woosnam	SIR5560 - If existing sub via same group as import order then add to group only
	UPDATE tmpSubscriberImport
	SET ExistingSubscriptionAction = CASE WHEN ImportIntoOrder.SubscriberId = SalesOrder.SubscriberId THEN 'GroupOnly' ELSE ExistingSubscriptionAction END
		,ExistingSubscriptionFound = 1
	FROM tmpSubscriberImport 
		INNER JOIN SalesOrder ImportIntoOrder
		ON ImportIntoOrder.OrderNumber = tmpSubscriberImport.OrderNumber

		INNER JOIN SalesOrderLine  --previous order made by this subscriber
		ON SalesOrderLine.SubscriberId = CASE DuplicateAction WHEN 'Selected' THEN tmpSubscriberImport.DuplicateSubscriberIdToUse 
									ELSE ISNULL(tmpSubscriberImport.MatchedSubscriberId,0) END
		AND ISNULL(SalesOrderLine.IsCancel,0) = 0
		AND SalesOrderLine.OrderNumber <> tmpSubscriberImport.OrderNumber
		INNER JOIN SalesOrder
		On SalesOrder.OrderNumber = SalesOrderLine.OrderNumber
--14/7/08	James Woosnam	SIR1554	- Add Completed Orders into query
		AND SalesOrder.SalesOrderStatus IN ('Confirmed','Complete')
--1/10/12	James Woosnam	SIR2874 - Also look for duplicate subscriptions for products in @AdditionalProducts list
		AND (SalesOrder.PrimaryProductCode = ImportIntoOrder.PrimaryProductCode
			OR SalesOrder.PrimaryProductCode IN (SELECT ProductCode FROM @AdditionalProducts )
			)
		INNER JOIN Product
		On Product.ProductCode = SalesOrder.PrimaryProductCode
	WHERE tmpSubscriberImport.SubscriberImportBatchId = @SubscriberImportBatchId
	AND ISNULL(tmpSubscriberImport.ExistingSubscriptionAction,'') = ''
	AND ( ISNULL(ImportIntoOrder.SubscriptionStartDateForAdd ,@Today) BETWEEN SalesOrderLine.RecurringSubscriptionStartDate AND SalesOrderLine.RecurringSubscriptionEndDate
		OR ISNULL(Product.RecurringSubscriptionFlag,0) = 0)
	AND (tmpSubscriberImport.SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
If @ErrorFound = 0
BEGIN
	UPDATE tmpSubscriberImport
	SET ErrorMessage = LEFT(
				ISNULL(ErrorMessage,'') 
			+	 'Already subscribed to '  + Product.ProductCode + ' via ' + sOrd.SubscriberName + ' Ends:' + FORMAT(SalesOrderLine.RecurringSubscriptionEndDate,'dd-MMM-yy HH:mm') + '<BR>' + @Line 
		,1000)
		,ExistingSubscriptionFound = 1
	FROM tmpSubscriberImport 
		INNER JOIN SalesOrder ImportIntoOrder
		ON ImportIntoOrder.OrderNumber = tmpSubscriberImport.OrderNumber

		INNER JOIN SalesOrderLine  --previous order made by this subscriber
		ON SalesOrderLine.SubscriberId = CASE DuplicateAction WHEN 'Selected' THEN tmpSubscriberImport.DuplicateSubscriberIdToUse 
									ELSE ISNULL(tmpSubscriberImport.MatchedSubscriberId,0) END
		AND ISNULL(SalesOrderLine.IsCancel,0) = 0
		AND SalesOrderLine.OrderNumber <> tmpSubscriberImport.OrderNumber
		INNER JOIN SalesOrder
			INNER JOIN Subscriber sOrd
			ON sOrd.SubscriberId = SalesOrder.SubscriberId
		On SalesOrder.OrderNumber = SalesOrderLine.OrderNumber
--14/7/08	James Woosnam	SIR1554	- Add Completed Orders into query
		AND SalesOrder.SalesOrderStatus IN ('Confirmed','Complete')
--1/10/12	James Woosnam	SIR2874 - Also look for duplicate subscriptions for products in @AdditionalProducts list
		AND (SalesOrder.PrimaryProductCode = ImportIntoOrder.PrimaryProductCode
			OR SalesOrder.PrimaryProductCode IN (SELECT ProductCode FROM @AdditionalProducts )
			)
		INNER JOIN Product
		On Product.ProductCode = SalesOrder.PrimaryProductCode
	WHERE tmpSubscriberImport.SubscriberImportBatchId = @SubscriberImportBatchId
	AND ISNULL(tmpSubscriberImport.ExistingSubscriptionAction,'') = ''
	AND ( ISNULL(ImportIntoOrder.SubscriptionStartDateForAdd ,@Today) BETWEEN SalesOrderLine.RecurringSubscriptionStartDate AND SalesOrderLine.RecurringSubscriptionEndDate
		OR ISNULL(Product.RecurringSubscriptionFlag,0) = 0)
	AND (tmpSubscriberImport.SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END

--10/12/15	James Woosnam	SIR4020 - Check username for a new user (not matched) has not been used.  Only do if user going to be overwritten
--8/11/19	James Woosnam	SIR4760 - Reworked for Remote User
--2/3/23   JamesWoosnam    SIR5561 -  Check overwriting UserName with email wont cause duplicatr
If @ErrorFound = 0
BEGIN
	UPDATE tmpSubscriberImport
	SET ErrorMessage = LEFT(
			ISNULL(ErrorMessage,'') 
		+	'Email set to overwrite UserName, this would create a duplicate in PaDS. Either change, set overwrite to No, or match with sub<BR>'  + @Line
			   ,1000)
	FROM tmpSubscriberImport 
	WHERE 0 < (SELECT COUNT(*)
--3/1/20	James Woosnam	SIR5133 - Reworked to check all non-Inactive users
			FROM RemoteUser ru
				LEFT JOIN RemoteUserRights rur
				ON rur.UserId = ru.UserId
				LEFT JOIN Subscriber s
				ON s.SubscriberId  = rur.RightsToId
				AND s.SubscriberStatus IN ('Current','Proposed')
				LEFT JOIN SubscriberAffiliate
				On SubscriberAffiliate.ChildSubscriberId = s.SubscriberId
				AND SubscriberAffiliate.ParentSubscriberId = tmpSubscriberImport.GroupSubscriberId
				AND SubscriberAffiliate.AffiliateReferenceId = tmpSubscriberImport.AffiliateReferenceId
			WHERE ru.UserName  = tmpSubscriberImport.EmailAddress
			AND ru.UserStatus <> 'Inactive'

			AND ISNULL(s.SubscriberId,0) <> ISNULL(tmpSubscriberImport.MAtchedSubscriberId,0)
			AND ISNULL(s.SubscriberId,0)  <> ISNULL(tmpSubscriberImport.DuplicateSubscriberIdToUse ,0)
			)
	AND tmpSubscriberImport.SubscriberImportBatchId = @SubscriberImportBatchId
	AND OverwriteWebUserName = 'Yes'
	AND (tmpSubscriberImport.SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END	
--3/1/20	James Woosnam	SIR5133 - Check for duplicate email addresses
--22/2/23	James Woosnam	SIR5559 - Adjust and extend email dup check 
If @ErrorFound = 0
BEGIN
	UPDATE tmpSubscriberImport
	SET ErrorMessage = LEFT(
			ISNULL(ErrorMessage,'') 
		+	CAST(DupCount AS VARCHAR)+ ' duplicate email addresses' 
		+	CASE WHEN OrgDupCount<>0 THEN ', ' + CAST(OrgDupCount AS VARCHAR) + ' organisations' ELSE '' END
		+ '<BR>'  + @Line
			   ,1000)
		,DuplicateFound = 1 
	FROM tmpSubscriberImport 
		
		INNER JOIN (SELECT  t.SubscriberImportId 
						,sa.AddressText 
						,DupCount=COUNT(*)
						,OrgDupCount = SUM(CASE WHEN s.EntityType='Organisation' THEN 1 ELSE 0 END)
			FROM Subscriber s
				INNER JOIN SubscriberAddress sa
				ON sa.SubscriberId = s.SubscriberId 
				AND sa.AddressType = 'Email'
				AND sa.AddressDescription = 'Main'
				INNER JOIN tmpSubscriberImport t
				ON (t.SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
			WHERE sa.AddressText  = t.EmailAddress
			AND s.SubscriberId <> ISNULL(t.MAtchedSubscriberId,0)
			AND s.SubscriberId <> ISNULL(t.DuplicateSubscriberIdToUse ,0)
			AND s.SubscriberStatus IN ('Current','Proposed')
			
			GROUP BY  t.SubscriberImportId 
			,sa.AddressText 
			) s
		ON s.SubscriberImportId = tmpSubscriberImport.SubscriberImportId
	WHERE tmpSubscriberImport.SubscriberImportBatchId = @SubscriberImportBatchId
	AND (tmpSubscriberImport.SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
	AND s.DupCount <> 0
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
If @ErrorFound = 0
BEGIN
--5/3/10	James Woosnam	SIR2179 - Do WebUserName checks on Check not in Import
--19/2/11	James Woosnam	Use new  WebUserLastLoggedOn
--8/11/19	James Woosnam	SIR4760 - Reworked for Remote User
	SELECT  
		si.SubscriberImportId  
		,LastLoggedOnDateTime = MAX(ru.LastLoggedOn)
		,UserName = MAX(ru.UserName )
--10/12/15	James Woosnam	SIR4020 - Always set OverwriteWebUserName to No for IJP
		,OverwriteWebUserName = CASE WHEN MAX(si.companyId) = 1 THEN 'No'
									WHEN MAX(ru.LastLoggedOn ) IS NULL 	THEN 'Yes' ELSE 'No' END	
		,Subscriberid = MAX(rur.RightsToId )
	INTO #LastLogonDetails
	FROM tmpSubscriberImport si
		LEFT JOIN RemoteUserRights rur
				INNER JOIN RemoteUser ru
				ON ru.UserId = rur.UserId
				AND ru.UserStatus IN ('Active','Emailed')
		ON ( rur.RightsToId = si.MatchedSubscriberId 
		OR rur.RightsToId = si.DuplicateSubscriberIdToUse )
		AND rur.RightsType = 'Subscriber'
	WHERE si.SubscriberImportBatchId = @SubscriberImportBatchId
	AND (si.SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
	AND ISNULL(WebUserOverwriteActionReviewed,0) = 0
	GROUP BY si.SubscriberImportId  
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT

	If @ErrorFound = 0
	BEGIN
		UPDATE tmpSubscriberImport
		SET LastLoggedOnDateTime = lld.LastLoggedOnDateTime
--10/12/15	James Woosnam	SIR4020 - Always set OverwriteWebUserName to No for IJP
			,OverwriteWebUserName = CASE WHEN si.companyId = 1 THEN 'No'
										WHEN ISNULL(WebUserOverwriteActionReviewed,0)=1 THEN si.OverwriteWebUserName
										WHEN ISNULL(lld.userName,'')= si.EmailAddress  THEN 'No' --7/3/23 - No change so always no
										WHEN si.DuplicateFound =1 THEN NULL
										WHEN ISNULL(WebUserOverwriteActionReviewed,0)=0 THEN 
											CASE WHEN lld.SubscriberImportId  IS NULL THEN 'No' Else lld.OverwriteWebUserName END
								    ELSE si.OverwriteWebUserName END
			,WebUserOverwriteActionReviewed = CASE WHEN ISNULL(WebUserOverwriteActionReviewed,0)=0 THEN 
												CASE WHEN lld.UserName is null THEN 1  ELSE 0 END
											  ELSE 1 END
			,ErrorMessage = LEFT(
						ISNULL(ErrorMessage,'') 
							+	 
						CASE WHEN lld.Subscriberid is not null AND ISNULL(WebUserOverwriteActionReviewed,0) = 0 AND lld.UserName <> si.EmailAddress AND si.OverwriteWebUserName='Yes'  THEN
							'UserName will be changed to Email.  User last Logon:' + CASE WHEN lld.LastLoggedOnDateTime IS NULL THEN 'Never' ELSE FORMAT(lld.LastLoggedOnDateTime,'dd-MMM-yy') END + '<BR>' + @Line 
						ELSE '' END	
						,1000)
		FROM tmpSubscriberImport si
			LEFT JOIN #LastLogonDetails lld
			ON lld.SubscriberImportId = si.SubscriberImportId
		WHERE si.SubscriberImportBatchId = @SubscriberImportBatchId
		AND (si.SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
		SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	END 
END
--14/10/10	James Woosnam	SIR2299 - Check Overwrite Username action at end
If @ErrorFound = 0
BEGIN
	UPDATE tmpSubscriberImport
	SET ErrorMessage = LEFT(
				ISNULL(ErrorMessage,'') 
			+	 'Overwrite Username action not selected<BR>' + @Line 
		,1000)
	FROM tmpSubscriberImport 
	WHERE tmpSubscriberImport.SubscriberImportBatchId = @SubscriberImportBatchId
	AND (SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
	AND ISNULL(tmpSubscriberImport.OverwriteWebUserName,'') = ''
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
If @ErrorFound = 0
BEGIN
--Set status if any error messages have been set
	UPDATE tmpSubscriberImport
	SET Status = CASE WHEN ISNULL(ErrorMessage,'') = ''  THEN 'OK' ELSE 'Error' END
	FROM tmpSubscriberImport 
	WHERE  tmpSubscriberImport.SubscriberImportBatchId = @SubscriberImportBatchId
	AND (tmpSubscriberImport.SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END

--28/9/10	James Woosnam	SIR2293 - Only show indivifual error message for individual
IF EXISTS(Select SubscriberImportBatchId
		FROM tmpSubscriberImport
		WHERE tmpSubscriberImport.SubscriberImportBatchId = @SubscriberImportBatchId
	AND (tmpSubscriberImport.SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
		AND tmpSubscriberImport.Status NOT IN ('OK'))
BEGIN
	SET @ErrorFound = 1
	SET @ReturnCode = 2
	If @IndividualSubscriberImportId=0 
	BEGIN
		SET @ErrorMessage = 'Errors found in batch:' + CAST(@SubscriberImportBatchId as varchar) + ' See list for details.'
	End
	ELSE
	BEGIN
		SELECT @ErrorMessage = 'Errors found in ' + tmpSubscriberImport.FirstName + ' ' + tmpSubscriberImport.LastName 
						+ '<BR>' + ISNULL(tmpSubscriberImport.ErrorMessage,'')
		FROM tmpSubscriberImport
		WHERE tmpSubscriberImport.SubscriberImportId = @IndividualSubscriberImportId
	END
END

IF @ErrorFound = 0
AND @RunMode = 'Import'
BEGIN
 --29/11/18	James Woosnam	SIR4760 -Stop transaction here as it needs to be controlled from VB after password update
	--DECLARE @TranBegun BIT
	--SET @TranBegun = 0
	--If @ErrorFound = 0
	--BEGIN
	--	BEGIN TRAN
	--	SET @TRanBegun = 1
	--END
	DECLARE @SubscriberId INT
	DECLARE @MinSubscriberImportId INT
	DECLARE @SubscriberCount INT
	DECLARE @SubscriberImportId INT
	DECLARE @OrderNumber INT
	DECLARE @Row INT
	If @ErrorFound = 0
	BEGIN
		SELECT @MinSubscriberImportId = MIN(SubscriberImportId)
				,@SubscriberCount = COUNT(*)
				,@OrderNumber = ISNULL(MAX(OrderNumber),0)
		FROM tmpSubscriberImport
		WHERE tmpSubscriberImport.SubscriberImportBatchId = @SubscriberImportBatchId
--15/10/21	James Woosnam	SIR5342 - All indiviual subscribers to be imported
		AND (tmpSubscriberImport.SubscriberImportId = @IndividualSubscriberImportId OR @IndividualSubscriberImportId=0)
		SET @Row = 0
	END

	WHILE @Row < @SubscriberCount
	BEGIN
		If @ErrorFound = 0
		BEGIN
			SELECT @SubscriberId = CASE ISNULL(DuplicateAction,'') WHEN 'Selected' THEN DuplicateSubscriberIdToUse 
									ELSE ISNULL(MatchedSubscriberId,0) END
				,@SubscriberImportId = tmpSubscriberImport.SubscriberImportId
			FROM tmpSubscriberImport 
			WHERE tmpSubscriberImport.SubscriberImportBatchId = @SubscriberImportBatchId
			AND tmpSubscriberImport.SubscriberImportId = @MinSubscriberImportId + @Row
			SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
		END
		
		If @ErrorFound = 0
		AND @SubscriberId = 0
		BEGIN
		--New Subscriber--
			Exec dbo.sp005GetNextTableNumber 'Subscriber',@SubscriberId OUTPUT
			INSERT INTO Subscriber
				(SubscriberId
			  ,SubscriberName
			  ,SubscriberStatus
			  ,EntityType
			  ,PrimaryCountryId
			  ,SubscriberCategory
			  ,IsAccount
			  ,MailMethod
			  ,IsReceiveMail
			  ,FirstName
			  ,LastName
			  ,CreatedDateTime
			  ,CreatedByUserId
			  ,LastUpdatedDateTime
			  ,LastUpdatedByUserId
			 )
			SELECT	
				@SubscriberId
--12/2/20	James Woosnam	SIR5014 - Always truncate the subscriber name to 50 characters.  This means that the first name could be truncated but this shouldn't be a problem is the last name is that long.
--17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .
				,SubscriberName = LEFT(ISNULL(LastName,'') + CASE WHEN ISNULL(FirstName,'') <> '' THEN + ', ' + FirstName ELSE '' END,150)
				,'Current'
				,'Person'
				,Country.CountryId
				,dbo.fn485GetSubsciberCategory(tmpSubscriberImport.SubscriberCategory,tmpSubscriberImport.CompanyId)
			  ,IsAccount = 0
			  ,MailMethod = 'Post'
			  ,IsReceiveMail = 1 --13/1/22	James	SIR5388 - Always default IsReceiveMail to true
			  ,FirstName = FirstName
			  ,LastName = LastName
			  ,CreatedDateTime = GETDATE()
			  ,CreatedByUserId = @UserName
			  ,LastUpdatedDateTime = GetDate()
			  ,LastUpdatedByUserId = @UserName
			FROM tmpSubscriberImport
				LEFT JOIN Country
				On Country.CountryName = tmpSubscriberImport.CountryName
			WHERE tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
			SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
			
			IF @ErrorFound = 0 
			BEGIN
			--Add Affiliate for group subscriber
				INSERT INTO SubscriberAffiliate
					(ParentSubscriberID
					,ChildSubscriberID
					,StartDate
					,EndDate
					,AffiliateReferenceID
					)
				SELECT tmpSubscriberImport.GroupSubscriberID
					,@SubscriberId
					,@Today
					,'31-DEC-4949'
					,tmpSubscriberImport.AffiliateReferenceID
				FROM tmpSubscriberImport
				WHERE tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
				SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
			END
		END
		ELSE
		BEGIN
--2/12/13	James Woosnam	Put Update statement in If so doesn't run if error found
			IF @ErrorFound = 0
			BEGIN
	--5/3/10	James Woosnam	SIR2179 - Do WebUserName checks on Check not in Import (Whole section of code removed)

			--Exisiting Subscriber--
				UPDATE Subscriber
--12/2/20	James Woosnam	SIR5014 - Always truncate the subscriber name to 50 characters.  This means that the first name could be truncated but this shouldn't be a problem is the last name is that long.
				SET SubscriberName = LEFT(ISNULL(tmpSubscriberImport.LastName,'') + CASE WHEN ISNULL(tmpSubscriberImport.FirstName,'') <> '' THEN + ', ' + tmpSubscriberImport.FirstName ELSE '' END,50)
				  ,PrimaryCountryId = Country.CountryId
				  ,SubscriberCategory = dbo.fn485GetSubsciberCategory(tmpSubscriberImport.SubscriberCategory,tmpSubscriberImport.CompanyId)
				  ,FirstName = tmpSubscriberImport.FirstName
				  ,LastName = tmpSubscriberImport.LastName
				  ,IsReceiveMail = 1--13/1/22	James	SIR5388 - Always default IsReceiveMail to true
				  ,LastUpdatedDateTime = GETDATE()
				  ,LastUpdatedByUserId = @UserName
				FROM Subscriber	
					INNER JOIN tmpSubscriberImport
						LEFT JOIN Country
						On Country.CountryName = tmpSubscriberImport.CountryName
					ON tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
				WHERE Subscriber.SubscriberId = @SubscriberId
				SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
			END
		END
	
		UPDATE tmpSubscriberImport SET SubscriberId = @SubscriberId WHERE SubscriberImportId = @SubscriberImportId
		--****Affiliates****
		--If DupSelected then update the Affiliate ref with what is in the file or create a new affiliate
		--13/6/07	James Woosnam	Create Affiliation to GroupSubscriberId if one not already present SIR1188
		IF @ErrorFound = 0
		AND NOT EXISTS( SELECT  ParentSubscriberID 
						FROM SubscriberAffiliate
							INNER JOIN  tmpSubscriberImport
							ON tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
							AND tmpSubscriberImport.GroupSubscriberId = SubscriberAffiliate.ParentSUbscriberId
						WHERE SubscriberAffiliate.ChildSubscriberId  = @SubscriberId
						AND tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
						AND StartDate <= @Today
						AND EndDate >= @Today) 
		BEGIN
			INSERT INTO SubscriberAffiliate
				(ParentSubscriberID
				,ChildSubscriberID
				,StartDate
				,EndDate
				,AffiliateReferenceID
				)
			SELECT tmpSubscriberImport.GroupSubscriberId
				,@SubscriberId
				,@Today
				,'31-DEC-4949'
				,tmpSubscriberImport.AffiliateReferenceID
			FROM tmpSubscriberImport
			WHERE tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
			SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT		
		END
		ELSE 
		BEGIN
			IF @ErrorFound = 0
			BEGIN
				UPDATE SubscriberAffiliate
				SET AffiliateReferenceID =tmpSubscriberImport.AffiliateReferenceID
				FROM SubscriberAffiliate
					INNER JOIN  tmpSubscriberImport
					ON tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
					AND tmpSubscriberImport.GroupSubscriberId = SubscriberAffiliate.ParentSUbscriberId
				WHERE SubscriberAffiliate.ChildSubscriberId  = @SubscriberId
				AND tmpSubscriberImport.DuplicateAction = 'Selected'
				AND tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
				SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
			END
		END

		IF @ErrorFound = 0
		AND NOT EXISTS( SELECT  ParentSubscriberID 
						FROM SubscriberAffiliate
						WHERE ParentSubscriberID = 30000
						AND ChildSubscriberID = @SubscriberId
						AND StartDate <= @Today
						AND EndDate >= @Today) 
		BEGIN
		--Add Affiliate for 3000
			INSERT INTO SubscriberAffiliate
				(ParentSubscriberID
				,ChildSubscriberID
				,StartDate
				,EndDate
				,AffiliateReferenceID
				)
			SELECT 30000
				,@SubscriberId
				,@Today
				,'31-DEC-4949'
				,NULL
			FROM tmpSubscriberImport
				INNER JOIN Company
				On Company.CompanyId = tmpSubscriberImport.CompanyId
			WHERE tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
			SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
		END

		IF @ErrorFound = 0 
		AND NOT EXISTS( SELECT  ParentSubscriberID 
						FROM SubscriberAffiliate
						WHERE ParentSubscriberID = (SELECT GroupParentSubscriberId
													FROM tmpSubscriberImport
														INNER JOIN Company
														On Company.CompanyId = tmpSubscriberImport.CompanyId
													WHERE tmpSubscriberImport.SubscriberImportId = @SubscriberImportId )
						AND ChildSubscriberID = @SubscriberId
						AND StartDate <= @Today
						AND EndDate >= @Today) 
		BEGIN
		--Add Affiliate for Company
			INSERT INTO SubscriberAffiliate
				(ParentSubscriberID
				,ChildSubscriberID
				,StartDate
				,EndDate
				,SubscriberCategory)
			SELECT Company.GroupParentSubscriberId
				,@SubscriberId
				,@Today
				,'31-DEC-4949'
				,dbo.fn485GetSubsciberCategory(tmpSubscriberImport.SubscriberCategory,tmpSubscriberImport.CompanyId)
			FROM tmpSubscriberImport
				INNER JOIN Company
				On Company.CompanyId = tmpSubscriberImport.CompanyId
			WHERE tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
			SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
		END
		ELSE
		BEGIN
--2/12/13	James Woosnam	Put Update statement in If so doesn't run if error found
			IF @ErrorFound = 0
			BEGIN
	--18/5/07	James Woosnam	SIR1156 - Update SubscriberCategory on Import
				UPDATE SubscriberAffiliate
				SET SubscriberCategory = dbo.fn485GetSubsciberCategory(tmpSubscriberImport.SubscriberCategory,tmpSubscriberImport.CompanyId)
				FROM SubscriberAffiliate
					INNER JOIN tmpSubscriberImport
					ON tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
					INNER JOIN Company
					On Company.CompanyId = tmpSubscriberImport.CompanyId
					AND Company.GroupParentSubscriberId = SubscriberAffiliate.ParentSubscriberID
				WHERE ChildSubscriberID = @SubscriberId
				SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
			END
		END
		--****Addresses****
		IF @ErrorFound = 0
		BEGIN
--30/3/11	James Woosnam	SIR2401 - Use @CompanyAddressDescription
			EXEC sp484SubscriberImportAddressMaint
							@SubscriberImportId = @SubscriberImportId
							,@SubscriberId = @SubscriberID
							,@AddressType = 'Postal'
							,@AddressDescription = @CompanyAddressDescription
							,@AddressText = ''
							,@UserName = @UserName
							,@ReturnCode = @ErrorFound OUTPUT
							,@ErrorMessage = @ErrorMessage OUTPUT
			IF @ReturnCode <> 0 
			BEGIN 
				SET @ErrorFound = 1
			END			
		END
		--Set the DefaultPostalAddressId if not already set or set to a redundant address
		IF @ErrorFound = 0
		BEGIN
			UPDATE Subscriber
			SET DefaultPostalAddressId = SubscriberAddress.SubscriberAddressId
			FROM Subscriber
				INNER JOIN SubscriberAddress
				ON SubscriberAddress.SubscriberId = Subscriber.SubscriberId
				AND AddressType = 'Postal'
--30/3/11	James Woosnam	SIR2401 - only set default to main, unless there isn't a main.				
				AND (AddressDescription = 'Main'
				  OR (AddressDescription <> 'Main'
				    AND AddressDescription = @CompanyAddressDescription 
				    AND Not EXISTS(SELECT SubscriberAddressId 
									FROM SubscriberAddress sa
									WHERE sa.SubscriberId = Subscriber.SubscriberId
									AND sa.AddressType = 'Postal'
									AND sa.AddressDescription <> 'Main')
					 )
				  ) 
			WHERE Subscriber.SubscriberId = @SubscriberId
			AND (Subscriber.DefaultPostalAddressId IS NULL
--23/4/08	James Woosnam	Use DefaultPostalAddressId in check for update default adddress 
				OR Subscriber.DefaultPostalAddressId  IN (SELECT sa.SubscriberAddressId
															FROM SubscriberAddress sa
															WHERE sa.SubscriberId = Subscriber.SubscriberId
															AND sa.AddressType = 'Postal'
															AND sa.AddressDescription = 'Redundant')
				)
																	
			SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
		END 
		DECLARE @AddressText VARCHAR(255)
		IF @ErrorFound = 0
		BEGIN
--25/9/07	James Woosnam	SIR1327 - Remove trailing spaces from email "Main"
			SELECT @AddressText = EmailAddress FROM  tmpSubscriberImport WHERE tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
			EXEC sp484SubscriberImportAddressMaint
							@SubscriberImportId = @SubscriberImportId
							,@SubscriberId = @SubscriberID
							,@AddressType = 'Email'
							,@AddressDescription = 'Main'
							,@AddressText = @AddressText
							,@UserName = @UserName
							,@ReturnCode = @ErrorFound OUTPUT
							,@ErrorMessage = @ErrorMessage OUTPUT
			IF @ReturnCode <> 0 
			BEGIN 
				SET @ErrorFound = 1
			END			
		END
		IF @ErrorFound = 0
		BEGIN
			--Set oldest redundant email address as deleted
			IF EXISTS(SELECT SubscriberId
						FROM SubscriberAddress 
						WHERE SubscriberId =@SubscriberID
						AND AddressType = 'Email'
						AND AddressDescription = 'Redundant'
						GROUP BY SubscriberId
						HAVING COUNT(*) > 2 )
			BEGIN
				UPDATE SubscriberAddress
				SET AddressDescription = 'Deleted'
				FROM SubscriberAddress
				WHERE SubscriberId =@SubscriberID
				AND AddressType = 'Email'
				AND AddressDescription = 'Redundant'
				AND LastUpdatedDateTime = (SELECT MIN(LastUpdatedDateTime)
										FROM SubscriberAddress sa
										WHERE sa.SubscriberId =SubscriberAddress.SubscriberId
										AND sa.AddressType = 'Email'
										AND sa.AddressDescription = 'Redundant')
				SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
			END
		END
		
	--*****Order Lines ***
		IF @ErrorFound = 0 
		AND @OrderNumber <> 0 
		AND EXISTS(SELECT SubscriberImportId
					FROM tmpSubscriberImport
					WHERE SubscriberImportId = @SubscriberImportId
					AND (ISNULL(ExistingSubscriptionFound,0) = 0
						OR ExistingSubscriptionAction = 'Ignore')
					)
		BEGIN
			--11/4/08		James Woosnam	SIR1517 - Set Order line address to the one just loaded.
			DECLARE @SubscriberAddressId INT
			SELECT @SubscriberAddressId = SubscriberAddressId
			FROM SubscriberAddress
			WHERE SubscriberId = @SubscriberId
			AND AddressType = 'Postal'
			AND AddressDescription = @CompanyAddressDescription 
			SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
--26/11/19	James Woosnam	SIR4960 - pass @IfPresentAddAssociatedProductLine=1 to sp401AddSalesOrderSubscriberLine unless PrintedCopy='N"
			DECLARE @IfPresentAddAssociatedProductLine VARCHAR(1) = CASE 
														WHEN (SELECT PrintedCopy FROM tmpSubscriberImport WHERE SubscriberImportId = @SubscriberImportId)='N' THEN 0
														ELSE 1 END
			IF @ErrorFound = 0 
			BEGIN
				Execute sp401AddSalesOrderSubscriberLine @OrderNumber=@OrderNumber
													,@SubscriberId=@SubscriberId
													,@DeliveryAddressId=@SubscriberAddressId
													,@IfPresentAddAssociatedProductLine= @IfPresentAddAssociatedProductLine
				SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
			END
		END
	
		SET @ROw = @row + 1
	END --While loop of sub lines
 --29/11/18	James Woosnam	SIR4760 -Stop transaction here as it needs to be controlled from VB after password update
	--IF @TranBegun = 1
	--BEGIN
	--	IF @ErrorFound <> 0
	--	BEGIN
	--		ROLLBACK TRAN
	--		PRINT 'Tran rolled back'
	--	END
	--	ELSE
	--	BEGIN
	--		COMMIT TRAN
	--		PRINT 'Tran Commited'
	--	END
	--END
END --Import processing

If @ReturnCode = 0 
	--If an error been found with no return code then set the returncode to the ErrorCode
	SET @ReturnCode = @ErrorFound

RETurn (@ReturnCode)	
--select @ErrorMessage

GO
GRANT  EXECUTE ON sp483SubscriberImport TO PaDSSQLServerUser
