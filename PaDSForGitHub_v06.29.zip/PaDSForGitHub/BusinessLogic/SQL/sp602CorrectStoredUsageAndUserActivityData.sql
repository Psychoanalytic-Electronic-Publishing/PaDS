IF  exists (select * from dbo.sysobjects where id = object_id(N'sp602CorrectStoredUsageAndUserActivityData') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp602CorrectStoredUsageAndUserActivityData
GO
CREATE  PROCEDURE sp602CorrectStoredUsageAndUserActivityData (
		@BatchLogId INT = NULL
)
AS
DECLARE @Msg VARCHAR(MAX) =''
DECLARE @RowCount INT =0
BEGIN TRY
	EXEC sp029UpdateBatchLog @BatchLogId, ' CorrectStoredUsageAndUserActivityData SQL Started'

	UPDATE UserActionLog  
	SET ItemName = d.documentRef 
	FROM UserActionLog l
		inner join ContentDocuments d
		ON d.documentID = l.ItemId 
	where l.ItemName <> d.documentRef 
	SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' UserActionLog rows from ContentDocuments';EXEC sp029UpdateBatchLog @BatchLogId, @Msg
	UPDATE UserActionLog 
	SET ItemName = lm.ItemName 
	from UserActionLog  l
		INNER JOIN (
			select
			l.ItemId 
			,l.ItemName
			,l.TitleId 
			,l.TitleName 
			from UserActionLog  l
			WHERE l.DateTime = (SELECT MAX(l2.DateTime) FROM UserActionLog l2 WHERE l2.ItemId = l.ItemId AND l2.TitleId = l.TitleId  )
			) lm
		ON lm.ItemId = l.ItemId 
		AND lm.TitleId = l.TitleId 
	WHERE l.ItemName <> lm.ItemName 
	SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' UserActionLog rows from Last Record';EXEC sp029UpdateBatchLog @BatchLogId, @Msg

	UPDATE PEPUsage
	SET documentRef = d.documentRef 
	FROM PEPUsage l
		inner join ContentDocuments d
		ON d.documentID = l.DocumentId 
	where l.documentRef  <> d.documentRef
	SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' PEPUsage rows from ContentDocuments';EXEC sp029UpdateBatchLog @BatchLogId, @Msg
	UPDATE PEPUsage 
	SET documentRef  = lm.documentRef  
	from pepusage  l
		INNER JOIN (
			select
			l.DocumentId 
			,l.documentRef
			from pepusage  l
			WHERE l.DateTime = (SELECT MAX(l2.DateTime) FROM PEPUsage l2 WHERE l2.DocumentId = l.DocumentId  )
			) lm
		ON lm.documentID = l.DocumentId 
	where l.documentRef  <> lm.documentRef
	SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' PEPUsage rows from Last Record';EXEC sp029UpdateBatchLog @BatchLogId, @Msg

	UPDATE PEPUsageSummary  
	SET documentRef = d.documentRef 
	FROM PEPUsageSummary l
		inner join ContentDocuments d
		ON d.documentID = l.DocumentId 
	where l.documentRef  <> d.documentRef
	SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' PEPUsageSummary rows from ContentDocuments';EXEC sp029UpdateBatchLog @BatchLogId, @Msg
	UPDATE PEPUsageSummary 
	SET documentRef  = lm.documentRef  
	from PEPUsageSummary  l
		INNER JOIN (
			select
			l.DocumentId 
			,l.documentRef
			from PEPUsageSummary  l
			WHERE l.MonthStartDate  = (SELECT MAX(l2.MonthStartDate) FROM PEPUsageSummary l2 WHERE l2.DocumentId = l.DocumentId  )
			) lm
		ON lm.documentID = l.DocumentId 
	where l.documentRef  <> lm.documentRef
	SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' PEPUsageSummary rows from Last Record';EXEC sp029UpdateBatchLog @BatchLogId, @Msg

	UPDATE UsageByMonthDocument   
	SET Title  = d.documentRef 
	FROM UsageByMonthDocument l
		inner join ContentDocuments d
		ON d.documentID = l.document_id 
	where l.Title  <> d.documentRef
	SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' UsageByMonthDocument rows from ContentDocuments';EXEC sp029UpdateBatchLog @BatchLogId, @Msg

	UPDATE UsageByMonthDocument 
	SET Title  = lm.Title  
	from UsageByMonthDocument  l
		INNER JOIN (
			select
			l.document_id 
			,l.Title
			from UsageByMonthDocument  l
			WHERE l.MonthStart   = (SELECT MAX(l2.MonthStart) FROM UsageByMonthDocument l2 WHERE l2.document_id = l.document_id  )
			) lm
		ON lm.document_id = l.document_id 
	where l.Title  <> lm.Title
	SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' UsageByMonthDocument rows from Last Record';EXEC sp029UpdateBatchLog @BatchLogId, @Msg

END TRY
BEGIN CATCH
	SELECT @Msg ='sp602CorrectStoredUsageAndUserActivityData Failed:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE() ;EXEC sp029UpdateBatchLog @BatchLogId, @Msg
	RAISERROR ('%s', 18, 1,@Msg)
END CATCH	
GO
GRANT EXECUTE ON sp602CorrectStoredUsageAndUserActivityData to PaDSSQLServerUser
