
use [PaDS_Try_Logs]
exec sp_reinitsubscription @publication = N'PaDS_Try_Logs', @subscriber = N'all', @invalidate_snapshot = 1
exec sys.sp_startpublication_snapshot @publication = N'PaDS_Try_Logs'

use [PaDS_Live]
exec sp_reinitsubscription @publication = N'PaDS_Live', @subscriber = N'all', @invalidate_snapshot = 1
exec sys.sp_startpublication_snapshot @publication = N'PaDS_Live'

