--29/8/22	James			SIR5551 - Mark all individual users to not receive alerts
--09/03/23	Julian Gates	Insert ResetPadsTestData job on copied live database restored to test.
begin tran
USE Pads_Live
DECLARE @PaDS01PrivateIPAddress VARCHAR(100) = '172.30.4.89'
DECLARE @SQL as varchar(max)

/*
May 2021: The following sql must be run on the existing test PaDS
	SELECT sql= 'insert into stblparameters (ParameterName,ParameterType,UserID,ParameterValue) select ''' +  REPLACE(ParameterName,'''','''''') + ''',''' +  REPLACE(ParameterType,'''','''''') + ''',''' +  REPLACE(UserId,'''','''''') + ''',''' +  REPLACE(ParameterValue,'''','''''') + ''''  FROM [PaDS_Live].[dbo].[stblParameters]

The SQL insert statements should be pasted below overwriting the 2 example lines.
The parameter insert lines should NOT be saved in this file.
Before running this script delete all parameters from the copied live database.
*/
insert into stblparameters (ParameterName,ParameterType,UserID,ParameterValue) select 'aaa','aa`','aa`aa`','aa'
insert into stblparameters (ParameterName,ParameterType,UserID,ParameterValue) select 'AllContentSetIdsForAdmin','System','All','1'


--End of Insert SQL
UPDATE stblParameters SET ParameterValue = '\\' + @PaDS01PrivateIPAddress + '\c$\PaDS\SQLLive' where parameterName =  'SQLFileDirectory'
 

 UPDATE BatchJob
 Set BatchJobStatus = 'PendingPaused'
 --22/10/21		James	Add convert below, as was failing because text field
	,XMLParameters = REPLACE(CONVERT(VARCHAR(MAX),XMLParameters),'<ParameterValue>Integrated Security=SSPI;Initial Catalog=pads_live;Data Source=PaDS02;Connect Timeout=1;</ParameterValue>'
										  ,'<ParameterValue>Integrated Security=SSPI;Initial Catalog=PaDSSecondaryAuditLog;Data Source=PaDS01;Connect Timeout=1;</ParameterValue>')
 WHERE BatchJobStatus = 'Pending'

 --Insert ResetPadsTestData job on copied live database restored to test
  SET @SQL = 'DECLARE @LastBatchJobId INT = (SELECT MAX(BatchJobId ) FROM BatchJob) + 1
  INSERT into BatchJob (
		 BatchJobId
		,BatchJobName
		,BatchJobStatus
		,ScheduledStartDateTime
		,ActualStartDateTime
		,EndDateTime
		,CreatedDateTime
		,ReScheduleDelaySeconds
		,SubmittedByUserSessionId
		,ReScheduleFrom
		,XMLParameters
		)
	  SELECT 
	  BatchJobId = @LastBatchJobId
	  ,''ResetPadsTestData''
	  ,''PendingPaused''
	  ,GETDATE()
	  ,NULL
	  ,NULL
	  ,GetDate()
	  ,''86400''
	  ,NULL
	  ,''Start''
	  ,''<?xml version=''''1.0'''' standalone=''''yes''''?><NewDataSet>
  <Parameters>
    <ParameterName>ProcessToPerform</ParameterName>
    <ParameterValue>ResetPadsTestData</ParameterValue>
  </Parameters>
  <Parameters>
    <ParameterName>ConnectionString</ParameterName>
    <ParameterValue>UID=PaDSSQLSecurityUser;PWD=7nHk98Ak; Initial Catalog=Pads_Live;Data Source=PaDS01PrvIp;Connect Timeout=1</ParameterValue>
  </Parameters>
  <Parameters>
    <ParameterName>SubmittedByUserSessionId</ParameterName>
    <ParameterValue>6c6c7f96-ba32-4505-8734-331db2aa0762</ParameterValue>
  </Parameters>
  <Parameters>
    <ParameterName>SecondaryConnectionString</ParameterName>
    <ParameterValue>UID=PaDSSQLSecurityUser;PWD=7nHk98Ak; Initial Catalog=Pads_Live;Data Source=PaDS02PrvIp;Connect Timeout=3</ParameterValue>
  </Parameters>
</NewDataSet>'''

	execute(@sql)

  commit tran
  GO
  	IF NOT EXISTS(select * from master..sysdatabases where name = 'PaDSSecondaryAuditLog')
	BEGIN

	  CREATE DATABASE [PaDSSecondaryAuditLog]
		 CONTAINMENT = NONE
		 ON  PRIMARY 
		( NAME = N'PaDSSecondaryAuditLog', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\PaDSSecondaryAuditLog.mdf' , SIZE = 116736KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
		 LOG ON 
		( NAME = N'PaDSSecondaryAuditLog_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\PaDSSecondaryAuditLog_log.ldf' , SIZE = 20480KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
		
	
	END

GO
	USE [PaDSSecondaryAuditLog]
	if not exists(select * from sysobjects where name = 'SecondaryAuditLog' and type = 'u')
	BEGIN
		CREATE USER [PaDSSQLServerUser] FOR LOGIN [PaDSSQLServerUser]
		
		CREATE TABLE [dbo].[SecondaryAuditLog](
			[AuditLogId] [int] IDENTITY(1,1) NOT NULL,
			[TableName] [varchar](50) NOT NULL,
			[AuditDate] [datetime] NOT NULL,
			[UpdatedByUserName] [varchar](50) NULL,
			[UpdatedRecordFamily] [varchar](50) NULL,
			[UpdatedRecordFamilyKey] [varchar](50) NULL,
			[UpdatedRecordKey] [varchar](100) NULL,
			[ModificationType] [varchar](20) NULL,
			[AfterDescription] [varchar](max) NULL,
		 CONSTRAINT [PK_AuditLog] PRIMARY KEY CLUSTERED 
		(
			[AuditDate] DESC,
			[AuditLogId] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
		GRANT  SELECT,INSERT,UPDATE,DELETE ON [SecondaryAuditLog] TO PaDSSQLServerUser
	END

USE PaDS_Live 
go

Begin tran
--29/8/22	James		SIR5551 - Mark all individual users to not receive alerts
Update RemoteUser 
SET SendJournalAlerts=0
	,SendVideoAlerts =0
where (SendJournalAlerts = 1 OR SendVideoAlerts = 1)
and AuthorityLevel not in ( 'CompanyAdmin','SuperCompanyAdmin')


commit tran