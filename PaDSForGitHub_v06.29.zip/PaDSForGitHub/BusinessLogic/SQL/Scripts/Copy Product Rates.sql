--Copy Product rates for a product
begin tran
DECLARE @CopyFromProductCode VARCHAR(10) = 'IJP21C01'
DECLARE @CopyToProductCode VARCHAR(10) = 'IJP21C02'


DECLARE @Id INT
DECLARE @NewProductRateId INT


		INSERT INTO ProductRate (
			ProductCode
			,CurrencyCode
			,RateType
			,AccountType
			,SubscriberCategory
			,DeliveryArea
			,ProductRate
			,CreatedDateTime
			,CreatedByUserId
			,LastUpdatedDateTime
			,LastUpdatedByUserId
			,NewUserRateFlag
			,SellOnWebFlag

		)
		SELECT 
			ProductCode = @CopyToProductCode
			,CurrencyCode
			,RateType
			,AccountType
			,SubscriberCategory
			,DeliveryArea
			,ProductRate
			,CreatedDateTime = GETDATE()
			,CreatedByUserId = 1
			,LastUpdatedDateTime = GETDATE()
			,LastUpdatedByUserId = 1
			,NewUserRateFlag
			,SellOnWebFlag
		FROM ProductRate pr
		WHERE pr.ProductCode = @CopyFromProductCode  

		INSERT INTO ProductAffiliateRate(
			ProductCode
			,GroupSubscriberId
			,SubscriberCategory
			,ProductRateId
			,LastUpdatedDateTime
			,LastUpdatedByUserId

		)
		SELECT 
			ProductCode = @CopyToProductCode
			,GroupSubscriberId
			,SubscriberCategory
			,ProductRateId = (SELECT MAX(ProductRateId) FROM ProductRate r1 WHERE r1.ProductCode = r.ProductCode AND r1.SubscriberCategory = r.SubscriberCategory )
			,LastUpdatedDateTime = GETDATE()
			,LastUpdatedByUserId = 1
		FROM ProductAffiliateRate r
		WHERE r.ProductCode =  @CopyFromProductCode

		INSERT INTO ProductQualifyingProduct(
			ProductCode
			,QualifyingProductCode
			,SubscriberCategory
			,ProductRateId
			,MustBuyFlag
			,TerminatedSubscriptionsGracePeriodMonths
			,CheckAgainstOrderType
			,LastUpdatedDateTime
			,LastUpdatedByUserId

		)
		SELECT 
			ProductCode = @CopyToProductCode
			,QualifyingProductCode
			,SubscriberCategory
			,ProductRateId = (SELECT MAX(ProductRateId) FROM ProductRate r1 WHERE r1.ProductCode = r.ProductCode AND r1.SubscriberCategory = r.SubscriberCategory )
			,MustBuyFlag
			,TerminatedSubscriptionsGracePeriodMonths
			,CheckAgainstOrderType
			,LastUpdatedDateTime = GETDATE()
			,LastUpdatedByUserId = 1
		FROM ProductQualifyingProduct r
		WHERE r.ProductCode =  @CopyFromProductCode


select * from ProductRate where ProductCode = @CopyToProductCode
select * from ProductAffiliateRate where ProductCode = @CopyToProductCode
select * from ProductQualifyingProduct where ProductCode = @CopyToProductCode


rollback tran