Imports System.Net
Imports System.Net.Http
Imports System.Web.Http
Imports BusinessLogic
Namespace Controllers
    'May 2020   James Woosnam   SIR5039 - Initial Version
    Public Class AuthenticateController
        Inherits ApiController

        Public Class AuthenticationResponse
            Public session_id As String = Nothing
            Public is_valid_user_name As Boolean = False
            Public is_valid_logon As Boolean = False
            Public has_subscription As Boolean = False
            Public reason_id As Integer
            Public reason_str As String
        End Class
        Public Shared Function GetQueryString(ByVal request As HttpRequestMessage, ByVal key As String) As String
            Dim queryStrings = request.GetQueryNameValuePairs()
            If queryStrings Is Nothing Then Return Nothing
            Dim match = queryStrings.FirstOrDefault(Function(kv) String.Compare(kv.Key, key, True) = 0)
            If String.IsNullOrEmpty(match.Value) Then Return Nothing
            Return match.Value
        End Function
        ' GET: api/Authenticate/5
        '  Public Function GetValue(ByVal reqMess As HttpRequestMessage) As HttpResponseMessage ' PEPSecurity.AuthenticationResponse
        Public Function GetValue(ByVal user_name As String, password As String, Optional session_id As String = Nothing) As HttpResponseMessage ' PEPSecurity.AuthenticationResponse
            Dim resp As New AuthenticationResponse
            Dim statusCode As HttpStatusCode = HttpStatusCode.OK
            Try

                Dim stopWatch As Stopwatch = Stopwatch.StartNew

                Dim PaDSDB As BusinessLogic.Database = New PaDSDB().db

                If user_name = "" Then resp.reason_str += IIf(resp.reason_str = "", "", Environment.NewLine) + "UserName must be populated"
                If password = "" Then resp.reason_str += IIf(resp.reason_str = "", "", Environment.NewLine) + "Password must be populated"
                If resp.reason_str <> "" Then
                    statusCode = HttpStatusCode.BadRequest
                    Exit Try
                End If
                Try
                    If user_name.ToLower.Contains("error") Then
                        Throw New Exception("Text error found in username")
                    End If
                    Dim pepS As New PEPSecurity(PaDSDB)
                    Dim pepsAuthReq As New BusinessLogic.PEPSecurity.AuthenticationRequest
                    pepsAuthReq.UserName = user_name
                    pepsAuthReq.Password = password
                    With pepS.AuthenticateUser(pepsAuthReq)
                        resp.session_id = .SessionId
                        resp.is_valid_user_name = .IsValidUserName
                        resp.is_valid_logon = .IsValidLogon
                        resp.has_subscription = .HasSubscription
                        resp.reason_str = .ReasonDescription

                        If resp.reason_str <> "" Then
                            statusCode = HttpStatusCode.Unauthorized
                        End If
                        'If PaDSDB.GetParameterValue("ShowFullError") Then
                        '    stopWatch.Stop()
                        '    resp.reason_str += "Time:" & stopWatch.ElapsedMilliseconds & "ms"
                        'End If
                    End With


                Catch ex As Exception
                    Throw ex
                Finally
                    Try
                        PaDSDB.DBConnection.Close()
                        PaDSDB.DBConnection.Dispose()
                    Catch ex As Exception
                    End Try
                End Try

            Catch ex As Exception
                '****LOG ERROR****
                resp.reason_str = ex.Message
                Dim errMsg As String = "Unexpected error encountered."
                statusCode = HttpStatusCode.InternalServerError
                Try
                    If New PaDSDB().db.ShowFullError Then
                        errMsg += " ShowFullError:" & ex.Message
                    Else
                        errMsg += " Set ShowFullError for more."
                    End If
                Catch ex1 As Exception
                End Try
                Return Request.CreateResponse(Of String)(statusCode, errMsg)

            End Try

            Return Request.CreateResponse(Of AuthenticationResponse)(statusCode, resp)
        End Function

        ' POST: api/Authenticate
        'Public Function PostValue(<FromBody()> ByVal authReq As PEPSecurity.AuthenticationRequest) As PEPSecurity.AuthenticationResponse
        '    Dim resp As New PEPSecurity.AuthenticationResponse
        '    Try
        '        Dim pepS As New PEPSecurity(New PaDSDB().db)
        '        resp = pepS.AuthenticateUser(authReq)
        '    Catch ex As Exception
        '        '****LOG ERROR****
        '        resp.ReasonDescription = ex.Message
        '    End Try
        '    Return resp
        'End Function


    End Class
End Namespace