/*******************************************************
--31/10/06		James Woosnam	Cast values as money to stop rounding in vw420SubscriberTransactionsDetails
--30/1/12		James Woosnam	SIR2588 - Add IsBankedIfCashbook for AuditDebtorCreditors
--1/2/18	James Woosnam		SIR4572 - If Cashbook.BankDepositId set with dummy bank deposit Id then mark as banked with cashbook date

******************************************************/

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[vw420SubscriberTransactionsDetails]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw420SubscriberTransactionsDetails]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[vw421SubscriberTransactions1]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw421SubscriberTransactions1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[vw422SubscriberTransactions2]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw422SubscriberTransactions2]
GO

CREATE VIEW vw421SubscriberTransactions1
AS
--30/1/12		James Woosnam	SIR2588 - Add IsBankedIfCashbook for AuditDebtorCreditors
--1/2/18	James Woosnam		SIR4572 - If Cashbook.BankDepositId set with dummy bank deposit Id then mark as banked with cashbook date
SELECT     Cashbook.SubscriberID
	, Cashbook.CompanyID
	, Cashbook.CurrencyCode
	, Cashbook.OrderNumber
	, Null As PrimaryProductCode
--1/2/18	James Woosnam		SIR4572 - If Cashbook.BankDepositId set with dummy bank deposit Id then mark as banked with cashbook date
	, CASE 
		WHEN ISNULL(BankDeposit.BankDepositId,0) = 0 Then Cashbook.EntryDate 
		ELSE cast(Cast(BankDeposit.DateBanked As Varchar(11)) As DateTime)
	  END As [Date]
	,IsBankedIfCashbook = CASE WHEN ISNULL(Cashbook.BankDepositId,0) = 0 THEN 0 ELSE 1 END  
	, Cashbook.EntryType AS TransactionType
	, CASE Cashbook.EntryType 
		WHEN 'Payment' THEN Cashbook.PaymentType + ISNULL(' ' + CashBook.PaymentCardMerchant,'')
		ELSE Cashbook.EntryType 
	  END as ItemType
	, cast( Cashbook.Amount * -1  as money )AS Amount
	,cast(Cashbook.CashbookId as Varchar) as RecordKey
FROM  Cashbook 
	LEFT JOIN BankDeposit
	ON BankDeposit.BankDepositID = Cashbook.BankDepositId
WHERE CashbookStatus = 'Confirmed'
UNION All
SELECT   SalesOrder.SubscriberId
	, SalesOrder.CompanyId
	,SalesOrder.CurrencyCode
	,SalesOrder.OrderNumber
	,SalesOrder.PrimaryProductCode
	, SalesOrder.OrderDate AS [Date]
	,IsBankedIfCashbook = 1
	, 'Order' AS TransactionType
	, OrderType AS ItemType
	, CAST( SalesOrder.AmountGross AS MONEY ) AS Amount
	,cast(SalesOrder.OrderNumber AS Varchar) as RecordKey
FROM SalesOrder 
WHERE SalesOrderStatus IN ('Confirmed','Complete','Cancelled')
UNION All
SELECT   SalesOrder.SubscriberId
	, SalesOrder.CompanyId
	,SalesOrder.CurrencyCode
	,SalesOrder.OrderNumber
	,SalesOrder.PrimaryProductCode
	,  cast(Cast(SalesOrder.CancelledDate As Varchar(11)) As DateTime) AS [Date]
	,IsBankedIfCashbook = 1
	, 'CancelledOrder' AS TransactionType
	, OrderType AS ItemType
	, CAST(SalesOrder.AmountGross AS MONEY) * -1.00 AS Amount
	,cast(SalesOrder.OrderNumber as varchar) + 'C' as RecordKey
FROM SalesOrder 
WHERE SalesOrderStatus IN ('Cancelled')


GO


CREATE VIEW vw422SubscriberTransactions2
AS
SELECT	 t1.*
	,Company.CurrencyCode As BaseCurrencyCode
	,Rate.ConversionRate * t1.Amount As AmountInBaseCurrency
FROM vw421SubscriberTransactions1 t1
	INNER JOIN Company
	On t1.CompanyId = Company.CompanyId
	Left Join CurrencyConversionRate Rate
	On Rate.CompanyId = t1.CompanyId
	AND Rate.FromCurrencyCode = t1.CurrencyCode
	AND Rate.ToCurrencyCode = Company.CurrencyCode
	AND t1.[Date] Between Rate.StartDate and Rate.EndDate

GO

CREATE VIEW vw420SubscriberTransactionsDetails
AS
--31/10/06		James Woosnam	Cast values as money to stop rounding in vw420SubscriberTransactionsDetails
--30/1/12		James Woosnam	SIR2588 - Add IsBankedIfCashbook for AuditDebtorCreditors
SELECT    st.CompanyId
	, CompanyName
	, CountryName
	, CountryGroup
	, DeliveryArea
	, st.SubscriberId
	, Subscriber.SubscriberName + ' (' + cast(Subscriber.SubscriberId  as varchar) + ')' As SubscriberName
	, Subscriber.SubscriberCategory
	,Subscriber.VATNumber
	, CompanyAccount.AccountType
	, CompanyAccount.RateType
	, st.CurrencyCode
	, st.OrderNumber
	, st.PrimaryProductCode
	,st.IsBankedIfCashbook 
	, [Year]
	, [Quarter]
	, [Month]
	, st.[Date]
	, st.TransactionType
	, st.ItemType
--31/10/06		James Woosnam	Cast values as money to stop rounding
	, CAST(st.Amount AS MONEY) AS AmountInNative
	, CAST(st.AmountInBaseCurrency AS MONEY) AS AmountInBase
	,st.RecordKey
FROM vw422SubscriberTransactions2 st
	INNER JOIN Subscriber
	ON Subscriber.SubscriberId = st.SubscriberId
	INNER JOIN CompanyAccount
	ON CompanyAccount.SubscriberId = st.SubscriberId
	AND CompanyAccount.CompanyId = st.CompanyId
	INNER JOIN Company
	ON Company.CompanyId = st.CompanyId
	Left Join Country
	On Country.CountryId = Subscriber.PrimaryCountryId
	LEFT JOIN ReportingCalendar
	ON ReportingCalendar.CalendarDate = [Date]
--WHERE st.SubscriberId < 100
GO

