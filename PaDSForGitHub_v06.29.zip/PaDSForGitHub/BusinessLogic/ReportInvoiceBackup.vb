﻿'Modification History
'8/3/23       James Woosnam   SIR5514 - Initial Version


Public Class ReportInvoiceBackup
    Inherits ReportSSG
#Region "Class Properties"
    Dim BatchJobId As Integer = Nothing
    Dim OrderNumber As Integer = Nothing

#End Region

    Public Sub New(ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("InvoiceBackup", "Excel", db, SubmittedByUserSessionId)
    End Sub
    Public Sub New(ByVal OrderNumber As Integer, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("InvoiceBackup", "Excel", db, SubmittedByUserSessionId)
        Me.OrderNumber = OrderNumber
    End Sub
    Public Overloads Sub Submit()

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSessionId
        BatchJob.Parameters.Add("ReportName", Me.ReportName)
        BatchJob.Parameters.Add("OrderNumber", OrderNumber)
        BatchJob.CreateBatchJobEntry("RunReportSpreadsheetGearExcel", Me.db)

    End Sub

    Public Overloads Sub Execute(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.JobParameters = Parameters
        Me.OrderNumber = Parameters.GetValue("OrderNumber")
        Me.Execute()
    End Sub

    Public Overloads Sub Execute(Optional ByVal InBatchLog As BatchLog = Nothing)

        Dim batchLogCreatedHere As Boolean = False
        If InBatchLog Is Nothing Then
            Me.BatchLog = New BatchLog("Report-" & Me.ReportName _
                                          , ";OrderNumber=" & Me.OrderNumber _
                                         , Me.db _
                                         , BatchJobId _
                                         , Me.SubmittedByUserSessionId)
            batchLogCreatedHere = True
        Else
            Me.BatchLog = InBatchLog
        End If
        Try
            MyBase.Execute(Me.BatchLog)

            Me.ExcelWorkBook = SpreadsheetGear.Factory.GetWorkbook(Me.ExcelTemplate.FullName)

            Me.ReportSQL = "
SELECT
	s.SubscriberName 
	,s.SubscriberId
	,r.SubscriberCategory
	,l.ProductCode 
	,l.Quantity 
	,l.ProductRate
	,LineTotal = l.AmountProduct
FROM SalesOrder o
	INNER JOIN SalesOrderLine l
		INNER JOIN Subscriber s
		ON s.SubscriberId = l.SubscriberId 
		INNER JOIN ProductRate r
		ON r.ProductRateId = l.ProductRateId 
		LEFT JOIN (
			SELECT 
				i.SubscriberId
				,i.OrderNumber
				,ProfileChanges = MAX(ProfileChanges)
			FROM tmpSubscriberImport i
			WHERE i.SubscriberImportBatchId = (SELECT MAX(i2.SubscriberImportBatchId) FROM tmpSubscriberImport i2 WHERE i2.OrderNumber=i.OrderNumber and i2.SubscriberId=i.SubscriberId)
			GROUP BY
				i.SubscriberId
				,i.OrderNumber
			) i
		ON i.SubscriberId = s.SubscriberId
		AND i.OrderNumber = l.OrderNumber

	ON l.OrderNumber = o.OrderNumber 
	
WHERE o.OrderNumber = " & Me.OrderNumber & "
ORDER BY 
	s.SubscriberName 
	,l.ProductCode 

            "
            Dim tblRep As DataTable = db.GetDataTableFromSQL(Me.ReportSQL)

            Dim ProfileChangesSQL As String = "
SELECT
	s.SubscriberName 
	,s.SubscriberId
	,ProfileChanges = REPLACE(i.ProfileChanges,'||','||' + CHAR(10))
FROM tmpSubscriberImport i
	INNER JOIN Subscriber s
	ON s.SubscriberId = i.SubscriberId 
WHERE i.SubscriberImportBatchId = (SELECT MAX(i2.SubscriberImportBatchId) FROM tmpSubscriberImport i2 WHERE i2.OrderNumber=i.OrderNumber and i2.SubscriberId=i.SubscriberId AND ISNULL(i2.ProfileChanges,'')<>'')
AND i.OrderNumber = " & Me.OrderNumber & "
ORDER BY 
	s.SubscriberName 
            "
            Dim tblProfileChanges As DataTable = db.GetDataTableFromSQL(ProfileChangesSQL)

            Dim ExcludedLinesSQL As String = "
SELECT
	s.SubscriberName 
	,s.SubscriberId
FROM tmpSubscriberImport i
	INNER JOIN Subscriber s
	ON s.SubscriberId = i.SubscriberId 
WHERE i.SubscriberImportBatchId = (SELECT MAX(i2.SubscriberImportBatchId) FROM tmpSubscriberImport i2 WHERE i2.OrderNumber=i.OrderNumber and i2.SubscriberId=i.SubscriberId AND i2.ExistingSubscriptionFound = 1 AND i2.ExistingSubscriptionAction='GroupOnly' )
AND i.OrderNumber = " & Me.OrderNumber & "
ORDER BY 
	s.SubscriberName 

            "
            Dim tblExcludedLines As DataTable = db.GetDataTableFromSQL(ExcludedLinesSQL)


            Dim wsData As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Invoice Backup")
            Dim wsCriteria As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Criteria")

            wsCriteria.Cells("OrderNumber").Value = Me.OrderNumber
            wsCriteria.Cells("DateRun").Value = Now.ToString("dd-MMM-yyyy HH:mm")
            wsCriteria.Cells("UserName").Value = Me.SubmittedByUserSession.UserFullName
            '   wsCriteria.Cells("SQL").Value = Me.ReportSQL
            If tblRep.Rows.Count > 0 Then
                Dim rg As SpreadsheetGear.IRange
                If tblProfileChanges.Rows.Count > 0 Then
                    rg = wsData.Cells("ProfileChanges")
                    rg.CopyFromDataTable(tblProfileChanges, SpreadsheetGear.Data.SetDataFlags.InsertCells + SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders) '+ SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders)
                Else
                    Dim wsChanges As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Import Profile Changes")
                    wsChanges.Delete()
                End If
                If tblExcludedLines.Rows.Count > 0 Then
                    rg = wsData.Cells("ExcludedLines")
                    rg.CopyFromDataTable(tblExcludedLines, SpreadsheetGear.Data.SetDataFlags.InsertCells + SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders) '+ SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders)
                Else
                    Dim wsExcludedLines As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Excluded Lines")
                    wsExcludedLines.Delete()
                End If
                rg = wsData.Cells("MainData")

                rg.CopyFromDataTable(tblRep, SpreadsheetGear.Data.SetDataFlags.InsertCells + SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders) '+ SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders)

                End If

                ReportName = ReportName & " For Order No" & Me.OrderNumber
            ExcelWorkBook.SaveAs(Me.ReportFile.FullName, SpreadsheetGear.FileFormat.OpenXMLWorkbook)
            BatchLog.Update(Me.FileLink)

            If batchLogCreatedHere Then
                BatchLog.Update("Process Complete", "Complete")
            End If
        Catch ex As Exception
            BatchLog.Update("Report Failed:" & ex.Message, "Failed")
            Throw New Exception("Report Failed:" & ex.Message, ex)

        End Try

    End Sub

End Class
