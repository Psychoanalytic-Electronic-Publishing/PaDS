Imports Google.Apis.Auth.OAuth2
Imports EASendMail
Imports System.Security.Cryptography.X509Certificates
Public Class Email
    '10/9/21    James Woosnam   SIR5313 - Allow email to be used with any account by setting SMTPClient.Credentials before sending
    Public MailMessage As EASendMail.SmtpMail = Nothing
    Public UserSession As UserSession = Nothing

#Region "Class Properties"

    Public WriteOnly Property From() As String
        Set(ByVal Value As String)
            MailMessage.From = New MailAddress(Value)
        End Set
    End Property

    Public Property SendTo() As String
        Get
            Return MailMessage.To.ToString
        End Get
        Set(ByVal Value As String)
            MailMessage.To.Add(Value)
        End Set

    End Property

    Public Property CC() As String
        Get
            Return MailMessage.Cc.ToString
        End Get
        Set(ByVal Value As String)
            MailMessage.Cc.Add(Value)
        End Set
    End Property
    Public Property BCC() As String
        Get
            Return MailMessage.Bcc.ToString
        End Get
        Set(ByVal Value As String)
            MailMessage.Bcc.Add(Value)
        End Set
    End Property
    Public Property Subject() As String
        Get
            Return MailMessage.Subject()
        End Get
        Set(ByVal Value As String)
            MailMessage.Subject = Value
        End Set
    End Property
    Public Property Body() As String
        'Always HTML Body
        Get
            Return MailMessage.HtmlBody
        End Get
        Set(ByVal Value As String)
            MailMessage.HtmlBody = Value
        End Set
    End Property
    Private _db As BusinessLogic.Database = Nothing
    Private Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property
#End Region
    Public Sub New()
        'Can be opened without a DB and should still work, just!!
    End Sub
    Public Sub New(ByVal DB As BusinessLogic.Database)
        Me.db = DB
        Me.UserSession = UserSession
        Me.MailMessage = New EASendMail.SmtpMail(DB.GetParameterValue("EASendMailLicenceCode"))
    End Sub

    Public Sub Send()
        Dim additianlErrMsg As String = ""
        Try
            Dim serviceAccount As String = db.GetParameterValue("GoogleServiceAccount", "")

            Dim ioFileKey As New IO.FileInfo(db.GetParameterValue("GoogleOAUTHKeyFileLocation"))
            Dim sr As New IO.StreamReader(ioFileKey.FullName)
            sr.Close()

            If Not ioFileKey.Exists Then Throw New Exception("File:" & ioFileKey.FullName & " can't be found")
            Dim certificate = New X509Certificate2(ioFileKey.FullName,
                                               db.GetParameterValue("GoogleOAUTHPassword"),
                                               X509KeyStorageFlags.Exportable And X509KeyStorageFlags.PersistKeySet)

            ' G Suite user email address
            Dim gsuiteUser As String = db.GetParameterValue("SMTPUser")
            Dim gsuiteUserName As String = db.GetParameterValue("SMTPUserName")

            Dim serviceAccountCredentialInitializer = New ServiceAccountCredential.Initializer(serviceAccount) With {
                .User = gsuiteUser,
                .Scopes = {"https://mail.google.com/"}
            }.FromCertificate(certificate)

            Dim credential = New ServiceAccountCredential(serviceAccountCredentialInitializer)
            If Not credential.RequestAccessTokenAsync(System.Threading.CancellationToken.None).Result Then
                Throw New InvalidOperationException("Access token failed.")
            End If

            Dim server = New SmtpServer(db.GetParameterValue("SMTPServer"))
            server.ConnectType = SmtpConnectType.ConnectSSLAuto
            server.User = gsuiteUser
            server.Password = credential.Token.AccessToken
            server.AuthType = SmtpAuthType.XOAUTH2

            MailMessage.From = New MailAddress(gsuiteUserName, gsuiteUser)

            Dim smtp = New SmtpClient()
            '26/4/22    James Woosnam   Get SurpressEmails in tryCatch as sometimes there is no DB
            Dim sendEmail As Boolean = True
            Try
                sendEmail = Not CBool(db.GetParameterValue("SurpressEmails", False))
            Catch ex As Exception
            End Try
            If sendEmail Then smtp.SendMail(server, MailMessage)


        Catch ex As Exception
            Throw New Exception("SendEmail Failed:" & ex.Message & additianlErrMsg, ex)
        End Try

    End Sub

    Public Sub Attach(ByVal FileName As String)
        If Not System.IO.File.Exists(FileName) Then
            Throw New Exception("Can't add email attachment:" & FileName)
        End If
        MailMessage.AddAttachment(FileName)
    End Sub
    Public Sub SendErrorEmail(ByVal Subject As String, ByVal ErrorMessage As String, Optional ByVal AttachmentFileName As String = "")
        '29/10/08   James Woosnam   SIR1614 - Move SendErrorEmail from BatchControl
        Dim RegistryKey As String = ""
        Try
            RegistryKey = db.GetParameterValue("ServiceRegistryKey")
        Catch ex As Exception
        End Try
        Dim stdCde As New BusinessLogic.StdCode
        Try
            Me.SendTo = stdCde.ReadRegValue(Microsoft.Win32.RegistryHive.LocalMachine, RegistryKey, "ErrorToEmailAddress", "")
            If Me.SendTo = "" Then
                Me.SendTo = "Support@Zedra.co.uk"
            End If
        Catch ex As Exception
            Me.SendTo = "Support@Zedra.co.uk"
        End Try
        Try
            Me.From = stdCde.ReadRegValue(Microsoft.Win32.RegistryHive.LocalMachine, RegistryKey, "ErrorFromEmailAddress", "")
        Catch ex As Exception
            'If nothing in Reg then just use support
            Me.From = "Support@Zedra.co.uk"
        End Try
        If Subject = "" Then
            Subject = "PaDS Web Error"
        Else
            Me.Subject = Subject
        End If
        Me.Body = "<html>"
        Me.Body += "    <head></head>"
        Me.Body += "    <body>"
        Try
            Me.Body += "<br>Version:" & Me.db.PaDSVersion
        Catch ex As Exception
        End Try
        Try
            Me.Body += "<br>ConnectionString:" & Me.db.DBConnection.ConnectionString
        Catch ex As Exception
        End Try
        Try
            Dim host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName())

            For Each ip In host.AddressList

                If ip.AddressFamily = System.Net.Sockets.AddressFamily.InterNetwork Then
                    Me.Body += "<br>IP Address:" & ip.ToString
                End If
            Next
        Catch ex As Exception
        End Try
        Try
            Me.Body += "<br>Server Description::" & Me.db.GetParameterValue("ServerDescription")
        Catch ex As Exception
            Me.Body += "<br>Server Description::*** stblParameter ServerDescription not populated *****"
        End Try
        Me.Body += "        <br>" & ErrorMessage.Replace(vbCrLf, "<br>")
        Me.Body += "    </body>"
        Me.Body += "</html>"

        If AttachmentFileName <> "" Then
            Try
                Me.Attach(AttachmentFileName)
            Catch ex As Exception
            End Try
        End If
        Try
            Me.Send()
        Catch ex As Exception
            Throw New Exception("Send in SendErrorEmail failed:" & ex.ToString & "}}}}")
        End Try
    End Sub
End Class
