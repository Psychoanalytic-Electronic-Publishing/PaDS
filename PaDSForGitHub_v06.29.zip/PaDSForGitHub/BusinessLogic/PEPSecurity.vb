﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Globalization
Imports BusinessLogic.ContentSet
Imports System.Net

Public Class PEPSecurity
    'May 2020   James Woosnam   SIR5039 - Initial Version
    '19/10/20   James Woosnam   SIR5140 - Add additional user fields
    '2/3/21     James Woosnam   Use the UserType from Sessiondata & add ExtraSessionLogComent so X-Forwarded-For can be logged from controllers
    '12/9/21    James Woosnam   SIR5315 - Don't let GroupUsers logon directly from PEP
    '03/12/21   Julian Gates    SIR5356 - Change Auto logon ReasonDescriptionMsg text.
    '20/12/21   James Woosnam   SIR5390 - Enhanced message if user already emailed in AuthenticateUser
    '5/1/22	James Woosnam	SIR5401 - sp237 now returns autologon orders so only check autologon if view of autologon orders is empty
    '2/3/22     James Woosnam   SIR5433 - Add more descriptive message if existing session is no longer valid because no order can be found as the subscription has expired
    '3/11/22   James Woosnam   SIR5533 - Add UserDisqusPayload & GetDisqusPayload
    '18/1/23    James Woosnam   SIR5621 - Stop duplicate for admin users linked to multiple subscribers.
    '17/02/23   Julian Gates    SIR5566 - Add new better message and link to PaDS for GroupRenewer & GroupAdmin user trying to log onto PEP in Function AuthenticateUser

    Public Class AuthenticationRequest
        Public UserName As String
        Public Password As String
        Public SessionId As String
    End Class
    Public Class AuthenticationResponse
        Public SessionId As String = Nothing
        Public SessionExpires As Integer = Nothing
        Public IsValidUserName As Boolean = False
        Public IsValidLogon As Boolean = False
        Public HasSubscription As Boolean = False
        Public ReasonId As HttpStatusCode = HttpStatusCode.OK
        Public ReasonStr As String = ""
        'Public ReasonDescription As String
    End Class


    Public Class SessionLogoutResponse

        Public LogoutSuccess As Boolean = Nothing
        Public NewSessionId As String = Nothing
        Public ReasonDescription As String = Nothing

    End Class

    Public Class AuthoriseRequest
        Public SessionId As String
        Public DocumentId As String
        Public Year As Integer
        Public ReasonForCheck As String
    End Class
    Public Class AuthoriseResponse
        Public SessionId As String
        Public DocumentId As String
        Public Permit As Boolean = False
        Public HasCurrentAccess As Boolean = False
        Public HasArchiveAccess As Boolean = False
        Public ReasonDescription As String = Nothing
        Public ReasonCode As HttpStatusCode = HttpStatusCode.InternalServerError
    End Class
#Region "Class Properties"
    Dim UserIdForLogging As String = 0
    Public Property SessionLogExtraComment As String
        Get
            Return Me.UserSess.SessionLogExtraComment
        End Get
        Set(value As String)
            Me.UserSess.SessionLogExtraComment = value
        End Set
    End Property
    Private _db As Database = Nothing
    Public Property db() As Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As Database)

            Me._db = value
        End Set
    End Property
    Private _logs As Logs = Nothing
    Public Property Logs As Logs
        Get
            If _logs Is Nothing Then
                _logs = New BusinessLogic.Logs(db, UserSess)
            Else
                If Not _logs.UserSession.LoggedIn Then
                    _logs = New BusinessLogic.Logs(db, UserSess)
                End If
            End If
            Return _logs
        End Get
        Set(value As Logs)
            _logs = value
        End Set
    End Property
    Private _UserSess As UserSession = Nothing
    Public ReadOnly Property UserSess As UserSession
        Get
            If _UserSess Is Nothing Then
                _UserSess = New BusinessLogic.UserSession(db)
            End If
            Return _UserSess
        End Get
    End Property

    Dim RemoteIPAddress As String = Nothing
    Public ReadOnly Property UserHasIJPOpenSubscription As Boolean
        '14/11/22   James Woosnam   SIR5533 - Add HasIJPOpenSubscription for UseClass and GetDisqusPayload 
        Get
            Dim IJPOpenContentSets() As String = db.GetParameterValue("IJPOpenContentSets", "9").Split(",")
            Dim hasIJPOpenAccess As Boolean = False
            If UserSess.Data("ContentSets") IsNot Nothing Then
                For Each IJPOpenSet As String In IJPOpenContentSets
                    For Each UserSet As String In UserSess.Data("ContentSets").Split(",")
                        If IJPOpenSet = UserSet Then hasIJPOpenAccess = True
                    Next
                Next
            End If
            Return hasIJPOpenAccess
        End Get
    End Property
#End Region
    Public Sub New(db As Database, RemoteIPAddress As String)
        Me.db = db
        Me.RemoteIPAddress = RemoteIPAddress
    End Sub
    Public Sub New(db As Database, RemoteIPAddress As String, UserSession As UserSession)
        Me.db = db
        Me.RemoteIPAddress = RemoteIPAddress
        Me._UserSess = UserSession
    End Sub
#Region "Actions"
    Public Function AuthoriseDocument(AuthRequest As AuthoriseRequest) As AuthoriseResponse
        Dim authResp As New AuthoriseResponse
        authResp.SessionId = AuthRequest.SessionId
        authResp.DocumentId = AuthRequest.DocumentId
        Try
            Dim OrderNumberForLogging As Integer = Nothing
            Try
                If AuthRequest.SessionId = "" Then
                    authResp.ReasonDescription += IIf(authResp.ReasonDescription = "", "", Environment.NewLine) & "No SessionId passed."
                    authResp.ReasonCode = HttpStatusCode.BadRequest
                    Exit Try
                End If
                '16/12/20   James Woosnam   SIR5168 - Allow universal access for some documents dependant on a regular express check
                authResp.ReasonCode = HttpStatusCode.OK '28/4/21    once we get this far OK unless code error
                Dim pattern As String = db.GetParameterValue("UniversalContentRegPtrn", "0000A")
                Try
                    If System.Text.RegularExpressions.Regex.IsMatch(AuthRequest.DocumentId, pattern) Then
                        authResp.Permit = True 'Always permitted for .0000A, will keeping going through checks to pick up user info further down
                        authResp.ReasonDescription += IIf(authResp.ReasonDescription = "", "", Environment.NewLine) & "Permitted via universal access check"
                    End If
                Catch ex As Exception
                    Throw New Exception("PEPWebUniversalContentAcessRegularExpression:'" & pattern & "' failed:" & ex.Message)
                End Try

                Try
                    UserSess.Restore(AuthRequest.SessionId, False)
                Catch ex As Exception
                    authResp.ReasonDescription = IIf(authResp.ReasonDescription = "", "", Environment.NewLine) & ex.Message
                    authResp.ReasonCode = HttpStatusCode.Unauthorized
                    Exit Try
                End Try
                If Not UserSess.LoggedIn Then
                    If authResp.ReasonDescription = "" Then authResp.ReasonDescription = "Session has not been authenticated"
                Else
                    UserIdForLogging = UserSess.UserId 'set here incase we exit below for universal docs
                End If
                If authResp.ReasonDescription <> "" Then
                    Exit Try
                End If
                If AuthRequest.DocumentId.Contains("ExpireSession") Then
                    'Special testing code to expire session
                    UserSess.Data("Expires") = Now.AddDays(-1)
                    authResp.ReasonDescription = "As DocId contains ExpireSession the session was expired for testing."
                    authResp.ReasonCode = HttpStatusCode.RequestTimeout
                    Exit Try
                End If
                If UserSess.Data("ContentSets") = Nothing Then
                    authResp.ReasonDescription += IIf(authResp.ReasonDescription = "", "", Environment.NewLine) & "User has no access to PEP full content."
                Else
                    Dim contentSetIds As New ArrayList
                    Try
                        For Each contSet As String In UserSess.Data("ContentSets").ToString.Split(",")
                            If IsNumeric(contSet) Then
                                contentSetIds.Add(CInt(contSet))
                            Else
                                authResp.ReasonDescription += IIf(authResp.ReasonDescription = "", "", Environment.NewLine) & "ContentSet:" & contSet & " is not a valid number"
                            End If
                        Next

                    Catch ex As Exception
                        Throw ex
                    End Try
                End If

                If AuthRequest.DocumentId = "" Then
                    authResp.ReasonDescription += IIf(authResp.ReasonDescription = "", "", Environment.NewLine) & "No DocumentId passed."
                End If
                If Not IsNumeric(AuthRequest.Year) Then
                    authResp.ReasonDescription += IIf(authResp.ReasonDescription = "", "", Environment.NewLine) & "Year '" & AuthRequest.Year & "' is not a valid number."
                End If
                If authResp.ReasonDescription <> Nothing Then
                    Exit Try
                End If
                Dim docIdParts As String() = AuthRequest.DocumentId.Split(".")

                Dim sql As String = ""
                sql = "
                SELECT
	                c.PEPCode 
	                ,c.embargoYears 
	                ,c.SourceType 
                    ,c.accessClassification
                    ,c.PEPRelease
	                ,cs.ContentSetId 
                    ,cs.ContentSetName
                    ,cs.ContentSetStatus 
                    ,cs.ContentSetStatus 
                    ,cs.GivesAccessToAllCurrentContent 
                    ,cs.GivesAccessToAllArchiveContent 
	                ,css.ContentSetSourceId 
	                ,css.IncludeAllSourceItems 
	                ,css.ExcludeEmbargoedYears 
	                ,css.EmbargoedYearsOnly 
	                ,css.OverrideEmbargoYears 
	                ,css.SingleYearOnly 
                FROM (
		                SELECT
		                    SourceType = 'Journal' 
			                ,c.PEPCode 
			                ,c.embargoYears 
                            ,c.accessClassification
                            ,c.PEPRelease
		                FROM ContentJournals c
		                UNION
		                SELECT
		                    SourceType = 'Book' 
			                ,c.PEPCode 
			                ,c.embargoYears 
                            ,c.accessClassification
                            ,c.PEPRelease
		                FROM ContentBooks c
		                UNION
		                SELECT
		                    SourceType = 'Video' 
			                ,c.PEPCode 
			                ,c.embargoYears 
                            ,c.accessClassification
                            ,c.PEPRelease
		                FROM ContentVideos c
	                ) c
                    LEFT JOIN ContentSet cs
                    ON cs.ContentSetId IN (" & UserSess.Data("ContentSets") & ")
                    AND cs.ContentSetStatus = 'Active'
	                LEFT JOIN ContentSetSource css
	                ON css.ContentSetId = cs.ContentSetId 
	                AND c.sourceType = css.SourceType 
                WHERE c.PEPCode = @PEPCode
            "
                Dim cmd As New SqlCommand("", db.DBConnection, db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PEPCode", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                                              docIdParts(0)))
                If docIdParts.Length > 1 Then
                    '6/10/20    James Woosnam   SIR5135 - For books the PEPCode is the concatination from the first 2 parts of the docid, so add an OR to the query.
                    '                           So a user requests GW.004.0311A which is has a PEPCode in books of GW004
                    sql += "
                OR c.PEPCode = @Part1and2Code
                            "
                    cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Part1and2Code", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                                              docIdParts(0) & docIdParts(1)))
                End If
                cmd.CommandText = sql 'set here after OR added
                Dim sets As DataTable = db.GetDataTableFromSQL(cmd)
                If sets.Rows.Count = 0 Then
                    authResp.ReasonDescription += IIf(authResp.ReasonDescription = "", "", Environment.NewLine) & "Details of Item:" & docIdParts(0) & " can't be found on PaDS."
                    Exit Try
                End If
                If db.IsDBNull(sets.Rows(0)("ContentSetId")) Then
                    authResp.ReasonDescription += IIf(authResp.ReasonDescription = "", "", Environment.NewLine) & "You do not have any access to PEP Content."
                    Exit Try
                End If
                Dim vwActive As New DataView(sets, "ContentSetStatus='Active'", "", DataViewRowState.CurrentRows)
                If vwActive.Count = 0 Then
                    authResp.ReasonDescription += IIf(authResp.ReasonDescription = "", "", Environment.NewLine) & "You are not linked to any Active ContentSets."
                    Exit Try
                End If
                Dim vwActiveWithSource As New DataView(sets, "ContentSetStatus='Active' AND ContentSetSourceId IS NOT NULL", "", DataViewRowState.CurrentRows)
                If vwActiveWithSource.Count = 0 Then
                    authResp.ReasonDescription += IIf(authResp.ReasonDescription = "", "", Environment.NewLine) & "Your subscription doesn't give any access to content type '" & vwActive(0)("SourceType") & "'."
                    Exit Try
                End If
                Dim setDeniedReason As String = Nothing
                Dim contentSetNames As String = ""

                For Each rc As DataRowView In vwActiveWithSource
                    contentSetNames += IIf(contentSetNames = "", "", ", ") & rc("ContentSetName")
                Next
                For Each rc As DataRowView In vwActiveWithSource
                    Dim msg As String = ""
                    Dim myTI As TextInfo = New CultureInfo("en-US", False).TextInfo
                    Dim srcType As ContentSetSourceTypes = [Enum].Parse(GetType(ContentSetSourceTypes), myTI.ToTitleCase(rc("SourceType").ToString))

                    If Me.IsPermited(srcType,
                                                                db.IsDBNull(rc("IncludeAllSourceItems"), 0),
                                                                db.IsDBNull(rc("ExcludeEmbargoedYears"), 0),
                                                                db.IsDBNull(rc("EmbargoedYearsOnly"), 0),
                                                                db.IsDBNull(rc("OverrideEmbargoYears"), -1),
                                                                db.IsDBNull(rc("SingleYearOnly"), -1),
                                                                db.IsDBNull(rc("embargoYears"), 0),
                                                                db.IsDBNull(rc("accessClassification"), ""),
                                                                IIf(Not IsNumeric(db.IsDBNull(rc("PEPRelease"), "1900")), "1900", db.IsDBNull(rc("PEPRelease"), "1900")),
                                                                AuthRequest.DocumentId,
                                                                AuthRequest.Year,
                                                                rc("ContentSetSourceId"),
                                                                msg) Then
                        authResp.Permit = True
                    Else
                        If setDeniedReason = Nothing Then setDeniedReason += IIf(setDeniedReason = "", "", Environment.NewLine) & "Your subscription gives you access to " & contentSetNames & ", but access to this document is denied because " & msg
                    End If
                    '
                    If db.IsDBNull(rc("GivesAccessToAllCurrentContent"), 0) Then authResp.HasCurrentAccess = True
                    If db.IsDBNull(rc("GivesAccessToAllArchiveContent"), 0) Then authResp.HasArchiveAccess = True
                    If authResp.Permit Then
                        '10/12/20   James Woosnam   SIR5165 - If Permitted use the SubscriptionOrders in session to get OrderNumber
                        If UserSess.Data("SubscriptionOrders") IsNot Nothing Then
                            Dim ds As DataSet = Newtonsoft.Json.JsonConvert.DeserializeObject(Of DataSet)(UserSess.Data("SubscriptionOrders"))
                            If ds.Tables("Orders") IsNot Nothing Then
                                Dim vwOrders As New DataView(ds.Tables("Orders"), "", "RecurringSubscriptionEndDate DESC", DataViewRowState.CurrentRows)
                                For Each rOrders As DataRowView In vwOrders
                                    If rOrders("ContentSetId") = rc("ContentSetId") Then
                                        OrderNumberForLogging = rOrders("OrderNumber")
                                        Exit For
                                    End If

                                Next
                            End If
                            Exit For 'Jump out once first one found, unlickly to be more than 1
                        End If

                    End If
                Next
                If setDeniedReason <> Nothing And Not authResp.Permit Then 'only denied if no content sets give access
                    authResp.ReasonDescription += IIf(authResp.ReasonDescription = "", "", Environment.NewLine) & setDeniedReason
                    Exit Try
                End If
                authResp.ReasonCode = HttpStatusCode.OK
            Catch ex As Exception
                Logs.LogErrorMessage(ex)
                authResp.ReasonDescription = "Unexpected Error"
                authResp.ReasonCode = HttpStatusCode.InternalServerError
                If db.ShowFullError Then authResp.ReasonDescription += " ShowFullError:" & ex.Message

            Finally
                Try
                    Logs.WritePEPWebAuthoriseLog(LogonLocation:="PEPSecurity",
                                                                    LogonStatus:=IIf(authResp.Permit, "Success", "Failed"),
                                                                    SubscriberId:=UserSess.Data("SubscriberId"),
                                                                    OrderNumber:=OrderNumberForLogging,
                                                                    UserName:=UserIdForLogging,
                                                                    ReasonForCheck:=AuthRequest.ReasonForCheck,
                                                                    DocumentId:=AuthRequest.DocumentId,
                                                                    AdditionalDetails:=authResp.ReasonDescription,
                                                                    RemoteIPAddress:=Me.RemoteIPAddress
                                           )
                Catch ex As Exception
                End Try

            End Try
        Catch ex As Exception
            authResp.ReasonDescription = HandleError(ex)
            authResp.ReasonCode = HttpStatusCode.InternalServerError
        Finally
            Try
                Logs.WriteSessionLog(LogType:="PEPSecurity",
                                                             PageId:="002",
                                                             PageTitle:="AuthoriseDocument",
                                                             UserId:=UserIdForLogging,
                                                             UserName:=UserSess.UserName,
                                                             RemoteIPAddress:=Me.RemoteIPAddress,
                                                             Comment:=authResp.ReasonDescription + UserSess.SessionLogExtraComment,
                                                             IsReadOnlyOnSecondary:=False,
                                                             IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                                                             IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)
            Catch ex As Exception
            End Try
        End Try


        Return authResp
    End Function
    Function IsPermited(SourceType As ContentSetSourceTypes,
                                            IncludeAllSourceItems As String,
                                            ExcludeEmbargoedYears As Boolean,
                                            EmbargoedYearsOnly As Boolean,
                                            OverrideEmbargoYears As Integer,
                                            SingleYearOnly As Integer,
                                            ItemEmbargoedYears As Integer,
                                            accessClassification As String,
                                            PEPReleaseYear As String,
                                            RequestedDocumentId As String,
                                            RequestedDocumentYear As Integer,
                                            ContentSetSourceId As Integer,
                                            ByRef IsNotPermittedReasen As String
                                            ) As Boolean
        IsPermited = False
        Try
            Dim sql As String = ""
            Dim currrentYear As Integer = db.GetParameterValue("CurrentContentYear", "2020")

            '17//22   James Woosnam   SIR5387 - IsPermited - Check items against allowable AccessClassifications, if accessclassification of document is spaces then permit as before OPAS updates
            If accessClassification <> "" Then
                sql = "
SELECT DISTINCT 
    AccessClassification
FROM ContentSetAccessClassification ac
    INNER JOIN ContentSetSource s
    ON s.ContentSetId = ac.ContentSetId
    AND s.ContentSetSourceId=" & ContentSetSourceId & "
"
                Dim tClassifications As DataTable = db.GetDataTableFromSQL(sql)
                Dim AllowedClassifications As String = ""
                Dim AccessClassificationFound As Boolean = False
                For Each row As DataRow In tClassifications.Rows
                    If row("AccessClassification").ToString.ToLower = accessClassification.ToLower Then AccessClassificationFound = True
                    AllowedClassifications += IIf(AllowedClassifications = "", "", ",") & row("AccessClassification")
                Next
                If Not AccessClassificationFound Then
                    IsNotPermittedReasen = "it is marked as '" & accessClassification & "' and your subscription only allows you access to " & AllowedClassifications & "."
                    Return False
                End If
            End If

            '24/1/22    James Woosnam   If admin content set then skip release year check
            If UserSess.Data("ContentSets") <> db.GetParameterValue("AllContentSetIdsForAdmin") And CInt(PEPReleaseYear) > currrentYear Then
                IsNotPermittedReasen = "it is in the " & PEPReleaseYear & " release and can only be viewed as an abstract."
                Return False
            End If
            Dim docIdParts As String() = RequestedDocumentId.Split(".")
            'first check whether the requested doc is permitted, without conwidering embargoed years
            If IncludeAllSourceItems Then
                IsPermited = True
            Else
                'lookup specific content item
                sql = "SELECT * FROM ContentSetSourceItem WHERE ContentSetSourceId=" & ContentSetSourceId
                Dim tItems As DataTable = db.GetDataTableFromSQL(sql)
                For Each r As DataRow In tItems.Rows
                    If db.IsDBNull(r("DocumentId")) Then
                        If db.IsDBNull(r("Volume")) Then
                            If db.IsDBNull(r("ContentCode"), "") = docIdParts(0) Then
                                IsPermited = True
                            End If
                        Else
                            If db.IsDBNull(r("ContentCode"), "") = docIdParts(0) And r("Volume") = docIdParts(1) Then
                                IsPermited = True
                            End If
                        End If
                    Else
                        If r("DocumentId") = RequestedDocumentId Then
                            IsPermited = True
                        End If
                    End If
                Next
                If Not IsPermited Then IsNotPermittedReasen = "the document, volume or journal has not been explicitly granted access in this set."
            End If
            'if doc permitted check embargoed years
            If IsPermited Then
                IsPermited = False 'again assuming nothing permitted
                Dim embargoedYears As Integer = ItemEmbargoedYears
                If OverrideEmbargoYears <> -1 Then embargoedYears = OverrideEmbargoYears
                If embargoedYears = 0 Then
                    'if embargoed years = 0 then no check neccessary as years not relavant
                    IsPermited = True
                Else
                    If RequestedDocumentYear < 1909 Or RequestedDocumentYear > 2040 Then
                        IsNotPermittedReasen = "year '" & RequestedDocumentYear & "' is not a year between 1909 and 2040."
                    End If
                    If ExcludeEmbargoedYears Then
                        If currrentYear - RequestedDocumentYear <= embargoedYears Then
                            IsNotPermittedReasen = "" & RequestedDocumentYear & " is in the embargoed years (" & embargoedYears & ")."
                        Else
                            IsPermited = True
                        End If
                    ElseIf EmbargoedYearsOnly Then
                        If currrentYear - RequestedDocumentYear > embargoedYears Then
                            IsNotPermittedReasen = "" & RequestedDocumentYear & " is not in the embargoed years (" & embargoedYears & ")."
                        Else
                            IsPermited = True
                        End If
                    ElseIf SingleYearOnly <> -1 Then
                        If currrentYear - RequestedDocumentYear <> SingleYearOnly Then
                            IsNotPermittedReasen = "" & RequestedDocumentYear & " is not the single permitted year(" & SingleYearOnly & ")."
                        Else
                            IsPermited = True
                        End If
                    Else
                        IsPermited = True
                    End If
                End If


            End If

        Catch ex As Exception
            Throw ex
        End Try

        Return IsPermited
    End Function



    Public Function SessionLogout(SessionId As String) As SessionLogoutResponse
        Dim Res As New SessionLogoutResponse
        Try
            UserSess.Restore(SessionId)

            If UserSess.Expires < Now() Then
                Res.ReasonDescription = "Session expired"
                Exit Try
            End If
            Logs = New Logs(db, New UserSession(UserSess.UserSessionIdGUID, db)) 'make sure log to old session
            UserSess.Logout() 'Old session set to logged out and new session created
            Res.NewSessionId = UserSess.UserSessionId
            Res.LogoutSuccess = True

        Catch ex As Exception
            Res.ReasonDescription = HandleError(ex)
        Finally
            Try
                Logs.WriteSessionLog(LogType:="PEPSecurity",
                                                             PageId:="030",
                                                             PageTitle:="SessionLogout",
                                                             UserId:=UserIdForLogging,
                                                             UserName:=UserSess.UserName,
                                                             RemoteIPAddress:=Me.RemoteIPAddress,
                                                             Comment:=Res.ReasonDescription + UserSess.SessionLogExtraComment,
                                                             IsReadOnlyOnSecondary:=False,
                                                             IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                                                             IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)
            Catch ex As Exception
            End Try
        End Try
        Return Res
    End Function
    Public Function AuthenticateUser(AuthReq As AuthenticationRequest) As AuthenticationResponse
        '   Dim authResp As New AuthenticationResponse
        Dim authResp As New AuthenticationResponse
        Dim ReasonDescriptionMsg As String = Nothing
        Try
            Dim Orders As DataTable = Nothing
            Dim remoteUser As BusinessLogic.RemoteUser = Nothing
            Try

                'Try until a valid row has been found
                If AuthReq.UserName Is Nothing Or AuthReq.UserName = "" Then
                    ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "No UserName passed"
                End If
                If AuthReq.Password Is Nothing Or AuthReq.Password = "" Then
                    ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "No Password passed"
                End If
                If ReasonDescriptionMsg <> Nothing Then Exit Try
                Try
                    UserSess.Restore(AuthReq.SessionId)

                Catch ex As Exception
                    'If restore fails on authenticate just try with blank sessionId to create a new one.
                    UserSess.Restore("")
                End Try
                Try
                    UserSess.Data("IsValidLogon") = False
                    UserSess.Data("IsValidUserName") = False
                    remoteUser = New BusinessLogic.RemoteUser(AuthReq.UserName, db, UserSess)
                    UserIdForLogging = UserSess.UserId
                    Select Case remoteUser.AuthorityLevel
                        Case UserSession.AuthorityLevels.SuperCompanyAdmins, UserSession.AuthorityLevels.CompanyAdmins
                            '2/10/20    James Woosnam   SIR5132 - PaDS users with authority level of either CompanyAdmin or SuperCompanyAdmin and with access to the PEP company will automatically have admin rights to the new PEPWeb system.
                            Dim HasPEPCompanyRights As Boolean = False
                            For Each r As DataRow In remoteUser.RemoteUserRights.Rows
                                If r("RightsToId") = 2 And r("RightsType") = "Company" Then
                                    HasPEPCompanyRights = True
                                    Exit For
                                End If
                            Next
                            If Not HasPEPCompanyRights Then
                                ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "Admin user does not have rights to the PEP company"
                            End If
                        Case UserSession.AuthorityLevels.IndividualSubscriber, UserSession.AuthorityLevels.SuperCompanyAdmins, UserSession.AuthorityLevels.CompanyAdmins
                        Case UserSession.AuthorityLevels.GroupUser
                            '12/9/21    James Woosnam   SIR5315 - Don't let GroupUsers logon directly from PEP
                            ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "Group Users can only auto-logon via an Ip Address, Referrer or Federated methods."

                        Case Else
                            '17/02/23   Julian Gates    SIR5566 - Add new better message and link to PaDS for GroupRenewer & GroupAdmin user trying to log onto PEP
                            ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "These Admin credentials failed on PEP. Goto <span class='productLink'><a href='https://www.psychoanalystdatabase.com/pages/pg070Logon.aspx' target='_blank'>PaDS</a></span> for Admin access."
                    End Select
                    UserSess.Data("IsValidUserName") = True
                    Select Case remoteUser.UserStatus
                        Case RemoteUser.UserStates.Active
                                'All good
                        Case RemoteUser.UserStates.Emailed
                            '20/12/21   James Woosnam   SIR5390 - Enhanced message if user already emailed in AuthenticateUser
                            If CDate(remoteUser.EmailAuthenticationSentDateTime) < Now.Date.AddHours(remoteUser.HoursToConfirmNewEmail * -1) Then
                                ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "The password reset email sent to this user has now expired please use the link below to re-send it"
                            Else
                                ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "A password reset email was sent " & remoteUser.TimeDescSinceEmailSent & " ago, please use the link in the email.  If the email hasn't been received please use the 'Forgot Password?' link below to re-send it"
                            End If
                        Case Else
                            ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "User status of '" & remoteUser.UserStatus.ToString & "' is not allowed"
                    End Select
                Catch ex As Exception
                    Throw ex
                End Try
                If ReasonDescriptionMsg <> Nothing Then Exit Try
                Try
                    '31/5/11    James Woosnam   Put UserSession.Logon in try catch
                    UserSess.Logon(AuthReq.UserName, AuthReq.Password)
                    UserIdForLogging = UserSess.UserId
                    Logs = New Logs(db, UserSess)
                Catch ex As Exception
                    Throw ex
                End Try

            Catch ex As Exception
                Throw ex
            End Try
            If ReasonDescriptionMsg <> Nothing Then Exit Try
            Me.CompleteAuthentication(remoteUser, ReasonDescriptionMsg)

        Catch ex As Exception
            If db.DBTransaction IsNot Nothing Then db.RollbackTran()
            ReasonDescriptionMsg = HandleError(ex)
        Finally
            Try
                Logs.WriteSessionLog(LogType:="PEPSecurity",
                                                             PageId:="010",
                                                             PageTitle:="AuthenticateUser",
                                                             UserId:=UserIdForLogging,
                                                             UserName:=AuthReq.UserName,
                                                             RemoteIPAddress:=Me.RemoteIPAddress,
                                                             Comment:=ReasonDescriptionMsg + UserSess.SessionLogExtraComment,
                                                             IsReadOnlyOnSecondary:=False,
                                                             IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                                                             IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)

            Catch ex As Exception
            End Try
        End Try
        authResp = UserSess.AuthenticationResponse
        authResp.ReasonStr = ReasonDescriptionMsg
        Return authResp
    End Function
    Public Function AuthenticateFromIP(SessionId As String, IPAddress As String, ReferrerURL As String) As AuthenticationResponse
        Dim ReasonDescriptionMsg As String = ""
        Dim authResp As New AuthenticationResponse
        Try
            Try
                UserSess.SessionLogExtraComment += ", AuthenticateFromIP with SessId:" & SessionId  '19/1/22 - Output additional info
                UserSess.Restore(SessionId)
                If SessionId <> UserSess.UserSessionId Then UserSess.SessionLogExtraComment += ";NewSession:" & UserSess.UserSessionId  '19/1/22 - Output additional info
                UserSess.SessionLogExtraComment += " Restored."  '19/1/22 - Output additional info
            Catch ex As Exception
                'If restore fails on authenticate just try with blank sessionId to create a new one.
                UserSess.SessionLogExtraComment += ", SessRestoreFailed:" & ex.Message '19/1/22 - Output additional info
                UserSess.Restore("")
            End Try

            Dim StdCd As New StdCode()
            Dim Remoteuser As New RemoteUser(db)
            If StdCd.IsValidIPAddress(IPAddress) Then
                If UserSess.LoggedInMethod = UserSession.LoggedInMethods.IPAddress And UserSess.Data("LoggedInWithIPAddress") <> IPAddress Then
                    '10/12/20 - The restored session was an IP logon, but the IP address has changed so create a new session
                    '                    UserSess.Restore("")
                    '15/12/20   James Woosnam   New session creation commentedout as causing problems for requests for OPAS server.
                    Logs.WriteSessionLog("AdHoc", "999", "AdHoc", UserIdForLogging, UserSess.UserName20, IPAddress, "Auto IP Logon with:" & UserSess.Data("LoggedInWithIPAddress") & " now " & IPAddress & ".  New session creation commentedout as causing problems for requests for OPAS server.", False, db.IsDatabaseServerPrimaryOrSecondary, db.IsWebServerPrimaryOrSecondary)
                End If
                If UserSess.LoggedIn Then  '10/12/20 - If already logged in then don't log in again
                    UserSess.SessionLogExtraComment += "Already Logged in, IP Address:" & IPAddress
                    UserIdForLogging = UserSess.UserId
                    Exit Try
                End If
                If Not UserSess.LoggedIn Then
                    '29/1/22    James Woosnam   SIR5427 -  AuthenticateFromIP if not logged on then ensure LoggedInMethod is reset as might be left as IPAddress which will confuse Logon function
                    UserSess.LoggedInMethod = Nothing
                    Dim UserFoundFromReferrerURL As Boolean = False
                    Remoteuser = Remoteuser.GetRemoteUserFromIPAddress(IPAddress, 0)
                    If Remoteuser Is Nothing And ReferrerURL IsNot Nothing Then
                        'try logging in with ReferrerURL
                        Remoteuser = New RemoteUser(db).GetRemoteUserFromReferrerURL(ReferrerURL)
                        '10/12/21   James Woosnam   Add additional info about the referrer URL
                        If Remoteuser IsNot Nothing Then
                            UserFoundFromReferrerURL = True
                            UserSess.SessionLogExtraComment += ";User found from ReferrerURL:" & ReferrerURL
                        ElseIf ReferrerURL <> "" Then
                            UserSess.SessionLogExtraComment += ";Unknown ReferrerURL:'" & ReferrerURL & "'"

                        End If
                    End If
                    If Remoteuser IsNot Nothing Then
                        Try
                            Select Case Remoteuser.AuthorityLevel
                                Case UserSession.AuthorityLevels.GroupUser
                                Case Else
                                    ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "AuthorityLevel '" & Remoteuser.AuthorityLevel.ToString & "' not authorised.  Only authority level GroupUser can authenticate from an IP address."
                                    Exit Try
                            End Select

                            UserSess.Logon(UserName:=Remoteuser.UserName, Password:="", IsSpoofLogon:=False, SpoofingUserId:=0, IsAutoLogon:=True)
                            Dim tranStartedHere As Boolean = False
                            If db.DBTransaction Is Nothing Then
                                db.BeginTran() 'Start tran to right session data updates in one go
                                tranStartedHere = True
                            End If
                            Try
                                UserSess.LoggedInMethod = IIf(UserFoundFromReferrerURL, UserSession.LoggedInMethods.ReferrerURL, UserSession.LoggedInMethods.IPAddress)
                                If Not UserFoundFromReferrerURL Then UserSess.Data("LoggedInWithIPAddress") = IPAddress
                                If UserFoundFromReferrerURL Then UserSess.Data("LoggedInWithReferrerURL") = ReferrerURL
                                UserSess.Data("IsValidUserName") = True
                                UserSess.Data("IsValidLogon") = True
                                UserIdForLogging = UserSess.UserId
                                Remoteuser = New RemoteUser(UserSess.UserId, db, UserSess)
                                Logs = New Logs(db, UserSess)
                                UserSess.Save()
                                If tranStartedHere Then db.CommitTran()
                            Catch ex As Exception
                                If tranStartedHere Then db.RollbackTran()
                                Throw ex
                            End Try

                        Catch ex As Exception
                            Throw ex
                        End Try
                    End If
                End If
            Else
                If UserSess.LoggedIn Then  '10/12/20 - If already logged in then don't log in again
                    UserSess.SessionLogExtraComment += ";Already Logged in, IP Address:" & IPAddress
                Else
                    If UserSess.UserName = "Not Logged On" Then
                        'This is just a blank session so we can keep it
                    Else
                        UserSess.SessionLogExtraComment += ";Session has been logged out, so renewed."
                        UserSess.Restore("")
                    End If
                End If
                Exit Try 'Invalid IP address so drop out
            End If
            If ReasonDescriptionMsg <> Nothing Then Exit Try

            If Remoteuser IsNot Nothing Then
                Me.CompleteAuthentication(Remoteuser, ReasonDescriptionMsg)
            Else
                UserSess.SessionLogExtraComment += ";Unregistered IP Address:" & IPAddress
            End If

        Catch ex As Exception
            ReasonDescriptionMsg = HandleError(ex)
        Finally
            Try
                Logs.WriteSessionLog(LogType:="PEPSecurity",
                                                                PageId:="011",
                                                                PageTitle:="AuthenticateFromIP",
                                                                UserId:=UserIdForLogging,
                                                                UserName:=UserSess.UserName,
                                                                RemoteIPAddress:=Me.RemoteIPAddress,
                                                                Comment:=ReasonDescriptionMsg + UserSess.SessionLogExtraComment,
                                                                IsReadOnlyOnSecondary:=False,
                                                                IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                                                                IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)
            Catch ex As Exception

            End Try
        End Try
        authResp = UserSess.AuthenticationResponse
        authResp.ReasonStr = ReasonDescriptionMsg
        Return authResp
    End Function
    Public Function AuthenticateFromFederated(ByRef InUserSession As UserSession, Entity As String, Scope As String, FederatedPersonId As String) As AuthenticationResponse
        Dim ReasonDescriptionMsg As String = ""
        Dim authResp As New AuthenticationResponse
        Try
            Try
                _UserSess = InUserSession
            Catch ex As Exception
                'If session fails just try with blank sessionId to create a new one.
                UserSess.Restore("")
            End Try
            If UserSess.LoggedIn Then  '19/12/20 - For federated log out and reset session in again
                Dim AfterPasswordSetupReturnToPep As String = "False" ' Need to preserve this into new session
                If UserSess.Data("AfterPasswordSetupReturnToPep") IsNot Nothing Then
                    AfterPasswordSetupReturnToPep = UserSess.Data("AfterPasswordSetupReturnToPep")
                End If
                UserSess.Restore("")
                UserSess.Data("AfterPasswordSetupReturnToPep") = AfterPasswordSetupReturnToPep
            End If
            Dim Remoteuser As New RemoteUser(db)
            Remoteuser = Remoteuser.GetRemoteUserFromFederatedEntityAndScope(Entity, Scope, 0)
            If Remoteuser IsNot Nothing Then
                Try
                    Select Case Remoteuser.AuthorityLevel
                        Case UserSession.AuthorityLevels.GroupUser, UserSession.AuthorityLevels.IndividualSubscriber
                        Case Else
                            ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "AuthorityLevel '" & Remoteuser.AuthorityLevel.ToString & "' not authorised.  Only authority level GroupUser can authenticate from an IP address."
                            Exit Try
                    End Select
                    UserSess.Logon(UserName:=Remoteuser.UserName, Password:="", IsSpoofLogon:=False, SpoofingUserId:=0, IsAutoLogon:=True)

                    '29/1/22    James Woosnam   SIR5427 -  AuthenticateFromFederated set loggedInMethod after 1st login as the secnd logon was getting confused
                    UserSess.LoggedInMethod = UserSession.LoggedInMethods.Federated
                    UserSess.SessionLogExtraComment += ";GroupUser logged on"
                    If FederatedPersonId <> "" Then
                        'now try and find a user matching the personId and if found logon as that user, the session subscription info will be merged 
                        Dim IndividualRemoteUser As RemoteUser = Remoteuser.GetRemoteUserFromFederatedPersonId(FederatedPersonId)
                        If IndividualRemoteUser IsNot Nothing Then
                            UserSess.SessionLogExtraComment += ";FederatedPersonId found UserId:" & IndividualRemoteUser.UserId
                            'Before we switch the RemoteUser to the individual we need to do CompleteAuthentication with GroupUser to populate subscription info
                            Me.CompleteAuthentication(Remoteuser, ReasonDescriptionMsg)
                            'Now update individuak use with GroupUser details

                            Remoteuser = IndividualRemoteUser 'now switch remote user to individual
                            UserSess.Logon(UserName:=Remoteuser.UserName, Password:="", IsSpoofLogon:=False, SpoofingUserId:=0, IsAutoLogon:=True)

                        Else
                            UserSess.SessionLogExtraComment += ";FederatedPersonId not found"
                        End If
                    End If
                    Dim tranStartedHere As Boolean = False
                    If db.DBTransaction Is Nothing Then
                        db.BeginTran() 'Start tran to right session data updates in one go
                        tranStartedHere = True
                    End If
                    Try
                        Select Case Remoteuser.AuthorityLevel
                            Case UserSession.AuthorityLevels.GroupUser
                                UserSess.LoggedInMethod = UserSession.LoggedInMethods.Federated
                            Case UserSession.AuthorityLevels.IndividualSubscriber
                                'must be an individual from FederatedPersonId
                                UserSess.LoggedInMethod = UserSession.LoggedInMethods.FederatedIndividual
                        End Select
                        UserSess.Data("LoggedInWithFederatedEntity") = Entity
                        If Scope <> Nothing Then UserSess.Data("LoggedInWithFederatedScope") = Scope
                        If FederatedPersonId <> Nothing Then UserSess.Data("LoggedInWithFederatedPersonId") = FederatedPersonId
                        UserSess.Data("IsValidUserName") = True
                        UserSess.Data("IsValidLogon") = True
                        UserIdForLogging = UserSess.UserId
                        Remoteuser = New RemoteUser(UserSess.UserId, db, UserSess)
                        Logs = New Logs(db, UserSess)
                        UserSess.Save()
                        If tranStartedHere Then db.CommitTran()
                    Catch ex As Exception
                        If tranStartedHere Then db.RollbackTran()
                        Throw ex
                    End Try
                Catch ex As Exception
                    Throw ex
                End Try
            End If
            If Remoteuser IsNot Nothing Then
                Me.CompleteAuthentication(Remoteuser, ReasonDescriptionMsg)
            Else
                Throw New Exception("User not identified")
            End If

        Catch ex As Exception
            ReasonDescriptionMsg = HandleError(ex)
        Finally
            Try
                Logs.WriteSessionLog(LogType:="PEPSecurity",
                                                                PageId:="012",
                                                                PageTitle:="AuthenticateFromFederated",
                                                                UserId:=UserIdForLogging,
                                                                UserName:=UserSess.UserName,
                                                                RemoteIPAddress:=Me.RemoteIPAddress,
                                                                Comment:=ReasonDescriptionMsg + UserSess.SessionLogExtraComment,
                                                                IsReadOnlyOnSecondary:=False,
                                                                IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                                                                IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)
            Catch ex As Exception

            End Try
        End Try
        authResp = UserSess.AuthenticationResponse
        authResp.ReasonStr = ReasonDescriptionMsg
        Return authResp
    End Function
    Public Function AuthenticateFromReferrerURL(ByRef InUserSession As UserSession, ReferrerURL As String) As AuthenticationResponse
        Dim ReasonDescriptionMsg As String = ""
        Dim authResp As New AuthenticationResponse
        Try
            Try
                _UserSess = InUserSession
            Catch ex As Exception
                'If session fails just try with blank sessionId to create a new one.
                UserSess.Restore("")
            End Try
            If UserSess.LoggedIn Then  '19/12/20 - For federated log out and reset session in again
                UserSess.Restore("")
            End If
            Dim Remoteuser As New RemoteUser(db)
            Remoteuser = Remoteuser.GetRemoteUserFromReferrerURL(ReferrerURL)
            If Remoteuser Is Nothing Then
                ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "Can't authenticate with ReferrerURL:" & ReferrerURL
            Else
                Try
                    Select Case Remoteuser.AuthorityLevel
                        Case UserSession.AuthorityLevels.GroupUser
                        Case Else
                            ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "AuthorityLevel '" & Remoteuser.AuthorityLevel.ToString & "' not authorised.  Only authority level GroupUser can authenticate from an IP address."
                            Exit Try
                    End Select
                    UserSess.Logon(UserName:=Remoteuser.UserName, Password:="", IsSpoofLogon:=False, SpoofingUserId:=0, IsAutoLogon:=True)
                    Dim tranStartedHere As Boolean = False
                    If db.DBTransaction Is Nothing Then
                        db.BeginTran() 'Start tran to right session data updates in one go
                        tranStartedHere = True
                    End If
                    Try
                        UserSess.LoggedInMethod = UserSession.LoggedInMethods.ReferrerURL
                        UserSess.Data("LoggedInWithReferrerURL") = ReferrerURL
                        UserSess.Data("IsValidUserName") = True
                        UserSess.Data("IsValidLogon") = True
                        UserIdForLogging = UserSess.UserId
                        Remoteuser = New RemoteUser(UserSess.UserId, db, UserSess)
                        Logs = New Logs(db, UserSess)
                        UserSess.Save()
                        If tranStartedHere Then db.CommitTran()
                    Catch ex As Exception
                        If tranStartedHere Then db.RollbackTran()
                        Throw ex
                    End Try
                Catch ex As Exception
                    Throw ex
                End Try
            End If
            If Remoteuser IsNot Nothing Then
                Me.CompleteAuthentication(Remoteuser, ReasonDescriptionMsg)
            End If

        Catch ex As Exception
            ReasonDescriptionMsg = HandleError(ex)
        Finally
            Try
                Logs.WriteSessionLog(LogType:="PEPSecurity",
                                                                PageId:="012",
                                                                PageTitle:="AuthenticateFromReferrerURL",
                                                                UserId:=UserIdForLogging,
                                                                UserName:=UserSess.UserName,
                                                                RemoteIPAddress:=Me.RemoteIPAddress,
                                                                Comment:=ReasonDescriptionMsg + UserSess.SessionLogExtraComment,
                                                                IsReadOnlyOnSecondary:=False,
                                                                IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                                                                IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)
            Catch ex As Exception

            End Try
        End Try
        authResp = UserSess.AuthenticationResponse
        authResp.ReasonStr = ReasonDescriptionMsg
        Return authResp
    End Function
    Public Sub CompleteAuthentication(User As RemoteUser, ByRef ReasonDescriptionMsg As String)
        'This must be passed a user that has been successfully logged on
        Dim tranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            db.BeginTran() 'Start tran to right session data updates in one go
            tranStartedHere = True
        End If
        Try
            User = New RemoteUser(User.UserId, db, UserSess)
            Select Case User.AuthorityLevel
                Case UserSession.AuthorityLevels.CompanyAdmins, UserSession.AuthorityLevels.SuperCompanyAdmins
                    '2/10/20    James Woosnam   SIR5132 - PaDS users with authority level of either CompanyAdmin or SuperCompanyAdmin and with access to the PEP company will automatically have admin rights to the new PEPWeb system.
                    Try

                        UserSess.Data("HasSubscription") = True
                        UserSess.Data("ContentSets") = db.GetParameterValue("AllContentSetIdsForAdmin", 1)
                        UserSess.Data("SubscriptionEndDate") = CDate("31-dec-4949")
                    Catch ex As Exception
                        Logs.LogErrorMessage(ex)
                        Throw ex
                    Finally
                        Try
                            Logs.WritePEPWebAthenticateLog(LogonLocation:="PEPSecurity",
                                                LogonStatus:=IIf(UserSess.LoggedIn, "Success", "Failed"),
                                                SubscriberId:=0,
                                                SubscriberName:="AdminUser:" & User.UserName,
                                                UserName:=UserIdForLogging,
                                                OrderNumber:=0,
                                                AccessibleContentSets:=db.GetParameterValue("AllContentSetIdsForAdmin", 1),
                                                AdditionalDetails:=ReasonDescriptionMsg,
                                                RemoteIPAddress:=Me.RemoteIPAddress
                                           )
                        Catch ex As Exception
                        End Try
                    End Try
                Case Else
                    Dim Orders As DataTable = Nothing
                    '

                    Try
                        Try
                            Me.UserSess.SessionLogExtraComment += ";UserDetailBeforeOrderlookup:" & db.DLookup("UserName & FORMAT(ISNULL(LastAutoLoginGroupUserId,''),'dd-MMM-yy')", "RemoteUser", "UserId=" & User.UserId)
                        Catch ex As Exception

                        End Try
                        Orders = GetUserOdersFromsp237(User.UserName)
                        Dim vwOrdsAutoOnly As New DataView(Orders, "IsViaAutoLogon=1", "", DataViewRowState.CurrentRows)
                        If vwOrdsAutoOnly.Count = 0 Then
                            '5/1/22	James Woosnam	SIR5401 - sp237 now returns autologon orders so only check autologon if view of autologon orders is empty
                            Select Case UserSess.LoggedInMethod
                                Case UserSession.LoggedInMethods.FederatedIndividual, UserSession.LoggedInMethods.IPAddressIndividual, UserSession.LoggedInMethods.ReferrerURLIndividual
                                    'if secoondary login and has no subs then use groups
                                Case Else
                                    If db.IsDBNull(User.RemoteUserRow("LastAutoLoginGroupUserId"), 0) <> 0 AndAlso UserSess.LoggedInMethod = UserSession.LoggedInMethods.Individual Then
                                        Dim LastLoggedInMethod As UserSession.LoggedInMethods = [Enum].Parse(GetType(UserSession.LoggedInMethods), User.RemoteUserRow("LastLoggedInMethod"))
                                        Dim GroupUser As New RemoteUser(CInt(User.RemoteUserRow("LastAutoLoginGroupUserId")), db, UserSess) 'If LastLoggedInMethod is populated so should this so no need to check for nulls

                                        Select Case LastLoggedInMethod
                                            Case UserSession.LoggedInMethods.FederatedIndividual, UserSession.LoggedInMethods.IPAddressIndividual, UserSession.LoggedInMethods.ReferrerURLIndividual
                                                '20/4/21    James Woosnam   SIR5224 - If we have passed the AutoLogonAuthenticationRetentionDays then encourage user to reauthenticate form institution.
                                                Dim AutoLogonAuthenticationRetentionDays As Integer = db.GetParameterValue("AutoLogonAuthenticationRetentionDays", 90)
                                                Dim LastAutoLoginRefreshDateTime As Date = CDate(db.IsDBNull(User.RemoteUserRow("LastAutoLoginRefreshDateTime"), "01-jan-1900"))

                                                Dim span As TimeSpan = Now() - LastAutoLoginRefreshDateTime
                                                If LastAutoLoginRefreshDateTime.AddDays(AutoLogonAuthenticationRetentionDays) < Now() Then
                                                    UserSess.Data("IsValidLogon") = False
                                                    UserSess.Data("LoggedIn") = False
                                                    '03/12/21   Julian Gates    SIR5356 - Change Auto logon ReasonDescriptionMsg text.
                                                    ReasonDescriptionMsg += span.TotalDays.ToString("0") & " days have passed since you enabled the auto logon feature. To enable again,"
                                                    Select Case LastLoggedInMethod
                                                        Case UserSession.LoggedInMethods.FederatedIndividual
                                                            ReasonDescriptionMsg += " access PEP-Web through the website of '" & GroupUser.RemoteUserRow("UserFullName") & "' or use the Federated/OpenAthens link below (as relevant) and 'Sign in' using your username and password from PEP's user database <a href=""https://www.psychoanalystdatabase.com/"">(PaDS)</a>."
                                                        Case UserSession.LoggedInMethods.IPAddressIndividual, UserSession.LoggedInMethods.ReferrerURLIndividual
                                                            ReasonDescriptionMsg += " login to the website of '" & GroupUser.RemoteUserRow("UserFullName") & "', click on the PEP-Web link and 'Sign in' using your username and password from PEP's user database <a href=""https://www.psychoanalystdatabase.com/"">(PaDS)</a>."
                                                    End Select
                                                    If Orders.Rows.Count <> 0 Then ReasonDescriptionMsg += "<br>You will need to login again to pick up your other subscriptions."
                                                Else
                                                    '5/1/22	James Woosnam	SIR5401 - No Autoorders found but auto details found on user which must now be invalid
                                                    ReasonDescriptionMsg += "" & GroupUser.RemoteUserRow("UserFullName") & " no longer has PEP web access.  "

                                                End If
                                                '5/1/22	James Woosnam	SIR5401 - Only show "days have passed since you enabled the auto logon " message once then disable
                                                User.RemoteUserRow("LastAutoLoginGroupUserId") = System.DBNull.Value
                                                User.RemoteUserRow("LastLoggedInMethod") = System.DBNull.Value
                                                User.RemoteUserRow("LastAutoLoginRefreshDateTime") = System.DBNull.Value
                                                User.Save()
                                        End Select
                                    End If
                            End Select
                        End If
                        Try ' Testing specific modification, subtract 100 days from LastAutoLoginRefreshDateTime for Test3 & 8 so next time it outputs re-use message. 8/1/22: Only for first Test8 indiviual logon
                            If (User.UserName = "Test3" Or User.UserName = "Test8") And Not db.IsDBNull(User.RemoteUserRow("LastAutoLoginRefreshDateTime")) And UserSess.LoggedInMethod = UserSession.LoggedInMethods.Individual Then db.ExecuteSQL("UPDATE RemoteUser SET LastAutoLoginRefreshDateTime = DATEADD(DAY,-100,LastAutoLoginRefreshDateTime) WHERE UserId=" & User.UserId)
                        Catch ex As Exception
                        End Try
                        Select Case UserSess.LoggedInMethod
                            Case UserSession.LoggedInMethods.FederatedIndividual, UserSession.LoggedInMethods.IPAddressIndividual, UserSession.LoggedInMethods.ReferrerURLIndividual
                                'na
                            Case Else
                                '5/1/22	James Woosnam	SIR5401 - If there are AutoLogon orders then assume logon method same as last time, even if there is an additonal non auto logon
                                If Not db.IsDBNull(User.RemoteUserRow("LastLoggedInMethod")) And vwOrdsAutoOnly.Count <> 0 Then UserSess.LoggedInMethod = [Enum].Parse(GetType(UserSession.LoggedInMethods), User.RemoteUserRow("LastLoggedInMethod"))
                        End Select
                        If Orders.Rows.Count = 0 And ReasonDescriptionMsg = Nothing Then
                            '2/3/22     James Woosnam   SIR5433 - Add more descriptive message if existing session is no longer valid because no order can be found as the subscription has expired
                            If UserSess.LoggedInMethod <> UserSession.LoggedInMethods.Individual Then
                                'Auto logon but no subscription
                                UserSess.Data("IsValidLogon") = False
                                UserSess.Data("HasSubscription") = False
                                Dim LastAutoLoginGroupUserId As Integer = 0
                                Try
                                    LastAutoLoginGroupUserId = db.IsDBNull(User.RemoteUserRow("LastAutoLoginGroupUserId"), UserSess.Data("LastAutoLoginGroupUserId"))
                                Catch ex As Exception
                                End Try
                                If LastAutoLoginGroupUserId = 0 Then LastAutoLoginGroupUserId = UserSess.UserId 'If none other found assume logging on user, should be the group user
                                Dim LastAutoLoginGroupUserName As String = db.DLookup("UserFullName", "RemoteUser", "UserId=" & LastAutoLoginGroupUserId)
                                Select Case UserSess.LoggedInMethod
                                    Case UserSession.LoggedInMethods.FederatedIndividual, UserSession.LoggedInMethods.IPAddressIndividual, UserSession.LoggedInMethods.ReferrerURLIndividual
                                        'Auto individual
                                        ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "This logon is linked to '" & LastAutoLoginGroupUserName & "', but the logon is no longer valid."
                                    Case Else
                                        ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "This seesion has been linked to '" & LastAutoLoginGroupUserName & "' via a " & UserSess.LoggedInMethod.ToString & ", but their subscription is no longer valid."
                                End Select
                                UserSess.Save()
                                '5/3/22 - Write session log to old session befere it is abandoned
                                Logs.WriteSessionLog(LogType:="PEPSecurity", PageId:="001", PageTitle:="AuthenticateUser", UserId:=UserIdForLogging, UserName:=User.UserName, RemoteIPAddress:=Me.RemoteIPAddress, Comment:=ReasonDescriptionMsg + UserSess.SessionLogExtraComment, IsReadOnlyOnSecondary:=False, IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary, IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)

                                Dim oldSessionId As String = UserSess.UserSessionId
                                _UserSess = New UserSession(db)
                                UserSess.Restore("")
                                Logs = New Logs(db, UserSess)
                                UserSess.SessionLogExtraComment += ";Created as sess:" & oldSessionId & " is now invalid"
                            Else
                                '5/1/22	James Woosnam	SIR5401 - If no Auto, or normal, orders and there isn't a message already then this message
                                ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "There is no valid subscription."

                            End If
                        End If
                        If ReasonDescriptionMsg <> Nothing Then
                            Logs.WritePEPWebAthenticateLog(LogonLocation:="PEPSecurity",
                                                                            LogonStatus:="Failed",
                                                                            SubscriberId:=0,
                                                                            SubscriberName:="",
                                                                            UserName:=UserIdForLogging,
                                                                            OrderNumber:=0,
                                                                            AccessibleContentSets:="",
                                                                            AdditionalDetails:=ReasonDescriptionMsg,
                                                                            RemoteIPAddress:=Me.RemoteIPAddress)
                        End If
                    Catch ex As Exception
                        Throw ex
                    End Try

                    If ReasonDescriptionMsg <> "" Then Exit Select

                    'After this point a valid row has been found but it still may not be valid
                    Try
                        Dim firstRow As DataRow = Orders.Rows(0)
                        If firstRow("ProductCode") Is System.DBNull.Value Then
                            ReasonDescriptionMsg += IIf(ReasonDescriptionMsg = "", "", Environment.NewLine) & "This user has Not purchased any qualifying products Or the subscription has expired."
                            Exit Try
                        End If

                        UserSess.Data("HasSubscription") = True

                        UserSess.Data("ContentSets") = db.IsDBNull(firstRow("ContentSets"), "")
                        '14/2/22    James Woosnam   Check pep orders first, if none use other orders
                        '7/9/22     James Woosnam   Try PEPweb products first, then just pep products and then any others
                        Dim vw As New DataView(Orders, "CompanyId=2 AND ProductCode LIKE '*PEPWeb*'", "RecurringSubscriptionEndDate desc", DataViewRowState.CurrentRows)
                        If vw.Count = 0 Then vw = New DataView(Orders, "CompanyId=2", "RecurringSubscriptionEndDate desc", DataViewRowState.CurrentRows)
                        If vw.Count = 0 Then vw = New DataView(Orders, "", "RecurringSubscriptionEndDate desc", DataViewRowState.CurrentRows)
                        UserSess.Data("SubscriptionEndDate") = CDate("31-dec-4949")
                        For Each r As DataRowView In vw
                            UserSess.Data("SubscriptionEndDate") = r("RecurringSubscriptionEndDate")
                            UserSess.Data("SubscriptionProductCode") = r("ProductCode")
                            UserSess.Data("SubscriptionOrderNumber") = r("OrderNumber")
                            Exit For
                        Next
                        Dim d As New DataSet
                        d.Tables.Add(Orders)
                        Dim sjOrders As String = Newtonsoft.Json.JsonConvert.SerializeObject(d)
                        UserSess.Data("SubscriptionOrders") = sjOrders
                    Catch ex As Exception
                        If tranStartedHere Then
                            db.RollbackTran()
                            tranStartedHere = False
                        End If
                        Logs.LogErrorMessage(ex)
                        Throw ex
                    Finally
                        Try
                            Logs.WritePEPWebAthenticateLog(LogonLocation:="PEPSecurity",
                                                                    LogonStatus:=IIf(CBool(UserSess.Data("IsValidLogon")), "Success", "Failed"),
                                                                    SubscriberId:=UserSess.Data("SubscriberId"),
                                                                    SubscriberName:=UserSess.Data("SubscriberName"),
                                                                    UserName:=UserIdForLogging,
                                                                    OrderNumber:=UserSess.Data("SubscriptionOrderNumber"),
                                                                    AccessibleContentSets:=UserSess.Data("ContentSets"),
                                                                    AdditionalDetails:=ReasonDescriptionMsg,
                                                                    RemoteIPAddress:=RemoteIPAddress
                                           )
                        Catch ex As Exception
                        End Try
                    End Try

            End Select
            UserSess.Save()
            If tranStartedHere Then db.CommitTran()
        Catch ex As Exception
            If tranStartedHere Then db.RollbackTran()
            ReasonDescriptionMsg = HandleError(ex)
        Finally
            Try
                '5/3/22 James Woosnam   WriteSessionlog below removed as it is always done in calling module
                'Logs.WriteSessionLog(LogType:="PEPSecurity",
                '                                             PageId:="001",
                '                                             PageTitle:="AuthenticateUser",
                '                                             UserId:=UserIdForLogging,
                '                                             UserName:=User.UserName,
                '                                             RemoteIPAddress:=Me.RemoteIPAddress,
                '                                             Comment:=ReasonDescriptionMsg + UserSess.SessionLogExtraComment,
                '                                             IsReadOnlyOnSecondary:=False,
                '                                             IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                '                                             IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)

            Catch ex As Exception
            End Try
        End Try
    End Sub
    Function GetUserOdersFromsp237(UserName As String) As DataTable
        Dim orders As DataTable = Nothing
        Dim cmd As New SqlCommand("sp237GetSubscriberPEPWebSubscriptions", db.DBConnection, db.DBTransaction)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReturnType", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                              "ContentSets"))
        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                              UserName))
        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OnDate", System.Data.SqlDbType.DateTime, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , Now()))
        Try
            orders = db.GetDataTableFromSQL(cmd)
            orders.TableName = "Orders"
        Catch eSQL As SqlException
            Dim email As New BusinessLogic.Email(db)
            email.SendErrorEmail("PEP Security SQL lookup failed", "SQL:sp237GetSubscriberPEPWebSubscriptions @UserName='" & UserName & "'" _
                                             & System.Environment.NewLine & "Error:" & eSQL.Message _
                                             & System.Environment.NewLine & "Connection:" & db.DBConnection.ConnectionString
                                             )
            Throw New Exception("Authenticate failed.  SQL Error" & eSQL.Message)
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try
        Return orders
    End Function


    Public Class PaDSUser
        Public UserId As Integer
        Public UserName As String 'Name used to logon, could be email address, short textual code or any other text string 
        Public UserFullName As String 'Full user known by name in the form "surname, firstname" for individuals and the full organisation name for groups
        Public UserType As String ' Individual, Group or Admin
        Public SubscriptionEndDate As Date 'The date and time when the subscription terminates
        Public IsSubscriptionRenewalDue As Boolean = False 'Will return True approx 12 weeks before the subscription terminates, will be False once subscription renewed.
        Public PaDSHomeURL As String 'Will take the user to their PaDS home page
        Public PaDSRenewalURL As String 'Will take the user directly to the page where they can renewal their subscription
        Public Branding As String
        Public ClientSettings As Object
        Public HasCurrentAccess As Boolean = False
        Public HasArchiveAccess As Boolean = False
        Public ReasonDescription As String
        Public ReasonCode As HttpStatusCode = HttpStatusCode.InternalServerError
        '10/12/20   James Woosnam   SIR5165 - add additional user info
        Public EmailAddress As String
        Public LoggedInMethod As String 'Individual,IP Address or Federated
        Public ActiveSubscriptions As Object 'JSON of each Product, Subscribed Via, FromDate, ToDate
        Public SendJournalAlerts As Boolean = False
        Public SendVideoAlerts As Boolean = False
        Public HasIJPOpenSubscription As Boolean = False '14/11/22   James Woosnam   SIR5533 - Add HasIJPOpenSubscription to user class

    End Class
    Public Function GetUser(SessionId As String) As PaDSUser

        Dim pUser As New PaDSUser

        Try
            UserSess.Restore(SessionId)
            If Not UserSess.LoggedIn Then
                pUser.ReasonDescription = "SessionId has not been successfully logged on, so user details can't be retrieved."
                pUser.ReasonCode = HttpStatusCode.Unauthorized
                Exit Try
            End If
            UserIdForLogging = UserSess.UserId
            pUser.UserId = UserSess.UserId
            pUser.UserName = UserSess.UserName
            '19/10/20   James Woosnam   SIR5140 - Add additional user fields
            pUser.UserFullName = UserSess.UserFullName
            pUser.EmailAddress = UserSess.Data("EmailAddress")
            '9/2/21     James Woosnam   SIR5176 - Add SendJournalAlerts & SendVideoAlerts
            pUser.SendJournalAlerts = UserSess.Data("SendJournalAlerts")
            pUser.SendVideoAlerts = UserSess.Data("SendVideoAlerts")
            pUser.HasIJPOpenSubscription = Me.UserHasIJPOpenSubscription '14/11/22   James Woosnam   SIR5533 - Add HasIJPOpenSubscription to user class  
            pUser.LoggedInMethod = UserSess.LoggedInMethod.ToString
            If UserSess.Data("SubscriptionEndDate") IsNot Nothing Then pUser.SubscriptionEndDate = UserSess.Data("SubscriptionEndDate")
            '2/3/21 - Use the UserType from Sessiondata
            pUser.UserType = UserSess.Data("UserType")
            '24/5/21    James Woosnam   SIR5253 - User type is Moderator if user marked as IsModerator
            Select Case UserSess.Data("UserType")
                Case "Individual"
                    If pUser.SubscriptionEndDate <> Nothing AndAlso Now() >= pUser.SubscriptionEndDate.AddDays(CInt(db.GetParameterValue("FirstReminderDaysBefore")) * -1) Then
                        pUser.IsSubscriptionRenewalDue = True
                        pUser.PaDSRenewalURL = db.GetParameterValue("WebSiteURL") & "/Pages/pg232RemoteOrder.aspx?PageMode=RenewOrder&CompanyId=2&ProductCode=" & UserSess.Data("SubscriptionProductCode") & "&" & UserSess.QueryString
                    End If
                Case "Admin"
                    pUser.HasArchiveAccess = True
                    pUser.HasCurrentAccess = True
            End Select
            pUser.PaDSHomeURL = db.GetParameterValue("WebSiteURL") & "/Pages/pg070Logon.aspx?Action=RedirectToUserHome&" & UserSess.QueryString
            Try
                pUser.ClientSettings = IIf(db.IsDBNull(UserSess.Data("PEPWebClientSettings"), "") = "", Nothing, Newtonsoft.Json.JsonConvert.DeserializeObject(UserSess.Data("PEPWebClientSettings")))
                '     pUser.ClientSettings = IIf(db.IsDBNull(UserSess.Data("PEPWebClientSettings"), "") = "", Nothing, UserSess.Data("PEPWebClientSettings"))
            Catch ex As Exception
                pUser.ClientSettings = Me.HandleError(ex)
            End Try
            If UserSess.Data("SubscriptionOrders") IsNot Nothing Then
                Dim ds As DataSet = Newtonsoft.Json.JsonConvert.DeserializeObject(Of DataSet)(UserSess.Data("SubscriptionOrders"))
                If ds.Tables("Orders") IsNot Nothing Then
                    Dim tOrders As DataTable = ds.Tables("Orders")

                    Dim tSubs As New DataTable
                    For Each col As DataColumn In tOrders.Columns
                        ',"ContentSetId"	,"ProductCode"	,"ProductName"	,"RecurringSubscriptionStartDate"	,"RecurringSubscriptionEndDate"	,"OrderNumber"	,"OrderedViaSubscriberId"	,"OrderedViaName"	,"HasCurrentAccess"	,"HasArchiveAccess"	,"ContentSets"
                        If {"ProductCode", "ProductName", "RecurringSubscriptionStartDate", "RecurringSubscriptionEndDate", "OrderedViaName"}.Contains(col.ColumnName) Then
                            Dim cNew As New DataColumn(col.ColumnName)
                            tSubs.Columns.Add(cNew)
                        End If
                    Next
                    For Each r As DataRow In tOrders.Rows
                        Dim rNew As DataRow = tSubs.NewRow
                        For Each col As DataColumn In tSubs.Columns
                            rNew(col.ColumnName) = r(col.ColumnName)
                        Next
                        tSubs.Rows.Add(rNew)
                        '9/11/21    James Woosnam   SIR5364 - Move Archive/Current access into for each so they are set to best row.
                        '24/1/22    James Woosnam   SIR5417 - use row from loop raher than first row
                        If r("HasArchiveAccess") Then pUser.HasArchiveAccess = True
                        If r("HasCurrentAccess") Then pUser.HasCurrentAccess = True
                    Next
                    Dim sjSubs As String = Newtonsoft.Json.JsonConvert.SerializeObject(tSubs)
                    pUser.ActiveSubscriptions = sjSubs
                End If
            End If
            pUser.ReasonCode = HttpStatusCode.OK
        Catch ex As Exception
            pUser.ReasonDescription = Me.HandleError(ex)
        Finally
            Try
                Logs.WriteSessionLog(LogType:="PEPSecurity",
                                                             PageId:="020",
                                                             PageTitle:="GetUser",
                                                             UserId:=UserIdForLogging,
                                                             UserName:=UserSess.UserName,
                                                             RemoteIPAddress:=Me.RemoteIPAddress,
                                                             Comment:=pUser.ReasonDescription + UserSess.SessionLogExtraComment,
                                                             IsReadOnlyOnSecondary:=False,
                                                             IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                                                             IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)
            Catch ex As Exception
            End Try
        End Try
        Return pUser
    End Function

    '3/11/22   James Woosnam   SIR5533 - Add UserDisqusPayload & GetDisqusPayload
    Public Class UserDisqusPayload
        Public Payload As String
        Public PublicKey As String
        Public ReasonDescription As String
        Public ReasonCode As HttpStatusCode = HttpStatusCode.InternalServerError
    End Class
    Public Function GetDisqusPayload(SessionId As String) As UserDisqusPayload

        Dim pUserDisqusPayload As New UserDisqusPayload

        Try
            UserSess.Restore(SessionId)
            If Not UserSess.LoggedIn Then
                pUserDisqusPayload.ReasonDescription = "SessionId has not been successfully logged on, so user details can't be retrieved."
                pUserDisqusPayload.ReasonCode = HttpStatusCode.Unauthorized
                Exit Try
            End If
            UserIdForLogging = UserSess.UserId

            If Not Me.UserHasIJPOpenSubscription Then '14/11/22   James Woosnam   SIR5533 - Use HasIJPOpenSubscription
                pUserDisqusPayload.ReasonDescription = "User doesn't have access to IJP Open."
                pUserDisqusPayload.ReasonCode = HttpStatusCode.Forbidden '9/11/22 - changed to Forbidden as requested by Jordan
                Exit Try
            End If
            Dim DisqusInterface As New DisqusInterface(db, UserSess)
            '7/12/22    James Woosnam   SIR5602 - User Full Name as Disqus UserName
            pUserDisqusPayload.Payload = DisqusInterface.GetPayload(user_id:=UserSess.UserId, user_name:=UserSess.UserFullName, user_email:=UserSess.Data("EmailAddress"))
            pUserDisqusPayload.PublicKey = DisqusInterface.APIPublicKey
            pUserDisqusPayload.ReasonCode = HttpStatusCode.OK
        Catch ex As Exception
            pUserDisqusPayload.ReasonDescription = Me.HandleError(ex)
        Finally
            Try
                Logs.WriteSessionLog(LogType:="PEPSecurity",
                                                             PageId:="020",
                                                             PageTitle:="GetUser",
                                                             UserId:=UserIdForLogging,
                                                             UserName:=UserSess.UserName,
                                                             RemoteIPAddress:=Me.RemoteIPAddress,
                                                             Comment:=pUserDisqusPayload.ReasonDescription + UserSess.SessionLogExtraComment,
                                                             IsReadOnlyOnSecondary:=False,
                                                             IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                                                             IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)
            Catch ex As Exception
            End Try
        End Try
        Return pUserDisqusPayload
    End Function

    Public Sub AddUpdateUserClientSettings(UserId As Integer, ClientSettings As Object, SendJournalAlerts As Boolean, SendVideoAlerts As Boolean, SessionId As String)
        '9/2/21     James Woosnam   SIR5176 - Add SendJournalAlerts & SendVideoAlerts
        Dim ErrMsg As String = ""
        Try
            UserSess.Restore(SessionId)
            UserIdForLogging = UserSess.UserId
            If UserId <> UserSess.UserId Then
                Throw New Exception("UserId does not match Sessionid")
            End If
            Dim tranStartedHere As Boolean = False
            If db.DBTransaction Is Nothing Then
                db.BeginTran() 'Start tran to right session data updates in one go
                tranStartedHere = True
            End If
            Try
                Dim ru As New RemoteUser(UserId, db, UserSess)
                Try
                    ru.RemoteUserRow("PEPWebClientSettings") = Newtonsoft.Json.JsonConvert.SerializeObject(ClientSettings, Newtonsoft.Json.Formatting.Indented)
                    ru.RemoteUserRow("SendJournalAlerts") = SendJournalAlerts
                    ru.RemoteUserRow("SendVideoAlerts") = SendVideoAlerts
                    UserSess.Data("PEPWebClientSettings") = ru.RemoteUserRow("PEPWebClientSettings")
                    UserSess.Data("SendJournalAlerts") = ru.RemoteUserRow("SendJournalAlerts")
                    UserSess.Data("SendVideoAlerts") = ru.RemoteUserRow("SendVideoAlerts")
                    UserSess.Save() 'As in transaction need to explicitly save data changes
                Catch ex As Exception
                    Throw New Exception("ClientSettings can't be serialised", ex)
                End Try
                ru.Save()
                If tranStartedHere Then db.CommitTran()
            Catch ex As Exception
                If tranStartedHere Then db.RollbackTran()
                Throw ex
            End Try

        Catch ex As Exception
            ErrMsg = Me.HandleError(New Exception("AddUpdateUserClientSettings failed:" & ex.Message))
            Throw New Exception(ErrMsg)
        Finally
            Try
                Logs.WriteSessionLog(LogType:="PEPSecurity",
                                                             PageId:="021",
                                                             PageTitle:="AddUpdateUserClientSettings",
                                                             UserId:=UserIdForLogging,
                                                             UserName:=UserSess.UserName,
                                                             RemoteIPAddress:=Me.RemoteIPAddress,
                                                             Comment:=ErrMsg + UserSess.SessionLogExtraComment,
                                                             IsReadOnlyOnSecondary:=False,
                                                             IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                                                             IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)
            Catch ex As Exception
            End Try
        End Try
    End Sub
    Public Class ClientConfiguration
        Public PaDSLogonURL As String
        Public PaDSPasswordResetURL As String 'Will take the user to where they can change their password
        Public PaDSRegisterUserURL As String 'Will take the user to a form where they can register as a user
        Public GenericFederatedURL As String 'This this the URL for re-dirct to generic OpenAthens portal
        Public FederatedLinks As Object 'JSON of the Federated URLs to display on the client(Array of Name, URL) 
        Public ReasonDescription As String

    End Class
    Public Function GetClientConfiguration(SessionId As String) As ClientConfiguration
        Dim rClientConfiguration As New ClientConfiguration

        Try
            UserSess.Restore(SessionId)
            UserIdForLogging = UserSess.UserId

            rClientConfiguration.PaDSLogonURL = db.GetParameterValue("WebSiteURL") & "/Pages/pg070Logon.aspx?" & UserSess.QueryString
            rClientConfiguration.PaDSPasswordResetURL = db.GetParameterValue("WebSiteURL") & "/Pages/pg070Logon.aspx?Action=RequestPassword&" & UserSess.QueryString
            rClientConfiguration.PaDSRegisterUserURL = db.GetParameterValue("WebSiteURL") & "/Pages/pg117AddNewSubscriber.aspx?PageMode=BasicDetails&" & UserSess.QueryString

            Dim PaDSFederatedPortalURL As String = db.GetParameterValue("PaDSFederatedPortalURL", "https://localhost:44301/")
            rClientConfiguration.GenericFederatedURL = PaDSFederatedPortalURL & "?FederatedEntity=Default&" & UserSess.QueryString

            '29/9/21    James Woosnam   SIR5333 - Add scope in query string
            Dim tLinks As DataTable = db.GetDataTableFromSQL("
                        SELECT 
	                        Name = ru.UserFullName                         
	                        ,URL = '" & PaDSFederatedPortalURL & "?FederatedEntity=' + al.FederatedEntity + '&FederatedScope=' + al.FederatedScope + '&" & UserSess.QueryString & "'
                        FROM RemoteUserAutoLogon al
	                        INNER JOIN RemoteUser ru
	                        ON ru.UserId = al.UserId 
                        WHERE ru.UserStatus = 'Active'
                        AND al.AutoLogonStatus = 'Active'
                        AND al.AutoLogonType = 'Federated'
                        AND al.IsFederatedLinkRequired = 1
                        ORDER BY
                            ru.UserFullName 
                        ")
            tLinks.TableName = "FederatedLinks"
            If tLinks.Rows.Count > 0 Then
                Dim d As New DataSet
                d.Tables.Add(tLinks)
                rClientConfiguration.FederatedLinks = Newtonsoft.Json.JsonConvert.SerializeObject(d)
            End If
        Catch ex As Exception
            rClientConfiguration.ReasonDescription = Me.HandleError(ex)
        Finally
            Try
                Logs.WriteSessionLog(LogType:="PEPSecurity",
                                                             PageId:="040",
                                                             PageTitle:="GetClientConfiguration",
                                                             UserId:=UserIdForLogging,
                                                             UserName:=UserSess.UserName,
                                                             RemoteIPAddress:=Me.RemoteIPAddress,
                                                             Comment:=rClientConfiguration.ReasonDescription + UserSess.SessionLogExtraComment,
                                                             IsReadOnlyOnSecondary:=False,
                                                             IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                                                             IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)
            Catch ex As Exception
            End Try
        End Try
        Return rClientConfiguration
    End Function
    Public Class UserAlerts

        Public UserAlertInfo As Object 'JSON of the Federated URLs to display on the client(Array of Name, URL) 
        Public ReasonDescription As String

    End Class
    Public Function GetUserAlerts(SessionId As String) As UserAlerts
        Dim rUserAlerts As New UserAlerts

        Try
            UserSess.Restore(SessionId)
            UserIdForLogging = UserSess.UserId

            '18/1/23    James Woosnam   SIR5621 - Stop duplicate for admin users linked to multiple subscribers.
            Dim tAlerts As DataTable = db.GetDataTableFromSQL("
    SELECT
	    u.UserId 
	    ,u.UserFullName 
	    ,s.FirstName 
	    ,LastName = ISNULL(s.LastName ,u.UserFullName )
	    ,u.EmailAddress 
	    ,SendJournalAlerts = ISNULL(u.SendJournalAlerts ,0)
	    ,SendVideoAlerts = ISNULL(u.SendVideoAlerts,0)
    FROM RemoteUser u
	    LEFT JOIN RemoteUserRights rur
		    INNER JOIN Subscriber s
		    ON s.SubscriberId = rur.RightsToId 
            AND s.EntityType = 'Person'
	    ON rur.UserId = u.UserId 
	    AND rur.RightsType = 'Subscriber'
    WHERE u.UserStatus = 'Active'
    AND (U.SendJournalAlerts = 1 OR u.SendVideoAlerts = 1)
                        ")
            tAlerts.TableName = "UserAlerts"
            If tAlerts.Rows.Count > 0 Then
                Dim d As New DataSet
                d.Tables.Add(tAlerts)
                rUserAlerts.UserAlertInfo = Newtonsoft.Json.JsonConvert.SerializeObject(d)
            End If
        Catch ex As Exception
            rUserAlerts.ReasonDescription = Me.HandleError(ex)
        Finally
            Try
                Logs.WriteSessionLog(LogType:="PEPSecurity",
                                                             PageId:="050",
                                                             PageTitle:="GetUserAlerts",
                                                             UserId:=UserIdForLogging,
                                                             UserName:=UserSess.UserName,
                                                             RemoteIPAddress:=Me.RemoteIPAddress,
                                                             Comment:=rUserAlerts.ReasonDescription + UserSess.SessionLogExtraComment,
                                                             IsReadOnlyOnSecondary:=False,
                                                             IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                                                             IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)
            Catch ex As Exception
            End Try
        End Try
        Return rUserAlerts
    End Function
    Public Class RepopulateAllPEPWebContentReturn

        Public ReasonDescription As String

    End Class
    Public Function ProcessRepopulateAllPEPWebContentRequest() As RepopulateAllPEPWebContentReturn
        Dim RepopulateAllPEPWebContentReturn As New RepopulateAllPEPWebContentReturn

        Try
            Dim IsTestSubmission As Boolean = False
            Try 'if test3 user has logged on i last minue then assume test run and pause job.
                If db.DLookup("UserId", "RemoteUser", "UserName='Test3' AND DATEADD(MINUTE,1,LastLoggedOn) > GETDATE()") IsNot Nothing Then IsTestSubmission = True
            Catch ex As Exception
            End Try
            Me._UserSess = New BusinessLogic.UserSession(db)
            UserSess.Restore("")
            UserSess.Logon(db.GetParameterValue("AdminUserName", "AdminUser"), db.GetParameterValue("AdminPassword"))
            UserIdForLogging = UserSess.UserId
            Dim sql As String = "
SELECT *
,StartTime=ISNULL(j.ActualStartDateTime ,j.ScheduledStartDateTime )
FROM BatchJob j
WHERE j.BatchJobName = 'RepopulateAllPEPWebContent'
AND j.BatchJobStatus IN ('Pending','Started')
AND ISNULL(j.ActualStartDateTime ,j.ScheduledStartDateTime ) > DATEADD(MINUTE,-60,GETDATE())
ORDER BY ISNULL(j.ActualStartDateTime ,j.ScheduledStartDateTime ) DESC
"
            Dim tJobs As DataTable = db.GetDataTableFromSQL(sql)
            If tJobs.Rows.Count > 0 Then
                Try
                    If IsTestSubmission Then db.ExecuteSQL("UPDATE BatchJob SET BatchJobStatus='PendingPaused' WHERE BatchJobId =" & tJobs.Rows(0)("BatchJobId"))
                Catch ex As Exception
                End Try
                Throw New Exception("Failed:A RepopulateAllPEPWebContent has been submitted at " & CDate(tJobs.Rows(0)("StartTime")).ToString("dd-MMM-yy HH:mm:ss") & " another job can't be submitted within an hour of this")
            End If
            Dim PEPContent As New BusinessLogic.PEPwebContent(db, UserSess)
            PEPContent.SubmitRepopulateAllPEPWebContent()

            UserSess.SessionLogExtraComment += "RepopulateAllPEPWebContent successfully submitted."
        Catch ex As Exception
            RepopulateAllPEPWebContentReturn.ReasonDescription = Me.HandleError(ex)
        Finally
            Try
                Logs.WriteSessionLog(LogType:="PEPSecurity",
                                                             PageId:="060",
                                                             PageTitle:="RepopulateAllPEPWebContentRequest",
                                                             UserId:=UserIdForLogging,
                                                             UserName:=UserSess.UserName,
                                                             RemoteIPAddress:=Me.RemoteIPAddress,
                                                             Comment:=RepopulateAllPEPWebContentReturn.ReasonDescription + UserSess.SessionLogExtraComment,
                                                             IsReadOnlyOnSecondary:=False,
                                                             IsDatabaseServerPrimaryOrSecondary:=db.IsDatabaseServerPrimaryOrSecondary,
                                                             IsWebServerPrimaryOrSecondary:=db.IsWebServerPrimaryOrSecondary)
            Catch ex As Exception
            End Try
        End Try
        Return RepopulateAllPEPWebContentReturn
    End Function
    Function HandleError(ex As Exception) As String
        Dim sRet As String = ""
        Logs.LogErrorMessage(ex)

        Return ex.Message

        '**Not sure which one we want**
        sRet = "Unexpected error encountered."
        If db.ShowFullError Then
            sRet += " ShowFullError:" & ex.Message
        Else
            sRet += " Set ShowFullError for more."
        End If
        Return sRet
    End Function
#End Region


End Class
