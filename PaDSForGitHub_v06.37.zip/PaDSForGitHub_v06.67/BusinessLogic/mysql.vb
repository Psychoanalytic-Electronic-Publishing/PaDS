Imports System
Imports System.Threading.Tasks
Imports System.Data
Imports MySql.Data.MySqlClient
Imports Amazon
Imports Amazon.SecretsManager
Imports Amazon.SecretsManager.Model
Imports Newtonsoft.Json.Linq

Public Class DatabaseConnector
    '16/12/24   James Woosnam   SIR5777 - Initial version to support direct reads for PEP MySQL database

    Private Shared _connection As MySqlConnection
    Private Shared _connectionString As String
    Private _db As Database = Nothing
    Public Property db() As Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As Database)

            Me._db = value
        End Set
    End Property
    Public BatchLog As BatchLog = Nothing
    Public Sub New(db As Database)
        Me.db = db

    End Sub
    ' Fetch RDS credentials once and build the connection string
    Private Shared Function InitialiseConnectionString(secretName As String, region As String)
        If _connectionString Is Nothing Then
            Dim client = New AmazonSecretsManagerClient(RegionEndpoint.GetBySystemName(region))
            Dim request = New GetSecretValueRequest With {
                .SecretId = secretName
            }

            '  Dim response = Await client.GetSecretValue(request)
            Dim response = client.GetSecretValue(request)
            Dim secretJson = response.SecretString

            Dim secret = JObject.Parse(secretJson)

            Dim host = secret("host").ToString()
            Dim port = secret("port").ToString()
            Dim username = secret("username").ToString()
            Dim password = secret("password").ToString()
            Dim database = secret("dbname").ToString()

            _connectionString = $"Server={host};Port={port};Database={database};Uid={username};Pwd={password};Connection Timeout=120"
        End If
    End Function

    ' Get or create the database connection (Singleton pattern)
    Public ReadOnly Property Connection() As MySqlConnection
        Get
            If _connection Is Nothing Then
                _connection = New MySqlConnection(_connectionString)
            End If
            If _connection.State <> ConnectionState.Open Then
                _connection.Open()
            End If
            If Me.BatchLog IsNot Nothing Then BatchLog.Update("Connection Open")

            Return _connection
        End Get
    End Property

    Public Function GetTableFromSQL(Sql As String, secretName As String, region As String) As DataTable
        Dim cmd As MySqlCommand = Nothing

        Try
            InitialiseConnectionString(secretName, region)
            If Me.BatchLog IsNot Nothing Then BatchLog.Update("_connectionString populated")

            cmd = New MySqlCommand(Sql, Me.Connection)
            cmd.CommandTimeout = 600
            If Me.BatchLog IsNot Nothing Then BatchLog.Update("cmd initiated")

            Dim da As New MySqlDataAdapter(cmd)
            Dim tbl As New DataTable
            da.Fill(tbl)
            Return tbl
        Catch ex As Exception
            If Me.BatchLog IsNot Nothing Then BatchLog.Update("GetTableFromSQL Failed:" & ex.Message & " SQL:" & Sql & " ConnStr:" & Left(_connectionString, 90) & "....")
            Throw ex
        Finally
            If cmd IsNot Nothing Then
                cmd.Dispose()
                cmd = Nothing
            End If
        End Try
        Return Nothing
    End Function

End Class
