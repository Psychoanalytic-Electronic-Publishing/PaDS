﻿Imports System
Imports System.Web.Script.Serialization
Imports System.Security.Cryptography
Imports System.Text

Public Class DisqusInterface
    '3/11/22   James Woosnam   SIR5533 - Initial Version
    Dim APISecretKey As String = ""
    Public APIPublicKey As String = ""
    Dim UserSess As BusinessLogic.UserSession
    Private db As Database = Nothing

    Sub New(ByVal db As Database, ByRef UserSession As UserSession)
        Me.db = db
        Me.UserSess = UserSession
        'To get keys goto https://disqus.com/api/applications/ and log on as pep
        APISecretKey = db.GetParameterValue("DISQUS_SECRET_KEY")
        APIPublicKey = db.GetParameterValue("DISQUS_PUBLIC_KEY")

    End Sub
    Function GetPayload(ByVal user_id As String, ByVal user_name As String, ByVal user_email As String, ByVal Optional avatar_url As String = "", ByVal Optional website_url As String = "") As String
        Try
            Dim userdata = New With {Key .id = user_id, Key .username = user_name, Key .email = user_email, Key .avatar = avatar_url, Key .url = website_url}

            Dim serializedUserData As String = New JavaScriptSerializer().Serialize(userdata)
            Return GeneratePayload(serializedUserData)

        Catch ex As Exception
            Throw New Exception("GetPayload Failed: " & ex.Message)
        End Try
    End Function

    Private Function GeneratePayload(ByVal serializedUserData As String) As String
        Try
            Dim userDataAsBytes As Byte() = Encoding.UTF8.GetBytes(serializedUserData)
            Dim Message As String = System.Convert.ToBase64String(userDataAsBytes)
            Dim ts As TimeSpan = (DateTime.UtcNow - New DateTime(1970, 1, 1, 0, 0, 0))
            Dim Timestamp As String = Convert.ToInt32(ts.TotalSeconds).ToString()
            Dim messageAndTimestampBytes As Byte() = Encoding.UTF8.GetBytes(Message & " " & Timestamp)
            Dim apiBytes As Byte() = Encoding.UTF8.GetBytes(APISecretKey)
            Dim Value As String = Nothing
            Using hmac As HMACSHA1 = New HMACSHA1(apiBytes)
                Dim hashedMessage As Byte() = hmac.ComputeHash(messageAndTimestampBytes)
                Dim payLoad As String = Message & " " & ByteToString(hashedMessage) & " " & Timestamp
                Return payLoad
            End Using

        Catch ex As Exception
            Throw New Exception("GeneratePayload Failed:" & ex.Message)
        End Try
    End Function

    Private Function ByteToString(ByVal buff As Byte()) As String
        Dim sbinary As String = ""
        For i As Integer = 0 To buff.Length - 1
            sbinary += buff(i).ToString("X2")
        Next
        Return (sbinary)
    End Function
    Public Function GetImbedScript(PageURL As String, PageId As String) As String
        Try
            Dim ru As New RemoteUser(UserSess.UserId, db, UserSess)
            '7/12/22    James Woosnam   SIR5602 - User Full Name as Disqus UserName
            Dim js As String = "
<script>
var disqus_config = function () {
    this.page.remote_auth_s3 = '" & Me.GetPayload(user_id:=ru.UserId, user_name:=ru.RemoteUserRow("UserFullName"), user_email:=ru.EmailAddress) & "'
    this.page.api_key = '" & Me.APIPublicKey & "';
    this.page.url = '" & PageURL & "';
    this.page.identifier = '" & PageId & "';
};

(function() {  // REQUIRED CONFIGURATION VARIABLE: EDIT THE SHORTNAME BELOW
    var d = document, s = d.createElement('script');
    s.src = 'https://pepweb.disqus.com/embed.js';
    s.setAttribute('data-timestamp', +new Date());
    (d.head || d.body).appendChild(s);
})();
</script>"
            Return js
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class

