Imports System
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Data.Entity.Spatial

Partial Public Class vw458PEPUsageSummaryForPivot
    <Key>
    Public Property PEPUsageSummaryId As Integer

    Public Property MonthStartDate As Date?

    <StringLength(150)>
    Public Property ReportingParentSubscriberName As String

    Public Property ReportingParentSubscriberId As Integer?

    <StringLength(20)>
    Public Property ReportingParentType As String

    Public Property OrderNumber As Integer?

    <StringLength(50)>
    Public Property LoggedInMethod As String

    <StringLength(200)>
    Public Property UserName As String

    <StringLength(200)>
    Public Property UserFullName As String

    <StringLength(100)>
    Public Property UserCountry As String

    <StringLength(50)>
    Public Property MediaType As String

    <StringLength(200)>
    Public Property PEPCode As String

    <StringLength(200)>
    Public Property DocumentVolume As String

    <StringLength(4)>
    Public Property DocumentYear As String

    <StringLength(200)>
    Public Property documentRef As String

    <StringLength(200)>
    Public Property authorMast As String

    <StringLength(20)>
    Public Property ArchiveOrCurrent As String

    Public Property UserActivitySessionCount As Integer?

    Public Property AbstractCount As Integer?

    Public Property ReadCount As Integer?

    Public Property SearchCount As Integer?

    Public Property TurnAwayCount As Integer?
End Class
