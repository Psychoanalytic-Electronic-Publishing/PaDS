/*
If required creates a default value on the tables
This is needed as replication overwrites this on secondary server

*/
IF NOT EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'DF_Product_IsForReporting')
	ALTER TABLE dbo.Product ADD CONSTRAINT
		DF_Product_IsForReporting DEFAULT 0 FOR IsForReporting
	
IF NOT EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'DF_Product_IsCarriageCharge')
	ALTER TABLE dbo.Product ADD CONSTRAINT
		DF_Product_IsCarriageCharge DEFAULT 0 FOR IsCarriageCharge