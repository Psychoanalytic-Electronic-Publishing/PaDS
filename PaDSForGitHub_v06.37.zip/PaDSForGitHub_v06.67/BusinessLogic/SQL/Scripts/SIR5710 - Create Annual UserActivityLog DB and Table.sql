/*    ==Scripting Parameters==

    Source Server Version : SQL Server 2017 (14.0.1000)
    Source Database Engine Edition : Microsoft SQL Server Express Edition
    Source Database Engine Type : Standalone SQL Server

    Target Server Version : SQL Server 2017
    Target Database Engine Edition : Microsoft SQL Server Express Edition
    Target Database Engine Type : Standalone SQL Server
*/

USE [master]
GO

/****** Object:  Database [PaDS_Logs_UserAction2024]    Script Date: 14/11/2023 20:36:01 ******/
CREATE DATABASE [PaDS_Logs_UserAction2024]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'PaDS_Logs_UserAction2024', FILENAME = N'c:\Data\MSSQL\PaDS_Logs_UserAction2024.mdf' , SIZE = 1286144KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'PaDS_Logs_UserAction2024_log', FILENAME = N'c:\Data\MSSQL\PaDS_Logs_UserAction2024_log.ldf' , SIZE = 57344KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET COMPATIBILITY_LEVEL = 140
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [PaDS_Logs_UserAction2024].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET ANSI_NULL_DEFAULT OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET ANSI_NULLS OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET ANSI_WARNINGS OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET ARITHABORT OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET AUTO_CLOSE OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET AUTO_SHRINK OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET CONCAT_NULL_YIELDS_NULL OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET QUOTED_IDENTIFIER OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET  DISABLE_BROKER 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET HONOR_BROKER_PRIORITY OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET RECOVERY SIMPLE 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET  MULTI_USER 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET PAGE_VERIFY CHECKSUM  
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET DB_CHAINING OFF 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET DELAYED_DURABILITY = DISABLED 
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET QUERY_STORE = OFF
GO

USE [PaDS_Logs_UserAction2024]
GO

ALTER DATABASE SCOPED CONFIGURATION SET IDENTITY_CACHE = ON;
GO

ALTER DATABASE SCOPED CONFIGURATION SET LEGACY_CARDINALITY_ESTIMATION = OFF;
GO

ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET LEGACY_CARDINALITY_ESTIMATION = PRIMARY;
GO

ALTER DATABASE SCOPED CONFIGURATION SET MAXDOP = 0;
GO

ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET MAXDOP = PRIMARY;
GO

ALTER DATABASE SCOPED CONFIGURATION SET PARAMETER_SNIFFING = ON;
GO

ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET PARAMETER_SNIFFING = PRIMARY;
GO

ALTER DATABASE SCOPED CONFIGURATION SET QUERY_OPTIMIZER_HOTFIXES = OFF;
GO

ALTER DATABASE SCOPED CONFIGURATION FOR SECONDARY SET QUERY_OPTIMIZER_HOTFIXES = PRIMARY;
GO

ALTER DATABASE [PaDS_Logs_UserAction2024] SET  READ_WRITE 
GO


USE [PaDS_Logs_UserAction2024]

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') CREATE USER [PaDSSQLServerUser] FOR LOGIN [PaDSSQLServerUser] WITH DEFAULT_SCHEMA=[dbo]
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLSecurityUser') CREATE USER [PaDSSQLSecurityUser] FOR LOGIN [PaDSSQLSecurityUser] WITH DEFAULT_SCHEMA=[dbo]

EXEC sys.sp_addrolemember @rolename= 'db_datareader', @membername= 'PaDSSQLServerUser'

EXEC sys.sp_addrolemember @rolename= 'db_datawriter', @membername= 'PaDSSQLServerUser'

EXEC sys.sp_addrolemember @rolename= 'db_owner', @membername= 'PaDSSQLSecurityUser'

go

/*    ==Scripting Parameters==

    Source Server Version : SQL Server 2017 (14.0.1000)
    Source Database Engine Edition : Microsoft SQL Server Express Edition
    Source Database Engine Type : Standalone SQL Server

    Target Server Version : SQL Server 2017
    Target Database Engine Edition : Microsoft SQL Server Standard Edition
    Target Database Engine Type : Standalone SQL Server
*/

USE [PaDS_Logs_UserAction2024]
GO
/****** Object:  Table [dbo].[UserActionLog]    Script Date: 14/11/2023 20:41:56 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserActionLog](
	[UserActionLogId] [int] IDENTITY(1,1) NOT NULL,
	[FromLogRecordWithId] [int] NULL,
	[UserSessionId] [varchar](50) NOT NULL,
	[DateTime] [datetime] NOT NULL,
	[MonthStartDate] [datetime] NOT NULL,
	[ActionType] [varchar](37) NOT NULL,
	[UserId] [int] NULL,
	[LoggedInMethod] [varchar](50) NULL,
	[UserType] [varchar](50) NULL,
	[SubscriberId] [int] NULL,
	[SubscriberName] [varchar](150) NULL,
	[Institution_Id] [int] NULL,
	[Institution_Name] [varchar](150) NULL,
	[Access_Type] [varchar](50) NOT NULL,
	[Access_Method] [varchar](50) NOT NULL,
	[Data_Type] [varchar](50) NULL,
	[Publisher_ID] [varchar](50) NULL,
	[Section_Type] [varchar](50) NULL,
	[TitleId] [varchar](50) NULL,
	[TitleName] [varchar](200) NULL,
	[ItemId] [varchar](50) NULL,
	[ItemName] [varchar](200) NULL,
	[YOP] [int] NULL,
	[ISSN] [varchar](50) NULL,
	[ISBN] [varchar](50) NULL,
	[Language] [varchar](200) NULL,
	[OrderNumber] [int] NULL,
	[publisher] [nvarchar](200) NULL,
 CONSTRAINT [UserActionLog_PK] PRIMARY KEY NONCLUSTERED 
(
	[UserActionLogId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_UserActionLog_UserActionLog_Data_Type]    Script Date: 14/11/2023 20:41:56 ******/
CREATE NONCLUSTERED INDEX [IX_UserActionLog_UserActionLog_Data_Type] ON [dbo].[UserActionLog]
(
	[Data_Type] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_UserActionLog_UserActionLog_Institution_Id]    Script Date: 14/11/2023 20:41:56 ******/
CREATE NONCLUSTERED INDEX [IX_UserActionLog_UserActionLog_Institution_Id] ON [dbo].[UserActionLog]
(
	[Institution_Id] ASC
)
INCLUDE ( 	[Institution_Name]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [IX_UserActionLog_UserActionLog_MonthStartDate]    Script Date: 14/11/2023 20:41:56 ******/
CREATE NONCLUSTERED INDEX [IX_UserActionLog_UserActionLog_MonthStartDate] ON [dbo].[UserActionLog]
(
	[MonthStartDate] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_UserActionLog_UserActionLog_Various]    Script Date: 14/11/2023 20:41:56 ******/
CREATE NONCLUSTERED INDEX [IX_UserActionLog_UserActionLog_Various] ON [dbo].[UserActionLog]
(
	[ActionType] ASC,
	[Institution_Id] ASC,
	[Access_Type] ASC,
	[Access_Method] ASC,
	[Data_Type] ASC,
	[MonthStartDate] ASC
)
INCLUDE ( 	[UserId],
	[TitleId],
	[TitleName],
	[ItemId],
	[ItemName],
	[ISBN]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
