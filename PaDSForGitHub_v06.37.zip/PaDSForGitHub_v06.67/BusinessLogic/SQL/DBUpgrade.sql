﻿

DECLARE @NewDBVersion varchar(10)
DECLARE @OldDBVersion varchar(10)
DECLARE @CurrentDBVersion varchar(10)
DECLARE @SQL as varchar(max)
DECLARE @ProcName Varchar(50)
DECLARE @ServerName varchar(100)
DECLARE @DBName varchar(100)= DB_Name()
DECLARE @Message VARCHAR(2000)
DECLARE @RowCount INT
DECLARE @v sql_variant 
DECLARE @IsAtClient BIT = 0
DECLARE @LookupId INT

IF PATINDEX('%zedra%',@@ServerName) = 0
	SET @IsAtClient = 1

SELECT @ServerName = CASE WHEN @IsAtClient = 1 THEN 'PaDS01' ELSE  @@ServerName END

DECLARE @RunningAtClient BIT = ( SELECT CASE WHEN PATINDEX('%zedra%',@ServerName)=0 THEN 1 ELSE 0 END )

SET @OldDBVersion = '2.8'
SET @NewDBVersion = '2.9'
 
IF NOT EXISTS(SELECT * FROM stblParameters WHERE ParameterName = 'DatabaseVersion') INSERT INTO stblParameters(ParameterName,ParameterType,UserID,ParameterValue) SELECT 'DatabaseVersion','System','All','01.00'  
SELECT @CurrentDBVersion = ParameterValue FROM dbo.stblParameters WHERE ParameterName = 'DatabaseVersion'
SELECT 'Current Version: ' + @CurrentDBVersion

IF NOT (@CurrentDBVersion = @OldDBVersion OR  @CurrentDBVersion = @NewDBVersion)
OR @CurrentDBVersion IS NULL
BEGIN
	SELECT 'Current DB Version ' + ISNULL(@CurrentDBVersion,'EMPTY') + ' does not match'
END
ELSE
BEGIN
BEGIN TRANSACTION 
BEGIN TRY
print '1'

IF NOT EXISTS(SELECT * FROM CounterReport c WHERE c.Report_ID = 'DR' )
	INSERT INTO CounterReport (		Report_ID		,Report_Name		,ReportStatus		,DisplayOrder		,Details	)
	SELECT 
		Report_ID = 'DR'
		,Report_Name = 'Database Report'
		,ReportStatus = 'Active'
		,DisplayOrder = 15
		,Details = 'A customizable report detailing activity by database that allows the user to apply filters and select other configuration options.'
IF NOT EXISTS(SELECT * FROM CounterReport c WHERE c.Report_ID = 'DR_D1' )
	INSERT INTO CounterReport (		Report_ID		,Report_Name		,ReportStatus		,DisplayOrder		,Details	)
	SELECT 
		Report_ID = 'DR_D1'
		,Report_Name = 'Database Search and Item Usage'
		,ReportStatus = 'Active'
		,DisplayOrder = 15
		,Details = 'Reports on key Searches, Investigations and Requests metrics needed to evaluate a database.'
IF NOT EXISTS(SELECT * FROM CounterReport c WHERE c.Report_ID = 'DR_D2' )
	INSERT INTO CounterReport (		Report_ID		,Report_Name		,ReportStatus		,DisplayOrder		,Details	)
	SELECT 
		Report_ID = 'DR_D2'
		,Report_Name = 'Database Access Denied'
		,ReportStatus = 'Active'
		,DisplayOrder = 15
		,Details = 'Reports on Access Denied activity for databases where users were denied access because simultaneous-use licenses were exceeded or their institution did not have a license for the database..'

IF NOT EXISTS(SELECT * FROM stblParameters WHERE ParameterName = 'HandlingFeePercentForCompanyId5')
	INSERT INTO stblParameters select 'HandlingFeePercentForCompanyId5','Sysytem','All','0.03',getdate(),'jwoosnam'
	

--SIR5784
	IF NOT EXISTS(SELECT * FROM sysobjects o inner join syscolumns c on c.id = o.id where o.name = 'Company' and c.name = 'StripePrivateAPIKey')
		ALTER TABLE Company ADD
			StripePrivateAPIKey VARCHAR(500)
			,StripeProductCodeForCompanyPurchases VARCHAR(50)
	--IF NOT EXISTS(SELECT * FROM sysobjects o inner join syscolumns c on c.id = o.id where o.name = 'Company' and c.name = 'CompanyBankAccountIdForCardPayment')
	--	ALTER TABLE Company ADD
	--		CompanyBankAccountIdForCardPayment INT
	IF NOT EXISTS(SELECT * FROM sysobjects o inner join syscolumns c on c.id = o.id where o.name = 'CompanyBankAccount' and c.name = 'CompanyBankAccountId')
		ALTER TABLE CompanyBankAccount ADD
			CompanyBankAccountId INT IDENTITY(1,1)
	--IF NOT EXISTS(select * from stblParameters where ParameterName='CompanyBankAccountIdForStripeDeposites')
	--exec('	insert into stblParameters SELECT ''CompanyBankAccountIdForStripeDeposites'',''Sysytem'',''All'',CompanyBankAccountId,getdate(),''jwoosnam'' FROM CompanyBankAccount WHERE BankAccountNumber=''TBA'' AND BankSortCode=''TBA''')

	IF NOT EXISTS(SELECT * from Lookup WHERE LookupName = 'PaymentCardMerchant' AND LookupItemKey = 'Stripe')
	BEGIN
		INSERT INTO Lookup 
		VALUES('PaymentCardMerchant','Stripe',1,'Stripe','CompanyAdmin','1','Active', NULL,NULL)

		INSERT INTO Lookup 
		VALUES('PaymentCardMerchant','Stripe',2,'Stripe','CompanyAdmin','2','Active', NULL,NULL)
	END
	
	----**************************
	--Set New DB Version
	
	Update stblParameters
	SET ParameterValue =CAST( @NewDBVersion AS VARCHAR)
	WHERE ParameterName = 'DatabaseVersion'
	
--*************   END TRANSACTION *********************
Commit TRAN

SELECT 'Transaction Commited'
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SELECT 'Transaction Rolled Back'
	SELECT @Message = 'DBUpgrade Failed - Line:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE()
	
	RAISERROR ('%s', 18, 1,@Message)

END CATCH

END
