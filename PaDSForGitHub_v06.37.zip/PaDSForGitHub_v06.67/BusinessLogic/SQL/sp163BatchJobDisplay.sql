if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp163BatchJobDisplay]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp163BatchJobDisplay]
GO
CREATE  PROCEDURE sp163BatchJobDisplay (
				 @RecordsRequired INT  	--Number of recods to return
				,@FltrBatchJobName Varchar(50)
				,@FltrBatchJobStatus Varchar(20)
				,@FltrFromActualStartDate Varchar(50) = ''
				,@FltrToActualStartDate Varchar(50) = '')
AS
set nocount on
set arithignore on
DECLARE @ReturnError INT
DECLARE @From VARCHAR(2000)
DECLARE @Where VARCHAR(2000)
DECLARE @Columns VARCHAR(2000)
DECLARE @SQL VARCHAR(4000)
DECLARE @LF Varchar(5)
DECLARE @Today Varchar(11)
DECLARE @Records INT
DECLARE @RecordCount INT

SET @Today = CONVERT(Varchar(11),GetDate(),13)
SET @LF = CHAR(13) + CHAR(10)


SET @Where = ' WHERE 1=1'
If ISNULL(@FltrBatchJobName,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND BatchJob.BatchJobName LIKE ''%' + @FltrBatchJobName + '%''' + @LF
END
If ISNULL(@FltrBatchJobStatus,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND BatchJob.BatchJobStatus = ''' + @FltrBatchJobStatus + '''' + @LF
END

If ISNULL(@FltrFromActualStartDate,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND (BatchJob.ActualStartDateTime IS NULL OR BatchJob.ActualStartDateTime >= ''' + @FltrFromActualStartDate + ''')' + @LF
END
If ISNULL(@FltrToActualStartDate,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND (BatchJob.ActualStartDateTime IS NULL OR BatchJob.ActualStartDateTime <= ''' + @FltrToActualStartDate + ''')' + @LF
END

SET @From = '		
	FROM BatchJob  With (NoLock)
		LEFT JOIN BatchLog bl   With (NoLock)
		ON bl.BatchLogId =(SELECT MAX(bl.BatchLogId) FROM BatchLog bl WHERE bl.BatchJobId = BatchJob.BatchJobId)
             ' + @Where 

--Count records into Temp table
CREATE TABLE #RecordCount(RecordCount INT)

SET @SQL = '
INSERT INTO #RecordCount
SELECT (SELECT Count1=COUNT(*)  

			FROM (Select 1 Num ' + @From + ') ResultSet)
'			
execute (@SQL)
SELECT @RecordCount = RecordCount
FROM #RecordCount

SET @Columns = '
	SELECT  Top '  + CAST(@RecordsRequired as VARCHAR) + '
		ReturnError=CASE WHEN ' + CAST(@RecordCount as VARCHAR) + '=0 THEN 1 ELSE 0 END
		,ReturnMessage=CASE WHEN ' + CAST(@RecordCount as VARCHAR) + '=0 THEN ''No records match your search. Please try again'' ELSE'''' END
		,NoDisplayRecordCount = ' + CAST(@RecordCount as VARCHAR) + '
		,BatchJob.BatchJobId
		,BatchJob.BatchJobName
		,BatchJob.BatchJobStatus
		,BatchJob.ScheduledStartDateTime
		,BatchJob.ActualStartDateTime
		,BatchJob.EndDateTime
		,BatchJob.RescheduleDelaySeconds
		,BatchJob.ReScheduleFrom
		,BatchLogId = ISNULL(bl.BatchLogId,0)
		,BatchLogStatus = ISNULL(bl.BatchLogStatus,'''')
'
SET @From = @From + '
		ORDER BY BatchJob.BatchJobId Desc'

--Now Run the query
SET @SQL =  @Columns
			+ @From
execute (@SQL)
SELECT @ReturnError = @@Error, @Records= @@ROWCOUNT 
IF @ReturnError <> 0
BEGIN
	SELECT ReturnError=@ReturnError
		,ReturnMessage=master..sysmessages.description 
		from master..sysmessages where error=@returnerror
	RETURN
END	
set nocount off
set arithignore off

GO