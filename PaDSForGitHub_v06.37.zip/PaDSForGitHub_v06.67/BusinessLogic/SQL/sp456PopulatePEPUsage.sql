IF  exists (select * from dbo.sysobjects where id = object_id(N'sp456PopulatePEPUsage') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp456PopulatePEPUsage 
GO
CREATE  PROCEDURE sp456PopulatePEPUsage (
					@BatchLogId INT = NULL
)
AS
--16/3/22	James Woosnam	SIR5457 - Populate ArchiveOrCurrent
--21/3/22	James Woosnam	SIR5463 - Change AffiliateRateSubscriber to ReportingParentSubscriber
--20/4/22	James Woosnam	SIR5486 - Use vw433SalesOrderReportingParent 
--8/6/22	James Woosnam	SIR5459 - Add MediaType and MonthstartDate
--26/2/23	James Woosnam	HOTFIX: ItemOfInterest very occasionally more than 50 so truncate
DECLARE @RowCount INT = 0
	,@Message VARCHAR(MAX) = ''
DECLARE @ActivityLogLastPEPWebLogId INT=0
		,@ActivityLogLastPEPWebSessionLogIdAbstracts INT=0
		,@ActivityLogLastPEPWebSessionLogIdSearches INT=0
		,@AddFromDate DATETIME  = '01-feb-2021'


--IF NOT EXISTS(SELECT * FROM SYSOBJECTS WHERE Name='PEPUsage' ) EXECUTE('CREATE View PEPUsage AS SELECT * FROM [pads01].[PaDS_PEP_Activity_Log].dbo.PEPUsage')
IF NOT EXISTS(SELECT * FROM SYSOBJECTS WHERE Name='PEPUsage' ) EXECUTE('CREATE View PEPUsage AS SELECT * FROM [PaDS_PEP_Usage].dbo.PEPUsage')
IF EXISTS(SELECT PEPUsageId FROM PEPUsage) SELECT @AddFromDate = DATEADD(DAY,-1,min(mDate)) 
											FROM (SELECT mDate = MAX(DateTime) FROM PEPUsage WHERE ActionType  IN ('FullRead','FailedRead')
												UNION SELECT mDate = MAX(DateTime) FROM PEPUsage WHERE ActionType  IN ('Abstract')
												UNION SELECT mDate = MAX(DateTime) FROM PEPUsage WHERE ActionType  IN ('Search')
												) a

IF @BatchLogId IS NULL SELECT @BatchLogId = (SELECT MAX(BatchLogId) FROM BatchLog	)
	SELECT 
		us.UserSessionId 
		,UserId = MAX(us.UserId )
		,UserName = MAX(us.UserName )
		,UserFullName = MAX(CONVERT(VARCHAR(50),CASE WHEN usd.DataItemName = 'UserFullName' THEN usd.DataItemValue ELSE NULL END))
		,SubscriberId = MAX(CONVERT(INT,CASE WHEN usd.DataItemName = 'SubscriberId' THEN usd.DataItemValue ELSE NULL END))
		,SubscriberName = CAST(NULL AS VARCHAR(150))
		,OrderNumber = MAX(CONVERT(INT,CASE WHEN usd.DataItemName  = 'SubscriptionOrderNumber' THEN usd.DataItemValue ELSE NULL END))
		,SubscriptionEndDate = MAX(CONVERT(DATETIME,CASE WHEN usd.DataItemName  = 'SubscriptionEndDate' THEN usd.DataItemValue ELSE NULL END,103))
		,LoggedInMethod = MAX(CONVERT(VARCHAR(50),CASE WHEN usd.DataItemName  = 'LoggedInMethod' THEN usd.DataItemValue ELSE NULL END))
		,UserType = MAX(CONVERT(VARCHAR(50),CASE WHEN usd.DataItemName = 'UserType' THEN usd.DataItemValue ELSE NULL END))
		,UserCountry =CAST(NULL AS VARCHAR(150))
		,ReportingParentSubscriberName =CAST(NULL AS VARCHAR(150))
		,ReportingParentSubscriberId = CAST(NULL AS INT)
		,ReportingParentType = CAST(NULL AS VARCHAR(20) )
	INTO #SessOrder
	FROM UserSession us  With (nolock)
		INNER JOIN UserSessionData usd  With (nolock)
		ON usd.UserSessionId = us.UserSessionId 
	WHERE us.LastAccessedDate >= @AddFromDate
	 and us.UserId <> -1
	GROUP BY
		us.UserSessionId 
		,us.UserId 
		,us.UserName 
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #SessOrder records added';PRINT @Message;PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message
--19/10/21	James Woosnam	SIR5348 - Allow for Admin users
	UPDATE #SessOrder
	SET SubscriberName = s.SubscriberName
		,ReportingParentSubscriberId =  CASE 
											WHEN sess.userType = 'Admin' AND so.orderNumber IS NULL THEN -3
											WHEN so.orderNumber IS NULL THEN -2
											WHEN so.ReportingParentSubscriberId IS NULL THEN -1
										ELSE so.ReportingParentSubscriberId END
		,ReportingParentSubscriberName = CASE 
											WHEN sess.userType = 'Admin' AND so.orderNumber IS NULL  THEN '**Admin Users**' 
											WHEN so.orderNumber IS NULL THEN '**No Subscription Users**' 
											WHEN so.ReportingParentSubscriberId IS NULL THEN '**Individual Subscription Users**'
										ELSE rps.SubscriberName END
		,ReportingParentType = CASE
								WHEN sess.userType = 'Admin' AND so.orderNumber IS NULL  THEN 'Admin' 
								 WHEN so.orderNumber IS NULL THEN 'NoSubscription' 
								 WHEN so.ReportingParentSubscriberId IS NULL THEN 'IndividualUser'
								 WHEN so.ReportingParentType= 'Individual' THEN 'IndividualUser'
										ELSE so.ReportingParentType END
		,UserCountry = ISNULL((SELECT c.CountryName FROM Country c WHERE c.CountryId= s.PrimaryCountryId ),'Unknown')
	FROM #SessOrder sess
		LEFT JOIN Subscriber s
		ON s.SubscriberId = sess.SubscriberId
--20/4/22	James Woosnam	SIR5486 - Use vw433SalesOrderReportingParent 
		LEFT JOIN vw433SalesOrderReportingParent so
			LEFT JOIN Subscriber rps
			ON rps.SubscriberId = so.ReportingParentSubscriberId
		ON so.OrderNumber = sess.OrderNumber
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #SessOrder records updated';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message


	SELECT *
	INTO #Log
	FROM PEPUsage
	WHERE 1=2
	SET @RowCount = @@ROWCOUNT ;SET @Message =' #Log Table Created';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message

--Add FullReads 
	SELECT @ActivityLogLastPEPWebLogId = ISNULL(MAX(FromLogRecordWithId),0) FROM PEPUsage WHERE ActionType IN ('FullRead','FailedRead')
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@ActivityLogLastPEPWebLogId=' +CAST(@ActivityLogLastPEPWebLogId AS VARCHAR(20)) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	INSERT INTO #Log ( FromLogRecordWithId,	DateTime,	DateDay,	DateHour,	HourNumber,	GroupUserSessionBy,	Year,	Quarter,	Month,	ActionType,	LogonLocation,	LogonStatus,	LoggedUserName,	UserName,	UserFullName,	ReportingParentSubscriberName,	ReportingParentSubscriberId,	ReportingParentType,	OrderNumber,	UserCountry,	ReasonForCheck,	SubscriptionEndDate,	LoggedInMethod,	DocumentId,	UserSessionId, ReadCount)
	SELECT
		FromLogRecordWithId = l.PEPWebUsageLogId 
		,l.DateTime 
		,DateDay = FORMAT(l.DateTime ,'dd-MMM-yy')
		,DateHour = FORMAT(l.DateTime ,'dd-MMM-yy HH') + ':00:00'
		,HourNumber = FORMAT(l.DateTime ,'HH')
		,GroupUserSessionBy = FORMAT(l.DateTime ,'dd-MMM-yy') --day
		,rc.[Year]
		,rc.[Quarter]
		,rc.[Month]
		,ActionType = CASE 
							WHEN  l.LogonStatus  = 'Success' THEN 'FullRead' 
							WHEN  l.LogonStatus  = 'Failed' THEN 'FailedRead' 
							--WHEN l.ActionType = 'Authorise' THEN 'Abstract' SIR5325 - Abstracts now from OPAS Log below
							ELSE 'Unknown'  + ISNULL(l.LogonStatus,'')   END
		,l.LogonLocation 
		,l.LogonStatus 
		,LoggedUserName = so.UserName 
		,so.UserName   
		,so.UserFullName   
		,so.ReportingParentSubscriberName
		,so.ReportingParentSubscriberId
		,so.ReportingParentType 
		,so.OrderNumber 
		,so.UserCountry
		,l.ReasonForCheck
		,so.SubscriptionEndDate
		,so.LoggedInMethod
		,DocumentId = LEFT(l.DocumentId,50)
		,l.UserSessionId
		,ReadCount = CASE 
							WHEN  l.LogonStatus  = 'Success' THEN 1 
							ELSE 0  END
	FROM PEPWebUsageLog l
		INNER JOIN #SessOrder so
		ON so.UserSessionId = l.UserSessionId 
		left join contentdocuments d
			left join contentjournals j
			on j.pepcode = d.pepcode
		on d.DocumentId = l.DocumentId collate database_default
		LEFT JOIN ReportingCalendar rc
		ON rc.CalendarDate = CAST(FORMAT(l.DateTime ,'dd-MMM-yy') AS DATETIME)
	where 1=1
	AND l.PEPWebUsageLogId > @ActivityLogLastPEPWebLogId
	and l.DateTime >= @AddFromDate
	and l.LogonLocation = 'PEPSecurity'
	AND isnumeric(l.username)=1
	AND l.ActionType = 'Authorise'
	AND l.ReasonForCheck  = 'DocumentView'
	
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #Log records add for Reads';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message

--Abstracts
	SELECT @ActivityLogLastPEPWebSessionLogIdAbstracts = ISNULL(MAX(FromLogRecordWithId),0) FROM PEPUsage WHERE ActionType IN ('Abstract')
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@ActivityLogLastPEPWebSessionLogIdAbstracts=' +CAST(@ActivityLogLastPEPWebSessionLogIdAbstracts AS VARCHAR(20)) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	INSERT INTO #Log (FromLogRecordWithId,	 DateTime,	DateDay,	DateHour,	HourNumber,	GroupUserSessionBy,	Year,	Quarter,	Month,	ActionType,	LogonLocation,	LogonStatus,	LoggedUserName,	UserName,	UserFullName,	ReportingParentSubscriberName,	ReportingParentSubscriberId,	ReportingParentType,	OrderNumber,	UserCountry,	ReasonForCheck,	SubscriptionEndDate,	LoggedInMethod,	DocumentId,	UserSessionId, AbstractCount)
	SELECT
		FromLogRecordWithId=l.PEPWebSessionLogId 
		,l.LastUpdate 
		,DateDay = FORMAT(l.LastUpdate ,'dd-MMM-yy')
		,DateHour = FORMAT(l.LastUpdate ,'dd-MMM-yy HH') + ':00:00'
		,HourNumber = FORMAT(l.LastUpdate ,'HH')
		,GroupUserSessionBy = FORMAT(LastUpdate,'yyyy-MM-dd HH:mm:ss')--For search each one counts
		,rc.[Year]
		,rc.[Quarter]
		,rc.[Month]
		,ActionType = 'Abstract'
		,LogonLocation = 'PEPSecurity'
		,LogonStatus ='Success'
		,LoggedUserName = so.UserName 
		,so.UserName   
		,so.UserFullName   
		,so.ReportingParentSubscriberName
		,so.ReportingParentSubscriberId
		,so.ReportingParentType 
		,so.OrderNumber 
		,so.UserCountry
		,ReasonForCheck = 'AbstractView'
		,SubscriptionEndDate = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='SubscriptionEndDate' AND usd.UserSessionId = CAST(l.UserSessionId AS uniqueidentifier ))
		,LoggedInMethod = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='LoggedInMethod' AND usd.UserSessionId = CAST(l.UserSessionId AS uniqueidentifier ) )
--26/2/23	James Woosnam	HOTFIX: ItemOfInterest very occasionally more than 50 so truncate
		,DocumentId = LEFT(l.ItemOfInterest,50)
		,l.UserSessionId
		,AbstractCount=1
	FROM PEPWebSessionLog l
		INNER JOIN #SessOrder so
		ON so.UserSessionId = l.UserSessionId 
		LEFT JOIN ReportingCalendar rc
		ON rc.CalendarDate = CAST(FORMAT(l.LastUpdate ,'dd-MMM-yy') AS DATETIME)
	where 1=1
	AND l.PEPWebSessionLogId > @ActivityLogLastPEPWebSessionLogIdAbstracts
	AND l.Endpoint = '/Documents/Abstracts/{documentID}/'
	AND l.ReturnAddedStatusMessage LIKE '%Success%'
	and l.LastUpdate >= @AddFromDate
	
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #Log records add for Abstracts';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message

--16/3/22	James Woosnam	SIR5457 - Populate ArchiveOrCurrent
--8/6/22	James Woosnam	SIR5459 - Add MediaType 
	DECLARE @CurrentYear INT = (select dbo.fn017GetParameter('CurrentContentYear'))
	UPDATE #Log 
	SET documentRef = ISNULL(d.documentRef ,b.title )
		,MediaType = ISNULL(c.MediaType,b.MediaType)
		,PEPCode = ISNULL(c.PEPCode,b.PEPCode)
		,DocumentVolume=ISNULL(d.vol ,0)
		,DocumentYear=ISNULL(d.year ,b.pub_year )
		,authorMast=ISNULL(d.authorMast ,b.authors  )
		,ArchiveOrCurrent = CASE WHEN  ISNULL(ISNULL(c.embargoYears,b.embargoYears ),'0') = '0' THEN 'Archive'
								 WHEN CONVERT(INT,ISNULL(d.year ,b.pub_year )) >= @CurrentYear - CONVERT(INT,ISNULL(c.embargoYears,b.embargoYears )) THEN 'Current'
							ELSE 'Archive' END
	FROM #Log l
			LEFT JOIN ContentDocuments d
				LEFT JOIN (
					SELECT j.PEPCode 
						,j.sourceType 
						,j.Title 
						,j.ISSN 
						,ISBN = CAST('' AS VARCHAR(50))
						,j.language 
						,MediaType = CAST('Journal' AS VARCHAR(50))
						,j.embargoYears 
					FROM ContentJournals j
					UNION
					SELECT v.PEPCode 
						,v.sourceType 
						,v.Title 
						,v.ISSN 
						,ISBN = CAST('' AS VARCHAR(50))
						,v.language 
						,MediaType = CAST('Video' AS VARCHAR(50))
						,v.embargoYears 
					FROM ContentVideos v
					) c
				ON c.PEPCode = d.PEPCode 
			ON d.documentID = l.DocumentId 
			LEFT JOIN (
				SELECT b.PEPCode 
					,b.sourceType 
					,b.documentID 
					,b.Title 
					,b.ISSN 
					,ISBN = b.ISBN13 
					,b.language
					,MediaType = 'Book' --Might be book????  Book_Segment  A book segment (e.g. chapter, section, etc.). Note that MediaType Book_Segment is only applicable for Item Reports when the book segment is the item, in Title Reports this is represented by the Section_Type.
					,b.pub_year
					,b.authors 
					,b.embargoYears 
				FROM ContentBooks b
				) b
			on b.documentID = l.DocumentId  
			or replace(l.DocumentId ,'.','') like b.PEPCode + '%'
		WHERE ISNULL(l.DocumentId,'')<>''
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #Log updated with document info';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message

--Add Searches
	SELECT @ActivityLogLastPEPWebSessionLogIdSearches = ISNULL(MAX(FromLogRecordWithId),0) FROM PEPUsage WHERE ActionType IN ('Search')
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@ActivityLogLastPEPWebSessionLogIdSearches=' +CAST(@ActivityLogLastPEPWebSessionLogIdSearches AS VARCHAR(20)) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message
	INSERT INTO #Log (FromLogRecordWithId,	 DateTime,	DateDay,	DateHour,	HourNumber,	GroupUserSessionBy,	Year,	Quarter,	Month,	ActionType,	LogonLocation,	LogonStatus,	LoggedUserName,	UserName,	UserFullName,	ReportingParentSubscriberName,	ReportingParentSubscriberId,	ReportingParentType,	OrderNumber,	UserCountry,	ReasonForCheck,	SubscriptionEndDate,	LoggedInMethod,	UserSessionId, SearchCount)
	SELECT
		FromLogRecordWithId=l.PEPWebSessionLogId 
		,l.LastUpdate 
		,DateDay = FORMAT(l.LastUpdate ,'dd-MMM-yy')
		,DateHour = FORMAT(l.LastUpdate ,'dd-MMM-yy HH') + ':00:00'
		,HourNumber = FORMAT(l.LastUpdate ,'HH')
		,GroupUserSessionBy = FORMAT(LastUpdate,'yyyy-MM-dd HH:mm:ss')--For search each one counts
		,rc.[Year]
		,rc.[Quarter]
		,rc.[Month]
		,ActionType = 'Search'
		,LogonLocation = 'PEPSecurity'
		,LogonStatus ='Success'
		,LoggedUserName = so.UserName 
		,so.UserName   
		,so.UserFullName   
		,so.ReportingParentSubscriberName
		,so.ReportingParentSubscriberId
		,so.ReportingParentType 
		,so.OrderNumber 
		,so.UserCountry
		,ReasonForCheck = 'Search'
		,SubscriptionEndDate = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='SubscriptionEndDate' AND usd.UserSessionId = CAST(l.UserSessionId AS uniqueidentifier ))
		,LoggedInMethod = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='LoggedInMethod' AND usd.UserSessionId = CAST(l.UserSessionId AS uniqueidentifier ) )
		,l.UserSessionId
		,SearchCount=1
	FROM PEPWebSessionLog l
		INNER JOIN #SessOrder so
		ON so.UserSessionId = l.UserSessionId 
		LEFT JOIN ReportingCalendar rc
		ON rc.CalendarDate = CAST(FORMAT(l.LastUpdate ,'dd-MMM-yy') AS DATETIME)
	where 1=1
	AND l.PEPWebSessionLogId>@ActivityLogLastPEPWebSessionLogIdSearches
	AND l.Endpoint = '/Database/Search/'
	AND l.Params LIKE '%user=true%'
	and l.LastUpdate >= @AddFromDate
	
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #Log records add for searches';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message

--8/6/22	James Woosnam	SIR5459 -	Populate MonthstartDate
	UPDATE #Log 
	SET MonthStartDate = '01-' + FORMAT(l.DateTime,'MMM-yyyy')
	FROM #Log l

	UPDATE #Log 
	SET UserActivitySessionCount = l2.UserActivitySessionCount 
		,PaDSSessionDurationMinutes = l2.PaDSSessionDurationMinutes 
	FROM #Log l
		INNER JOIN (
	SELECT
	l.PEPUsageId
	,UserActivitySessionCount  =CASE WHEN DATEDIFF(MINUTE,ISNULL(llast.DateTime,'01-jan-1900'),l.DateTime) > 30 THEN 1 ELSE 0 END
	,PaDSSessionDurationMinutes = DATEDIFF(MINUTE,(SELECT MIN(l2.DateTime) FROM #Log l2 WHERE l2.UserSessionId = l.UserSessionId) , (SELECT MAX(l3.DateTime) FROM #Log l3 WHERE l3.UserSessionId = l.UserSessionId))
	FROM #Log l
		LEFT JOIN #Log lLast
		ON lLast.UserSessionId = l.UserSessionId 
		AND lLast.PEPUsageId <> l.PEPUsageId 
		AND lLast.DateTime <= l.DateTime 
		AND lLast.PEPUsageId = (SELECT MAX(l3.PEPUsageId) 
						FROM #Log l3
						WHERE l3.UserSessionId = l.UserSessionId 
						and l3.PEPUsageId <> l.PEPUsageId 
						AND l3.DateTime <= l.DateTime )
	 ) l2
	ON l2.PEPUsageId = l.PEPUsageId 
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #Log updated with SessionCount and Duration';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message

	--13/4/23	James Woosnam	SIR5459 - Add MediaType CORECTLY!!
	INSERT INTO PEPUsage
		(FromLogRecordWithId	,DateTime	,DateDay	,DateHour	,HourNumber	,GroupUserSessionBy	,Year	,Quarter	,Month	,MonthStartDate	,ActionType	,LogonLocation	,LogonStatus	,LoggedUserName	,UserName	,UserFullName	,ReportingParentSubscriberName	,ReportingParentSubscriberId	,ReportingParentType	,OrderNumber	,UserCountry	,ReasonForCheck	,SubscriptionEndDate	,LoggedInMethod	,DocumentId	,documentRef	,PEPCode	,DocumentVolume	,DocumentYear	,authorMast	,UserSessionId	,UserActivitySessionCount	,AbstractCount	,ReadCount	,SearchCount	,PaDSSessionDurationMinutes	,ArchiveOrCurrent	,MediaType)
	SELECT 
		 FromLogRecordWithId	,DateTime	,DateDay	,DateHour	,HourNumber	,GroupUserSessionBy	,Year	,Quarter	,Month	,MonthStartDate	,ActionType	,LogonLocation	,LogonStatus	,LoggedUserName	,UserName	,UserFullName	,ReportingParentSubscriberName	,ReportingParentSubscriberId	,ReportingParentType	,OrderNumber	,UserCountry	,ReasonForCheck	,SubscriptionEndDate	,LoggedInMethod	,DocumentId	,documentRef	,PEPCode	,DocumentVolume	,DocumentYear	,authorMast	,UserSessionId	,UserActivitySessionCount	,AbstractCount	,ReadCount	,SearchCount	,PaDSSessionDurationMinutes	,ArchiveOrCurrent	,MediaType
	FROM #Log
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' records added to PEPUsage';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message

	DELETE FROM PEPUsageSummary WHERE Month >= FORMAT(DATEADD(MONTH,-1,GETDATE()),'yyyy-MM MMM')
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' records deleted from PEPUsageSummary for last 2 months';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message
--11/4/22	James Woosnam	SIR5457 - Add ArchiveOrCurrent
--8/6/22	James Woosnam	SIR5459 - Add MediaType 
--26/2/23	James Woosnam	Split INSERT INTO PEPUsageSummary into 2 as OR in Where causing performance issues
	IF (SELECT COUNT(*) FROM PEPUsageSummary) = 0 
	--Repopulate all
			INSERT INTO PEPUsageSummary (
				Year	,Quarter	,Month	,UserName	,UserFullName	,ReportingParentSubscriberName	,ReportingParentSubscriberId	,ReportingParentType	,OrderNumber	,UserCountry	,LoggedInMethod	,DocumentId	,documentRef	,PEPCode	,DocumentVolume	,DocumentYear	,authorMast	,ArchiveOrCurrent	,MediaType
				,UserActivitySessionCount 	
				,AbstractCount	
				,ReadCount	
				,SearchCount
				,MonthStartDate
				  )
			SELECT
				u.Year	,u.Quarter	,u.Month	,u.UserName	,u.UserFullName	,u.ReportingParentSubscriberName	,u.ReportingParentSubscriberId	,u.ReportingParentType	,u.OrderNumber	,u.UserCountry	,u.LoggedInMethod	,u.DocumentId	,u.documentRef	,u.PEPCode	,u.DocumentVolume	,u.DocumentYear	,u.authorMast	,u.ArchiveOrCurrent	,u.MediaType
				,UserActivitySessionCount = SUM(UserActivitySessionCount)
				,AbstractCount = SUM(AbstractCount)
				,ReadCount = SUM(ReadCount)
				,SearchCount = SUM(SearchCount)
				,MonthStartDate = u.MonthStartDate
			FROM  PEPUsage u
			WHERE u.DateTime  >= '01-sep-2021'
			GROUP BY 
				u.Year	,u.Quarter	,u.Month	,u.UserName	,u.UserFullName	,u.ReportingParentSubscriberName	,u.ReportingParentSubscriberId	,u.ReportingParentType	,u.OrderNumber	,u.UserCountry	,u.LoggedInMethod	,u.DocumentId	,u.documentRef	,u.PEPCode	,u.DocumentVolume	,u.DocumentYear	,u.authorMast	,u.ArchiveOrCurrent	,u.MediaType
				,u.MonthStartDate
	ELSE
			INSERT INTO PEPUsageSummary (
				Year	,Quarter	,Month	,UserName	,UserFullName	,ReportingParentSubscriberName	,ReportingParentSubscriberId	,ReportingParentType	,OrderNumber	,UserCountry	,LoggedInMethod	,DocumentId	,documentRef	,PEPCode	,DocumentVolume	,DocumentYear	,authorMast	,ArchiveOrCurrent	,MediaType
				,UserActivitySessionCount 	
				,AbstractCount	
				,ReadCount	
				,SearchCount
				,MonthStartDate
				  )
			SELECT
				u.Year	,u.Quarter	,u.Month	,u.UserName	,u.UserFullName	,u.ReportingParentSubscriberName	,u.ReportingParentSubscriberId	,u.ReportingParentType	,u.OrderNumber	,u.UserCountry	,u.LoggedInMethod	,u.DocumentId	,u.documentRef	,u.PEPCode	,u.DocumentVolume	,u.DocumentYear	,u.authorMast	,u.ArchiveOrCurrent	,u.MediaType
				,UserActivitySessionCount = SUM(UserActivitySessionCount)
				,AbstractCount = SUM(AbstractCount)
				,ReadCount = SUM(ReadCount)
				,SearchCount = SUM(SearchCount)
				,MonthStartDate = u.MonthStartDate
			FROM  PEPUsage u
			WHERE u.DateTime  >= CONVERT(DATETIME,'01-' + FORMAT(DATEADD(MONTH,-1,GETDATE()),'MMM-yyyy'))
			GROUP BY 
				u.Year	,u.Quarter	,u.Month	,u.UserName	,u.UserFullName	,u.ReportingParentSubscriberName	,u.ReportingParentSubscriberId	,u.ReportingParentType	,u.OrderNumber	,u.UserCountry	,u.LoggedInMethod	,u.DocumentId	,u.documentRef	,u.PEPCode	,u.DocumentVolume	,u.DocumentYear	,u.authorMast	,u.ArchiveOrCurrent	,u.MediaType
				,u.MonthStartDate
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' records added to PEPUsageSummary for last 2 months';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message

DROP TABLE #Log

--26/6/22	James Woosnam	SIR5487 - Add Population of UsageByMonthDocument
	DECLARE @MostRecentMonth VARCHAR(30) = (SELECT MAX(MonthStart) FROM UsageByMonthDocument )
	IF @MostRecentMonth < '2021-12 Dec'
	BEGIN
		SET @Message = 'Invalid @MostRecentMonth populating in sp456PopulatePEPUsage:' + @MostRecentMonth 
		RAISERROR (@Message, 16, 1)
		RETURN
	END
	DELETE FROM UsageByMonthDocument WHERE MonthStart = @MostRecentMonth 
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' deleted from UsageByMonthDocument for:' + @MostRecentMonth ;PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message
	INSERT INTO UsageByMonthDocument 
	SELECT
		MonthStart = u.Month 
		,Source = 'NewPEP'
		,u.ReportingParentSubscriberId
		,u.ReportingParentSubscriberName 
		,document_id = u.DocumentId  
		,Journal = ISNULL(u.PEPCode,'DocIdNotKnownOnNewPEP')
		,Title = ISNULL(CAST(u.documentRef as varchar(500)),'DocIdNotKnownOnNewPEP')
		,DataType = ISNULL(u.MediaType,'DocIdNotKnownOnNewPEP')
		,ArchiveOrCurrent = CASE WHEN ISNULL(u.ArchiveOrCurrent,'')='' THEN 'Archive' ELSE u.ArchiveOrCurrent END
		,TotalHits = sum(u.ReadCount  )
	from PEPUsageSummary u
		LEFT JOIN RemoteUser ru
		ON ru.UserName = u.UserName
	where u.Month >= @MostRecentMonth
	and u.ReadCount is not null
	GROUP BY
	u.Month 
	,u.ReportingParentSubscriberId
	,u.ReportingParentSubscriberName 
	, u.DocumentId 
	, u.PEPCode
	,CAST(u.documentRef as varchar(500))
	,u.MediaType
	, u.ArchiveOrCurrent
	Order by
	u.Month 
	, u.DocumentId 
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' rows inserted into UsageByMonthDocument for:' + @MostRecentMonth ;PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message
GO
--EXEC sp456PopulatePEPUsage