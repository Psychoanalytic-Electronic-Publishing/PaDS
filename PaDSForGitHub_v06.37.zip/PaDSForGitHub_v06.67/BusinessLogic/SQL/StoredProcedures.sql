/*************************************************************************************
Stored Procedures
	sp400AddSalesOrderLines
	sp451DebtorsReport
	sp470renewalsList

Mods:
====
30/7/04 James Woosnam	sp400AddSalesOrderLines updated to only include live subscribers
**(Not released)**
8/3/05	James Wosonam	Fixed error due to SubCategory now being on Affilaition and take
						account of Despatch Delivery Area
17/8/05	James Woosnam	Add sp401AddSalesOrderSubscriberLine
22/9/05	James Woosnam	Only use Current Subs in sp400AddSalesOrderLines
2/8/06	James Woosnam	Update sp470renewalsList to conform to SIR108
31/3/11 James Woosnam   SIR2401 - sp470renewalsList Use the company specific address if available else use latest address
2/12/11	James WOosnam	Hot Fix - Remove Carriage return from Address1 in sp470renewalsList
30/1/12	James Woosnam	SIR2588 - Add @ForAuditDebtorCreditorsReport to sp451DebtorsReport
16/5/19 Julian Gates    SIR4759 - Removed Home and work telephone and Fax number fields
19/11/19	James Woosnam	sp470renewalsList no longer used so removed
--1/8/20	James Woosnam	SIR5051 - sp401AddSalesOrderSubscriberLine Use all if no delivery area

**************************************************************************************/
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp400AddSalesOrderLines]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp400AddSalesOrderLines]
GO
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp401AddSalesOrderSubscriberLine]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp401AddSalesOrderSubscriberLine]
GO
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp451DebtorsReport]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp451DebtorsReport]
GO
if exists (select * from sysobjects where id = object_id(N'[dbo].[sp470renewalsList]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp470renewalsList]
GO

CREATE PROCEDURE sp401AddSalesOrderSubscriberLine  ( @OrderNumber INT
													,@SubscriberId INT 
													,@DeliveryAddressId INT = 0 --Id 0 use DefaultPostalAddress 
													,@IfPresentAddAssociatedProductLine BIT --This will always be 1 unless a N found in PrintedCopy
													)
AS
/*
Add a single subscriber to an order

Modifications
=============
17/8/05		James Woosnam	Intiial Version
11/4/08		James Woosnam	SIR1517 - Allow Order lines to be set against a specified address
16/11/19	James Wosnam	SIR4949 - If product has an associated product then add an additional line, this is for EJV with JV
--26/11/19	James Woosnam	SIR4960 - Only add associated product if @IfPresentAddAssociatedProductLine=1
--1/8/20	James Woosnam	SIR5051 - Use all if no delivery area

*/
INSERT INTO SalesOrderLine
	(
	OrderNumber
	,SubscriberId
	,ProductCode
	,ProductRateId
	,DeliveryAddressId
	,ProductRate
	,Quantity
	,AmountProduct
	)
select SalesOrder.OrderNumber
	,SubscriberAffiliate.ChildSubscriberId
	,PrimaryProductCode
	,pr.ProductRateId
	,DeliveryAddressId = CASE WHEN ISNULL(@DeliveryAddressId,0) = 0 
								THEN Subscriber.DefaultPostalAddressId 
						ELSE @DeliveryAddressId END
	,pr.ProductRate
	,1 As Qunatity
	,pr.ProductRate as AmountProduct
From SalesOrder
	INNER JOIN CompanyAccount
		INNER JOIN Company
		On Company.CompanyId = CompanyAccount.CompanyId
	ON CompanyAccount.SubscriberId = SalesOrder.Subscriberid
	AND CompanyAccount.CompanyId = SalesOrder.CompanyId
	INNER JOIN SubscriberAffiliate
		INNER JOIN Subscriber
		ON Subscriber.SubscriberId = SubscriberAffiliate.ChildSubscriberid
	ON SubscriberAffiliate.ParentSubscriberId = SalesOrder.SubscriberID
	AND GETDATE() BETWEEN SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate
	LEFT JOIN DespatchDeliveryArea
	On DespatchDeliveryArea.CountryId = Subscriber.PrimaryCountryId
	AND DespatchDeliveryArea.CompanyId = SalesOrder.CompanyId
	INNER JOIN SubscriberAffiliate CompanyAffiliation
	ON CompanyAffiliation.parentSubscriberId =  Company.GroupParentSubscriberId
	AND CompanyAffiliation.ChildSubscriberId = SubscriberAffiliate.ChildSubscriberId
--1/8/20	James Woosnam	SIR5051 - Use all if no delivery area
	LEFT JOIN ProductRate pr
	ON pr.ProductRateId = (SELECT MAX(ProductRate.ProductRateId )
						FROM ProductRate 
						WHERE ProductRate.ProductCode = SalesOrder.PrimaryProductCode
						AND ProductRate.CurrencyCode = SalesOrder.CurrencyCode
						AND ProductRate.RateType = CompanyAccount.RateType
						AND ProductRate.AccountType = CompanyAccount.AccountType
						AND ProductRate.SubscriberCategory = CompanyAffiliation.SubscriberCategory
						AND (ProductRate.DeliveryArea = DespatchDeliveryArea.DespatchDeliveryArea
							OR (ProductRate.DeliveryArea <> DespatchDeliveryArea.DespatchDeliveryArea
								AND ProductRate.DeliveryArea = 'All')
							)
						)		
	LEFT JOIN SalesOrderLine
	ON SalesOrderLine.OrderNumber = SalesOrder.OrderNumber
	AND SalesOrderLine.SubscriberId = Subscriber.SubscriberId
where salesorder.ordernumber = @OrderNumber
AND SalesOrderLine.OrderNumber Is Null
AND Subscriber.SubscriberId = @SubscriberId

--16/11/19	James Wosnam	SIR4949 - If product has an associated product then add an additional line, this is for EJV with JV
--26/11/19	James Woosnam	SIR4960 - Only add associated product if @IfPresentAddAssociatedProductLine=1
DECLARE @AssociatedProductCode VARCHAR(10) = NULL
SET @AssociatedProductCode = (SELECT p.AssociatedProductCode
							FROM SalesOrder so
								INNER JOIN Product p 
								ON p.ProductCode = so.PrimaryProductCode 
							WHERE so.OrderNumber = @OrderNumber 
							AND p.AssociatedProductCode IS NOT NULL)

IF @AssociatedProductCode IS NOT NULL
AND @IfPresentAddAssociatedProductLine = 1
BEGIN
	INSERT INTO SalesOrderLine
		(
		OrderNumber
		,SubscriberId
		,ProductCode
		,ProductRateId
		,DeliveryAddressId
		,ProductRate
		,Quantity
		,AmountProduct
		)
	select SalesOrder.OrderNumber
		,SubscriberAffiliate.ChildSubscriberId
		,@AssociatedProductCode 
		,pr.ProductRateId
		,DeliveryAddressId = CASE WHEN ISNULL(@DeliveryAddressId,0) = 0 
									THEN Subscriber.DefaultPostalAddressId 
							ELSE @DeliveryAddressId END
		,pr.ProductRate
		,1 As Qunatity
		,pr.ProductRate as AmountProduct
	From SalesOrder
		INNER JOIN CompanyAccount
			INNER JOIN Company
			On Company.CompanyId = CompanyAccount.CompanyId
		ON CompanyAccount.SubscriberId = SalesOrder.Subscriberid
		AND CompanyAccount.CompanyId = SalesOrder.CompanyId
		INNER JOIN SubscriberAffiliate
			INNER JOIN Subscriber
			ON Subscriber.SubscriberId = SubscriberAffiliate.ChildSubscriberid
		ON SubscriberAffiliate.ParentSubscriberId = SalesOrder.SubscriberID
		AND GETDATE() BETWEEN SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate
		LEFT JOIN DespatchDeliveryArea
		On DespatchDeliveryArea.CountryId = Subscriber.PrimaryCountryId
		AND DespatchDeliveryArea.CompanyId = SalesOrder.CompanyId
		INNER JOIN SubscriberAffiliate CompanyAffiliation
		ON CompanyAffiliation.parentSubscriberId =  Company.GroupParentSubscriberId
		AND CompanyAffiliation.ChildSubscriberId = SubscriberAffiliate.ChildSubscriberId
--1/8/20	James Woosnam	SIR5051 - Use all if no delivery area
	LEFT JOIN ProductRate pr
	ON pr.ProductRateId = (SELECT MAX(ProductRate.ProductRateId )
						FROM ProductRate 
--10/12/21	James Woosnam	Use the @AssociatedProductCode to get the correct rates
						WHERE ProductRate.ProductCode = @AssociatedProductCode
						AND ProductRate.CurrencyCode = SalesOrder.CurrencyCode
						AND ProductRate.RateType = CompanyAccount.RateType
						AND ProductRate.AccountType = CompanyAccount.AccountType
						AND ProductRate.SubscriberCategory = CompanyAffiliation.SubscriberCategory
						AND (ProductRate.DeliveryArea = DespatchDeliveryArea.DespatchDeliveryArea
							OR (ProductRate.DeliveryArea <> DespatchDeliveryArea.DespatchDeliveryArea
								AND ProductRate.DeliveryArea = 'All')
							)
						)		
		LEFT JOIN SalesOrderLine
		ON SalesOrderLine.OrderNumber = SalesOrder.OrderNumber
		AND SalesOrderLine.SubscriberId = Subscriber.SubscriberId
		AND SalesOrderLine.ProductCode = @AssociatedProductCode 
	where salesorder.ordernumber = @OrderNumber
	AND SalesOrderLine.OrderNumber Is Null
	AND Subscriber.SubscriberId = @SubscriberId
END
Go

CREATE PROCEDURE sp400AddSalesOrderLines  ( @OrderNumber INT )
AS
/*
Used in pg142OrderMaint2.asp to "IncludeAllAfiliates"
*/
INSERT INTO SalesOrderLine
	(
	OrderNumber
	,SubscriberId
	,ProductCode
	,ProductRateId
	,DeliveryAddressId
	,ProductRate
	,Quantity
	,AmountProduct
	)
select SalesOrder.OrderNumber
	,SubscriberAffiliate.ChildSubscriberId
	,PrimaryProductCode
	,pr.ProductRateId
	,Subscriber.DefaultPostalAddressId DeliveryAddressId
	,pr.ProductRate
	,1 As Qunatity
	,pr.ProductRate as AmountProduct
From SalesOrder
	INNER JOIN CompanyAccount
		INNER JOIN Company
		On Company.CompanyId = CompanyAccount.CompanyId
	ON CompanyAccount.SubscriberId = SalesOrder.Subscriberid
	AND CompanyAccount.CompanyId = SalesOrder.CompanyId
	INNER JOIN SubscriberAffiliate
		INNER JOIN Subscriber
		ON Subscriber.SubscriberId = SubscriberAffiliate.ChildSubscriberid
	ON SubscriberAffiliate.ParentSubscriberId = SalesOrder.SubscriberID
	AND GETDATE() BETWEEN SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate
	LEFT JOIN DespatchDeliveryArea
	On DespatchDeliveryArea.CountryId = Subscriber.PrimaryCountryId
	AND DespatchDeliveryArea.CompanyId = SalesOrder.CompanyId
	INNER JOIN SubscriberAffiliate CompanyAffiliation
	ON CompanyAffiliation.parentSubscriberId =  Company.GroupParentSubscriberId
	AND CompanyAffiliation.ChildSubscriberId = SubscriberAffiliate.ChildSubscriberId
--1/8/20	James Woosnam	SIR5051 - Use all if no delivery area
	LEFT JOIN ProductRate pr
	ON pr.ProductRateId = (SELECT MAX(ProductRate.ProductRateId )
						FROM ProductRate 
						WHERE ProductRate.ProductCode = SalesOrder.PrimaryProductCode
						AND ProductRate.CurrencyCode = SalesOrder.CurrencyCode
						AND ProductRate.RateType = CompanyAccount.RateType
						AND ProductRate.AccountType = CompanyAccount.AccountType
						AND ProductRate.SubscriberCategory = CompanyAffiliation.SubscriberCategory
						AND (ProductRate.DeliveryArea = DespatchDeliveryArea.DespatchDeliveryArea
							OR (ProductRate.DeliveryArea <> DespatchDeliveryArea.DespatchDeliveryArea
								AND ProductRate.DeliveryArea = 'All')
							)
						)		
	LEFT JOIN SalesOrderLine
	ON SalesOrderLine.OrderNumber = SalesOrder.OrderNumber
	AND SalesOrderLine.SubscriberId = Subscriber.SubscriberId
where salesorder.ordernumber = @OrderNumber
AND SalesOrderLine.OrderNumber Is Null
--22/9/05	James Woosnam	Only use Current Subs
AND Subscriber.SubscriberStatus in ('Current')
Go

CREATE  PROCEDURE sp451DebtorsReport ( @StartDate datetime
					,@EndDate datetime
					,@CompanyId Int
					,@ForAuditDebtorCreditorsReport BIT = 0
					,@OutputTarget VARCHAR(50) = 'DebtorsReport' --'AgedDebtor'
)
AS
/*
'First part of the query gets all the details lines for the periond required.
'It has to have the detail for all accounts that were <> 0 at the end of the period
'The second part of the query gets the balance at the beginning of the period for all subscribers
'who have a non zero balance at the end and the beginnning		

--30/1/12	James Woosnam	SIR2588 - If @ForAuditDebtorCreditorsReport = 1 then filter by IsBankedIfCashbook to make report always reproduceble.
										This will only show banked and "Journal" cashbook items which are all that are needed for audit purposes
--16/2/18	James Woosnam	SIR4572 - Put standard output into a temp table so we can then add DebtorTimeCategory and pivot on it
*/
SELECT Debtors.*
INTO #Debtors
FROM (
	SELECT SubscriberName 
		,SubscriberCategory  
		,AccountType  
		,CurrencyCode  
		,OrderNumber  
		,PrimaryProductCode  
		,[Date]  
		,TransactionType  
		,ItemType  
		,AmountInNative  
		,AmountInBase  
		FROM vw420SubscriberTransactionsDetails  
		WHERE vw420SubscriberTransactionsDetails.CompanyId = @CompanyId
		AND vw420SubscriberTransactionsDetails.[Date] BETWEEN @StartDate AND @EndDate
		AND ( 0 <> ROUND(( SELECT SUM(Amount)  --Imbalance <= End Date
				 FROM vw421SubscriberTransactions1   
				 WHERE vw421SubscriberTransactions1.SubscriberId = vw420SubscriberTransactionsDetails.SubscriberId   
				 AND vw421SubscriberTransactions1.CompanyId = vw420SubscriberTransactionsDetails.CompanyId 
				 AND vw421SubscriberTransactions1.[Date] <= @EndDate
				 AND (IsBankedIfCashbook = 1 OR TransactionType<>'Payment' OR @ForAuditDebtorCreditorsReport = 0 )
					 ) ,2)  
			 ) 
		AND (IsBankedIfCashbook = 1 OR TransactionType<>'Payment' OR @ForAuditDebtorCreditorsReport = 0 )
	UNION All 
	SELECT SubscriberName  
		,SubscriberCategory  
		,AccountType ,CurrencyCode  
		,999999 AS OrderNumber  
		,PrimaryProductCode  
		,DATEADD(d,-1,@StartDate) AS [Date]  
		,TransactionType  
		,ItemType  
		,SUM(AmountInNative) AS AmountInNative  
		,SUM(AmountInBase) As AmountInBase 
	FROM vw420SubscriberTransactionsDetails 
	WHERE vw420SubscriberTransactionsDetails.CompanyId = @CompanyId
	AND vw420SubscriberTransactionsDetails.[Date] < @StartDate
	AND 0 <> ROUND(( SELECT SUM(Amount) --Imbalance <= End Date
		   FROM vw421SubscriberTransactions1 
		   WHERE vw421SubscriberTransactions1.SubscriberId = vw420SubscriberTransactionsDetails.SubscriberId 
		   AND vw421SubscriberTransactions1.CompanyId = vw420SubscriberTransactionsDetails.CompanyId 
		   AND vw421SubscriberTransactions1.[Date] <= @EndDate 
		   AND (IsBankedIfCashbook = 1 OR TransactionType<>'Payment' OR @ForAuditDebtorCreditorsReport = 0 )
		   ),2)
	AND 0 <> ROUND(( SELECT SUM(Amount) --AND Imballance < Start Date
		   FROM vw421SubscriberTransactions1 
		   WHERE vw421SubscriberTransactions1.SubscriberId = vw420SubscriberTransactionsDetails.SubscriberId 
		   AND vw421SubscriberTransactions1.CompanyId = vw420SubscriberTransactionsDetails.CompanyId 
		   AND vw421SubscriberTransactions1.[Date] < @StartDate 
		   AND (IsBankedIfCashbook = 1 OR TransactionType<>'Payment' OR @ForAuditDebtorCreditorsReport = 0 )
		   ),2)
	AND (IsBankedIfCashbook = 1 OR TransactionType<>'Payment' OR @ForAuditDebtorCreditorsReport = 0 )
	GROUP BY SubscriberName  
		,SubscriberCategory  
		,AccountType  
		,CurrencyCode  
		,PrimaryProductCode  
		,TransactionType  
		,ItemType
	) Debtors


--16/2/18	James Woosnam	SIR4572 - Add DebtorTimeCategory and populate it
ALTER TABLE #Debtors ADD DebtorTimeCategory VARCHAR(10) NULL

UPDATE #Debtors 
SET DebtorTimeCategory = CASE 
		WHEN DATEADD(MONTH, -6, @EndDate) > DAte THEN '6+'
		WHEN DATEADD(MONTH, -5, @EndDate) > DAte THEN '5'
		WHEN DATEADD(MONTH, -4, @EndDate) > DAte THEN '4'
		WHEN DATEADD(MONTH, -3, @EndDate) > DAte THEN '3'
		WHEN DATEADD(MONTH, -2, @EndDate) > DAte THEN '2'
		WHEN DATEADD(MONTH, -1, @EndDate) > DAte THEN '1'
		ELSE '<1' END


IF @OutputTarget = 'DebtorsReport'
BEGIN  --Standard output
	SELECT *
	FROM #Debtors 
END

IF @OutputTarget = 'AgedDebtor'
BEGIN  --Pivoted Output
	SELECT CurrencyCode
			,SubscriberName
				,[6+] = ISNULL([6+],0)
				,[5] = ISNULL([5],0)
				,[4] = ISNULL([4],0)
				,[3] = ISNULL([3],0)
				,[2] = ISNULL([2],0)
				,[1] = ISNULL([1],0)
				,[<1] = ISNULL([<1],0)
	FROM 
	(
	SELECT
		d.CurrencyCode 
		,d.SubscriberName 
		,d.DebtorTimeCategory
		,d.AmountInNative 
	FROM #Debtors d
	) ps
	PIVOT
	(
	SUM (AmountInNative)
	FOR DebtorTimeCategory IN
	( [6+],[5],[4],[3],[2],[1],[<1])
	) AS pvt    
	ORDER BY
	CurrencyCode
			,SubscriberName


END





go

go
