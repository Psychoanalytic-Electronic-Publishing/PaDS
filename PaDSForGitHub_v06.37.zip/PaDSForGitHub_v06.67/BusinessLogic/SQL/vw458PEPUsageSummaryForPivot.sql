/************************************************************************************
--23/1/25	Julian Gates	SIR5785 - Change documentRef to LEFT(documentRef, 90) as documentRef to fix documentRef too long issue
** 
***********************************************************************************/

if  exists (select * from sysobjects where id = object_id(N'vw458PEPUsageSummaryForPivot') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP view vw458PEPUsageSummaryForPivot
go

CREATE VIEW vw458PEPUsageSummaryForPivot
As
	SELECT
		PEPUsageSummaryId 
		,MonthStartDate
		,ReportingParentSubscriberName
		,ReportingParentSubscriberId
		,ReportingParentType
		,OrderNumber
		,LoggedInMethod
		,UserName
		,UserFullName
		,UserCountry
		,MediaType
		,PEPCode
		,DocumentVolume
		,DocumentYear
		,LEFT(documentRef, 40) as documentRef
		,authorMast
		,ArchiveOrCurrent	
		,UserActivitySessionCount 
		,AbstractCount 
		,ReadCount 
		,SearchCount 
		,TurnAwayCount
	FROM PEPUsageSummary u

Go