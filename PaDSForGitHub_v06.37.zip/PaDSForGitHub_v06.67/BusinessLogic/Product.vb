﻿'Updates
'======
'18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if Product, ProductRate, ProductQualifyingProduct record modified
'12/07/21   Julian Gates    SIR5281 - Add DisplayProductName to AddNewProduct
'26/11/21   Julian Gates    SIR5361 - Add FixedSubscriptionEndDate to AddNewProduct
'07/01/25   Julian Gates    SIR5781 - Modify DLookup to stop SQL injection

Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class Product
#Region "Class Properties"
    Public MainDataset As New DataSet
    Public ReadonlyDataset As New DataSet
    Dim UserSession As BusinessLogic.UserSession

    Dim _ProductCode As String = Nothing
    Public Property ProductCode() As String
        Get
            If Me._ProductCode = Nothing Then
                If Me.MainDataset.Tables.Count > 0 Then
                    Me._ProductCode = Me.ProductRow("ProductCode")
                End If
            End If
            Return Me._ProductCode
        End Get
        Set(ByVal Value As String)
            _ProductCode = Value
            'initilise dataset
            Me.Initilise()
        End Set
    End Property
    Public ReadOnly Property ProductName As String
        Get
            Return Me.ProductRow("ProductName")
        End Get
    End Property
    Public ReadOnly Property HasAssociatedProduct As Boolean
        Get
            Return db.IsDBNull(ProductRow("AssociatedProductCode"), "") <> ""
        End Get
    End Property

    Private _db As Database = Nothing
    Public Property db() As Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As Database)

            Me._db = value
        End Set
    End Property
#End Region

#Region "DependantTables"
    '***********************************************
    'Product
    Public ReadOnly Property Product() As DataTable
        Get
            If Me.MainDataset.Tables("Product") Is Nothing Then
                Me.daProduct.Fill(Me.MainDataset, "Product")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("Product").Columns("ProductCode")}
            Me.MainDataset.Tables("Product").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("Product")
        End Get
    End Property
    Private _daProduct As SqlDataAdapter
    Private ReadOnly Property daProduct() As SqlDataAdapter
        Get
            If Me._daProduct Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM Product"
                If Me.ProductCode = "" Then
                    sql += " WHERE 1=2"
                Else
                    sql += " WHERE ProductCode=@ProductCode"
                End If

                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                If Me.ProductCode <> "" Then
                    cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProductCode", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current _
                                                                             , Me.ProductCode))
                End If

                _daProduct = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daProduct)
                _daProduct.UpdateCommand = cmdBld.GetUpdateCommand()
                _daProduct.InsertCommand = cmdBld.GetInsertCommand()
                _daProduct.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daProduct.InsertCommand.Transaction = Me.db.DBTransaction
                _daProduct.UpdateCommand.Transaction = Me.db.DBTransaction
                _daProduct.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daProduct
        End Get
    End Property

    Public ReadOnly Property ProductRow() As DataRow
        Get
            If Me.Product.Rows.Count = 0 Then
                Me.daProduct.Fill(Me.MainDataset.Tables("Product"))
                If Me.Product.Rows.Count = 0 Then
                    Throw New Exception("UserError: Product Code can't be found")
                End If
            End If
            Return Me.Product.Rows(0)
        End Get
    End Property


    '***********************************************
    'ProductRate
    Public ReadOnly Property ProductRate() As DataTable
        Get
            If Me.MainDataset.Tables("ProductRate") Is Nothing Then
                Me.daProductRate.Fill(Me.MainDataset, "ProductRate")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("ProductRate").Columns("ProductRateId")}
            Me.MainDataset.Tables("ProductRate").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("ProductRate")
        End Get
    End Property
    Private _daProductRate As SqlDataAdapter
    Public ReadOnly Property daProductRate() As SqlDataAdapter
        Get
            If Me._daProductRate Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM ProductRate"
                sql += " WHERE ProductCode=@ProductCode"
                sql += " ORDER BY CurrencyCode,RateType,AccountType,SubscriberCategory,DeliveryArea"
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProductCode", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.InputOutput, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current _
                                                                             , Me.ProductCode))
                _daProductRate = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daProductRate)
                _daProductRate.UpdateCommand = cmdBld.GetUpdateCommand()
                _daProductRate.InsertCommand = cmdBld.GetInsertCommand()
                _daProductRate.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daProductRate.InsertCommand.Transaction = Me.db.DBTransaction
                _daProductRate.UpdateCommand.Transaction = Me.db.DBTransaction
                _daProductRate.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daProductRate
        End Get
    End Property
    Public Function ProductRateRow(ByVal ProductCode As String, ByVal ProductRateId As Integer) As DataRow
        Me.ProductCode = ProductCode
        For Each row As DataRow In Me.ProductRate.Rows
            If row("ProductCode") = ProductCode And row("ProductRateId") = ProductRateId Then
                Return row
            End If
        Next
        Throw New Exception("UserError: ProductCode:" & Me.ProductCode & " And ProductRateId:" & ProductRateId & " can't be found")
    End Function

    Public ReadOnly Property ProductAffiliateRate() As DataTable
        Get
            If Me.MainDataset.Tables("ProductAffiliateRate") Is Nothing Then
                daProductAffiliateRate.Fill(Me.MainDataset, "ProductAffiliateRate")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("ProductAffiliateRate").Columns("ProductAffiliateRateId")}
            Me.MainDataset.Tables("ProductAffiliateRate").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("ProductAffiliateRate")
        End Get
    End Property

    Private _daProductAffiliateRate As SqlDataAdapter
    Public ReadOnly Property daProductAffiliateRate() As SqlDataAdapter
        Get
            If Me._daProductAffiliateRate Is Nothing Then
                Dim sql As String = ""
                sql = "SELECT *"
                sql += " FROM ProductAffiliateRate"
                sql += " WHERE ProductCode='" & Me.ProductCode & "'"
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daProductAffiliateRate = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daProductAffiliateRate)
                _daProductAffiliateRate.UpdateCommand = cmdBld.GetUpdateCommand()
                _daProductAffiliateRate.InsertCommand = cmdBld.GetInsertCommand()
                _daProductAffiliateRate.DeleteCommand = cmdBld.GetDeleteCommand()

            End If

            If Not Me.db.DBTransaction Is Nothing Then
                _daProductAffiliateRate.InsertCommand.Transaction = Me.db.DBTransaction
                _daProductAffiliateRate.UpdateCommand.Transaction = Me.db.DBTransaction
                _daProductAffiliateRate.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daProductAffiliateRate
        End Get
    End Property

    Public ReadOnly Property ProductAffiliateRateRow() As DataRow
        Get
            If Me.ProductAffiliateRate.Rows.Count = 0 Then
                Me.daProductAffiliateRate.Fill(Me.MainDataset.Tables("ProductAffiliateRate"))
                If Me.ProductAffiliateRate.Rows.Count = 0 Then
                    Throw New Exception("UserError: Product Affiliate Rate for :" & Me.ProductCode & " can't be found")
                End If
            End If
            Return Me.ProductAffiliateRate.Rows(0)
        End Get
    End Property

    Public ReadOnly Property ProductQualifyingProduct() As DataTable
        Get
            If Me.MainDataset.Tables("ProductQualifyingProduct") Is Nothing Then
                daProductQualifyingProduct.Fill(Me.MainDataset, "ProductQualifyingProduct")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("ProductQualifyingProduct").Columns("ProductQualifyingProductId")}
            Me.MainDataset.Tables("ProductQualifyingProduct").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("ProductQualifyingProduct")
        End Get
    End Property

    Private _daProductQualifyingProduct As SqlDataAdapter
    Public ReadOnly Property daProductQualifyingProduct() As SqlDataAdapter
        Get
            If Me._daProductQualifyingProduct Is Nothing Then
                Dim sql As String = ""
                sql = "SELECT *"
                sql += " FROM ProductQualifyingProduct"
                sql += " WHERE ProductCode='" & Me.ProductCode & "'"
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daProductQualifyingProduct = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daProductQualifyingProduct)
                _daProductQualifyingProduct.UpdateCommand = cmdBld.GetUpdateCommand()
                _daProductQualifyingProduct.InsertCommand = cmdBld.GetInsertCommand()
                _daProductQualifyingProduct.DeleteCommand = cmdBld.GetDeleteCommand()

            End If

            If Not Me.db.DBTransaction Is Nothing Then
                _daProductQualifyingProduct.InsertCommand.Transaction = Me.db.DBTransaction
                _daProductQualifyingProduct.UpdateCommand.Transaction = Me.db.DBTransaction
                _daProductQualifyingProduct.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daProductQualifyingProduct
        End Get
    End Property

    Public ReadOnly Property ProductQualifyingProductRow() As DataRow
        Get
            If Me.ProductQualifyingProduct.Rows.Count = 0 Then
                Me.daProductQualifyingProduct.Fill(Me.MainDataset.Tables("ProductQualifyingProduct"))
                If Me.ProductQualifyingProduct.Rows.Count = 0 Then
                    Throw New Exception("UserError: Product Qualifying Product for :" & Me.ProductCode & " can't be found")
                End If
            End If
            Return Me.ProductQualifyingProduct.Rows(0)
        End Get
    End Property



    Private Sub Initilise()
        Dim xx As Integer = 0
        MainDataset.Clear()
        Me._daProduct = Nothing
        Me._daProductRate = Nothing
        Me._daProductAffiliateRate = Nothing
        Me._daProductQualifyingProduct = Nothing
        xx = Me.Product.Rows.Count
        'xx = Me.ProductRate.Rows.Count

    End Sub



    '***********************************************
#End Region

    Sub New(ByVal db As Database)
        Me.db = db
    End Sub
    Sub New(ByVal ProductCode As String, ByVal db As Database)
        Me.db = db
        Me.ProductCode = ProductCode
        Me.Initilise()
    End Sub
    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As BusinessLogic.UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.ProductCode = 0
    End Sub

    Sub New(ByVal ProductCode As String, ByVal db As BusinessLogic.Database, ByVal UserSession As BusinessLogic.UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.ProductCode = ProductCode
        Me.Initilise()
    End Sub


#Region "Actions"

    Public Sub Save()
        Dim sql As String = ""
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
            Select Case Me.ProductRow.RowState
                Case DataRowState.Added, DataRowState.Modified
                    ProductRow("LastUpdatedDateTime") = Now()
                    ProductRow("LastUpdatedByUserId") = UserSession.UserName20
            End Select
            Me.daProduct.Update(Me.MainDataset, "Product")

            'Update Sub_Feature
            If Me.ProductRate IsNot Nothing Then
                If Me.ProductRate.Rows.Count > 0 Then
                    '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
                    For Each row As DataRow In Me.MainDataset.Tables("ProductRate").Rows
                        Select Case row.RowState
                            Case DataRowState.Added, DataRowState.Modified
                                row("LastUpdatedDateTime") = Now()
                                row("LastUpdatedByUserId") = UserSession.UserName20

                        End Select
                    Next
                    Me.daProductRate.Update(Me.MainDataset, "ProductRate")
                End If
            End If

            If Me.ProductQualifyingProduct IsNot Nothing Then
                If Me.ProductQualifyingProduct.Rows.Count > 0 Then
                    '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
                    For Each row As DataRow In Me.MainDataset.Tables("ProductQualifyingProduct").Rows
                        Select Case row.RowState
                            Case DataRowState.Added, DataRowState.Modified
                                row("LastUpdatedDateTime") = Now()
                                row("LastUpdatedByUserId") = UserSession.UserName20
                        End Select
                    Next
                    Me.daProductQualifyingProduct.Update(Me.MainDataset, "ProductQualifyingProduct")
                End If
            End If

            If TranStartedHere Then
                Me.db.CommitTran()
            End If

        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try
    End Sub

    Public Function HasValidAssociatedProductRates() As Boolean
        Try
            Dim vw As New DataView(Me.AllAssociatedProductRates, "ProductCode='" & Me.ProductCode & "' And IsMissing <> ''", "", DataViewRowState.CurrentRows)
            Return vw.Count = 0
        Catch ex As Exception
            Throw New Exception("HasValidAssociatedProductRates failed:" & ex.Message)
        End Try
    End Function
    Public ReadOnly Property AllAssociatedProductRates As DataTable
        Get
            Dim sql As String = ""
            sql = "
SELECT
	cp.ProductCode
	,cp.AssociatedProductCode 
	,prm.CurrencyCode
	,prm.RateType 
	,prm.AccountType 
	,prm.SubscriberCategory
	,prm.DeliveryArea 
	,MainRateId = prm.ProductRateId
	,AssociatedRateId = pra.ProductRateId
	,MainRate = prm.ProductRate 
	,AssociatedRate = pra.ProductRate 
	,IsMissing = CASE WHEN pra.ProductRateId is null then '**Missing Rate**' ELSE '' END
FROM (
		SELECT
			p.ProductCode 
			,p.AssociatedProductCode 
		FROM Product p
		WHERE p.ProductStatus = 'current'
		and isnull(p.AssociatedProductCode,'') <> ''
		and p.IsParent = 1
	) cp
	INNER JOIN ProductRate prm
	on prm.ProductCode = cp.ProductCode 
	LEFT JOIN ProductRate pra
	ON pra.ProductCode = cp.AssociatedProductCode 
	AND pra.CurrencyCode = prm.CurrencyCode 
	AND pra.RateType = prm.RateType 
	AND pra.AccountType  = prm.AccountType 
	AND pra.SubscriberCategory = prm.SubscriberCategory 
	AND pra.DeliveryArea = prm.DeliveryArea 
ORDER BY 
	cp.ProductCode
	,cp.AssociatedProductCode 
	,prm.CurrencyCode
	,prm.RateType 
	,prm.AccountType 
	,prm.SubscriberCategory
	,prm.DeliveryArea 
"
            Return db.GetDataTableFromSQL(sql)
        End Get
    End Property
    Public Function GetAdditionalProductsTable(AdditionalProductsString As String) As DataTable
        '2/10/12    James Woosnam   SIR2874 - Turn additional products entered on import page into a table
        Dim tbl As New DataTable
        Dim dt As System.Type
        dt = System.Type.GetType("System.String")
        tbl.Columns.Add(New DataColumn("ProductCode", dt))

        Dim products As String() = AdditionalProductsString.Replace("'", "").Split(New Char() {","c})

        Dim productCode As String = ""
        Dim comma As String = ""
        Dim localErrorMsg As String = ""
        For Each productCode In products
            Dim row As DataRow = tbl.NewRow
            row("ProductCode") = productCode.Trim
            tbl.Rows.Add(row)
        Next
        Return tbl
    End Function
    '12/07/21   Julian Gates    SIR5281 - Add DisplayProductName to AddNewProduct
    '26/11/21   Julian Gates    SIR5361 - Add FixedSubscriptionEndDate to AddNewProduct
    '07/01/22   Julian Gates    SIR5396 - Change FixedSubscriptionEndDate to pass as a string value 

    Public Sub AddNewProduct(ByVal ProductCode As String,
                             ByVal ProductName As String,
                             ByVal ProductStatus As String,
                             ByVal CompanyID As String,
                             ByVal Notes As String,
                             ByVal ShippedProductFlag As Boolean,
                             ByVal TermsAndConditionsFileName As String,
                             ByVal ProductGroupingName As String,
                             ByVal ProductShortName As String,
                             ByVal ReleaseDate As Date,
                             ByVal AssociatedProductCode As String,
                             ByVal RecurringSubscriptionFlag As Boolean,
                             ByVal RecurringSubscriptionUnitType As String,
                             ByVal RecurringSubscriptionUnits As String,
                             ByVal SellOnWebFlag As Boolean,
                             ByVal OnePerSubscriberFlag As Boolean,
                             ByVal CheckAgainstOrderType As String,
                             ByVal DisplayProductName As String,
                             ByVal FixedSubscriptionEndDate As String
                            )

        Dim row As DataRow = Me.Product.NewRow
        Dim tranStartedhere As Boolean = False
        If db.DBTransaction Is Nothing Then
            db.BeginTran()
            tranStartedhere = True
        End If
        Try

            row("ProductCode") = ProductCode
            row("ProductName") = ProductName
            row("ProductStatus") = ProductStatus
            row("CompanyID") = CInt(CompanyID)
            row("Notes") = Notes
            row("IsParent") = True
            row("ShippedProductFlag") = ShippedProductFlag
            row("TermsAndConditionsFileName") = TermsAndConditionsFileName
            row("ProductGroupingName") = ProductGroupingName
            row("ProductShortName") = ProductShortName
            row("ReleaseDate") = CDate(ReleaseDate)
            If AssociatedProductCode <> "" Then
                If db.DLookup("ProductCode", "Product", "ProductCode=@AssociatedProductCode AND ProductStatus='Current' AND ISParent=1", "AssociatedProductCode", AssociatedProductCode, True) Is Nothing Then
                    Throw New Exception(AssociatedProductCode & " is not a current parent product and can't be an associated product")
                Else
                    row("AssociatedProductCode") = AssociatedProductCode
                End If
            End If
            row("RecurringSubscriptionFlag") = RecurringSubscriptionFlag
            row("RecurringSubscriptionUnitType") = RecurringSubscriptionUnitType
            If RecurringSubscriptionUnits <> Nothing Then
                row("RecurringSubscriptionUnits") = CInt(RecurringSubscriptionUnits)
            Else
                row("RecurringSubscriptionUnits") = System.DBNull.Value
            End If
            row("SellOnWebFlag") = SellOnWebFlag
            row("OnePerSubscriberFlag") = OnePerSubscriberFlag
            row("CheckAgainstOrderType") = CheckAgainstOrderType
            row("CreatedDateTime") = Now()
            row("CreatedByUserId") = UserSession.UserName20
            row("DisplayProductName") = DisplayProductName
            If FixedSubscriptionEndDate <> Nothing Then
                row("FixedSubscriptionEndDate") = CDate(FixedSubscriptionEndDate)
            Else
                row("FixedSubscriptionEndDate") = System.DBNull.Value
            End If

            Me.Product.Rows.Add(row)

            'Now add child product
            row = Me.Product.NewRow
            row("ProductCode") = ProductCode & "C1"
            row("ProductName") = ProductName & "Child1"
            row("ProductStatus") = ProductStatus
            row("CompanyID") = CInt(CompanyID)
            row("Notes") = System.DBNull.Value
            row("IsParent") = False
            row("ProductGroupingName") = System.DBNull.Value
            row("ProductShortName") = ProductShortName & "C1"
            row("IsForReporting") = True
            row("ReportProportion") = 1
            row("ProductReportName") = ProductCode
            row("ReleaseDate") = CDate(ReleaseDate)
            row("ParentProductCode") = ProductCode
            row("AssociatedProductCode") = System.DBNull.Value
            row("RecurringSubscriptionFlag") = System.DBNull.Value
            row("RecurringSubscriptionUnitType") = System.DBNull.Value
            row("RecurringSubscriptionUnits") = System.DBNull.Value
            row("SellOnWebFlag") = System.DBNull.Value
            row("OnePerSubscriberFlag") = System.DBNull.Value
            row("CheckAgainstOrderType") = System.DBNull.Value
            row("CreatedDateTime") = Now()
            row("CreatedByUserId") = UserSession.UserName20
            row("DisplayProductName") = DisplayProductName
            row("FixedSubscriptionEndDate") = System.DBNull.Value
            Me.Product.Rows.Add(row)

            Me.Save()
            Me.ProductCode = ProductCode
            If tranStartedhere Then db.CommitTran()
        Catch ex As Exception
            If tranStartedhere Then db.RollbackTran()
            Throw New Exception("Add New Product failed", ex)
        End Try
    End Sub

    Sub AddProductRate(CurrencyCode As String,
                    RateType As String,
                    AccountType As String,
                    SubscriberCategory As String,
                    DeliveryArea As String,
                    ProductRate As Decimal,
                    NewUserRateFlag As Boolean,
                    SellOnWebFlag As Boolean
                    )
        Try
            Dim nr As DataRow = Me.ProductRate.NewRow
            nr("ProductRateId") = Now.Millisecond
            System.Threading.Thread.Sleep(10) 'to ensure ProductRateId isn't set to same millisecond!!
            nr("ProductCode") = ProductCode
            nr("CurrencyCode") = CurrencyCode
            nr("RateType") = RateType
            nr("AccountType") = AccountType
            nr("SubscriberCategory") = SubscriberCategory
            nr("DeliveryArea") = DeliveryArea
            nr("ProductRate") = ProductRate
            nr("CreatedDateTime") = Now()
            nr("CreatedByUserId") = UserSession.UserId
            nr("LastUpdatedDateTime") = Now
            nr("LastUpdatedByUserId") = UserSession.UserName20
            nr("NewUserRateFlag") = NewUserRateFlag
            nr("SellOnWebFlag") = SellOnWebFlag
            Me.ProductRate.Rows.Add(nr)
            Me.Save()

        Catch ex As Exception
            Throw New Exception("AddProductRate failed:" & ex.Message, ex)

        End Try
    End Sub
    Sub AddProductQualifyingProduct(QualifyingProductCode As String,
              SubscriberCategory As String,
              ProductRateId As Integer,
            Optional MustBuyFlag As Boolean = True,
            Optional TerminatedSubscriptionsGracePeriodMonths As Integer = 12,
            Optional CheckAgainstOrderType As String = "All"
              )
        Try
            If Not {"Institutional", "Ordinary", "Student"}.Contains(SubscriberCategory) Then Throw New Exception("SubscriberCategory:" & SubscriberCategory & " not invalid")
            If Not {"Block", "Individual", "All"}.Contains(CheckAgainstOrderType) Then Throw New Exception("CheckAgainstOrderType:" & CheckAgainstOrderType & " not invalid")

            Dim nr As DataRow = Me.ProductQualifyingProduct.NewRow
            nr("ProductQualifyingProductId") = Now.Millisecond
            System.Threading.Thread.Sleep(10) 'to ensure id isn't set to same millisecond!!
            nr("ProductCode") = ProductCode
            nr("QualifyingProductCode") = QualifyingProductCode
            nr("SubscriberCategory") = SubscriberCategory
            nr("ProductRateId") = ProductRateId
            nr("MustBuyFlag") = MustBuyFlag
            nr("TerminatedSubscriptionsGracePeriodMonths") = TerminatedSubscriptionsGracePeriodMonths
            ' nr("timestamp") = timestamp
            nr("CheckAgainstOrderType") = CheckAgainstOrderType

            Me.ProductQualifyingProduct.Rows.Add(nr)
            Me.Save()

        Catch ex As Exception
            Throw New Exception("AddProductQualifyingProduct failed:" & ex.Message, ex)

        End Try
    End Sub
#End Region

    Public Function GetRecurringEndDate(RecuringStartDate As Date) As Date
        Dim sql As String = "
            SELECT dbo.fn236GetRecurringSubscriptionEndDate('" & Me.ProductCode & "', " & New StdCode().vFQ(RecuringStartDate, "D") & ")"
        Return db.GetDataTableFromSQL(sql).Rows(0)(0)
    End Function

End Class
