﻿Imports System.Collections.Generic
Imports Stripe
Imports Stripe.Checkout
Public Class StripeInterface
#Region "Class Properties"
    Dim db As Database = Nothing
    Dim UserSession As UserSession = Nothing
    Dim StripeAccountHolderCompanyId As Integer = Nothing
    Public SuccessUrl As String = Nothing
    Public CancelUrl As String = Nothing
#End Region


    Sub New(StripeAccountHolderCompanyId As Integer, ByVal db As Database, ByRef UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.StripeAccountHolderCompanyId = StripeAccountHolderCompanyId
        Stripe.StripeConfiguration.ApiKey = db.DLookup("StripePrivateAPIKey", "Company", "CompanyId=" & StripeAccountHolderCompanyId)
        If Stripe.StripeConfiguration.ApiKey = Nothing Then Throw New Exception("Company StripePrivateAPIKey must be populated")

    End Sub
    Public Function GetPayementURL(StripeProductCode As String, ClientReference As String, PaymentDescription As String, CustomerEmail As String, CurrencyCode As String, Optional OneOffPrice As Decimal = Nothing) As String
        If SuccessUrl = Nothing Then Throw New Exception("SuccessURL must be populated")
        If CancelUrl = Nothing Then Throw New Exception("CancelUrl must be populated")
        If StripeProductCode = Nothing Then Throw New Exception("StripeProductCode must be populated")

        '  Dim domain = UserSession.WebsiteURL

        Dim sessLineItemOptions As SessionLineItemOptions = Nothing
        If OneOffPrice = Nothing Then
            'if there is no price, then the code passed in via the stripe product code actually needs to be the stripe product PRICE code, this was used in 2023 and will hopefully I'll be phased out.
            sessLineItemOptions = New SessionLineItemOptions With {
                    .Price = StripeProductCode,
                    .Quantity = 1
                }
        Else
            Dim priceData As New SessionLineItemPriceDataOptions
            priceData.UnitAmount = OneOffPrice * 100
            priceData.Currency = CurrencyCode
            priceData.Product = StripeProductCode
            sessLineItemOptions = New SessionLineItemOptions With {
                    .PriceData = priceData,
                    .Quantity = 1
                }
        End If
        Dim po As New SessionPaymentIntentDataOptions()
        po.Description = PaymentDescription
        po.CaptureMethod = "manual"
        Dim options = New SessionCreateOptions With {
            .LineItems = New List(Of SessionLineItemOptions) From {
                sessLineItemOptions
            },
            .PaymentIntentData = po,
            .Mode = "payment",
            .SuccessUrl = Me.SuccessUrl,
            .CancelUrl = Me.CancelUrl,
            .CustomerEmail = CustomerEmail,
            .ClientReferenceId = ClientReference
        }
        Dim service = New SessionService()
        Dim session As Session = service.Create(options)
        CheckOutSessionId = session.Id
        Return session.Url
    End Function
    Public CheckOutSessionId As String = Nothing

    Public Sub CapturePayment(CheckOutSessionId As String)
        'https://docs.stripe.com/checkout/fulfillment
        Dim service = New SessionService()
        Dim checkoutSession As Session = service.Get(CheckOutSessionId, Nothing, Nothing)

        If checkoutSession.PaymentStatus = "unpaid" Then
            Dim xx As New PaymentIntentService
            xx.Capture(checkoutSession.PaymentIntentId)

        Else
            Throw New Exception("PaymentStatus:" & checkoutSession.PaymentStatus & " can't be fulfilled")
        End If


    End Sub

End Class
