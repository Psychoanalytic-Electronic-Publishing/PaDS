﻿'Updates
'======
'22/5/11    James Woosnam   HotFix - Open Logs with UserSession
'17/01/14   Julian Gates    Add more batchlogmessage updates to sub ExecuteAddFromCashbookIds.
'03/07/15   Julian Gates    SIR3895 - Call SendEmailReceipt and update EmailReceiptDateTime if blank in sub ExecuteAddFromCashbookIds.
'10/1/20    James Woosnam       SIR4990 - Make receipt failure an error
'22/08/23   Julian Gates    SIR5683 - Don't try to send receipt emails for block orders

Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class BankDeposit
#Region "Class Properties"

    Public MainDataset As New DataSet
    Dim _BankDepositId As Long
    Dim UserSession As UserSession
    Public AuthorisationRejectMsg As String = ""

    Public Property BankDepositId() As Integer
        Get
            If Me._BankDepositId = Nothing Then
                If Me.MainDataset.Tables.Count <> 0 Then
                    Me._BankDepositId = Me.BankDepositRow("BankDepositId")
                End If
            End If
            Return Me._BankDepositId
        End Get
        Set(ByVal Value As Integer)
            _BankDepositId = Value
            'initilise dataset
            'Me.Initilise()
        End Set
    End Property

    Private ReadOnly Property BankDeposit() As DataTable
        Get
            If Me.MainDataset.Tables("BankDeposit") Is Nothing Then
                Me.daBankDeposit.Fill(Me.MainDataset, "BankDeposit")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("BankDeposit").Columns("BankDepositId")}
            Me.MainDataset.Tables("BankDeposit").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("BankDeposit")
        End Get
    End Property
    Private _daBankDeposit As SqlDataAdapter
    Private ReadOnly Property daBankDeposit() As SqlDataAdapter
        Get
            If Me._daBankDeposit Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM BankDeposit"
                sql += " WHERE BankDepositId=" & Me.BankDepositId
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daBankDeposit = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daBankDeposit)
                _daBankDeposit.UpdateCommand = cmdBld.GetUpdateCommand()
                _daBankDeposit.InsertCommand = cmdBld.GetInsertCommand()
                _daBankDeposit.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daBankDeposit.InsertCommand.Transaction = Me.db.DBTransaction
                _daBankDeposit.UpdateCommand.Transaction = Me.db.DBTransaction
                _daBankDeposit.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daBankDeposit
        End Get
    End Property

    Public ReadOnly Property BankDepositRow() As DataRow
        Get
            If Me.BankDeposit.Rows.Count = 0 Then
                Me.daBankDeposit.Fill(Me.MainDataset.Tables("BankDeposit"))
                If Me.BankDeposit.Rows.Count = 0 Then
                    Throw New Exception("UserError: BankDepositId:" & Me.BankDepositId & " can't be found")
                End If
            End If
            Return Me.BankDeposit.Rows(0)
        End Get
    End Property

    Public ReadOnly Property CompanyName As String
        Get
            If Me.BankDeposit.Rows.Count = 0 Then
                Return ""
            Else
                Return db.DLookup("CompanyName", "Company", "CompanyId=" & Me.BankDepositRow.Item("CompanyId"))
            End If
        End Get
    End Property
    Public ReadOnly Property BankAccountName As String
        Get
            If Me.BankDeposit.Rows.Count = 0 Then
                Return ""
            Else
                Return db.DLookup("BankAccountName", "CompanyBankAccount", "CompanyId=" & Me.BankDepositRow.Item("CompanyId") _
                                  & " AND BankSortCode='" & Me.BankDepositRow("BankSortCode") & "'" _
                                  & " AND BankAccountNumber='" & Me.BankDepositRow("BankAccountNumber") & "'")
            End If
        End Get
    End Property
    Public ReadOnly Property CurrencyCode As String
        Get
            If Me.BankDeposit.Rows.Count = 0 Then
                Return ""
            Else
                Return db.DLookup("CurrencyCode", "CompanyBankAccount", "CompanyId=" & Me.BankDepositRow.Item("CompanyId") _
                                  & " AND BankSortCode='" & Me.BankDepositRow("BankSortCode") & "'" _
                                  & " AND BankAccountNumber='" & Me.BankDepositRow("BankAccountNumber") & "'")
            End If
        End Get
    End Property
    Private Sub Initilise()
        Dim xx As Integer = 0
        Me.MainDataset = New DataSet
        Me._daBankDeposit = Nothing
        xx = Me.BankDeposit.Rows.Count

    End Sub
    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property

#End Region
    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.BankDepositId = 0
        Me.UserSession = UserSession
    End Sub
    Sub New(ByVal BankDepositId As Integer, ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.BankDepositId = BankDepositId
        Me.UserSession = UserSession
        Me.Initilise()
    End Sub
    Public Sub Save()
        Dim sql As String = ""
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Dim logs As New businesslogic.logs(db, Me.UserSession)
            Select Case Me.BankDepositRow.RowState
                Case DataRowState.Added, DataRowState.Modified
                    Me.BankDepositRow("LastUpdatedDateTime") = Now()
                    Me.BankDepositRow("LastUpdatedByUserId") = UserSession.UserName20
                    Try
                        logs.WriteAuditLog("BankDeposit", Me.BankDepositId, UserSession.UserId, UserSession.UserName, Me.BankDepositRow.RowState.ToString(), "")
                    Catch ex As Exception
                    End Try
            End Select
            Me.daBankDeposit.Update(Me.MainDataset, "BankDeposit")

            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try

    End Sub
    Public Function SubmitAddFromCashbookIds(ByVal CashbookIds As String _
                        , ByVal CompanyId As Integer _
                        , ByVal BankSortCode As String _
                        , ByVal BankAccountNumber As String _
                        , ByVal Notes As String _
                        , ByVal SendReceipt As Boolean _
                        , ByVal DateBanked As Date _
                        , ByVal SettleTransaction As Boolean) As Integer
        'Sumbits the job and returns the BatchJobId
        Dim BatchJobId As Integer = 0
        Try
            Dim BatchJob As BusinessLogic.BatchJob = Nothing
            BatchJob = New BusinessLogic.BatchJob(Me.db)
            BatchJob.SubmittedByUserSessionId = Me.UserSession.UserSessionIdGUID
            BatchJob.Parameters.Add("CashbookIds", CashbookIds)
            BatchJob.Parameters.Add("CompanyId", CompanyId)
            BatchJob.Parameters.Add("BankSortCode", BankSortCode)
            BatchJob.Parameters.Add("BankAccountNumber", BankAccountNumber)
            BatchJob.Parameters.Add("Notes", Notes)
            BatchJob.Parameters.Add("SendReceipt", SendReceipt)
            BatchJob.Parameters.Add("DateBanked", DateBanked)
            BatchJob.Parameters.Add("SettleTransaction", SettleTransaction)
            BatchJob.Parameters.Add("SecondaryConnectionString", db.SecondaryConnectionString)
            BatchJob.CreateBatchJobEntry("AddBankDepositFromCashbookIds", db)
            BatchJobId = BatchJob.BatchJobId
        Catch ex As Exception
            Throw ex
        End Try
        Return BatchJobId
    End Function
    Public Sub ExecuteAddFromCashbookIds(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Try
            Me.ExecuteAddFromCashbookIds(BatchJobId _
                                         , CStr(Parameters.GetValue("CashbookIds")) _
                                         , CInt(Parameters.GetValue("CompanyId")) _
                                         , CStr(Parameters.GetValue("BankSortCode")) _
                                         , CStr(Parameters.GetValue("BankAccountNumber")) _
                                         , CStr(Parameters.GetValue("Notes")) _
                                         , CBool(Parameters.GetValue("SendReceipt")) _
                                         , CDate(Parameters.GetValue("DateBanked")) _
                                         , CBool(Parameters.GetValue("SettleTransaction")) _
                                         , New Guid(CStr(Parameters.GetValue("SubmittedByUserSessionId"))))
        Catch ex As Exception
            Throw ex
        End Try

    End Sub
    Public Sub ExecuteAddFromCashbookIds(ByVal BatchJobId As Integer _
                        , ByVal CashbookIds As String _
                        , ByVal CompanyId As Integer _
                        , ByVal BankSortCode As String _
                        , ByVal BankAccountNumber As String _
                        , ByVal Notes As String _
                        , ByVal SendReceipt As Boolean _
                        , ByVal DateBanked As Date _
                        , ByVal SettleTransaction As Boolean _
                        , ByVal SubmittedByUserSessionId As Guid)
        Dim sql As String = ""

        Dim BatchLog As BatchLog = Nothing
        If BatchJobId <> Nothing Then
            BatchLog = New BatchLog("AddBankDepositFromCashbookIds" _
                                                    , "AddFromCashbookIds:" & CashbookIds _
                                                   & ";SendReceipt=" & SendReceipt _
                                                   & ";SettleTransaction=" & SettleTransaction _
                                                    , Me.db _
                                                    , BatchJobId _
                                                    , Me.UserSession.UserSessionIdGUID
                                                    )
        End If


        Dim BatchLogMessage As String = Nothing

        Try
            sql = "SELECT CashbookId "
            sql += "    ,Amount"
            sql += " FROM Cashbook"
            sql += " WHERE CashbookId IN (0" & CashbookIds & ")"
            Dim tblCashbook As DataTable = db.GetDataTableFromSQL(sql)
            If tblCashbook.Rows.Count = 0 Then
                Throw New Exception("No Cashbook records found for criteria:'" & CashbookIds & "'")
            End If
            For Each rowCash As DataRow In tblCashbook.Rows
                Dim Cashbook As New Cashbook(rowCash("CashbookId"), db, UserSession)
                If Not db.IsDBNull(Cashbook.CashbookRow("BankDepositId")) Then
                    Throw New Exception("CashbookId:" & Cashbook.CashbookId & " has already been marked as Deposited.  This deposit has been cancelled")
                End If
            Next

            Dim TotalAmount As Double = 0
            Dim row As DataRow = Me.BankDeposit.NewRow
            row("BankDepositId") = db.GetNextNumber("BankDeposit")
            row("CompanyID") = CompanyId
            row("BankAccountNumber") = BankAccountNumber
            row("BankSortCode") = BankSortCode
            row("DateBanked") = DateBanked
            row("AmountDeposited") = TotalAmount
            row("Notes") = Notes
            row("CreatedDateTime") = Now()
            row("CreatedByUserId") = UserSession.UserName20
            Me.BankDeposit.Rows.Add(row)
            Me.daBankDeposit.Update(Me.MainDataset, "BankDeposit")
            Me.Save()
            Me.BankDepositId = row("BankDepositId")
            Me.Initilise()
            If BatchLog IsNot Nothing Then BatchLog.Update("BankDeposit:" & Me.BankDepositId & " created")

            For Each rowCash As DataRow In tblCashbook.Rows
                Dim Cashbook As New Cashbook(rowCash("CashbookId"), db, UserSession)
                Dim TranStartedHere As Boolean = False
                If db.DBTransaction Is Nothing Then
                    Me.db.BeginTran()
                    TranStartedHere = True
                End If
                Try
                    BatchLogMessage = "CashbookId:" & Cashbook.CashbookId
                    If SettleTransaction Then
                        Cashbook.SettleCreditCard()
                        BatchLogMessage += " settled,"
                    End If
                    Me.BankDepositRow("AmountDeposited") += Cashbook.CashbookRow("Amount")
                    Me.Save()
                    Cashbook.CashbookRow("BankDepositId") = Me.BankDepositId
                    '27/11/07  Julian Gates Replace all but last 4 digits from PaymentCardNumber for successful settlements SIR1250
                    If db.IsDBNull(Cashbook.CashbookRow("PaymentCardNumber"), "") <> "" Then
                        Dim sNo As String = CStr(Cashbook.CashbookRow("PaymentCardNumber"))
                        Cashbook.CashbookRow("PaymentCardNumber") = "XXXXXXXXXXXXXXXXXX".Substring(0, sNo.Length - 4) & sNo.Substring(sNo.Length - 4, 4)
                    End If
                    If db.IsDBNull(Cashbook.CashbookRow("BankAccountNumber"), "") <> "" Then
                        Dim sNo As String = CStr(Cashbook.CashbookRow("BankAccountNumber"))
                        Cashbook.CashbookRow("BankAccountNumber") = "XXXXXXXXXXXXXXXXXX".Substring(0, sNo.Length - 4) & sNo.Substring(sNo.Length - 4, 4)
                    End If
                    If db.DBTransaction Is Nothing Then
                        BatchLogMessage += " **Report to ZEDRA: DBTransaction is nothing when it shouldn't be**"
                    End If
                    BatchLogMessage += " deposited,"
                    '03/07/15   Julian Gates    SIR3895 - Call SendEmailReceipt and update EmailReceiptDateTime if blank
                    '22/08/23   Julian Gates    SIR5683 - Don't try to send receipt emails for block orders
                    If SendReceipt And db.IsDBNull(Cashbook.CashbookRow("EmailReceiptDateTime"), Nothing) = Nothing Then
                        Dim salesOrderType As String = db.DLookup("OrderType", "SalesOrder", "OrderNumber=" & Cashbook.CashbookRow("OrderNumber"))
                        Select Case salesOrderType
                            Case "Block"
                                'Don't send receipt email for block orders
                                BatchLogMessage += "Is Block order type no receipt email required,"
                            Case Else
                                Try
                                    Cashbook.SendEmailReceipt()
                                    BatchLogMessage += " emailed,"
                                    Cashbook.CashbookRow("EmailReceiptDateTime") = Now()
                                Catch ex As Exception
                                    '10/1/20    James Woosnam       SIR4990 - Make receipt failure an error
                                    Throw New Exception("Send Receipt FAILED for CashbookId:" & Cashbook.CashbookId & " Error:" & ex.Message)
                                End Try
                        End Select
                    End If
                    Cashbook.Save()
                    If TranStartedHere Then Me.db.CommitTran()
                Catch ex As Exception
                    BatchLogMessage += " Deposit Failure:" & ex.Message
                    If TranStartedHere Then Me.db.RollbackTran()
                    Throw New Exception("CashbookId:" & Cashbook.CashbookId & " Failed:" & ex.Message)
                End Try

                BatchLogMessage = BatchLogMessage.Substring(0, BatchLogMessage.Length - 1) & "."
                If BatchLog IsNot Nothing Then BatchLog.Update(BatchLogMessage)

            Next
            Dim logs As New BusinessLogic.Logs(db, Me.UserSession)

            logs.WriteAuditLog("BankDeposit", Me.BankDepositId, Me.UserSession.UserId, Me.UserSession.UserName, "Add", "")

            If BatchLog IsNot Nothing Then BatchLog.Update("Depositid:" & Me.BankDepositId & " Create Successfully.", "Complete")

        Catch ex As Exception
            If BatchLog IsNot Nothing Then BatchLog.Update("Add Bank Deposit Failed:" & ex.Message & " BatchLogMessage:" & BatchLogMessage, "Failed")
            Throw New Exception("Add Bank Deposit failed:" & ex.Message)
        End Try

    End Sub
End Class
