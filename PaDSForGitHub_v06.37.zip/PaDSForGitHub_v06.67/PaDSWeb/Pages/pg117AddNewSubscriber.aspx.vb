﻿Imports System.Data
Imports System.Data.SqlClient
Imports AjaxControlToolkit.ToolkitScriptManager

'Modification History
'19/01/11  Julian Gates   Initial version
'21/6/11   Julian Gates   Modification: Save entered passwords in viewstate to repopulate field if error.
'21/6/11   Julian Gates   Modification: Add animation and hide save button to stop duplicate subscribers being added.
'05/3/12   Julian Gates   Removed Ajax roundpanels
'03/10/14   Julian Gates    SIR3621 - Add IsReceiveMail to  Subscriber.Add
'31/07/15   Julian Gates    SIR3898 - Remove mandatory validation from Non Us & Canada State field.
'16/10/15   Julian Gates    SIR3982 - Change www.p-e-p.org links to support.pep-web.org
'23/11/15   Julian Gates    SIR4016 - Add Triggers to Update panel on aspx page to get MaintainSchrollPosition working
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields
'29/10/19   Julian Gates    SIR4763 - Remove WebUserName, WebUserPassword and email confirmation fields.
'29/10/19   Julian Gates    SIR4763 - Remove VAT Number field.
'10/1/20    James Woosnam   SIR4984 - If passed in AffiliateToSubscriberId then affiliate to sub
'13/1/20    James Woosnam   SIR4977 - Update duplicate checking
'17/02/20   Julian Gates    SIR5020 - Change Duplicate Email Info Message text and move below Email Address field and move page error message into page.
'03/03/20   Julian Gates    Convert page to be English and Spanish
'7/1/21     Julian Gates    SIR5143 - Rework page to allow Basic User entry.
'12/02/21   Julian Gates    SIR5193 - Set field focus to correct field after Email check
'25/08/21   Julian Gates    SIR5305 - Change @p-e-p.org emails to @pep-web.org
'19/4/22    James Woosnam   SIR5476 - Get subscriber from the one matched to the email and create user
'21/4/22    James Woosnam   SIR5489 - Check first & last names saved on DB match, if not rollback and show error
'24/05/22   Julian Gates    SIR5509 - Add functionality to add RFP users and order PEPWEBS products.
'17/03/23   Julian Gates    SIR5622 - Add Trim to Me.EmailMain.Text, Me.FirstName.Text, Me.LastName.Text
'07/01/25   Julian Gates    SIR5781 - Modify to stop SQL injection

Partial Class Pages_pg117AddNewSubscriber
    Inherits System.Web.UI.Page
    '******* This page is designed to work with one Company *****************
    Dim CompanyId As Integer = 2
    Public ErrorMessage As String = ""

    Dim StdCode As New BusinessLogic.StdCode()
    '10/1/20    James Woosnam   SIR4984 - If passed in AffiliateToSubscriberId then affiliate to sub
    Dim _AffiliateToSubscriber As BusinessLogic.Subscriber = Nothing
    ReadOnly Property AffiliateToSubscriber As BusinessLogic.Subscriber
        Get
            If _AffiliateToSubscriber Is Nothing Then
                If ViewState("AffiliateToSubscriberId") IsNot Nothing Then
                    _AffiliateToSubscriber = New BusinessLogic.Subscriber(ViewState("AffiliateToSubscriberId"), Master.db, Master.UserSession)
                End If
            End If
            Return _AffiliateToSubscriber
        End Get
    End Property

    Private _SalesOrder As BusinessLogic.SalesOrder = Nothing
    Public Property SalesOrder() As BusinessLogic.SalesOrder
        Get
            If Me._SalesOrder Is Nothing Then
                Me._SalesOrder = New BusinessLogic.SalesOrder(Me.Master.db, Me.Master.UserSession)
            End If
            Return Me._SalesOrder
        End Get
        Set(ByVal value As BusinessLogic.SalesOrder)
            Me._SalesOrder = value
        End Set
    End Property
    Public JournalProductName As String = ""
    Dim _JournalProd As BusinessLogic.Product = Nothing
    Public ReadOnly Property JournalProd As BusinessLogic.Product
        Get
            If _JournalProd Is Nothing AndAlso ViewState("JournalPurchaseProductCode") IsNot Nothing Then
                _JournalProd = New BusinessLogic.Product(ViewState("JournalPurchaseProductCode"), Master.db)
            End If
            Return _JournalProd
        End Get
    End Property
    Dim _PEPWebProd As BusinessLogic.Product = Nothing
    Public ReadOnly Property PEPWebProd As BusinessLogic.Product
        Get
            If _PEPWebProd Is Nothing AndAlso ViewState("PEPPurchaseProductCode") IsNot Nothing Then
                _PEPWebProd = New BusinessLogic.Product(ViewState("PEPPurchaseProductCode"), Master.db)
            End If
            Return _PEPWebProd
        End Get
    End Property

    Enum PageModes
        FullDetails
        BasicDetails
    End Enum
    ReadOnly Property PageMode As PageModes
        Get
            Return ViewState("PageMode")
        End Get
    End Property
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim langDis As BusinessLogic.UserSession.DisplayLanguages = Me.Master.DisplayLanguageRBLSelectedValue
        If Not IsPostBack And IsNumeric(Request.QueryString("DisplayLanguage")) Then
            langDis = Request.QueryString("DisplayLanguage")
        End If
        'Must reset cookie when opening 
        Dim ResetSessionCookieIfNotPostback As Boolean = Not Me.IsPostBack Or Request.QueryString("UserSessionId") = "" 'if a sess is passed then needed 
        Master.Initilise("New User Registration", "00", "", "", "", ResetSessionCookieIfNotPostback)
        Master.UserSession.DisplayLanguage = langDis
        Master.ShowLanguageRBL = True


        If Page.IsPostBack Then
            'Me.Subscriber.MainDataset = CType(ViewState("MainDataSet"), DataSet)
            ''24/05/22   Julian Gates    SIR5509 - Set Pagemode to FullDetails if AddRFPPEPAccess checked.
            'If ViewState("JournalPurchaseProductCode") <> "" And Me.AddPEPWebAccess.Checked Then
            '    ViewState("PageMode") = PageModes.FullDetails
            'End If
        Else

            If Request.QueryString("PageMode") <> "" AndAlso Request.QueryString("PageMode").ToLower = "basicdetails" Then
                ViewState("PageMode") = PageModes.BasicDetails
            Else
                ViewState("PageMode") = PageModes.FullDetails
            End If
            '10/1/20    James Woosnam   SIR4984 - If passed in AffiliateToSubscriberId then affiliate to sub
            If IsNumeric(Request.QueryString("AffiliateToSubscriberId")) Then
                ViewState("AffiliateToSubscriberId") = Request.QueryString("AffiliateToSubscriberId")
                Try
                    If Me.AffiliateToSubscriber.SubscriberRow("EntityType") <> "Organisation" Then
                        Me.Master.WebForm.AddPageError("AffiliateToSubscriberId error. New subscribers can only be added to Organisations")
                    End If
                Catch ex As Exception
                    Me.Master.WebForm.AddPageError("AffiliateToSubscriberId error. " & ex.Message)
                    _AffiliateToSubscriber = Nothing
                End Try
            End If

            If Me.Master.WebForm.IsValid Then
                ReadRecord()
            End If
            Select Case Me.PageMode
                Case PageModes.BasicDetails
                    'For now basic details is always when called from PEP so add setting to session to use after password set up
                    Master.UserSession.Data("AfterPasswordSetupReturnToPep") = True

            End Select

            Me.EmailMain.Focus()
        End If
        If Request.QueryString("JournalPurchaseProductCode") <> "" Then
            If Master.db.DLookup("ProductCode", "Product", "ProductCode=@JournalPurchaseProductCode AND ProductStatus='Current'", "JournalPurchaseProductCode", Request.QueryString("JournalPurchaseProductCode"), True) = Nothing Then
                Master.WebForm.AddPageError(Request.QueryString("JournalPurchaseProductCode") & " is not a valid product")
            Else
                ViewState("JournalPurchaseProductCode") = Request.QueryString("JournalPurchaseProductCode")
                Me.JournalProductName = Me.JournalProd.ProductName
                Dim vw As New DataView(Me.JournalProd.ProductAffiliateRate, "SubscriberCategory='" & IIf(Me.CandidateStudent.Checked, "Student", "Ordinary") & "' AND GroupSubscriberId=" & ViewState("AffiliateToSubscriberId"), "", DataViewRowState.CurrentRows)
                If vw.Count = 0 Then
                    Master.WebForm.AddPageError(JournalProd.ProductName & " does not have an affiliate rate.")
                Else
                    ViewState("JournalProductRateId") = vw(0)("ProductrateId")
                End If
            End If
        End If
        If Request.QueryString("PEPPurchaseProductCode") <> "" Then
            If Master.db.DLookup("ProductCode", "Product", "ProductCode=@PEPPurchaseProductCode AND ProductStatus='Current'", "PEPPurchaseProductCode", Request.QueryString("PEPPurchaseProductCode"), True) = Nothing Then
                Master.WebForm.AddPageError(Request.QueryString("PEPPurchaseProductCode") & " is not a valid product")
            Else
                ViewState("PEPPurchaseProductCode") = Request.QueryString("PEPPurchaseProductCode")
                Dim vw As New DataView(Me.PEPWebProd.ProductAffiliateRate, "GroupSubscriberId=" & ViewState("AffiliateToSubscriberId"), "", DataViewRowState.CurrentRows)
                For Each r As DataRowView In vw
                    Dim vwPR As New DataView(Me.PEPWebProd.ProductRate, "ProductRateId=" & r("ProductRateId"), "", DataViewRowState.CurrentRows)
                    Select Case r("SubscriberCategory")
                        Case "Ordinary"
                            ViewState("OrdinaryPEPProductRateText") = CDbl(vwPR(0)("Productrate")).ToString("#,##0.##") & vwPR(0)("CurrencyCode")
                        Case "Student"
                            ViewState("StudentPEPProductRateText") = CDbl(vwPR(0)("Productrate")).ToString("#,##0.##") & vwPR(0)("CurrencyCode")
                    End Select
                Next

            End If
        End If
        'Used to display animation when processing credit card and hide confirm button
        Me.progressImage.Style.Add("display", "none")
        SaveBtn.OnClientClick = "document.getElementById('" + progressImage.ClientID + "').style.display = ''; document.getElementById('" + SaveBtn.ClientID + "').style.display = 'none';"

    End Sub

    Sub PageSetup()
        'Hide show page elements based on PageMode of BasicDetails or FullDetails
        Me.Master.PageTitle = Master.GetTranslatedText(38, 117, "New User Registration", "Registro de nuevo usuario") & IIf(Me.AffiliateToSubscriber Is Nothing, "", Master.GetTranslatedText(39, 117, " / Exisiting User Confirmation", " / Confirmación de usuario existente"))
        Select Case Me.PageMode
            Case PageModes.BasicDetails
                Me.HeaderText.Text = Master.GetTranslatedText(37, 117, "Blank at present")

            Case PageModes.FullDetails
                Me.HeaderText.Text = Master.GetTranslatedText(36, 117, "To order a PEP, or an IJP......")
        End Select

        Me.AddDataPanel.Visible = EmailAddressCheckOutcome = EmailAddressCheckOutcomes.OKNew
        Me.GDPRAgreementPanel.Visible = EmailAddressCheckOutcome = EmailAddressCheckOutcomes.OKNew
        Me.CandidatePanel.Visible = EmailAddressCheckOutcome = EmailAddressCheckOutcomes.OKNew And (Me.PageMode = PageModes.FullDetails Or AffiliateToSubscriber IsNot Nothing)

        If Me.AffiliateToSubscriber IsNot Nothing Then
            Me.AffiliateToSubscriberLbl.Text = String.Format(Master.GetTranslatedText(47, 117, "As part of this registration/confirmation you will be automatically affiliated to {0}. This will allow you to receive any discounted rates allocated with this group.<br>If you already have a PaDS user, please start entering your email and other details to allow us to check.") _
                                                       , Me.AffiliateToSubscriber.SubscriberName)
            Me.AffiliateToSubscriberLbl.Visible = True
        End If
        If Me.JournalProd IsNot Nothing Then
            Me.JournalPurchaseAccessHeader.Text = String.Format(Master.GetTranslatedText(43, 117, "Access to the {0} for {1} members."), JournalProd.ProductCode, Me.AffiliateToSubscriber.SubscriberName)
            Me.JournalPurchaseAccessText.Text = String.Format(Master.GetTranslatedText(19, 117, "This registration will {0}=Journal Prod {1}=AffiliateName, {2}=FullRate,{3}=StudentRate"), JournalProd.ProductName, Me.AffiliateToSubscriber.SubscriberName, ViewState("OrdinaryPEPProductRateText"), ViewState("StudentPEPProductRateText"))
            JournalPurchaseAccessPanel.Visible = True
        End If

        'Hide show page elements based if FullDetails
        Me.TitleRow.Visible = Me.PageMode = PageModes.FullDetails
        Me.BillingAddressRow.Visible = Me.PageMode = PageModes.FullDetails
        Me.TownRow.Visible = Me.PageMode = PageModes.FullDetails
        Me.PostcodeRow.Visible = Me.PageMode = PageModes.FullDetails


        Me.SaveBtn.Text = Master.GetTranslatedText(34, 0, "Save", "Guarda")
        Me.CheckEmailButton.Text = Master.GetTranslatedText(228, 117, "Check", "Controlar")

        Me.ResendLogonDetails.Text = Master.GetTranslatedText(35, 0, "Send", "Enviar")

        '17/02/20   Julian Gates    SIR5020 -  Show ErrorMessage in the page and not in header
        Me.ErrorMessage = Master.OutputErrorMessage()
        Me.pnlError.Visible = True
        Me.pnlError.Update()

        Me.SaveBtn.Visible = EmailAddressCheckOutcome = EmailAddressCheckOutcomes.OKNew
        Me.ResendLogonDetailsRow.Visible = Me.EmailAddressCheckOutcome = EmailAddressCheckOutcomes.AlreadyUser
        Me.DuplicateEmailInfoMessageRow.Visible = EmailAddressCheckOutcome = EmailAddressCheckOutcomes.AlreadyUser



        '01/03/22   Julian Gates    SIR5443 - Show Non US and US State fields based on country field selection.
        'Postal
        Me.PostalStateIsUSCanadaRow.Visible = (Me.CountryId.SelectedValue = "11" Or Me.CountryId.SelectedValue = "56") And PageMode = PageModes.FullDetails
        Me.PostalStateNonUSCanadaRow.Visible = Not (Me.CountryId.SelectedValue = "11" Or Me.CountryId.SelectedValue = "56" Or Me.CountryId.SelectedValue = "") And PageMode = PageModes.FullDetails

    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else


                Select Case Me.PageMode
                    Case PageModes.FullDetails
                        Me.Master.WebForm.DropDownValidateMandatory(Me.Title, Master.GetTranslatedText(5, 0, "Title"))
                End Select
                Me.Master.WebForm.FieldValidateMandatory(Me.FirstName, Master.GetTranslatedText(2, 0, "First Name"))
                Me.Master.WebForm.FieldValidateFirstLastNameInput(Me.FirstName, Master.GetTranslatedText(2, 0, "First Name"))
                Me.Master.WebForm.FieldValidateMandatory(Me.LastName, Master.GetTranslatedText(3, 0, "Last Name"))
                Me.Master.WebForm.FieldValidateFirstLastNameInput(Me.LastName, Master.GetTranslatedText(3, 0, "Last Name"))

                If tSubscriber.Rows.Count = 1 And Master.WebForm.IsValid Then
                    If Me.FirstName.Text.Trim = Master.db.IsDBNull(tSubscriber.Rows(0)("FirstName"), "") And Me.LastName.Text.Trim = Master.db.IsDBNull(tSubscriber.Rows(0)("LastName"), "") And Me.CountryId.Text = Master.db.IsDBNull(tSubscriber.Rows(0)("PrimaryCountryId"), "") Then
                        'Names match sub linked to entered email so all ok
                    Else
                        Me.Master.WebForm.AddPageError(Master.GetTranslatedText(29, 117, "The names and country entered do not match those we have stored against this email address. Please correct them, or contact support." _
                                                               , "Los nombres ingresados ​​no coinciden con los que hemos almacenado en esta dirección de correo electrónico. Póngase en contacto con el soporte."))
                    End If
                End If


                Me.Master.WebForm.DropDownValidateMandatory(Me.CountryId, Master.GetTranslatedText(12, 0, "Country"))
                Select Case Me.PageMode
                    Case PageModes.FullDetails
                        Me.Master.WebForm.FieldValidateMandatory(Me.BillingAddress, Master.GetTranslatedText(7, 0, "Billing Address"))
                        Me.Master.WebForm.FieldValidateMandatory(Me.Town, Master.GetTranslatedText(23, 0, "City", "Es obligación escribir su Ciudad"))
                        '31/07/15   Julian Gates    SIR3898 - Remove mandatory validation from Non Us & Canada State field.
                        If Me.Master.db.IsDBNull(Me.CountryId.SelectedValue, "") = "11" Or Me.Master.db.IsDBNull(Me.CountryId.SelectedValue, "") = "56" Then 'US or Canada
                            Me.Master.WebForm.DropDownValidateMandatory(Me.CountyUS, Master.GetTranslatedText(13, 0, "State"))
                        End If
                        Me.Master.WebForm.FieldValidateMandatory(Me.PostCode, Master.GetTranslatedText(15, 0, "Postcode"))
                End Select
                If Not Me.GDPRAgreement.Checked Then
                    Master.WebForm.FieldErrorControl(Me.GDPRAgreement, Master.GetTranslatedText(30, 117, "Please tick To confirm you agree With PEP retaining your details"))
                End If
        End Select

        Return Me.Master.WebForm.IsValid
    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        'populate dropdowns
        Select Case Me.PageMode
            Case PageModes.FullDetails
                Me.Master.WebForm.PopulateDropDownListFromLookup(Me.Title, "Title", "<--Select-->")
                Me.Master.WebForm.PopulateDropDownListFromLookup(Me.CountyUS, "US_CanadaStateCode", "<--Select-->")
        End Select
        Me.Master.WebForm.PopulateDropDownListFromSQL(Me.CountryId, "Select Country.CountryId As Value" _
                                                                                & "     , Country.CountryName As Text" _
                                                                                & " FROM Country" _
                                                                                & " ORDER BY Country.CountryName" _
                                                                             , "<--Select-->")

    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        '  ViewState("MainDataSet") = Me.Subscriber.MainDataset
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    '03/10/14   Julian Gates    SIR3621 - Add IsReceiveMail to  Subscriber.Add
    '16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields
    '29/10/19   Julian Gates    SIR4768 - Remove VAT Number field.
    '07.01/21   Julian Gates    SIR5143 - Only pass Title if PageModes.FullDetails

    Protected Sub SaveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                Master.db.BeginTran()
                Try
                    Dim Subscriber As New BusinessLogic.Subscriber(Me.Master.db, Me.Master.UserSession)
                    If tSubscriber.Rows.Count = 0 Then
                        Subscriber.Add(Me.EmailMain.Text.Trim _
                                  , IIf(Me.PageMode = PageModes.FullDetails, Me.Title.SelectedValue, "") _
                                  , Me.FirstName.Text.Trim _
                                  , Me.LastName.Text.Trim _
                                  , Me.BillingAddress.Text _
                                  , Me.Town.Text _
                                  , Me.County.Text _
                                  , Me.CountyUS.SelectedValue _
                                  , Me.PostCode.Text _
                                  , Me.CountryId.SelectedValue _
                                  , Me.CandidateStudent.Checked _
                                  , Me.CompanyId _
                                  , True _
                                  , IIf(Me.PageMode = PageModes.FullDetails, True, False))
                    Else
                        '19/4/22    James Woosnam   SIR5476 - Get subscriber from the one matched to the email and create user
                        Subscriber = New BusinessLogic.Subscriber(CInt(tSubscriber.Rows(0)("SubscriberId")), Me.Master.db, Me.Master.UserSession)
                        Dim RemoteUser As New BusinessLogic.RemoteUser(Me.Master.db, Me.Master.UserSession)
                        RemoteUser.AddNewSubscriberUser(Me.EmailMain.Text.Trim, Subscriber.SubscriberId, BusinessLogic.UserSession.AuthorityLevels.IndividualSubscriber)
                        If Not RemoteUser.UserName.Contains("PaDSTest") Then RemoteUser.ResetPasswordAndEmail()

                    End If

                    Select Case Me.PageMode
                        Case PageModes.FullDetails
                            Subscriber.AddCompanyAccount(Me.CompanyId, "Individual", 4, "Full", Subscriber.SubscriberRow("DefaultPostalAddressId"))
                        Case PageModes.BasicDetails

                            If Master.UserSession.LoggedIn Then
                                Select Case Master.UserSession.AuthorityLevel
                                    Case BusinessLogic.UserSession.AuthorityLevels.GroupUser
                                        Select Case Master.UserSession.LoggedInMethod
                                            Case BusinessLogic.UserSession.LoggedInMethods.IPAddress, BusinessLogic.UserSession.LoggedInMethods.ReferrerURL
                                                Subscriber.AddSubscriberAffiliate(Master.UserSession.Data("SubscriberId"))
                                            Case BusinessLogic.UserSession.LoggedInMethods.Federated
                                                Subscriber.AddSubscriberAffiliate(Master.UserSession.Data("SubscriberId"))
                                                'Before updating the loggedInMethod Call UpdateFederatedPersonIdFromSession which will update when available and required
                                                Subscriber.RemoteUser.UpdateFederatedPersonIdFromSession()
                                        End Select

                                End Select

                            End If
                    End Select
                    '10/1/20    James Woosnam   SIR4984 - If passed in AffiliateToSubscriberId then affiliate to sub
                    DoAffiliateProcessing()

                    '21/4/22    James Woosnam   SIR5489 - Check first & last names saved on DB match, if not rollback and show error
                    Dim testSubscriber As New BusinessLogic.Subscriber(Subscriber.SubscriberId, Master.db, Master.UserSession)
                    If testSubscriber.SubscriberRow("FirstName") <> Me.FirstName.Text.Trim Then
                        Master.WebForm.FieldErrorControl(Me.FirstName, Master.GetTranslatedText(28, 0, "PaDS doesn't currently handle these characters. Please remove them.", "PaDS actualmente no maneja estos caracteres. Por favor quítalas."))
                    End If
                    If testSubscriber.SubscriberRow("LastName") <> Me.LastName.Text.Trim Then
                        Master.WebForm.FieldErrorControl(Me.LastName, Master.GetTranslatedText(28, 0, "PaDS doesn't currently handle these characters. Please remove them.", "PaDS actualmente no maneja estos caracteres. Por favor quítalas."))
                    End If



                    If Not Master.WebForm.IsValid Then
                        Master.db.RollbackTran()
                        Exit Sub

                    End If
                    Master.db.CommitTran()
                    Try
                        Me.Master.UserSession.UserSessionRow("UserId") = Subscriber.RemoteUser.UserId  'populate to help debugging
                        Me.Master.UserSession.UserSessionRow("UserName") = Subscriber.RemoteUser.UserId  'As user isn't logged-on user userId in Username
                        Me.Master.UserSession.Save()
                    Catch ex As Exception
                        Me.Master.AddAdditionalInfoForlog("Update Session Info failed:  " & ex.Message)
                    End Try
                    Me.Master.AddAdditionalInfoForlog("New Registration Saved")
                Catch ex As Exception
                    Master.db.RollbackTran()
                    Throw ex
                End Try

            Catch ex As Exception
                Me.Master.WebForm.AddPageError(ex)
            End Try

            ' Show message to say user set up and emails confirmation and password set up emails sent 
            If Me.Master.WebForm.IsValid Then
                Me.MainContentTable.Visible = False
                Me.EmailSentMessageTable.Visible = True
            Else
                Me.EmailSentMessageTable.Visible = False
                Me.MainContentTable.Visible = True
            End If


        End If
    End Sub



    Protected Sub EmailMain_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles EmailMain.TextChanged
        CheckEmail()
    End Sub
    Enum EmailAddressCheckOutcomes
        NotChecked
        OKNew
        AlreadyUser
        UsedManyTimes
    End Enum
    Public Property EmailAddressCheckOutcome As EmailAddressCheckOutcomes
        Get
            If ViewState("EmailAddressCheckOutcome") Is Nothing Then ViewState("EmailAddressCheckOutcome") = EmailAddressCheckOutcomes.NotChecked
            Return ViewState("EmailAddressCheckOutcome")
        End Get
        Set(value As EmailAddressCheckOutcomes)
            ViewState("EmailAddressCheckOutcome") = value
        End Set
    End Property

    ReadOnly Property tUser As DataTable
        Get
            '13/1/20    James Woosnam   SIR4977 - Update duplicate checking

            Dim sql As String = ""
            sql = "Select ru.EmailAddress"
            sql += " , SubscriberId = rur.RightsToId"
            sql += " , ru.UserStatus"
            sql += " FROM RemoteUser ru"
            sql += "    LEFT JOIN RemoteUserRights rur"
            sql += "    On rur.userid = ru.UserId"
            sql += " WHERE EmailAddress=@EmailAddress"
            sql += " And ru.UserStatus <> 'InActive'"
            Dim cmd As New SqlCommand(sql, Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailAddress", System.Data.SqlDbType.VarChar, 255, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                         , Me.EmailMain.Text.Trim))
            Return Me.Master.db.GetDataTableFromSQL(cmd)
        End Get
    End Property
    ReadOnly Property tSubscriber As DataTable
        Get
            Dim sql As String = ""
            sql = "Select s.subscriberId"
            sql += " , s.SubscriberName"
            sql += " , s.FirstName"
            sql += " , s.LastName"
            sql += " , s.EntityType"
            sql += " , s.PrimaryCountryId"
            sql += " FROM Subscriber s"
            sql += "    INNER JOIN SubscriberAddress em"
            sql += "    On em.SubscriberId = s.Subscriberid"
            sql += "    AND em.AddressType = 'Email'"
            sql += "    AND em.AddressDescription = 'Main'"
            sql += " WHERE em.AddressText=@EmailAddress"
            sql += " And s.SubscriberStatus = 'Current'"
            Dim cmd As New SqlCommand(sql, Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailAddress", System.Data.SqlDbType.VarChar, 255, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                         , Me.EmailMain.Text.Trim))
            Return Me.Master.db.GetDataTableFromSQL(cmd)
        End Get
    End Property
    Protected Sub CheckEmail()
        Me.EmailMain.CssClass = "fldEntry"
        Me.EmailAddressCheckOutcome = EmailAddressCheckOutcomes.NotChecked
        Me.SubscriberButNoUserRow.Visible = False
        Me.Master.WebForm.FieldValidateMandatory(Me.EmailMain, Master.GetTranslatedText(4, 0, "Email Address"))

        If Me.EmailMain.Text.Trim <> "" Then

            '12/02/21   Julian Gates    SIR5193 - Set field focus to correct field after Email check
            Select Case Me.tUser.Rows.Count
                Case 0
                    Select Case tSubscriber.Rows.Count
                        Case 0
                            EmailAddressCheckOutcome = EmailAddressCheckOutcomes.OKNew
                        Case 1
                            Me.SubscriberButNoUserRow.Visible = True
                            ViewState("PageMode") = PageModes.BasicDetails
                            EmailAddressCheckOutcome = EmailAddressCheckOutcomes.OKNew
                        Case Else
                            EmailAddressCheckOutcome = EmailAddressCheckOutcomes.UsedManyTimes
                    End Select
                Case 1
                    If tUser.Rows(0)("UserStatus") = "Pending" Then
                        Me.Master.WebForm.AddPageError(Master.GetTranslatedText(4, 0, "Email address: ", "Correo electrónico: ") & Me.EmailMain.Text &
                                                                   Master.GetTranslatedText(25, 117, " is already used on a Pending user. Please contact PaDS support ", " ya está en uso en un Usuario pendiente. Por favor contacte al soporte de PaDS ") & Me.Master.db.SupportEmailLink)
                    Else
                        '17/02/20   Julian Gates    SIR5020 - Change Duplicate Email Info Message text and move below Email Address field
                        Me.EmailAddressCheckOutcome = EmailAddressCheckOutcomes.AlreadyUser
                        Me.DuplicateEmailAddressText.Text = Me.EmailMain.Text.Trim
                        Me.ResendLogonDetailsRow.Focus()
                    End If

                Case 2
                    EmailAddressCheckOutcome = EmailAddressCheckOutcomes.UsedManyTimes
            End Select
            If EmailAddressCheckOutcome = EmailAddressCheckOutcomes.UsedManyTimes Then
                Me.Master.WebForm.AddPageError(Master.GetTranslatedText(4, 0, "Email address: ", "Correo electrónico: ") & Me.EmailMain.Text &
                                                                   Master.GetTranslatedText(26, 117, " is already in use multiple times on PaDS. Please contact PaDS support ", " ya está en uso en muchas ocasiones en PaDS. Por favor contacte al soporte de PaDS ") & Me.Master.db.SupportEmailLink)


            End If
            If EmailAddressCheckOutcome = EmailAddressCheckOutcomes.OKNew Then
                Select Case Me.PageMode
                    Case PageModes.FullDetails
                        Me.Title.Focus()
                    Case PageModes.BasicDetails
                        Me.FirstName.Focus()
                End Select
            Else
                Me.EmailMain.Focus()
            End If
        End If
    End Sub
    Sub DoAffiliateProcessing()
        Try
            If Me.AffiliateToSubscriber IsNot Nothing Then
                Select Case tUser.Rows.Count
                    Case 1
                        Dim subscriber As New BusinessLogic.Subscriber(tUser.Rows(0)("SubscriberId"), Master.db, Master.UserSession)
                        subscriber.AddSubscriberAffiliate(Me.AffiliateToSubscriber.SubscriberId)

                        If Me.JournalProd IsNot Nothing Then
                            'Add order and orderline records
                            Dim sql As String = ""
                            sql += "SELECT * FROM SalesOrder so "
                            sql += "    INNER JOIN SalesOrderLine sol "
                            sql += "    ON sol.OrderNumber = so.OrderNumber "
                            sql += " WHERE so.SalesOrderStatus IN ('Comlete','Confirmed') "
                            sql += " AND sol.ProductCode = @ProductCode "
                            sql += " AND sol.SubscriberId = @SubscriberId"
                            Dim cmd As New SqlCommand(sql, Master.db.DBConnection, Master.db.DBTransaction)
                            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProductCode", System.Data.SqlDbType.VarChar, 10, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, JournalProd.ProductCode))
                            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, subscriber.SubscriberId))

                            Dim t As DataTable = Master.db.GetDataTableFromSQL(cmd)
                            If t.Rows.Count > 0 Then Exit Sub
                            Me.SalesOrder.Add(JournalProd.ProductCode, subscriber.SubscriberId, "RemotePartial", "AddNewOrderRow", "USD", System.DateTime.Now)
                            Me.SalesOrder.AddNewSalesOrderLine(JournalProd, subscriber.SubscriberId, ViewState("JournalProductRateId"), System.DateTime.Now)
                            Me.SalesOrder.SalesOrderRow("SalesOrderStatus") = "Confirmed"
                            Me.SalesOrder.Save()
                        End If
                End Select
            End If
        Catch ex As Exception
            Throw New Exception("DoAffiliateProcessing failed:" & ex.Message)
        End Try
    End Sub

    'Protected Sub ResendLogonDetails_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ResendLogonDetails.Click
    '    Try
    '        Dim UserName As String = Master.db.DLookup("UserName", "RemoteUser", "EmailAddress=@EmailAddress AND UserStatus IN ('Active','Emailed')", "EmailAddress", Me.EmailMain.Text.Trim, True)
    '        If UserName = Nothing Then
    '            Throw New Exception(Master.GetTranslatedText(27, 117, "Email address not linked to a User record.", "Este correo electrónico no está vinculado a nuestros registros de usuarios."))
    '        End If
    '        Dim ru As New BusinessLogic.RemoteUser(UserName, Master.db, Master.UserSession)
    '        ru.ResetPasswordAndEmail()
    '        DoAffiliateProcessing()
    '        Try
    '            Me.Master.UserSession.UserSessionRow("UserId") = ru.UserId  'populate to help debugging
    '            Me.Master.UserSession.UserSessionRow("UserName") = ru.UserId  'As user isn't logged-on user userId in Username
    '            Me.Master.UserSession.Save()
    '        Catch ex As Exception
    '            Me.Master.AddAdditionalInfoForlog("Update Session Info failed:" & ex.Message)
    '        End Try
    '    Catch ex As Exception
    '        Me.Master.WebForm.AddPageError(ex)
    '    End Try

    '    If Master.WebForm.IsValid Then
    '        Me.MainContentTable.Visible = False
    '        Me.ResendEmailSentMessageTable.Visible = True
    '    Else
    '        Me.MainContentTable.Visible = True
    '        Me.ResendEmailSentMessageTable.Visible = False
    '    End If
    'End Sub

    '17/02/20   Julian Gates    SIR5020 - Click Here link to run code below if AffiliateToSubscriber
    Private Sub ClickHereLinkBtn_Click(sender As Object, e As EventArgs) Handles ClickHereLinkBtn.Click
        Try
            DoAffiliateProcessing()
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(ex)
        End Try
        If Master.WebForm.IsValid Then
            If Me.JournalProd Is Nothing Then
                Response.Redirect("../pages/pg070Logon.aspx?" & Me.Master.UserSession.QueryString)
            Else
                Me.AddJournalProductConfirmation.Visible = True
            End If
        End If
    End Sub
    Private Sub CheckEmailButton_Click(sender As Object, e As EventArgs) Handles CheckEmailButton.Click
        Me.CheckEmail()
    End Sub


End Class
