﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.Subscriber
Imports BusinessLogic.ContentSet
'Modification History
'23/04/20  Julian Gates   Initial New version

Partial Class Pages_pg162CompanyAccountMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Enum PageModes
        Add
        Update
    End Enum

    Property pageMode As PageModes
        Set(value As PageModes)
            ViewState("PageMode") = value
        End Set
        Get
            If ViewState("PageMode") Is Nothing Then ViewState("PageMode") = "Add"
            Return ViewState("PageMode")
        End Get
    End Property
    Private _CompanyAccount As BusinessLogic.CompanyAccount = Nothing
    Public Property CompanyAccount() As BusinessLogic.CompanyAccount
        Get
            If Me._CompanyAccount Is Nothing Then
                Me._CompanyAccount = New BusinessLogic.CompanyAccount(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._CompanyAccount
        End Get
        Set(ByVal value As BusinessLogic.CompanyAccount)
            Me._CompanyAccount = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Company Account Maintenance ", "")
        Try
            If Page.IsPostBack Then
                Me.CompanyAccount.MainDataset = CType(ViewState("MainDataSet"), DataSet)
            Else
                If Request.QueryString("CompanyAccountId") <> "" Then
                    Me.pageMode = PageModes.Update
                    Try
                        ViewState("CompanyAccountId") = Request.QueryString("CompanyAccountId")
                        Me.CompanyAccount = New BusinessLogic.CompanyAccount(CInt(Request.QueryString("CompanyAccountId")), Me.uPage.db, Me.uPage.UserSession)
                        ViewState("SubscriberId") = Me.CompanyAccount.CompanyAccountRow("SubscriberId")
                    Catch ex As Exception
                        Me.uPage.PageError = "Invalid Parameter has been passed in"
                    End Try
                    Me.AccountNumber.Focus()
                Else
                    If Request.QueryString("SubscriberId") <> "" Then
                        Me.pageMode = PageModes.Add
                        Try
                            ViewState("SubscriberId") = Request.QueryString("SubscriberId")
                        Catch ex As Exception
                            Me.uPage.PageError = "Invalid Parameter has been passed in"
                        End Try
                    End If
                    Me.CompanyId.Focus()
                End If

                If Me.uPage.IsValid Then
                    ReadRecord()
                End If

                If Request.QueryString("InfoMsg") <> "" Then
                    InfoMsg.Text = Request.QueryString("InfoMsg")
                End If
            End If
        Catch ex As Exception
            uPage.PageError = "An unexpected error has occured.  Please contact support." & ex.ToString
        End Try
    End Sub

    Sub PageSetup()
        Select Case Me.pageMode
            Case PageModes.Add
                uPage.pageTitle = "Add New Company Account"
                Me.CompanyAccountStatus.Text = "Initial"
                Me.CompanyId.Enabled = True
                Me.AddNewBtn.Visible = True
            Case PageModes.Update
                uPage.pageTitle = "Company Account Maint"
                Me.CompanyId.Enabled = False
                Me.AuditTable.Visible = True
                Me.SaveBtn.Visible = True
                Select Case Me.uPage.UserSession.AuthorityLevel
                    Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                    Case Else
                        'If not Company admins then disable fields
                        Me.AccountNumber.Enabled = False
                        Me.AccountType.Enabled = False
                        Me.DiscountRateID.Enabled = False
                        Me.RateType.Enabled = False
                        Me.BillingAddressId.Enabled = False
                        Me.RequireReceipt.Enabled = False
                        Me.RequireInvoice.Enabled = False
                End Select
        End Select
        Me.pageHeaderTitle.Text = uPage.pageTitle

        Me.SubscriberNameLink.Text = uPage.db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & ViewState("SubscriberId"))
        Me.SubscriberNameLink.NavigateUrl = "../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & ViewState("SubscriberId")
    End Sub
    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else
                Select Case Me.uPage.UserSession.AuthorityLevel
                    Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                        Select Case Me.pageMode
                            Case PageModes.Add
                                Me.uPage.DropDownValidateMandatory(Me.CompanyId, "Company")
                                If Me.CompanyId.SelectedValue <> "" And ViewState("SubscriberId") <> "" Then
                                    If uPage.db.DLookup("CompanyAccountId", "CompanyAccount", "CompanyId =" & Me.CompanyId.SelectedValue & " And SubscriberId=" & ViewState("SubscriberId")) <> Nothing Then
                                        uPage.PageError = "Selected Company account alresdy exists for this subscriber, please choose another Company."
                                    End If
                                End If
                        End Select
                        Me.uPage.FieldValidateMandatory(Me.AccountNumber)
                        Me.uPage.DropDownValidateMandatory(Me.AccountType, "Account Type")
                        Me.uPage.DropDownValidateMandatory(Me.DiscountRateID, "Discount Rate")
                        Me.uPage.DropDownValidateMandatory(Me.RateType, "Rate Type")
                        Me.uPage.DropDownValidateMandatory(Me.BillingAddressId, "Billing Address")
                End Select
        End Select

        Return Me.uPage.IsValid
    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        If Me.pageMode = PageModes.Update Then
            Me.uPage.PopulatePageFieldsFromDataRow(Me.CompanyAccount.CompanyAccountRow)
        End If

        Dim sql As String = "SELECT CompanyId As Value" _
                        & " ,CompanyName As Text" _
                        & " FROM " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                        & " Order by 2"
        Me.uPage.PopulateDropDownListFromSQL(Me.CompanyId, sql, uPage.db.DBConnection)

        sql = "Select DiscountRateID As Value,Description As Text " _
                        & " From DiscountRate " _
                        & " Order by 2"
        Me.uPage.PopulateDropDownListFromSQL(Me.DiscountRateID, sql, uPage.db.DBConnection, "<--Select-->")

        sql = "SELECT SubscriberAddressId As Value, AddressDescription + ' - ' + AddressText As Text" _
                        & " From SubscriberAddress " _
                        & " WHERE AddressType = 'Postal'" _
                        & " AND SubscriberId = " & ViewState("SubscriberId") _
                        & " Order by 2"
        Me.uPage.PopulateDropDownListFromSQL(Me.BillingAddressId, sql, uPage.db.DBConnection, "<--Select-->")

        If Me.CompanyId.SelectedValue <> "" Then
            BuildCompanyDependentDropdowns(Me.CompanyId.SelectedValue)
        End If

    End Sub

    Sub BuildCompanyDependentDropdowns(ByVal CompanyId As Integer)

        Dim sql As String = "SELECT LookupItemKey As Value, Name As Text" _
                        & " FROM Lookup" _
                        & " WHERE LookupName = 'AccountType'" _
                        & " AND CompanyId = " & CompanyId _
                        & " AND LookupStatus = 'Active'" _
                        & " ORDER BY DisplayOrder,Name,LookupItemKey"
        Me.uPage.PopulateDropDownListFromSQL(Me.AccountType, sql, uPage.db.DBConnection, "<--Select-->")

        sql = "Select LookupItemKey As Value, Name As Text " _
                        & " FROM Lookup" _
                        & " WHERE LookupName = 'RateType'" _
                        & " AND CompanyId = " & CompanyId _
                        & " AND LookupStatus = 'Active'" _
                        & " ORDER BY DisplayOrder,Name,LookupItemKey"
        Me.uPage.PopulateDropDownListFromSQL(Me.RateType, sql, uPage.db.DBConnection, "<--Select-->")

    End Sub
    Sub SaveRecord()
        '******************************************************
        'Description:	Save the record either by updating
        '******************************************************
        Try
            uPage.db.BeginTran()
            Try

                Me.uPage.PopulateDataRowFromPageFields(Me.CompanyAccount.CompanyAccountRow)
                Me.CompanyAccount.Save()
                Me.uPage.db.CommitTran()

            Catch ex As Exception
                uPage.db.RollbackTran()
                Throw ex
            End Try

        Catch ex As Exception
            Me.uPage.PageError = "An Unexpected Error has occured.  Please contact support" & ex.ToString
        End Try

        If Me.uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=Company Account has been saved&CompanyAccountId=" & Me.CompanyAccount.CompanyAccountId)
        End If
    End Sub

    Protected Sub AddNewBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AddNewBtn.Click
        If Me.IsPageValidForStatus("") Then
            Dim NewCompanyAccount As New BusinessLogic.CompanyAccount(Me.uPage.db, Me.uPage.UserSession)
            Try
                uPage.db.BeginTran()
                Try
                    NewCompanyAccount.AddCompanyAccount(ViewState("SubscriberId") _
                                                        , Me.CompanyId.SelectedValue _
                                                        , Me.AccountNumber.Text _
                                                        , Me.AccountType.SelectedValue _
                                                        , Me.DiscountRateID.SelectedValue _
                                                        , Me.RateType.SelectedValue _
                                                        , Me.BillingAddressId.SelectedValue _
                                                        , Me.Notes.Text _
                                                        , Me.RequireReceipt.Checked _
                                                        , Me.RequireInvoice.Checked)

                    uPage.db.CommitTran()
                Catch ex As Exception
                    uPage.db.RollbackTran()
                    Throw ex
                End Try

            Catch ex As Exception
                Me.uPage.PageError = "An unexpected error has occured. Please contact support." & ex.ToString
            End Try

            If Me.uPage.IsValid Then
                Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=New Company Account has been saved&CompanyAccountId=" & NewCompanyAccount.CompanyAccountId)
            End If
        End If
    End Sub

    Protected Sub SaveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        Try
            If Me.IsPageValidForStatus("") Then SaveRecord()
        Catch ex As Exception
            Me.uPage.PageError = "An unexpected Error has occured. Please contact support." & ex.ToString
        End Try
    End Sub

    Protected Sub BackBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        Response.Redirect("../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & ViewState("SubscriberId"))
    End Sub

    Protected Sub ResetBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ResetBtn.Click
        Select Case Me.pageMode
            Case PageModes.Add
                Response.Redirect(Request.ServerVariables("Path_Info") & "?SubscriberId=" & ViewState("SubscriberId"))
            Case PageModes.Update
                Response.Redirect(Request.ServerVariables("Path_Info") & "?CompanyAccountId=" & Me.CompanyAccount.CompanyAccountId)
        End Select
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.CompanyAccount.MainDataset
        Me.PageSetup()
    End Sub
    Protected Sub CompanyId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CompanyId.SelectedIndexChanged
        If Me.CompanyId.SelectedValue <> "" Then
            BuildCompanyDependentDropdowns(Me.CompanyId.SelectedValue)
        End If
    End Sub
End Class
