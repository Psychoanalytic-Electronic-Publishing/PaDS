﻿Imports System.Data
Imports System.Data.SqlClient
Imports DevExpress.Web

'Modification History
'27/03/  Julian Gates   Initial New version
'23/9/20    James Woosnam   SIR5043 - Allow users to be set up for Organisations
'26/1/21    Julian Gates    SIR5179 - Format RecurringSubscriptionEndDate to show date and time
'17/02/21   Julian Gates    SIR5166 - Removed old asp page links
'07/10/21   Julian Gates    SIR5323 - Add BuildUserDetailsGridViewHTML() to show multiple Users linked to this Sub.
'13/1/22    james Woosnam   SIR5388 - Remove IsReceive Mail/EmailOpt Out column
'11/4/22    Julian Gates    SIR5458 - Add Sent Email list to page.
'21/04/22   Julian Gates    SIR5467 - Show IsReportingParentOverride message if IsReportingParentOverride = true
'16/08/22   Julian Gates    SIR5515 - Add AddAccountBtn to page and button event code.
'20/8/22    Julian Gates    SIR5556 - Show primary country for subscriber 
'18/5/23    Julian Gates    SIR5641 - Add PhoneNumberForCourier ro field to page.
'14/11/23   James Woosnam   SIR5709 - Show end date where sub has no subscription

Partial Class Pages_pg111SubscriberDisplay
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                Me._Subscriber = New BusinessLogic.Subscriber(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Subscriber Display ", "")

        If Request.QueryString("SubscriberId") <> "" Then
            Try
                Me.txtSubscriberId.Value = Request.QueryString("SubscriberId")
                Me.Subscriber = New BusinessLogic.Subscriber(CInt(Request.QueryString("SubscriberId")), Me.uPage.db, Me.uPage.UserSession)
            Catch ex As Exception
                Me.uPage.PageError = "Invalid Parameter has been passed in"
            End Try

            If Me.uPage.IsValid Then
                ReadRecord()
            End If
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If
        OrdersAndSubscriptionsGridSetup()
    End Sub

    Sub PageSetup()
        uPage.pageTitle = "SID: " & Subscriber.SubscriberId & " - " & Subscriber.SubscriberName
        Me.pageHeaderTitle.Text = uPage.pageTitle

        Select Case Subscriber.SubscriberRow("EntityType")
            Case "Organisation"
                Me.SubscriberNamePrompt.Text = "Org Name:"
                Me.UserDetailsGrid.Visible = False
                Me.AddUserLinkGrid.Visible = False
            Case "Person"
                Me.SubscriberNamePrompt.Text = "Person Name:"
        End Select
        'Update remote User
        '23/9/20    James Woosnam   SIR5043 - Allow users to be set up for Organisations
        '07/10/21   Julian Gates    SIR5323 - Use BuildUserDetailsGridViewHTML to show multiple Users.
        If Me.Subscriber.RemoteUserRows IsNot Nothing Then
            If Me.Subscriber.RemoteUserRows.Rows.Count > 0 Then
                BuildUserDetailsGridViewHTML()
                Me.UserDetailsGrid.Visible = True
                Me.AddUserLinkGrid.Visible = False
            End If
        Else
            'Add remote User
            Me.AddUserLinkGrid.Visible = Me.Subscriber.SubscriberStatus = BusinessLogic.Subscriber.SubscriberStates.Current
            Me.UserDetailsGrid.Visible = False
            Me.AddUserLink.NavigateUrl = "../pages/pg061UserMaint.aspx?" _
                                                       & "SubscriberId=" & Me.Subscriber.SubscriberId _
                                                       & "&EmailAddress=" & Me.Subscriber.GetAddressText("Email", "Main") _
                                                       & "&AuthorityLevel=" & IIf(Subscriber.SubscriberRow("EntityType") = "Person", "IndividualSubscriber", "GroupUser") _
                                                       & "&PageMode=Add"
            Me.AddUserLink.ToolTip = "Add Remote User"
        End If

        'if no Email address disable Add User link and show message if entity type is Person
        If Me.Subscriber.GetAddressText("Email", "Main") Is Nothing Or EmailMain.Text = "" Then
            If Me.AddUserLinkGrid.Visible Then
                If Subscriber.SubscriberRow("EntityType") = "Person" Then
                    Me.AddUserLink.Enabled = False
                    Me.AddUserTextLbl.Visible = True
                Else
                    Me.AddUserLink.Enabled = True
                    Me.AddUserTextLbl.Visible = False
                End If
            End If
        End If

        Me.ViewChildAffiliatesLink.NavigateUrl = "../pages/pg130SubscriberAffiliateSelect.aspx?SubscriberId=" & Me.Subscriber.SubscriberId
        Me.ViewChildAffiliatesLink.Text = "See Child Affiliates of this Sub"
        Me.ViewChildAffiliatesLink.ToolTip = "Affiliated to this sub"

        Select Case Me.uPage.UserSession.AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                Me.AddAccountBtn.Visible = True
            Case Else
                Me.AddAccountBtn.Visible = False
        End Select

        '21/10/20   Julian Gates    SIR5099 - Add Audit link
        Me.AuditLink.NavigateUrl = "../pages/pg040AuditLogDisplay.aspx?FltrUpdatedRecordFamily=Subscriber&FltrUpdatedRecordFamilyKey=" & Me.Subscriber.SubscriberId
        Me.AuditLink.Text = "View Audit"
        Me.AuditLink.ToolTip = "View Audit for this record"

        '12/11/20   Julian Gates    SIR5148 - Add Link to Cashbook records linked to this subscriber
        If Me.OrderTable.Visible Then
            Me.ViewCashBookLink.NavigateUrl = "../pages/pg150CashbookSelect.aspx?FilterSubscriberId=" & Me.Subscriber.SubscriberId
            Me.ViewCashBookLink.Text = "View cashbooks linked to this subscriber"
            Me.ViewCashBookLink.ToolTip = "Select to view cashbooks linked to this subscriber"
        End If
        '21/04/22   Julian Gates    SIR5467 - Show IsReportingParentOverride message if IsReportingParentOverride = true
        If uPage.db.IsDBNull(Subscriber.SubscriberRow("IsReportingParentOverride"), False) = True Then
            Me.IsReportingParentOverrideRow.Visible = True
        Else
            Me.IsReportingParentOverrideRow.Visible = False
        End If
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Try
            'Read in subscriber details
            Dim row As DataRow = Me.Subscriber.SubscriberRow
            Me.uPage.PopulatePageFieldsFromDataRow(Me.Subscriber.SubscriberRow)

            Select Case Me.uPage.db.IsDBNull(row("EntityType"), "")
                Case "Person"
                    Me.SubscriberName.Text = row("Title") & " " & row("FirstName") & " " & row("LastName")
            End Select

            If Me.Subscriber.GetAddressText("Email", "Main") Is Nothing Then
                Me.EmailMain.Text = "#### Currently No Main Email ####"
            Else
                Me.EmailMain.Text = Me.Subscriber.GetAddressText("Email", "Main").Replace(",", ", ")
            End If
            'Show billing address
            If Me.Subscriber.GetAddressText("Postal", "Billing") Is Nothing Then
                Me.BillingMain.Text = "#### Currently No Billing Address ####"
            Else
                Me.BillingMain.Text = Me.Subscriber.GetAddressText("Postal", "Billing", True).Replace(",", ", ")
                If Me.Subscriber.IsDefaultAddress("Postal", "Billing") Then
                    Me.BillingMain.CssClass = "fldViewPreferred"
                    Me.BillingMain.Text += " <span class=""fldViewPreferredRed""><< Default</span>"
                End If
            End If

            'Show mailing address
            If Me.Subscriber.GetAddressText("Postal", "Main") Is Nothing Then
                Me.PostalMain.Text = "#### Currently No Postal Address ####"
            Else
                Me.PostalMain.Text = Me.Subscriber.GetAddressText("Postal", "Main", True).Replace(",", ", ")
                If Me.Subscriber.IsDefaultAddress("Postal", "Main") Then
                    Me.PostalMain.CssClass = "fldViewPreferred"
                    Me.PostalMain.Text += " <span class=""fldViewPreferredRed""><< Default</span>"
                End If
            End If
            '20/8/22    Julian Gates    SIR5556 - Show primary country for subscriber 
            Me.PrimaryCountry.Text = uPage.db.IsDBNull(uPage.db.DLookup("CountryName", "Country", "CountryId= '" & row("PrimaryCountryId") & "'"), "")

            '13/1/22    james Woosnam   SIR5388 - Remove IsReceive Mail/EmailOpt Out column

            SubscriberAffiliateGridSetup()
            CompanyAccountsGridSetup()
            SentEmailsGridSetup()
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        PageSetup()
        uPage.PagePreRender()
    End Sub

    Protected Sub UpdateBtn_Click(sender As Object, e As EventArgs) Handles UpdateBtn.Click
        Response.Redirect("pg113SubscriberMaint.aspx?SubscriberId=" & Me.Subscriber.SubscriberId)
    End Sub

    Protected Sub AddAffiliateBtn_Click(sender As Object, e As EventArgs) Handles AddAffiliateBtn.Click
        Response.Redirect("pg131SubscriberAffiliateMaint.aspx?PageMode=Add&ParentSubscriberId=" & Me.Subscriber.SubscriberId)
    End Sub

    '16/08/22   Julian Gates    SIR5523 - Add AddAccountBtn to page
    Protected Sub AddAccountBtn_Click(sender As Object, e As EventArgs) Handles AddAccountBtn.Click
        Response.Redirect("pg162CompanyAccountMaint.aspx?SubscriberId=" & Me.Subscriber.SubscriberId)
    End Sub

    '16/08/22   Julian Gates    SIR5515 - Add AddAccountBtn to page.
    Protected Sub AddSalesOrderBtn_Click(sender As Object, e As EventArgs) Handles AddSalesOrderBtn.Click
        Response.Redirect("pg141OrderMaint1.aspx?SubscriberId=" & Me.Subscriber.SubscriberId)
    End Sub

    Sub OrdersAndSubscriptionsGridSetup()
        Try

            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT * FROM (SELECT SubscriberId FROM SalesOrder UNION SELECT SubscriberId FROM SalesOrderLine) o "
            Sql += " WHERE SubscriberId = " & Me.Subscriber.SubscriberId
            If uPage.db.GetDataTableFromSQL(Sql).Rows.Count = 0 Then
                Me.OrderTable.Visible = False
                Exit Sub
            End If
            Sql = "SELECT DISTINCT Orders.* FROM ( " & sCR
            Sql += " SELECT DISTINCT SalesOrder.OrderNumber " & sCR
            Sql += "		, ProductCode " & sCR
            Sql += "		, SalesOrder.OrderDate  " & sCR
            Sql += "		, SalesOrder.SalesOrderStatus  " & sCR
            Sql += "		, Subscriber.SubscriberName " & sCR
            Sql += "		, Subscriber.SubscriberId " & sCR
            Sql += "		, SalesOrderLine.DeliveryAddressId " & sCR
            Sql += "		,dbo.f530SubscriberAddressDisplay(SalesOrderLine.DeliveryAddressId,'SingleLine') + (SELECT ' (' + sa2.AddressDescription + '-' + CONVERT(VARCHAR,sa2.SubscriberAddressId) + ')' FROM SubscriberAddress sa2 WHERE sa2.SubscriberAddressId = SalesOrderLine.DeliveryAddressId) DeliveryAddress" & sCR
            Sql += "		,Despatches = dbo.fn120GetOrderDespatch(SalesOrderLine.SubscriberId,SalesOrder.OrderNumber,SalesOrderLine.ProductCode) " & sCR
            Sql += "        ,SalesOrderLine.RecurringSubscriptionEndDate" & sCR
            Sql += "        ,SalesOrder.AmountGross" & sCR
            Sql += " FROM SalesOrderLine " & sCR
            Sql += "		INNER JOIN SalesOrder " & sCR
            Sql += "			INNER JOIN " & uPage.SubscriberTable("Subscriber") & sCR
            Sql += "			ON Subscriber.SubscriberId = SalesOrder.SubscriberId " & sCR
            Sql += "			INNER JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId) & sCR
            Sql += "			ON Company.CompanyId = SalesOrder.CompanyId " & sCR
            Sql += "		ON SalesOrder.OrderNumber = SalesOrderLine.OrderNumber " & sCR
            Sql += " WHERE SalesOrderLine.SubscriberId = " & Me.txtSubscriberId.Value & sCR
            Sql += " UNION Select DISTINCT SalesOrder.OrderNumber " & sCR
            Sql += "		, PrimaryProductCode " & sCR
            Sql += "		, SalesOrder.OrderDate  " & sCR
            Sql += "		, SalesOrder.SalesOrderStatus  " & sCR
            Sql += "		, Subscriber.SubscriberName " & sCR
            Sql += "		, Subscriber.SubscriberId " & sCR
            Sql += "		, DeliveryAddressId = -1 " & sCR
            Sql += "		, DeliveryAddress = 'na' " & sCR
            Sql += "		, Despatches = '' " & sCR
            '14/11/23   James Woosnam   SIR5709 - Show end date where sub has no subscription
            Sql += "		, RecurringSubscriptionEndDate = ISNULL(SalesOrderLine.RecurringSubscriptionEndDate,(SELECT MAX(RecurringSubscriptionEndDate) FROM SalesOrderLine WHERE OrderNumber = SalesOrder.OrderNumber))" & sCR
            Sql += "        ,SalesOrder.AmountGross" & sCR
            Sql += " FROM SalesOrder " & sCR
            Sql += "			INNER JOIN " & uPage.SubscriberTable("Subscriber") & sCR
            Sql += "			ON Subscriber.SubscriberId = SalesOrder.SubscriberId " & sCR
            Sql += "			INNER JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId) & sCR
            Sql += "			ON Company.CompanyId = SalesOrder.CompanyId " & sCR
            Sql += "			LEFT JOIN SalesOrderLine" & sCR
            Sql += "			ON SalesOrderLine.OrderNumber = SalesOrder.OrderNumber " & sCR
            Sql += "			AND SalesOrderLine.SubscriberId = SalesOrder.SubscriberId " & sCR
            Sql += "			AND SalesOrderLine.ProductCode = SalesOrder.PrimaryProductCode " & sCR
            Sql += "	WHERE SalesOrder.SubscriberId = " & Me.txtSubscriberId.Value & sCR
            Sql += "	AND SalesOrderLine.OrderNumber IS NULL" & sCR
            Sql += " ) Orders " & sCR
            Sql += " WHERE 1=1 " & sCR
            If Not Me.ShowAllOrdersSubs.Checked Then
                Sql += "AND (RecurringSubscriptionEndDate>DATEADD(YEAR,-1,GETDATE()) OR OrderDate >DATEADD(YEAR,-2,GETDATE()))" & sCR
                Sql += "AND SalesOrderStatus NOT IN ('Cancelled','Rejected')" & sCR
            End If
            Sql += " ORDER BY Orders.OrderDate DESC"
            Me.OrdersAndSubscriptionsDatasource.SelectCommand = Sql
            Me.OrdersAndSubscriptionsDatasource.DataBind()
            Me.OrdersAndSubscriptionsGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Sub SubscriberAffiliateGridSetup()
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT DISTINCT Subscriber.SubscriberId as SubscriberId " & sCR
            Sql += "		, Subscriber.SubscriberName " & sCR
            Sql += "        , SubscriberAffiliate.SubscriberCategory " & sCR
            Sql += "		, SubscriberAffiliate.AffiliateReferenceID " & sCR
            Sql += "		, SecureSubscriber.SubscriberId SecureSubscriberId " & sCR
            Sql += " FROM Subscriber" & sCR
            Sql += "		INNER JOIN SubscriberAffiliate " & sCR
            Sql += "		On SubscriberAffiliate.ParentSubscriberId = Subscriber.SubscriberId " & sCR
            Sql += "		AND GetDate() Between SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate" & sCR
            Sql += "		LEFT JOIN " & uPage.SubscriberTable("SecureSubscriber") & sCR
            Sql += "		ON SecureSubscriber.SubscriberId = SubscriberAffiliate.ParentSubscriberId " & sCR
            Sql += "	WHERE SubscriberAffiliate.ChildSubscriberId = " & Me.txtSubscriberId.Value & sCR
            Sql += " Order By Subscriber.SubscriberName"

            Me.SubscriberAffiliateDatasource.SelectCommand = Sql
            Me.SubscriberAffiliateDatasource.DataBind()
            Me.SubscriberAffiliateGridView.DataBind()
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Sub CompanyAccountsGridSetup()
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT CompanyAccountId" & sCR
            Sql += "    ,AccountNumber " & sCR
            Sql += "	, CompanyAccountStatus " & sCR
            Sql += "    , AccountType " & sCR
            Sql += "    , CompanyAccount.CompanyId " & sCR
            Sql += "	, CompanyName " & sCR
            Sql += " FROM CompanyAccount" & sCR
            Sql += "		INNER JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId) & sCR
            Sql += "		On Company.CompanyId = CompanyAccount.CompanyId " & sCR
            Sql += "	WHERE CompanyAccount.SubscriberId = " & Me.txtSubscriberId.Value & sCR
            Sql += " ORDER BY CompanyName"
            If uPage.db.GetDataTableFromSQL(Sql).Rows.Count = 0 Then
                Me.AccountsTable.Visible = False
                Exit Sub
            End If
            Me.CompanyAccountsDatasource.SelectCommand = Sql
            Me.CompanyAccountsDatasource.DataBind()
            Me.CompanyAccountsGridView.DataBind()
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Function GetProposedChangesHtml() As String

        Dim strSQL As String = ""
        Dim html As String = ""

        strSQL = "Select Subscriber.SubscriberId " _
            & "		, Subscriber.LastUpdatedDateTime " _
            & "		, LastUpdatedByUserId  " _
            & " From Subscriber " _
            & "	Where UpdateToSubscriberId = " & Me.Subscriber.SubscriberId _
            & "	And SubscriberStatus = 'Proposed'" _
            & " Order By Subscriber.SubscriberId "
        Try
            Dim tblChanges As DataTable = uPage.db.GetDataTableFromSQL(strSQL)
            Dim row As DataRow = tblChanges.Rows(0)
            If tblChanges.Rows.Count <> 0 Then
                html += "<table width=""400"" border=""0"" cellpadding=""2"" class=""selectTableRed"">"
                html += "   <tr>"
                html += "       <td colspan=""6""><H3>Proposed Changes</H3></td>"
                html += "  </tr>"
                html += "  <tr>"
                html += "    <td class=""fldPrompt"">Id No</td>"
                html += "    <td class=""fldView"">"
                html += "       <a href ='../pages/pg111SubscriberDisplay.aspx" _
                                    & "?SubscriberId=" & row("SubscriberId") _
                                    & "&PageMode=Update" _
                                    & "' Title='View Subscriber'>"
                html += "           <span class=""fldView"">" & row("SubscriberId") & "</span>"
                html += "         </a>"
                html += "    </td>"
                html += "    <td class=""fldPrompt"">When</td>"
                html += "    <td class=""fldView"">" & row("LastUpdatedDateTime") & "</td>"
                html += "    <td class='fldPrompt'>Who</td>"
                html += "    <td class=""fldView"">" & row("LastUpdatedByUserId") & "</td>"
                html += "  </tr>"
                html += "</table>"
            Else
                html = ""
            End If

        Catch ex As Exception
            uPage.PageError = "An Unexpected error has occured." & ex.ToString
        End Try
        Return html
    End Function

    Function GetProposedNewOrChangedHtml() As String
        Dim html As String = ""
        Try
            Dim row As DataRow = Me.Subscriber.SubscriberRow
            If uPage.db.IsDBNull(row("SubscriberStatus"), "") = "Proposed" Then
                If uPage.db.IsDBNull(row("UpdateToSubscriberId"), 0) = 0 Then
                    html += "<table width=""400"" border=""0"" cellpadding=""2"" class=""selectTableRed"">"
                    html += "   <tr>"
                    html += "       <td class=""fldPrompt"">New Subscriber entered by " & uPage.db.IsDBNull(row("CreatedByUserId"), "") & "</td>"
                    html += "  </tr>"
                    html += " </table>"
                Else
                    html += "<table width=""400"" border=""0"" cellpadding=""2"" class=""selectTableRed"">"
                    html += "  <tr>"
                    html += "    <td class=""fldPrompt"">Updates to Subscriber " _
                                        & "<a href ='../pages/pg111SubscriberDisplay.aspx" _
                                        & "?SubscriberId=" & row("UpdateToSubscriberId") _
                                        & "&PageMode=Update" _
                                        & "' Title='View Subscriber'>"
                    html += "           <span class=""fldView"">" & row("UpdateToSubscriberId") & "</span>"
                    html += "         </a> by " & row("LastUpdatedByUserId")
                    html += "    </td>"
                    html += "  </tr>"
                    html += "</table>"
                End If
            Else
                html = ""
            End If

        Catch ex As Exception
            uPage.PageError = "An Unexpected error has occured." & ex.ToString
        End Try
        Return html
    End Function

    Sub BuildUserDetailsGridViewHTML()
        Dim strHtml As String = Nothing
        Dim sCR As String = System.Environment.NewLine
        Try
            For Each row As DataRow In Me.Subscriber.RemoteUserRows.Rows
                strHtml += "    <tr>"
                strHtml += "        <td><a href=""../pages/pg061UserMaint.aspx?" _
                                                & "UserId=" & row("UserId") _
                                                & "&PageMode=Update" _
                                                & """ Title='Maintain Remote User'>" & sCR
                strHtml += "                <span class=""fldLink"">" & row("UserName") & "</span>" & sCR
                strHtml += "              </a></td>" & sCR
                strHtml += "        <td Class=""fldView"">" & row("Userstatus") & "</td>"
                strHtml += "        <td Class=""fldView"">" & row("AuthorityLevel") & "</td>"
                strHtml += "        <td Class=""fldView"">" & uPage.db.IsDBNull(row("LastLoggedOn"), "Never") & "</td>"
                strHtml += "    </tr>"
            Next
            Me.UserDetailsGridView.Text = strHtml
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Sub SentEmailsGridSetup()
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT EmailDistributionLogId" & sCR
            Sql += "    ,EmailDistributionStatus" & sCR
            Sql += "    ,EmailName " & sCR
            Sql += "	,EmailSubject " & sCR
            Sql += "    ,EmailAddress " & sCR
            Sql += "    ,EmailSentDate " & sCR
            Sql += "	,EmailBody " & sCR
            Sql += " FROM EmailDistributionLog" & sCR
            Sql += " WHERE SubscriberId = " & Me.txtSubscriberId.Value & sCR
            Sql += " ORDER BY EmailSentDate Desc"
            If uPage.db.GetDataTableFromSQL(Sql).Rows.Count = 0 Then
                Me.SentEmailsTable.Visible = False
                Exit Sub
            End If
            Me.SentEmailsDatasource.SelectCommand = Sql
            Me.SentEmailsDatasource.DataBind()
            Me.SentEmailsGridView.DataBind()
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Public Function EmailBodyLink(EmailDistributionLogId As String) As String
        Return "<a href = ""javascript:void(0);"" onclick=""OnMoreInfoClick(this, '" & EmailDistributionLogId & "')"">View...</a>"
    End Function
    Protected Sub callbackPanel_Callback(ByVal source As Object, ByVal e As DevExpress.Web.CallbackEventArgsBase)
        Dim EmailDistributionLogId As Integer = Convert.ToInt32(e.Parameter)
        EmailBody.Text = uPage.db.IsDBNull(uPage.db.DLookup("EmailBody", "EmailDistributionLog", "EmailDistributionLogId=" & EmailDistributionLogId), "")
    End Sub
End Class
