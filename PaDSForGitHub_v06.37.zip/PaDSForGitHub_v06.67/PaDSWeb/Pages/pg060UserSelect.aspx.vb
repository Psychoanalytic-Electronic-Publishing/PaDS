﻿Imports System.Data.SqlClient
Imports System.Data
Partial Class Pages_pg060UserSelect
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    'Modification History
    '12/01/2016 Julian Gates    Initial version
    '25/1019    Julian Gates    SIR4763 - Add EmailAddress, UserStatus, LastLoggedOn, User Full Name and remove ValidUntil and add new filters.
    '19/1/20    James Woosnam   Add subscriber column and filter
    '15/02/21   Julian Gates    Add FltrAutoLogonDetails

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "User Search and List", "")
        Me.pageHeaderTitle.Text = "User Search and List"
        Select Case Me.uPage.UserSession.AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                'all fine
            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins
                Response.Redirect("pg100HomeAdmin.aspx?InfoMsg=User list not accessable.")
            Case Else
                Response.Redirect("pg070Logon.aspx")
        End Select
        If Not Page.IsPostBack Then
            If Request.QueryString("InfoMsg") <> "" Then
                Me.InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            uPage.PopulateDropDownListFromLookup(Me.FltrAuthorityLevel, "AuthorityLevel", uPage.PrimaryConnection, "--All--")
            Me.uPage.PopulateDropDownListFromSQL(Me.FltrUserStatus, "SELECT Distinct UserStatus Value, UserStatus Text From RemoteUser ORDER BY UserStatus", uPage.PrimaryConnection, "--All--")
            Me.FltrUserStatus.SelectedValue = "Active"
            txtRecordsToShow.Text = 20
            Me.txtPageNumber.Text = 1
            If Request.QueryString("EmailAddress") <> "" Then
                Me.FltrEmailAddress.Text = Request.QueryString("EmailAddress")
            End If
            BuildGrid()
        Else
            If Me.txtPrevRecordsToShow.Value <> Me.txtRecordsToShow.Text Then
                Me.txtPageNumber.Text = 1
                Me.txtPrevRecordsToShow.Value = Me.txtRecordsToShow.Text
            End If
            If Me.txtGotoPageNum.Value <> "" Then
                Me.txtPageNumber.Text = Me.txtGotoPageNum.Value
                Me.txtGotoPageNum.Value = ""
            End If
            BuildGrid()
        End If
    End Sub
    '25/1019    Julian Gates    SIR4763 - Add EmailAddress, UserStatus, LastLoggedOn and remove ValidUntil and add new filters.
    Private Sub BuildGrid()
        If Me.IsPageValidForStatus() Then
            Dim listSQL As String = Nothing
            Dim html As String = Nothing
            Dim PrevProductCombinationId As String = Nothing
            Try
                listSQL = "SELECT * FROM (SELECT ru.UserId" _
                        & " ,UserName = ru.UserName" _
                        & " ,ru.UserFullName" _
                        & " ,ru.EmailAddress" _
                        & " ,ru.AuthorityLevel" _
                        & " ,ru.UserStatus" _
                        & " ,ru.LastLoggedOn" _
                        & " ,s.SubscriberId" _
                        & " ,Subscriber = ISNULL(s.SubscriberName + ' (' + CAST(s.SubscriberId as varchar) + ')','')"
                If Me.FltrAutoLogonDetails.Text <> "" Then
                    listSQL += " ,rual.ReferrerURL" _
                        & " ,rual.FederatedEntity" _
                        & " ,rual.MinIPAddress" _
                        & " ,rual.MaxIPAddress" _
                        & " ,rual.RemoteUserAutoLogonId" _
                        & " ,rual.FederatedScope"
                End If
                listSQL += " FROM RemoteUser ru" _
                        & "      LEFT JOIN RemoteUserRights rur" _
                        & "         INNER JOIN Subscriber s" _
                        & "             LEFT JOIN Company c" _
                        & "             ON c.GroupParentSubscriberId = s.SubscriberId" _
                        & "         ON s.SubscriberId = rur.RightsToId" _
                        & "         AND c. CompanyId IS NULL" _
                        & "      ON rur.UserId = ru.UserId" _
                        & "      AND rur.RightsType = 'Subscriber'"
                If Me.FltrAutoLogonDetails.Text <> "" Then
                    listSQL += "    LEFT JOIN RemoteUserAutoLogon rual" _
                            & "     ON rual.UserId = ru.UserId"
                End If
                listSQL += " ) ru" _
                        & " WHERE 1=1"

                Dim ds As New DataSet
                Dim da As New SqlDataAdapter(listSQL, uPage.PrimaryConnection)
                'Populate Dataset
                da.Fill(ds, "RemoteUser")

                If Me.FltrUserId.Text <> "" Then
                    listSQL += " AND ru.UserId = " & Me.FltrUserId.Text
                End If

                If Me.FltrUserName.Text <> "" Then
                    listSQL += " AND ru.UserName LIKE '%" & Me.FltrUserName.Text.Replace("'", "''") & "%'"
                End If

                If Me.FltrUserFullName.Text <> "" Then
                    listSQL += " AND ru.UserFullName LIKE '%" & Me.FltrUserFullName.Text.Replace("'", "''") & "%'"
                End If

                If Me.FltrEmailAddress.Text <> "" Then
                    listSQL += " AND ru.EmailAddress LIKE '%" & Me.FltrEmailAddress.Text.Replace("'", "''") & "%'"
                End If

                If Me.FltrAuthorityLevel.SelectedValue <> "" Then
                    listSQL += " AND ru.AuthorityLevel = '" & Me.FltrAuthorityLevel.SelectedValue & "'"
                End If

                If Me.FltrUserStatus.SelectedValue <> "" Then
                    listSQL += " AND ru.UserStatus = '" & Me.FltrUserStatus.SelectedValue & "'"
                End If
                If Me.FltrSubscriber.Text <> "" Then
                    listSQL += " AND Subscriber Like '%" & Me.FltrSubscriber.Text & "%'"
                End If
                If Me.FltrAutoLogonDetails.Text <> "" Then
                    listSQL += " AND ( CAST(ru.MinIPAddress AS NVARCHAR(255)) Like '%" & Me.FltrAutoLogonDetails.Text & "%'"
                    listSQL += "   Or CAST(ru.MaxIPAddress AS NVARCHAR(255)) Like '%" & Me.FltrAutoLogonDetails.Text & "%'"
                    listSQL += "   Or CAST(ru.ReferrerURL AS NVARCHAR(255)) Like '%" & Me.FltrAutoLogonDetails.Text & "%'"
                    listSQL += "   Or CAST(ru.FederatedEntity AS NVARCHAR(255)) Like '%" & Me.FltrAutoLogonDetails.Text & "%'"
                    listSQL += "   )"
                End If
                listSQL += "ORDER BY ru.UserName "
                'SQLInjectionPart2ReviewRequired
                Dim listTable As DataTable = uPage.GetListDatatable(Me.txtPageNumber.Text, Me.txtRecordsToShow.Text, Me.lblPaging.Text, listSQL, uPage.PrimaryConnection)

                If listTable.Rows.Count <> 0 Then
                    For Each row As DataRow In listTable.Rows
                        html += "<tr>"
                        html += "<td>" _
                                & "<span class='lnkMaintNew'><a href='../pages/pg061UserMaint.aspx?PageMode=Update&UserId=" & row.Item("UserId") _
                                & "' Title='Update this record'><span class=hyperLinkButtonText>Update</Span></a></span>" _
                                & "</td>"
                        html += "<td><p class=fldView>" & row.Item("UserId") & "</p></td>"
                        html += "<td><p class=fldView>" & row.Item("UserName") & "</p></td>"
                        html += "<td><p class=fldView>" & row.Item("UserFullName") & "</p></td>"
                        html += "<td><p class=fldView>" & row.Item("EmailAddress") & "</p></td>"
                        html += "<td><p class=fldView>" & row.Item("AuthorityLevel") & "</p></td>"
                        html += "<td><p class=fldView>" & row.Item("UserStatus") & "</p></td>"
                        html += "<td><p class=fldView>" & row.Item("LastLoggedOn") & "</p></td>"
                        html += "<td><a href=""../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & row.Item("SubscriberId") & """>" & row.Item("Subscriber") & "</a></td>"
                        If Me.FltrAutoLogonDetails.Text <> "" Then
                            Dim autoLogonDetails As String = ""
                            If uPage.db.IsDBNull(row.Item("ReferrerURL"), "") <> "" Then
                                autoLogonDetails += "<b>Referrer URL:</b><br>" & row.Item("ReferrerURL")
                            End If
                            If uPage.db.IsDBNull(row.Item("FederatedEntity"), "") <> "" Then
                                autoLogonDetails += "<b>Federated Entity:</b><br>" & row.Item("FederatedEntity")
                                If uPage.db.IsDBNull(row.Item("FederatedScope"), "") <> "" Then
                                    autoLogonDetails += "<br><b>Federated Scope:</b><br>" & row.Item("FederatedScope")
                                End If
                            End If
                            If uPage.db.IsDBNull(row.Item("MinIPAddress"), "") <> "" And uPage.db.IsDBNull(row.Item("MaxIPAddress"), "") <> "" Then
                                autoLogonDetails += "<b>Min IP Address:</b> " & row.Item("MinIPAddress") & "<br><b>Max IP Address:</b> " & row.Item("MaxIPAddress")
                            End If
                            If autoLogonDetails <> "" Then
                                Me.AutoLogonDetailsTD.Visible = True
                                Me.AutoLogonDetailsFilterTD.Visible = True
                                html += "<td><p class=fldView>" & autoLogonDetails & "</p></td>"
                            End If
                        End If
                        html += "</tr>"
                    Next
                Else
                    uPage.PageError = "No records match your selection criteria"
                End If
            Catch e As Exception
                uPage.PageError = e.ToString
            End Try
            'Assign grid to Label
            lblGridView.Text = html
        End If
    End Sub

    Private Sub btnFilter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFilter.Click
        Me.txtPageNumber.Text = 1
        BuildGrid()
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub
    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        uPage.PagePreRender()
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        Select Case validatorStatus
            Case Else
                If Me.txtRecordsToShow.Text = "" Then
                    uPage.FieldErrorControl(Me.txtRecordsToShow, "Max Records To Show is mandatory")
                End If
                If Me.txtRecordsToShow.Text <> "" Then
                    If Not IsNumeric(Me.txtRecordsToShow.Text) Then
                        uPage.FieldErrorControl(Me.txtRecordsToShow, "Max Records To Show must be a numerical value")
                    End If
                End If
                If Me.FltrUserId.Text <> "" Then
                    If Not IsNumeric(Me.FltrUserId.Text) Then
                        uPage.FieldErrorControl(Me.FltrUserId, "User Id filter must be a numerical value")
                    End If
                End If
        End Select
        Return uPage.IsValid
    End Function
    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub AddNewBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddNewBtn.Click
        Response.Redirect("../pages/pg061UserMaint.aspx?PageMode=Add")
    End Sub

End Class

