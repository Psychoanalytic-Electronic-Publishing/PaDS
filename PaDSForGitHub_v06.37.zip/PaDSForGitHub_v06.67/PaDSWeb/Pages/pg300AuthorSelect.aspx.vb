﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web
Imports BusinessLogic
'Modification History
'31/08/2022    Julian Gates   Initial Version

Partial Class Pages_pg300AuthorSelect
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Author List", "")
        Me.pageHeaderTitle.Text = "Author List"

        If Page.IsPostBack Then

        Else
            Me.AuthorGridView.FilterExpression = "AuthorStatus = 'Active' and IsLiving=True"
            Me.AuthorGridView.SortBy(AuthorGridView.Columns("ReadsLast12Months"), DevExpress.Data.ColumnSortOrder.Descending)
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        GridSetup()

    End Sub

    Sub PageSetup()

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub GridSetup()
        Try
            Dim Sql As String = ""
            Sql = "SELECT Author.*"
            Sql += " ,ReadsLast12Months = (SELECT SUM(u.TotalHits  /CAST(da.NoOfAuthors  as MONEY)) FROM DocumentAuthor da	INNER JOIN UsageByMonthDocument u ON u.document_id = da.DocumentId WHERE da.AuthorId= Author.AuthorId)"
            Sql += " FROM Author"
            Sql += " WHERE 1=1"
            Sql += " ORDER BY AuthorNameAndInitials, AuthorStatus"
            Me.AuthorDatasource.SelectCommand = Sql

            'Populate dropdown fields
            CType(Me.AuthorGridView.Columns("AuthorStatus"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL("SELECT Lookup.LookupItemKey" _
                                                                                                                                                            & "    , Lookup.Name" _
                                                                                                                                                            & " FROM Lookup" _
                                                                                                                                                            & " WHERE LookupName = 'AuthorStatus'" _
                                                                                                                                                            & " AND LookupStatus = 'Active'" _
                                                                                                                                                            & " ORDER BY DisplayOrder,Name,LookupItemKey"
                                                                                                                                                            )
            'show filter row menu
            Me.AuthorGridView.Settings.ShowFilterRowMenu = True

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
End Class
