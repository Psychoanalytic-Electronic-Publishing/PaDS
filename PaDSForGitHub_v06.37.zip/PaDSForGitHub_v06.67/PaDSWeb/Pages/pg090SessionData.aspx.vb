﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'29/01/2021     Julian Gates    Initial Version
'17/09/2021     Julian Gates    SIR5309 - Various modifications

Partial Class Pages_pg090SessionData
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Enum PageModes
        SessionList
        DisplayAndList
        OnlySingleSession
        OnlyAllSession
    End Enum
    Dim PageMode As PageModes = PageModes.SessionList
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Session Data", "")
        Me.pageHeaderTitle.Text = "Session Data"
        If Request.QueryString("PageMode") = "OnlyAllSession" Then
            Me.PageMode = PageModes.OnlyAllSession
        End If
        If Page.IsPostBack Then
            If Me.txtCommandData.Value <> "" Then
                Dim sCommand As String = Me.txtCommandData.Value.Split("_")(0)
                Dim sSessionId As String = Me.txtCommandData.Value.Split("_")(1)
                Select Case sCommand
                    Case "Filter"
                        Me.PageMode = PageModes.DisplayAndList
                        Me.SingleSessionFilter.Text = sSessionId
                        RefreshSingleDisplay()
                    Case "PEP"
                        Response.Redirect(uPage.db.GetParameterValue("PEPWeb2021URL") & "?sessionId=" & sSessionId)
                    Case "Logout"
                        Try
                            Dim usrSess As New BusinessLogic.UserSession(uPage.db)
                            usrSess.Restore(sSessionId)
                            usrSess.Logout()

                        Catch ex As Exception
                            uPage.PageError = ex.Message
                        End Try
                End Select

                Me.txtCommandData.Value = ""
            Else
                RefreshSingleDisplay()
                If Me.PageMode = PageModes.OnlyAllSession Then AllSessionLogGridSetup()
            End If
            If Me.txtPrevRecordsToShow.Value <> Me.txtRecordsToShow.Text Then
                Me.txtPageNumber.Text = 1
                Me.txtPrevRecordsToShow.Value = Me.txtRecordsToShow.Text
            End If
            If Me.txtGotoPageNum.Value <> "" Then
                Me.txtPageNumber.Text = Me.txtGotoPageNum.Value
                Me.txtGotoPageNum.Value = ""
                BuildSessionsList()
            End If
        Else
            txtRecordsToShow.Text = 50
            Me.txtPageNumber.Text = 1
            Me.FltrFromLastAccessedDate.Text = Now.AddDays(-7).ToString("d-MMM-yy HH:mm:ss")
            Me.FltrToLastAccessedDate.Text = Now.AddDays(1).ToString("d-MMM-yy HH:mm:ss")
            If Request.QueryString("UserId") <> "" Then
                Me.FltrUserName.Text = Request.QueryString("UserId")
            End If
            If Request.QueryString("SelectedSessionId") <> "" Then
                Me.SingleSessionFilter.Text = Request.QueryString("SelectedSessionId")
                Me.PageMode = PageModes.OnlySingleSession
                HideList.Checked = True
            End If
            If Me.PageMode = PageModes.OnlyAllSession Then
                If Request.QueryString("FltrFromDate") <> "" Then
                    Me.FltrFromDate.Text = Request.QueryString("FltrFromDate")
                Else
                    Me.FltrFromDate.Text = Now.AddHours(-1).ToString("d-MMM-yy HH:mm:ss")
                End If

                If Request.QueryString("FltrToDate") <> "" Then
                    Me.FltrToDate.Text = Request.QueryString("FltrToDate")
                Else
                    Me.FltrToDate.Text = Now.ToString("d-MMM-yy HH:mm:ss")
                End If
            End If

            Select Case PageMode
                Case PageModes.SessionList
                    BuildSessionsList()
                Case PageModes.DisplayAndList
                    BuildSessionsList()
                    If Me.SingleSessionFilter.Text <> "" Then RefreshSingleDisplay()
                Case PageModes.OnlySingleSession
                    If Me.SingleSessionFilter.Text <> "" Then RefreshSingleDisplay()
                Case PageModes.OnlyAllSession
                    Me.pageHeaderTitle.Text = "All Session Data"
                    AllSessionLogGridSetup()
            End Select
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If
    End Sub
    Sub RefreshSingleDisplay()
        If Me.PageMode <> PageModes.OnlyAllSession Then
            If Me.SingleSessionFilter.Text <> "" Then
                Dim tSess As DataTable = uPage.db.GetDataTableFromSQL(GetSessionListSQL(Me.SingleSessionFilter.Text))
                If tSess.Rows.Count = 0 Then
                    uPage.FieldErrorControl(Me.SingleSessionFilter, "Session:" & Me.SingleSessionFilter.Text & " can't be found.")
                    Exit Sub
                End If

                Dim row As DataRow = tSess.Rows(0)

                'assign current select session values to PEP Log header fields
                Me.UserName.Text = uPage.db.IsDBNull(row.Item("UserDesc"), "")
                Me.UserNameLink.NavigateUrl = "../pages/pg061UserMaint.aspx?PageMode=Update&UserId=" & row.Item("UserId")
                Me.UserNameLink.Text = uPage.db.IsDBNull(row.Item("UserDesc"), "")
                Me.LoggedInMethod.Text = uPage.db.IsDBNull(row.Item("LoggedInMethod"), "")
                Me.StartDate.Text = uPage.db.IsDBNull(row.Item("StartDate"), "") & "&nbsp<a href='javascript:SubmitCommandData(""Logout_" & row("UserSessionId").ToString & """)'>Logout</a>"
                Me.LastAccessedDate.Text = uPage.db.IsDBNull(row.Item("LastAccessedDate"), "") & "&nbsp<a href='" & uPage.db.GetParameterValue("PEPWeb2021URL") & "?sessionId=" & row("UserSessionId").ToString & "' target='_blank'>PEP</a>"
                Me.SessionDataGridSetup(Me.SingleSessionFilter.Text)
                Me.PEPWebLogGridSetup(Me.SingleSessionFilter.Text)
                Me.SessionLogGridSetup(Me.SingleSessionFilter.Text)
                Me.OPASSessionLogGridSetup(Me.SingleSessionFilter.Text)
                Me.pageHeaderTitle.Text = "Session Data For Session: " & Me.SingleSessionFilter.Text
                BuildSessionsList()
            End If
        End If
    End Sub
    Sub PageSetup()

        SessionsListAndDisplayROW.Visible = True And Me.PageMode <> PageModes.OnlyAllSession
        SessionsListTD.Visible = Me.PageMode <> PageModes.OnlySingleSession And Not HideList.Checked And Me.PageMode <> PageModes.OnlyAllSession
        SessionDisplayTD.Visible = Me.PageMode <> PageModes.SessionList And Me.PageMode <> PageModes.OnlyAllSession
        UserNameTD.Visible = UserName.Text <> "" And Me.PageMode <> PageModes.OnlyAllSession
        LoggedInMethodTD.Visible = LoggedInMethod.Text <> "" And Me.PageMode <> PageModes.OnlyAllSession
        Me.StartDateTD.Visible = StartDate.Text <> "" And Me.PageMode <> PageModes.OnlyAllSession
        Me.LastAccessedDateTD.Visible = LastAccessedDate.Text <> "" And Me.PageMode <> PageModes.OnlyAllSession
        AllSessionsListROW.Visible = Me.PageMode = PageModes.OnlyAllSession
        If Page.IsPostBack Then
        Else
            Me.PEPWebLogGridView.FilterExpression = "ReasonForCheck <> 'AbstractView'"
            Me.AllSessionLogGridView.FilterExpression = "LoggedOn = 'Y'"
        End If
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub
    Function GetSessionListSQL(SingleSessionId As String) As String
        Dim ListSQL As String = ""
        Dim sCR As String = System.Environment.NewLine
        ListSQL = "SELECT top 1000 us.UserSessionId" & sCR
        ListSQL += " ,us.StartDate" & sCR
        ListSQL += " ,us.LastAccessedDate" & sCR
        ListSQL += " ,us.UserId" & sCR
        ListSQL += " ,UserDesc = us.UserName + '(' + CAST(us.UserId AS VARCHAR) + ') ' + ru.UserFullName + CASE WHEN ruAff.UserId IS NOT NULL THEN ' Via:' + ruAff.UserFullName + '(' + CAST(ruAff.UserId AS VARCHAR) + ')' ELSE '' END" & sCR
        ListSQL += " ,LoggedInMethod = (SELECT MAX(CAST(d.DataItemValue AS VARCHAR(100))) From UserSessionData d With (nolock) WHERE d.DataItemName = 'LoggedInMethod' AND d.UserSessionId=us.UserSessionId)" & sCR
        ListSQL += " FROM UserSession us With (nolock)" & sCR
        ListSQL += "    LEFT JOIN RemoteUser ru With (nolock)" & sCR
        ListSQL += "        LEFT JOIN RemoteUser ruAff With (nolock)" & sCR
        ListSQL += "        ON ruAff.UserId = ru.LastAutoLoginGroupUserId" & sCR
        ListSQL += "    ON ru.UserId = us.UserId" & sCR


        ListSQL += " WHERE 1=1 "
        If SingleSessionId <> "" Then ListSQL += " AND us.UserSessionId = '" & SingleSessionId & "'" & sCR 'SQLInjectionPart2ReviewRequired
        If SingleSessionId = "" Then
            If Me.ExcludeNotLoggedIn.Checked Then ListSQL += " AND us.UserId <> -1" & sCR
            If Me.ExcludeOldPEPWeb.Checked Then ListSQL += " AND NOT EXISTS(SELECT l.SessionId FROM SessionLog l WHERE l.SessionId = us.UserSessionId AND l.LogType = 'PEPProduct' )" & sCR
            If Me.PEPWebOnly.Checked Then ListSQL += " AND  EXISTS(SELECT l.UserSessionId FROM PEPWebUsageLog l WHERE l.UserSessionId = us.UserSessionId)" & sCR
            'SQLInjectionPart2ReviewRequired
            If IPAddress.Text <> "IPAddress" Then ListSQL += " AND us.UserSessionId IN (select l2.SessionId from sessionlog l2 where  l2.Comment like '%" & IPAddress.Text & "%' or l2.RemoteIPAddress = '" & IPAddress.Text & "')"

            If Me.FltrUserName.Text <> "" Then 'SQLInjectionPart2ReviewRequired
                ListSQL += " AND us.UserName + '(' + CAST(us.UserId AS VARCHAR) + ') ' + ru.UserFullName + CASE WHEN ruAff.UserId IS NOT NULL THEN ' Via:' + ruAff.UserFullName + '(' + CAST(ruAff.UserId AS VARCHAR) + ')' ELSE '' END LIKE '%" & Me.FltrUserName.Text.Replace("'", "''") & "%'"
            End If

            If Me.FltrFromLastAccessedDate.Text <> "" Then
                ListSQL += " AND us.LastAccessedDate >= " & uPage.db.vFQ(Me.FltrFromLastAccessedDate.Text, "D")
            End If
            If Me.FltrToLastAccessedDate.Text <> "" Then
                ListSQL += " AND us.LastAccessedDate <= " & uPage.db.vFQ(Me.FltrToLastAccessedDate.Text, "D")
            End If
            If Me.FltrLoggedInMethod.Text <> "" Then 'SQLInjectionPart2ReviewRequired
                ListSQL += " AND (SELECT MAX(CAST(d.DataItemValue AS VARCHAR(100))) From UserSessionData d With (nolock) WHERE d.DataItemName = 'LoggedInMethod' AND d.UserSessionId=us.UserSessionId) LIKE '%" & Me.FltrLoggedInMethod.Text.Replace("'", "''") & "%'"
            End If
        End If


        ListSQL += " ORDER BY us.LastAccessedDate Desc" & sCR

        Return ListSQL
    End Function
    Sub BuildSessionsList()
        Try
            Dim html As String = Nothing
            Try


                Dim listTable As DataTable = uPage.GetListDatatable(Me.txtPageNumber.Text, Me.txtRecordsToShow.Text, Me.lblPaging.Text, GetSessionListSQL(""), uPage.PrimaryConnection)
                Dim PEPWeb2021URL As String = uPage.db.GetParameterValue("PEPWeb2021URL")
                If listTable.Rows.Count <> 0 Then
                    For Each row As DataRow In listTable.Rows
                        If Me.SingleSessionFilter.Text = row("UserSessionId").ToString Then
                            html += "<tr class=""sessionListHighlightRow"">"

                        Else
                            html += "<tr>"
                        End If

                        html += "<td><a href='javascript:SubmitCommandData(""Filter_" & row("UserSessionId").ToString & """)'>" & SessionIdDisplay(row("UserSessionId")) & "</a>"
                        html += "</td>"
                        html += "<td Class=""fldView"">" & row.Item("StartDate")
                        html += "&nbsp<a href='javascript:SubmitCommandData(""Logout_" & row("UserSessionId").ToString & """)'>Logout</a>"
                        html += "</td>"
                        html += "<td Class=""fldView"">" & row.Item("LastAccessedDate")
                        html += "&nbsp<a href='" & PEPWeb2021URL & "?sessionId=" & row("UserSessionId").ToString & "' target='_blank'>PEP</a>"
                        html += "</td>"
                        html += "<td Class=""fldView""><a href='pg061UserMaint.aspx?UserId=" & row.Item("UserId") & "'>" & row.Item("UserDesc") & "</a></td>"
                        html += "<td class=""fldView"">" & row.Item("LoggedInMethod") & "</td>"
                    Next
                End If
            Catch e As Exception
                uPage.PageError = e.ToString
            End Try
            'Assign grid to Label
            lblSessionGrid.Text = html
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Public Function SessionIdDisplay(SessionId As Object) As String
        SessionId = SessionId.ToString
        Return Left(SessionId, 4) & "..." & Right(SessionId, 4)
    End Function
    Sub SessionDataGridSetup(ByVal UserSessionId As String)
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT usd.UserSessionId" & sCR
            Sql += " ,usd.DataItemName" & sCR
            Sql += " ,usd.DataItemValue" & sCR
            Sql += " FROM UserSessionData usd  with (nolock)" & sCR
            Sql += " WHERE UserSessionId = '" & UserSessionId & "'" & sCR 'SQLInjectionPart2ReviewRequired
            Sql += " ORDER By usd.DataItemName" & sCR

            Me.SessionDataDatasource.SelectCommand = Sql
            Me.SessionDataDatasource.DataBind()
            Me.SessionDataGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Sub PEPWebLogGridSetup(ByVal UserSessionId As String)
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT pwul.PEPWebUsageLogId" & sCR
            Sql += " ,pwul.DateTime" & sCR
            Sql += " ,pwul.ActionType" & sCR
            Sql += " ,pwul.LogonLocation" & sCR
            Sql += " ,pwul.LogonStatus" & sCR
            Sql += " ,Subscriber = ISNULL(s.Subscribername,'') + '(' + CAST(pwul.SubscriberId AS VARCHAR) + ')'" & sCR
            Sql += " ,pwul.SubscriberId" & sCR
            Sql += " ,pwul.OrderNumber" & sCR
            Sql += " ,pwul.AccessibleContentSets" & sCR
            Sql += " ,pwul.ReasonForCheck" & sCR
            Sql += " ,IPAddress = pwul.RemoteIPAddress + ISNULL('(' + (SELECT MAX(Notes) FROM RemoteUserAutoLogon WHERE MinIPAddress = pwul.RemoteIPAddress) + ')','')" & sCR
            Sql += " ,pwul.DocumentId" & sCR
            Sql += " ,Info = pwul.DocumentId + ' ' + ISNULL(d.documentRef,'') + ' ' + ISNULL(pwul.AdditionalDetails,'') " & sCR
            Sql += " FROM PEPWebUsageLog pwul with (nolock)" & sCR
            Sql += "    LEFT JOIN Subscriber s with (nolock)" & sCR
            Sql += "    ON s.SubscriberId = pwul.SubscriberId" & sCR
            Sql += "    LEFT JOIN contentdocuments d WITH (NOLOCK)" & sCR
            Sql += "        LEFT JOIN contentjournals j WITH (NOLOCK)" & sCR
            Sql += "        ON j.pepcode = d.pepcode" & sCR
            Sql += "    ON d.DocumentId = pwul.DocumentId collate database_default" & sCR
            Sql += " WHERE pwul.UserSessionId = '" & UserSessionId & "'" & sCR 'SQLInjectionPart2ReviewRequired
            Sql += " ORDER By pwul.DateTime desc" & sCR
            Sql += "    , pwul.PEPWebUsageLogId desc" & sCR

            Me.PEPWebLogDatasource.SelectCommand = Sql
            Me.PEPWebLogDatasource.DataBind()
            Me.PEPWebLogGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Sub SessionLogGridSetup(ByVal UserSessionId As String)
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT s.SessionLogId" & sCR
            Sql += " ,s.Date" & sCR
            Sql += " ,s.LogType" & sCR
            Sql += " ,Page = LEFT(LEFT(REPLACE(s.PageId,'/Pages/',''),5) + ' ' + s.PageTitle,30)" & sCR
            Sql += " ,s.PageTitle" & sCR
            Sql += " ,RemoteIPAddress = s.RemoteIPAddress  + ISNULL('(' + (SELECT MAX(Notes) FROM RemoteUserAutoLogon with (nolock) WHERE MinIPAddress = s.RemoteIPAddress) + ')','')" & sCR
            Sql += " ,s.Comment" & sCR
            Sql += " FROM SessionLog s with (nolock)" & sCR
            Sql += " WHERE s.SessionId = '" & UserSessionId & "'" & sCR 'SQLInjectionPart2ReviewRequired
            Sql += " ORDER By s.Date desc" & sCR
            Sql += "    , s.SessionLogId desc" & sCR

            Me.SessionLogDatasource.SelectCommand = Sql
            Me.SessionLogDatasource.DataBind()
            Me.SessionLogGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Sub OPASSessionLogGridSetup(ByVal UserSessionId As String)
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT s.PEPWebSessionLogId" & sCR
            Sql += " ,s.UserSessionId" & sCR
            Sql += " ,s.LastUpdate" & sCR
            Sql += " ,s.ItemOfInterest" & sCR
            Sql += " ,s.Endpoint" & sCR
            Sql += " ,s.Params" & sCR
            Sql += " ,s.ReturnAddedStatusMessage" & sCR
            Sql += " FROM PEPWebSessionLog s with (nolock)" & sCR
            Sql += " WHERE s.UserSessionId = '" & UserSessionId & "'" & sCR 'SQLInjectionPart2ReviewRequired
            Sql += " ORDER By s.LastUpdate DESC" & sCR
            Sql += "    , s.PEPWebSessionLogId DESC" & sCR

            Me.OPASSessionLogDatasource.SelectCommand = Sql
            Me.OPASSessionLogDatasource.DataBind()
            Me.OPASSessionLogGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Sub AllSessionLogGridSetup()
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT TOP 1000 s.SessionLogId" & sCR
            Sql += " ,Date = s.date" & sCR
            Sql += " ,PadsOrPEP = CASE WHEN s.LogType='PageLoad' THEN 'PaDS' ELSE 'PEP' END" & sCR
            Sql += " ,Module = s.PageId + '-' + s.PageTitle" & sCR
            Sql += " ,LoggedOn = CASE WHEN s.UserId = 0 THEN 'N' ELSE 'Y' END" & sCR
            Sql += " ,UserInfo = u.UserName + '(' + CAST(s.UserId AS VARCHAR) + ') ' + u.UserFullName + CASE WHEN ruAff.UserId IS NOT NULL THEN ' Via:' + ruAff.UserFullName + '(' + CAST(ruAff.UserId AS VARCHAR) + ')' ELSE '' END" & sCR
            Sql += " ,s.Comment" & sCR
            Sql += " ,s.RemoteIPAddress" & sCR
            Sql += " ,s.UserId" & sCR
            Sql += " ,UserSessionId = s.SessionId" & sCR
            Sql += " FROM SessionLog s  With (nolock)" & sCR
            Sql += "    LEFT JOIN RemoteUser u  With (nolock)" & sCR
            Sql += "        LEFT JOIN RemoteUser ruAff With (nolock)" & sCR
            Sql += "        ON ruAff.UserId = u.LastAutoLoginGroupUserId" & sCR
            Sql += "    ON u.UserId = s.UserId" & sCR
            Sql += " WHERE 1=1" & sCR
            If Me.FltrFromDate.Text <> "" Then
                Sql += " AND s.Date >= " & uPage.db.vFQ(Me.FltrFromDate.Text, "D")
            End If
            If Me.FltrToDate.Text <> "" Then
                Sql += " AND s.Date <= " & uPage.db.vFQ(Me.FltrToDate.Text, "D")
            End If
            Sql += " ORDER By s.Date desc" & sCR
            Sql += "    , s.SessionLogId desc" & sCR

            Me.AllSessionLogDatasource.SelectCommand = Sql
            Me.AllSessionLogDatasource.DataBind()
            Me.AllSessionLogGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Private Sub ClearBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearBtn.Click, ClearBtn1.Click
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub

    Private Sub FindSessionBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindSessionBtn.Click
        Try
            If Me.SingleSessionFilter.Text = "" Then
                uPage.FieldErrorControl(Me.SingleSessionFilter, "Session value is Mandatory")
            End If

            If uPage.IsValid Then
                Me.PageMode = PageModes.OnlySingleSession
                Me.HideList.Checked = True
                RefreshSingleDisplay()
            End If
        Catch ex As Exception
            Me.uPage.PageError = "An unexpected error has occured. Please contact support." & ex.ToString
        End Try

    End Sub
    Private Sub GoBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoBtn.Click
        Try

            If Me.uPage.IsValid Then
                BuildSessionsList()
            End If
        Catch ex As Exception
            Me.uPage.PageError = "An unexpected error has occured. Please contact support." & ex.ToString
        End Try
    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Sub PEPSessionLogJobBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PEPSessionLogJobBtn.Click
        Try
            'submit a job to get latest PEPSessionLog records,do as batch job so as not to conflict with regular job
            Dim bj As New BusinessLogic.BatchJob(uPage.db)
            bj.SubmittedByUserSessionId = uPage.UserSession.UserSessionIdGUID
            bj.CreateBatchJobEntry("GetPEPWebSessionLog", uPage.db)
        Catch ex As Exception
            Me.uPage.PageError = "Get latest PEPSessionLog records job failed." & ex.ToString
        End Try
    End Sub

    Private Sub HideList_CheckedChanged(sender As Object, e As EventArgs) Handles HideList.CheckedChanged
        If HideList.Checked Then
            PageMode = PageModes.OnlySingleSession
        Else
            PageMode = PageModes.DisplayAndList
            If Me.lblSessionGrid.Text = "" Then Me.BuildSessionsList()
        End If
    End Sub

    Private Sub ShowAllSessionList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShowAllSessionList.Click
        Response.Redirect("../pages/pg090SessionData.aspx?PageMode=OnlyAllSession")
    End Sub

    Private Sub AllSessionDateFilterBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AllSessionDateFilterBtn.Click
        Response.Redirect("../pages/pg090SessionData.aspx?FltrFromDate=" & Me.FltrFromDate.Text & "&FltrToDate=" & Me.FltrToDate.Text & "&PageMode=OnlyAllSession")
    End Sub

End Class
