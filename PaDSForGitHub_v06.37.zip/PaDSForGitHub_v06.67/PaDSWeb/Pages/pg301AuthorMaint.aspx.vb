﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.Subscriber
Imports DevExpress.Web

'Modification History
'05/09/22  Julian Gates   Initial New version
'07/01/25  Julian Gates   SIR5781 - Modify DLookup to stop SQL injection
Partial Class Pages_pg301AuthorMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Enum PageModes
        Add
        Update
    End Enum
    Property pageMode As PageModes
        Set(value As PageModes)
            ViewState("PageMode") = value
        End Set
        Get
            If ViewState("PageMode") Is Nothing Then ViewState("PageMode") = "Add"
            Return ViewState("PageMode")
        End Get
    End Property
    Private _Author As BusinessLogic.Author = Nothing
    Public Property Author() As BusinessLogic.Author
        Get
            If Me._Author Is Nothing Then
                Me._Author = New BusinessLogic.Author(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._Author
        End Get
        Set(ByVal value As BusinessLogic.Author)
            Me._Author = value
        End Set
    End Property
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Update Author ", "")
        Try
            If Page.IsPostBack Then
                Me.Author.MainDataset = CType(ViewState("MainDataSet"), DataSet)
            Else
                If Request.QueryString("AuthorId") <> "" Then
                    Try
                        Me.Author = New BusinessLogic.Author(Request.QueryString("AuthorId"), Me.uPage.db, Me.uPage.UserSession)
                    Catch ex As Exception
                        Me.uPage.PageError = "Invalid Parameter has been passed in"
                    End Try
                    Me.pageMode = PageModes.Update
                    Me.AuthorName.Focus()
                End If
                If Me.uPage.IsValid And PageMode = PageModes.Update Then
                    ReadRecord()
                End If
                Me.AuthorName.Focus()
            End If
        Catch ex As Exception
            uPage.PageError = "An unexpected error has occured.  Please contact support." & ex.ToString
        End Try

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If
    End Sub
    Sub PageSetup()
        Select Case Me.PageMode

            Case PageModes.Add

            Case PageModes.Update
                Me.InactiveBtnTd.Visible = Me.Author.AuthorRow("AuthorStatus") = "Active"
                Me.ActiveBtnTd.Visible = Me.Author.AuthorRow("AuthorStatus") = "Inactive"
                uPage.pageTitle = "Update Author " & Me.Author.AuthorName
        End Select
        Me.pageHeaderTitle.Text = uPage.pageTitle
    End Sub
    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Try

            Me.uPage.PopulatePageFieldsFromDataRow(Me.Author.AuthorRow)

            Dim sql As String = "SELECT Distinct AuthorId as Value" _
                                    & ", AuthorName As Text" _
                                    & " FROM Author" _
                                    & " WHERE AuthorId <> " & Me.AuthorId.Text _
                                    & " AND AuthorStatus = 'Active'" _
                                    & " ORDER BY AuthorName"
            Me.uPage.PopulateDevExpressDropDownListFromSQL(Me.AuthorSelection, sql, "<--Select-->")
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.Author.MainDataset
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Private Sub SaveBtn_Click(sender As Object, e As EventArgs) Handles SaveBtn.Click
        Try
            If Me.AuthorName.Text <> "" Then
                If Me.AuthorName.Text = Me.uPage.db.DLookup("AuthorName", "Author", "AuthorName=@AuthorName AND AuthorId <> '" & Me.AuthorId.Text & "'", "AuthorName", Me.AuthorName.Text, True) Then
                    uPage.FieldErrorControl(Me.AuthorName, "Entered Author Name already exists, please enter another.")
                End If
            Else
                uPage.FieldErrorControl(Me.AuthorName, "Author Name is mandatory")
            End If
            If uPage.IsValid Then
                Me.uPage.PopulateDataRowFromPageFields(Me.Author.AuthorRow)
                Me.Author.Save()
            End If

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
        If uPage.IsValid Then
            Me.InfoMsg.Text = "Author record saved."
        End If
    End Sub
    Protected Sub BackBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        Response.Redirect("../pages/pg300AuthorSelect.aspx")
    End Sub
    Protected Sub ClearBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ClearBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?AuthorId=" & Me.AuthorId.Text)
    End Sub
    Protected Sub InactiveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles InactiveBtn.Click
        Me.AuthorStatus.Text = Author.AuthorStates.Inactive.ToString
        Me.SaveBtn_Click(sender, e)
    End Sub
    Protected Sub ActiveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ActiveBtn.Click
        Me.AuthorStatus.Text = Author.AuthorStates.Active.ToString
        Me.SaveBtn_Click(sender, e)
    End Sub

    Protected Sub AuthorName_TextChanged(sender As Object, e As EventArgs) Handles AuthorName.TextChanged
        Try
            Dim nameParts As String() = Me.AuthorName.Text.Split(" ")
            Dim authorNameAndInitials As String = nameParts(nameParts.Count - 1)
            If nameParts.Count > 1 Then authorNameAndInitials += ", "
            For i As Integer = 0 To nameParts.Count - 1
                If i < nameParts.Count - 1 Then
                    authorNameAndInitials += Left(nameParts(i), 1) & "."
                End If
            Next
            Me.AuthorNameAndInitials.Text = authorNameAndInitials
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Protected Sub AddSynonymBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AddSynonymBtn.Click
        Try
            If Me.AuthorSelection.Text <> "<--Select-->" Then
                If Me.AuthorNameSynonyms.Text = "" Then
                    Me.AuthorNameSynonyms.Text = Me.AuthorSelection.SelectedItem.Text & ", "
                Else
                    Me.AuthorNameSynonyms.Text += Me.AuthorSelection.SelectedItem.Text & ", "
                End If
            End If

            Me.SaveBtn_Click(sender, e)

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

End Class
