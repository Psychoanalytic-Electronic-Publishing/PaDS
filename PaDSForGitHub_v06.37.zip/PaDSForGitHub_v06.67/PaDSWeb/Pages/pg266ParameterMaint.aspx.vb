Imports System.Data.SqlClient
Imports System.Data
Imports System.IO

'Modification History
'16/12/2021     Julian Gates   Initial Version
Partial Class pg266ParameterMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim pageMode As String
    Dim selectCommand As String
    Dim ds As New DataSet
    Dim dRow As DataRow
    Dim dTble As DataTable
    Dim cPageNumber As Long

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Parameter Maint", "")
        Me.pageHeaderTitle.Text = "Parameter Maint"

        Dim emailAddress As String = uPage.db.IsDBNull(uPage.db.DLookup("EmailAddress", "RemoteUser", "UserId=" & Me.uPage.UserSession.UserId), "")
        If emailAddress.ToUpper.Contains("ZEDRA") Then
            'all fine
        Else
            Response.Redirect("pg100HomeAdmin.aspx?InfoMsg=You are not authourised to update Parameters")
        End If

        pageMode = Request.QueryString("PageMode")
        If pageMode = "Update" Then
            Me.ParameterName.Text = Request.QueryString("ParameterName")
        End If
        If Request.QueryString("PageNumber") <> "" Then
            Me.cPageNumber = Request.QueryString("PageNumber")
        End If
        'uPage.FocusControl = Me.AffiliateReferenceId
        selectCommand = "Select *" _
           & " From stblParameters" _
           & " Where ParameterName = '" & Me.ParameterName.Text & "'" 'SQLInjectionPart2ReviewRequired

        If Page.IsPostBack Then
            ds = CType(ViewState("MainDataSet"), DataSet)
        Else
            ReadRecord()
            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
        End If
        PageSetup()
    End Sub

    Sub PageSetup()
        Select Case pageMode
            Case "Add"
                Me.ParameterName.Enabled = True
                Me.pageHeaderTitle.Text = "Add New Parameter"
            Case "Update"
                Me.ParameterName.Enabled = False
        End Select
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Dim commandText As String = Nothing
        Dim dr As SqlDataReader
        Dim field As DataSet
        Dim da As New SqlDataAdapter(selectCommand, uPage.PrimaryConnection)
        'Populate Dataset
        da.Fill(ds, "Parameters")
        'Read all data from dataset into page fields
        If pageMode = "Update" Then
            uPage.PopulatePageFieldsFromDataRow(ds.Tables("Parameters").Rows(0))
        End If
    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else
                If pageMode = "Add" Then
                    If Me.ParameterName.Text = "" Then
                        uPage.FieldErrorControl(Me.ParameterName, "Parameter Name is mandatory")
                    Else
                        If uPage.db.DLookup("ParameterName", "stblParameters", "ParameterName ='" & Me.ParameterName.Text & "'") <> "" Then
                            uPage.FieldErrorControl(Me.ParameterName, "Entered Parameter Name already exists, please choose another")
                        End If
                    End If
                End If
                If Me.ParameterValue.Text = "" Then
                    uPage.FieldErrorControl(Me.ParameterValue, "Parameter Value is mandatory")
                End If
        End Select
        Return uPage.IsValid
    End Function

    Sub SaveRecord()
        '******************************************************
        'Description:	Save the record either by updating or adding
        '******************************************************
        Dim intRowsAffected As Integer
        Dim cmdBld As System.Data.SqlClient.SqlCommandBuilder
        Dim da As New SqlDataAdapter(selectCommand, uPage.PrimaryConnection)

        dTble = ds.Tables("Parameters")
        If dTble.Rows.Count = 0 Then
            dRow = dTble.NewRow()
        Else
            dRow = dTble.Rows(0)
        End If
        'Read Values from page fields into dataset table
        uPage.PopulateDataRowFromPageFields(dRow)
        'Assign any default values or foreign key values if required
        If dTble.Rows.Count = 0 Then
            dTble.Rows.Add(dRow)
        End If
        'Add or Update data using command builder and transaction
        cmdBld = New System.Data.SqlClient.SqlCommandBuilder(da)
        da.InsertCommand = cmdBld.GetInsertCommand()
        da.UpdateCommand = cmdBld.GetUpdateCommand()
        da.DeleteCommand = cmdBld.GetDeleteCommand()
        If pageMode = "Add" Then
            ds.Tables("Parameters").Rows(0)("ParameterType") = "System"
            ds.Tables("Parameters").Rows(0)("UserID") = "All"
        End If
        Dim transaction As SqlTransaction
        transaction = uPage.PrimaryConnection.BeginTransaction
        Try
            da.InsertCommand.Transaction = transaction
            da.UpdateCommand.Transaction = transaction
            da.DeleteCommand.Transaction = transaction
            intRowsAffected = da.Update(ds, "Parameters")

            transaction.Commit()

            InfoMsg.Text = "Record Saved"

            Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=This record has been successfully saved&ParameterName=" & Me.ParameterName.Text)

        Catch e As Exception
            uPage.PageError = e.ToString
            transaction.Rollback()
        End Try
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = ds
        uPage.PagePreRender()
    End Sub
    Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        Try
            If IsPageValidForStatus() Then
                SaveRecord()
            End If
        Catch ex As Exception
            Me.uPage.PageError = "Save Parameter record failed " & ex.Message
        End Try
    End Sub
    Private Sub BackBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        Response.Redirect("../pages/pg265ParameterList.aspx")
    End Sub
End Class
