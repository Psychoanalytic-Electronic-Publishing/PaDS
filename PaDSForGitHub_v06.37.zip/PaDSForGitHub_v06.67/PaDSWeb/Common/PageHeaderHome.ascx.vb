'Modification History
'22/05/2015     Julian Gates    Initial Version
'04/02/2016     Julian Gates    SIR4070 - Add Update User link for CompanyAdmin users

Partial Class PageHeader
    Inherits System.Web.UI.UserControl
    Dim pg As Object
    Dim uPage As UserPage
    Public pageTitle, pageErrorMessage, pageInfoMessage, userName As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        pg = Me.Parent.NamingContainer.Page
        uPage = pg.uPage
        pageTitle = pg.uPage.pageTitle

        BuildHeader()
        Me.lblMenuBar.Text = uPage.OutputMenu(uPage.UserSession.LoggedIn)

        'Show Test version banner
        If Me.uPage.db.IsOnLiveServer = False Then
            Me.TestVersionBannerRow.Visible = True
        Else
            Me.TestVersionBannerRow.Visible = False
        End If
    End Sub
    Sub BuildHeader()
        Dim strHtml As String = ""
        strHtml = strHtml & "<table cellSpacing='0' cellPadding='0' width='750' border='0'>"
        strHtml += "   <tr>"
        'Show read only message if On secondary server
        If uPage.UserSession.Data("IsReadOnlyOnSecondary") Then
            strHtml += "    <td width='150'> " & Chr(13)
            strHtml += "      <span class='hmTitle1'>(Read Only)</span>" & Chr(13)
            strHtml += "    </td> " & Chr(13)
        End If
        strHtml += "    <td width=''300''>" & Chr(13)
        strHtml += "        <img src='../images/IJPSTAMPgrey4Logo.png' alt='IJPA Logo'></img>" & Chr(13)
        strHtml += "    </td>" & Chr(13)
        strHtml += "    <td align='center'> " & Chr(13)
        strHtml += "        <span Class=hmTitle1>PaDS</span>" & Chr(13)
        strHtml += "        <br />"
        strHtml += "         <span Class=hmTitle2>Psychoanalysts Database System</span>"
        strHtml += "    </td> " & Chr(13)
        strHtml += "    <td align='right' width='150'> " & Chr(13)
        strHtml += "     <span class=fldView>" & Chr(13)
        strHtml += "       User: " & uPage.UserSession.UserName
        strHtml += "       <a Href='../Pages/pg070Logon.aspx?Action=Logout'>Logout</a>" & Chr(13)
        strHtml += "     </span>" & Chr(13)
        strHtml += "    </td>" & Chr(13)
        '04/02/2016     Julian Gates    SIR4070 - Add Update User link for CompanyAdmin users
        Select Case Me.uPage.UserSession.AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins
                strHtml += "    <td align='left'>&nbsp;" & Chr(13)
                strHtml += "     <span class=fldView>" & Chr(13)
                strHtml += "       <a href ='../Pages/pg061UserMaint.aspx?PageMode=Update&UserId=" & uPage.UserSession.UserId & "' title=""Update your password"">Update</a>" & Chr(13)
                strHtml += "     </span>" & Chr(13)
                strHtml += "    </td>" & Chr(13)
        End Select
        strHtml += "   </tr>"
        strHtml += "</table>"
        Me.lblHeader.Text = strHtml
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        pageErrorMessage = uPage.PageError
        pageInfoMessage = uPage.InfoMessage
    End Sub
End Class
