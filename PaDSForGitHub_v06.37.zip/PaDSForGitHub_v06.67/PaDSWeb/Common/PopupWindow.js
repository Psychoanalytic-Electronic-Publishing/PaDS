<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
//Modification History
//03/04/2006 JGates Reworked to allow toolbars and menus to be controlled
//17/01/2007 JGates Add SetReturnCommand function
//10/4/08	James Woosnam	Increase the height of fixed window
var newwindow = null;
function popupWindow(url)
//{
	{
    nameW='feature'
	if (navigator.appVersion.indexOf('4') != -1) {
		xTop = 0;
		yTop = 0;
		height=screen.height-480
		width=screen.width -420
		newwindow = window.open(url, nameW, 'height='+height+',width='+width+',scrollbars=1,resizable=0,menubar=0,toolbar=0,status=1,location=0,directories=0,left=' + xTop + ',top=' + yTop + '');
		//newwindow.moveTo(400,400);
		} 
		else 
		{
			newwindow = window.open(url, nameW, 'height='+height+',width='+width+',scrollbars=1,resizable=0,menubar=0,toolbar=0,status=1,location=0,directories=0,left=' + xTop + ',top=' + yTop + '');
			newwindow.moveTo(400,400);
		}
		
	}
	
function popupWindowFixedSize(url)
//{
	{
    nameW='feature'
	if (navigator.appVersion.indexOf('4') != -1) {
		xTop = 200;
		yTop = 5;
		height= 750;
		width= 800;
		newwindow = window.open(url, nameW, 'height='+height+',width='+width+',scrollbars=1,resizable=0,menubar=0,toolbar=0,status=0,location=0,directories=0,left=' + xTop + ',top=' + yTop + '');
		//newwindow.moveTo(400,400);
		} 
		else 
		{
			newwindow = window.open(url, nameW, 'height='+height+',width='+width+',scrollbars=1,resizable=0,menubar=0,toolbar=0,status=0,location=0,directories=0,left=' + xTop + ',top=' + yTop + '');
			//newwindow.moveTo(400,400);
		}
		
	}
function SetReturnCommand(ReturnFormName,Command)
{
	eval('var theform = document.' + ReturnFormName + ';');
	newwindow.close();
	theform.item('txtCommandData').value = Command
	theform.submit()	
	
}	

function CloseWindow()
	{
		self.close;
	}	

function SetReturn(ReturnFormName,Command)
{
	eval('var theform = document.' + ReturnFormName + ';');
	theform.item('txtCommandData').value = Command
	theform.submit()
}	
	//newwindow = window.open(url,'name','height=450,width=750');
//}

//-->
</SCRIPT>