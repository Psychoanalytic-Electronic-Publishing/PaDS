﻿Namespace System.Management
    Friend Class ManagementPath
        Public Property NamespacePath As String
        Public Property Server As String
    End Class
End Namespace
