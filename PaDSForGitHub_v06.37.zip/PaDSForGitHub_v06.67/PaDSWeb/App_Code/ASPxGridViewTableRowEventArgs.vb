﻿Namespace DevExpress.Web
    Friend Class ASPxGridViewTableRowEventArgs
    End Class
End Namespace
