﻿Imports System.Data.SqlClient
Imports System.Data
Imports BusinessLogic.ReportPEPUsage
'Modification History
'24/09/21  Julian Gates   Initial version

Partial Class Pages_pg466PEPUsageReport
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim _tblGroups As DataTable = Nothing
    Dim Rep As BusinessLogic.ReportPEPUsage = Nothing
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "PEP Usage Report", "")
        Me.pageHeaderTitle.Text = "PEP Usage Report"

        Rep = New BusinessLogic.ReportPEPUsage(Me.UsageBeginDate.Date, Me.UsageEndDate.Date, Me.ReportType.SelectedValue, uPage.db, uPage.UserSession.UserSessionIdGUID)

        If Page.IsPostBack Then

        Else
            ReadRecord()
            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            'Default date field values
            Dim sDate As Date = CDate("01-" & Now.AddMonths(-25).ToString("MMM-yyyy"))
            Me.UsageBeginDate.Text = IIf(sDate < CDate("01/09/2021"), CDate("01/09/2021"), sDate)
            Me.UsageEndDate.Text = DateTime.Today.AddDays(1)

            If Request.QueryString("ReportType") <> "" And Request.QueryString("AffiliateRateSubscriberId") <> "" Then
                Me.ReportType.SelectedValue = PEPUsageReportTypes.PEPUsageSingleAffiliateDetail
                Rep.PEPUsageReportType = PEPUsageReportTypes.PEPUsageSingleAffiliateDetail
                Me.AffiliateSubscriberId.SelectedValue = Request.QueryString("AffiliateRateSubscriberId")
            End If
        End If
    End Sub

    Sub PageSetup()
        SelectAffiliateSubscriberRow.Visible = Rep.PEPUsageReportType = PEPUsageReportTypes.PEPUsageSingleAffiliateDetail
        AffiliateSummaryTable.Visible = Rep.PEPUsageReportType = PEPUsageReportTypes.PEPUsageDetailByAffiliate
        AffiliateSummaryHeader.Visible = Rep.PEPUsageReportType = PEPUsageReportTypes.PEPUsageDetailByAffiliate

        Select Case Rep.PEPUsageReportType
            Case PEPUsageReportTypes.PEPUsageDetailByAffiliate

                BuildAffiliateSummaryGridHTML(uPage.db.GetDataTableFromSQL(New BusinessLogic.ReportPEPUsage(Me.UsageBeginDate.Date, Me.UsageEndDate.Date, PEPUsageReportTypes.PEPUsageSummaryByAffiliate, uPage.db, uPage.UserSession.UserSessionIdGUID).SQL))
            Case PEPUsageReportTypes.PEPUsageSingleAffiliateDetail
                Me.AffiliateSubscriberId.Focus()
        End Select
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************



        'Populate all dropdown fields
        Dim dropDownIntialValue As String = "<---------Select--------->"
        uPage.PopulateDropDownListFromSQL(Me.AffiliateSubscriberId, "SELECT DISTINCT Value = AffiliateRateSubscriberId" _
                                                             & "    ,Text = AffiliateRateSubscriberName" _
                                                             & " FROM PEPUsage " _
                                                             & " ORDER BY AffiliateRateSubscriberName" _
                                                             , uPage.PrimaryConnection, dropDownIntialValue
                                                             )

    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        PageSetup()
        uPage.PagePreRender()
    End Sub


    Private Sub SubmitBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubmitBtn.Click
        Try
            Dim SubId As Integer = 0
            Select Case Rep.PEPUsageReportType
                Case BusinessLogic.ReportPEPUsage.PEPUsageReportTypes.PEPUsageSingleAffiliateDetail
                    uPage.DropDownValidateMandatory(Me.AffiliateSubscriberId)
                    SubId = Me.AffiliateSubscriberId.SelectedValue
            End Select
            If Me.uPage.IsValid Then
                Rep.Submit(SubId)
                ViewState("BatchJobId") = Rep.BatchJob.BatchJobId
            End If

        Catch ex As Exception
            uPage.PageError = "There was an unexpected problem generating this report.  Please contact support." & ex.ToString
        End Try

        If uPage.IsValid Then
            UpdateTimer_Tick(sender, e)
        End If
    End Sub
    Private Sub ClearBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub

    Sub BuildAffiliateSummaryGridHTML(ByVal tbl As DataTable)
        Dim rowcount As Integer = Nothing
        Try
            For Each row As DataRow In tbl.Rows
                If rowcount > 50 Then
                    Exit For
                End If
                Dim tr As New HtmlTableRow
                Dim td As New HtmlTableCell
                Dim hLink As New HyperLink
                hLink.NavigateUrl = Request.ServerVariables("Path_Info") & "?ReportType=SingleAffiliateDetail&AffiliateRateSubscriberId=" & row("AffiliateRateSubscriberId")
                hLink.Text = row("AffiliateRateSubscriberName")
                hLink.ToolTip = "Open report for " & row("AffiliateRateSubscriberName")
                td.Controls.Add(hLink)
                tr.Cells.Add(td)
                td = New HtmlTableCell
                If Not uPage.db.IsDBNull(row("UserActivitySessionCount")) Then
                    td.InnerHtml = CType(row("UserActivitySessionCount"), Decimal).ToString("#,##0")
                    td.Align = "Right"
                End If
                tr.Cells.Add(td)
                td = New HtmlTableCell
                If Not uPage.db.IsDBNull(row("AbstractCount")) Then
                    td.InnerHtml = CType(row("AbstractCount"), Decimal).ToString("#,##0")
                    td.Align = "Right"
                End If
                tr.Cells.Add(td)
                td = New HtmlTableCell
                If Not uPage.db.IsDBNull(row("ReadCount")) Then
                    td.InnerHtml = CType(row("ReadCount"), Decimal).ToString("#,##0")
                    td.Align = "Right"
                End If
                tr.Cells.Add(td)
                td = New HtmlTableCell
                If Not uPage.db.IsDBNull(row("SearchCount")) Then
                    td.InnerHtml = CType(row("SearchCount"), Decimal).ToString("#,##0")
                    td.Align = "Right"
                End If
                tr.Cells.Add(td)
                td = New HtmlTableCell
                If Not uPage.db.IsDBNull(row("RecordCount")) Then
                    td.InnerHtml = CType(row("RecordCount"), Decimal).ToString("#,##0")
                    td.Align = "Right"
                End If
                tr.Cells.Add(td)

                Me.AffiliateSummaryTable.Rows.Add(tr)
                rowcount += 1
            Next

        Catch ex As Exception
            uPage.PageError = "There was an unexpected problem generating Affiliate Summary Grid." & ex.ToString
        End Try
    End Sub

    Private Sub SubmitPopulatePEPUsageBtn_Click(sender As Object, e As EventArgs) Handles SubmitPopulatePEPUsageBtn.Click
        Try
            Rep.SubmitPopulatePEPUsage()
            ViewState("BatchJobId") = Rep.BatchJob.BatchJobId

        Catch ex As Exception
            uPage.PageError = "SubmitPopulatePEPUsageBtn_Click failed:" & ex.Message
        End Try
        If uPage.IsValid Then
            UpdateTimer_Tick(sender, e)
        End If
    End Sub
    Protected Sub UpdateTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateTimer.Tick
        Try
            If IsNumeric(ViewState("BatchJobId")) Then
                Me.TimedPanel.Visible = True
                Dim BatchLog As New BusinessLogic.BatchLog(uPage.db)
                Me.BatchLogLines.Text = BatchLog.GetBatchLogLinesHTML(ViewState("BatchJobId"))
                Select Case uPage.db.IsDBNull(uPage.db.DLookup("MAX(BatchLogStatus)", "BatchLog", "BatchJobId=" & ViewState("BatchJobId")), "")
                    Case "Failed"
                        Me.UpdateTimer.Enabled = False
                    Case "Complete"
                        Me.UpdateTimer.Enabled = False
                        '      Response.Redirect("pg483SubscriberImportFileLoad.aspx?SubscriberImportBatchId=" & Me.SubscriberImportBatchId.Text )
                    Case Else
                        Me.UpdateTimer.Enabled = True
                End Select
            Else
                Me.UpdateTimer.Enabled = False
                Me.TimedPanel.Visible = False
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub
End Class
