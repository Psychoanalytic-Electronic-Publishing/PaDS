﻿Imports System.Data.SqlClient
Imports System.Data
Imports BusinessLogic.SubscriberImportBatch
'Modification History
'20/08/20   Julian Gates    SIR5099 - Add Audit link
'1/3/22     James Woosnam   SIR5425 - Allow for no product in order.

Partial Class Pages_pg483SubscriberImportFileLoad
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim dr As SqlDataReader
    Enum PageModes
        Add
        Display
    End Enum

    Property pageMode As PageModes
        Set(value As PageModes)
            ViewState("PageMode") = value

        End Set
        Get
            If ViewState("PageMode") Is Nothing Then ViewState("PageMode") = "Add"
            Return ViewState("PageMode")
        End Get
    End Property
    Dim commandText As String

    Private _SubscriberImportBatch As BusinessLogic.SubscriberImportBatch = Nothing
    Public Property SubscriberImportBatch() As BusinessLogic.SubscriberImportBatch
        Get
            If Me._SubscriberImportBatch Is Nothing Then
                Me._SubscriberImportBatch = New BusinessLogic.SubscriberImportBatch(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._SubscriberImportBatch
        End Get
        Set(ByVal value As BusinessLogic.SubscriberImportBatch)
            Me._SubscriberImportBatch = value
        End Set
    End Property

    'Modification History
    '09/02/2016  Julian Gates   Initial Version
    '07/02/20   Julian Gates    SIR5008 - Batch Details Text modifications

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Subscriber Name - Renewal Control", "")

        If Not Page.IsPostBack Then

            If Request.QueryString("SubscriberImportBatchId") <> "" Then
                Me.pageMode = PageModes.Display
                Try
                    ViewState("SubscriberImportBatchId") = Request.QueryString("SubscriberImportBatchId")
                    Me.SubscriberImportBatch = New BusinessLogic.SubscriberImportBatch(CInt(Request.QueryString("SubscriberImportBatchId")), Me.uPage.db, Me.uPage.UserSession)
                Catch ex As Exception
                    Me.uPage.PageError = "Invalid Parameter has been passed in"
                End Try
            Else

                Me.pageMode = PageModes.Add

            End If
            If Me.uPage.IsValid Then
                ReadRecord()
            End If
        Else
            Me.SubscriberImportBatch.MainDataset = CType(ViewState("MainDataSet"), DataSet)
            If Left(Me.txtCommandData.Value, "FileUpload".Length) = "FileUpload" Then
                Me.UploadFile(Me.txtCommandData.Value.Substring(10, 1))
            End If
        End If

    End Sub

    Sub UploadFile(FileType As SubscriberImportBatchFileTypes)
        Dim ftu As FileUpload = Me.FileStoreTable.FindControl("FileToUpload" & FileType)
        If ftu.HasFile Then
            Select Case FileType
                Case SubscriberImportBatchFileTypes.BeforeImport
                    Dim FileStore As New BusinessLogic.FileStore(uPage.db)
                    FileStore.AddNewFile(ftu.FileBytes, ftu.FileName, "To be imported into PaDS")
                    SubscriberImportBatch.ValidateFile(FileStore)
                    If SubscriberImportBatch.ErrorMessages <> "" Then
                        uPage.FieldErrorControl(ftu, "This file has errors please correct")
                    Else
                        Me.SubscriberImportBatch.SubscriberImportBatchRow("BeforeImportFileStoreId") = FileStore.FileStoreId
                        Me.SubscriberImportBatch.UpdateStatus(SubscriberImportBatchStates.Importing, Nothing, Nothing)
                    End If
                Case Else
                    If FileType = SubscriberImportBatchFileTypes.Renewal And Me.SubscriberImportBatch.SubscriberImportBatchStatus = SubscriberImportBatchStates.Initial Then
                        Me.SubscriberImportBatch.UpdateStatus(SubscriberImportBatchStates.Available, ftu.FileBytes, ftu.FileName)
                    Else
                        Me.SubscriberImportBatch.AddFile(FileType, ftu.FileBytes, ftu.FileName)
                    End If
            End Select


            Me.uPage.PopulatePageFieldsFromDataRow(Me.SubscriberImportBatch.SubscriberImportBatchRow)

        Else
            uPage.PageError = "No file selected.  Please Browse and select a file."

        End If
        Me.txtCommandData.Value = ""
    End Sub

    Sub PageSetup()
        Me.AddTable.Visible = Me.pageMode = PageModes.Add
        Me.MainDisplayTable.Visible = Me.pageMode = PageModes.Display
        Me.AssociatedproductWarningLbl.Visible = False

        Select Case Me.pageMode
            Case PageModes.Add
                Me.CompanyId.Enabled = Me.CompanyId.Items.Count > 1
                Me.pageHeaderTitle.Text = "Add New Renewel Control"
                Me.ErrorsTableRow.Visible = False
                Me.WarningTableRow.Visible = False
            Case PageModes.Display
                '17/12/12   JamesWoosnam    SIR4979/1 - Add Batch Id to title
                uPage.pageTitle = "Import Batch:" & Me.SubscriberImportBatch.SubscriberImportBatchId & " - " & Me.SubscriberImportBatch.SubscriberImportBatchRow("SubscriberImportBatchName")
                Me.pageHeaderTitle.Text = "Batch:" & Me.SubscriberImportBatch.SubscriberImportBatchId & " - " & Me.SubscriberImportBatch.SubscriberImportBatchRow("SubscriberImportBatchName")
                Me.OrderNumberRow.Visible = True
                Me.AddOrderTable.Visible = uPage.db.IsDBNull(Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber"))
                If Me.CurrencyProductCode.SelectedValue <> "" Then
                    Dim prodCode As String = Me.CurrencyProductCode.SelectedValue.Substring(3, Me.CurrencyProductCode.SelectedValue.Length - 3)
                    Me.SubscriptionStartDateForAddRow.Visible = CBool(uPage.db.DLookup("ISNULL(RecurringSubscriptionFlag,0)", "Product", "ProductCode='" & prodCode & "'"))
                Else
                    Me.SubscriptionStartDateForAddRow.Visible = False
                End If
                ' Me.OrderSelectionDropdown.Visible = Me.OrderSelectionDropdown.Items.Count > 1
                If Not uPage.db.IsDBNull(Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber")) Then
                    Me.OrderNumberLink.Text = Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber")
                    Me.OrderNumberLink.NavigateUrl = "pg142OrderMaint2.aspx?PageMode=Update&OrderNumber=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber")
                    'Set OrderSelectionDropdown value
                    BuildOrderSelectionDropdown()
                    Me.OrderSelectionDropdown.SelectedValue = Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber")
                    '1/3/22     James Woosnam   SIR5425 - Allow for no product in order.
                    Dim PrimaryProductCode As String = uPage.db.IsDBNull(uPage.db.DLookup("PrimaryProductCode", "SalesOrder", "OrderNumber=" & Me.OrderNumberLink.Text), Nothing)
                    If PrimaryProductCode IsNot Nothing Then
                        Dim OrderProduct As New BusinessLogic.Product(PrimaryProductCode, uPage.db, uPage.UserSession)
                        If Not OrderProduct.HasValidAssociatedProductRates Then
                            Me.AssociatedproductWarningLbl.Text = "Missing associated product rates.  These must be added before you can import."
                            Me.AssociatedproductWarningLbl.Visible = True
                        End If

                    End If
                End If
                '   Dim hideSomeUploads As Boolean = Me.SubscriberImportBatch.SubscriberImportBatchStatus= 
                '07/02/20   Julian Gates    SIR5008 - Batch Details Text modifications
                PopulateFileTableRow("Original Renewal File", SubscriberImportBatchFileTypes.Renewal, Me.SubscriberImportBatch.SubscriberImportBatchStatus < SubscriberImportBatchStates.Importing)
                PopulateFileTableRow("File Uploaded by Sub Admin", SubscriberImportBatchFileTypes.Uploaded, False)

                PopulateFileTableRow("File to Import into PaDS", SubscriberImportBatchFileTypes.BeforeImport, Me.SubscriberImportBatch.SubscriberImportBatchStatus < SubscriberImportBatchStates.Imported)
                PopulateFileTableRow("Results of Import", SubscriberImportBatchFileTypes.AfterImport, False)
                PopulateFileTableRow("Sub Admin Confirmation File", SubscriberImportBatchFileTypes.Confirmation, Me.SubscriberImportBatch.SubscriberImportBatchStatus >= SubscriberImportBatchStates.Imported)

                BuildSubscriberImportBatchLogGridHTML()
                BuildMessageListList(Me.SubscriberImportBatch.ErrorMessages, MessageTypes.ErrorMessage)
                BuildMessageListList(Me.SubscriberImportBatch.WarningMessages, MessageTypes.WarningMessage)
                Me.SubscriberImportBatchStatusText.Text = Me.SubscriberImportBatch.SubscriberImportBatchRow("SubscriberImportBatchStatus")

                '20/08/20   Julian Gates    SIR5099 - Add Audit link
                Me.AuditLink.NavigateUrl = "../pages/pg040AuditLogDisplay.aspx?FltrUpdatedRecordFamily=SubscriberImportBatch&FltrUpdatedRecordFamilyKey=" & Me.SubscriberImportBatch.SubscriberImportBatchId
                Me.AuditLink.Text = "View Audit"
                Me.AuditLink.ToolTip = "View Audit for this record"
        End Select

    End Sub
    Sub PopulateFileTableRow(FileDescription As String, FileType As SubscriberImportBatchFileTypes, ShowUpload As Boolean)
        Dim fs As BusinessLogic.FileStore = Nothing
        If Not uPage.db.IsDBNull(Me.SubscriberImportBatch.SubscriberImportBatchRow(FileType.ToString & "FileStoreId")) Then
            fs = New BusinessLogic.FileStore(Me.SubscriberImportBatch.SubscriberImportBatchRow(FileType.ToString & "FileStoreId"), uPage.db)
        End If
        Dim td As TableCell = Nothing
        td = Me.FileStoreTable.FindControl("FileDescriptionCell" & FileType)
        td.Text = FileDescription

        Dim hl As HyperLink = Me.FileStoreTable.FindControl("FileDownloadLink" & FileType)
        hl.Visible = False
        If fs IsNot Nothing Then
            hl.NavigateUrl = "pg100HomeAdmin.aspx?FileStoreId=" & fs.FileStoreId
            hl.Visible = True
        End If
        Dim ftu As FileUpload = Me.FileStoreTable.FindControl("FileToUpload" & FileType)
        ftu.Visible = ShowUpload
    End Sub
    ReadOnly Property SubscriberName As String
        Get
            If Me.SubscriberImportBatch.SubscriberImportBatch.Rows.Count > 0 Then
                Return uPage.db.IsDBNull(Me.uPage.db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("BlockSubscriberId")), "")

            End If
            Return ""
        End Get
    End Property
    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Select Case Me.pageMode
            Case PageModes.Add
                Dim sql As String = ""
                sql = "SELECT Value=c.CompanyId"
                sql += " ,Text=c.CompanyName"
                sql += " FROM " & uPage.CompanyTable("c", uPage.UserSession.UserId)
                sql += " ORDER By CompanyName"
                uPage.PopulateDropDownListFromSQL(Me.CompanyId, sql, uPage.db.DBConnection)
                BuildSubscriberDropDown()
            Case PageModes.Display
                Me.SubscriberNameLink.Text = SubscriberName
                Me.SubscriberNameLink.NavigateUrl = "pg111SubscriberDisplay.aspx?SubscriberId=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("BlockSubscriberId")

                Me.CompanyName.Text = uPage.db.IsDBNull(Me.uPage.db.DLookup("CompanyName", "Company", "CompanyId=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("CompanyId")), "")

                Dim xx As List(Of SubscriberImportBatchStates) = [Enum].GetValues(GetType(SubscriberImportBatchStates)).Cast(Of SubscriberImportBatchStates).ToList
                Me.SubscriberImportBatchStatus.DataSource = xx
                Me.SubscriberImportBatchStatus.DataBind()
                BuildOrderSelectionDropdown()
                If Not uPage.db.IsDBNull(Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber")) Then
                    Me.OrderSelectionDropdown.SelectedValue = Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber")
                End If
                Dim sql As String = ""
                sql = "SELECT DISTINCT Value=pr.CurrencyCode + p.ProductCode"
                sql += " ,Text=pr.CurrencyCode + ' ' + p.ProductCode + '-' + p.ProductShortName"
                sql += "        + CASE WHEN assp.ProductCode IS NULL THEN '' ELSE ' with associated:' + assp.ProductCode END"
                sql += " FROM Product p"
                sql += "		INNER JOIN ProductRate pr"
                sql += "		ON pr.ProductCode = p.ProductCode"
                sql += "		LEFT JOIN Product assP"
                sql += "		ON assP.ProductCode = p.AssociatedProductCode"
                sql += " WHERE p.ProductStatus='Current'"
                sql += " AND p.ParentProductCode IS NULL"
                sql += " AND NOT EXISTS(SELECT p2.* from product p2 where p2.associatedProductCode = p.ProductCode)"
                sql += " AND p.CompanyId =" & Me.SubscriberImportBatch.SubscriberImportBatchRow("CompanyId")
                sql += " ORDER By 2"
                uPage.PopulateDropDownListFromSQL(Me.CurrencyProductCode, sql, uPage.db.DBConnection, "", "")

                Me.uPage.PopulatePageFieldsFromDataRow(Me.SubscriberImportBatch.SubscriberImportBatchRow)
                Me.SubscriberImportBatchStatusText.Text = Me.SubscriberImportBatch.SubscriberImportBatchRow("SubscriberImportBatchStatus")
        End Select

    End Sub
    Sub BuildSubscriberDropDown()
        Dim sql As String = ""
        sql = "SELECT DISTINCT Value= s.subscriberId"
        sql += " ,Text= s.SubscriberName + ' (' + CAST(s.SubscriberId as VARCHAR) + ')'"
        sql += " ,s.SubscriberName"
        sql += " FROM " & uPage.SubscriberTable("s")
        sql += "    INNER JOIN SubscriberAffiliate sa"
        sql += "    ON sa.ChildSubscriberId = s.SubscriberId"
        sql += "    AND sa.ParentSubscriberId = (SELECT GroupParentSubscriberId FROM Company WHERE CompanyId=" & Me.CompanyId.SelectedValue & ")"
        sql += " WHERE s.SubscriberStatus='Current'"
        sql += " AND s.EntityType='Organisation'"
        sql += " ORDER By s.SubscriberName"
        uPage.PopulateDropDownListFromSQL(Me.SubscriberId, sql, uPage.db.DBConnection, "", "")
    End Sub
    Sub PopulateSubscriberImportBatchNameForAdd()
        If Me.SubscriberId.SelectedValue <> Nothing Then
            Me.SubscriberImportBatchNameForAdd.Text = Me.SubscriberImportBatch.GetSubscriberImportBatchNameForAdd(Me.CompanyId.SelectedValue, Me.SubscriberId.SelectedValue, uPage.db.DLookup("CompanyShortName", "Company", "CompanyId=" & Me.CompanyId.SelectedValue) & " import " & Now.ToString("MMM-yyyy"))
        End If
    End Sub
    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else

        End Select
        Return uPage.IsValid
    End Function

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        ViewState("MainDataSet") = Me.SubscriberImportBatch.MainDataset
        PageSetup()
        uPage.PagePreRender()
    End Sub

    Private Sub BackBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackBtn.Click, Back2Btn.Click
        Response.Redirect("../pages/pg482SubscriberInProgressImportsSelect.aspx")
    End Sub
    Private Sub ImportBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportBtn.Click
        '  uPage.DropDownValidateMandatory(Me.OrderSelectionDropdown)
        If uPage.db.IsDBNull(Me.SubscriberImportBatch.SubscriberImportBatchRow("BeforeImportFileStoreId")) Then
            uPage.PageError = "There must be an uploaded 'File to import into PaDS' before you can import"
        End If
        If Me.SubscriberImportBatch.SubscriberImportBatchStatus > SubscriberImportBatchStates.Importing Then
            uPage.PageError = "The file can't be imported once it is:" & Me.SubscriberImportBatch.SubscriberImportBatchStatus.ToString
        End If
        If Me.AssociatedproductWarningLbl.Visible Then
            uPage.PageError = "There are missing associated product rates.  These must be added, in product maint, on before you can import."
        End If
        If uPage.IsValid Then
            Response.Redirect("../pages/pg480SubscriberImport.aspx?SubscriberImportBatchId=" & SubscriberImportBatch.SubscriberImportBatchRow("SubscriberImportBatchId") _
                                                                               & "&SubscriberId=" & SubscriberImportBatch.SubscriberImportBatchRow("BlockSubscriberId") _
                                                                               & "&CompanyId=" & SubscriberImportBatch.SubscriberImportBatchRow("CompanyId") _
                                                                               & "&OrderNumber=" & SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber")
                                                                               )

        End If

    End Sub

    Sub BuildSubscriberImportBatchLogGridHTML()
        '******************************************************
        'Description:	Builds and Displays User Rights Grid
        '******************************************************
        Dim strHtml As String = Nothing
        Dim vw As New DataView(Me.SubscriberImportBatch.SubscriberImportBatchLog, "", "LogDateTime DESC", DataViewRowState.CurrentRows)
        For Each row As DataRowView In vw
            strHtml += "<tr>"
            strHtml += "<td class=""fldView"">" & row.Item("LogDateTime") & "</td>"
            strHtml += "<td class=""fldView"">" & row.Item("UserName") & "</td>"
            strHtml += "<td class=""fldView"">" & row.Item("Description") & "&nbsp;"
            If Not uPage.db.IsDBNull(row("FileStoreId")) Then
                strHtml += "<a href=""pg100HomeAdmin.aspx?FileStoreId=" & row("FileStoreId") & """>Get File</a>"
            End If
            strHtml += "</td>"
            strHtml += "</tr>"
        Next
        'Assign grid to Label
        Me.SubscriberImportBatchLogGridView.Text = strHtml
    End Sub

    Private Sub CompanyId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CompanyId.SelectedIndexChanged
        BuildSubscriberDropDown()
        PopulateSubscriberImportBatchNameForAdd()
    End Sub
    Private Sub SubscriberId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles SubscriberId.SelectedIndexChanged
        PopulateSubscriberImportBatchNameForAdd()
    End Sub

    Private Sub AddBtn_Click(sender As Object, e As EventArgs) Handles AddBtn.Click
        Try
            uPage.DropDownValidateMandatory(SubscriberId)
            uPage.FieldValidateMandatory(Me.SubscriberImportBatchNameForAdd)
            If uPage.IsValid Then
                Me.SubscriberImportBatch.AddNew(Me.SubscriberId.SelectedValue, Me.CompanyId.SelectedValue, Me.SubscriberImportBatchNameForAdd.Text)
                Me.pageMode = PageModes.Display
                Me.ReadRecord()
            End If
        Catch ex As Exception
            uPage.PageError = "Add failed:" & ex.Message

        End Try
    End Sub

    Private Sub SubscriberImportBatchStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles SubscriberImportBatchStatus.SelectedIndexChanged
        Try
            Me.SubscriberImportBatch.SubscriberImportBatchStatus = [Enum].Parse(GetType(SubscriberImportBatchStates), Me.SubscriberImportBatchStatus.SelectedItem.Text)
            Me.SubscriberImportBatch.Save()
        Catch ex As Exception
            uPage.PageError = "Add failed:" & ex.Message

        End Try
    End Sub

    Sub BuildMessageListList(ByRef Messages As String, MessageType As MessageTypes)
        Try
            Dim tb As Table = Nothing
            Dim tr As TableRow = Nothing
            Dim style As String = ""
            Select Case MessageType
                Case MessageTypes.ErrorMessage
                    tb = Me.FileErrorList
                    style = "errMsgNoMargin"
                    tr = Me.ErrorsTableRow
                Case MessageTypes.WarningMessage
                    tb = Me.FileWarningList
                    style = "WaringMsgNoMargin"
                    tr = Me.WarningTableRow
            End Select
            If Messages <> Nothing Then
                Dim tRow As New TableRow()
                Dim tCell As New TableCell()
                Dim lines As String() = Messages.Split(vbCrLf)
                Dim linesToShow As Integer

                tCell.Text = "<span class='" & style & "'>"
                linesToShow = lines.Length - 1
                Dim i As Integer = 0
                Do While i < linesToShow
                    tCell.Text += " - " & lines(i) & "<br>"
                    i += 1
                Loop

                tCell.Text += "</span>"

                tRow.Cells.Add(tCell)
                tb.Rows.Add(tRow)
                tr.Visible = True
            Else
                tr.Visible = False
            End If

        Catch ex As Exception
            uPage.PageError = "An Unexpected error has occured.  Please contact support " & ex.ToString
        End Try
    End Sub

    Private Sub AddOrderBtn_Click(sender As Object, e As EventArgs) Handles AddOrderBtn.Click
        Try
            uPage.DropDownValidateMandatory(Me.CurrencyProductCode)
            If Me.SubscriptionStartDateForAddRow.Visible Then uPage.FieldValidateDate(Me.SubscriptionStartDateForAdd, True)
            If uPage.IsValid Then
                uPage.db.BeginTran()
                Try
                    Dim so As New BusinessLogic.SalesOrder(uPage.db, uPage.UserSession)
                    so.Add(Me.CurrencyProductCode.SelectedValue.Substring(3, Me.CurrencyProductCode.SelectedValue.Length - 3),
                            Me.SubscriberImportBatch.SubscriberImportBatchRow("BlockSubscriberId"),
                            "Block",
                             "Partial",
                            Me.CurrencyProductCode.SelectedValue.Substring(0, 3),
                            IIf(Me.SubscriptionStartDateForAddRow.Visible, Me.SubscriptionStartDateForAdd.Text, Nothing))
                    Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber") = so.OrderNumber
                    Me.SubscriberImportBatch.Save()
                    uPage.db.CommitTran()
                Catch ex As Exception
                    uPage.db.RollbackTran()
                    Throw ex
                End Try

                Me.uPage.PopulatePageFieldsFromDataRow(Me.SubscriberImportBatch.SubscriberImportBatchRow)

            End If
        Catch ex As Exception
            uPage.PageError = "Add failed:" & ex.Message

        End Try
    End Sub

    Private Sub SubscriberImportBatchName_TextChanged(sender As Object, e As EventArgs) Handles SubscriberImportBatchName.TextChanged
        Try
            uPage.FieldValidateMandatory(Me.SubscriberImportBatchName)
            If uPage.IsValid Then
                Me.SubscriberImportBatch.SubscriberImportBatchRow("SubscriberImportBatchName") = Me.SubscriberImportBatchName.Text
                Me.SubscriberImportBatch.Save()
            End If
        Catch ex As Exception
            uPage.PageError = "Add failed:" & ex.Message

        End Try
    End Sub

    Private Sub OrderSelectionDropdown_SelectedIndexChanged(sender As Object, e As EventArgs) Handles OrderSelectionDropdown.SelectedIndexChanged
        Try
            If Me.OrderSelectionDropdown.SelectedValue = "" Then
                Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber") = System.DBNull.Value
            Else
                Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber") = Me.OrderSelectionDropdown.SelectedValue
            End If
            Me.SubscriberImportBatch.Save()
        Catch ex As Exception
            uPage.PageError = "Add failed:" & ex.Message
        End Try
    End Sub

    Private Sub BuildOrderSelectionDropdown()
        uPage.PopulateDropDownListFromSQL(Me.OrderSelectionDropdown, "SELECT OrderNumber as Value" _
                                                                     & "    ,CAST(OrderNumber as VARCHAR) + ' - ' +  ISNULL(PrimaryProductCode,'[None]') as Text" _
                                                                     & " FROM SalesOrder " _
                                                                     & " Where SubscriberId=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("BlockSubscriberId") _
                                                                     & " AND CompanyId=" & Me.SubscriberImportBatch.SubscriberImportBatchRow("CompanyId") _
                                                                     & " AND (SalesOrderStatus = 'Partial' or OrderNumber=" & uPage.db.IsDBNull(Me.SubscriberImportBatch.SubscriberImportBatchRow("OrderNumber"), 0) & ")" _
                                                                     , uPage.PrimaryConnection, "<---------Select--------->")
    End Sub
End Class

