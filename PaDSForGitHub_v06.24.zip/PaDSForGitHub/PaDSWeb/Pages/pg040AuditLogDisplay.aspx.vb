﻿Imports System.Data
Imports System.Data.SqlClient
'Modification History
'19/08/20  Julian Gates   Initial New version

Partial Class Pages_pg040AuditLogDisplay
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Public PageHtml As String = ""
    Public ListTableHtml As String = ""

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Audit Log List", "")

        If Page.IsPostBack Then

        Else
            Me.FltrFromDate.Focus()
            Me.RecordsToShow.Text = "100"
            If Request.QueryString("FltrUpdatedRecordFamily") <> "" Then
                Me.FltrUpdatedRecordFamily.Text = Request.QueryString("FltrUpdatedRecordFamily")
            End If
            If Request.QueryString("FltrUpdatedRecordFamilyKey") <> "" Then
                Me.FltrUpdatedRecordFamilyKey.Text = Request.QueryString("FltrUpdatedRecordFamilyKey")
            End If
        End If
        If Me.IsPageValidForStatus("") Then
            ListTableHtml = GetListTable()
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else

        End Select
        Me.uPage.FieldValidateNumber(Me.RecordsToShow)
        Me.uPage.FieldValidateDate(Me.FltrFromDate, False)
        Me.uPage.FieldValidateDate(Me.FltrToDate, False)
        Return Me.uPage.IsValid
    End Function

    Public Function GetListTable() As String
        Dim listSQL As String = ""
        Dim html As String = ""

        If Me.ViewState("PageNumber") = Nothing Then
            Me.ViewState("PageNumber") = 1
        End If

        If Me.txtGotoPageNum.Value <> "" Then
            Me.ViewState("PageNumber") = Me.txtGotoPageNum.Value
        End If

        Try
            listSQL = "EXEC sp041AuditLogDisplay "
            If Me.FltrFromDate.Text <> "" Then
                listSQL += "@FltrFromDate=" & uPage.db.vFQ(Me.FltrFromDate.Text, "D")
            Else
                listSQL += "@FltrFromDate=''"
            End If
            If Me.FltrToDate.Text <> "" Then
                listSQL += ",@FltrToDate=" & uPage.db.vFQ(Me.FltrToDate.Text, "D")
            Else
                listSQL += ",@FltrToDate=''"
            End If
            listSQL += ",@FltrTableName='" & Me.FltrTableName.Text & "'" _
                        & ",@FltrUpdatedByUserId='" & Me.FltrUpdatedByUserId.Text & "'" _
                        & ",@FltrUpdatedRecordFamily='" & Me.FltrUpdatedRecordFamily.Text & "'" _
                        & ",@FltrUpdatedRecordFamilyKey='" & Me.FltrUpdatedRecordFamilyKey.Text & "'" _
                        & ",@FltrUpdatedRecordKey='" & Me.FltrUpdatedRecordKey.Text & "'" _
                        & ",@FltrModificationType='" & Me.FltrModificationType.Text & "'" _
                        & ",@RecordsRequired=" & Me.RecordsToShow.Text * 5
            'Me.uPage.PageError = listSQL
            Dim tbl As DataTable = uPage.GetListDatatable(ViewState("PageNumber"), Me.RecordsToShow.Text, PageHtml _
                                                        , listSQL _
                                                        , uPage.PrimaryConnection, True)
            If tbl.Rows.Count > 0 Then
                For Each row As DataRow In tbl.Rows
                    html += "<tr>"
                    html += "   <td class='fldView'>" & row("AuditDate") & "</td>"
                    html += "   <td class='fldView'>" & row("TableName") & "</td>"
                    html += "   <td class='fldView'>" & Mid(uPage.db.IsDBNull(row("UpdatedByUserId"), ""), uPage.db.IsDBNull(row("UpdatedByUserId"), "").IndexOf("\") + 2) & "</td>"
                    html += "   <td class='fldView'>" & row("UpdatedRecordFamily") & "</td>"
                    html += "   <td class='fldView'>" & row("UpdatedRecordFamilyKey") & "</td>"
                    html += "   <td class='fldView'>" & row("UpdatedRecordKey") & "</td>"
                    html += "   <td class='fldView'>" & row("ModificationType") & "</td>"

                    '******* Beginging of new table ******
                    Dim shNew As String = ""
                    'shNew += "   <td class='smallRow'></td>"
                    shNew += "   <td class='auditLogSmallRow'>"
                    shNew += "<table class='auditLogDetailsTable' border='0' cellpadding='0' cellspacing='0'>"
                    shNew += "<tr>"
                    shNew += "<th>"
                    shNew += "Column"
                    shNew += "</th>"
                    Dim astrBeforeData As String() = Nothing
                    Dim astrAfterData As String() = Nothing
                    Dim lngBeforeFieldCount As Integer = 0
                    Dim lngAfterFieldCount As Integer = 0
                    Dim i As Integer = 0
                    If Not row("BeforeDescription") Is System.DBNull.Value Then
                        astrBeforeData = Split(row("BeforeDescription"), "|")
                        lngBeforeFieldCount = UBound(astrBeforeData)
                    Else
                        lngBeforeFieldCount = 0
                    End If
                    If Not row("AfterDescription") Is System.DBNull.Value Then
                        astrAfterData = Split(row("AfterDescription"), "|")
                        lngAfterFieldCount = UBound(astrAfterData)
                    Else
                        lngAfterFieldCount = 0
                    End If
                    Dim ColumnNames As String() = CStr(row("ColumnNames")).Split(",")
                    For i = 0 To ColumnNames.Length - 1
                        '   col.DataType()
                        If (i <= lngBeforeFieldCount _
                            Or CStr(row("ModificationType")).ToUpper = "INSERT") _
                          And (i <= lngAfterFieldCount _
                            Or CStr(row("ModificationType")).ToUpper = "DELETE") Then
                            If row("BeforeDescription") Is System.DBNull.Value _
                              Or row("AfterDescription") Is System.DBNull.Value Then
                                shNew += "<td class='colHeader'>"
                                shNew = shNew & ColumnNames(i)
                                shNew += "</td>"
                            Else
                                If astrAfterData(i) <> astrBeforeData(i) Then
                                    shNew += "<td class='colHeader'>"
                                    shNew = shNew & ColumnNames(i)
                                    shNew += "</td>"
                                End If
                            End If
                        End If
                    Next
                    shNew += "</TR>"

                    If Not row("BeforeDescription") Is System.DBNull.Value Then
                        shNew += "<tr>"
                        shNew += "<th>"
                        shNew += "Before"
                        shNew += "</th>"
                        For i = 0 To UBound(astrBeforeData)
                            If row("BeforeDescription") Is System.DBNull.Value Then
                                shNew += "<td class='beforeRowTD'>"
                                shNew = shNew & astrBeforeData(i)
                                shNew += "</td>"
                            Else
                                Dim outputBeforeData As Boolean
                                outputBeforeData = False
                                If CStr(row("ModificationType")).ToUpper = "DELETE" Then
                                    outputBeforeData = True
                                Else
                                    If UBound(astrAfterData) < i Then
                                        outputBeforeData = True
                                    Else
                                        If astrAfterData(i) <> astrBeforeData(i) Then
                                            outputBeforeData = True
                                        End If
                                    End If
                                End If
                                If outputBeforeData Then
                                    shNew += "<td class='beforeRowTD'>"
                                    shNew = shNew & astrBeforeData(i)
                                    shNew += "</td>"
                                End If
                            End If
                        Next
                        shNew += "</tr>"
                    End If
                    If Not row("AfterDescription") Is System.DBNull.Value Then
                        shNew += "<tr>"
                        shNew += "<th>"
                        shNew += "After"
                        shNew += "</th>"
                        For i = 0 To UBound(astrAfterData)
                            If row("BeforeDescription") Is System.DBNull.Value Then
                                shNew += "<td class='afterRowTD'>"
                                shNew = shNew & astrAfterData(i)
                                shNew += "</td>"
                            Else
                                '15/11/07  Julian Gates Add new code to test if arrays have the same amount of items to fix audit button error. SIR 1379
                                Dim outputAfterData As Boolean
                                outputAfterData = False
                                If UBound(astrBeforeData) < i Then
                                    outputAfterData = True
                                Else
                                    If astrAfterData(i) <> astrBeforeData(i) Then
                                        outputAfterData = True
                                    End If
                                End If
                                If outputAfterData Then
                                    shNew += "<td class='afterRowTD'>"
                                    shNew = shNew & astrAfterData(i)
                                    shNew += "</td>"
                                End If
                            End If
                        Next
                        shNew += "</tr>"
                    End If
                    shNew += "<tr>"
                    shNew += "</table>"
                    html += shNew
                    '******* End of new table ******

                    html += "   </td>"
                    html += "</tr>"
                Next
            Else
                Me.uPage.PageError = "No records found for selected criteria"
            End If
        Catch ex As Exception
            Me.uPage.PageError = ex.Message
        End Try
        Return html
    End Function

    Protected Sub ClearBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ClearBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub

    Protected Sub FilterBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles FilterBtn.Click
        Me.txtGotoPageNum.Value = 1
        GetListTable()
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        uPage.PagePreRender()
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub
End Class

