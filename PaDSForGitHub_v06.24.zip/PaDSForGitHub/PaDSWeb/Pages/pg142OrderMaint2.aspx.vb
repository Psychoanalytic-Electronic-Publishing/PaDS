﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'09/02/11  Julian Gates   Initial New version
'11/5/11   Julian Gates   SIR2424 - Fix PrimaryProductCode dropdown loosing selected value issue.
'23/5/11   Julian Gates   SIR2435 - Add lookup to Discount rate to get selected Discount rate for account
'23/5/11    James Woosnam   SIR2435 - Get the correct Account for the company
'23/5/11    James Woosnam   SIR2435 - Do CompanyAccount first otherwise CompanyAccount update detals are shown rather than SalesOrder
'26/5/11   Julian Gates   Use new Me.Subscriber.CompanyAccountRow to update and read from correct company account
'31/5/11    James Woosnam   Pass current value to Populate drop down so we always have the value
'24/6/11    James Woosnam   Sometimes there is no account therefore no discount so allow for this
'23/7/11    James Woosnam   use companyaccountrow not just a count
'19/9/12    Julian Gates    SIR2866 - Add NotesRo code to populate read only nnotes field in Sub ReadRecord
'09/02/16   Julian Gates    SIR4048 - Change RateType and AccountType dropdown sql to use Lookup
'23/05/16   Julian Gates    SIR4046 - Change SIR Import link to go to pg483SubscriberImportFileLoad page
'07/2/20    Julian Gates    SIR4989 - Remove OrderPlacedBy field
'19/08/20   Julian Gates    SIR5099 - Add Audit link
'28/10/20   Julian Gates    Make Notes field always updatable and other small modifications.
'12/11/20   Julian Gates    SIR5148 - Add Various modifications
'17/02/21   Julian Gates    SIR5166 - Removed old asp page links
'07/12/21   Julian Gates    SIR5378 - Add Cancelled column to GetOrderSummaryHTML()
'14/12/21   Julian Gates    SIR5381 - Add Group confirmation email functionality
'04/01/22   Julian Gates    SIR5399 - Add SalesOrderLine.ProductRate and change grid formatting
Partial Class Pages_pg142OrderMaint2
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim pageMode As String = ""
    '   Dim noAccountSetup As Boolean = False

    Private _SalesOrder As BusinessLogic.SalesOrder = Nothing
    Public Property SalesOrder() As BusinessLogic.SalesOrder
        Get
            If Me._SalesOrder Is Nothing Then
                Me._SalesOrder = New BusinessLogic.SalesOrder(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._SalesOrder
        End Get
        Set(ByVal value As BusinessLogic.SalesOrder)
            Me._SalesOrder = value
        End Set
    End Property

    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                Me._Subscriber = New BusinessLogic.Subscriber(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property

    Private _Cashbook As BusinessLogic.Cashbook = Nothing
    Public Property Cashbook() As BusinessLogic.Cashbook
        Get
            If Me._Cashbook Is Nothing Then
                Me._Cashbook = New BusinessLogic.Cashbook(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._Cashbook
        End Get
        Set(ByVal value As BusinessLogic.Cashbook)
            Me._Cashbook = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Order Maint 1", "")
        Me.pageHeaderTitle.Text = "Order Maint 1"

        If Request.QueryString("OrderNumber") <> "" Then
            pageMode = "Update"
        End If

        '5/4/10     James Woosnam   Get SalesOrder and Subscriber everytime to stop unnessary conncurreny problems
        If Request.QueryString("OrderNumber") <> "" Then
            Try
                Me.txtOrderNumber.Value = Request.QueryString("OrderNumber")
                Me.SalesOrder = New BusinessLogic.SalesOrder(CInt(Request.QueryString("OrderNumber")), Me.uPage.db, Me.uPage.UserSession)
                Me.Subscriber = New BusinessLogic.Subscriber(CInt(Me.SalesOrder.SalesOrderRow.Item("SubscriberId")), Me.uPage.db, Me.uPage.UserSession)
            Catch ex As Exception
                Me.uPage.PageError = "Invalid Parameter has been passed in"
            End Try
            pageMode = "Update"

        End If
        If Page.IsPostBack Then
            '            Me.SalesOrder.MainDataset = CType(ViewState("MainDataSet"), DataSet)
            '            Me.Subscriber.MainDataset = CType(ViewState("MainDataSet1"), DataSet)
        Else


            If Me.uPage.IsValid Then
                ReadRecord()
            End If

            Me.PrimaryProductCodeValue.Focus()
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

    End Sub

    Sub PageSetup()
        Select Case pageMode
            Case "Add"
            Case "Update"
                '28/2/22    James Woosnam   SIR5443 - More descriptive page header
                uPage.pageTitle = "OrdDsply No: " & Me.SalesOrder.OrderNumber & " Sub:" & Me.Subscriber.SubscriberName & "(" & Me.Subscriber.SubscriberId & ")"
                Me.pageHeaderTitle.Text = uPage.pageTitle
                Me.SubscriberLink.NavigateUrl = "../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & Me.SalesOrder.SalesOrderRow.Item("SubscriberId")
                Me.SubscriberLink.Text = Me.SalesOrder.SalesOrderRow.Item("SubscriberId")

                Me.CashbookLink.NavigateUrl = "../pages/pg150CashbookSelect.aspx?" _
                                            & "FilterSubscriberId=" & Me.Subscriber.SubscriberRow("SubscriberId") _
                                            & "&CompanyId=" & Me.SalesOrder.SalesOrderRow.Item("CompanyId")


                Select Case Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")
                    Case "Pending", "Partial", "RemotePartial"
                        Me.OrderUpdateFieldsPanel.Visible = True
                        Me.OrderROFieldsPanel.Visible = False

                        '22/5/11    James Woosnam   SIR2435 - Allow Product to be updated
                        'If Me.SalesOrder.SalesOrderLine.Rows.Count = 0 Then
                        Me.PrimaryProductCodeValue.Enabled = True
                        'Else
                        '    Me.PrimaryProductCodeValue.Enabled = False
                        'End If
                        'Show primary product dropdown in RecurringSubscriptionFlag true
                        If Me.PrimaryProductCodeValue.SelectedValue <> "" Then
                            If uPage.db.IsDBNull(Me.uPage.db.DLookup("RecurringSubscriptionFlag", "Product", "ProductCode='" & Me.PrimaryProductCodeValue.SelectedValue.Remove(0, 3) & "'"), False) = True Then
                                Me.SubscriptionStartDateFieldPanel.Visible = True
                                Me.SubscriptionStartDateForAdd.Focus()
                            Else
                                Me.SubscriptionStartDateFieldPanel.Visible = False
                                Me.Notes.Focus()
                            End If
                        End If
                        'show account updatable fields if AuthorityLevel = Admins
                        Select Case Me.uPage.UserSession.AuthorityLevel
                            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                                Me.AccountUpdateFieldsPanel.Visible = True
                                Me.AccountROFieldsPanel.Visible = False
                            Case Else
                                Me.AccountUpdateFieldsPanel.Visible = False
                                Me.AccountROFieldsPanel.Visible = True
                        End Select
                    Case Else
                        Me.OrderUpdateFieldsPanel.Visible = False
                        Me.OrderROFieldsPanel.Visible = True

                        'Show primary product read only field in RecurringSubscriptionFlag true
                        If Me.PrimaryProductCodeValue.SelectedValue <> "" Then
                            If uPage.db.IsDBNull(Me.uPage.db.DLookup("RecurringSubscriptionFlag", "Product", "ProductCode='" & Me.PrimaryProductCodeValue.SelectedValue.Remove(0, 3) & "'"), False) = True Then
                                Me.SubscriptionStartDateROFieldPanel.Visible = True
                            Else
                                Me.SubscriptionStartDateROFieldPanel.Visible = False
                            End If
                        End If
                        Me.AccountUpdateFieldsPanel.Visible = False
                        Me.AccountROFieldsPanel.Visible = True
                        '12/11/20   Julian Gates    SIR5148 - Change Primary product to a link
                        Me.ProductCurrencyRO.NavigateUrl = "../pages/pg504ProductMaint.aspx?" _
                                           & "PageMode=Update" _
                                           & "&ProductCode=" & Me.ProductCurrencyRO.Text

                End Select

                'Check for account
                If Me.Subscriber.CompanyAccount.Rows.Count = 0 Then
                    Me.AccountDetailsPrompt.Text = "New Account Details"
                Else
                    Me.AccountDetailsPrompt.Text = "Confirm Account Details"
                End If

                'Show Import subscribers link
                Select Case Me.uPage.UserSession.AuthorityLevel
                    Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                        Me.ImportSubscribersLink.Visible = True
                        '23/05/16   Julian Gates    SIR4046 - Change SIR Import link to go to pg483SubscriberImportFileLoad page
                        Me.ImportSubscribersLink.NavigateUrl = "../Pages/pg482SubscriberInProgressImportsSelect.aspx?BlockSubscriberId=" & Me.Subscriber.SubscriberRow("SubscriberId")

                End Select

                'Me.NextPageLink.NavigateUrl = "../pages/pg143OrderMaint3.aspx?OrderNumber=" & Me.SalesOrder.OrderNumber 

                '19/08/20   Julian Gates    SIR5099 - Add Audit link
                Me.AuditLink.NavigateUrl = "../pages/pg040AuditLogDisplay.aspx?FltrUpdatedRecordFamily=SalesOrder&FltrUpdatedRecordFamilyKey=" & Me.SalesOrder.OrderNumber
                Me.AuditLink.Text = "View Audit"
                Me.AuditLink.ToolTip = "View Audit for this record"

                '5/10/21    Julian Gates    SIR5338 - Add Suspend order fields
                Select Case Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")
                    Case "Confirmed", "Complete"
                        Me.SuspendOrderRow.Visible = True
                    Case Else
                        Me.SuspendOrderRow.Visible = False
                End Select

                Me.ConfirmationsEmailsRow.Visible = uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus"), "") = "Confirmed" And uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("OrderType"), "") = "Block"
                Dim lastConfirmationBatchLogId As Integer = uPage.db.DLookup("ISNULL(MAX(BatchLogId),0)", "BatchLog", "Description like '%" & Me.SalesOrder.ConfirmationEmailName & "%'")
                If lastConfirmationBatchLogId <> Nothing Then
                    Me.ConfirmationEmailBatchLogRow.InnerHtml = "Click <a href=""pg161BatchLogLines.aspx?BatchLogId=" & lastConfirmationBatchLogId & """>here</a> for last batch log."
                Else
                    Me.ConfirmationEmailBatchLogRow.InnerHtml = ""
                End If
                GetOrderSummaryHTML()
                GetCashbookSummaryHTML()
        End Select
    End Sub
    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Try
            Select Case pageMode
                Case "Add"

                Case "Update"
                    'Read in subscriber details
                    Me.uPage.PopulatePageFieldsFromDataRow(Me.Subscriber.SubscriberRow)

                    'Read in Sales Order details
                    'Read in Company Account details
                    '23/5/11    James Woosnam   SIR2435 - Do CompanyAccount first otherwise CompanyAccount update detals are shown rather than SalesOrder
                    If Me.Subscriber.CompanyAccount.Rows.Count > 0 Then
                        '23/5/11    James Woosnam   SIR2435 - Get the correct Account for the company
                        '26/5/11    Julian Gates    Use CompanyAccountRow to get correct Account for the company
                        Me.uPage.PopulatePageFieldsFromDataRow(Me.Subscriber.CompanyAccountRow(Me.SalesOrder.SalesOrderRow("CompanyId")))
                    End If

                    Me.uPage.PopulatePageFieldsFromDataRow(Me.SalesOrder.SalesOrderRow)
                    If uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow("CurrencyCode"), "") <> "" _
                        And uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow("PrimaryProductCode"), "") <> "" Then
                        Select Case Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")
                            Case "Pending", "Partial", "RemotePartial"
                                '23/5/11    James Woosnam   Only populate drop down if we need to to avialbe the value not being in the list
                                Me.PrimaryProductCodeValue.SelectedValue = Me.SalesOrder.SalesOrderRow("CurrencyCode") & Me.SalesOrder.SalesOrderRow("PrimaryProductCode")
                        End Select
                    End If
                    '12/11/20   Julian Gates    SIR5148 - Show Company name
                    Me.CompanyName.Text = uPage.db.IsDBNull(uPage.StdCode.DLookup("CompanyName", "Company", "CompanyId=" & Me.SalesOrder.SalesOrderRow.Item("CompanyId"), uPage.PrimaryConnection), "")
                    Select Case Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")
                        Case "Pending", "Partial", "RemotePartial"
                            'Populate all dropdown fields
                            '23/5/11    James Woosnam   Add current product incase it is not current
                            '31/5/11    James Woosnam   Pass current value to Populate drop down so we always have the value
                            '31/7/15    Julian Gates    Add uPage.db.IsDBNull around SalesOrderRow("CurrencyCode") and SalesOrderRow("PrimaryProductCode") in sql below as was causing IsNull to string error
                            uPage.PopulateDropDownListFromSQL(Me.PrimaryProductCodeValue, "SELECT DISTINCT CurrencyCode + Product.ProductCode as Value" _
                                                                                & "    ,CurrencyCode + ' ' + Product.ProductCode + '-' + ProductShortName  as Text" _
                                                                                & " FROM Product" _
                                                                                & "		INNER JOIN ProductRate " _
                                                                                & "		ON ProductRate.ProductCode = Product.ProductCode" _
                                                                                & " WHERE Product.CompanyId = " & Me.SalesOrder.SalesOrderRow.Item("CompanyId") _
                                                                                & " AND isnull(CurrencyCode + Product.ProductCode,'')<>''" _
                                                                                & " AND Product.IsParent <> 0" _
                                                                                & " AND (Product.ProductStatus = 'Current'" _
                                                                                & "     OR Product.ProductCode = '" & Me.SalesOrder.SalesOrderRow("PrimaryProductCode") & "')" _
                                                                                & " Order by 2" _
                                                                                , uPage.PrimaryConnection _
                                                                                , "<--Primary Product-->" _
                                                                                , uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow("CurrencyCode"), "") & uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow("PrimaryProductCode"), "")
                                                                                )

                            '11/8/15    James Woosnam   Add IsNulls to all dropdowns
                            '09/02/16   Julian Gates    SIR4048 - Change AccountType dropdown sql to use Lookup
                            uPage.PopulateDropDownListFromSQL(Me.AccountType, "SELECT DISTINCT LookupItemKey as Value" _
                                                                                & "    ,Name as Text" _
                                                                                & "    ,DisplayOrder" _
                                                                                & " FROM Lookup " _
                                                                                & " WHERE LookupName = 'AccountType'" _
                                                                                & "	AND CompanyId = " & Me.SalesOrder.SalesOrderRow.Item("CompanyId") _
                                                                                & " AND LookupStatus = 'Active'" _
                                                                                & " ORDER BY DisplayOrder,Name,LookupItemKey" _
                                                                               , uPage.PrimaryConnection _
                                                                               , "<--Account Type-->" _
                                                                               , uPage.db.IsDBNull(Me.Subscriber.CompanyAccountRow(Me.SalesOrder.SalesOrderRow("CompanyId"))("AccountType"), "")
                                                                               )

                            uPage.PopulateDropDownListFromSQL(Me.DiscountRateID, "SELECT DiscountRateID as Value" _
                                                                                & "    , Description as Text" _
                                                                                & " FROM DiscountRate " _
                                                                                & " ORDER BY 2" _
                                                                                , uPage.PrimaryConnection _
                                                                                , "<--Discount Rate-->" _
                                                                               , uPage.db.IsDBNull(Me.Subscriber.CompanyAccountRow(Me.SalesOrder.SalesOrderRow("CompanyId"))("DiscountRateID"), 0)
                                                                              )

                            '09/02/16   Julian Gates    SIR4048 - Change RateType dropdown sql to use Lookup
                            uPage.PopulateDropDownListFromSQL(Me.RateType, "SELECT DISTINCT LookupItemKey as Value" _
                                                                                & "    ,Name as Text" _
                                                                                & "    ,DisplayOrder" _
                                                                                & " FROM Lookup " _
                                                                                & " WHERE LookupName = 'RateType'" _
                                                                                & "	AND CompanyId = " & Me.SalesOrder.SalesOrderRow.Item("CompanyId") _
                                                                                & " AND LookupStatus = 'Active'" _
                                                                                & " ORDER BY DisplayOrder,Name,LookupItemKey" _
                                                                                , uPage.PrimaryConnection _
                                                                                , "<--Rate Type-->" _
                                                                               , uPage.db.IsDBNull(Me.Subscriber.CompanyAccountRow(Me.SalesOrder.SalesOrderRow("CompanyId"))("RateType"), "")
                                                                              )

                            uPage.PopulateDropDownListFromSQL(Me.BillingAddressId, "SELECT SubscriberAddress.SubscriberAddressId as Value" _
                                                                                & "    , Left(SubscriberAddress.AddressDescription + ' - ' + SubscriberAddress.AddressText,50) as Text" _
                                                                                & " FROM SubscriberAddress " _
                                                                                & " WHERE AddressType = 'Postal'" _
                                                                                & " AND SubscriberId = " & Me.Subscriber.SubscriberRow("SubscriberId") _
                                                                                & " ORDER BY 2" _
                                                                                , uPage.PrimaryConnection _
                                                                                , "<--Billing Address-->" _
                                                                               , uPage.db.IsDBNull(Me.Subscriber.CompanyAccountRow(Me.SalesOrder.SalesOrderRow("CompanyId"))("BillingAddressId"), 0)
                                                                              )
                        Case "Confirmed"
                            If uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("OrderType"), "") = "Block" Then
                                Dim sql As String = "Select TOP 100 PERCENT" _
                                    & " s.SubscriberId As Value" _
                                    & " ,Text = s.SubscriberName + ' (' + CAST(s.SubscriberId AS VARCHAR) +')' + ' ' + sol.ProductCode + CASE WHEN asol.OrderNumber IS NULL THEN '' ELSE ' + ' + asol.ProductCode END" _
                                    & " FROM SalesOrder so" _
                                    & "     INNER Join SalesOrderLine sol" _
                                    & "         INNER JOIN Subscriber s" _
                                    & "         ON s.SubscriberId = sol.SubscriberId" _
                                    & "     ON so.OrderNumber = sol.OrderNumber" _
                                    & "     AND sol.ProductCode = so.PrimaryProductCode" _
                                    & "     INNER JOIN Product p" _
                                    & "     ON p.ProductCode = so.PrimaryProductCode" _
                                    & "     LEFT JOIN SalesOrderLine asol" _
                                    & "     ON asol.SubscriberId = sol.SubscriberId" _
                                    & "     And asol.OrderNumber = sol.OrderNumber" _
                                    & "     And asol.ProductCode = p.AssociatedProductCode" _
                                    & " WHERE 1 = 1" _
                                    & " AND so.OrderNumber =" & Me.SalesOrder.SalesOrderRow.Item("OrderNumber") _
                                    & " ORDER BY so.orderNumber Desc, 2"
                                Me.uPage.PopulateDropDownListFromSQL(Me.SendTestEmailSubsciberId, sql, uPage.db.DBConnection, Nothing)
                            End If
                    End Select

                    Select Case Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")
                        Case "Pending", "Partial", "RemotePartial"
                        Case Else
                            'Populate sales order read only fields
                            Me.ProductCurrencyRO.Text = uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("PrimaryProductCode"), "")
                            Me.SubscriptionStartDateForAddRO.Text = uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("SubscriptionStartDateForAdd"), "")

                            If Me.Subscriber.CompanyAccount.Rows.Count > 0 Then
                                Dim row As DataRow = Me.Subscriber.CompanyAccountRow(Me.SalesOrder.SalesOrderRow("CompanyId"))
                                '23/5/11    James Woosnam   SIR2435 - Get the correct Account for the company
                                'Populate account read only fields
                                Me.AccountNumberRO.Text = uPage.db.IsDBNull(row("AccountNumber"), "")
                                Me.AccountStatusRO.Text = uPage.db.IsDBNull(row("CompanyAccountStatus"), "")
                                Me.AccountTypeRO.Text = uPage.db.IsDBNull(row("AccountType"), "")
                                '23/5/11  Julian Gates  SIR2435 - Add lookup to Discount rate to get selected Discount rate for account
                                Me.DiscountRateIDRO.Text = uPage.db.IsDBNull(uPage.StdCode.DLookup("Description", "DiscountRate", "DiscountRateId=" & row("DiscountRateID"), uPage.PrimaryConnection), "")
                                Me.RateTypeRO.Text = uPage.db.IsDBNull(row("RateType"), "")
                                Me.BillingAddressRO.Text = uPage.db.IsDBNull(Me.uPage.db.DLookup("AddressText", "SubscriberAddress", "SubscriberAddressId=" & row("BillingAddressId")), "")
                            End If
                    End Select

            End Select

        Catch ex As Exception
            Dim email As New BusinessLogic.Email(Me.uPage.db)
            email.SendErrorEmail("pg142OrderMaint2 Read Error", ex.ToString)
            Me.uPage.PageError = "Read Error.  Please contact Support:" & ex.Message
        End Try

    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus

            Case Else
                Select Case Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")
                    Case "Pending", "Partial", "RemotePartial"
                        If Me.PrimaryProductCodeValue.SelectedValue = "" Then
                            uPage.FieldErrorControl(Me.PrimaryProductCodeValue, "Primary Product is mandatory")
                        End If

                        If Me.AccountNumber.Text = "" Then
                            uPage.FieldErrorControl(Me.AccountNumber, "Account Number is mandatory")
                        End If

                        If Me.AccountType.SelectedValue = "" Then
                            uPage.FieldErrorControl(Me.AccountType, "Account Type is mandatory")
                        End If

                        If Me.DiscountRateID.SelectedValue = "" Then
                            uPage.FieldErrorControl(Me.DiscountRateID, "Discount Rate is mandatory")
                        End If

                        If Me.RateType.SelectedValue = "" Then
                            uPage.FieldErrorControl(Me.RateType, "Rate Type is mandatory")
                        End If

                        If Me.BillingAddressId.SelectedValue = "" Then
                            uPage.FieldErrorControl(Me.BillingAddressId, "Billing Address is mandatory")
                        End If

                        If Me.SubscriptionStartDateFieldPanel.Visible = True Then
                            If Me.SubscriptionStartDateForAdd.Text = "" Then
                                uPage.PageError = "Please add a subscription start date"
                            End If

                            If Me.SubscriptionStartDateForAdd.Text <> "" Then
                                uPage.FieldValidateDate(Me.SubscriptionStartDateForAdd)
                            End If
                        End If
                    Case "Confirmed", "Complete"

                End Select
        End Select
        Return uPage.IsValid
    End Function

    Sub SaveRecord(ByVal SaveType As String)
        '******************************************************
        'Description:	Save the record either by updating
        '******************************************************
        Try

            Select Case Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")
                Case "Pending", "Partial", "RemotePartial"
                    '23/7/11    James Woosnam   use companyaccountrow not just a count
                    If Me.Subscriber.CompanyAccountRow(Me.SalesOrder.SalesOrderRow("CompanyId")).RowState = DataRowState.Detached Then
                        'Add comapny account if missing
                        Me.Subscriber.AddCompanyAccount(Me.SalesOrder.SalesOrderRow("CompanyId"),
                                                        Me.AccountType.SelectedValue,
                                                        Me.DiscountRateID.SelectedValue,
                                                        Me.RateType.SelectedValue,
                                                        Me.BillingAddressId.SelectedValue
                                                        )
                    Else
                        'Me.uPage.PopulateDataRowFromPageFields(Me.Subscriber.CompanyAccount.Rows(0))
                        Me.uPage.PopulateDataRowFromPageFields(Me.Subscriber.CompanyAccountRow(Me.SalesOrder.SalesOrderRow("CompanyId")))
                    End If
                    Me.Subscriber.Save()

                    Me.uPage.PopulateDataRowFromPageFields(Me.SalesOrder.SalesOrderRow)
                    Me.SalesOrder.SalesOrderRow("PrimaryProductCode") = Me.PrimaryProductCodeValue.SelectedValue.Remove(0, 3)
                    Me.SalesOrder.SalesOrderRow("CurrencyCode") = Left(Me.PrimaryProductCodeValue.SelectedItem.Text, 3)
                    '24/6/11    James Woosnam   Sometimes there is no account therefore no discount so allow for this
                    Dim PercentDiscount As Double = 0
                    Try
                        PercentDiscount = uPage.db.IsDBNull(uPage.StdCode.DLookup("PercentDiscount", "DiscountRate", "DiscountRateId=" & Me.Subscriber.CompanyAccountRow(Me.SalesOrder.SalesOrderRow("CompanyId"))("DiscountRateID"), uPage.PrimaryConnection), "")
                    Catch ex As Exception
                    End Try
                    Me.SalesOrder.SalesOrderRow("PercentDiscount") = PercentDiscount
                    Me.SalesOrder.Save()
                Case "Confirmed", "Complete"
                    Me.uPage.PopulateDataRowFromPageFields(Me.SalesOrder.SalesOrderRow)
                    Me.SalesOrder.Save()
                Case Else
                    'Save Notes field even if status is Complete or Rejected
                    Me.SalesOrder.SalesOrderRow("Notes") = Me.Notes.Text
                    Me.SalesOrder.Save()
            End Select

        Catch ex As Exception
            Me.uPage.PageError = "Save Record failed " & ex.ToString
        End Try

        If Me.uPage.IsValid Then
            Select Case SaveType
                Case "SaveOnly"
                    Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=This record has been saved&OrderNumber=" & Me.txtOrderNumber.Value & "&PageMode=Update")
            End Select
        End If

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        '  ViewState("MainDataSet") = Me.SalesOrder.MainDataset
        '  ViewState("MainDataSet1") = Me.Subscriber.MainDataset
        PageSetup()
        uPage.PagePreRender()
    End Sub

    Protected Sub SaveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                SaveRecord("SaveOnly")
            Catch ex As Exception
                uPage.PageError = ex.ToString
            End Try
        End If
    End Sub
    Protected Sub NextPageLink_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles NextPageLink.Click
        Select Case Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")
            Case "Partial", "Pending"
                If Me.IsPageValidForStatus("") Then
                    Response.Redirect("../pages/pg143OrderMaint3.aspx?OrderNumber=" & Me.SalesOrder.OrderNumber)
                Else
                    uPage.PageError = "Please Save before clicking Next link."
                End If
            Case Else
                Response.Redirect("../pages/pg143OrderMaint3.aspx?OrderNumber=" & Me.SalesOrder.OrderNumber)
        End Select

    End Sub
    Protected Sub PrimaryProductCode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles PrimaryProductCodeValue.SelectedIndexChanged
        'PageSetup()
    End Sub

    Sub GetOrderSummaryHTML()
        '12/11/20   Julian Gates    SIR5148 - Add CurrencyCode
        '07/12/21   Julian Gates    SIR5378 - Add Cancelled column to GetOrderSummaryHTML()
        '04/01/22   Julian Gates    SIR5399 - Add SalesOrderLine.ProductRate and change grid formatting
        Dim strSQL As String = ""
        Dim html As String = ""
        Dim quantityTotal As Integer = 0
        Dim amountTotal As Double = 0

        strSQL = "Select SalesOrderLine.ProductCode" _
             & "	,SubscriberAffiliate.SubscriberCategory" _
             & "	,Sum(Quantity) AS Quantity" _
             & "    ,SalesOrder.CurrencyCode" _
             & "	,Sum(AmountProduct) AS Amount" _
             & "    ,SalesOrderLine.IsCancel" _
             & "    ,SalesOrderLine.ProductRate" _
             & " FROM SalesOrderLine" _
             & "	INNER JOIN SalesOrder" _
             & "		INNER JOIN Company" _
             & "		ON Company.CompanyId = SalesOrder.CompanyId" _
             & "	On SalesOrder.OrderNumber = SalesOrderLine.OrderNumber" _
             & "	INNER JOIN SubscriberAffiliate" _
             & "	ON SubscriberAffiliate.ChildSubscriberID = SalesOrderLine.SubscriberId" _
             & " WHERE Company.GroupParentSubscriberId = SubscriberAffiliate.ParentSubscriberID" _
             & " AND SalesOrderLine.OrderNumber=" & Me.txtOrderNumber.Value _
             & " GROUP BY SalesOrderLine.ProductCode" _
             & "        ,SubscriberAffiliate.SubscriberCategory" _
             & "        ,SalesOrder.CurrencyCode" _
             & "        ,SalesOrderLine.IsCancel" _
             & "        ,SalesOrderLine.ProductRate"
        Try
            Dim tblOrderSummary As DataTable = uPage.db.GetDataTableFromSQL(strSQL)
            If tblOrderSummary.Rows.Count <> 0 Then
                html += "<table width='400' border='0' cellpadding='5' class='selectTable'>"
                html += "  <tr>"
                html += "    <td class='fldTitle'>Product</td>"
                html += "    <td class='fldTitle'>Category</td>"
                html += "    <td class='fldTitle'>Currency</td>"
                html += "    <td class='fldTitle'>Cancelled</td>"
                html += "    <td class='fldTitle' align='right'>Quantity</td>"
                html += "    <td class='fldTitle' align='right'>Rate</td>"
                html += "    <td class='fldTitle' align='right'>Amount</td>"
                html += "  </tr>"

                For Each row As DataRow In tblOrderSummary.Rows
                    html += "  <tr>"
                    html += "	    <td class='fldView'>" & row("ProductCode") & "</td>"
                    html += "	    <td class='fldView'>" & row("SubscriberCategory") & "</td>"
                    html += "	    <td class='fldView'>" & row("CurrencyCode") & "</td>"
                    If uPage.db.IsDBNull(row("IsCancel"), False) = True Then
                        html += "	    <td class='fldView'>Yes</td>"
                    Else
                        html += "	    <td class='fldView'>&nbsp;</td>"
                    End If
                    html += "	    <td class='fldView' align='right'>" & Format(uPage.db.IsDBNull(row("Quantity"), 0), "#,##0") & "</td>"
                    html += "	    <td class='fldView' align='right'>" & Format(uPage.db.IsDBNull(row("ProductRate"), 0), "#,##0.00") & "</td>"
                    html += "	    <td class='fldView' align='right'>" & Format(uPage.db.IsDBNull(row("Amount"), 0), "#,##0.00") & "</td>"
                    html += "  </tr>"
                    quantityTotal += row("Quantity")
                    amountTotal += uPage.db.IsDBNull(row("Amount"), 0)
                Next
                html += "  <tr>"
                html += "	    <td>&nbsp;</td>"
                html += "	    <td>&nbsp;</td>"
                html += "	    <td>&nbsp;</td>"
                html += "	    <td class='fldViewBoldRight'>Total</td>"
                html += "	    <td class='fldViewBoldRight'>" & Format(quantityTotal, "#,##0") & "</td>"
                html += "	    <td>&nbsp;</td>"
                html += "	    <td class='fldViewBoldRight'>" & Format(amountTotal, "#,##0.00") & "</td>"
                html += "  </tr>"
                html += "</table>"
            Else
                html += "<table width='400' border='0' cellpadding='5' class='selectTable'>"
                html += "  <tr>"
                html += "    <td class='fldView'>No Order data available</td>"
                html += "  </tr>"
                html += "</table>"
            End If

            Me.OrderSummaryList.Text = html

        Catch ex As Exception
            uPage.PageError = "An Unexpected error has occured.  Get Order summary failed" & ex.ToString
        End Try
    End Sub

    Sub GetCashbookSummaryHTML()

        Dim strSQL As String = ""
        Dim html As String = ""

        strSQL = "SELECT Cashbook.CashBookId" _
            & "	    ,Cashbook.EntryDate" _
            & "	    ,Cashbook.CashbookStatus" _
            & "	FROM Cashbook" _
            & "   WHERE Cashbook.OrderNumber=" & Me.txtOrderNumber.Value _
            & " ORDER By Cashbook.EntryDate"
        Try
            Dim tblSCashbookummary As DataTable = uPage.db.GetDataTableFromSQL(strSQL)

            If tblSCashbookummary.Rows.Count = 0 Then
                html += "<table width='300' border='0' cellpadding='5' class='selectTable'>"
                html += "  <tr>"
                html += "    <td class='fldView'>No Cashbook data available</td>"
                html += "  </tr>"
                html += "</table>"
            Else
                html += "<table width='300' border='1' cellpadding='5' class='selectTable'>"
                html += "  <tr>"
                html += "    <td class='fldTitle'>Date</td>"
                html += "    <td class='fldTitle'>Status</td>"
                html += "    <td class='fldTitle'>&nbsp;</td>"
                html += "  </tr>"

                For Each row As DataRow In tblSCashbookummary.Rows
                    html += "  <tr>"
                    html += "	    <td class='fldView'>" & row("EntryDate") & "</td>"
                    html += "	    <td class='fldView'>" & row("CashbookStatus") & "</td>"
                    html += "	    <td class='fldView'><a href='../Pages/pg151CashbookMaint.aspx?PageMode=Update&CashBookId=" & row("CashBookId") & "' title='Go To Cashbook maint'>View</a></td>"
                    html += "  </tr>"
                Next
                html += "</table>"
            End If
            Me.CashbookSummaryList.Text = html

        Catch ex As Exception
            uPage.PageError = "An Unexpected error has occured.  Get cashbook summary failed" & ex.ToString
        End Try
    End Sub

    Private Sub IsOrderSuspended_CheckedChanged(sender As Object, e As EventArgs) Handles IsOrderSuspended.CheckedChanged
        If Me.SuspendedDateTime.Text = "" And Me.IsOrderSuspended.Checked Then
            Me.SuspendedDateTime.Text = System.DateTime.Today
        Else
            Me.SuspendedDateTime.Text = Nothing
        End If
    End Sub

    Protected Sub SendConfirmationEmailBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SendConfirmationEmailBtn.Click
        Try
            Me.SalesOrder.PopulateAndSubmitBlockConfirmationEmail()
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
        If Me.uPage.IsValid Then
            Me.uPage.InfoMessage = "The emails will be sent as a batch job, <span class='logLink'><a href='./pg160BatchLogList.aspx' title='Go To Batch Log List'>Click Here</a></span> to check"
        End If
    End Sub
    Protected Sub SendTestEmailBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SendTestEmailBtn.Click
        Try
            Me.SalesOrder.PopulateAndSubmitBlockConfirmationEmail(Me.SendTestEmailSubsciberId.SelectedValue)
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
        If Me.uPage.IsValid Then
            Me.uPage.InfoMessage = "The emails will be sent as a batch job, <span class='logLink'><a href='./pg160BatchLogList.aspx' title='Go To Batch Log List' target='_blank'>Click Here</a></span> to check"
        End If
    End Sub
End Class
