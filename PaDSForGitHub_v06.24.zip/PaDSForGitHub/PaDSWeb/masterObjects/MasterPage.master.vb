﻿
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data
Imports System.Web.UI.HtmlControls
Imports System.Data.SqlClient

'Modification History 
'17/11/10   Julian Gates  Initial Version
'13/01/11   Julian Gates  Remove page title for logon and home page
'22/5/11        James Woosnam   HotFix - Add Session and Primary/Secondary Flags to Session Log
'19/03/15   Julian Gates    SIR3783 - Add Spanish help link to page header to be shown for IJP-es subscribers.
'16/10/15   Julian Gates    SIR3982 - Change www.p-e-p.org link to support.pep-web.org
'04/07/17   Julian Gates    Remove all IJP-es spanish text
'31/10/19   Julian Gates    SIR4772 - Add cookie consent popup.
'17/03/20   Julian Gates    SIR5037 - Add menus for GroupAdmin users
'26/03/20   Julian Gates    SIR5050 - Change Renewals to Renewals/Additions in menu
'17/8/20    James Woosnam   SIR5082 - Store SessionId in, and restored from, a new session cookie
'25/8/20     James Woosnam   SIR5082 - Logout correctly with session cookies and spoof logins
'26/02/21   Julian Gates    SIR5046 - Add Counter Reports in menu
'16/03/21   Julian Gates    SIR5213 - Use ShowCounterReports for menu item
'18/8/21    James Woosnam   SIR5279 - If CounterReportsOnly only show counter reports

Partial Class masterObjects_MasterPage
    Inherits System.Web.UI.MasterPage

#Region "Class Properties"

    Public menuId As String = ""
    Public subMenuId As String = ""
    Public subMenuItemId As String = ""
    Public MainMenuId As String = ""
    Public PageTitle As String = ")"
    Public PageTitleBar As String = ")"
    Public MetaDescription As String = ""
    Public MetaKeywords As String = ""
    Public WebForm As WebForm
    '31/5/12    James Woosnam   VersionNumber moved into Database and called db.PaDsVersion
    ' Public Version As String = "v04.01e (15th May 2012) "
    Public ErrorMessage As String = ""
    Public SessionTimerScript As String
    Public ShowLanguageRBL As Boolean = False
    Public ReadOnly Property DisplayLanguageRBLSelectedValue As BusinessLogic.UserSession.DisplayLanguages
        Get

            Return Me.DisplayLanguageRBL.SelectedValue

        End Get
    End Property
    Public ReadOnly Property IsLoggedIn() As Boolean
        Get
            If Me.UserSession.Data("LoggedIn") = Nothing Then
                Return False
            End If
            If Me.UserSession.Data("LoggedIn") Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property
    Public ReadOnly Property SessionQueryString As String
        Get
            Return "UserSessionGUID=" & Me.UserSession.Data("UserSessionGUID")
        End Get
    End Property
    Dim _UserSession As BusinessLogic.UserSession = Nothing
    Public Property UserSession() As BusinessLogic.UserSession
        Get
            Return Me._UserSession
        End Get
        Set(ByVal value As BusinessLogic.UserSession)

        End Set
    End Property
    Public ReadOnly Property IsWebServerPrimaryOrSecondary As String
        Get
            Return System.Configuration.ConfigurationManager.AppSettings("IsPrimaryOrSeconday")
        End Get
    End Property
    Public IsDatabaseServerPrimaryOrSecondary As String = "Unknown"
    Public IsReadOnlyOnSecondary As Boolean = False
    Public ReadOnly Property DatabaseName() As String
        Get
            Try
                Return Me.db.DBConnection.Database
            Catch generatedExceptionName As Exception
                Return "**Not Found**"
            End Try
        End Get
    End Property
    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            If Me._db Is Nothing Then
                Dim FailOver As New BusinessLogic.Failover()
                Me._db = New BusinessLogic.Database(FailOver.ChooseConnectionString( _
                                                    System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringPrimary").ToString _
                                                    , System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringSecondary").ToString _
                                                    , System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringSecurityOnSecondary").ToString _
                                                    , "ASP.NET - MasterPage.vb - " _
                                                    , Me.IsWebServerPrimaryOrSecondary))
                Me._db.SecondaryConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringSecondary").ToString
                Me.IsDatabaseServerPrimaryOrSecondary = FailOver.IsDatabaseServerPrimaryOrSecondary
                Me.IsReadOnlyOnSecondary = FailOver.IsReadOnlyOnSecondary
            End If
            Return (Me._db)
        End Get


        Set(ByVal value As BusinessLogic.Database)
            Me._db = value
        End Set
    End Property
    Private _FocusControl As System.Web.UI.Control
    Public Property FocusControl() As System.Web.UI.Control
        Get
            Return Me._FocusControl
        End Get
        Set(ByVal value As System.Web.UI.Control)
            Me._FocusControl = value
        End Set
    End Property

    Public ReadOnly Property IsSpanishIJPESSubscriber As Boolean
        Get
            If Me.UserSession.Data(Me.UserSession.Data("IsSpanishIJPESSubscriber")) Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
        If Not IsPostBack Then
            If Not String.IsNullOrEmpty(Request.QueryString("InfoMsg")) Then
                Me.WebForm.AddInfoMessage(Request.QueryString("InfoMsg"))
            End If
        End If

        If Me.IsLoggedIn Then
            Me.LogoutBtnPanel.Visible = True

            If Me.MainMenuId = "00" Then
                Me.LogoutBtnPanel.Visible = False
            Else
                Me.LogoutBtnPanel.Visible = True
            End If
            '            LogoutBtn.Attributes.Add("onclick", "if(confirm('Are you sure you want to log out?')){}else{return false}")
        Else
            Me.LogoutBtnPanel.Visible = False
        End If

        'Show read only message if on Secondary server
        If Me.UserSession.Data("IsReadOnlyOnSecondary") IsNot Nothing AndAlso Me.UserSession.Data("IsReadOnlyOnSecondary") Then
            Me.ReadOnlyMssg.Text = "(Read Only)"
        Else
            Me.ReadOnlyMssg.Text = ""
        End If

        'Show in footer live server info and show Test version banner
        If Me.db.IsOnLiveServer = False Then
            Me.TestVersionBannerRow.Visible = True
            Me.ServerInfo.Text = Me.db.GetParameterValue("ServerDescription")
        Else
            Me.TestVersionBannerRow.Visible = False
            Me.ServerInfo.Text = "(Live Server) " & Me.db.GetParameterValue("ServerDescription")
        End If

    End Sub
    Public Sub AddAdditionalInfoForlog(AdditionalInfo As String)
        Me.WebForm.AdditionalInfoForlog += Environment.NewLine + AdditionalInfo
    End Sub
    Protected Sub Page_PreRender(ByVal sender As Object, ByVal e As EventArgs)
        '17/11/21 - Beef up session logging by doing in PreRender and adding extra info
        InfoMessage()
        OutputErrorMessage()
        Me.DisplayLanguageRBL.Visible = Me.ShowLanguageRBL
        Me.DisplayLanguageRBL.SelectedValue = Me.UserSession.DisplayLanguage
        Me.UserSession.SessionCookie.Save(Me.Response)
        Me.WebForm.Page_PreRender(sender, e)
        Try
            Dim ex As Exception = Me.Server.GetLastError()
            Me.AddAdditionalInfoForlog("LastError:" & ex.ToString)
        Catch ex As Exception
        End Try
        Me.WriteSessionLog("PageLoad", Me.WebForm.AdditionalInfoForlog)

    End Sub
    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As EventArgs)
        Unload()
    End Sub
    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Me.HandlePageError()
        Catch generatedExceptionName As Exception

        End Try
    End Sub

    Public Sub Initilise(ByVal PageTitle As String, ByVal MainMenuId As String, ByVal SubMenuItemId As String,
                        Optional ByVal MetaDescription As String = "",
                        Optional ByVal MetaKeywords As String = "",
                         Optional ResetSessionCookie As Boolean = False)
        '29/3/18    James Woosnam   If not secure currection and on live then bounce to logon page
        '17/8/20    James Woosnam   SIR5082 - Store SessionId in, and restored from, a new session cookie
        If Not Request.IsSecureConnection Then
            If Not Server.MachineName.ToLower.Contains("zedra") Then
                Response.Redirect("https://" & Request.Url.Authority & "/pages/pg070Logon.aspx")
            End If
        End If
        Dim currentPage As Object = Me 'put me into currentPage so code can be identical in UserPage.vb

        '*****Code below should be kept pretty much in sync between UserPage.new and Master.Initilise*******
        Me._UserSession = New BusinessLogic.UserSession(Me.db)
        Dim RedirectURL As String = Nothing
        Try
            Me._UserSession.RestoreFromCookie(Me.Request, RedirectURL, ResetSessionCookie)
            Me.UserSession.Data("IsReadOnlyOnSecondary") = Me.IsReadOnlyOnSecondary
        Catch ex As Exception

            If ex.Message.Contains(" has timed out") Then
                Me.WebForm.AdditionalInfoForlog += "Session Timed Out"
            End If
        End Try
        If RedirectURL <> Nothing Then
            currentPage.Response.Redirect(RedirectURL)
            HttpContext.Current.ApplicationInstance.CompleteRequest()
        End If
        '*****Code above should be kept pretty much sync between UserPage.new and Master.Initilise*******

        If Not Me.Request.QueryString("Action") = Nothing Then
            If Me.Request.QueryString("Action").ToUpper = "LOGOUT" Then
                Me.SessionLogout() ' SessionLogout redirects to pg070Logon
            End If
        End If

        'Unless we are on any of the pages below we should be logged on therefore 
        'if not logged on we check for an auto logon in the query string and go to logon page
        'if that fails.
        If Me.Request.Item("Path_Info").ToLower.Contains("/pages/pg070logon.aspx") _
        Or Me.Request.Item("Path_Info").ToLower.Contains("/pages/pg071userauthorisation.aspx") _
        Or Me.Request.Item("Path_Info").ToLower.Contains("/pages/pg117addnewsubscriber.aspx") Then
        Else
            'User account 1 means noone has logged on
            If Not Me.IsLoggedIn Then
                Dim url As String = ""
                url = "../pages/pg070Logon.aspx"
                Try
                    Me.UserSession.SessionCookie.Save(Me.Response, True) 'save as expired cookie, which should delete it
                Catch ex As Exception

                End Try
                Me.Response.Redirect(url)
            End If

        End If

        Me.PageTitle = PageTitle
        Me.PageTitleBar = PageTitle
        Me.MetaDescription = MetaDescription
        Me.MetaKeywords = MetaKeywords
        Me.menuId = MainMenuId
        Me.MainMenuId = MainMenuId
        Me.subMenuId = SubMenuItemId
        Me.WebForm = New WebForm(Me.MainContent, Me.db, Me.Page, Me.UserSession)

        If Me.IsLoggedIn Then
            SessionTimerScript = "<script type=""text/javascript"" src=""../common/SessionTimer.js""></script>"
            Me.SessionTimeValue.Value = Me.UserSession.Timeout

            If Me.IsReadOnlyOnSecondary Then
                Me.WebForm.AddInfoMessage("PaDS Primary is temporarily unavailable.  PaDS must only be used for Reading, NOT writing")
            End If
        End If
        If Not Me.IsPostBack Then
            'Only do session log on first entry as every Ajax call is generateing a log
            If Me.Request.QueryString("SkipSessionLog") = "Yes" Then
                'Do record session log in some circumstances, eg pingdom and load balancer checks
            Else
                ' WriteSessionLog("PageLoad") 17/11/21 - now done in PreRender
            End If
        End If
    End Sub

    Public Function OutputErrorMessage() As [String]

        Dim strHTML As String = ""
        If Me.WebForm.PageErrors.Rows.Count <> 0 Then
            strHTML = "<div class='Inner3'>"
            strHTML += ("<h4>The following " & Me.WebForm.PageErrors.Rows.Count & " errors have been found:</h4>") + Environment.NewLine
            strHTML += "<ul>" & Environment.NewLine
            For Each row As DataRow In WebForm.PageErrors.Rows
                strHTML += "<li>" & Environment.NewLine
                strHTML += row("ErrorMessage").ToString().Replace(Environment.NewLine, "<br />") + Environment.NewLine
                strHTML += "</li>" & Environment.NewLine
                Me.AddAdditionalInfoForlog(row("ErrorMessage"))
            Next
            strHTML += "</ul>" & Environment.NewLine
            strHTML += "</div>"
            WebForm.PageErrors.Clear()
        End If
        'Panel must always be visible and updated every time to hide error messages after the error is fixed
        Me.pnlError.Visible = True
        Me.pnlError.Update()
        Me.ErrorMessage = strHTML
        Return Me.ErrorMessage
    End Function

    Private Sub InfoMessage()
        If Me.WebForm.InfoMessages.Rows.Count <> 0 Then
            Dim HTMLTable As New Table()
            Dim firstRow As Boolean = True
            For Each row As DataRow In WebForm.InfoMessages.Rows
                Dim TRow = New TableRow()
                Dim TCell = New TableCell()
                If firstRow Then
                    TCell.Text = "<img src='../images/icons/ok.gif'>"
                    TRow.Cells.Add(TCell)
                    firstRow = False
                Else
                    TRow.Cells.Add(TCell)
                End If
                Dim newCell1 = New TableCell()
                newCell1.CssClass = "infoMsg"
                newCell1.Text = row("InfoMessage").ToString().Replace(Environment.NewLine, "<br />")
                TRow.Cells.Add(newCell1)
                HTMLTable.Rows.Add(TRow)
                Me.AddAdditionalInfoForlog(row("InfoMessage"))
            Next
            Me.InfoMessageContent.Controls.Add(HTMLTable)
            'this.pnlInfoMessage.Update(); 
            Me.pnlInfoMessage.Visible = True
        Else
            Me.pnlInfoMessage.Visible = False
        End If
    End Sub

    Public ReadOnly Property MainMenu() As String
        Get
            Dim html As String = "&nbsp;"
            '26/03/20   Julian Gates    SIR5050 - Change Renewals to Renewals/Additions in menu
            '26/02/21   Julian Gates    SIR5046 - Add Counter Reports in menu
            '16/03/21   Julian Gates    SIR5213 - Use ShowCounterReports for menu item
            '18/8/21    James Woosnam   SIR5279 - If CounterReportsOnly only show counter reports
            Select Case menuId
                Case "01a", "02a", "03a"
                    If UserSession.AuthorityLevel = BusinessLogic.UserSession.AuthorityLevels.GroupAdmins Then
                        html = "                   <table cellspacing=""0"" cellpadding=""0"" border=""0"" class=""menuTable"">" & Chr(13)
                        html += "                       <tr>" & Chr(13)
                        html += "                           <td>&nbsp;</td>" & Chr(13)
                        If Not CBool(Me.UserSession.Data("CounterReportsOnly")) Then
                            html += GetMainMenuItem("Subscribers", "pg490GroupSubscriberSelect.aspx?" & Me.UserSession.QueryString, "01a")
                            html += GetMenuSpacer()
                            html += GetMainMenuItem("Renewals/Additions", "pg462SubscriberRenewals.aspx?" & Me.UserSession.QueryString, "02a")
                        End If

                        If CBool(Me.UserSession.Data("ShowCounterReports")) Then
                            If Not CBool(Me.UserSession.Data("CounterReportsOnly")) Then html += GetMenuSpacer()
                            html += GetMainMenuItem("Counter Reports", "pg600CounterReports.aspx?" & Me.UserSession.QueryString, "03a")
                        End If
                        html += "                           <td>&nbsp;</td>" & Chr(13)
                        html += "                       </tr>" & Chr(13)
                        html += "                   </table>" & Chr(13)
                    End If

            End Select
            Return html
        End Get
    End Property





    Private Function GetMainMenuItem(ByVal MenuText As String, ByVal PageName As String, ByVal mainMenuId As String, Optional ByVal TitleText As String = "", Optional ByVal PageMode As String = "") As String
        Dim html As String = ""
        Dim menuBtnImage As String = ""
        Dim cssClass As String = ""
        Dim localTitleText As String = ""

        If menuId = mainMenuId Then
            menuBtnImage = "../images/MenuImages/over-btn.gif"
            cssClass = "cssnav2"
        Else
            menuBtnImage = "../images/MenuImages/menu-btn.gif"
            cssClass = "cssnav"
        End If
        If TitleText <> "" Then
            localTitleText = TitleText
        Else
            localTitleText = MenuText
        End If
        html += "        <td>"
        html += "            <div class='" & cssClass & "'>" & vbCrLf
        html += "                <a href=""" & PageName & """" _
                                    & " title=""Open " & localTitleText & """><img src=""" & menuBtnImage & """ alt=""" & MenuText & """/>" _
                                    & "<span>" & MenuText & "</span></a>" & vbCrLf
        html += "            </div>" & vbCrLf
        html += "        </td>" & vbCrLf
        Return html
    End Function

    Private Function GetMenuSpacer() As String
        Dim html As String = ""
        Dim spacerImage As String = ""

        spacerImage = "menuSpacer"

        html += "<td width='1' align='center'><img src='../images/MenuImages/" & spacerImage & ".gif' width='1' height='20' border='0'/></td>" & vbCrLf
        Return html
    End Function

    Public Sub LogErrorMessage(ByVal exToLog As Exception)
        Try
            Me.WebForm.LogErrorMessage(exToLog)
        Catch ex As Exception
        End Try
    End Sub

    Public Shadows Sub Unload()
        Try
            If db.DBConnection.State = ConnectionState.Open Then
                db.DBConnection.Close()
            End If
        Catch ex As Exception
        End Try
    End Sub

    Public Sub HandlePageError()
        Me.WebForm.HandlePageError()
    End Sub

    Public Function GetProcessTime(ByVal dateTime__1 As String, ByVal endDateTime As String) As String
        'Returns the Process time 
        Dim processTime As New TimeSpan()

        If (dateTime__1 <> "") AndAlso (endDateTime <> "") Then
            processTime = DateTime.Parse(dateTime__1).Subtract(DateTime.Parse(endDateTime))
            Return processTime.ToString().Replace("-", "")
        Else
            Return String.Empty

        End If
    End Function
    Public Sub SessionLogout()
        '25/8/20     James Woosnam   SIR5082 - Logout correctly with session cookies and spoof logins
        Dim url As String = "../pages/pg070Logon.aspx"
        Try
            If Request.QueryString("IsSpoofSession") IsNot Nothing Then
                If Request.QueryString("IsSpoofSession") And Me.UserSession.Data("SpoofingUserId") <> 0 Then
                    'If logout of spoof user then just send to admin home and it should pick up the cookie minus the spoof which was deleted in Logout
                    url = "pg100HomeAdmin.aspx"
                End If
            End If

            Me.UserSession.Logout(Me.Response)
            Me.WriteSessionLog("UserLogout")

        Catch ex As Exception
            Throw ex
        End Try
        Me.Response.Redirect(url)

    End Sub
    Protected Sub LogoutBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LogoutBtn.Click
        Me.SessionLogout()
    End Sub

    Sub WriteSessionLog(Optional ByVal LogType As String = "PageLoad", Optional ByVal Comment As String = "")
        '*******************************************************************************************
        'Purpose:   Writes a record to the session log
        'Modification History
        'Who                When        What
        '===                ====        ===============
        'James Woosnam      20/10/04    Initial Version
        'James Woosnam      26/2/11     Delegated to BusinessLogic.Logs
        '22/5/11        James Woosnam   HotFix - Add Session and Primary/Secondary Flags to Session Log

        '*******************************************************************************************
        Dim logs As New BusinessLogic.Logs(db, Me.UserSession)
        Dim lPage As System.Web.UI.Page = Me.Page
        logs.WriteSessionLog(LogType _
                             , lPage.Request.Path _
                             , PageTitle _
                             , Me.UserSession.UserId _
                             , Me.UserSession.UserName _
                             , New BusinessLogic.StdCode().GetIPAddress(lPage.Request) _
                             , Comment _
                             , IsReadOnlyOnSecondary _
                             , IsDatabaseServerPrimaryOrSecondary _
                             , IsWebServerPrimaryOrSecondary)
    End Sub

    Private Sub DisplayLanguageRBL_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DisplayLanguageRBL.SelectedIndexChanged
        Me.UserSession.DisplayLanguage = Me.DisplayLanguageRBL.SelectedValue

    End Sub
End Class
