﻿Imports System.Security.Claims
Imports BusinessLogic
Public Class Claims
    Inherits Page
    ReadOnly Property SM As SiteMaster
        Get
            Return CType(Me.Master, SiteMaster)
        End Get
    End Property
    ReadOnly Property Db As Database
        Get
            Return SM.Db
        End Get
    End Property
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        SM.Initialise(False)
        Me.NewUserRegistration.NavigateUrl = Db.GetParameterValue("WebSiteURL") & "/Pages/pg117AddNewSubscriber.aspx?PageMode=BasicDetails&" & SM.UserSession.QueryString

        Dim claims = ClaimsPrincipal.Current.Claims
        For Each c As Claim In claims
            Dim tr As New TableRow
            Dim tc As New TableCell
            tc.Text = c.Type
            tr.Cells.Add(tc)
            tc = New TableCell
            tc.Text = c.Value
            tr.Cells.Add(tc)
            Me.tbClaims.Rows.Add(tr)
        Next
        If Request.QueryString("UserSessionId") <> "" Then
            Dim tr As New TableRow
            Dim tc As New TableCell
            tc.Text = "SessionId"
            tr.Cells.Add(tc)
            tc = New TableCell
            tc.Text = Request.QueryString("UserSessionId")
            tr.Cells.Add(tc)
            Me.tbClaims.Rows.Add(tr)
        End If
    End Sub
End Class