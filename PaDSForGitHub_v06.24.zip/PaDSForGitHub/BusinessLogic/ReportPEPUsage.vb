﻿'Modification History
'Feb 2018       James Woosnam   SIR4571 - Initial Version
Imports System.Data.SqlClient

Public Class ReportPEPUsage
    Inherits ReportSSG
#Region "Class Properties"
    Dim BatchJobId As Integer = Nothing
    Dim StartDate As Date = Nothing
    Dim EndDate As Date = Nothing
    Public PEPUsageReportType As PEPUsageReportTypes = Nothing
    Public AffiliateRateSubscriberId As Integer = Nothing
    Enum PEPUsageReportTypes
        PEPUsageSummaryByAffiliate
        PEPUsageDetailByAffiliate
        PEPUsageSingleAffiliateDetail
    End Enum



#End Region
    Public Sub New(ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New(db, SubmittedByUserSessionId)
    End Sub
    Public Sub New(ByVal StartDate As Date, ByVal EndDate As Date, PEPUsageReportType As PEPUsageReportTypes, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New(PEPUsageReportType.ToString, "Excel", db, SubmittedByUserSessionId)
        Me.PEPUsageReportType = PEPUsageReportType
        Me.StartDate = StartDate
        Me.EndDate = EndDate
    End Sub

    'BatchJob  Submit & Execute not required for now
    Public Overloads Sub Submit(AffiliateRateSubscriberId As Integer)
        Me.AffiliateRateSubscriberId = AffiliateRateSubscriberId

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSessionId
        BatchJob.Parameters.Add("ReportName", Me.PEPUsageReportType)
        BatchJob.Parameters.Add("PEPUsageReportType", Me.PEPUsageReportType)
        BatchJob.Parameters.Add("StartDate", StartDate.ToString("dd-MMM-yyyy"))
        BatchJob.Parameters.Add("EndDate", EndDate.ToString("dd-MMM-yyyy"))
        BatchJob.Parameters.Add("AffiliateRateSubscriberId", AffiliateRateSubscriberId)
        BatchJob.CreateBatchJobEntry("PEPUsageReport", Me.db)

    End Sub

    Public Overloads Sub Execute(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.JobParameters = Parameters
        Me.StartDate = Parameters.GetValue("StartDate")
        Me.EndDate = Parameters.GetValue("EndDate")
        Me.EndDate = Parameters.GetValue("EndDate")
        Me.PEPUsageReportType = Parameters.GetValue("PEPUsageReportType")
        Me.ReportName = Me.PEPUsageReportType.ToString
        Me.ReportType = "Excel"
        Me.BuildReport(Parameters.GetValue("AffiliateRateSubscriberId"))
    End Sub
    Public ReadOnly Property SQL As String
        Get
            If Me.ReportSQL = "" Then
                Me.ReportSQL = "EXEC sp457GetPEPUsageView 
                    @StartDate = " & db.vFQ(StartDate, "d") & "
					,@EndDate = " & db.vFQ(EndDate, "d") & "
					,@ViewType = '" & Me.PEPUsageReportType.ToString.Replace("PEPUsage", "") & "'"
                If AffiliateRateSubscriberId <> Nothing Then Me.ReportSQL += ",@AffiliateRateSubscriberId=" & AffiliateRateSubscriberId
            End If
            Return Me.ReportSQL
        End Get

    End Property
    Public Sub BuildReport(AffiliateRateSubscriberId As Integer, Optional ByVal InBatchLog As BatchLog = Nothing)
        Me.AffiliateRateSubscriberId = AffiliateRateSubscriberId
        Dim batchLogCreatedHere As Boolean = False
        If InBatchLog Is Nothing Then
            Me.BatchLog = New BatchLog("Report-" & Me.ReportName _
                                          , ";StartDate=" & Me.StartDate _
                                         & ";EndDate=" & Me.EndDate _
                                         , Me.db _
                                         , BatchJobId _
                                         , Me.SubmittedByUserSessionId)
            batchLogCreatedHere = True
        Else
            Me.BatchLog = InBatchLog
        End If
        Try
            MyBase.Execute(Me.BatchLog)

            Dim AffiliateRateSubscriberName As String = db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & AffiliateRateSubscriberId)


            Dim HeaderSQL As String = "SELECT
                 StartDate = '" & Me.StartDate.ToString("dd-MMM-yy") & "'
                 ,EndDate = '" & Me.EndDate.ToString("dd-MMM-yy") & "'
                 ,Title = 'PEP Usage " & IIf(Me.PEPUsageReportType = PEPUsageReportTypes.PEPUsageDetailByAffiliate, " Affiliate Summary", " for " & AffiliateRateSubscriberName) & "'
"
            '            ,RunDate = '" & Now.ToString("dd-MMM-yyyy HH:mm") & "'
            ',UserName = '" & Me.SubmittedByUserSession.UserFullName & "'
            ',sql = '" & Me.SQL.Replace("'", "''") & "'
            Dim repPiv As New BusinessLogic.ReportGeneric(Me.ReportName, "GenericPivot", db, New Guid(CStr(JobParameters.GetValue("SubmittedByUserSessionId"))))
            repPiv.FileName = Me.PEPUsageReportType.ToString & " " & IIf(AffiliateRateSubscriberId <> 0, AffiliateRateSubscriberName & " ", "") & StartDate.ToString(" dd-MMM-yyyy") & " To " & EndDate.ToString("dd-MMM-yyyy")
            repPiv.Execute(Me.ReportName & ".xltm", HeaderSQL, SQL, BatchLog)

            If batchLogCreatedHere Then
                BatchLog.Update("Process Complete", "Complete")
            End If
        Catch ex As Exception
            BatchLog.Update("Report Failed:" & ex.Message, "Failed")
            Throw New Exception("Report Failed:" & ex.Message, ex)

        End Try
    End Sub


    Dim _ReportData As DataTable = Nothing

    'ReadOnly Property ReportData() As DataTable
    '    Get
    '        Try
    '            If _ReportData Is Nothing Then

    '                _ReportData = db.GetDataTableFromSQL(Me.ReportSQL)
    '            End If

    '            Return _ReportData
    '        Catch ex As Exception
    '            Throw New Exception("GetDataTable failed:" & ex.Message)
    '        End Try
    '    End Get
    'End Property
    Public Sub SubmitPopulatePEPUsage()
        Try
            Dim BatchJob As New BusinessLogic.BatchJob(db)
            BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSession.UserSessionIdGUID
            BatchJob.CreateBatchJobEntry("PopulatePEPUsage", db)
        Catch ex As Exception
            Throw New Exception("SubmitPopulatePEPUsage failed:" & ex.Message)
        End Try
    End Sub
    Public Sub ExecutePopulatePEPUsage(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        BatchLog = New BatchLog("PopulatePEPUsage", "", Me.db, BatchJobId)

        Try
            Dim PEPWebCont As New PEPwebContent(db, Me.SubmittedByUserSession)
            PEPWebCont.ExecuteGetPEPWebSessionLog(Me.BatchJobId, Parameters)
            BatchLog.Update("sp456PopulatePEPUsage Starting")
            Dim cmd As New SqlCommand("sp456PopulatePEPUsage", db.DBConnection, db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandTimeout = 36000
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchLogId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      BatchLog.BatchLogId))
            cmd.ExecuteNonQuery()

            BatchLog.Update("PopulatePEPUsage Complete", "Complete")

        Catch ex As Exception
            BatchLog.Update("PopulatePEPUsage failed:" & ex.Message, "Failed")
            Throw New Exception(ex.ToString)
        End Try

    End Sub
End Class
