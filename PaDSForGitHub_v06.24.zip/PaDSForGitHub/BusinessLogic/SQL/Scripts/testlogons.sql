            SELECT 
                ru.UserId
                 ,ru.UserName
                 ,ru.Password
                 ,ru.ValidUntil
                 ,ru.AuthorityLevel
                 ,ru.PasswordRetryAttempts
                 ,ru.UserStatus
                 ,UserFullName = ISNULL(UserFullName,ru.UserName)
				 ,SubscriberId = CASE WHEN sProp.SubscriberId IS NULL THEN s.SubscriberId ELSE sProp.SubscriberId END
				 ,BaseSubscriberId = CASE WHEN sProp.SubscriberId IS NULL THEN sProp.SubscriberId ELSE s.SubscriberId END
				 ,IsSpanishIJPESSubscriber = CASE WHEN sProp.SubscriberId IS NULL THEN s.IsSpanishIJPESSubscriber ELSE sProp.IsSpanishIJPESSubscriber END
             FROM RemoteUser ru
				LEFT JOIN RemoteUserRights rur
					INNER JOIN Subscriber s
						LEFT JOIN Subscriber sProp
						ON sProp.UpdateToSubscriberId = s.SubscriberId 
						AND sProp.SubscriberStatus = 'Proposed'
					ON s.SubscriberId = rur.RightsToId 
					--AND NOT EXISTS (SELECT s.UpdateToSubscriberid FROM Subscriber s2 WHERE s2.SubscriberStatus = 'Proposed' AND s.SubscriberId = s2.UpdateToSubscriberId)
				on rur.UserId = ru.UserId 
				AND ru.AuthorityLevel = 'IndividualSubscriber'
				AND rur.RightsType = 'Subscriber'
				AND 1 = (SELECT COUNT(*) FROM RemoteUserRights rur2 where rur2.UserId = rur.UserId)
             WHERE UserName in ('jwoosnam','jamesremote44','jamesremote','xxxxxxxxxxxxxxx109054')


            SELECT 
				 SubscriberId = CASE WHEN sProp.SubscriberId IS NULL THEN s.SubscriberId ELSE sProp.SubscriberId END
				 ,BaseSubscriberId = CASE WHEN sProp.SubscriberId IS NULL THEN sProp.SubscriberId ELSE s.SubscriberId END
				 ,IsProposedSubscriber = CASE WHEN sProp.SubscriberId IS NULL THEN 0 ELSE 1 END
				 ,IsSpanishIJPESSubscriber = CASE WHEN sProp.SubscriberId IS NULL THEN s.IsSpanishIJPESSubscriber ELSE sProp.IsSpanishIJPESSubscriber END
             FROM RemoteUserRights rur
					INNER JOIN Subscriber s
						LEFT JOIN Subscriber sProp
						ON sProp.UpdateToSubscriberId = s.SubscriberId 
						AND sProp.SubscriberStatus = 'Proposed'
					ON s.SubscriberId = rur.RightsToId 
			WHERE rur.RightsType = 'Subscriber'
			AND 1 = (SELECT COUNT(*) FROM RemoteUserRights rur2 where rur2.UserId = rur.UserId)
            AND rur.UserId IN (8254,147)