use [PaDS_Try_Logs]
exec sp_dropsubscription @publication = N'PaDS_Try_Logs', @subscriber = N'PaDS02c', @destination_db = N'PaDS_Try_Logs', @article = N'all'
exec sp_droppublication @publication = N'PaDS_Try_Logs'
exec sp_replicationdboption @dbname = N'PaDS_Try_Logs', @optname = N'publish', @value = N'false'

use [PaDS_Live]
exec sp_dropsubscription @publication = N'PaDS_Live', @subscriber = N'PaDS02c', @destination_db = N'PaDS_Live', @article = N'all'
exec sp_droppublication @publication = N'PaDS_Live'
exec sp_replicationdboption @dbname = N'PaDs_Live', @optname = N'publish', @value = N'false'