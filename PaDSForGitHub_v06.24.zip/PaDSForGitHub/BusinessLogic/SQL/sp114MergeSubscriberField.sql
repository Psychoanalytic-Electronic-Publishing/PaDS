if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp114MergeSubscriberField]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp114MergeSubscriberField]
GO
CREATE  PROCEDURE sp114MergeSubscriberField (
				@FieldName varchar(100)
				,@MergeIntoSubscriberId INT  
				,@MergeFromSubscriberId INT
				,@MergeMessage varchar(4000) OUTPUT
				,@ErrorFound INT OUTPUT
				,@ErrorMessage varchar(200) OUTPUT
				)
AS

DECLARE @SQL VARCHAR(8000)
DECLARE @ROWCOUNT INT

IF @ErrorFound = 0
BEGIN
	CREATE Table #Message (Message varchar(4000))
	DELETE FROM #Message
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END

IF @ErrorFound = 0
BEGIN
	SET @SQL = '
	DECLARE @LfCr VARCHAR(2)
	SET @LfCr = CHAR(13) + CHAR(10)

	INSERT INTO #Message
	SELECT
			CASE WHEN ISNULL(CAST(MergeIntoSubscriber.' + @FieldName + ' as varchar),'''') <> ISNULL(CAST(MergeFromSubscriber.' + @FieldName + ' as varchar),'''') 
					AND ISNULL(CAST(MergeFromSubscriber.' + @FieldName + ' as VARCHAR),'''') <> ''''
				THEN  ''' + @FieldName + ' ['' + ISNULL(CASE WHEN ''WebUserPassword'' = ''' + @FieldName + ''' THEN ''****'' ELSE CAST(MergeFromSubscriber.' + @FieldName + ' as varchar) END ,'''') 
					+ ''] merged into ['' + ISNULL(CASE WHEN ''WebUserPassword'' = ''' + @FieldName + ''' THEN ''****'' ELSE CAST( MergeIntoSubscriber.' + @FieldName + ' as varchar) END,'''') + '']'' + @LfCr 
			ELSE ''''
			END
	FROM Subscriber MergeIntoSubscriber
		INNER JOIN Subscriber MergeFromSubscriber
		ON MergeFromSubscriber.SubscriberId = ' + CAST(@MergeFromSubscriberId as varchar) + '
	WHERE MergeIntoSubscriber.SubscriberId =' + CAST( @MergeIntoSubscriberId as varchar)
--print @sql
	EXECUTE(@SQL)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
IF @ErrorFound = 0
BEGIN
	SELECT @MergeMessage = @MergeMessage +  Message
	FROM #Message
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END	
IF @ErrorFound = 0
BEGIN
--21/10/20	James Woosnam	SIR5099 - Set LastUpdatedDateTime & LastUpdatedByUserId
	SET @SQL = '
	UPDATE Subscriber
	SET ' + @FieldName + ' = MergeFromSubscriber.' + @FieldName + '
		,LastUpdatedDateTime = CASE WHEN Subscriber.' + @FieldName + ' = MergeFromSubscriber.' + @FieldName + ' THEN Subscriber.LastUpdatedDateTime ELSE MergeFromSubscriber.LastUpdatedDateTime END
		,LastUpdatedByUserId = CASE WHEN Subscriber.' + @FieldName + ' = MergeFromSubscriber.' + @FieldName + ' THEN Subscriber.LastUpdatedByUserId ELSE MergeFromSubscriber.LastUpdatedByUserId END
	FROM Subscriber Subscriber
		INNER JOIN Subscriber MergeFromSubscriber
		ON MergeFromSubscriber.SubscriberId = ' + CAST(@MergeFromSubscriberId as varchar) + '
	WHERE Subscriber.SubscriberId =' + CAST( @MergeIntoSubscriberId as varchar) + '
	AND ISNULL(CAST(Subscriber.' + @FieldName + ' as VARCHAR),'''') <> ISNULL(CAST(MergeFromSubscriber.' + @FieldName + ' as VARCHAR),'''')
	AND ISNULL(CAST(MergeFromSubscriber.' + @FieldName + ' as VARCHAR),'''') <> ''''
	'
--print @sql
	EXECUTE(@SQL)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END

IF @ErrorFound <> 0
BEGIN 
	SELECT @ErrorMessage = 'Merge of Field ''' + @FieldName + ''' failed'
END

GO
