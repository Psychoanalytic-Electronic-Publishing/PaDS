if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp006UpdateCashbookBankDetails]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp006UpdateCashbookBankDetails]
GO
CREATE PROCEDURE sp006UpdateCashbookBankDetails @RecordsUpdated INT OUTPUT
AS
/* 	Updates the CardPaymentNuber to last 4 digits on Cashbook items more tahn 1 month old
	27/11/2007 Julian Gates Initial version
18/4/08		James Woosnam	Output info message
29/3/11		James Woosnam	Update to run from .NET
19/6/17		James Woosnam	Superceeded by sp009MaskCashbookCreditAndBankFields
*/
DECLARE @ErrorFound INT
--DECLARE @Message varchar(4000)
--DECLARE @ROWCOUNT INT
--	UPDATE Cashbook
--	SET 		PaymentCardNumber =   CASE WHEN LEN(ISNULL(PaymentCardNumber,'')) <6 THEN PaymentCardNumber
--								ELSE SUBSTRING('XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',1,LEN(PaymentCardNumber)-4)
--									+ Substring(PaymentCardNumber,LEN(PaymentCardNumber)-3,4)
--								END
--		,BankAccountNumber =   CASE WHEN LEN(ISNULL(BankAccountNumber,'')) <6 THEN BankAccountNumber
--								ELSE SUBSTRING('XXXXXXXXXXXXXXXX',1,LEN(BankAccountNumber)-4)
--									+ Substring(BankAccountNumber,LEN(BankAccountNumber)-3,4)
--								END
--	WHERE EntryDate < DateAdd(M,-1,GetDate())
--	AND (LEN(ISNULL(PaymentCardNumber,'')) >5
--		OR LEN(ISNULL(BankAccountNumber,'')) >5)
--	AND LEFT(ISNULL(PaymentCardNumber,''),2) <> 'XX'
--	AND LEFT(ISNULL(BankAccountNumber,''),2) <> 'XX'
--	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
--	SET @RecordsUpdated = @ROWCOUNT
RETURN(@ErrorFound)
GO

