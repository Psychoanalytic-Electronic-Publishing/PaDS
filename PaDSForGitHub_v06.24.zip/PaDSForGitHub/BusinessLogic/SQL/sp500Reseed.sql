if exists (select * from dbo.sysobjects where id = object_id(N'[sp500Reseed]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [sp500Reseed]
GO
CREATE PROCEDURE [dbo].[sp500Reseed]
AS
-- =============================================
-- Author:		Mike Sheard 
-- Create date: 30 March 2010
-- Description:	Reseeds tables with identity columns
-- =============================================
BEGIN
	SET NOCOUNT ON;
	--DBCC CHECKIDENT ( [PaDS_Logs.dbo.SessionLog], RESEED)
	DBCC CHECKIDENT ( [PaDS_Logs.dbo.AuditLog], RESEED)
	DBCC CHECKIDENT ( [PaDS_Live.dbo.SalesOrderLine], RESEED)
	DBCC CHECKIDENT ( [PaDS_Live.dbo.DiscountRate], RESEED)
	DBCC CHECKIDENT ( [PaDS_Live.dbo.tmpSubscriberImport], RESEED)
	BEGIN TRY
		--ALTER TABLE PaDS_Logs.dbo.SessionLog ADD CONSTRAINT
		--DF_SessionLog_Date DEFAULT (getdate()) FOR Date
		
		ALTER TABLE dbo.SalesOrder ADD CONSTRAINT
			DF_SalesOrder_IsPaid DEFAULT (0) FOR IsPaid

		ALTER TABLE dbo.SalesOrderLine ADD CONSTRAINT
			DF_SalesOrderLine_IsCancel DEFAULT (0) FOR IsCancel

		ALTER TABLE dbo.Subscriber ADD CONSTRAINT
			DF_Subscriber_IsAccount DEFAULT (0) FOR IsAccount

		ALTER TABLE dbo.Subscriber ADD CONSTRAINT
			DF_Subscriber_IsReceiveMail DEFAULT (0) FOR IsReceiveMail

		ALTER TABLE dbo.Subscriber ADD CONSTRAINT
			DF_Subscriber_IsTrainingAnalyst DEFAULT (0) FOR IsTrainingAnalyst

		ALTER TABLE dbo.Subscriber ADD CONSTRAINT
			DF_Subscriber_IsChildAnalyst DEFAULT (0) FOR IsChildAnalyst

		ALTER TABLE dbo.Subscriber ADD CONSTRAINT
			DF_Subscriber_IsRetired DEFAULT (0) FOR IsRetired
			
		ALTER TABLE dbo.Cashbook ADD CONSTRAINT
			DF_Cashbook_IsReceiptMailed DEFAULT (0) FOR IsReceiptMailed

		ALTER TABLE dbo.Cashbook ADD CONSTRAINT
			DF_Cashbook_IsContrad DEFAULT (0) FOR IsContrad			

	END TRY
	BEGIN CATCH
	END CATCH
END