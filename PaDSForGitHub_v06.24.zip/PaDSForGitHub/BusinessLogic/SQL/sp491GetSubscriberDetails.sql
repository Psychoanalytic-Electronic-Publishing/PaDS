if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp491GetSubscriberDetails]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp491GetSubscriberDetails]
GO


CREATE  PROCEDURE sp491GetSubscriberDetails (
				 @SubscriberId INT  
				,@GroupSubscriberId INT	
				,@CompanyId INT 
				)
AS
--31/3/11    James Woosnam   SIR2401 - Use the company specific address if available else use latest address
--16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone numbers
--19/11/19	James Woosnam	SIR4763 - Use IndividualUsers in RemoteUser table
DECLARE @Delimiter VARCHAR(2)
SET @Delimiter = Char(13) + CHAR(10)

SELECT Distinct CompanyAffiliate.SubscriberCategory
	,Subscriber.FirstName
	,Subscriber.LastName 
	,Subscriber.SubscriberName 
	,Subscriber.EntityType 
	,Title = ISNULL(Subscriber.Title,'')
	,Subscriber.VATNumber
	,MailMethod = ISNULL(Subscriber.MailMethod,'')
	,Subscriber.Salutation
	,ISNULL(Email.AddressText,'') As EmailAddress
	,BuildingStreet = 		CASE 	(CASE IsNull( MainPostal.Address1 , '' )  WHEN '' THEN '' ELSE MainPostal.Address1 + @Delimiter END 
			+ CASE IsNull( MainPostal.Address2 , '' )  WHEN '' THEN '' ELSE MainPostal.Address2 + @Delimiter END 
			+ CASE IsNull( MainPostal.Address3 , '' )  WHEN '' THEN '' ELSE MainPostal.Address3 + @Delimiter END 
			+ CASE IsNull( MainPostal.Address4 , '' )  WHEN '' THEN '' ELSE MainPostal.Address4 + @Delimiter END 
 			) WHEN '' THEN ''
		ELSE
		    (	LEFT(
				CASE IsNull( MainPostal.Address1 , '' )  WHEN '' THEN '' ELSE MainPostal.Address1 + @Delimiter END 
				+ CASE IsNull( MainPostal.Address2 , '' )  WHEN '' THEN '' ELSE MainPostal.Address2 + @Delimiter END 
				+ CASE IsNull( MainPostal.Address3 , '' )  WHEN '' THEN '' ELSE MainPostal.Address3 + @Delimiter END 
				+ CASE IsNull( MainPostal.Address4 , '' )  WHEN '' THEN '' ELSE MainPostal.Address4 + @Delimiter END 
			, LEN(
				CASE IsNull( MainPostal.Address1 , '' )  WHEN '' THEN '' ELSE MainPostal.Address1 + @Delimiter END 
				+ CASE IsNull( MainPostal.Address2 , '' )  WHEN '' THEN '' ELSE MainPostal.Address2 + @Delimiter END 
				+ CASE IsNull( MainPostal.Address3 , '' )  WHEN '' THEN '' ELSE MainPostal.Address3 + @Delimiter END 
				+ CASE IsNull( MainPostal.Address4 , '' )  WHEN '' THEN '' ELSE MainPostal.Address4 + @Delimiter END 
			      ) - 2 
			     )
		     )
		END
	,MainPostal.Town  AS Town
	,MainPostal.County  AS County
	,MainPostal.PostCode  AS PostCode
	,ISNULL(Country.CountryId,0)  AS Country
	,ISNULL(Subscriber.Spare1,'') AS OperatingSystem
	,ru.UserName 
	,SubscriberAffiliate.StartDate
	,SubscriberAffiliate.EndDate
	,SubscriberAffiliate.ParentSubscriberId as GroupSubscriberId
FROM Subscriber  
	LEFT JOIN RemoteUserRights rur
		INNER JOIN RemoteUser ru
		ON ru.UserId = rur.UserId 
	ON rur.RightsToId = Subscriber.SubscriberId 
	AND rur.RightsType = 'Subscriber'
	INNER JOIN Company c
	ON c.CompanyId = @CompanyId 
--31/3/11    James Woosnam   SIR2401 - Use the company specific address if available else use latest address
	LEFT JOIN SubscriberAddress MainPostal
	ON MainPostal.SubscriberAddressId = (SELECT top 1 sa.SubscriberAddressId
											FROM SubscriberAddress sa
											WHERE(sa.SubscriberId = Subscriber.SubscriberId)
											AND sa.AddressType = 'Postal'
											AND sa.AddressDescription <> 'Redundant'
											Order BY CASE WHEN  sa.AddressDescription = c.DefaultAddressDescription THEN 0 ELSE 1 End
											,sa.LastUpdatedDateTime 
										)
	LEFT JOIN SubscriberAddress Email
	ON Email.SubscriberId = Subscriber.SubscriberId 
	AND Email.AddressType = 'Email' 
	AND Email.AddressDescription = 'Main' 
	LEFT JOIN Country
	ON Country.CountryId = MainPostal.CountryId
	LEFT JOIN SubscriberAffiliate
	On SubscriberAffiliate.ChildSubscriberId = Subscriber.SubscriberId
	AND SubscriberAffiliate.ParentSubscriberId = @GroupSubscriberId
	LEFT JOIN SubscriberAffiliate CompanyAffiliate
	On CompanyAffiliate.ChildSubscriberId = Subscriber.SubscriberId
	AND CompanyAffiliate.ParentSubscriberId = c.GroupParentSubscriberId
WHERE Subscriber.SubscriberId = @SubscriberId 

Go 
