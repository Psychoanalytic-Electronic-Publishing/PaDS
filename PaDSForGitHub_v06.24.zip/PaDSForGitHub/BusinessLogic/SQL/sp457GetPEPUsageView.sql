IF  exists (select * from dbo.sysobjects where id = object_id(N'sp457GetPEPUsageView') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp457GetPEPUsageView 
GO
CREATE  PROCEDURE sp457GetPEPUsageView (
					@StartDate DATETIME = '01-Feb-2021'
					,@EndDate DATETIME = '31-dec-4949'
					,@ViewType VARCHAR(50) = 'SummaryByAffiliate'
					,@AffiliateRateSubscriberId INT = NULL --American Psychological Association - Division 39
)
AS
DECLARE @Message VARCHAR(MAX) = ''

IF @ViewType = 'SummaryByAffiliate'
BEGIN
	SELECT
		u.AffiliateRateSubscriberId 
		,u.AffiliateRateSubscriberName
		,UserActivitySessionCount = ISNULL(sum(u.UserActivitySessionCount ),0)
		,AbstractCount = ISNULL(SUM(u.AbstractCount),0)
		,ReadCount = ISNULL(SUM(u.ReadCount),0)
		,SearchCount = ISNULL(SUM(u.SearchCount),0)
		,TurnAwayCount = ISNULL(SUM(CASE WHEN ActionType = 'FailedRead' THEN 1 ELSE 0 END ),0) --27/11/21	James	SIR5374 - Add TurnAwayCount
		,RecordCount = COUNT(*)
	FROM PEPUsage u
	WHERE u.DateTime BETWEEN @StartDate AND @EndDate 
	GROUP BY
		u.AffiliateRateSubscriberId
		,u.AffiliateRateSubscriberName 
	ORDER BY 
		ISNULL(SUM(u.ReadCount),0) desc
		,u.AffiliateRateSubscriberName 
END

IF @ViewType = 'DetailByAffiliate'
BEGIN
	SELECT
		AffiliateRateSubscriberName
		,AffiliateRateSubscriberId
		,AffiliateRateType
		,LoggedInMethod
		,DateDay
		,Year
		,Quarter
		,Month
		,UserCountry
		,PEPCode
		,DocumentVolume
		,DocumentYear
		--,authorMast
		--,DocumentId
		--,documentRef		
		,UserActivitySessionCount = ISNULL(sum(u.UserActivitySessionCount ),0)
		,AbstractCount = ISNULL(SUM(u.AbstractCount),0)
		,ReadCount = ISNULL(SUM(u.ReadCount),0)
		,SearchCount = ISNULL(SUM(u.SearchCount),0)
		,TurnAwayCount = ISNULL(SUM(CASE WHEN ActionType = 'FailedRead' THEN 1 ELSE 0 END ),0) --27/11/21	James	SIR5374 - Add TurnAwayCount
	FROM PEPUsage u
	WHERE u.DateTime BETWEEN @StartDate AND @EndDate 
	GROUP BY
		AffiliateRateSubscriberName
		,AffiliateRateSubscriberId
		,AffiliateRateType
		,LoggedInMethod
		,DateDay
		,Year
		,Quarter
		,Month
		,UserCountry
		,PEPCode
		,DocumentVolume
		,DocumentYear
		--,authorMast
		--,DocumentId
		--,documentRef	
	ORDER BY 
		AffiliateRateSubscriberName 
		,DateDay
		,PEPCode
END
IF @ViewType = 'SingleAffiliateDetail'
BEGIN
	IF @AffiliateRateSubscriberId IS NULL 
	BEGIN
		SELECT @Message ='ViewType:' + @ViewType + ' requires @AffiliateRateSubscriberId'
		RAISERROR ('%s', 18, 1,@Message)
	END
	SELECT
		AffiliateRateSubscriberName
		,AffiliateRateSubscriberId
		,AffiliateRateType
		,UserName
		,UserFullName
		,DateDay
		,Year
		,Quarter
		,Month
		,OrderNumber
		,UserCountry
		,SubscriptionEndDate
		,LoggedInMethod
		,DocumentId
		,documentRef
		,PEPCode
		,DocumentVolume
		,DocumentYear
		,authorMast
		,UserActivitySessionCount = ISNULL(sum(u.UserActivitySessionCount ),0)
		,AbstractCount = ISNULL(SUM(u.AbstractCount),0)
		,ReadCount = ISNULL(SUM(u.ReadCount),0)
		,SearchCount = ISNULL(SUM(u.SearchCount),0)
		,TurnAwayCount = ISNULL(SUM(CASE WHEN ActionType = 'FailedRead' THEN 1 ELSE 0 END ),0) --27/11/21	James	SIR5374 - Add TurnAwayCount
	FROM PEPUsage u
	WHERE u.DateTime BETWEEN @StartDate AND @EndDate 
	AND u.AffiliateRateSubscriberId = @AffiliateRateSubscriberId
	GROUP BY
		AffiliateRateSubscriberName
		,AffiliateRateSubscriberId
		,AffiliateRateType
		,UserName
		,UserFullName
		,DateDay
		,Year
		,Quarter
		,Month
		,OrderNumber
		,UserCountry
		,SubscriptionEndDate
		,LoggedInMethod
		,DocumentId
		,documentRef
		,PEPCode
		,DocumentVolume
		,DocumentYear
		,authorMast
	ORDER BY 
		AffiliateRateSubscriberName 
		,UserFullName 
END
GO
GRANT  EXECUTE ON sp457GetPEPUsageView TO PaDSSQLServerUser

--EXEC sp457GetPEPUsageView @ViewType = 'SummaryByAffiliate'
--EXEC sp457GetPEPUsageView @ViewType = 'DetailByAffiliate'
--EXEC sp457GetPEPUsageView @ViewType = 'SingleAffiliateDetail'	,@AffiliateRateSubscriberId=49337