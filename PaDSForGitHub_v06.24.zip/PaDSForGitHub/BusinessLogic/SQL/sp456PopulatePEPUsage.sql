IF  exists (select * from dbo.sysobjects where id = object_id(N'sp456PopulatePEPUsage') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp456PopulatePEPUsage 
GO
CREATE  PROCEDURE sp456PopulatePEPUsage (
					@BatchLogId INT = NULL
)
AS
DECLARE @RowCount INT = 0
	,@Message VARCHAR(MAX) = ''
DECLARE @ActivityLogLastPEPWebLogId INT=0
		,@ActivityLogLastPEPWebSessionLogIdAbstracts INT=0
		,@ActivityLogLastPEPWebSessionLogIdSearches INT=0
		,@AddFromDate DATETIME  = '01-feb-2021'


--IF NOT EXISTS(SELECT * FROM SYSOBJECTS WHERE Name='PEPUsage' ) EXECUTE('CREATE View PEPUsage AS SELECT * FROM [pads01].[PaDS_PEP_Activity_Log].dbo.PEPUsage')
IF NOT EXISTS(SELECT * FROM SYSOBJECTS WHERE Name='PEPUsage' ) EXECUTE('CREATE View PEPUsage AS SELECT * FROM [PaDS_PEP_Usage].dbo.PEPUsage')
IF EXISTS(SELECT PEPUsageId FROM PEPUsage) SELECT @AddFromDate = DATEADD(DAY,-1,min(mDate)) 
											FROM (SELECT mDate = MAX(DateTime) FROM PEPUsage WHERE ActionType  IN ('FullRead','FailedRead')
												UNION SELECT mDate = MAX(DateTime) FROM PEPUsage WHERE ActionType  IN ('Abstract')
												UNION SELECT mDate = MAX(DateTime) FROM PEPUsage WHERE ActionType  IN ('Search')
												) a

IF @BatchLogId IS NULL SELECT @BatchLogId = (SELECT MAX(BatchLogId) FROM BatchLog	)
	SELECT 
		us.UserSessionId 
		,UserId = MAX(us.UserId )
		,UserName = MAX(us.UserName )
		,UserFullName = MAX(CONVERT(VARCHAR(50),CASE WHEN usd.DataItemName = 'UserFullName' THEN usd.DataItemValue ELSE NULL END))
		,SubscriberId = MAX(CONVERT(INT,CASE WHEN usd.DataItemName = 'SubscriberId' THEN usd.DataItemValue ELSE NULL END))
		,SubscriberName = CAST(NULL AS VARCHAR(150))
		,OrderNumber = MAX(CONVERT(INT,CASE WHEN usd.DataItemName  = 'SubscriptionOrderNumber' THEN usd.DataItemValue ELSE NULL END))
		,SubscriptionEndDate = MAX(CONVERT(DATETIME,CASE WHEN usd.DataItemName  = 'SubscriptionEndDate' THEN usd.DataItemValue ELSE NULL END))
		,LoggedInMethod = MAX(CONVERT(VARCHAR(50),CASE WHEN usd.DataItemName  = 'LoggedInMethod' THEN usd.DataItemValue ELSE NULL END))
		,UserType = MAX(CONVERT(VARCHAR(50),CASE WHEN usd.DataItemName = 'UserType' THEN usd.DataItemValue ELSE NULL END))
		,UserCountry =CAST(NULL AS VARCHAR(150))
		,AffiliateRateSubscriberName =CAST(NULL AS VARCHAR(150))
		,AffiliateRateSubscriberId = CAST(NULL AS INT)
		,AffiliateRateType = CAST(NULL AS VARCHAR(20) )
	INTO #SessOrder
	FROM UserSession us  With (nolock)
		INNER JOIN UserSessionData usd  With (nolock)
		ON usd.UserSessionId = us.UserSessionId 
	WHERE us.LastAccessedDate >= @AddFromDate
	 and us.UserId <> -1
	GROUP BY
		us.UserSessionId 
		,us.UserId 
		,us.UserName 
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #SessOrder records added';PRINT @Message;PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message
--19/10/21	James Woosnam	SIR5348 - Allow for Admin users
	UPDATE #SessOrder
	SET SubscriberName = s.SubscriberName
		,AffiliateRateSubscriberId =  CASE 
											WHEN sess.userType = 'Admin' AND so.orderNumber IS NULL THEN -3
											WHEN so.orderNumber IS NULL THEN -2
											WHEN so.AffiliateRateSubscriberId = 0 THEN -1
										ELSE so.AffiliateRateSubscriberId END
		,AffiliateRateSubscriberName = CASE 
											WHEN sess.userType = 'Admin' AND so.orderNumber IS NULL  THEN '**Admin Users**' 
											WHEN so.orderNumber IS NULL THEN '**No Subscription Users**' 
											WHEN so.AffiliateRateSubscriberId = 0 THEN '**Individual Subscription Users**'
										ELSE so.AffiliateRateSubscriberName END
		,AffiliateRateType = CASE
								WHEN sess.userType = 'Admin' AND so.orderNumber IS NULL  THEN 'Admin' 
								 WHEN so.orderNumber IS NULL THEN 'NoSubscription' 
								 WHEN so.AffiliateRateSubscriberId = 0 THEN 'IndividualUser'
										ELSE so.AffiliateRateType END
		,UserCountry = ISNULL((SELECT c.CountryName FROM Country c WHERE c.CountryId= s.PrimaryCountryId ),'Unknown')
	FROM #SessOrder sess
		LEFT JOIN Subscriber s
		ON s.SubscriberId = sess.SubscriberId
		LEFT JOIN vw430SalesDetails so
		ON so.OrderNumber = sess.OrderNumber
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #SessOrder records updated';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message


	SELECT *
	INTO #Log
	FROM PEPUsage
	WHERE 1=2
	SET @RowCount = @@ROWCOUNT ;SET @Message =' #Log Table Created';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message

--Add FullReads 
	SELECT @ActivityLogLastPEPWebLogId = ISNULL(MAX(FromLogRecordWithId),0) FROM PEPUsage WHERE ActionType IN ('FullRead','FailedRead')
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@ActivityLogLastPEPWebLogId=' +CAST(@ActivityLogLastPEPWebLogId AS VARCHAR(20)) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	INSERT INTO #Log ( FromLogRecordWithId,	DateTime,	DateDay,	DateHour,	HourNumber,	GroupUserSessionBy,	Year,	Quarter,	Month,	ActionType,	LogonLocation,	LogonStatus,	LoggedUserName,	UserName,	UserFullName,	AffiliateRateSubscriberName,	AffiliateRateSubscriberId,	AffiliateRateType,	OrderNumber,	UserCountry,	ReasonForCheck,	SubscriptionEndDate,	LoggedInMethod,	DocumentId,	UserSessionId, ReadCount)
	SELECT
		FromLogRecordWithId = l.PEPWebUsageLogId 
		,l.DateTime 
		,DateDay = FORMAT(l.DateTime ,'dd-MMM-yy')
		,DateHour = FORMAT(l.DateTime ,'dd-MMM-yy HH') + ':00:00'
		,HourNumber = FORMAT(l.DateTime ,'HH')
		,GroupUserSessionBy = FORMAT(l.DateTime ,'dd-MMM-yy') --day
		,rc.[Year]
		,rc.[Quarter]
		,rc.[Month]
		,ActionType = CASE 
							WHEN  l.LogonStatus  = 'Success' THEN 'FullRead' 
							WHEN  l.LogonStatus  = 'Failed' THEN 'FailedRead' 
							--WHEN l.ActionType = 'Authorise' THEN 'Abstract' SIR5325 - Abstracts now from OPAS Log below
							ELSE 'Unknown'  + ISNULL(l.LogonStatus,'')   END
		,l.LogonLocation 
		,l.LogonStatus 
		,LoggedUserName = so.UserName 
		,so.UserName   
		,so.UserFullName   
		,so.AffiliateRateSubscriberName
		,so.AffiliateRateSubscriberId
		,so.AffiliateRateType 
		,so.OrderNumber 
		,so.UserCountry
		,l.ReasonForCheck
		,so.SubscriptionEndDate
		,so.LoggedInMethod
		,l.DocumentId 
		,l.UserSessionId
		,ReadCount = CASE 
							WHEN  l.LogonStatus  = 'Success' THEN 1 
							ELSE 0  END
	FROM PEPWebUsageLog l
		INNER JOIN #SessOrder so
		ON so.UserSessionId = l.UserSessionId 
		left join contentdocuments d
			left join contentjournals j
			on j.pepcode = d.pepcode
		on d.DocumentId = l.DocumentId collate database_default
		LEFT JOIN ReportingCalendar rc
		ON rc.CalendarDate = CAST(FORMAT(l.DateTime ,'dd-MMM-yy') AS DATETIME)
	where 1=1
	AND l.PEPWebUsageLogId > @ActivityLogLastPEPWebLogId
	and l.DateTime >= @AddFromDate
	and l.LogonLocation = 'PEPSecurity'
	AND isnumeric(l.username)=1
	AND l.ActionType = 'Authorise'
	AND l.ReasonForCheck  = 'DocumentView'
	
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #Log records add for Reads';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message

--Abstracts
	SELECT @ActivityLogLastPEPWebSessionLogIdAbstracts = ISNULL(MAX(FromLogRecordWithId),0) FROM PEPUsage WHERE ActionType IN ('Abstract')
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@ActivityLogLastPEPWebSessionLogIdAbstracts=' +CAST(@ActivityLogLastPEPWebSessionLogIdAbstracts AS VARCHAR(20)) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	INSERT INTO #Log (FromLogRecordWithId,	 DateTime,	DateDay,	DateHour,	HourNumber,	GroupUserSessionBy,	Year,	Quarter,	Month,	ActionType,	LogonLocation,	LogonStatus,	LoggedUserName,	UserName,	UserFullName,	AffiliateRateSubscriberName,	AffiliateRateSubscriberId,	AffiliateRateType,	OrderNumber,	UserCountry,	ReasonForCheck,	SubscriptionEndDate,	LoggedInMethod,	DocumentId,	UserSessionId, AbstractCount)
	SELECT
		FromLogRecordWithId=l.PEPWebSessionLogId 
		,l.LastUpdate 
		,DateDay = FORMAT(l.LastUpdate ,'dd-MMM-yy')
		,DateHour = FORMAT(l.LastUpdate ,'dd-MMM-yy HH') + ':00:00'
		,HourNumber = FORMAT(l.LastUpdate ,'HH')
		,GroupUserSessionBy = FORMAT(LastUpdate,'yyyy-MM-dd HH:mm:ss')--For search each one counts
		,rc.[Year]
		,rc.[Quarter]
		,rc.[Month]
		,ActionType = 'Abstract'
		,LogonLocation = 'PEPSecurity'
		,LogonStatus ='Success'
		,LoggedUserName = so.UserName 
		,so.UserName   
		,so.UserFullName   
		,so.AffiliateRateSubscriberName
		,so.AffiliateRateSubscriberId
		,so.AffiliateRateType 
		,so.OrderNumber 
		,so.UserCountry
		,ReasonForCheck = 'AbstractView'
		,SubscriptionEndDate = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='SubscriptionEndDate' AND usd.UserSessionId = CAST(l.UserSessionId AS uniqueidentifier ))
		,LoggedInMethod = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='LoggedInMethod' AND usd.UserSessionId = CAST(l.UserSessionId AS uniqueidentifier ) )
		,DocumentId = l.ItemOfInterest 
		,l.UserSessionId
		,AbstractCount=1
	FROM PEPWebSessionLog l
		INNER JOIN #SessOrder so
		ON so.UserSessionId = l.UserSessionId 
		LEFT JOIN ReportingCalendar rc
		ON rc.CalendarDate = CAST(FORMAT(l.LastUpdate ,'dd-MMM-yy') AS DATETIME)
	where 1=1
	AND l.PEPWebSessionLogId > @ActivityLogLastPEPWebSessionLogIdAbstracts
	AND l.Endpoint = '/Documents/Abstracts/{documentID}/'
	AND l.ReturnAddedStatusMessage LIKE '%Success%'
	and l.LastUpdate >= @AddFromDate
	
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #Log records add for Abstracts';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message


	UPDATE #Log 
	SET documentRef = ISNULL(d.documentRef ,b.title )
		,PEPCode = ISNULL(c.PEPCode,b.PEPCode)
		,DocumentVolume=ISNULL(d.vol ,0)
		,DocumentYear=ISNULL(d.year ,b.pub_year )
		,authorMast=ISNULL(d.authorMast ,b.authors  )
	FROM #Log l
			LEFT JOIN ContentDocuments d
				LEFT JOIN (
					SELECT j.PEPCode 
						,j.sourceType 
						,j.Title 
						,j.ISSN 
						,ISBN = CAST('' AS VARCHAR(50))
						,j.language 
						,Data_Type = CAST('Journal' AS VARCHAR(50))
					FROM ContentJournals j
					UNION
					SELECT v.PEPCode 
						,v.sourceType 
						,v.Title 
						,v.ISSN 
						,ISBN = CAST('' AS VARCHAR(50))
						,v.language 
						,Data_Type = CAST('Multimedia' AS VARCHAR(50))
					FROM ContentVideos v
					) c
				ON c.PEPCode = d.PEPCode 
			ON d.documentID = l.DocumentId 
			LEFT JOIN (
				SELECT b.PEPCode 
					,b.sourceType 
					,b.documentID 
					,b.Title 
					,b.ISSN 
					,ISBN = b.ISBN13 
					,b.language
					,Data_Type = 'Book' --Might be book????  Book_Segment  A book segment (e.g. chapter, section, etc.). Note that Data_Type Book_Segment is only applicable for Item Reports when the book segment is the item, in Title Reports this is represented by the Section_Type.
					,b.pub_year
					,b.authors 
				FROM ContentBooks b
				) b
			on b.documentID = l.DocumentId  
			or replace(l.DocumentId ,'.','') like b.PEPCode + '%'
		WHERE ISNULL(l.DocumentId,'')<>''
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #Log updated with document info';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message

--Add Searches
	SELECT @ActivityLogLastPEPWebSessionLogIdSearches = ISNULL(MAX(FromLogRecordWithId),0) FROM PEPUsage WHERE ActionType IN ('Search')
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@ActivityLogLastPEPWebSessionLogIdSearches=' +CAST(@ActivityLogLastPEPWebSessionLogIdSearches AS VARCHAR(20)) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message
	INSERT INTO #Log (FromLogRecordWithId,	 DateTime,	DateDay,	DateHour,	HourNumber,	GroupUserSessionBy,	Year,	Quarter,	Month,	ActionType,	LogonLocation,	LogonStatus,	LoggedUserName,	UserName,	UserFullName,	AffiliateRateSubscriberName,	AffiliateRateSubscriberId,	AffiliateRateType,	OrderNumber,	UserCountry,	ReasonForCheck,	SubscriptionEndDate,	LoggedInMethod,	UserSessionId, SearchCount)
	SELECT
		FromLogRecordWithId=l.PEPWebSessionLogId 
		,l.LastUpdate 
		,DateDay = FORMAT(l.LastUpdate ,'dd-MMM-yy')
		,DateHour = FORMAT(l.LastUpdate ,'dd-MMM-yy HH') + ':00:00'
		,HourNumber = FORMAT(l.LastUpdate ,'HH')
		,GroupUserSessionBy = FORMAT(LastUpdate,'yyyy-MM-dd HH:mm:ss')--For search each one counts
		,rc.[Year]
		,rc.[Quarter]
		,rc.[Month]
		,ActionType = 'Search'
		,LogonLocation = 'PEPSecurity'
		,LogonStatus ='Success'
		,LoggedUserName = so.UserName 
		,so.UserName   
		,so.UserFullName   
		,so.AffiliateRateSubscriberName
		,so.AffiliateRateSubscriberId
		,so.AffiliateRateType 
		,so.OrderNumber 
		,so.UserCountry
		,ReasonForCheck = 'Search'
		,SubscriptionEndDate = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='SubscriptionEndDate' AND usd.UserSessionId = CAST(l.UserSessionId AS uniqueidentifier ))
		,LoggedInMethod = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='LoggedInMethod' AND usd.UserSessionId = CAST(l.UserSessionId AS uniqueidentifier ) )
		,l.UserSessionId
		,SearchCount=1
	FROM PEPWebSessionLog l
		INNER JOIN #SessOrder so
		ON so.UserSessionId = l.UserSessionId 
		LEFT JOIN ReportingCalendar rc
		ON rc.CalendarDate = CAST(FORMAT(l.LastUpdate ,'dd-MMM-yy') AS DATETIME)
	where 1=1
	AND l.PEPWebSessionLogId>@ActivityLogLastPEPWebSessionLogIdSearches
	AND l.Endpoint = '/Database/Search/'
	AND l.Params LIKE '%user=true%'
	and l.LastUpdate >= @AddFromDate
	
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #Log records add for searches';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message

	UPDATE #Log 
	SET UserActivitySessionCount = l2.UserActivitySessionCount 
		,PaDSSessionDurationMinutes = l2.PaDSSessionDurationMinutes 
	FROM #Log l
		INNER JOIN (
	SELECT
	l.PEPUsageId
	,UserActivitySessionCount  =CASE WHEN DATEDIFF(MINUTE,ISNULL(llast.DateTime,'01-jan-1900'),l.DateTime) > 30 THEN 1 ELSE 0 END
	,PaDSSessionDurationMinutes = DATEDIFF(MINUTE,(SELECT MIN(l2.DateTime) FROM #Log l2 WHERE l2.UserSessionId = l.UserSessionId) , (SELECT MAX(l3.DateTime) FROM #Log l3 WHERE l3.UserSessionId = l.UserSessionId))
	FROM #Log l
		LEFT JOIN #Log lLast
		ON lLast.UserSessionId = l.UserSessionId 
		AND lLast.PEPUsageId <> l.PEPUsageId 
		AND lLast.DateTime <= l.DateTime 
		AND lLast.PEPUsageId = (SELECT MAX(l3.PEPUsageId) 
						FROM #Log l3
						WHERE l3.UserSessionId = l.UserSessionId 
						and l3.PEPUsageId <> l.PEPUsageId 
						AND l3.DateTime <= l.DateTime )
	 ) l2
	ON l2.PEPUsageId = l.PEPUsageId 
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #Log updated with SessionCount and Duration';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message


	INSERT INTO PEPUsage
		(FromLogRecordWithId	,DateTime	,DateDay	,DateHour	,HourNumber	,GroupUserSessionBy	,Year	,Quarter	,Month	,ActionType	,LogonLocation	,LogonStatus	,LoggedUserName	,UserName	,UserFullName	,AffiliateRateSubscriberName	,AffiliateRateSubscriberId	,AffiliateRateType	,OrderNumber	,UserCountry	,ReasonForCheck	,SubscriptionEndDate	,LoggedInMethod	,DocumentId	,documentRef	,PEPCode	,DocumentVolume	,DocumentYear	,authorMast	,UserSessionId	,UserActivitySessionCount	,AbstractCount	,ReadCount	,SearchCount	,PaDSSessionDurationMinutes)
	SELECT 
		 FromLogRecordWithId	,DateTime	,DateDay	,DateHour	,HourNumber	,GroupUserSessionBy	,Year	,Quarter	,Month	,ActionType	,LogonLocation	,LogonStatus	,LoggedUserName	,UserName	,UserFullName	,AffiliateRateSubscriberName	,AffiliateRateSubscriberId	,AffiliateRateType	,OrderNumber	,UserCountry	,ReasonForCheck	,SubscriptionEndDate	,LoggedInMethod	,DocumentId	,documentRef	,PEPCode	,DocumentVolume	,DocumentYear	,authorMast	,UserSessionId	,UserActivitySessionCount	,AbstractCount	,ReadCount	,SearchCount	,PaDSSessionDurationMinutes
	FROM #Log
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' records added to PEPUsage';PRINT @Message;EXEC sp029UpdateBatchLog @BatchLogId, @Message
/*
select 
l.AffiliateRateSubscriberId
,l.AffiliateRateSubscriberName 
,l.Month 
,UserActivitySessionCount = sum(l.UserActivitySessionCount )
,AbstractCount = sum(l.AbstractCount )
,ReadCount = sum(l.ReadCount )
,SearchCount = sum(l.SearchCount )

from PEPUsage l
Group by
l.AffiliateRateSubscriberId
,l.AffiliateRateSubscriberName 
,l.Month 

order by 
l.Month desc
,l.AffiliateRateSubscriberName 


*/
DROP TABLE #Log
GO
--EXEC sp456PopulatePEPUsage