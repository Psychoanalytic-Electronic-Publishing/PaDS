if exists (select * from sysobjects where id = object_id(N'trgSubscriberEmailAddressUserSync') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER trgSubscriberEmailAddressUserSync
Go
CREATE TRIGGER trgSubscriberEmailAddressUserSync ON [SubscriberAddress]
FOR Update,Insert
AS
--10/1/20	James Woosnam	SIR4977 - Initial version
--05/10/21	Julian Gates	SIR5337 - Only Sync for AuthorityLevel = 'IndividualSubscriber'
--10/1/22	James Woosnam	SIR5403 - Look for a running import started in last minute for this subscriber where OverwriteWebUserName is no,if found then stop username update
UPDATE RemoteUser
SET UserName = CASE WHEN ru.EmailAddress=ru.UserName Then inserted.AddressText ELSE ru.UserName END
	,LastUpdatedDateTime = INSERTED.LastUpdatedDateTime 
	,LastUpdatedByUserId  = INSERTED.LastUpdatedByUserId 
FROM RemoteUser ru
	INNER JOIN RemoteUserRights rur

	ON rur.UserId = ru.UserId 
	AND rur.RightsType = 'Subscriber'
	INNER JOIN INSERTED
	ON INSERTED.SubscriberId = rur.RightsToId 
	AND inserted.AddressType = 'Email'
	AND inserted.AddressDescription = 'Main'
WHERE ru.AuthorityLevel = 'IndividualSubscriber'
--10/1/22	James Woosnam	SIR5403 - Look for a running import started in last minute for this subscriber where OverwriteWebUserName is no,if found then stop username update
--13/1/22	James Woosnam	SIR5403 - Changed to last 30 minutes as SPI took 15 minutes to import
AND NOT EXISTS(
		SELECT sib.SubscriberImportBatchId 
		FROM SubscriberImportBatch sib
			inner JOIN tmpSubscriberImport tsi
				inner JOIN SubscriberAffiliate sa
					inner JOIN Subscriber s
					On s.SubscriberId = sa.ChildSubscriberId
					AND s.SubscriberStatus in ('Current','Proposed')
				On  sa.AffiliateReferenceID = tsi.AffiliateReferenceID
				AND sa.ParentSubscriberID = tsi.GroupSubscriberId
				AND  GETDATE() BETWEEN sa.StartDate and sa.EndDate
			ON tsi.SubscriberImportBatchId = sib.SubscriberImportBatchId 
			AND rur.RightsToId  = CASE ISNULL(tsi.DuplicateAction,'') WHEN 'Selected' THEN tsi.DuplicateSubscriberIdToUse 
									ELSE ISNULL(s.SubscriberId,0) END
			AND tsi.OverwriteWebUserName = 'No'
		WHERE GETDATE() BETWEEN sib.ImportedStartedDateTime AND DATEADD(minute,30, sib.ImportedStartedDateTime)
		)
UPDATE RemoteUser
SET EmailAddress = inserted.AddressText 
	,LastUpdatedDateTime = INSERTED.LastUpdatedDateTime 
	,LastUpdatedByUserId  = INSERTED.LastUpdatedByUserId 
FROM RemoteUser ru
	INNER JOIN RemoteUserRights rur
	ON rur.UserId = ru.UserId 
	AND rur.RightsType = 'Subscriber'
	INNER JOIN INSERTED
	ON INSERTED.SubscriberId = rur.RightsToId 
	AND inserted.AddressType = 'Email'
	AND inserted.AddressDescription = 'Main'
WHERE ru.AuthorityLevel = 'IndividualSubscriber'
go
