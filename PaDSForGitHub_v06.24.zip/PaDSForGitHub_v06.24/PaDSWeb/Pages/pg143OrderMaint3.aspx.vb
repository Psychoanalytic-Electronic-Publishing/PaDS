﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.Subscriber
Imports DevExpress.Web
Imports DevExpress.Web.Data

'Modification History
'05/05/20  Julian Gates   Initial New version
'12/11/20   James Woosnam   SIR5148 - Update all line rates to the latest rates
'12/11/20   Julian Gates    SIR5148 - Add CurrencyCode to AmountGross value
'12/10/21   James Woosnam   SIR5341 - Code to populate AffiliateRateSubscriberId moved to SalesOrder.Save
'3/12/21    James Woosnam   SIR5377 - If present show associated product amount

Partial Class Pages_pg143OrderMaint3
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Enum PageModes
        Block
        Blockaddress
        Individual
    End Enum
    ReadOnly Property IsUpdatable As Boolean
        Get
            If Me.SalesOrder IsNot Nothing Then
                Return SalesOrder.SalesOrderRow("SalesOrderStatus").ToString.Contains("Partial")
            End If
            Return False
        End Get
    End Property

    Public ReadOnly Property PageMode As PageModes
        Get
            If Me.SalesOrder IsNot Nothing Then
                Select Case SalesOrder.SalesOrderRow("OrderType")
                    Case "Block"
                        Return PageModes.Block
                End Select
            End If
            Return PageModes.Individual
        End Get
    End Property


    Private _SalesOrder As BusinessLogic.SalesOrder = Nothing
    Public Property SalesOrder() As BusinessLogic.SalesOrder
        Get
            If Me._SalesOrder Is Nothing Then
                If IsNumeric(Request.QueryString("OrderNumber")) Then
                    Me._SalesOrder = New BusinessLogic.SalesOrder(CInt(Request.QueryString("OrderNumber")), Me.uPage.db, Me.uPage.UserSession)
                    Me.Subscriber = New BusinessLogic.Subscriber(CInt(Me._SalesOrder.SalesOrderRow.Item("SubscriberId")), Me.uPage.db, Me.uPage.UserSession)
                Else
                    Me._SalesOrder = New BusinessLogic.SalesOrder(Me.uPage.db, Me.uPage.UserSession)
                End If

            End If
            Return Me._SalesOrder
        End Get
        Set(ByVal value As BusinessLogic.SalesOrder)
            Me._SalesOrder = value
        End Set
    End Property

    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                Me._Subscriber = New BusinessLogic.Subscriber(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property
    Dim _tDsplyLns As DataTable = Nothing
    ReadOnly Property tDsplyLns As DataTable
        Get

            If _tDsplyLns Is Nothing Then
                Dim listSQL As String = "EXEC sp148SalesOrderLists @ListType=@ListType,@OrderNumber=@OrderNumber,@MainFilter=@MainFilter"
                Dim cmd As New SqlCommand(listSQL, uPage.db.DBConnection, uPage.db.DBTransaction)

                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ListType", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                      , IIf(PageMode = PageModes.Individual, "Products", "Subscribers")))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@MainFilter", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                      , Me.MainFilter.Text))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OrderNumber", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                      , Me.SalesOrder.OrderNumber))
                Dim yt As DataTable = uPage.db.GetDataTableFromSQL(cmd)
                _tDsplyLns = uPage.GetListDatatable(Me.txtPageNumber.Text, Me.txtRecordsToShow.Text, Me.lblPaging.Text, cmd)
            End If
            Return _tDsplyLns
        End Get
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Bank Deposit Maintenance ", "")

        'Only allow update by AuthorityLevel Admin users
        Select Case Me.uPage.UserSession.AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
            Case Else
                Response.Redirect("../Pages/pg100HomeAdmin.aspx?InfoMsg=Your userid does not allow you access to this page.")
        End Select

        Try
            If Page.IsPostBack Then
                If Me.txtCommandData.value <> "" Then
                    Me.SalesOrder.CancelSalesOrderLine(txtCommandData.value.replace("CancelLine", ""))
                End If
                If Me.txtPrevRecordsToShow.Value <> Me.txtRecordsToShow.Text Then
                    Me.txtPageNumber.Text = 1
                    Me.txtPrevRecordsToShow.Value = Me.txtRecordsToShow.Text
                    BuildListTable(ClearTable:=True)
                Else
                    If Me.txtGotoPageNum.Value <> "" Then
                        Me.txtPageNumber.Text = Me.txtGotoPageNum.Value
                        BuildListTable(ClearTable:=True)
                        Me.txtGotoPageNum.Value = ""
                    Else
                        BuildListTable(ClearTable:=False) 'Normal saving

                    End If
                End If

            Else
                If Request.QueryString("OrderNumber") <> "" Then
                    'Me.SalesOrder & me.Subscriber set above so works in partital postback
                End If

                If Me.uPage.IsValid Then
                    SalesOrder.AddSalesOrderLineRates()
                    ReadRecord()
                End If

                txtRecordsToShow.Text = 20
                Me.txtPageNumber.Text = 1
                BuildListTable(ClearTable:=True)
            End If
        Catch ex As Exception
            uPage.PageError = "An unexpected error has occured.  Please contact support." & ex.ToString
        End Try

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If
        Me.UserId.Value = uPage.UserSession.UserId
    End Sub

    Sub PageSetup()

        '28/2/22    James Woosnam   SIR5443 - More descriptive page header
        uPage.pageTitle = "OrdLines No: " & Me.SalesOrder.OrderNumber & " Sub:" & Me.Subscriber.SubscriberName & "(" & Me.Subscriber.SubscriberId & ")"
        Me.pageHeaderTitle.Text = uPage.pageTitle

        Me.CompanyName.Text = uPage.db.IsDBNull(Me.uPage.db.DLookup("CompanyName", "Company", "CompanyId='" & Me.SalesOrder.SalesOrderRow.Item("CompanyId") & "'"), "")
        Dim PrimProd As New BusinessLogic.Product(Me.SalesOrder.SalesOrderRow("PrimaryProductCode"), uPage.db, uPage.UserSession)
        Me.PrimaryProductName.Text = PrimProd.ProductName
        Me.PreviousPageLink.NavigateUrl = "../pages/pg142OrderMaint2.aspx?OrderNumber=" & Me.SalesOrder.OrderNumber
        Me.NextPageLink.NavigateUrl = "../pages/pg144OrderMaint4.aspx?OrderNumber=" & Me.SalesOrder.OrderNumber

        Me.SubscriberId.NavigateUrl = "../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & Me.Subscriber.SubscriberId
        Me.PrimaryProductName.NavigateUrl = "../pages/pg504ProductMaint.aspx?PageMode=Update&ProductCode=" & Me.SalesOrder.SalesOrderRow("PrimaryProductCode")

        Me.SaveBtn.Visible = Me.IsUpdatable Or Me.HasIncompleteShippedOrderLine
        Me.CancelBtn.Visible = Me.IsUpdatable
        Me.DeliveryAddressTable.Visible = HasIncompleteShippedOrderLine And Me.PageMode = PageModes.Individual
        Me.DeliveryAddressId.Enabled = Me.IsUpdatable Or Me.HasIncompleteShippedOrderLine
        Me.CashbookLink.NavigateUrl = "../pages/pg150CashbookSelect.aspx?" _
                                          & "FilterSubscriberId=" & Me.Subscriber.SubscriberRow("SubscriberId") _
                                          & "&CompanyId=" & Me.SalesOrder.SalesOrderRow.Item("CompanyId")
    End Sub
    Dim HasIncompleteShippedOrderLine As Boolean = False
    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Me.uPage.PopulatePageFieldsFromDataRow(Me.SalesOrder.SalesOrderRow)
        '12/11/20   Julian Gates    SIR5148 - Add CurrencyCode to AmountGross
        Me.AmountGross.Text = IIf(IsNumeric(Me.AmountGross.Text), CType(Me.AmountGross.Text, Decimal).ToString("#,##0.00"), "") & " " & uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow("CurrencyCode"), "")
        Me.SubscriberName.Text = Me.Subscriber.SubscriberName
        Dim DeliveryAddressId As Integer = 0
        For Each r As DataRow In SalesOrder.SalesOrderLine.Rows
            If Not uPage.db.IsDBNull(r("DeliveryAddressId")) Then
                DeliveryAddressId = r("DeliveryAddressId")
                Exit For
            End If
        Next
        uPage.PopulateDropDownListFromSQL(Me.DeliveryAddressId, "SELECT SubscriberAddress.SubscriberAddressId as Value" _
                                                                                & "    , Left(SubscriberAddress.AddressDescription + ' - ' + SubscriberAddress.AddressText,50) as Text" _
                                                                                & " FROM SubscriberAddress " _
                                                                                & " WHERE AddressType = 'Postal'" _
                                                                                & " AND (AddressDescription in ('Main','Billing') OR SubscriberAddressId=" & DeliveryAddressId & ")" _
                                                                                & " AND SubscriberId = " & Me.Subscriber.SubscriberRow("SubscriberId") _
                                                                                & " ORDER BY 2" _
                                                                                , uPage.PrimaryConnection _
                                                                                , Nothing _
                                                                               , DeliveryAddressId
                                                                              )
        Me.DeliveryAddressId.SelectedValue = DeliveryAddressId
    End Sub

    Sub SaveRecord()
        '******************************************************
        'Description:	Save the record either by updating
        '******************************************************
        Try
            uPage.db.BeginTran()
            Try

                For Each rowtblPage As WebControls.TableRow In Me.MainTbl.Rows
                    Dim RowKey As String = rowtblPage.ID.Replace("ROW", "")
                    Try
                        Dim cb As CheckBox = Me.MainTbl.FindControl(RowKey & "Included")

                        If cb IsNot Nothing Then
                            If Not cb.Checked And 0 = uPage.db.DLookup("Count(*)", "SalesOrderLine", "OrderNumber=" & Me.OrderNumber.Text & " AND " & IIf(PageMode = PageModes.Block, "SubscriberId=" & RowKey, "ProductCode='" & RowKey & "'")) Then
                                Exit Try ''If not checked and no order line then just skip
                            End If
                            Dim cmd As New SqlCommand("sp146UpdateSalesOrderLine", uPage.db.DBConnection, uPage.db.DBTransaction)
                            cmd.CommandType = CommandType.StoredProcedure
                            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OrderNumber", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                                                  , Me.SalesOrder.OrderNumber))
                            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Included", System.Data.SqlDbType.Bit, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                                                  , cb.Checked))
                            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProductRateId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                                                  , CType(MainTbl.FindControl(RowKey & "ProductRateId"), DropDownList).SelectedValue))
                            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Quantity", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                                                  , IIf(Not IsNumeric(CType(MainTbl.FindControl(RowKey & "Quantity"), TextBox).Text), 0, CType(MainTbl.FindControl(RowKey & "Quantity"), TextBox).Text)))
                            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName20", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                                                  , uPage.UserSession.UserName20))
                            If ShowAssocProd Then cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IncludesAssociatedProduct", System.Data.SqlDbType.Bit, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                                                 , CType(MainTbl.FindControl(RowKey & "IncludesAssociatedProduct"), CheckBox).Checked))
                            Select Case PageMode
                                Case PageModes.Individual
                                    cmd.CommandText = "sp149UpdateSalesOrderProducts"
                                    cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProductCode", System.Data.SqlDbType.VarChar, 10, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                      , RowKey))
                                    If Me.HasIncompleteShippedOrderLine Then cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DeliveryAddressId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                                              , Me.DeliveryAddressId.SelectedValue))
                                Case PageModes.Block
                                    cmd.CommandText = "sp146UpdateSalesOrderSubscribers"
                                    cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                              , RowKey))
                                    If Me.HasIncompleteShippedOrderLine Then cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DeliveryAddressId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                                              , CType(MainTbl.FindControl(RowKey & "DeliveryAddressId"), DropDownList).SelectedValue))
                            End Select
                            cmd.ExecuteNonQuery()
                        End If
                    Catch ex As Exception
                        Throw New Exception("Failed on Row:" & RowKey & ":" & ex.Message)
                    End Try


                Next
                '12/11/20   James Woosnam   SIR5148 - Update all line rates to the latest rates
                Dim sql As String = ""
                sql += "UPDATE SalesOrderLine"
                sql += " SET ProductRate = pr.ProductRate "
                sql += "    ,AmountProduct = pr.ProductRate * sol.Quantity"
                sql += " FROM SalesOrderLine sol"
                sql += "	INNER JOIN ProductRate pr"
                sql += "	ON pr.ProductRateId = sol.ProductRateId "
                sql += " WHERE sol.OrderNumber = " & Me.SalesOrder.OrderNumber
                sql += " AND (sol.ProductRate <> pr.ProductRate "
                sql += "    OR  sol.AmountProduct <> pr.ProductRate * sol.Quantity)"
                uPage.db.ExecuteSQL(sql)
                '12/10/21   James Woosnam   SIR5341 - Code to populate AffiliateRateSubscriberId moved to SalesOrder.Save

                'Because the lines are updated in an sp we need to re-oprn the order and save to update totals
                Me.SalesOrder = New BusinessLogic.SalesOrder(Me.SalesOrder.OrderNumber, uPage.db, uPage.UserSession)
                Me.SalesOrder.Save()
                Me.uPage.db.CommitTran()

            Catch ex As Exception
                uPage.db.RollbackTran()
                Throw ex
            End Try

        Catch ex As Exception
            Me.uPage.PageError = "An Unexpected Error has occured.  Please contact support" & ex.ToString
        End Try

        If Me.uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=Sales order has been saved&OrderNumber=" & Me.SalesOrder.OrderNumber)
        End If
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.SalesOrder.MainDataset
        Me.PageSetup()
        Me.uPage.PagePreRender()
    End Sub
    Enum ComboSourceType
        Rates
        Addresses
    End Enum

    Dim tAllRates As DataTable = Nothing
    Dim tAllAddresses As DataTable = Nothing
    Function GetDropDownDataView(SourceType As ComboSourceType, EditingKeyValue As String) As DataView
        If uPage Is Nothing Then uPage = New UserPage(Me, "SO Maintenance ", "")
        Select Case SourceType
            Case ComboSourceType.Addresses
                If tAllAddresses Is Nothing Then tAllAddresses = GetDropDownTable(SourceType)
                Return New DataView(tAllAddresses, "SubscriberId=" & EditingKeyValue, "", DataViewRowState.CurrentRows)

            Case ComboSourceType.Rates
                If tAllRates Is Nothing Then tAllRates = GetDropDownTable(SourceType)
                Select Case PageMode
                    Case PageModes.Block
                        Return New DataView(tAllRates, "SubscriberId=" & EditingKeyValue, "", DataViewRowState.CurrentRows)
                    Case PageModes.Individual
                        Return New DataView(tAllRates, "ProductCode='" & EditingKeyValue & "'", "", DataViewRowState.CurrentRows)
                End Select

        End Select

        Return Nothing
    End Function
    Function GetDropDownTable(SourceType As ComboSourceType) As DataTable

        If uPage Is Nothing Then uPage = New UserPage(Me, "SO Maintenance ", "")

        Dim cmd As New SqlCommand("sp147SalesOrderSubscriberDropDownSource", uPage.db.DBConnection, uPage.db.DBTransaction)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OrderNumber", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                  , Me.SalesOrder.OrderNumber))

        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PageMode", System.Data.SqlDbType.VarChar, 10, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                              , PageMode.ToString))

        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SourceType", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                                  , SourceType.ToString))
        Return uPage.db.GetDataTableFromSQL(cmd)
    End Function
    Private Sub AddError(e As ASPxDataValidationEventArgs, ByVal column As GridViewColumn, ByVal errorText As String)
        If e.Errors.ContainsKey(column) Then
            Return
        End If
        e.Errors(column) = errorText
        e.RowError += IIf(e.RowError = "", "", "<br>") & errorText
    End Sub


    Dim ShowAssocProd As Boolean = False
    Sub BuildListTable(ClearTable As Boolean)
        Dim OverwriteUpdatableFields As Boolean = Not IsPostBack Or ClearTable
        Try
            If ClearTable Then
                For i As Integer = Me.MainTbl.Rows.Count - 1 To 0 Step -1
                    Dim rowtblPage As WebControls.TableRow = Me.MainTbl.Rows(i)
                    Dim cb As CheckBox = Me.MainTbl.FindControl(rowtblPage.ID.Replace("ROW", "") & "Included")
                    If cb IsNot Nothing Then
                        Me.MainTbl.Rows.Remove(rowtblPage)
                    End If

                Next


            End If
            Dim PrimProd As New BusinessLogic.Product(Me.SalesOrder.SalesOrderRow("PrimaryProductCode"), uPage.db, uPage.UserSession)
            ShowAssocProd = PrimProd.HasAssociatedProduct
            Dim tableCols As Integer = 6
            If ShowAssocProd Then tableCols += 1
            If PageMode = PageModes.Block Then tableCols += 1
            Me.PreHeaderCELL.ColumnSpan = tableCols
            Me.FilterCell.ColumnSpan = tableCols

            Dim hCell As New WebControls.TableCell
            If {"Complete", "Confirmed"}.Contains(Me.SalesOrder.SalesOrderRow("SalesOrderStatus")) Then
                hCell = New TableCell '**********************
                hCell.CssClass = "fldTitle"
                hCell.Text = ""
                HeaderROW.Cells.Add(hCell)
            End If

            Dim ftc As TableCell = Me.MainTbl.FindControl("FirstHeaderCell")
            If ftc Is Nothing Then
                hCell = New TableCell '**********************
                hCell.ID = "FirstHeaderCell"
                hCell.CssClass = "fldTitle"
                hCell.Text = "Subscriber"
                HeaderROW.Cells.Add(hCell)
                hCell = New TableCell '**********************
                hCell.CssClass = "fldTitle"
                hCell.Text = "Included"
                HeaderROW.Cells.Add(hCell)
                hCell = New TableCell '**********************
                hCell.CssClass = "fldTitle"
                hCell.Text = "Address"
                If PageMode = PageModes.Block Then HeaderROW.Cells.Add(hCell)
                hCell = New TableCell '**********************
                hCell.CssClass = "fldTitle"
                hCell.Text = "Rate"
                HeaderROW.Cells.Add(hCell)
                hCell = New TableCell '**********************
                hCell.CssClass = "fldTitle"
                hCell.Text = "Quantity"
                HeaderROW.Cells.Add(hCell)
                hCell = New TableCell '**********************
                hCell.CssClass = "fldTitle"
                hCell.Text = "Cost"
                HeaderROW.Cells.Add(hCell)
                hCell = New TableCell '**********************
                hCell.CssClass = "fldTitle"
                hCell.Text = "Associated Product"
                hCell.HorizontalAlign = HorizontalAlign.Center
                If ShowAssocProd Then HeaderROW.Cells.Add(hCell)
                HeaderROW.CssClass = "listTableHeaderBg"
            End If


            'Now add rows
            Dim rowNumber As Integer = 0
            For Each row As DataRow In tDsplyLns.Rows
                Dim RowKey As String = ""
                Select Case PageMode
                    Case PageModes.Block
                        RowKey = row("SubscriberId")
                    Case PageModes.Individual
                        RowKey = row("ProductCode")

                End Select
                Dim tb As New TextBox
                Dim chk As New CheckBox
                Dim hLink As New HyperLink()

                Dim tRow As New WebControls.TableRow
                tRow.ID = RowKey & "ROW"
                Dim cell As New WebControls.TableCell
                If uPage.db.IsDBNull(row("IsCancel"), False) Then
                    cell = New TableCell()
                    cell.Text = "Cancelled:" & CDate(row("CancelledDate")).ToString("dd-MMM-yy")
                    tRow.Cells.Add(cell) '******************************
                Else
                    If {"Complete", "Confirmed"}.Contains(Me.SalesOrder.SalesOrderRow("SalesOrderStatus")) Then
                        cell = New TableCell()
                        Dim bt As New Button

                        bt.OnClientClick = "ConfirmSubmitCommandData(" _
                                                            & "'Are you sure you want to cancel this line?" _
                                                            & " - Once cancelled this line will not be despatched'" _
                                                            & ",'CancelLine" & row("SalesorderLineId") & "')"
                        bt.Text = "cancel"
                        cell.Controls.Add(bt)
                        tRow.Cells.Add(cell) '******************************
                    End If
                End If


                cell = New TableCell()
                Select Case PageMode
                    Case PageModes.Block
                        hLink.NavigateUrl = "../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & RowKey
                        hLink.ToolTip = "View Subscriber"
                        hLink.Text = row("SubscriberName") & " (" & row("SubscriberId") & ")"
                    Case PageModes.Individual
                        hLink.NavigateUrl = "../pages/pg504ProductMaint.aspx?ProductCode=" & RowKey
                        hLink.ToolTip = "View Product"
                        hLink.Text = row("ProductDescription")
                End Select

                cell.Controls.Add(hLink)
                tRow.Cells.Add(cell) '******************************

                cell = New WebControls.TableCell
                cell.HorizontalAlign = HorizontalAlign.Center

                chk = New WebControls.CheckBox
                chk.ID = RowKey & "Included"
                If OverwriteUpdatableFields Then
                    chk.Checked = row("Included")
                    chk.EnableViewState = True
                End If
                chk.Enabled = Me.IsUpdatable
                cell.Controls.Add(chk)

                tRow.Cells.Add(cell) '******************************

                If Not Me.HasIncompleteShippedOrderLine Then Me.HasIncompleteShippedOrderLine = SalesOrderStatus.Text <> "Complete" And row("IsShipped")
                Dim dr As New WebControls.DropDownList
                Select Case PageMode
                    Case PageModes.Block
                        cell = New WebControls.TableCell
                        If row("IsShipped") Then
                            dr.ID = RowKey & "DeliveryAddressId"
                            dr.DataValueField = "DeliveryAddressId"
                            dr.DataTextField = "AddressText"
                            dr.DataSource = Me.GetDropDownDataView(ComboSourceType.Addresses, RowKey)
                            dr.DataBind()
                            If OverwriteUpdatableFields Then
                                If Not uPage.db.IsDBNull(row("DeliveryAddressId")) Then dr.SelectedValue = row("DeliveryAddressId")
                                dr.EnableViewState = True
                            End If
                            dr.CssClass = "fldEntry"
                            dr.Enabled = IsUpdatable Or SalesOrderStatus.Text = "Confirmed"
                            cell.Controls.Add(dr)
                        Else

                            cell.Text = "na"
                        End If

                        tRow.Cells.Add(cell)  '******************************
                End Select


                cell = New WebControls.TableCell
                dr = New WebControls.DropDownList
                dr.ID = RowKey & "ProductRateId"
                dr.Width = "400"
                dr.DataValueField = "ProductRateId"
                dr.DataTextField = "ProductRateDescription"
                dr.DataSource = Me.GetDropDownDataView(ComboSourceType.Rates, RowKey)
                dr.DataBind()
                If OverwriteUpdatableFields Then
                    If Not uPage.db.IsDBNull(row("ProductRateId")) Then dr.SelectedValue = row("ProductRateId")
                    dr.EnableViewState = True
                End If
                dr.Enabled = IsUpdatable
                dr.CssClass = "fldEntry"
                cell.Controls.Add(dr)
                If Not uPage.db.IsDBNull(row("AffiliateRateSubscriberId")) Then
                    Dim lb As New Label
                    lb.Text = "<br>Affiliate Rate via:"
                    cell.Controls.Add(lb)
                    hLink = New HyperLink
                    hLink.NavigateUrl = "../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & row("AffiliateRateSubscriberId")
                    hLink.Text = row("AffiliateRateSubscriberName") & " (" & row("AffiliateRateSubscriberId") & ")"
                    cell.Controls.Add(hLink)
                End If

                tRow.Cells.Add(cell) '******************************

                cell = New WebControls.TableCell
                tb = New WebControls.TextBox
                tb = New WebControls.TextBox
                tb.Width = "50"
                tb.ID = RowKey & "Quantity"
                If OverwriteUpdatableFields Then
                    tb.Text = uPage.db.IsDBNull(row("Quantity"), "")
                    tb.EnableViewState = True
                End If
                tb.Enabled = IsUpdatable
                tb.CssClass = "fldEntry"
                cell.Controls.Add(tb)
                tRow.Cells.Add(cell) '******************************

                cell = New WebControls.TableCell
                If Not uPage.db.IsDBNull(row("AmountProduct")) Then
                    cell.Text = CType(row("AmountProduct"), Decimal).ToString("#,##0.00")
                End If
                '3/12/21    James Woosnam   SIR5377 - If present show associated product amount
                If row("IncludesAssociatedProduct") AndAlso Not uPage.db.IsDBNull(row("AssociatedProductAmount")) Then
                    cell.Text += " + " & CType(row("AssociatedProductAmount"), Decimal).ToString("#,##0.00")
                End If
                cell.Width = "100"
                tRow.Cells.Add(cell) '******************************

                cell = New WebControls.TableCell
                cell.HorizontalAlign = HorizontalAlign.Center
                chk = New WebControls.CheckBox
                chk = New WebControls.CheckBox
                chk.ID = RowKey & "IncludesAssociatedProduct"
                If OverwriteUpdatableFields Then
                    chk.Checked = row("IncludesAssociatedProduct")
                    chk.EnableViewState = True
                End If
                tb.CssClass = "fldEntry"
                cell.Controls.Add(chk)
                If ShowAssocProd Then tRow.Cells.Add(cell) '******************************


                Me.MainTbl.Rows.Add(tRow)
                rowNumber += 1
            Next
        Catch ex As Exception
            Me.uPage.InfoMessage = ex.ToString
        End Try
    End Sub


    Private Function IsPageValidForStatus(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True) As Boolean

        Select Case validatorStatus
            Case Else
        End Select

        For Each rowtblPage As WebControls.TableRow In Me.MainTbl.Rows
            Dim RowKey As String = rowtblPage.ID.Replace("ROW", "")
            Dim cb As CheckBox = Me.MainTbl.FindControl(RowKey & "Included")
            If cb IsNot Nothing Then
                If cb.Checked Then
                    Dim tbQuant As TextBox = Me.MainTbl.FindControl(RowKey & "Quantity")
                    uPage.FieldValidateNumber(tbQuant, True)
                    Dim cbDeliveryAddress As DropDownList = CType(MainTbl.FindControl(RowKey & "DeliveryAddressId"), DropDownList)
                    If cbDeliveryAddress IsNot Nothing Then uPage.DropDownValidateMandatory(cbDeliveryAddress)
                    Dim cbProductRateId As DropDownList = CType(MainTbl.FindControl(RowKey & "ProductRateId"), DropDownList)
                    uPage.DropDownValidateMandatory(cbProductRateId)
                End If
            End If

        Next


        Return uPage.IsValid
    End Function

    Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                Me.SaveRecord()

            Catch ex As Exception
                Me.uPage.InfoMessage = ex.ToString
            End Try

            If uPage.PageError = Nothing Then
                Response.Redirect("../pages/pg143OrderMaint3.aspx?OrderNumber=" & Me.OrderNumber.Text)
            End If
        End If
    End Sub

    Private Sub CancelBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelBtn.Click
        Response.Redirect("../pages/pg143OrderMaint3.aspx?OrderNumber=" & Me.OrderNumber.Text)
    End Sub

    Private Sub btnFilter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFilter.Click
        Me.txtPageNumber.Text = 1
        BuildListTable(ClearTable:=True)
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?OrderNumber=" & Me.OrderNumber.Text)
    End Sub
End Class
