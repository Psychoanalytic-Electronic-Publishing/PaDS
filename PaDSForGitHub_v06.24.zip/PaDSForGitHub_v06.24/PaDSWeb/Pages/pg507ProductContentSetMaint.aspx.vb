﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web
Imports DevExpress.Web.Data

'Modification History
'20/04/2020 Julian Gates    Initial Version
'18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
'5/12/21    James Woosnam   SIR5376 - Updated to ensure audit log correct

Partial Class Pages_pg507ProductContentSetMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Product Content Set Add/Delete", "")
        Me.pageHeaderTitle.Text = "Product Content Set Add/Delete"

        If Page.IsPostBack Then

        Else

        End If
        If Request.QueryString("ProductCode") <> "" And Request.QueryString("CompanyId") <> "" Then
            Me.ProductCode.Text = Request.QueryString("ProductCode")
            Me.TargetProductCode.Value = Me.ProductCode.Text
            Me.TargetCompanyId.Value = Request.QueryString("CompanyId")
        Else
            uPage.PageError = "Invalid Parameter has been passed in."
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If
    End Sub

    Sub PageSetup()
        Me.pageHeaderTitle.Text = "Product Content Sets for: " & Me.ProductCode.Text
        Me.ProductName.Text = uPage.db.DLookup("ProductName", "Product", "ProductCode='" & Me.ProductCode.Text & "'")
        'Populate dropdown fields
        Try
            CType(Me.ProductContentSetGridView.Columns("ContentSetId"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL(Me.ContentSetDropdownSQL())

        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try

        'show filter row menu
        Me.ProductContentSetGridView.Settings.ShowFilterRowMenu = True
        Me.ProductContentSetGridView.SettingsEditing.Mode = GridViewEditingMode.Inline

        Me.ProductSelectLink.NavigateUrl = "../pages/pg503ProductSelect.aspx"
        Me.ProductMaintLink.NavigateUrl = "../pages/pg504ProductMaint.aspx?PageMode=Update&ProductCode=" & Me.ProductCode.Text
        Me.ProductRatesLink.NavigateUrl = "../pages/pg502ProductRatesMaint.aspx?ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.TargetCompanyId.Value
        Me.QualifyingProductsLink.NavigateUrl = "../pages/pg505QualifyingProductMaint.aspx?ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.TargetCompanyId.Value
        Me.AffiliateRatesLink.NavigateUrl = "../pages/pg506AffiliateRatesMaint.aspx?ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.TargetCompanyId.Value
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Protected Sub ProductContentSet_RowValidating(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataValidationEventArgs)
        If e.NewValues("ContentSetId") Is Nothing Then
            AddError(e.Errors, ProductContentSetGridView.Columns("ContentSetId"), "Please select a Content Set.")
        End If
        uPage.PageError = e.RowError

        BuildDropdownsForPostback()
    End Sub

    Private Sub AddError(ByVal errors As Dictionary(Of GridViewColumn, String), ByVal column As GridViewColumn, ByVal errorText As String)
        If errors.ContainsKey(column) Then
            Return
        End If
        errors(column) = errorText
    End Sub

    Protected Sub ProductContentSetGridView_InitNewRow(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInitNewRowEventArgs) Handles ProductContentSetGridView.InitNewRow
        BuildDropdownsForPostback()
    End Sub

    Protected Sub ProductContentSetGridView_StartRowEditing(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxStartRowEditingEventArgs) Handles ProductContentSetGridView.StartRowEditing
        BuildDropdownsForPostback()
    End Sub
    Protected Sub ProductQualifyingProductGridView_ItemUpdating(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataUpdatingEventArgs) Handles ProductContentSetGridView.RowUpdating

        e.NewValues("LastUpdatedDateTime") = DateTime.Now()
        e.NewValues("LastUpdatedByUserId") = uPage.UserSession.UserName20
    End Sub
    Protected Sub ProductQualifyingProductGridView_ItemInserting(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInsertingEventArgs) Handles ProductContentSetGridView.RowInserting
        e.NewValues("LastUpdatedDateTime") = DateTime.Now()
        e.NewValues("LastUpdatedByUserId") = uPage.UserSession.UserName20
    End Sub
    Private Sub ProductContentSetGridView_RowDeleting(sender As Object, e As ASPxDataDeletingEventArgs) Handles ProductContentSetGridView.RowDeleting
        If uPage Is Nothing Then
            uPage = New UserPage(Me, "Affiliate Rates View", "")
        End If
        uPage.db.ExecuteSQL("UPDATE ProductContentSet SET [LastUpdatedDateTime] = GETDATE(), [LastUpdatedByUserId] = '" & uPage.UserSession.UserName20 & "' WHERE ProductContentSetId=" & e.Values("ProductContentSetId"))
    End Sub
    Protected Sub ProductContentSetGridView_RowInserted(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInsertedEventArgs) Handles ProductContentSetGridView.RowInserted
        BuildDropdownsForPostback()
        '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
        e.NewValues("LastUpdatedDateTime") = Now()
        e.NewValues("LastUpdatedByUserId") = uPage.UserSession.UserName20
    End Sub

    Protected Sub ProductContentSetGridView_RowUpdated(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataUpdatedEventArgs) Handles ProductContentSetGridView.RowUpdated
        BuildDropdownsForPostback()
        '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
        e.NewValues("LastUpdatedDateTime") = Now()
        e.NewValues("LastUpdatedByUserId") = uPage.UserSession.UserName20
    End Sub

    Sub BuildDropdownsForPostback()
        Try
            Dim combo As GridViewDataComboBoxColumn = TryCast(ProductContentSetGridView.Columns("ContentSetId"), GridViewDataComboBoxColumn)
            combo.PropertiesComboBox.ValueType = GetType(String)

            If combo.PropertiesComboBox.Items.Count = 0 Then
                For Each row As DataRow In Me.uPage.db.GetDataTableFromSQL(Me.ContentSetDropdownSQL()).Rows
                    combo.PropertiesComboBox.Items.Add(row("ContentSetName"), row("ContentSetId"))
                Next
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub

    Function ContentSetDropdownSQL() As String
        Dim sql As String = "SELECT cs.ContentSetId"
        sql += "        ,ContentSetName = cs.ContentSetName + ' (' + CONVERT(VARCHAR,cs.ContentSetId) + ')'"
        sql += "  FROM ContentSet cs "
        sql += " WHERE cs.ContentSetStatus = 'Active'"
        sql += " ORDER BY cs.ContentSetName"

        Return sql
    End Function


End Class
