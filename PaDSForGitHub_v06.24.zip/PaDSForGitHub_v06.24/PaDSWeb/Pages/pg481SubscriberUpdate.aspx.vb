Imports System.Data.SqlClient
Imports System.Data

Partial Class pg481SubscriberUpdate
    '7/4/08     James Woosnam   SIR1524 - Allow processing of duplicate subscriptions
    '14/7/08	James Woosnam	SIR1554	- Add Completed Orders into Dup Subscription query
    '25/7/08	Julian Gates	SIR1556 - Add new sql to Sub BuildExistingSubscriptionList to fix bug raised by Athena to stop previous subscriptions showing.
    '8/3/10     James Woosnam   SIR2179 - Add functionality to handle checking web user name overwrires
    '24/9/10    Julian Gates    Removed this page from popup window
    '14/10/10   James Woosnam   SIR2299 - Allow Duplicate and Existing actions to take place and save even if the Overwrtie unsername actions has not been selected
    '17/02/11   Julian Gates    Add SubscriberEmail as modification to BuildDuplicateList
    '19/05/11   Julian Gates    Fix isnull issue for recurring end date
    '2/10/12    James Woosnam   SIR2874 - If additional products populated use these to check for existing subscriptions
    '12/12/12   Julian Gates    Fix pg142OrderMaint2 link in sub BuildExistingSubscriptionList()
    '14/12/12   Julian Gates    SIR2946 - Add subscriber billing address to BuildDuplicateList()
    '16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields and associated code
    '3/1/20	    James Woosnam	SIR5133 - Show subs with duplicate email addresses

    Inherits System.Web.UI.Page
    Public uPage As UserPage = Nothing
    Dim pageMode As String = Nothing
    Dim selectCommand As String = Nothing
    Dim ds As New DataSet
    Dim dRow As DataRow = Nothing
    Dim dTble As DataTable = Nothing
    Dim cPageNumber As Long = Nothing

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    'Modification History
    '02/05/2007  Julian Gates    Initial version
    '31/05/2007  Jacqueline Forster SIR 1163/1164 Fixed problems 
    '05/06/2007  Jacqueline Forster SIR 1163/1164 Fixed problems by changing ordering of ReadRecord
    '27/11/07    Julian Gates  Add code to SQL to replace "'" with "''" to stop BuildDuplicateList generating error SIR 1309
    '10/12/15   Julian Gates    SIR4020 - If CompanyId = 1 then set OverwriteWebUserName dropdown to readonly
    '09/02/16   Julian Gates    SIR4045 - Change Town/County Prompts to City/State


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Subscriber Update", "")
        Me.pageHeaderTitle.Text = "Subscriber Update"

        pageMode = Request.QueryString("PageMode")
        Me.SubscriberImportId.Text = Request.QueryString("SubscriberImportId")
        'CloseBtn.Attributes.Add("onclick", "CloseWindow()")

        If Request.QueryString("PageNumber") <> "" Then
            Me.cPageNumber = Request.QueryString("PageNumber")
        End If
        uPage.FocusControl = Me.AffiliateReferenceId
        selectCommand = "Select *" _
           & " From tmpSubscriberImport" _
           & " Where SubscriberImportId = " & Me.SubscriberImportId.Text

        If Page.IsPostBack Then
            ds = CType(ViewState("MainDataSet"), DataSet)
            If Left(Me.txtCommandData.Value, 3) = "Use" Then
                If Me.IsPageValidForStatus("") Then
                    SaveRecord(Mid(Me.txtCommandData.Value, 4))
                End If
                Me.txtCommandData.Value = ""
            End If
        Else
            ReadRecord()
            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
        End If
    End Sub

    Sub PageSetup()
        Select Case pageMode
            Case "Update"
                If uPage.StdCode.IsNull(Me.ds.Tables("SubscriberImport").Rows(0)("DuplicateFound"), False) Then
                    BuildDuplicateList()
                    Me.DuplicateListPanel.Visible = True
                Else
                    Me.DuplicateListPanel.Visible = False
                End If
                If uPage.StdCode.IsNull(Me.ds.Tables("SubscriberImport").Rows(0)("ExistingSubscriptionFound"), False) Then
                    BuildExistingSubscriptionList()
                    Me.ExistingSubscriptionPanel.Visible = True
                Else
                    Me.ExistingSubscriptionPanel.Visible = False
                End If
                Me.WebUserOverwriteLabel.Text = "If the Web User Name or Password are blank then they will never be overwritten."
                If Not ds.Tables(0).Rows(0)("LastLoggedOnDateTime") Is System.DBNull.Value Then
                    Me.WebUserOverwriteLabel.Text += "<BR>The User last logged on " & ds.Tables(0).Rows(0)("LastLoggedOnDateTime")
                Else
                End If
                If Not ds.Tables(0).Rows(0)("WebUserOverwriteActionReviewed") Is System.DBNull.Value Then
                    Me.WebUserOverwriteLabel.Text += "<BR><BR>Record must be saved to confirm overwrite selection"
                End If

                '10/12/15   Julian Gates    SIR4020 - If CompanyId = 1 then set OverwriteWebUserName dropdown to readonly
                Select Case Me.CompanyId.Value
                    Case "1"
                        Me.OverwriteWebUserName.Enabled = False
                    Case Else
                        Me.OverwriteWebUserName.Enabled = True
                End Select

        End Select
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Dim commandText As String = Nothing
        Dim dr As SqlDataReader = Nothing
        Dim field As DataSet = Nothing
        Dim da As New SqlDataAdapter(selectCommand, uPage.PrimaryConnection)
        'Populate Dataset
        da.Fill(ds, "SubscriberImport")

        'Populate all dropdown fields
        Dim dropDownIntialValue As String = "<---------Select--------->"

        'SIR 1163 Set up CountryName drop down list
        uPage.PopulateDropDownListFromSQL(Me.CountryName, "SELECT CountryName as Value" _
                                                            & "    ,CountryName as Text" _
                                                            & " FROM Country " _
                                                            & " ORDER BY CountryName" _
                                                            , uPage.PrimaryConnection, dropDownIntialValue _
                                                            , ds.Tables("SubscriberImport").Rows(0)("CountryName"))

        'SIR 1163 Set up SubscriberCategory drop down list
        Me.CompanyId.Value = ds.Tables("SubscriberImport").Rows(0)("CompanyId")
        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria and order by
        uPage.PopulateDropDownListFromSQL(Me.SubscriberCategory, "SELECT  LookupItemKey as Value" _
                                                        & "    ,Name as Text" _
                                                        & " FROM Lookup " _
                                                        & " Where LookupName = 'SubscriberCategory'" _
                                                        & " AND Lookup.CompanyId =" & Me.CompanyId.Value _
                                                        & " AND LookupStatus = 'Active'" _
                                                        & " ORDER BY DisplayOrder,Name,LookupItemKey" _
                                                        , uPage.PrimaryConnection, dropDownIntialValue _
                                                        , ds.Tables("SubscriberImport").Rows(0)("SubscriberCategory"))

        Me.uPage.PopulateDropDownListFromLookup(Me.OverwriteWebUserName, "YesNo", uPage.PrimaryConnection, "<--??-->")
        'Read all data from dataset into page fields
        uPage.PopulatePageFieldsFromDataRow(ds.Tables("SubscriberImport").Rows(0))

        'SIR 1163 Comment out code entirely
        'Add IIf statement to default CountryName if = "" - SIR 1163 - after have set up the dropdownlist
        'If uPage.StdCode.IsNull(ds.Tables("SubscriberImport").Rows(0)("CountryName"), "") = "" Then
        '    Me.CountryName.SelectedValue = "United Kingdom"
        '    Me.CountryName.Items.Insert(uPage.StdCode.IsNull(ds.Tables("SubscriberImport").Rows(0)("CountryName"), ""), uPage.StdCode.IsNull(ds.Tables("SubscriberImport").Rows(0)("CountryName"), ""))
        'End If
        'Add IIf statement to default subscriberCategory if = "" - SIR 1163 - after have set up the dropdownlist
        'If uPage.StdCode.IsNull(ds.Tables("SubscriberImport").Rows(0)("SubscriberCategory"), "") = "" Then
        '    Me.SubscriberCategory.SelectedValue = "Ordinary"
        'End If



    End Sub
    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else
                'If Me.AffiliateReferenceId.Text.Trim = "" Then
                '    uPage.FieldErrorControl(Me.AffiliateReferenceId, "Affiliate ReferenceId ID is mandatory")
                'End If
                If Me.SubscriberCategory.SelectedValue = "" Then
                    uPage.FieldErrorControl(Me.SubscriberCategory, "Subscriber Category is mandatory")
                End If
                If Me.FirstName.Text.Trim = "" Then
                    uPage.FieldErrorControl(Me.FirstName, "First Name is mandatory")
                End If
                If Me.LastName.Text.Trim = "" Then
                    uPage.FieldErrorControl(Me.LastName, "Last Name is mandatory")
                End If
                If Me.CountryName.SelectedValue = "" Then
                    uPage.FieldErrorControl(Me.CountryName, "Country Name is mandatory")
                End If
                '18/12/19 - remove email check here as already checked on import and no way to continue if error found

                '14/10/10   James Woosnam   SIR2299 - Only test OverwriteWebUserName if duplicates and existing are already delt with
                If Me.OverwriteWebUserName.SelectedValue = "" _
                 And (Me.uPage.StdCode.IsNull(Me.ds.Tables(0).Rows(0)("DuplicateFound"), 0) = 0 _
                     Or Me.uPage.StdCode.IsNull(Me.ds.Tables(0).Rows(0)("DuplicateAction"), "") <> "") _
                 And (Me.uPage.StdCode.IsNull(Me.ds.Tables(0).Rows(0)("ExistingSubscriptionFound"), 0) = 0 _
                     Or Me.uPage.StdCode.IsNull(Me.ds.Tables(0).Rows(0)("ExistingSubscriptionAction"), "") <> "") Then
                    uPage.FieldErrorControl(Me.OverwriteWebUserName, "Overwrite Web User Name is mandatory")
                End If
        End Select
        Return uPage.IsValid
    End Function

    Sub SaveRecord(Optional ByVal dupSubscriberId As String = "", Optional ByVal saveType As String = "")
        '******************************************************
        'Description:	Save the record either by updating or adding
        '******************************************************
        Dim intRowsAffected As Integer = Nothing
        Dim cmdBld As System.Data.SqlClient.SqlCommandBuilder
        Dim da As New SqlDataAdapter(selectCommand, uPage.PrimaryConnection)

        dTble = ds.Tables("SubscriberImport")
        If dTble.Rows.Count = 0 Then
            dRow = dTble.NewRow()
        Else
            dRow = dTble.Rows(0)
        End If

        'Read Values from page fields into dataset table
        uPage.PopulateDataRowFromPageFields(dRow)
        If dupSubscriberId <> "" Then
            dRow("DuplicateSubscriberIdToUse") = dupSubscriberId
            dRow("DuplicateAction") = "Selected"
        End If
        '14/10/10   James Woosnam   SIR2299 - Only set WebUserOverwriteActionReviewed =1 if duplicates and existing are already delt with
        If (Me.uPage.StdCode.IsNull(Me.ds.Tables(0).Rows(0)("DuplicateFound"), 0) = 0 _
             Or Me.uPage.StdCode.IsNull(Me.ds.Tables(0).Rows(0)("DuplicateAction"), "") <> "") _
         And (Me.uPage.StdCode.IsNull(Me.ds.Tables(0).Rows(0)("ExistingSubscriptionFound"), 0) = 0 _
             Or Me.uPage.StdCode.IsNull(Me.ds.Tables(0).Rows(0)("ExistingSubscriptionAction"), "") <> "") Then
            dRow("WebUserOverwriteActionReviewed") = 1
        End If
        'Assign any default values or foreign key values if required

        If dTble.Rows.Count = 0 Then
            dTble.Rows.Add(dRow)
        End If

        'Add or Update data using command builder and transaction
        cmdBld = New System.Data.SqlClient.SqlCommandBuilder(da)
        da.UpdateCommand = cmdBld.GetUpdateCommand()
        da.InsertCommand = cmdBld.GetInsertCommand()
        uPage.db.BeginTran()
        Try
            da.UpdateCommand.Transaction = uPage.db.DBTransaction
            da.InsertCommand.Transaction = uPage.db.DBTransaction
            intRowsAffected = da.Update(ds, "SubscriberImport")
            Try
                Dim cmd As New SqlCommand("sp483SubscriberImport", uPage.PrimaryConnection)
                cmd.CommandType = CommandType.StoredProcedure
                cmd.CommandTimeout = 300
                cmd.Transaction = uPage.db.DBTransaction
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberImportBatchId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.ds.Tables(0).Rows(0)("SubscriberImportBatchId")))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 100, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.uPage.UserSession.UserName))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IndividualSubscriberImportId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.ds.Tables(0).Rows(0)("SubscriberImportId")))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReturnCode", System.Data.SqlDbType.Int, 0, ParameterDirection.Output, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, 0))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ErrorMessage", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Output, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, ""))
                cmd.ExecuteNonQuery()
                If cmd.Parameters("@ReturnCode").Value <> 0 Then
                    uPage.PageError = "ErrorCode:" & cmd.Parameters("@ReturnCode").Value & vbCrLf _
                                        & cmd.Parameters("@ErrorMessage").Value
                End If
                cmd = Nothing



            Catch ex As Exception
                Throw New Exception(ex.ToString)
            End Try

            uPage.db.CommitTran()
            '14/10/10   James Woosnam   SIR2299 - Re-read data after save
            ds.Clear()
            Me.ReadRecord()
        Catch e As Exception
            uPage.PageError = e.ToString

            uPage.db.RollbackTran()
        End Try
        '22/5/10    jamed Woosnamw  Move rediect outside try catch so does trigger additional rollback
        If uPage.IsValid Then
            If saveType = "SaveAndReturn" Then
                Response.Redirect("../pages/pg480SubscriberImport.aspx" & Me.GetSubscriberImportQueryString(Me.ds.Tables(0).Rows(0)("SubscriberImportBatchId")))
            Else
                Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=Record Saved&SubscriberImportId=" & Me.SubscriberImportId.Text)
            End If
        End If
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If Me.IsPageValidForStatus("") Then
            SaveRecord()
        End If
    End Sub
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = ds
        PageSetup()
        uPage.PagePreRender()
    End Sub

    'Private Sub CloseBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseBtn.Click
    '    Dim scriptText As String = "<script language=javascript>window.opener.SetReturn('Form1','CloseAndReturnToSelect'); self.close();</script>"
    '    Page.RegisterClientScriptBlock("MyScript", scriptText)
    'End Sub

    Private Sub BuildDuplicateList()
        Dim html As String = Nothing
        '******************************************************
        'Description:	Builds and Displays a duplicate subscriber list
        '******************************************************
        Dim strHtml As String = Nothing
        Dim strCommandText As String = Nothing
        '27/11/07   Julian Gates    Add code to SQL to replace "'" with "''" to stop BuildDuplicateList generating error SIR 1309
        '17/02/11   Julian Gates    Add SubscriberEmail as modification.
        '14/12/12   Julian Gates    SIR2946 - Add subscriber billing address to list
        '4/12/19    James Woosnam   SIR4950 - Collate by SQL_Latin1_General_CP1_CI_AI and convert subscriber name to NVARCHAR
        '3/1/20	    James Woosnam	SIR5133 - Show subs with duplicate email addresses
        strCommandText = "SELECT top 100 Subscriber.SubscriberId" _
                & " , Subscriber.FirstName" _
                & " , Subscriber.LastName" _
                & " , Subscriber.SubscriberCategory" _
                & " , Subscriber.SubscriberStatus" _
                & "	, dbo.f530SubscriberAddressDisplay((SELECT MAX(SubscriberAddress.SubscriberAddressId)" _
                & "		                                FROM SubscriberAddress " _
                & "		                                WHERE SubscriberAddress.SubscriberId = Subscriber.SubscriberId " _
                & "                                     AND SubscriberAddress.AddressType = 'Postal'" _
                & "                                     AND SubscriberAddress.AddressDescription = 'Main')" _
                & "                                 ,'SingleLine') SubscriberPostalAddress" _
                & "	, dbo.f530SubscriberAddressDisplay((SELECT MAX(SubscriberAddress.SubscriberAddressId)" _
                & "		                                FROM SubscriberAddress " _
                & "		                                WHERE SubscriberAddress.SubscriberId = Subscriber.SubscriberId " _
                & "                                     AND SubscriberAddress.AddressType = 'Postal'" _
                & "                                     AND SubscriberAddress.AddressDescription = 'Billing')" _
                & "                                 ,'SingleLine') SubscriberBillingAddress" _
                & "	, dbo.f530SubscriberAddressDisplay((SELECT MAX(SubscriberAddress.SubscriberAddressId)" _
                & "		                                FROM SubscriberAddress " _
                & "		                                WHERE SubscriberAddress.SubscriberId = Subscriber.SubscriberId " _
                & "                                     AND SubscriberAddress.AddressType = 'Email'" _
                & "                                     AND SubscriberAddress.AddressDescription = 'Main')" _
                & "                                 ,'SingleLine') SubscriberEmail" _
                & " FROM Subscriber" _
                & "     LEFT JOIN SubscriberAddress sa" _
                & "     ON sa.SubscriberId = Subscriber.SubscriberId" _
                & "     And sa.AddressType = 'Email'" _
                & "     And sa.AddressDescription = 'Main'" _
                & " WHERE ((CAST(Subscriber.LastName AS NVARCHAR(50)) =N'" & Replace(Me.LastName.Text, "'", "''") & "'  COLLATE SQL_Latin1_General_CP1_CI_AI" _
                & "         AND CAST(CASE WHEN LEN(ISNULL(Subscriber.FirstName,'')) > 0 THEN LEFT(Subscriber.FirstName,1) ELSE '' END AS NVARCHAR(50))" _
                & "         = CASE WHEN LEN(ISNULL(N'" & Replace(Me.FirstName.Text, "'", "N''") & "',''))>0 THEN LEFT(N'" & Replace(Me.FirstName.Text, "'", "N''") & "',1) ELSE N'' END  COLLATE SQL_Latin1_General_CP1_CI_AI" _
                & "         )" _
                & "        OR sa.AddressText = '" & Me.EmailAddress.Text & "'" _
                & "        )" _
                & " AND Subscriber.SubscriberStatus IN ('Proposed', 'Current')" _
                & " ORDER BY Subscriber.LastName,Subscriber.FirstName"

        Dim tbl As DataTable = New BusinessLogic.Database(uPage.PrimaryConnection).GetDataTableFromSQL(strCommandText)
        Try
            For Each row As DataRow In tbl.Rows
                If Me.DuplicateSubscriberIdToUse.Value <> "" Then
                    If Me.DuplicateSubscriberIdToUse.Value = row.Item("SubscriberId") Then
                        strHtml = strHtml & "<TR bgcolor='MistyRose'>"
                    Else
                        strHtml = strHtml & "<TR>"
                    End If
                Else
                    strHtml = strHtml & "<TR>"
                End If
                strHtml += "<TD align=center>" _
                        & " <A href='../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & row.Item("SubscriberId") _
                        & "' Title='View Subscriber' Target='_blank'>" & row.Item("SubscriberId") & "</A></Span>" _
                        & "</TD>"
                strHtml += "<TD>" _
                        & "<P class=fldView>" & row.Item("LastName") & ", " & uPage.StdCode.IsNull(row.Item("FirstName"), "") & "</P>" _
                        & "</TD>"
                strHtml += "<TD>" _
                        & "<P class=fldView>" & row.Item("SubscriberCategory") & "</P>" _
                        & "</TD>"
                strHtml += "<TD>" _
                        & "<P class=fldView>" & row.Item("SubscriberStatus") & "</P>" _
                        & "</TD>"
                strHtml += "<TD>" _
                        & "<P class=fldView>" & uPage.StdCode.IsNull(row.Item("SubscriberPostalAddress"), "") & "</P>" _
                        & "</TD>"
                strHtml += "<TD>" _
                        & "<P class=fldView>" & uPage.StdCode.IsNull(row.Item("SubscriberBillingAddress"), "") & "</P>" _
                        & "</TD>"
                strHtml += "<TD>" _
                        & "<P class=fldView>" & row.Item("SubscriberEmail") & "</P>" _
                        & "</TD>"
                strHtml += "<TD width=50 align=center>" _
                        & "<p class='lnkMaintNew'><A href='javascript:SubmitCommandData(""Use" & row.Item("SubscriberId") _
                        & """)' Title='Use this record' ><Span class=hyperLinkButtonText>Use</Span></A></p>" _
                        & "</TD>"
                strHtml += "</TR>"
            Next
        Catch e As Exception
            uPage.PageError = e.ToString
        End Try
        'Assign grid to Label
        Me.lblDuplicateList.Text = strHtml
    End Sub

    Private Sub BuildExistingSubscriptionList()
        Dim html As String = Nothing
        '******************************************************
        'Description:	Builds and Displays a existing subscriptions list
        '22/3/11    James Woosnam   Add GroupSubscriberName
        '******************************************************
        Dim sAdditionalProductCodes As String = uPage.db.IsDBNull(Me.ds.Tables("SubscriberImport").Rows(0)("AdditionalProductsCode"), "")
        Dim strHtml As String = Nothing
        Dim strCommandText As String = Nothing

        strCommandText = "SELECT" & vbCrLf
        strCommandText += "     SalesOrderLine.OrderNumber" & vbCrLf
        strCommandText += "     ,SalesOrder.OrderDate" & vbCrLf
        strCommandText += "     ,SalesOrderLine.ProductCode" & vbCrLf
        strCommandText += "     ,GroupSubscriberName = Subscriber.SubscriberName" & vbCrLf
        strCommandText += "     ,SalesOrderLine.RecurringSubscriptionEndDate" & vbCrLf
        strCommandText += " FROM tmpSubscriberImport" & vbCrLf
        strCommandText += " 		INNER JOIN SalesOrder ImportIntoOrder" & vbCrLf
        strCommandText += " 		ON ImportIntoOrder.OrderNumber = tmpSubscriberImport.OrderNumber" & vbCrLf
        strCommandText += "     INNER JOIN SalesOrderLine" & vbCrLf
        strCommandText += "		ON SalesOrderLine.SubscriberId = CASE DuplicateAction WHEN 'Selected' THEN tmpSubscriberImport.DuplicateSubscriberIdToUse " & vbCrLf
        strCommandText += "									ELSE ISNULL(tmpSubscriberImport.MatchedSubscriberId,0) END" & vbCrLf
        strCommandText += "		AND ISNULL(SalesOrderLine.IsCancel,0) = 0" & vbCrLf
        strCommandText += "		AND SalesOrderLine.OrderNumber <> tmpSubscriberImport.OrderNumber" & vbCrLf
        strCommandText += "		INNER JOIN SalesOrder" & vbCrLf
        strCommandText += "		    INNER JOIN Subscriber" & vbCrLf
        strCommandText += "		    On Subscriber.SubscriberId = SalesOrder.SubscriberId" & vbCrLf
        strCommandText += "		On SalesOrder.OrderNumber = SalesOrderLine.OrderNumber" & vbCrLf
        '14/7/08	James Woosnam	SIR1554	- Add Completed Orders into Dup Subscription query
        strCommandText += "		AND SalesOrder.SalesOrderStatus IN ('Confirmed','Complete')" & vbCrLf
        '25/7/08	Julian Gates	SIR1556 - Add line below to fix bug raised by Athena to stop previous subscriptions showing.
        '2/10/12    James Woosnam   SIR2874 - If additional products populated use these to check for existing subscriptions
        If sAdditionalProductCodes <> "" Then
            strCommandText += "     AND (SalesOrderLine.ProductCode = ImportIntoOrder.PrimaryProductCode" & vbCrLf
            strCommandText += "           OR SalesOrderLine.ProductCode IN (" & sAdditionalProductCodes & "))" & vbCrLf
        Else
            strCommandText += "     AND SalesOrderLine.ProductCode = ImportIntoOrder.PrimaryProductCode" & vbCrLf
        End If
        strCommandText += "		INNER JOIN Product" & vbCrLf
        strCommandText += "		On Product.ProductCode = SalesOrder.PrimaryProductCode" & vbCrLf
        strCommandText += "	WHERE tmpSubscriberImport.SubscriberImportId = " & Me.SubscriberImportId.Text & vbCrLf
        strCommandText += "		AND ( ISNULL(ImportIntoOrder.SubscriptionStartDateForAdd ,GETDATE()) BETWEEN ISNULL(SalesOrderLine.RecurringSubscriptionStartDate,'01-jan-1900') AND ISNULL(SalesOrderLine.RecurringSubscriptionEndDate,'01-jan-3000')" & vbCrLf
        strCommandText += "			OR ISNULL(Product.RecurringSubscriptionFlag,0) = 0)" & vbCrLf

        'uPage.PageError = strCommandText
        'Exit Sub
        Dim tbl As DataTable = New BusinessLogic.Database(uPage.PrimaryConnection).GetDataTableFromSQL(strCommandText)
        Try
            For Each row As DataRow In tbl.Rows
                strHtml = strHtml & "<TR>"
                strHtml += "<TD align=center>" _
                        & " <A href='../pages/pg142OrderMaint2.aspx?PageMode=Update&OrderNumber=" & row.Item("OrderNumber") _
                        & "' Title='View Order' Target='_blank'>" & row.Item("OrderNumber") & "</A></Span>" _
                        & "</TD>"
                strHtml += "<TD>" _
                        & "<P class=fldView>" & CStr(row.Item("GroupSubscriberName")) & "</P>" _
                        & "</TD>"
                strHtml += "<TD>" _
                        & "<P class=fldView>" & CStr(row.Item("ProductCode")) & "</P>" _
                        & "</TD>"
                strHtml += "<TD>" _
                        & "<P class=fldView>" & CDate(row.Item("OrderDate")).ToString("dd-MMM-yy") & "</P>" _
                        & "</TD>"
                If uPage.db.IsDBNull(row.Item("RecurringSubscriptionEndDate")) Then
                    strHtml += "<TD>" _
                       & "<P class=fldView>&nbsp;</P>" _
                       & "</TD>"
                Else
                    strHtml += "<TD>" _
                            & "<P class=fldView>" & CDate(row.Item("RecurringSubscriptionEndDate")).ToString("dd-MMM-yy HH:mm:ss") & "</P>" _
                            & "</TD>"
                End If
                'strHtml += "<TD>&nbsp;</TD>"
                strHtml += "</TR>"
            Next
        Catch e As Exception
            uPage.PageError = e.ToString
        End Try
        'Assign grid to Label
        Me.lblExistingSubscriptionList.Text = strHtml
    End Sub

    Private Sub SaveAndReturnBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveAndReturnBtn.Click
        If Me.IsPageValidForStatus("") Then
            SaveRecord(, "SaveAndReturn")
        End If
    End Sub

    Private Sub IgnoreDuplicateBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IgnoreDuplicateBtn.Click
        If Me.IsPageValidForStatus("") Then
            Me.ds.Tables("SubscriberImport").Rows(0)("DuplicateAction") = "Ignore"
            Me.DuplicateSubscriberIdToUse.Value = ""
            SaveRecord()
        End If
    End Sub

    Private Sub ExisitngSubscriptionIgnoreBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExisitngSubscriptionIgnoreBtn.Click
        If Me.IsPageValidForStatus("") Then
            Me.ExistingSubscriptionAction.Text = "Ignore"
            SaveRecord()
        End If
    End Sub

    Private Sub ExisitngSubscriptionGroupOnlyBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExisitngSubscriptionGroupOnlyBtn.Click
        If Me.IsPageValidForStatus("") Then
            Me.ExistingSubscriptionAction.Text = "GroupOnly"
            SaveRecord()
        End If

    End Sub

    Public Function GetSubscriberImportQueryString(ByVal strSubscriberImportBatchId As String) As String
        Dim SQL As String = Nothing
        Dim QueryString As String = Nothing
        '22/3/11    James Woosnam   Add ImportFileName
        Try
            SQL = "Select tmpSubscriberImport.SubscriberImportBatchId" _
                        & "         ,tmpSubscriberImport.GroupSubscriberId" _
                        & "         ,tmpSubscriberImport.CompanyId" _
                        & "         ,tmpSubscriberImport.OrderNumber" _
                        & " From tmpSubscriberImport" _
                        & " WHERE SubscriberImportBatchId = " & strSubscriberImportBatchId

            Dim da As New SqlDataAdapter(SQL, uPage.PrimaryConnection)
            Dim tblParams As New DataTable
            da.Fill(tblParams)

            If tblParams.Rows.Count <> 0 Then
                QueryString = "?SubscriberImportBatchId=" & tblParams.Rows(0)("SubscriberImportBatchId")
                QueryString += "&SubscriberId=" & tblParams.Rows(0)("GroupSubscriberId")
                QueryString += "&CompanyId=" & tblParams.Rows(0)("CompanyId")
                QueryString += "&OrderNumber=" & tblParams.Rows(0)("OrderNumber")
                QueryString += "&ImportFileName=" & tblParams.Rows(0)("ImportFileName")
            End If

        Catch ex As Exception

        End Try
        Return QueryString

    End Function

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&SubscriberImportId=" & Me.SubscriberImportId.Text)
    End Sub

    Private Sub ReturnBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReturnBtn.Click
        Response.Redirect("../pages/pg480SubscriberImport.aspx" & Me.GetSubscriberImportQueryString(Me.ds.Tables(0).Rows(0)("SubscriberImportBatchId")))
    End Sub
End Class
