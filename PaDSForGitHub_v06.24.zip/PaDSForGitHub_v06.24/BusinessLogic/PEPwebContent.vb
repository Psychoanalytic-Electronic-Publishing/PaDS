﻿Imports System.Data.SqlClient
Imports BusinessLogic.UserSession
Imports System.Environment


Public Class PEPwebContent
    '30/6/21    James Woosnam   SIR5273 - In ExecuteGetPEPWebSessionLog logon as admin user and use and store new SessionActivityId field to get new data

#Region "Class Properties"
    Dim batchLog As BatchLog = Nothing
    Dim BatchJobId As Integer = 0

    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property
    Dim UserSess As UserSession = Nothing

#End Region
    Sub New(ByVal db As BusinessLogic.Database)
        Me.db = db
    End Sub
    Sub New(ByVal db As BusinessLogic.Database, UserSess As UserSession)
        Me.db = db
        Me.UserSess = UserSess
    End Sub
    Public Function GetAPIJObject(URLQuery As String) As Newtonsoft.Json.Linq.JObject
        Dim url As String = ""
        Try
            Dim webReq As System.Net.HttpWebRequest
            Dim response As System.Net.HttpWebResponse = Nothing
            Dim reader As IO.StreamReader
            url = db.GetParameterValue("PEPwebAPIRoot", "https://stage-api.pep-web.rocks/v2/") & URLQuery
            webReq = System.Net.WebRequest.Create(url)
            webReq.UserAgent = "PaDS"
            webReq.Method = "GET"
            webReq.Timeout = 300000
            webReq.Headers("client-id") = db.GetParameterValue("PaDSClientIdForOPAS", 3)
            webReq.Headers("x-api-authorize") = db.GetParameterValue("PEPWebAPIKey")
            webReq.Headers("client-session") = Me.UserSess.UserSessionId
            '10/2/22    James Woosnam   Add x-pep-auth header
            webReq.Headers("x-pep-auth") = "true"
            batchLog.Update("Headers(""client-session""):" & webReq.Headers("client-session"))
            batchLog.Update("Headers(""x-pep-auth""):" & webReq.Headers("x-pep-auth"))
            response = webReq.GetResponse()
            reader = New IO.StreamReader(response.GetResponseStream())

            Dim rawresp As String
            rawresp = reader.ReadToEnd()

            Dim rss As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(rawresp)
            Return rss
        Catch ex As Exception
            Throw New Exception("GetMetadataJObject Failed:" & ex.Message & " URL:" & url, ex)
        End Try
    End Function
    Dim LastURLUserd As String = ""
    Private Function GetMetadataJObject(URLQuery As String) As Newtonsoft.Json.Linq.JObject
        Dim url As String = ""
        Try
            Dim webReq As System.Net.HttpWebRequest
            Dim response As System.Net.HttpWebResponse = Nothing
            Dim reader As IO.StreamReader
            url = db.GetParameterValue("PEPwebContentMetadataRoot", "http://api.psybrarian.com/v2/Metadata/") & URLQuery
            LastURLUserd = url
            webReq = System.Net.WebRequest.Create(url)
            webReq.UserAgent = "PaDS"
            webReq.Method = "GET"
            webReq.Headers("client-id") = db.GetParameterValue("PaDSClientIdForOPAS", 3)
            '10/2/22    James Woosnam   Add x-pep-auth header
            webReq.Headers("x-pep-auth") = "true"
            If Me.UserSess IsNot Nothing Then webReq.Headers("client-session") = Me.UserSess.UserSessionId
            response = webReq.GetResponse()

            reader = New IO.StreamReader(response.GetResponseStream())

            Dim rawresp As String
            rawresp = reader.ReadToEnd()
            Dim rss As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(rawresp)
            Return rss
        Catch ex As Exception
            Throw New Exception("GetMetadataJObject Failed:" & ex.Message & " URL:" & url, ex)
        End Try
    End Function
    Enum ContentTypes
        Journals
        Books
        Videos
        Volumes
        Documents
    End Enum
    Public Function GetContentTable(ContentType As ContentTypes, Optional SubDirectory As String = Nothing, Optional query As String = Nothing) As DataTable
        Try
            Select Case ContentType
                Case ContentTypes.Documents
                    If SubDirectory = Nothing Then
                        Throw New Exception("For Documents a subdirectory must be supplied")
                    End If

            End Select
            Dim qs As String = IIf(ContentType = ContentTypes.Documents, "Contents", ContentType.ToString) & IIf(SubDirectory <> Nothing, "/" & SubDirectory, "") & IIf(query <> Nothing, "/?" & query, "")
            Dim metadatObj As Newtonsoft.Json.Linq.JObject = GetMetadataJObject(qs)
            If metadatObj Is Nothing Then Return Nothing
            Dim sourceData = From p In metadatObj(metadatObj.First.Path)("responseSet")
                             Select p
            Dim t As DataTable = db.GetDataTableFromSQL("SELECT * FROM Content" & ContentType.ToString & " WHERE 1=2")
            For Each sourceItem In sourceData
                Dim nr As DataRow = t.NewRow
                For Each col As DataColumn In t.Columns
                    nr(col.ColumnName) = sourceItem(col.ColumnName)
                Next
                t.Rows.Add(nr)
            Next
            Return t
        Catch ex As Exception
            Throw New Exception("GetContentTable Failed:" & ex.Message, ex)

        End Try
    End Function
    Public Sub RepopulateLocalContentTable(ContentType As ContentTypes)
        Try
            Dim t As DataTable = Me.GetContentTable(ContentType)
            Dim sql As String = ""
            sql += "DELETE FROM Content" & ContentType.ToString & NewLine
            db.ExecuteSQL(sql)
            Me.AddToLocalContentTableFromTable(ContentType, t, True)
            If batchLog IsNot Nothing Then batchLog.Update(t.Rows.Count & " " & ContentType & " rows added using:" & LastURLUserd)

        Catch ex As Exception
            Throw New Exception("RepopulateLocalContent Failed:" & ex.Message, ex)


        End Try
    End Sub
    Public Sub AddToTableFromTable(tbl As DataTable, IgnoreDuplicates As Boolean, SkipColumnNames As String)
        Dim sql As String = ""
        If tbl.TableName = "" Then Throw New Exception("Table must have a name in AddToTableFromTable")
        Try
            Dim tableName As String = tbl.TableName
            For Each r As DataRow In tbl.Rows
                If IgnoreDuplicates Then
                    sql += "If Not EXISTS(Select * FROM " & tableName & " WHERE 1=1 " & NewLine
                    Dim ds As New DataSet
                    Dim da As New SqlDataAdapter(New SqlCommand("Select * from " & tableName & " WHERE 1=2 ", db.DBConnection, db.DBTransaction))
                    da.FillSchema(ds, SchemaType.Mapped, tableName)
                    da.Fill(ds, tableName)
                    da.FillSchema(ds, SchemaType.Mapped, tableName)
                    For Each c As DataColumn In ds.Tables(tableName).PrimaryKey

                        If db.IsDBNull(r(c.ColumnName)) Then
                        Else
                            sql += " AND " & c.ColumnName & " = '" & Left(CStr(r(c.ColumnName)), 200).Replace("'", "''") & "'"
                        End If
                    Next
                    sql += ")" & NewLine
                End If
                sql += "INSERT INTO " & tableName & NewLine
                sql += " ("
                Dim colSQL As String = ""
                For Each c As DataColumn In tbl.Columns
                    If SkipColumnNames.ToLower.Contains(c.ColumnName.ToLower) Then
                    Else
                        colSQL += IIf(colSQL <> "", ",", "")
                        colSQL += c.ColumnName
                    End If

                Next
                sql += colSQL & " )"
                sql += " VALUES("
                colSQL = ""
                For Each c As DataColumn In tbl.Columns
                    If SkipColumnNames.ToLower.Contains(c.ColumnName.ToLower) Then
                    Else
                        colSQL += IIf(colSQL <> "", ",", "")
                        If db.IsDBNull(r(c.ColumnName)) Then
                            colSQL += "NULL"
                        Else
                            colSQL += "'" & Left(CStr(r(c.ColumnName)), 200).Replace("'", "''") & "'"
                        End If
                    End If

                Next
                sql += colSQL & " )" & NewLine

            Next
            If sql <> "" Then db.ExecuteSQL(sql)
        Catch ex As Exception
            Throw New Exception("RepopulateLocalContent Table:" & tbl.TableName & " Failed:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub AddToLocalContentTableFromTable(ContentType As ContentTypes, ContentTable As DataTable, IgnoreDuplicates As Boolean)
        Dim sql As String = ""
        Try
            '     Dim t As DataTable = Me.GetContentTable(ContentType)'
            Dim tableName As String = "Content" & ContentType.ToString
            For Each r As DataRow In ContentTable.Rows
                If IgnoreDuplicates Then
                    sql += "If Not EXISTS(Select * FROM " & tableName & " WHERE 1=1 " & NewLine
                    Dim ds As New DataSet
                    Dim da As New SqlDataAdapter(New SqlCommand("Select * from " & tableName & " WHERE 1=2 ", db.DBConnection, db.DBTransaction))
                    da.FillSchema(ds, SchemaType.Mapped, tableName)
                    da.Fill(ds, tableName)
                    da.FillSchema(ds, SchemaType.Mapped, tableName)
                    For Each c As DataColumn In ds.Tables(tableName).PrimaryKey

                        If db.IsDBNull(r(c.ColumnName)) Then
                        Else
                            sql += " AND " & c.ColumnName & " = '" & Left(CStr(r(c.ColumnName)), 200).Replace("'", "''") & "'"
                        End If
                    Next
                    sql += ")" & NewLine
                End If
                sql += "INSERT INTO " & tableName & "(" & NewLine
                For Each c As DataColumn In ContentTable.Columns
                    sql += IIf(c.Ordinal = 0, "", ",") & c.ColumnName
                Next
                sql += ")" & NewLine
                sql += " VALUES("
                For Each c As DataColumn In ContentTable.Columns
                    Dim val As String = IIf(c.Ordinal = 0, "", ",")
                    If db.IsDBNull(r(c.ColumnName)) Then
                        val += "NULL"
                    Else
                        val += "'" & Left(CStr(r(c.ColumnName)), 200).Replace("'", "''") & "'"
                    End If
                    sql += val
                Next
                sql += " )" & NewLine

            Next
            If sql <> "" Then db.ExecuteSQL(sql)
        Catch ex As Exception
            Throw New Exception("RepopulateLocalContent ContentType:" & ContentType.ToString & " ContentTable:" & ContentTable.TableName & " Failed:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub RepopulateVolumesAndDocs()
        Dim sql As String = ""
        Dim t As DataTable = Me.GetContentTable(BusinessLogic.PEPwebContent.ContentTypes.Journals)
        t.TableName = "Journals"
        Dim msg As String = ""
        '  For Each r As DataRow In t.Rows
        Dim r2 As DataRow = Nothing
        db.BeginTran()
        Try
            sql = "
                    DELETE FROM ContentVolumes  
                    DELETE FROM ContentDocuments 
                    "
            ' WHERE PEPCode = '" & r("PEPCode") & "'
            'WHERE PEPCode = '" & r("PEPCode") & "'
            db.CommandTimeout = 1200 ' 20minutes
            db.ExecuteSQL(sql)
            batchLog.Update("ContentVolumes & ContentDocuments Deleted:")
            Dim vols As DataTable = Me.GetContentTable(BusinessLogic.PEPwebContent.ContentTypes.Volumes, "", "limit=30000")
            vols.TableName = "Volumes"
            Me.AddToLocalContentTableFromTable(ContentTypes.Volumes, vols, True)
            batchLog.Update(vols.Rows.Count & " volumes added using:" & LastURLUserd)


            For Each r2 In vols.Rows
                Try
                    Dim docs As DataTable = Me.GetContentTable(BusinessLogic.PEPwebContent.ContentTypes.Documents, r2("PEPCode") & "/" & r2("vol"), "limit=10000")
                    If docs Is Nothing Then
                        batchLog.Update(r2("PEPCode") & "/" & r2("vol") & " no content retrieved:")
                        Exit Try
                    End If
                    docs.TableName = "Documents"
                    Me.AddToLocalContentTableFromTable(ContentTypes.Documents, docs, True)
                    batchLog.Update(docs.Rows.Count & " docs added using:" & LastURLUserd)
                Catch ex As Exception
                    Throw New Exception(LastURLUserd & " failed:" & ex.Message)
                End Try

            Next
            batchLog.Update("All volumes and documents added.")

            db.CommitTran()
        Catch ex As Exception
            Dim rollbackTimeoutMsg As String = Nothing
            Try
                db.RollbackTran()
            Catch ex1 As Exception
                If ex1.Message.Contains("Execution Timeout Expired") Then
                    'Roolback can timeout as the rollback uses the timeout in the connection string which for pads is set to 2 sec.  It throws an error even though rollback contiunes, so we can ignore it
                    rollbackTimeoutMsg = "Rollback timed out, but should have continued"
                Else
                    Throw ex
                End If
            End Try
            Throw New Exception("RepopulateVolumesAndDocs failed:" & ex.Message & IIf(rollbackTimeoutMsg <> Nothing, Environment.NewLine & rollbackTimeoutMsg, "") & Environment.NewLine & "LastURL:" & LastURLUserd, ex)
        End Try
        '    Next
    End Sub
    Public Sub SubmitRepopulateAllPEPWebContent()

        Dim bj As New BusinessLogic.BatchJob(db)
        bj.SubmittedByUserSessionId = Me.UserSess.UserSessionIdGUID
        bj.CreateBatchJobEntry("RepopulateAllPEPWebContent", db)
    End Sub
    Sub ExecuteRepopulateAllPEPWebContent(BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        batchLog = New BatchLog("RepopulateAllPEPWebContent", "", Me.db, BatchJobId)
        Try
            If Me.UserSess Is Nothing Then
                Me.UserSess = New BusinessLogic.UserSession(db)
                Me.UserSess.Restore("")
                Me.UserSess.Logon(db.GetParameterValue("AdminUserName", "AdminUser"), db.GetParameterValue("AdminPassword", "Zedra001"))
            End If
            Me.RepopulateLocalContentTable(BusinessLogic.PEPwebContent.ContentTypes.Journals)
            batchLog.Update("Journals repopulated")
            Me.RepopulateLocalContentTable(BusinessLogic.PEPwebContent.ContentTypes.Books)
            batchLog.Update("Books repopulated")
            Me.RepopulateLocalContentTable(BusinessLogic.PEPwebContent.ContentTypes.Videos)
            batchLog.Update("Videos repopulated")
            Me.RepopulateVolumesAndDocs()
            batchLog.Update("Valumes and docs repopulated")
            batchLog.Update("RepopulateAllPEPWebContent Complete", "Complete")

        Catch ex As Exception
            batchLog.Update(ex.Message, "Failed")
            Throw New Exception("RepopulateAllPEPWebContent failed:" & ex.Message, ex)
        End Try
    End Sub
    Sub ExecuteGetPEPWebSessionLog(BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        '15/12/21   James Woosnam   Allow the No of Rows limit to be changed in the parameters
        Dim NoOfRowsLimit As Integer = Parameters.GetValue("NoOfRowsLimit", 145000)
        Me.ExecuteGetPEPWebSessionLog(NoOfRowsLimit)
    End Sub
    Sub ExecuteGetPEPWebSessionLog(BatchLog As BatchLog, Optional NoOfRowsLimit As Integer = 100000)
        Me.batchLog = BatchLog
        Me.ExecuteGetPEPWebSessionLog()
    End Sub
    Sub ExecuteGetPEPWebSessionLog(Optional NoOfRowsLimit As Integer = 100000)
        Dim batchLogStartedHere As Boolean = False
        If batchLog Is Nothing Then
            batchLog = New BatchLog("ExecuteGetPEPWebSessionLog", "", Me.db, BatchJobId)
            batchLogStartedHere = True
        End If
        Try
            batchLog.Update("ExecuteGetPEPWebSessionLog Started")
            '30/6/21    James Woosnam   SIR5273 - Create new session and Log on as an admin user to pass to OPAS
            Dim SessForJob As New BusinessLogic.UserSession(db)
            SessForJob.Restore("")
            SessForJob.Logon(db.GetParameterValue("AdminUserName", "AdminUser"), db.GetParameterValue("AdminPassword", "Zedra001"))
            Dim pc As New BusinessLogic.PEPwebContent(db, SessForJob)
            pc.batchLog = Me.batchLog '6/7/21 - pass batch log so errors are recorded correctly
            pc.batchLog.Update("SessionStarted:" & pc.UserSess.UserSessionId)
            Dim cmd As New SqlCommand("SELECT top 1 * FROM PEPWebSessionLog ORDER BY LastUpdate DESC", Me.db.DBConnection, Me.db.DBTransaction)
            Dim da As New SqlDataAdapter(cmd)
            Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(da)
            da.InsertCommand = cmdBld.GetInsertCommand()
            Dim t As New DataTable
            t.TableName = "PEPWebSessionLog"
            da.Fill(t)
            Dim StartFrom As Date = "01-Apr-2021"
            '30/6/21    James Woosnam   SIR5273 - Use and store new SessionActivityId field to get new data
            Dim lastSessionActivityId As Integer = 0
            If t.Rows.Count <> 0 Then
                StartFrom = CDate(t.Rows(0)("LastUpdate")).AddHours(-1)
                lastSessionActivityId = db.DLookup("MAX(SessionActivityId)", "PEPWebSessionLog", "")
            End If
            '22/2/21    Change reports endpoint to be under Admin
            '3/6/21     Changed limit to be 100,000 
            '6/7/21     James Woosnam   SIR5273 - Add sortorder=asc and  update logging
            '14/10/21   James Woosnam   Limit increased to 100,000 to ensure we can do a whole day
            '15/12/21   James Woosnam   Allow the No of Rows limit to be changed in the parameters
            ' 31/12/21  James Woosnam   SIR5394 - Add correct time format for startdate
            Dim qs As String = "Admin/Reports/Session-Log?startdate=" & StartFrom.ToString("yyyyMMddHHmmss") & "&limit=" & NoOfRowsLimit & "&offset=0&download=false&sortorder=asc"
            batchLog.Update("OPAS Query:" & qs)
            Dim metadatObj As Newtonsoft.Json.Linq.JObject = pc.GetAPIJObject(qs)
            If metadatObj Is Nothing Then
                batchLog.Update("No data reterived")
            Else
                batchLog.Update("Data reterived")
                Dim sourceData = From p In metadatObj(metadatObj.First.Path)("responseSet")
                                 Select p
                Dim rowCount As Integer = 0
                batchLog.Update(sourceData.Count & " records retrieved")
                For Each sourceItem As Newtonsoft.Json.Linq.JObject In sourceData
                    If CInt(sourceItem("row")("session_activity_id")) > lastSessionActivityId Then
                        Dim nr As DataRow = t.NewRow
                        For Each col As DataColumn In t.Columns
                            If col.ColumnName = "SessionActivityId" And sourceItem("row")("session_activity_id").ToString <> "" Then nr("SessionActivityId") = sourceItem("row")("session_activity_id").ToString
                            If col.ColumnName = "UserId" And sourceItem("row")("global_uid").ToString <> "" Then nr("UserId") = sourceItem("row")("global_uid").ToString
                            If col.ColumnName = "UserSessionId" And sourceItem("row")("session_id").ToString <> "" Then nr("UserSessionId") = sourceItem("row")("session_id").ToString
                            If col.ColumnName = "SessionStart" And sourceItem("row")("session_start").ToString <> "" Then nr("SessionStart") = sourceItem("row")("session_start")
                            If col.ColumnName = "SessionEnd" And sourceItem("row")("session_end").ToString <> "" Then nr("SessionEnd") = sourceItem("row")("session_end")
                            If col.ColumnName = "ItemOfInterest" And sourceItem("row")("item_of_interest").ToString <> "" Then nr("ItemOfInterest") = Left(sourceItem("row")("item_of_interest").ToString, 300)
                            If col.ColumnName = "Endpoint" And sourceItem("row")("endpoint").ToString <> "" Then nr("Endpoint") = Left(sourceItem("row")("endpoint").ToString, 500)
                            If col.ColumnName = "Params" And sourceItem("row")("params").ToString <> "" Then nr("Params") = Left(sourceItem("row")("params").ToString, 3000)
                            If col.ColumnName = "ReturnStatusCode" And sourceItem("row")("return_status_code").ToString <> "" Then nr("ReturnStatusCode") = Left(sourceItem("row")("return_status_code").ToString, 50)
                            If col.ColumnName = "ReturnAddedStatusMessage" And sourceItem("row")("return_added_status_message").ToString <> "" Then nr("ReturnAddedStatusMessage") = Left(sourceItem("row")("return_added_status_message").ToString, 3000)
                            If col.ColumnName = "LastUpdate" And sourceItem("row")("last_update").ToString <> "" Then nr("LastUpdate") = sourceItem("row")("last_update")
                        Next
                        t.Rows.Add(nr)
                        rowCount += 1
                    End If
                Next
                da.Update(t)
                batchLog.Update(rowCount & " rows added to database")
            End If
            batchLog.Update("ExecuteGetPEPWebSessionLog Complete", IIf(batchLogStartedHere, "Complete", ""))
        Catch ex As Exception
            batchLog.Update(ex.Message, IIf(batchLogStartedHere, "Failed", ""))
            Throw New Exception("ExecuteGetPEPWebSessionLog failed:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub PopulateUserActivityLog(BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)

        batchLog = New BatchLog("PopulateUserActivityLog", "", Me.db, BatchJobId)

        Try
            Me.ExecuteGetPEPWebSessionLog(BatchJobId, Parameters)
            batchLog.Update("sp601PopulateActivityLog Starting")
            Dim cmd As New SqlCommand("sp601PopulateActivityLog", db.DBConnection, db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandTimeout = 36000
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchLogId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      batchLog.BatchLogId))
            cmd.ExecuteNonQuery()

            batchLog.Update("sp601PopulateActivityLog Complete", "Complete")

        Catch ex As Exception
            batchLog.Update("sp601PopulateActivityLog failed:" & ex.Message, "Failed")
            Throw New Exception(ex.ToString)
        End Try

    End Sub
End Class

