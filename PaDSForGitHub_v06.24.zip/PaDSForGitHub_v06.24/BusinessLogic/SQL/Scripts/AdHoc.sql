begin tran

exec sp483SubscriberImport
						@SubscriberImportBatchId =4994
						,@UserName = 'jwoosnam'
						,@RunMode = 'import' --Check or Import
						--,@AdditionalProducts=null 
						,@IndividualSubscriberImportId  = 1419
						,@ReturnCode =0
						,@ErrorMessage=''

select SubscriberId  from tmpSubscriberImport where SubscriberImportId = 1419

rollback tran