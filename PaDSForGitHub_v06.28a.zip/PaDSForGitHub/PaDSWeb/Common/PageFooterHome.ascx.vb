Partial Class PageFooter
    Inherits System.Web.UI.UserControl
    Dim pg As Object
    Dim pageTitle As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object


    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        pg = Me.Parent.NamingContainer.Page
        pageTitle = pg.uPage.pageTitle
        If pageTitle = "Subscriber Update" Then
            'Dont show main menu
        Else
            Me.lblMenuBar.Text = pg.uPage.OutputMenu(pg.uPage.UserSession.LoggedIn)
        End If
    End Sub

    Function BuildFooterText() As String
        Dim strH As String = Nothing
        strH = strH & "<table width=""750"">" & Chr(13)
        strH = strH & "  <tr>" & Chr(13)
        strH = strH & "    <td align=""left"">" & Chr(13)
        strH = strH & "         <span class=""Contact"" align=left>For more information please contact: </span>" & Chr(13)
        strH = strH & "    </td>" & Chr(13)
        strH = strH & "    <td align=centre>" & Chr(13)
        strH = strH & "      <span class=""contact"">" & Chr(13)
        strH = strH & "        Version:" & Me.pg.upage.db.PaDSVersion & " [Web:" & Left(Me.pg.upage.IsWebServerPrimaryOrSecondary, 1) & " DB:" & Left(Me.pg.upage.IsDatabaseServerPrimaryOrSecondary, 1) & "]" & Chr(13)
        'Show in footer live server & info
        If Me.pg.upage.db.IsOnLiveServer = True Then
            strH = strH & "(Live Server) " & Chr(13)
        End If
        strH = strH & Me.pg.upage.db.GetParameterValue("ServerDescription")
        strH = strH & "      </span>" & Chr(13)
        strH = strH & "    </td>" & Chr(13)
        strH = strH & "    <td align=""right"">" & Chr(13)
        strH = strH & "      <span class=""contact"">" & Chr(13)
        strH = strH & "        " & FormatDateTime(Now(), vbGeneralDate) & Chr(13)
        strH = strH & "      </span>" & Chr(13)
        strH = strH & "    </td>" & Chr(13)
        strH = strH & "  </tr>" & Chr(13)
        strH = strH & "</table>" & Chr(13)

        strH = strH & "<table width=""750"">" & Chr(13)
        strH = strH & "	<tr valign=""top"">" & Chr(13)
        strH = strH & "		<td width=""20"">" & Chr(13)
        strH = strH & "				<Image src='../images/zedralogo.gif'  alt='Zedra Logo'>" & Chr(13)
        strH = strH & "		</td>" & Chr(13)
        strH = strH & "		<td valign=""top"" width=""250"">" & Chr(13)
        strH = strH & "			<div Class=Contact align=left style=' COLOR: blue; FONT-FAMILY: sans-serif; FONT-SIZE: x-small; FONT-STYLE: italic; FONT-WEIGHT: bold'>" & Chr(13)
        strH = strH & "				Designed and built by<BR> <A Href='http://www.zedra.co.uk' target='_blank'>Zedra Solutions</a>" & Chr(13)
        strH = strH & "			</div>" & Chr(13)
        strH = strH & "		</td>" & Chr(13)
        strH = strH & "		<td width=""480"" align=""right"">" & Chr(13)
        strH = strH & "         <table width=""135"" border=""0"" cellpadding=""2"" cellspacing=""0"">"
        strH = strH & "             <tr>"
        strH = strH & "                 <td width=""135"" align=""center"" valign=""top""></td>"
        strH = strH & "             </tr>"
        strH = strH & "         </table>"
        strH = strH & "		</td>" & Chr(13)
        strH = strH & "	</tr>" & Chr(13)
        strH = strH & "</table>" & Chr(13)

            Return strH
    End Function
End Class
