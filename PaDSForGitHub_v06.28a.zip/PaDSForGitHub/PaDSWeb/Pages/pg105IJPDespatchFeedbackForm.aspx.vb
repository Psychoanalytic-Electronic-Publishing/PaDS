﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.UserSession

'Modification History
'08/02/22   Julian Gates   Initial version
'07/04/22   Julian Gates    SIR5464 - Various Email text modifications.
'13/06/22   Julian Gates    SIR5512 - Change language translations to come from database table
Partial Class Pages_pg105IJPDespatchFeedbackForm
    Inherits System.Web.UI.Page
    Dim pageMode As String = ""
    Dim StdCode As New BusinessLogic.StdCode()
    Dim FeedbackEmailNname As String = "IJPPublisherfeedBack"
    Public EmailRecentlySentMessage As String = ""

    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                If Me.IsPostBack Then
                    Me._Subscriber = New BusinessLogic.Subscriber(Me.Master.db, Me.Master.UserSession)
                Else
                    Me._Subscriber = New BusinessLogic.Subscriber(Me.Master.UserSession.Data("SubscriberId"), Me.Master.db, Me.Master.UserSession)
                End If
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property

    Public Property DisplayLanguage As BusinessLogic.UserSession.DisplayLanguages
        Get
            Return Me.Master.UserSession.DisplayLanguage
        End Get
        Set(value As BusinessLogic.UserSession.DisplayLanguages)
            Me.Master.UserSession.DisplayLanguage = value
        End Set
    End Property
    Dim _tSubscriberDespatchInfo As DataTable = Nothing
    ReadOnly Property SubscriberDespatchInfo As DataTable
        Get
            If _tSubscriberDespatchInfo Is Nothing Then
                Dim cmd As New SqlCommand("sp102GetSubscriberDespatchInfo", Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
                cmd.CommandType = CommandType.StoredProcedure

                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                      , Me.Master.UserSession.Data("SubscriberId")))

                _tSubscriberDespatchInfo = Me.Master.db.GetDataTableFromSQL(cmd)
            End If
            Return _tSubscriberDespatchInfo
        End Get
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            'Put user code to initialize the page here
            Master.Initilise("IJP Despatch Feedback Form", "06", "")
            Master.ShowLanguageRBL = True

            If Page.IsPostBack Then
                Me.Subscriber.MainDataset = CType(ViewState("MainDataSet"), DataSet)
            Else
                If Me.Master.WebForm.IsValid Then
                    ReadRecord()
                End If
                'Me.FirstName.Focus()
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(Master.GetTranslatedText(59, 0 _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try
        If Me.Subscriber.RemoteUser Is Nothing And IsPostBack Then
            'it is likely that the subscriber has been merged and user now points at original sub so switch to correct sub based on userid
            Me.Master.UserSession.Data("SubscriberId") = Master.db.DLookup("RightsToId", "RemoteUserRights", "RightsType ='Subscriber' AND UserId=" & Master.UserSession.UserId)
            Me.Master.UserSession.Data("HasOrIsAProposedSubscriber") = False
            Response.Redirect(Request.ServerVariables("Path_Info") & "?" & Me.Master.UserSession.QueryString)
        End If
        GetDespatchInfo()

    End Sub

    Sub PageSetup()
        Me.Master.PageTitle = Master.GetTranslatedText(138, 105 _
                               , "IJP Despatch Feedback Form" _
                               , "Formulario de comentarios de envío de IJP")

        Me.UpdateDespatchAddressTable.Visible = Me.CorrectAddressRDO.SelectedValue = "No"
        If Me.CorrectAddressRDO.SelectedValue = "No" Then
            Me.BuildingStreet.Focus()
            'Postal
            If Me.Master.db.IsDBNull(Me.CountryId.SelectedValue, "") = "11" Or Me.Master.db.IsDBNull(Me.CountryId.SelectedValue, "") = "56" Then 'US or Canada
                Me.PostalStateIsUSCanadaRow.Visible = True
                Me.PostalStateNonUSCanadaRow.Visible = False
            Else
                Me.PostalStateIsUSCanadaRow.Visible = False
                Me.PostalStateNonUSCanadaRow.Visible = True
            End If
        Else
            Me.PhoneNumber.Focus()
        End If

        Me.SaveAddressBtn.Text = Master.GetTranslatedText(139, 105, "Save Address", "Guardar dirección")
        Me.SaveAddressBtn.ToolTip = Master.GetTranslatedText(139, 105, "Save Address", "Guardar dirección")
        If Me.EmailOutputText.Visible And Me.EmailOutputText.Text <> "" And Me.CorrectAddressRDO.SelectedValue = "Yes" Then
            Me.ShowEmailBtn.Text = Master.GetTranslatedText(140, 105, "Refresh Email Text", "Mostrar texto de correo electrónico")
            Me.ShowEmailBtn.ToolTip = Master.GetTranslatedText(140, 105, "Refresh Email Text", "Mostrar texto de correo electrónico")
            Me.ShowEmailBtn.CssClass = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "longButton150", "longButton250")
            Me.SendEmailBtn.Visible = True
        Else
            Me.ShowEmailBtn.Text = Master.GetTranslatedText(141, 105, "Show Email Text", "Mostrar texto de correo electrónico")
            Me.ShowEmailBtn.ToolTip = Master.GetTranslatedText(141, 105, "Show Email Text", "Mostrar texto de correo electrónico")
            Me.ShowEmailBtn.CssClass = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "longButton150", "longButton250")
            Me.SendEmailBtn.Visible = False
        End If
        Me.CancelBtn.Text = Master.GetTranslatedText(62, 0, "Cancel", "Cancelar")
        Me.CancelBtn.ToolTip = Master.GetTranslatedText(62, 0, "Cancel", "Cancelar")

        Me.BackBtn.Text = Master.GetTranslatedText(63, 0, "Back", "Volver")
        Me.BackBtn.ToolTip = Master.GetTranslatedText(63, 0, "Back to home", "Volver")

        Me.SendEmailBtn.Text = Master.GetTranslatedText(142, 105, "Send Email", "Enviar correo electrónico")
        Me.SendEmailBtn.ToolTip = Master.GetTranslatedText(142, 105, "Send Email", "Enviar correo electrónico")

        'Show no parts due message and hide email info controls.
        Dim partsDueFound As Boolean = False
        Dim firstDueDate As String = Nothing
        For Each row As DataRow In SubscriberDespatchInfo.Rows
            If System.DateTime.Now < CDate(Master.db.IsDBNull(row("DateDespatched"), row("ChildReleaseDate"))).AddDays(Master.db.GetParameterValue("DaysIssueDueAfterDespatch", 90)) Then
                partsDueFound = True
            End If
            If firstDueDate = Nothing Then
                firstDueDate = CDate(Master.db.IsDBNull(row("DateDespatched"), row("ChildReleaseDate"))).AddDays(Master.db.GetParameterValue("DaysIssueDueAfterDespatch", 90))
            End If
        Next
        If partsDueFound = False Then
            Me.NoDespatchMainTable.Visible = False
            NoPartsDueMsgRow.Visible = True
            NoPartsDueMsg.Text = Master.GetTranslatedText(143, 105, "There are no issues due, therefore a ""Not Received"" email can't be sent until after " & CDate(firstDueDate).ToString("dd-MMM-yy") _
                                                                       , "No hay partes vencidas, por lo tanto, no se puede enviar un correo electrónico ""No recibido"" hasta después " & CDate(firstDueDate).ToString("dd-MMM-yy"))
            Me.CancelBtn.Visible = False
        Else
            Me.NoDespatchMainTable.Visible = True
            Me.NoPartsDueMsgRow.Visible = False
            Me.CancelBtn.Visible = True
        End If
        NoDespatchMainTable.Visible = EmailRecentlySentMessage = ""
        If Me.CorrectAddressRDO.SelectedValue = "No" Then
            Me.ShowEmailBtn.Visible = False
        Else
            Me.ShowEmailBtn.Visible = True
        End If
    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case "SendEmail"
                Dim checkBoxSelected = False
                Try
                    For i As Integer = Me.DespatchInfoTable.Rows.Count - 1 To 0 Step -1
                        Dim rowtblPage As WebControls.TableRow = Me.DespatchInfoTable.Rows(i)
                        Dim cb As CheckBox = Me.DespatchInfoTable.FindControl(rowtblPage.ID.Replace("ROW", "") & "NotReceived")
                        If cb IsNot Nothing Then
                            If cb.Checked Then
                                checkBoxSelected = True
                            End If
                        End If
                    Next
                Catch ex As Exception

                End Try

                If checkBoxSelected = False And Me.OtherComments.Text = "" Then
                    Me.Master.WebForm.AddPageError(Master.GetTranslatedText(144, 105 _
                                                                                   , "Please select a issue that has not been delivered, if you have a query for the publisher, not related to a journal issue please describe it in ""Other Comments" _
                                                                                   , "Seleccione una issue que no se haya entregado, si tiene una consulta para el editor, no relacionada con una issue de la revista, descríbala en ""Otros comentarios"))
                    Me.Master.WebForm.IsValid = False
                End If
                Master.WebForm.FieldValidateMandatory(CorrectAddressRDO, "Correct Address", "Se debe completar la dirección correcta")
            Case Else
                Me.Master.WebForm.FieldValidateMandatory(Me.BuildingStreet, Master.GetTranslatedText(55, 0, "Building Street", "Dirección"))
                Me.Master.WebForm.FieldValidateMandatory(Me.Town, Master.GetTranslatedText(23, 0, "City", "Ciudad"))
                If Me.Master.db.IsDBNull(Me.CountryId.SelectedValue, "") = "11" Or Me.Master.db.IsDBNull(Me.CountryId.SelectedValue, "") = "56" Then 'US or Canada
                    Me.Master.WebForm.DropDownValidateMandatory(Me.CountyUS, Master.GetTranslatedText(13, 0, "State"))
                End If
                Me.Master.WebForm.FieldValidateMandatory(Me.PostCode, Master.GetTranslatedText(15, 0, "Postal Code", "Es obligación escribir el código de su dirección de envío de correspondencia"))
                If String.IsNullOrEmpty(Me.CountryId.SelectedValue) _
                            Or Me.CountryId.SelectedValue = "0" Then
                    Me.Master.WebForm.AddPageError(Master.GetTranslatedText(72, 0, "Country is mandatory"))
                    Me.CountryId.CssClass = "fldEntryError"
                Else
                    Me.CountryId.CssClass = "DropDownList"
                End If

        End Select
        Return Me.Master.WebForm.IsValid
    End Function
    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.Subscriber.MainDataset
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)
    End Sub
    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        'Read all data from dataset into page fields
        Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.Subscriber.GetAddressRow("Postal"))

        If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("CountryId"), 0) <> 0 Then
            If CInt(Me.Subscriber.GetAddressRow("Postal").Item("CountryId")) = 11 Or CInt(Me.Subscriber.GetAddressRow("Postal").Item("CountryId")) = 56 Then 'US or Canada
                If Me.Subscriber.GetAddressRow("Postal").Item("County").ToString.Length > 2 Then
                    Me.CountyUS.SelectedValue = ""
                Else
                    Me.CountyUS.SelectedValue = Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("County").ToString.ToUpper, "")
                End If
                Me.County.Text = ""
            Else
                Me.County.Text = Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("County"), "")
            End If
        End If
        Me.BuildingStreet.Text = SetMultiLineAddress("Main")

        Me.CurrentDespatchAddress.Text = Me.Subscriber.GetAddressText("Postal", "Main").Replace(",", ", ")
        Me.Master.WebForm.PopulateDropDownListFromLookup(Me.CountyUS, "US_CanadaStateCode", "<--Select-->")

        Dim sql As String = "SELECT Country.CountryId as Value" _
                            & "     ,Country.CountryName As Text" _
                            & " FROM Country" _
                            & " ORDER BY Country.CountryName"

        Me.Master.WebForm.PopulateDropDownListFromSQL(Me.CountryId, sql, "<--Select-->")

        Dim lastFeedBackEmailSentDate As Date = Master.db.DLookup("ISNULL(MAX(EmailSentDate),'01-jan-1900')", "EmailDistributionLog", "EmailName='" & Me.FeedbackEmailNname & "' AND SubscriberId=" & Me.Subscriber.SubscriberId & " AND EmailDistributionStatus='Successfull'")
        If lastFeedBackEmailSentDate > Now.AddDays(-1 * Master.db.GetParameterValue("IJPPubisherFeedbackNextInDays", 42)) Then
            EmailRecentlySentMessage = "You sent a 'Not Received' email on " & lastFeedBackEmailSentDate.ToString("dd-MMM-yyyy") & ", another one can't be sent until " & lastFeedBackEmailSentDate.AddDays(1 + Master.db.GetParameterValue("IJPPubisherFeedbackNextInDays", 42)).ToString("dd-MMM-yyyy")
            Me.EmailRecentlySentMsg.Text = EmailRecentlySentMessage
            Me.EmailRecentlySentMsgRow.Visible = True
        End If

    End Sub
    Sub GetDespatchInfo()
        Try
            If SubscriberDespatchInfo.Rows.Count = 0 Then Exit Sub
            If SubscriberDespatchInfo.Rows.Count > 0 Then
                Dim DaysIssueDueAfterDespatch As Integer = Master.db.GetParameterValue("DaysIssueDueAfterDespatch", 90)
                Dim tRow As New TableRow()
                tRow.ID = "ROW"
                tRow.CssClass = "fldPrompt"
                Dim tCell As New TableCell()
                tCell = New TableCell()
                tCell.Text = Master.GetTranslatedText(150, 105, "Ordered", "Ordenado")
                tRow.Cells.Add(tCell)
                tCell = New TableCell()
                tCell.Text = Master.GetTranslatedText(151, 105, "Journal", "Diario")
                tRow.Cells.Add(tCell)
                tCell = New TableCell()
                tCell.Text = Master.GetTranslatedText(152, 105, "Issue", "Issue")
                tRow.Cells.Add(tCell)
                tCell = New TableCell()
                tCell.Text = Master.GetTranslatedText(153, 105, "Should arrive before", "Fecha de llegada prevista")
                Dim sPopUp As String = Master.GetTranslatedText(154, 105, "<i>Further Info: </i><br>The date, before which, the journal should arrive. This is the planned/actual ship date plus " & DaysIssueDueAfterDespatch & " days.", "<i>Informacion adicional: </i><br>La fecha antes de la cual debe llegar el diario..  Esta es la fecha de envío planificada/real más " & DaysIssueDueAfterDespatch & " días.")
                tCell.Text += Me.Master.WebForm.GetPopupInfo(sPopUp)
                tRow.Cells.Add(tCell)
                tCell = New TableCell()
                tCell.Text = Master.GetTranslatedText(155, 105, "Not Received?", "No recibido")
                tRow.Cells.Add(tCell)
                Me.DespatchInfoTable.Rows.Add(tRow)
                Dim LastLineKey As String = ""
                Dim lastAddress As String = ""
                For Each row As DataRow In SubscriberDespatchInfo.Rows
                    Dim RowKey As String = ""
                    RowKey = row("ChildProductCode") & "#" & row("OrderNumber")
                    tRow = New TableRow()
                    tRow.ID = RowKey & "ROW"
                    tRow.CssClass = "fldView"
                    '*******
                    tCell = New TableCell()
                    If row("ParentProductCode") & row("OrderNumber") <> LastLineKey Then
                        tCell.Text = CDate(row("OrderDate")).ToString("dd-MMM-yy")
                        tRow.Cells.Add(tCell)
                        tCell = New TableCell()
                        tCell.Text = row("ParentProductName")
                    Else
                        tCell.ColumnSpan = 2
                    End If
                    tRow.Cells.Add(tCell)
                    '*******
                    tCell = New TableCell()
                    tCell.Text = row("ChildProductName") & " (" & Master.db.IsDBNull(CDate(row("ChildReleaseDate")).ToString("MMM"), Nothing) & ")"
                    tRow.Cells.Add(tCell)
                    '*******
                    tCell = New TableCell()
                    If Master.db.IsDBNull(row("DateDespatched"), Nothing) = Nothing Then
                        tCell.CssClass = "despatchFooterTextSmall"
                        tCell.Text = Master.GetTranslatedText(156, 105, "Not sent yet", "Aún no enviado")
                    Else
                        tCell.Text = CDate(Master.db.IsDBNull(row("DateDespatched"), row("ChildReleaseDate"))).AddDays(DaysIssueDueAfterDespatch).ToString("dd-MMM-yy")
                        tCell.ToolTip = Master.GetTranslatedText(154, 105, "The date, before which, the journal should arrive. This is the planned/actual ship date plus " & DaysIssueDueAfterDespatch & " days.", "La fecha antes de la cual debe llegar el diario..  Esta es la fecha de envío planificada/real más " & DaysIssueDueAfterDespatch & " días.")
                    End If
                    tCell.HorizontalAlign = HorizontalAlign.Center
                    tRow.Cells.Add(tCell)
                    '*******
                    tCell = New TableCell()
                    tCell.HorizontalAlign = HorizontalAlign.Center
                    If CDate(Master.db.IsDBNull(row("DateDespatched"), row("ChildReleaseDate"))).AddDays(DaysIssueDueAfterDespatch) < System.DateTime.Now Then
                        Dim chk As New WebControls.CheckBox
                        chk.ID = RowKey & "NotReceived"
                        If Not IsPostBack Then
                            chk.Checked = True
                            chk.EnableViewState = True
                            chk.Checked = False
                        End If
                        chk.Visible = EmailRecentlySentMessage = ""
                        tCell.Controls.Add(chk)
                    Else
                        tCell.Text = ""
                    End If
                    tRow.Cells.Add(tCell)
                    Me.DespatchInfoTable.Rows.Add(tRow)

                    'If Not Master.db.IsDBNull(row("AddressText")) AndAlso row("AddressText") <> lastAddress Then
                    '    tRow = New TableRow()
                    '    tCell = New TableCell()
                    '    tCell.ColumnSpan = 2
                    '    tRow.Cells.Add(tCell)
                    '    tCell = New TableCell()
                    '    tCell.ColumnSpan = 5
                    '    tCell.Text = "<span class=""fldPrompt"">&nbsp;&nbsp;" & Master.GetTranslatedText(157, 105, "Address", "Habla a") & ": </span><span class=""despatchAddressTextSmall"">" & address & "</span>"
                    '    tRow.Cells.Add(tCell)
                    '    Me.DespatchInfoTable.Rows.Add(tRow)
                    'End If

                    '  Me.DespatchInfoTable.Rows.Add(tRow)

                    LastLineKey = row("ParentProductCode") & row("OrderNumber")
                    'lastAddress = address
                Next

            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(Master.GetTranslatedText(59, 0 _
                          , "An Unexpected error has occured.  Please contact support." _
                          , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia."), ex))
        End Try
    End Sub

    Protected Sub ShowEmailBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ShowEmailBtn.Click
        If Me.IsPageValidForStatus("SendEmail") Then
            Me.EmailOutputText.Text = CreateEmailText()
            Me.EmailOutputText.Visible = True
        End If
    End Sub

    Protected Sub BackBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        Response.Redirect("../pages/pg101Home.aspx?" & Me.Master.UserSession.QueryString)
    End Sub

    Protected Sub CancelBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?" & Me.Master.UserSession.QueryString)
    End Sub
    Protected Sub SendEmailBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SendEmailBtn.Click
        Try
            If Me.IsPageValidForStatus("SendEmail") Then
                Dim email As New BusinessLogic.Email(Master.db)
                If Master.UserSession.Data("SpoofingUserId") IsNot Nothing Then
                    email.SendTo = Master.db.DLookup("EmailAddress", "RemoteUser", "UserId=" & Master.UserSession.Data("SpoofingUserId"))
                Else
                    email.SendTo = Master.db.GetParameterValue("IJPPubisherFeedbackEmail", "support@zedra.co.uk")
                    email.CC = Me.Subscriber.GetAddressText("Email", "Main")
                End If
                email.Subject = "IJP Journal issue not received by " & Me.Subscriber.SubscriberRow("SubscriberName")
                email.Body = CreateEmailText()
                email.Send()
                Dim emailing As New BusinessLogic.EmailDistribution(Master.db)
                emailing.AddToSubscriberEmailToDitributionLog(EmailName:="IJPPublisherfeedBack",
                                                                    EmailSubject:=email.Subject,
                                                                    EmailBody:=email.Body,
                                                                    SendToEmailAddress:=email.SendTo,
                                                                    SubscriberId:=Me.Subscriber.SubscriberId,
                                                                    CompanyId:=1,
                                                                    EmailDistributionStatus:="Successfull")
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(Master.GetTranslatedText(59, 0 _
                                                            , "An Unexpected error has occured.  Please contact support" _
                                                            , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try

        If Me.Master.WebForm.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=" & Master.GetTranslatedText(158, 105 _
                                                                               , "IJP Non Despatch Email Sent" _
                                                                               , "Correo electrónico no enviado de IJP enviado") & "&" & Me.Master.UserSession.QueryString)
        End If
    End Sub

    Protected Sub SaveAddressBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveAddressBtn.Click
        If Me.IsPageValidForStatus("") Then
            SaveEmailAddressRecord()
            Me.CorrectAddressRDO.SelectedValue = "Yes"
        End If
    End Sub
    Sub SaveEmailAddressRecord()
        Dim areAddressesTheSame As Boolean = False
        Try
            Me.Subscriber = New BusinessLogic.Subscriber(Me.Master.UserSession.Data("SubscriberId"), Master.db, Master.UserSession)
            Master.db.BeginTran()
            Try
                'Check to see if Postal Main and Billing are the same before updating
                If Me.Subscriber.GetAddressText("Postal", "Main") = Me.Subscriber.GetAddressText("Postal", "Billing") Then
                    areAddressesTheSame = True
                End If

                If Me.CountryId.SelectedValue <> "" AndAlso (Me.CountryId.SelectedValue = 11 Or Me.CountryId.SelectedValue = 56) Then 'US or Canada
                    Me.County.Text = Me.CountyUS.SelectedValue
                End If
                If Me.BuildingStreet.Text <> "" And Me.Town.Text <> "" Then Me.Subscriber.SavePostalSubscriberAddress("Main", Me.BuildingStreet.Text.TrimEnd, Me.Town.Text, Me.County.Text, Me.PostCode.Text, Me.CountryId.SelectedValue, True)

                If areAddressesTheSame Then
                    'Update Billing Address if both the same.
                    Me.Subscriber.SavePostalSubscriberAddress("Billing", Me.BuildingStreet.Text.TrimEnd, Me.Town.Text, Me.County.Text, Me.PostCode.Text, Me.CountryId.SelectedValue)
                End If

                Master.db.CommitTran()

            Catch ex As Exception
                Master.db.RollbackTran()
                Throw ex
            End Try

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(Master.GetTranslatedText(59, 0 _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try
        If Me.Master.WebForm.IsValid Then
            ReadRecord()
        End If
    End Sub

    Private Function SetMultiLineAddress(ByVal AddressDescription As String) As String
        Dim postalAddress As String = ""

        postalAddress += Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address1") & System.Environment.NewLine

        If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address2"), "") <> "" Then
            postalAddress += Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address2") & System.Environment.NewLine
        End If
        If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address3"), "") <> "" Then
            postalAddress += Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address3") & System.Environment.NewLine
        End If
        If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address4"), "") <> "" Then
            postalAddress += Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address4")
        End If

        Return postalAddress

    End Function
    Function CreateEmailText() As String
        Dim sText As String = Nothing
        Dim notReceivedTemplate As String = Nothing
        Try
            notReceivedTemplate = Me.Master.db.GetParameterValue("ReportTemplateDirectory") & "\PublisherNotReceivedEmail.htm"
            'see if template is available for product
            If System.IO.File.Exists(notReceivedTemplate) Then
                sText = New BusinessLogic.StdCode().GetFileText(notReceivedTemplate)
            Else
                'use default template if product one not found
                sText = New BusinessLogic.StdCode().GetFileText(Me.Master.db.GetParameterValue("ReportTemplateDirectory") & "\PublisherNotReceivedEmail.htm")
            End If

            sText = sText.Replace("[FirstName]", Me.Subscriber.SubscriberRow("FirstName"))
            sText = sText.Replace("[LastName]", Me.Subscriber.SubscriberRow("LastName"))
            sText = sText.Replace("[DespatchAddress]", Me.Subscriber.GetAddressText("Postal", "Main").Replace(",", ", "))
            Dim addText As String = Nothing
            If Me.PhoneNumber.Text <> "" Then
                addText += "<p>In case a courier is needed my telephone number and email address are:</p>"
                addText += "<p><strong>Phone:</strong> " & Me.PhoneNumber.Text & "</p>"
            Else
                addText += "<p>In case a courier is needed my email address is:</p>"
            End If
            If Master.UserSession.Data("SpoofingUserId") IsNot Nothing Then
                addText += "<p><strong>Email (For Spoof Send):</strong> " & Master.db.DLookup("EmailAddress", "RemoteUser", "UserId=" & Master.UserSession.Data("SpoofingUserId")) & "</p>"
            Else
                addText += "<p><strong>Email:</strong> " & Me.Subscriber.GetAddressText("Email", "Main") & "</p>"
            End If

            If Me.DeliveryInstructions.Text <> "" Then
                addText += "<p><strong>Delivery Instructions:</strong></p><p>" & Me.DeliveryInstructions.Text.Replace(vbLf, "<br>") & "</p>"
            End If
            If Me.OtherComments.Text <> "" Then
                addText += "<p><strong>Other Comments:</strong></p><p>" & Me.OtherComments.Text.Replace(vbLf, "<br>") & "</p>"
            End If
            sText = sText.Replace("[AdditionalFields]", addText)

            Dim partsDueSelected As String = Nothing
            Try
                For i As Integer = Me.DespatchInfoTable.Rows.Count - 1 To 0 Step -1
                    Dim rowtblPage As WebControls.TableRow = Me.DespatchInfoTable.Rows(i)
                    Dim cb As CheckBox = Me.DespatchInfoTable.FindControl(rowtblPage.ID.Replace("ROW", "") & "NotReceived")
                    If cb IsNot Nothing Then
                        If cb.Checked Then
                            Dim ProdCode As String = cb.ID.Substring(0, cb.ID.IndexOf("#")).Trim()
                            Dim vw As New DataView(Me.SubscriberDespatchInfo, "ChildProductCode='" & ProdCode & "'", "", DataViewRowState.CurrentRows)
                            partsDueSelected += vw(0)("ChildProductName") & "<br>"
                        End If
                    End If
                Next
            Catch ex As Exception

            End Try

            If partsDueSelected <> Nothing Then
                sText = sText.Replace("[List]", partsDueSelected)
            Else
                sText = sText.Replace("[List]", "No missing issues")
            End If

            Return sText
            Catch ex As Exception
                Return ""
            Me.Master.WebForm.AddPageError(New Exception(Master.GetTranslatedText(59, 0 _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try
    End Function

End Class
