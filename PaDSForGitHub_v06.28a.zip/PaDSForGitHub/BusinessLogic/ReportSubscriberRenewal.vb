﻿'Modification History
'Oct 2019       James Woosnam   SIR4945 - Initial Version
'25/11/19   James Woosnam   SIR4959 - Add optional Notes field
'13/1/22    james Woosnam   SIR5388 - Remove EmailOpt Out column

Public Class ReportSubscriberRenewal
    Inherits ReportSSG
#Region "Class Properties"
    Dim BatchJobId As Integer = Nothing
    Dim BlockSubscriberId As Integer
    Dim CompanyId As Integer
    Enum RenenalReportTypes
        Recurring
        NonRecurring
    End Enum
    Dim RenenalReportType As RenenalReportTypes = Nothing
#End Region

    Public Sub New(ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("SubscriberRenewal", "Excel", db, SubmittedByUserSessionId)
    End Sub
    Public Sub New(BlockSubscriberId As Integer, CompanyId As Integer, ReportSQL As String, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("SubscriberRenewal", "Excel", db, SubmittedByUserSessionId)
        Me.BlockSubscriberId = BlockSubscriberId
        Me.ReportSQL = ReportSQL
        Me.CompanyId = CompanyId
    End Sub
    Public Sub New(CompanyId As Integer, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("SubscriberRenewal", "Excel", db, SubmittedByUserSessionId)
        Me.CompanyId = CompanyId
    End Sub
    Public Overloads Sub Submit(CreateSubscriberImportBatches As Boolean)

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSessionId
        BatchJob.Parameters.Add("ReportName", Me.ReportName)
        BatchJob.Parameters.Add("RenenalReportType", RenenalReportTypes.Recurring)
        BatchJob.Parameters.Add("ReportSQL", Me.ReportSQL)
        BatchJob.Parameters.Add("BlockSubscriberId", Me.BlockSubscriberId)
        BatchJob.Parameters.Add("CreateSubscriberImportBatches", CreateSubscriberImportBatches)
        BatchJob.Parameters.Add("CompanyId", Me.CompanyId)

        BatchJob.CreateBatchJobEntry("RunReportSpreadsheetGearExcel", Me.db)

    End Sub

    Public Overloads Sub Execute(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.JobParameters = Parameters
        Select Case CType(Parameters.GetValue("RenenalReportType"), RenenalReportTypes)
            Case RenenalReportTypes.Recurring
                Me.ReportSQL = Parameters.GetValue("ReportSQL")
                Me.BlockSubscriberId = Parameters.GetValue("BlockSubscriberId")
                Me.CompanyId = Parameters.GetValue("CompanyId")
                Me.Execute(Parameters.GetValue("CreateSubscriberImportBatches"))
            Case RenenalReportTypes.NonRecurring
                Me.CompanyId = Parameters.GetValue("CompanyId")
                Me.ExecuteNonRecurring(Parameters.GetValue("SubscribedToProductCodes"), Parameters.GetValue("SpreadsheetsForSubscriberIds"), Parameters.GetValue("CreateSubscriberImportBatches"))
            Case Else
                Throw New Exception("RenenalReportType not handled")
        End Select

    End Sub

    Public Overloads Sub Execute(CreateSubscriberImportBatches As Boolean, Optional ByVal InBatchLog As BatchLog = Nothing)
        Dim blockSubscriberName As String = db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & Me.BlockSubscriberId)

        Dim batchLogCreatedHere As Boolean = False
        If InBatchLog Is Nothing Then
            Me.BatchLog = New BatchLog("Report-" & Me.ReportName _
                                          , ";BlockSubscriberId=" & Me.BlockSubscriberId _
                                          & ";BlockName=" & blockSubscriberName _
                                         , Me.db _
                                         , BatchJobId _
                                         , Me.SubmittedByUserSessionId)
            batchLogCreatedHere = True
        Else
            Me.BatchLog = InBatchLog
        End If
        Try
            MyBase.Execute(Me.BatchLog)
            Dim tblRep As DataTable = db.GetDataTableFromSQL(Me.ReportSQL)

            Me.ExcelWorkBook = SpreadsheetGear.Factory.GetWorkbook(Me.ExcelTemplate.FullName)
            Dim wsData As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Data")


            Dim rgBase As SpreadsheetGear.IRange
            rgBase = wsData.Cells("DataRows")
            rgBase.CopyFromDataTable(tblRep, SpreadsheetGear.Data.SetDataFlags.InsertCells + SpreadsheetGear.Data.SetDataFlags.None) '+ SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders)

            If Me.BlockSubscriberId <> Nothing And CreateSubscriberImportBatches Then
                Try
                    ReportName += " " & blockSubscriberName
                    'FileStore.AddNewFile(Me.ReportByteArray, Me.ReportName & ".xlsx", ReportType)
                    Dim srb As New SubscriberImportBatch(db, Me.SubmittedByUserSession)
                    '2/3/20     James Woosnam   SIR5030 - Make import batch name unique
                    srb.AddNew(BlockSubscriberId, CompanyId, srb.GetSubscriberImportBatchNameForAdd(Me.CompanyId,
                                                                                                    Me.BlockSubscriberId,
                                                                                                    Left(db.DLookup("CompanyShortName", "Company", "CompanyId=" & Me.CompanyId).ToString, 40) & " Renewal " & Now.ToString("yyyy")))
                    'srb.SubscriberImportBatchRow("RenewalFileStoreId") = FileStore.FileStoreId
                    srb.UpdateStatus(SubscriberImportBatch.SubscriberImportBatchStates.Available, Me.ReportByteArray, Me.ReportName)
                    BatchLog.Update("Import Batch:" & srb.SubscriberImportBatchId & " created")
                Catch ex As Exception
                    Throw New Exception("Add import batch Failed:" & ex.ToString)
                End Try


            End If
            ExcelWorkBook.SaveAs(Me.ReportFile.FullName, SpreadsheetGear.FileFormat.OpenXMLWorkbook)

            BatchLog.Update(Me.FileLink)

            If batchLogCreatedHere Then
                BatchLog.Update("Process Complete", "Complete")
            End If
        Catch ex As Exception
            BatchLog.Update("Report Failed:" & ex.Message, "Failed")
            Throw New Exception("Report Failed:" & ex.Message, ex)

        End Try

    End Sub
    Public Overloads Sub SubmitNonRecurring(SubscribedToProductCodes As String, SpreadsheetsForSubscriberIds As String, CreateSubscriberImportBatches As Boolean)

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSessionId
        BatchJob.Parameters.Add("ReportName", Me.ReportName)
        BatchJob.Parameters.Add("RenenalReportType", RenenalReportTypes.NonRecurring)
        BatchJob.Parameters.Add("SubscribedToProductCodes", SubscribedToProductCodes)
        BatchJob.Parameters.Add("SpreadsheetsForSubscriberIds", SpreadsheetsForSubscriberIds)
        BatchJob.Parameters.Add("CreateSubscriberImportBatches", CreateSubscriberImportBatches)
        BatchJob.Parameters.Add("CompanyId", Me.CompanyId)

        BatchJob.CreateBatchJobEntry("RunReportSpreadsheetGearExcel", Me.db)

    End Sub
    Public Overloads Sub ExecuteNonRecurring(SubscribedToProductCodes As String, SpreadsheetsForSubscriberIds As String, CreateSubscriberImportBatches As Boolean, Optional ByVal InBatchLog As BatchLog = Nothing)

        Dim batchLogCreatedHere As Boolean = False
        If InBatchLog Is Nothing Then
            Me.BatchLog = New BatchLog("Report-" & Me.ReportName _
                                          , ";SubscribedToProductCodes=" & SubscribedToProductCodes _
                                          & ";SpreadsheetsForSubscriberIds=" & SpreadsheetsForSubscriberIds _
                                          & ";CreateSubscriberImportBatches=" & CreateSubscriberImportBatches.ToString _
                                         , Me.db _
                                         , BatchJobId _
                                         , Me.SubmittedByUserSessionId)
            batchLogCreatedHere = True
        Else
            Me.BatchLog = InBatchLog
        End If
        Try
            MyBase.Execute(Me.BatchLog)
            Dim sql As String
            sql = "
SELECT DISTINCT
	so.OrderNumber
	,sol.SubscriberId
	,so.OrderType
	,SubAff.AffiliateReferenceID 
	,OrderedBySubscriberId = OrderedBySubscriber.SubscriberId
	,OrderedBySubscriberName = OrderedBySubscriber.SubscriberName 
FROM SalesorderLine sol
	INNER JOIN Salesorder so
		INNER JOIN Subscriber OrderedBySubscriber 
		On OrderedBySubscriber.SubscriberId = so.SubscriberId
	On so.OrderNumber = sol.OrderNumber
	AND so.SalesorderStatus IN ('Confirmed','Complete')
	INNER JOIN Product ParentProduct 
	On ParentProduct.ProductCode = sol.ProductCode
	AND ParentProduct.ProductCode IN (" & SubscribedToProductCodes & ")
	INNER JOIN SubscriberAffiliate SubAff
	ON SubAff.ParentSubscriberId = so.SubscriberId
	AND SubAff.ChildSubscriberId = sol.SubscriberId
WHERE ISNULL(sol.IsCancel,0) <> 1
AND so.SubscriberId IN (" & SpreadsheetsForSubscriberIds & ")
ORDER BY
	 OrderedBySubscriber.SubscriberName 
	,sol.SubscriberId
"
            Dim tbl As DataTable = db.GetDataTableFromSQL(sql)
            If tbl.Rows.Count = 0 Then
                Throw New Exception("There are no rows to output")
            End If
            Dim OrderedBySubscriberName As String = ""
            For Each row As DataRow In tbl.Rows
                If OrderedBySubscriberName <> row("OrderedBySubscriberName") Then
                    Dim subIds As String = ""
                    For Each r2 As DataRow In tbl.Rows
                        If r2("OrderedBySubscriberName") = row("OrderedBySubscriberName") Then
                            subIds += IIf(subIds = "", "", ",") & r2("SubscriberId")
                        End If
                    Next
                    '25/11/19   James Woosnam   SIR4959 - Add optional Notes field
                    '12/12/19   James Woosnam   SIR4978 - Re-add blank webusername and password fields
                    '13/1/22    james Woosnam   SIR5388 - Remove EmailOpt Out column
                    sql = "
                        SELECT DISTINCT
                            AffiliateReferenceID = ISNULL(SubAff.AffiliateReferenceID,Subscriber.SubscriberId)
                            ,SubscriberAffiliate.SubscriberCategory
                            ,ParentSubscriberName='" & row("OrderedBySubscriberName").ToString.Replace("'", "''") & "'
                            ,Subscriber.FirstName
                            ,Subscriber.LastName
                            ,SubscriberAddress.Address1
                            ,SubscriberAddress.Address2
                            ,SubscriberAddress.Address3
                            ,SubscriberAddress.Address4
                            ,City = SubscriberAddress.Town
                            ,State = SubscriberAddress.County
                            ,SubscriberAddress.PostCode
                            ,Country.CountryName
                            ,EmailAddress = Email.AddressText
                            ,PrintedCopy = 'Y'
                            ,WebUserName = ''
                            ,WebUserPassword = ''
                            ,Notes = ''
                         FROM  Subscriber Subscriber 
	                        INNER JOIN SubscriberAffiliate
			                        INNER JOIN Company
			                        On Company.CompanyId = " & Me.CompanyId & "
			                        AND Company.GroupParentSubscriberId = SubscriberAffiliate.ParentSubscriberId
	                        ON SubscriberAffiliate.ChildSubscriberId = Subscriber.SubscriberId
	                        AND GetDate() BETWEEN SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate
	                        Left JOIN SubscriberAddress
 		                        LEFT JOIN Country
 		                        ON Country.CountryId = SubscriberAddress.CountryId
 	                        ON SubscriberAddress.SubscriberAddressId = (SELECT top 1 sa.SubscriberAddressId
 											                        FROM SubscriberAddress sa
                                                                   WHERE(sa.SubscriberId = Subscriber.SubscriberId)
											                        AND sa.AddressType = 'Postal'
 											                        AND sa.AddressDescription <> 'Redundant'
 											                        Order BY CASE WHEN  sa.AddressDescription = Company.DefaultAddressDescription THEN 0 ELSE 1 End
 											                            ,sa.LastUpdatedDateTime 
 											                        )
 	                        Left JOIN SubscriberAddress Email
 	                        ON Email.SubscriberId = Subscriber.SubscriberID
 	                        AND Email.AddressType = 'Email'
 	                        AND Email.AddressDescription = 'Main'
	                        LEFT JOIN SubscriberAffiliate SubAff
	                        ON SubAff.ParentSubscriberId   IN (" & row("OrderedBySubscriberId") & ")
	                        AND SubAff.ChildSubscriberId = subscriber.SubscriberId
	                        AND GetDate() BETWEEN SubAff.StartDate AND SubAff.EndDate

                         WHERE Subscriber.SubscriberStatus='Current'
                         AND Subscriber.SubscriberId in (" & subIds & ")
                         ORDER BY  Subscriber.LastName 
		                        ,Subscriber.FirstName  
  
                        "
                    Dim outtbl As DataTable = db.GetDataTableFromSQL(sql)
                    Me.ExcelWorkBook = SpreadsheetGear.Factory.GetWorkbook(Me.ExcelTemplate.FullName)
                    Dim wsData As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Data")

                    Dim rgBase As SpreadsheetGear.IRange
                    rgBase = wsData.Cells("DataRows")
                    rgBase.CopyFromDataTable(outtbl, SpreadsheetGear.Data.SetDataFlags.InsertCells + SpreadsheetGear.Data.SetDataFlags.None) '+ SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders)
                    Dim fi As New IO.FileInfo(IO.Path.Combine(Me.RandomOutputDirectory.FullName, row("OrderedBySubscriberName") & " RenewalFile.xlsx"))
                    If CreateSubscriberImportBatches Then
                        'FileStore.AddNewFile(Me.ReportByteArray, Me.ReportName & ".xlsx", ReportType)
                        Dim srb As New SubscriberImportBatch(db, Me.SubmittedByUserSession)
                        '2/3/20     James Woosnam   SIR5030 - Make import batch name unique
                        srb.AddNew(row("OrderedBySubscriberId"), CompanyId, srb.GetSubscriberImportBatchNameForAdd(Me.CompanyId,
                                                                                                    Me.BlockSubscriberId,
                                                                                                    Left(db.DLookup("CompanyShortName", "Company", "CompanyId=" & Me.CompanyId).ToString, 40) & " Renewal " & Now.ToString("yyyy")))
                        Dim memoryStream As New System.IO.MemoryStream()
                        Me.ExcelWorkBook.SaveToStream(memoryStream, SpreadsheetGear.FileFormat.OpenXMLWorkbook)
                        srb.UpdateStatus(SubscriberImportBatch.SubscriberImportBatchStates.Available, memoryStream.ToArray, fi.Name)
                    End If
                    ExcelWorkBook.SaveAs(fi.FullName, SpreadsheetGear.FileFormat.OpenXMLWorkbook)

                    BatchLog.Update(Me.GetFileLink(fi.Name.Replace(".xlsx", "")))

                End If

                OrderedBySubscriberName = row("OrderedBySubscriberName")
            Next


            If batchLogCreatedHere Then BatchLog.Update("Process Complete", "Complete")
        Catch ex As Exception
            If batchLogCreatedHere Then BatchLog.Update("Report Failed:" & ex.Message, "Failed")
            Throw New Exception("Report Failed:" & ex.Message, ex)

        End Try

    End Sub

End Class
