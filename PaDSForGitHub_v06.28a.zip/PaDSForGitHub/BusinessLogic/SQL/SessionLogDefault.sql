/*
If required creates a default value on the tables
This is needed as replication overwrites this on secondary server

*/
IF NOT EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'DF_Product_IsForReporting')
	ALTER TABLE dbo.Product ADD CONSTRAINT
		DF_Product_IsForReporting DEFAULT 0 FOR IsForReporting
	
IF NOT EXISTS(SELECT * FROM SYSOBJECTS WHERE name = 'DF_Product_IsCarriageCharge')
	ALTER TABLE dbo.Product ADD CONSTRAINT
		DF_Product_IsCarriageCharge DEFAULT 0 FOR IsCarriageCharge

--Create index on Session log (if neccessary) as it seems to get overwritten by renewing replication
IF NOT ExiSTS(select * from [PaDS_Try_Logs]..sysindexes where name = 'IX_SessionLog_Date')
	CREATE NONCLUSTERED INDEX [IX_SessionLog_Date] ON [PaDS_Try_Logs].[dbo].[SessionLog] 
	(
		[Date] DESC
	)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]

