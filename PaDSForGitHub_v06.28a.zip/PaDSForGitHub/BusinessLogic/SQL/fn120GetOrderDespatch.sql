if exists (select * from dbo.sysobjects where id = object_id(N'fn120GetOrderDespatch') and xtype in (N'FN', N'IF', N'TF'))
drop function fn120GetOrderDespatch
GO
CREATE FUNCTION fn120GetOrderDespatch( @SubscriberId INT, @OrderNumber INT,@ParentProductCode VARCHAR(10))
RETURNS Varchar(max)
AS
BEGIN
--Aug 2021	James Woosnam	Display Despatch details
--2/12/21	James Woosnam	SIR5359 - Add address to despatch display, but only when it changes
DECLARE @Out VARCHAR(max) = ''

DECLARE @DespatchText VARCHAR(50)
DECLARE @AddressText VARCHAR(50) =''
DECLARE @LastAddressText VARCHAR(50) = ''
DECLARE @ShippedProductFlag BIT

DECLARE cur CURSOR FOR 
SELECT DespatchText = solp.ProductCode + '-->' + FORMAT( solp.DateDespatched,'dd-MMM-yy')
	,solp.AddressText
FROM SalesOrderLinePart solp
	INNER JOIN Product pC
	ON pC.ProductCode = solp.ProductCode 
	INNER JOIN SalesOrderLine sol
	ON sol.SalesOrderLineID = solp.SalesOrderLineID 
	INNER JOIN Product pP
	ON pP.ProductCode = sol.ProductCode
WHERE solp.OrderNumber = @OrderNumber 
AND sol.SubscriberId = @SubscriberId 
AND sol.ProductCode = @ParentProductCode
AND pP.ProductCode = pC.ParentProductCode 
ORDER BY solp.DateDespatched
Open cur 
FETCH cur 
INTO @DespatchText,@AddressText
WHILE @@FETCH_STATUS = 0 
BEGIN
--2/12/21	James Woosnam	SIR5359 - Add address to despatch display, but only when it changes
	SET @Out += CASE WHEN @Out='' THEN ''ELSE '<br/>' END 
		+ @DespatchText 
		+ CASE WHEN @LastAddressText<>@AddressText THEN '<br>&nbsp;&nbsp;&nbsp;&nbsp;Despatched:' + @AddressText ELSE '' END
	SET @LastAddressText = @AddressText
	FETCH cur 
	INTO @DespatchText,@AddressText
END
CLOSE cur 
DEALLOCATE cur 
SET @Out = ISNULL(@Out ,'')
SELECT @Out = 
			CASE WHEN pp.ShippedProductFlag<>1 THEN '' ELSE
			@Out
			+
			CASE WHEN so.SalesOrderStatus <> 'Complete' THEN	--Once complete hide next address
				CASE WHEN @Out<>'' THEN '<br>' ELSE '' END + 'Next Despatch:' + sa.AddressText
				ELSE '' END
			END
FROM SalesOrderLine sol
	INNER JOIN SalesOrder so
	ON so.OrderNumber = sol.OrderNumber
	INNER JOIN SubscriberAddress sa
	ON sa.SubscriberAddressId = sol.DeliveryAddressId
	INNER JOIN Product pP
	ON pP.ProductCode = sol.ProductCode
WHERE sol.OrderNumber = @OrderNumber 
AND sol.SubscriberId = @SubscriberId 
AND sol.ProductCode = @ParentProductCode

RETURN ( @Out)

END

GO
GRANT  EXECUTE ON fn120GetOrderDespatch TO PaDSSQLServerUser

 