begin tran
create table #authStatus(autthorName nvarchar(200),Status BIT)
INSERT INTO #authStatus SELECT 'Šebek, M.',0
INSERT INTO #authStatus SELECT 'Švrakić, D.M.',0
INSERT INTO #authStatus SELECT 'Åredal, &.',0
INSERT INTO #authStatus SELECT 'Émond, M.',0
INSERT INTO #authStatus SELECT 'Žižek, S.',0
INSERT INTO #authStatus SELECT 'Adler, E.',0
INSERT INTO #authStatus SELECT 'Anzieu, D.',0
INSERT INTO #authStatus SELECT 'Arlow, J.A.',0
INSERT INTO #authStatus SELECT 'Basch, M.F.',0
INSERT INTO #authStatus SELECT 'Bemporad, J.',0
INSERT INTO #authStatus SELECT 'Bemporad, J.R.',0
INSERT INTO #authStatus SELECT 'Bick, E.',0
INSERT INTO #authStatus SELECT 'Bick, I.',0
INSERT INTO #authStatus SELECT 'Bick, L.J.',0
INSERT INTO #authStatus SELECT 'Bion, W.R.',0
INSERT INTO #authStatus SELECT 'Bleger, J.',0
INSERT INTO #authStatus SELECT 'Bowlby, J.',0
INSERT INTO #authStatus SELECT 'Brenner, C.',0
INSERT INTO #authStatus SELECT 'Bruehl, E.Y.',0
INSERT INTO #authStatus SELECT 'Carpy, D.V.',0
INSERT INTO #authStatus SELECT 'Chasseguet - Smirgel, J.',0
INSERT INTO #authStatus SELECT 'Chasseguet-Smirgel, J.',0
INSERT INTO #authStatus SELECT 'Cohen, D.J.',0
INSERT INTO #authStatus SELECT 'Coltart, N.',0
INSERT INTO #authStatus SELECT 'Coltart, N.E.',0
INSERT INTO #authStatus SELECT 'Cooper, A.M.',0
INSERT INTO #authStatus SELECT 'Edgcumbe, R.',0
INSERT INTO #authStatus SELECT 'Erikson, E.H.',0
INSERT INTO #authStatus SELECT 'Fairbairn, W.D.',0
INSERT INTO #authStatus SELECT 'Fairbairn, W.R.',0
INSERT INTO #authStatus SELECT 'Ferenczi, S.',0
INSERT INTO #authStatus SELECT 'Fiscalini, J.',0
INSERT INTO #authStatus SELECT 'Fiscalini, J.A.',0
INSERT INTO #authStatus SELECT 'Fountain, G.',0
INSERT INTO #authStatus SELECT 'Fraiberg, S.',0
INSERT INTO #authStatus SELECT 'Freud, A.',0
INSERT INTO #authStatus SELECT 'Freud, S.',0
INSERT INTO #authStatus SELECT 'Furman, E.',0
INSERT INTO #authStatus SELECT 'Ghent, E.',0
INSERT INTO #authStatus SELECT 'Gill, M.M.',0
INSERT INTO #authStatus SELECT 'Glasser, M.',0
INSERT INTO #authStatus SELECT 'Glenn, J.',0
INSERT INTO #authStatus SELECT 'Godley, W.',0
INSERT INTO #authStatus SELECT 'Gray, P.',0
INSERT INTO #authStatus SELECT 'Green, A.',0
INSERT INTO #authStatus SELECT 'Greenson, R.R.',0
INSERT INTO #authStatus SELECT 'Grossman, W.I.',0
INSERT INTO #authStatus SELECT 'Guntrip, H.',0
INSERT INTO #authStatus SELECT 'Hauser, S.T.',0
INSERT INTO #authStatus SELECT 'Heimann, P.',0
INSERT INTO #authStatus SELECT 'Isaacs, S.',0
INSERT INTO #authStatus SELECT 'Jacobson, E.',0
INSERT INTO #authStatus SELECT 'Jaques, E.',0
INSERT INTO #authStatus SELECT 'Jones, E.E.',0
INSERT INTO #authStatus SELECT 'Kennedy, H.',0
INSERT INTO #authStatus SELECT 'Khan, M.R.',0
INSERT INTO #authStatus SELECT 'Klein, M.',0
INSERT INTO #authStatus SELECT 'Kohut, H.',0
INSERT INTO #authStatus SELECT 'Kris, E.',0
INSERT INTO #authStatus SELECT 'Lacan, J.',0
INSERT INTO #authStatus SELECT 'Lidz, T.',0
INSERT INTO #authStatus SELECT 'Loewald, H.W.',0
INSERT INTO #authStatus SELECT 'Mahler, M.S.',0
INSERT INTO #authStatus SELECT 'Mancia, M.',0
INSERT INTO #authStatus SELECT 'Masterson, J.F.',0
INSERT INTO #authStatus SELECT 'Mayer, E.L.',0
INSERT INTO #authStatus SELECT 'McDougall, J.',0
INSERT INTO #authStatus SELECT 'McLaughlin, J.T.',0
INSERT INTO #authStatus SELECT 'Mead, M.',0
INSERT INTO #authStatus SELECT 'Meadow, P.W.',0
INSERT INTO #authStatus SELECT 'Meissner, S.J.',0
INSERT INTO #authStatus SELECT 'Meissner, W.',0
INSERT INTO #authStatus SELECT 'Meissner, W.W.',0
INSERT INTO #authStatus SELECT 'Meissnkr, W.W.',0
INSERT INTO #authStatus SELECT 'Mitchell, S.A.',0
INSERT INTO #authStatus SELECT 'Money-Kyrle, R.E.',0
INSERT INTO #authStatus SELECT 'Morrison, A.P.',0
INSERT INTO #authStatus SELECT 'Ostow, M.',0
INSERT INTO #authStatus SELECT 'Racker, H.',0
INSERT INTO #authStatus SELECT 'Rangell, L.',0
INSERT INTO #authStatus SELECT 'Riviere, J.',0
INSERT INTO #authStatus SELECT 'Roazen, P.',0
INSERT INTO #authStatus SELECT 'Rosenfeld, H.',0
INSERT INTO #authStatus SELECT 'Rosenthal, L.',0
INSERT INTO #authStatus SELECT 'Russell, P.L.',0
INSERT INTO #authStatus SELECT 'Rycroft, C.',0
INSERT INTO #authStatus SELECT 'Rycroft, C.F.',0
INSERT INTO #authStatus SELECT 'Sandler, J.',0
INSERT INTO #authStatus SELECT 'Schafer, R.',0
INSERT INTO #authStatus SELECT 'Searles, H.F.',0
INSERT INTO #authStatus SELECT 'Segal, H.',0
INSERT INTO #authStatus SELECT 'Spielrein, S.',0
INSERT INTO #authStatus SELECT 'Stein, R.',0
INSERT INTO #authStatus SELECT 'Stern, D.N.',0
INSERT INTO #authStatus SELECT 'Strachey, J.',0
INSERT INTO #authStatus SELECT 'Tolpin, M.',0
INSERT INTO #authStatus SELECT 'Winnicott, C.',0
INSERT INTO #authStatus SELECT 'Winnicott, D.W.',0
INSERT INTO #authStatus SELECT 'Yorke, C.',0
INSERT INTO #authStatus SELECT 'Young-bruehl, E.',0
INSERT INTO #authStatus SELECT 'Zetzel, E.R.',0

update Author set AuthorStatus = 'Active' 
update author
set IsLiving = 0
from author a
	inner join #authStatus s
	on s.autthorName = a.AuthorNameAndInitials collate database_default
where s.Status = 0

drop table #authStatus
commit tran

begin tran
--select
--a.AuthorName 
--,AuthorFirstPublishedYear = (SELECT MIN(d2.year ) FROM DocumentAuthor da2 INNER JOIN ContentDocuments d2 ON d2.documentId = da2.DocumentId WHERE da2.AuthorId = a.AuthorId )
--from Author a
--where  (SELECT MIN(d2.year ) FROM DocumentAuthor da2 INNER JOIN ContentDocuments d2 ON d2.documentId = da2.DocumentId WHERE da2.AuthorId = a.AuthorId ) <1942
--and a.isliving = 1

update author
set isliving = 0
from author a
where  (SELECT MIN(d2.year ) FROM DocumentAuthor da2 INNER JOIN ContentDocuments d2 ON d2.documentId = da2.DocumentId WHERE da2.AuthorId = a.AuthorId ) <1942
and a.isliving = 1


UPDATE Author SET IsLiving = 0 WHERE AuthorName IN ('Psychoanayltic Electronic Publishing')

UPDATE Author SET AuthorNameSynonyms = 'Sigm Freud,Sigm. Freud.,Sig. Freud,S. Freud,Sigmund Freud,Freud,' WHERE AuthorName = 'Sigm. Freud' AND AuthorNameSynonyms IS NULL 
UPDATE Author SET AuthorNameSynonyms = 'Otto F. Kernberg,Otto F. Kernberg' WHERE AuthorName = 'Otto Kernberg' AND AuthorNameSynonyms IS NULL 
UPDATE Author SET AuthorNameSynonyms = 'David A. Tuckett' WHERE AuthorName = 'David Tuckett' AND AuthorNameSynonyms IS NULL 


commit tran