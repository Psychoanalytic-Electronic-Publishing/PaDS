﻿'Updates
'======
'22/5/11    James Woosnam   HotFix - Open Logs with UserSession
'23/5/11    Julian Gates    SIR2437 - Detect for NULL values when building sText in SendEmailReceipt
'8/6/11     James Woosnam   Settle: Populate merchantReferenceCode as it failes without it
'8/6/11     James Woosnam   Settle: Add code to force an error if failed
'22/6/11    Julian Gates    SIR2459 - Use Subscriber.BillingAddressRow to get either Billing or Main address details
'26/02/13   Julian Gates    SIR3024 - Remove BillTo.phoneNumber from Sub AuthenticateCreditCard as causing problems.
'14/05/15   Julian Gates    SIR3838 - Call new SendEmailReceipt() in SalesOrder class from SendEmailReceipt() in this class.
'26/02/18   Julian Gates    SIR4588 - Modify RemoteAdd code to mask all credit card details.
'26/02/18   Julian Gates    SIR4588 - Pass in PaymentCardNumber and PaymentCardCVNumber from page fields to AuthenticateCreditCard and do not store in Cashbook
'12/03/18   Julian Gates    Handle CyberSourceReasonCode 200 AVS check failed in AuthenticateCreditCard
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields

Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class Cashbook
#Region "Class Properties"

    Public MainDataset As New DataSet
    Dim _CashbookId As Long
    Dim UserSession As UserSession
    Public AuthorisationRejectMsg As String = ""

    Public Property CashbookId() As Integer
        Get
            If Me._CashbookId = Nothing Then
                If Me.MainDataset.Tables.Count <> 0 Then
                    Me._CashbookId = Me.CashbookRow("CashbookId")
                End If
            End If
            Return Me._CashbookId
        End Get
        Set(ByVal Value As Integer)
            _CashbookId = Value
            'initilise dataset
            'Me.Initilise()
        End Set
    End Property

    Private ReadOnly Property Cashbook() As DataTable
        Get
            If Me.MainDataset.Tables("Cashbook") Is Nothing Then
                Me.daCashbook.Fill(Me.MainDataset, "Cashbook")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("Cashbook").Columns("CashbookId")}
            Me.MainDataset.Tables("Cashbook").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("Cashbook")
        End Get
    End Property
    Private _daCashbook As SqlDataAdapter
    Private ReadOnly Property daCashbook() As SqlDataAdapter
        Get
            If Me._daCashbook Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM Cashbook"
                sql += " WHERE CashbookId=" & Me.CashbookId
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daCashbook = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daCashbook)
                _daCashbook.UpdateCommand = cmdBld.GetUpdateCommand()
                _daCashbook.InsertCommand = cmdBld.GetInsertCommand()
                _daCashbook.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daCashbook.InsertCommand.Transaction = Me.db.DBTransaction
                _daCashbook.UpdateCommand.Transaction = Me.db.DBTransaction
                _daCashbook.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daCashbook
        End Get
    End Property

    Public ReadOnly Property CashbookRow() As DataRow
        Get
            If Me.Cashbook.Rows.Count = 0 Then
                Me.daCashbook.Fill(Me.MainDataset.Tables("Cashbook"))
                If Me.Cashbook.Rows.Count = 0 Then
                    Throw New Exception("UserError: CashbookId:" & Me.CashbookId & " can't be found")
                End If
            End If
            Return Me.Cashbook.Rows(0)
        End Get
    End Property

    Private Sub Initilise()
        Dim xx As Integer = 0
        Me.MainDataset = New DataSet
        Me._daCashbook = Nothing
        xx = Me.Cashbook.Rows.Count

    End Sub
    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property

    Public _cyberSourceDecision As String
    Public Property CyberSourceDecision() As String
        Get
            Return _cyberSourceDecision
        End Get
        Set(ByVal value As String)
            _cyberSourceDecision = value
        End Set
    End Property

    Public _cyberSourceReasonCode As String
    Public Property CyberSourceReasonCode() As String
        Get
            Return _cyberSourceReasonCode
        End Get
        Set(ByVal value As String)
            _cyberSourceReasonCode = value
        End Set
    End Property

    Public _cyberSourceRequestID As String
    Public Property CyberSourceRequestID() As String
        Get
            Return _cyberSourceRequestID
        End Get
        Set(ByVal value As String)
            _cyberSourceRequestID = value
        End Set
    End Property

    Public _cyberSourceAuthReplyReasonCode As String
    Public Property CyberSourceAuthReplyReasonCode() As String
        Get
            Return _cyberSourceAuthReplyReasonCode
        End Get
        Set(ByVal value As String)
            _cyberSourceAuthReplyReasonCode = value
        End Set
    End Property

#End Region
    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.CashbookId = 0
        Me.UserSession = UserSession
        'Me._CalledByCashbookId = _CalledByCashbookId
    End Sub
    Sub New(ByVal CashbookId As Integer, ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.CashbookId = CashbookId
        Me.UserSession = UserSession
        Me.Initilise()
    End Sub
    Sub New(ByVal db As BusinessLogic.Database)
        Me.db = db
    End Sub
    Public Sub Save()
        Dim sql As String = ""
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Dim logs As New businesslogic.logs(db, Me.UserSession)
            Select Case Me.CashbookRow.RowState
                Case DataRowState.Added, DataRowState.Modified
                    Me.CashbookRow("LastUpdatedDateTime") = Now()
                    Me.CashbookRow("LastUpdatedByUserId") = UserSession.UserName20
                    'Always overwrite credit card values
                    Dim sNo As String = Me.db.IsDBNull(Me.CashbookRow("PaymentCardNumber"), "")
                    If sNo <> "" Then
                        Me.CashbookRow("PaymentCardNumber") = "XXXXXXXXXXXXXXXXXX".Substring(0, sNo.Length - 4) & sNo.Substring(sNo.Length - 4, 4)
                    Else
                        Me.CashbookRow("PaymentCardNumber") = ""
                    End If
                    Me.CashbookRow("PaymentCardCVNumber") = "XXX"
                    Try
                        logs.WriteAuditLog("Cashbook", Me.CashbookId, UserSession.UserId, UserSession.UserName, Me.CashbookRow.RowState.ToString(), "")
                    Catch ex As Exception
                    End Try
            End Select

            Me.daCashbook.Update(Me.MainDataset, "Cashbook")

            If Me.CashbookRow("CashbookStatus") = "Confirmed" Then
                If Not db.IsDBNull(Me.CashbookRow("OrderNumber")) Then
                    Dim SalesOrder As New BusinessLogic.SalesOrder(CInt(Me.CashbookRow("OrderNumber")), db, UserSession)
                    '31/10/20   James   Saving the order will set it to IsPaid and Complete if appropriate
                    SalesOrder.Save()
                End If
            End If

            Dim al As New AuditLog(db, UserSession)
            al.WriteAuditLog(AuditLog.RecordTables.Cashbook, Me.CashbookId)

            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try

    End Sub

    Public Sub RemoteAdd(ByVal OrderNumber As String,
                   ByVal SalesOrderRow As DataRow,
                   ByVal PaymentCardType As String,
                   ByVal PaymentCardNumber As String,
                   ByVal PaymentCardName As String,
                   ByVal PaymentCardExpiryDate As String,
                   ByVal PaymentCardCVNumber As String
                   )


        Dim message As String = ""
        If PaymentCardType = "" Then
            message += "Payment Card Type required" & System.Environment.NewLine
        End If
        If PaymentCardNumber = "" Then
            message += "Payment Card Number required" & System.Environment.NewLine
        End If
        If PaymentCardName = "" Then
            message += "Payment Card Name required" & System.Environment.NewLine
        End If
        If PaymentCardExpiryDate = "" Then
            message += "Payment Card Expiry Date required" & System.Environment.NewLine
        End If

        If PaymentCardCVNumber = "" Then
            message += "Payment Card CV Number required, this is the last 3 digits on the back of your card. If American Express this is the 4 digits on the front of your card." & System.Environment.NewLine
        End If

        If message <> "" Then
            message = message.Substring(0, message.Length - System.Environment.NewLine.Length)
            Throw New Exception("UserError: Add Cashbook Failed:" & System.Environment.NewLine & message)
        End If
        Dim tranBeginhere As Boolean = False
        If db.DBTransaction Is Nothing Then
            db.BeginTran()
            tranBeginhere = True
        End If

        '26/02/18   Julian Gates   SIR4588 - Modify code to mask all credit card details.
        Try
            Dim row As DataRow = Me.Cashbook.NewRow
            row("CashbookId") = db.GetNextNumber("Cashbook")
            row("CreatedDateTime") = Now()
            row("CreatedByUserId") = UserSession.UserName20
            '13/11/19   James Woosnam   SIR4949 - use companyId from order
            row("CompanyID") = SalesOrderRow("CompanyId")
            row("SubscriberId") = SalesOrderRow.Item("SubscriberId")
            row("EntryType") = "Payment"
            row("PaymentType") = "Credit Card"
            row("OrderNumber") = OrderNumber
            row("EntryDate") = System.DateTime.Today
            row("CashbookStatus") = "Partial"
            row("CurrencyCode") = SalesOrderRow.Item("CurrencyCode")
            row("Amount") = SalesOrderRow.Item("AmountGross")
            row("PaymentCardType") = PaymentCardType
            row("PaymentCardMerchant") = "Cybersource"
            Dim sNo As String = PaymentCardNumber
            row("PaymentCardNumber") = "XXXXXXXXXXXXXXXXXX".Substring(0, sNo.Length - 4) & sNo.Substring(sNo.Length - 4, 4)
            row("PaymentCardName") = PaymentCardName
            row("PaymentCardExpiryDate") = PaymentCardExpiryDate
            row("PaymentCardAuthorisationStatus") = "Pending"
            row("LastUpdatedDateTime") = Now()
            row("LastUpdatedByUserId") = UserSession.UserName20
            row("PaymentCardCVNumber") = "XXX"
            Me.Cashbook.Rows.Add(row)

            Me.Save()
            Me.CashbookId = row("CashbookId")
            Me.Initilise()
            If tranBeginhere Then db.CommitTran()
        Catch ex As Exception
            If tranBeginhere Then db.RollbackTran()
            Throw New Exception("UserError: Add Cashbook failed", ex)
        End Try
    End Sub

    Public Sub InternalAdd(ByVal OrderNumber As String,
                    ByVal CompanyId As String,
                    ByVal SubscriberId As String,
                    ByVal EntryType As String,
                    ByVal PaymentType As String
                   )


        Dim message As String = ""
        If CompanyId = "" Then
            message += "Company required" & System.Environment.NewLine
        End If
        If SubscriberId = "" Then
            message += "Subscriber Id required" & System.Environment.NewLine
        End If
        If EntryType = "" Then
            message += "Entry Type required" & System.Environment.NewLine
        End If

        If PaymentType = "" Then
            message += "Payment Type required" & System.Environment.NewLine
        End If

        If message <> "" Then
            message = message.Substring(0, message.Length - System.Environment.NewLine.Length)
            Throw New Exception("UserError: Add Cashbook Failed:" & System.Environment.NewLine & message)
        End If
        Dim tranStaratedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            db.BeginTran()
            tranStaratedHere = True
        End If
        Try
            Dim row As DataRow = Me.Cashbook.NewRow
            row("CashbookId") = db.GetNextNumber("Cashbook")
            row("CreatedDateTime") = Now()
            row("CreatedByUserId") = UserSession.UserName20
            row("CompanyID") = CompanyId
            row("SubscriberId") = SubscriberId
            row("EntryType") = EntryType
            row("PaymentType") = PaymentType

            If OrderNumber = "" Then
                row("OrderNumber") = System.DBNull.Value
            Else
                row("OrderNumber") = OrderNumber
            End If
            row("EntryDate") = System.DateTime.Today
            row("CashbookStatus") = "Partial"

            Dim currencyCode As String = Nothing

            If OrderNumber <> "" Then
                currencyCode = Me.db.IsDBNull(db.DLookup("CurrencyCode", "SalesOrder", "OrderNumber=" & OrderNumber), System.DBNull.Value)
            End If

            If currencyCode Is System.DBNull.Value Then
                currencyCode = db.IsDBNull(db.DLookup("CurrencyCode", "Company", "CompanyId=" & CompanyId), "non")
            End If
            row("CurrencyCode") = currencyCode

            If OrderNumber <> "" Then
                row("Amount") = db.DLookup("AmountGross", "SalesOrder", "OrderNumber=" & OrderNumber)
            End If

            Me.Cashbook.Rows.Add(row)

            Me.CashbookId = row("CashbookId")

            Me.Save()

            'WriteAuditLog
            If tranStaratedHere Then db.CommitTran()
        Catch ex As Exception
            If tranStaratedHere Then db.RollbackTran()
            Throw New Exception("UserError: Add Cashbook failed", ex)
        End Try
    End Sub

    Public Sub AuthenticateCreditCard(ByVal PaymentCardNumber As String,
                                      ByVal PaymentCardCVNumber As String)
        Try
            Dim Request As New CyberSource.RequestMessage

            ' To help us troubleshoot any problems that you may encounter,
            ' please include the following information about your application.
            Request.clientLibrary = ".NET VB WCF"
            Request.clientLibraryVersion = Environment.Version.ToString()
            Request.clientEnvironment =
                Environment.OSVersion.Platform.ToString() &
                Environment.OSVersion.Version.ToString() & "-CLR" &
                Environment.Version.ToString()


            Request.ccAuthService = New CyberSource.CCAuthService
            Request.ccAuthService.run = "true"

            Request.merchantReferenceCode = Me.CashbookRow("CashbookId")
            Request.merchantID = db.GetParameterValue("CybersourceMerchantID")

            Dim BillTo As New CyberSource.BillTo
            BillTo.firstName = FindFirstword(Me.CashbookRow("PaymentCardName"))
            Dim lastName As String
            lastName = Right(CashbookRow("PaymentCardName"), CLng(Len(Me.CashbookRow("PaymentCardName"))) - CLng(Len(FindFirstword(Me.CashbookRow("PaymentCardName")))))
            If lastName = "" Then
                lastName = FindFirstword(Me.CashbookRow("PaymentCardName"))
            End If
            BillTo.lastName = lastName
            Dim Subscriber As New Subscriber(Me.CashbookRow("SubscriberId"), Me.db, UserSession)
            '22/6/11 Julian Gates SIR2459 - Use Subscriber.BillingAddressRow to get either Billing or Main address details
            Dim PostalAddressRow As DataRow = Subscriber.BillingAddressRow
            '24/5/11    James Woosnam   Allow for NUll in any address fields
            BillTo.street1 = db.IsDBNull(PostalAddressRow("Address1"), "")
            BillTo.street2 = db.IsDBNull(PostalAddressRow("Address2"), "")
            BillTo.city = db.IsDBNull(PostalAddressRow("Town"), "")
            BillTo.country = db.IsDBNull(db.DLookup("CountryCode", "Country", "CountryId=" & PostalAddressRow("CountryId")), "")
            BillTo.state = db.IsDBNull(PostalAddressRow("County"), "")
            BillTo.postalCode = db.IsDBNull(PostalAddressRow("Postcode"), "")
            BillTo.email = Subscriber.GetAddressText("Email")

            Request.billTo = BillTo
            '26/02/18   Julian Gates SIR4588 - Pass in PaymentCardNumber and PaymentCardCVNumber from page fields and do not store in Cashbook
            Dim Card As New CyberSource.Card
            Card.accountNumber = PaymentCardNumber
            Card.expirationMonth = Left(Me.CashbookRow("PaymentCardExpiryDate"), 2)
            Card.expirationYear = Mid(Me.CashbookRow("PaymentCardExpiryDate"), 4, 2)
            Card.cvNumber = PaymentCardCVNumber

            Request.card = Card

            Dim PurchaseTotal As New CyberSource.PurchaseTotals
            PurchaseTotal.grandTotalAmount = Me.CashbookRow("Amount")
            PurchaseTotal.currency = "USD"

            Request.purchaseTotals = PurchaseTotal

            Dim Reply As CyberSource.ReplyMessage = Nothing

            Dim client As New CyberSource.TransactionProcessorClient
            client.ChannelFactory.Credentials.UserName.UserName = Request.merchantID
            client.ChannelFactory.Credentials.UserName.Password = Me.db.GetParameterValue("CybersourceSecurityPassword")

            Reply = client.runTransaction(Request)

            Me.CyberSourceDecision = Reply.decision.ToUpper()
            Me.CyberSourceReasonCode = Reply.reasonCode
            Me.CyberSourceRequestID = Reply.requestID
            If Not Reply.ccAuthReply Is Nothing Then
                Me.CyberSourceAuthReplyReasonCode = Reply.ccAuthReply.reasonCode
            End If

            Select Case Me.CyberSourceDecision
                Case "ACCEPT"
                    'Update the cashbook
                    Me.CashbookRow("PaymentCardAuthorisationCode") = Me.CyberSourceRequestID
                    Me.CashbookRow("PaymentCardRequestToken") = Reply.requestToken
                    Me.CashbookRow("PaymentCardAuthorisationReturnText") = Me.CyberSourceAuthReplyReasonCode & ": Successful transaction."
                    Me.CashbookRow("PaymentCardAuthorisationStatus") = "Accepted"
                    Me.CashbookRow("CashbookStatus") = "Confirmed"
                    Me.CashbookRow("LastUpdatedDateTime") = Now()
                    Me.CashbookRow("LastUpdatedByUserId") = UserSession.UserName20

                    '19/6/17    James Woosnam   SIR4420 - Blank CC details if accepted
                    'Dim sNo As String = CStr(Me.CashbookRow("PaymentCardNumber"))
                    'Me.CashbookRow("PaymentCardNumber") = "XXXXXXXXXXXXXXXXXX".Substring(0, sNo.Length - 4) & sNo.Substring(sNo.Length - 4, 4)
                    'Me.CashbookRow("PaymentCardCVNumber") = "XXX"

                Case "REJECT"
                    'Handle error codes
                    Select Case Me.CyberSourceReasonCode
                        Case "101"
                            AuthorisationRejectMsg += "The request is missing one or more required fields:"
                            If Reply.missingField.Length <> 0 Then
                                For Each msg As String In Reply.missingField
                                    AuthorisationRejectMsg += System.Environment.NewLine & msg
                                Next
                            End If
                        Case "102"
                            AuthorisationRejectMsg += "One or more fields in the request contains invalid data:"
                            If Reply.invalidField.Length <> 0 Then
                                For Each msg As String In Reply.invalidField
                                    AuthorisationRejectMsg += System.Environment.NewLine & msg
                                Next
                            End If
                        '12/03/18   Julian Gates    Handle CyberSourceReasonCode 200 AVS check failed
                        Case "200"
                            AuthorisationRejectMsg += "AVS check failed. Please check your Pads billing address is the same as your payment card address."
                        Case "202"
                            AuthorisationRejectMsg += "Card has expired. Please use a different card or another form of payment." & Me.CyberSourceReasonCode
                        Case "204"
                            AuthorisationRejectMsg += "Insufficient funds in the account."
                        Case "205"
                            AuthorisationRejectMsg += "Lost or stolen card."
                        Case "231"
                            AuthorisationRejectMsg += "Invalid credit card number."
                        Case Else
                            AuthorisationRejectMsg += "Authorisation failed."
                    End Select

                    'Update the cashbook
                    Me.CashbookRow("PaymentCardAuthorisationStatus") = "Rejected"
                    Me.CashbookRow("PaymentCardRejectDescription") = AuthorisationRejectMsg
                    Me.CashbookRow("LastUpdatedDateTime") = Now()
                    Me.CashbookRow("LastUpdatedByUserId") = UserSession.UserName20

                Case Else
                    Throw New Exception("Unexpected Error in authorisation")
            End Select

            Me.Save()

        Catch ex As Exception
            Dim msg As String = ex.Message
            Try '31/1/18 - Ensure a send email failure doesn't desgise true error
                Dim email As New BusinessLogic.Email(db)
                email.SendErrorEmail("Error in Credit Authorisation", "CyberSourceDecision=" & Me.CyberSourceDecision & System.Environment.NewLine _
                                                                    & "CashbookId:" & Me.CashbookId & System.Environment.NewLine _
                                                                   & "Error:" & ex.ToString)
            Catch ex1 As Exception
                msg += vbCrLf & "********  Email Error **********" & vbCrLf & "AND AuthenticateCreditCard email failed:" & ex1.Message
            End Try

            Throw New Exception(msg, ex)
        End Try
    End Sub
    Public Sub SettleCreditCard()
        Try
            Dim Request As New CyberSource.RequestMessage

            ' To help us troubleshoot any problems that you may encounter,
            ' please include the following information about your application.
            Request.clientLibrary = ".NET VB WCF"
            Request.clientLibraryVersion = Environment.Version.ToString()
            Request.clientEnvironment =
                Environment.OSVersion.Platform.ToString() &
                Environment.OSVersion.Version.ToString() & "-CLR" &
                Environment.Version.ToString()


            Request.ccCaptureService = New CyberSource.CCCaptureService
            Request.ccCaptureService.run = "true"
            Request.merchantID = db.GetParameterValue("CybersourceMerchantID")
            Request.ccCaptureService.authRequestID = CashbookRow("PaymentCardAuthorisationCode")
            '8/6/11     James Woosnam   Populate merchantReferenceCode as it failes without it
            Request.merchantReferenceCode = CashbookRow("CashbookId")
            'The line below may not be requried so has been commented out for now
            '26/1/18    Jmaes   Tried line below with new cybersource but didn't make any difference
            'Request.ccCaptureService.authRequestToken = CashbookRow("PaymentCardRequestToken")

            Request.ccCaptureService.merchantReceiptNumber = CashbookRow("CashbookId")

            Dim PurchaseTotals As New CyberSource.PurchaseTotals
            PurchaseTotals.currency = CashbookRow("CurrencyCode")
            PurchaseTotals.grandTotalAmount = CashbookRow("Amount")

            Request.purchaseTotals = PurchaseTotals

            Dim Reply As CyberSource.ReplyMessage = Nothing

            Dim client As New CyberSource.TransactionProcessorClient
            client.ChannelFactory.Credentials.UserName.UserName = Request.merchantID
            client.ChannelFactory.Credentials.UserName.Password = Me.db.GetParameterValue("CybersourceSecurityPassword")

            Reply = client.runTransaction(Request)

            Me.CyberSourceDecision = Reply.decision.ToUpper()
            Me.CyberSourceReasonCode = Reply.reasonCode
            Me.CyberSourceRequestID = Reply.requestID
            If Not Reply.ccAuthReply Is Nothing Then
                Me.CyberSourceAuthReplyReasonCode = Reply.ccAuthReply.reasonCode
            End If

            Select Case Me.CyberSourceDecision
                Case "ACCEPT"
                    'Update the cashbook

                Case "REJECT"
                    'Handle error codes
                    Select Case Me.CyberSourceReasonCode
                        Case "101"
                            AuthorisationRejectMsg += "The request is missing one or more required fields:"
                            If Reply.missingField.Length <> 0 Then
                                For Each msg As String In Reply.missingField
                                    AuthorisationRejectMsg += System.Environment.NewLine & msg
                                Next
                            End If
                        Case "102"
                            AuthorisationRejectMsg += "One or more fields in the request contains invalid data:"
                            If Reply.invalidField.Length <> 0 Then
                                For Each msg As String In Reply.invalidField
                                    AuthorisationRejectMsg += System.Environment.NewLine & msg
                                Next
                            End If
                        Case Else
                            AuthorisationRejectMsg += "Failed, reason Code:" & Me.CyberSourceReasonCode
                    End Select
            End Select
            '8/6/11     James Woosnam   Add code to force an error if failed
            If AuthorisationRejectMsg <> "" Then
                Throw New Exception("****Settle Failed****:" & AuthorisationRejectMsg)
            End If

        Catch ex As Exception
            Throw New Exception("Settlement Failed:" & ex.Message)
        End Try

    End Sub
    Public Sub SendEmailReceipt()
        Try
            '14/05/15   Julian Gates    SIR3838 - Call new SendEmailReceipt() in SalesOrder class
            Dim salesOrder As New SalesOrder(Me.CashbookRow("OrderNumber"), db, UserSession)
            salesOrder.SendEmailReceipt()

        Catch ex As Exception
            Throw New Exception("Send Email Receipt Failed:" & ex.Message)
        End Try
    End Sub
    Function FindFirstword(ByVal text As String) As String
        Dim firstWord As String()
        If text <> "" Then
            firstWord = Split(text, " ")
            FindFirstword = firstWord(0)
        Else
            FindFirstword = Nothing
        End If
    End Function

End Class
