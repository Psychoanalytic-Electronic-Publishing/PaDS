Imports System.Data.SqlClient
Imports System.Data

Partial Class pg490GroupSubscriberSelect
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Public pageContent As String
    Public pageTitle, pageErrorMessage, pageInfoMessage, userName As String
    Dim temp As String
    Dim listTable As DataTable
    Dim SQLSelect, SQLAll, SQLFrom, SQLWhere As String

    'Modification History
    '21/02/2008 Julian Gates  Initial version
    '27/03/08  Julian Gates  Add SubscribeTo Filter and Subscribed To Date Filter SIR 1502
    '27/03/08  Julian Gates  Add Export to Excel functionality SIR 1503
    '03/04/08  Julian Gates  Add date formatting.
    '7/7/11     James Woosnam   Split query into two sections to massively improve performance
    '16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone and fax number fields
    '16/03/20   Julian Gates    Add uPage.currentUser
    '17/03/20   Julian Gates    SIR5037 - Add menu functionality for GroupAdmin users
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        uPage = New UserPage(Me, "List of Subscribers Affiliates", "01a")
        If CBool(uPage.UserSession.Data("CounterReportsOnly")) Then
            Response.Redirect("pg600CounterReports.aspx?" & uPage.UserSession.QueryString)
        End If
        uPage.pageTitle = "List of Subscribers Affiliated To " & Me.uPage.UserSession.Data("GroupSubscriberName")
        uPage.metaDescription = "Psychoanalysts Database System Subscriber List Screen"
        uPage.currentUser = Me.uPage.UserSession.UserName
        uPage.menuId = "01a"
        If Not Page.IsPostBack Then
            If Request.QueryString("InfoMsg") <> "" Then
                'Me.InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            txtRecordsToShow.Text = 20
            Me.txtPageNumber.Text = 1
            Me.FltrSubscribedToDate.Text = uPage.FormatDate(System.DateTime.Today)
            'Populate all dropdown fields
            Dim dropDownIntialValue As String = "<--All-->"
            '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria and Order by
            uPage.PopulateDropDownListFromSQL(Me.FltrSubscriberCategory, "SELECT LookupItemKey as Value,Name as Text FROM Lookup WHERE LookupName = 'SubscriberCategory'" _
            & " AND LookupItemKey <> 'Institutional' AND LookupStatus = 'Active' AND CompanyId =" & Me.uPage.UserSession.Data("CompanyId") & " ORDER BY DisplayOrder,Name,LookupItemKey", uPage.PrimaryConnection, dropDownIntialValue)

            uPage.PopulateDropDownListFromSQL(Me.FltrSubscribedTo, "SELECT  ProductName as Value" _
                                                                & "     ,ProductName as Text" _
                                                                & " FROM dbo.fn495GetGroupProductSubscriptions(" & Me.uPage.UserSession.Data("PrimaryGroupSubscriberId") _
                                                                & "                                             ," & Me.uPage.UserSession.Data("CompanyId") & ") GroupProductSubscriptions" _
                                                                & " GROUP BY ProductName" _
                                                                & " ORDER BY ProductName" _
                                                                , uPage.PrimaryConnection, "<-Select->")
            BuildGrid()
            uPage.FocusControl = Me.FltrSubscriberId
        Else
            If Me.txtPrevRecordsToShow.Value <> Me.txtRecordsToShow.Text Then
                Me.txtPageNumber.Text = 1
                Me.txtPrevRecordsToShow.Value = Me.txtRecordsToShow.Text
            End If
            If Me.txtGotoPageNum.Value <> "" Then
                Me.txtPageNumber.Text = Me.txtGotoPageNum.Value
                Me.txtGotoPageNum.Value = ""
                BuildGrid()
            End If
        End If
    End Sub
    Private Function GetGridSQL() As String
        Dim sLine As String = ControlChars.NewLine
        '7/7/11     James Woosnam   Split query into two sections to massively improve performance

        SQLSelect = "Select  Subscriber.SubscriberId" & sLine
        SQLSelect += " ,Subscriber.SubscriberName AffiliateName " & sLine
        SQLSelect += " ,CompanyAffiliation.SubscriberCategory " & sLine
        SQLSelect += " ,Email.AddressText As EmailAddress" & sLine
        SQLSelect += " ,MainPostal.AddressText As PostalAddress" & sLine

        SQLFrom = " FROM Subscriber" & sLine
        SQLFrom += "     LEFT JOIN SubscriberAddress Email" & sLine
        SQLFrom += "     ON Email.SubscriberId = Subscriber.SubscriberId" & sLine
        SQLFrom += "     AND Email.AddressType = 'Email' " & sLine
        SQLFrom += "     AND Email.AddressDescription = 'Main' " & sLine
        SQLFrom += "    INNER JOIN SubscriberAffiliate CompanyAffiliation" & sLine
        SQLFrom += "        INNER JOIN Company " & sLine
        SQLFrom += "	    ON Company.CompanyId = " & Me.uPage.UserSession.Data("CompanyId") & sLine
        SQLFrom += "	    AND Company.GroupParentSubscriberId = CompanyAffiliation.ParentSubscriberId" & sLine
        SQLFrom += "	ON CompanyAffiliation.ChildSubscriberId = Subscriber.SubscriberId" & sLine
        SQLFrom += "     LEFT JOIN SubscriberAddress MainPostal" & sLine
        '31/3/11    James Woosnam   SIR2401 - Use the company specific address if available else use latest address
        SQLFrom += " 	ON MainPostal.SubscriberAddressId = (SELECT top 1 sa.SubscriberAddressId" & sLine
        SQLFrom += " 											FROM SubscriberAddress sa" & sLine
        SQLFrom += "                                            WHERE sa.SubscriberId = Subscriber.SubscriberId" & sLine
        SQLFrom += "											AND sa.AddressType = 'Postal'" & sLine
        SQLFrom += " 											AND sa.AddressDescription <> 'Redundant'" & sLine
        SQLFrom += " 											Order BY CASE WHEN  sa.AddressDescription = Company.DefaultAddressDescription THEN 0 ELSE 1 End" & sLine
        SQLFrom += " 											    ,sa.LastUpdatedDateTime " & sLine
        SQLFrom += " 											)" & sLine
        'Get required subs from temp table
        SQLWhere = " WHERE Subscriber.SubscriberId IN (" & sLine
        SQLWhere += " SELECT SubscriberId  " & sLine
        SQLWhere += " FROM  Subscriber  " & sLine
        SQLWhere += " WHERE (Subscriber.SubscriberId IN (Select InSub.SubscriberId " & sLine
        SQLWhere += "                                    FROM  " & uPage.SubscriberTable("InSub") & ")" & sLine
        SQLWhere += "         OR Subscriber.SubscriberId = " & Me.uPage.UserSession.Data("PrimaryGroupSubscriberId") & sLine
        SQLWhere += "        )" & sLine
        SQLWhere += " AND Subscriber.SubscriberStatus in ('Current','Proposed') " & sLine
        SQLWhere += "                               ) " & sLine

        If Me.FltrSubscriberId.Text <> "" Then
            SQLWhere += " AND Subscriber.SubscriberId like '%" & Me.FltrSubscriberId.Text & "%'" & sLine
        End If
        If Me.FltrAffiliateName.Text <> "" Then
            SQLWhere += " AND Subscriber.SubscriberName like '%" & Me.FltrAffiliateName.Text & "%'" & sLine
        End If
        If Me.FltrSubscriberCategory.SelectedValue <> "" Then
            SQLWhere += " AND Subscriber.SubscriberCategory = '" & Me.FltrSubscriberCategory.SelectedValue & "'" & sLine
        End If
        If Me.FltrEmail.Text <> "" Then
            SQLWhere += " AND Email.AddressText like '%" & Me.FltrEmail.Text & "%'" & sLine
        End If
        If Me.FltrAddress.Text <> "" Then
            SQLWhere += " AND MainPostal.AddressText like '%" & Me.FltrAddress.Text & "%'" & sLine
        End If
        If Me.FltrSubscribedTo.SelectedValue <> "" Then
            SQLWhere += " AND Subscriber.SubscriberId  in (SELECT TOP 100 PERCENT GroupProductSubscriptions.SubscriberId" & sLine _
                                                        & " FROM dbo.fn495GetGroupProductSubscriptions(" & Me.uPage.UserSession.Data("PrimaryGroupSubscriberId") & sLine _
                                                        & "                                             ," & Me.uPage.UserSession.Data("CompanyId") & ") GroupProductSubscriptions" & sLine _
                                                        & " WHERE GroupProductSubscriptions.ProductName = '" & Me.FltrSubscribedTo.SelectedValue & "' " & sLine _
                                                        & " AND " & uPage.StdCode.vFQ(Me.FltrSubscribedToDate.Text, "D") & " BETWEEN GroupProductSubscriptions.RecurringSubscriptionStartDate AND GroupProductSubscriptions.RecurringSubscriptionEndDate )" & sLine


        End If
        '7/7/11     James Woosnam   Split query into two sections to massively improve performance

        SQLAll = SQLSelect & SQLFrom & SQLWhere
        SQLAll += " GROUP BY Subscriber.SubscriberId " & sLine _
                        & "        ,Subscriber.SubscriberName " & sLine _
                        & "        ,CompanyAffiliation.SubscriberCategory " & sLine _
                        & "        ,Email.AddressText" & sLine _
                        & "        ,MainPostal.AddressText" & sLine _
                        & " ORDER BY Subscriber.SubscriberName Asc " & sLine
        Return SQLAll
    End Function
    Private Sub BuildGrid()
        If Me.IsPageValidForStatus() Then
            Dim html As String = Nothing
            Try
                'Exit Sub
                listTable = uPage.GetListDatatable(Me.txtPageNumber.Text, Me.txtRecordsToShow.Text, Me.lblPaging.Text, GetGridSQL(), uPage.PrimaryConnection)

                If listTable.Rows.Count <> 0 Then
                    For Each row As DataRow In listTable.Rows
                        html = html & "<tr>"
                        html = html & "<td align='left' valign='middle'>" _
                                    & "<a href='../pages/pg491GroupSubscriberUpdate.aspx?PageMode=Update&SubscriberId=" & row.Item("SubscriberId") _
                                    & "&" & uPage.UserSession.QueryString _
                                    & "' Title='Update Subscriber Record' class='lnkMaintNew'>Update</a>" _
                                    & "</td>"
                        html = html & "<td valign='top'><p class='fldView'>" & row.Item("SubscriberId") & "</p></td>"
                        html = html & "<td valign='top'><p class='fldView'>" & row.Item("AffiliateName") & "</p></td>"
                        html = html & "<td valign='top'><p class='fldView'>" & row.Item("SubscriberCategory") & "</p></td>"
                        html = html & "<td valign='top'>" _
                                    & "<a href='MailTo:" & row.Item("EmailAddress") & "'" _
                                    & "' Title='Email " & row.Item("EmailAddress") & "' class='emailLink'>" & row.Item("EmailAddress") & "</a>" _
                                    & "</td>"
                        html = html & "<td valign='top'><p class=fldView>" & Left(uPage.db.IsDBNull(row.Item("PostalAddress"), ""), 20) & "</p></td>"
                        html = html & "</tr>"
                    Next
                Else
                    uPage.PageError = "No records match your selection critieria"
                End If
            Catch e As Exception
                uPage.PageError = e.ToString
            End Try
            'Assign grid to Label
            lblGridView.Text = html
        End If
    End Sub
    Private Sub btnFilter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFilter.Click
        Me.txtPageNumber.Text = 1
        BuildGrid()
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?" & uPage.UserSession.QueryString)
    End Sub
    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        Select Case validatorStatus
            Case Else
                If txtRecordsToShow.Text = "" Then
                    uPage.FieldErrorControl(Me.txtRecordsToShow, "Max Records To Show must be numerical")
                End If
                If txtRecordsToShow.Text <> "" Then
                    If Not IsNumeric(Me.txtRecordsToShow.Text) Then
                        uPage.FieldErrorControl(Me.txtRecordsToShow, "Max Records To Show must be numerical")
                    End If
                End If
                If Me.FltrSubscribedToDate.Text = "" Then
                    Me.FltrSubscribedToDate.Text = uPage.FormatDate(System.DateTime.Today)
                End If
                If Me.FltrSubscribedToDate.Text <> "" Then
                    uPage.FieldValidateDate(Me.FltrSubscribedToDate)
                End If
        End Select
        Return uPage.IsValid
    End Function
    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub FltrSubscriberCategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FltrSubscriberCategory.SelectedIndexChanged
        BuildGrid()
    End Sub

    Private Sub AddNewBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddNewBtn.Click
        Response.Redirect("../pages/pg491GroupSubscriberUpdate.aspx?PageMode=Add&" & uPage.UserSession.QueryString)
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        uPage.PagePreRender()
    End Sub

    Private Sub FltrSubscribedTo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FltrSubscribedTo.SelectedIndexChanged
        BuildGrid()
    End Sub

    Private Sub ExportBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportBtn.Click
        Dim sLine As String = ControlChars.NewLine
        If Me.IsPageValidForStatus("") Then
            Try
                'GetGridSQL needs run first to popluate the SQL strings and popualte the temp #subs table
                '16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone and fax number fields
                GetGridSQL()

                SQLSelect = "SELECT " & sLine
                SQLSelect += "	AffiliateReferenceID = MIN(GroupAffiliation.AffiliateReferenceID)" & sLine

                SQLSelect += "  ,SubscriberCategory = MIN(CompanyAffiliation.SubscriberCategory) " & sLine
                SQLSelect += "	,ParentSubscriberName =MIN(ParentSubscriber.SubscriberName)" & sLine

                SQLSelect += "	,MIN( CASE Subscriber.EntityType WHEN 'Organisation' THEN '' ELSE Subscriber.FirstName END) AS FirstName" & sLine
                SQLSelect += "	,MIN( CASE Subscriber.EntityType WHEN 'Organisation' THEN Subscriber.SubscriberName ELSE Subscriber.LastName END) AS LastName" & sLine
                SQLSelect += "	,MIN( MainPostal.Address1) AS Address1" & sLine
                SQLSelect += "	,MIN( MainPostal.Address2) AS Address2" & sLine
                SQLSelect += "	,MIN( MainPostal.Address3) AS Address3" & sLine
                SQLSelect += "	,MIN( MainPostal.Address4) As Address4" & sLine
                SQLSelect += "	,MIN( MainPostal.Town) AS Town" & sLine
                SQLSelect += "	,MIN( MainPostal.County) As County" & sLine
                SQLSelect += "	,MIN( MainPostal.PostCode) AS PostCode" & sLine
                SQLSelect += "	,MIN( Country.CountryName) As CountryName" & sLine
                SQLSelect += "	,MIN( Email.AddressText) As EmailAddress" & sLine
                SQLSelect += "	,MIN( Subscriber.WebUserName) As WebUserName" & sLine
                SQLSelect += "	,'' As WebUserPassword" & sLine

                SQLFrom += "    INNER JOIN SubscriberAffiliate GroupAffiliation" & sLine
                SQLFrom += "          INNER JOIN Subscriber ParentSubscriber"
                SQLFrom += "          On ParentSubscriber.SubscriberId = GroupAffiliation.ParentSubscriberId"
                SQLFrom += "	ON GroupAffiliation.ChildSubscriberId = Subscriber.SubscriberId" & sLine
                SQLFrom += "	AND GroupAffiliation.ParentSubscriberId =" & Me.uPage.UserSession.Data("PrimaryGroupSubscriberId")

                SQLFrom += " 	LEFT JOIN Country" & sLine
                SQLFrom += " 	ON Country.CountryId = MainPostal.CountryId" & sLine

                SQLAll = SQLSelect & SQLFrom & SQLWhere
                SQLAll += " GROUP BY Subscriber.SubscriberId" & sLine
                SQLAll += "     , Subscriber.SubscriberName" & sLine
                SQLAll += " Order BY Subscriber.SubscriberName" & sLine
                Dim db As New BusinessLogic.Database(uPage.PrimaryConnection)
                db.CommandTimeout = 60
                Dim tbl As DataTable = db.GetDataTableFromSQL(SQLAll)
                Dim fileNameXLSTemplate As String = System.Configuration.ConfigurationManager.AppSettings("XLSImportTemplateDirectory") & "\SubscriberImportBatchTemplate.xls"

                uPage.ExportDataTableAsXLSToBrowser(tbl, fileNameXLSTemplate, "Affiliated Subscribers")

            Catch ex As Exception
                uPage.PageError = "Error Occurred Exporting Data" & sLine & ex.ToString & sLine & SQLAll
            End Try
        End If
    End Sub
End Class
