﻿Imports System.Data
Imports System.Data.SqlClient
'Modification History
'21/09/21  Julian Gates   Initial version

Partial Class pages_pg164BatchJobMaint
    Inherits System.Web.UI.Page
    Dim pageMode As String = ""
    Dim selectCommand As String = ""
    Dim ds As New DataSet
    Dim dRow As DataRow
    Dim dTble As DataTable
    Public uPage As UserPage
    Dim cPageNumber As Long = Nothing
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        uPage = New UserPage(Me, "Batch Job Maintenance", "")
        Me.pageHeaderTitle.Text = "Batch Job Maintenance"

        'Put user code to initialize the page here
        pageMode = "Update"

        Me.BatchJobId.Text = Request.QueryString("BatchJobId")
        If Request.QueryString("PageNumber") <> "" Then
            Me.cPageNumber = Request.QueryString("PageNumber")
        End If
        selectCommand = "Select *" _
           & " From BatchJob" _
           & " Where BatchJobId = '" & Me.BatchJobId.Text & "'"

        If Page.IsPostBack Then
            ds = CType(ViewState("MainDataSet"), DataSet)
        Else
            ReadRecord()
        End If
        PageSetup()
    End Sub
    Sub PageSetup()
        uPage.FocusControl = Me.BatchJobStatus
    End Sub
    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        Select Case validatorStatus

        End Select
        If enableClientSideValidation Then
        Else
        End If
    End Sub
    Private Function IsPageValidForStatus(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True) As Boolean
        Dim allIsValid As Boolean = True
        PageSetupValidators(validatorStatus, enableClientSideValidation)
        Page.Validate()
        allIsValid = Page.IsValid

        If Me.BatchJobName.Text = "" Then
            uPage.PageError = "Batch Job Name is mandatory"
            allIsValid = False
        End If

        If Me.BatchJobStatus.Text = "" Then
            uPage.PageError = "Batch Job Status is mandatory"
            allIsValid = False
        End If

        If Me.RescheduleDelaySeconds.Text = "" Then
            uPage.PageError = "Reschedule Delay Seconds is mandatory"
            allIsValid = False
        End If
        If Me.RescheduleDelaySeconds.Text <> "" Then
            If Not IsNumeric(Me.RescheduleDelaySeconds.Text) Then
                uPage.PageError = "Reschedule Delay Seconds must be a numerical value"
                allIsValid = False
            End If
        End If

        Return allIsValid
    End Function
    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Dim commandText As String = ""
        Dim dr As SqlDataReader = Nothing
        Dim field As DataSet = Nothing
        Dim da As New SqlDataAdapter(selectCommand, uPage.PrimaryConnection)
        'Populate Dataset
        da.Fill(ds, "BatchJob")

        'Populate all dropdown fields
        If pageMode = "Update" Then
            'Read all data from dataset into page fields
            uPage.PopulatePageFieldsFromDataRow(ds.Tables("BatchJob").Rows(0))
            'Me.XMLParameters1.Text = ds.Tables("BatchJob").Rows(0).Item("XMLParameters")
            Me.XMLParameters.Text = CStr(Me.XMLParameters.Text).Replace("<", "{").Replace(">", "}")
        End If
    End Sub
    Function SaveRecord() As Boolean
        '******************************************************
        'Description:	Save the record either by updating or adding
        '******************************************************
        Dim intRowsAffected As Integer = Nothing
        Dim cmdBld As System.Data.SqlClient.SqlCommandBuilder
        Dim da As New SqlDataAdapter(selectCommand, uPage.PrimaryConnection)

        dTble = ds.Tables("BatchJob")
        If dTble.Rows.Count = 0 Then
            dRow = dTble.NewRow()
        Else
            dRow = dTble.Rows(0)
        End If
        'Read Values from page fields into dataset table
        uPage.PopulateDataRowFromPageFields(dRow)
        dRow("XMLParameters") = CStr(uPage.db.IsDBNull(dRow("XMLParameters"), "").Replace("{", "<").Replace("}", ">"))

        If dTble.Rows.Count = 0 Then
            dTble.Rows.Add(dRow)
        End If
        'Add or Update data using command builder and transaction
        cmdBld = New System.Data.SqlClient.SqlCommandBuilder(da)
        da.UpdateCommand = cmdBld.GetUpdateCommand()
        Dim transaction As SqlTransaction = Nothing
        Try
            transaction = uPage.PrimaryConnection.BeginTransaction
            da.UpdateCommand.Transaction = transaction
            intRowsAffected = da.Update(ds, "BatchJob")
            transaction.Commit()
            Return True

        Catch e As Exception
            uPage.PageError = e.ToString
            transaction.Rollback()
            Return False
        End Try
    End Function

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        uPage.PageUnload()
    End Sub

    Private Sub Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Save.Click
        If IsPageValidForStatus("") Then
            If SaveRecord() Then
                InfoMsg.Text = "Record Saved"
            End If
        End If
    End Sub
    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub
    Private Sub Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Clear.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&BatchJobId=" & Me.BatchJobId.Text)
    End Sub
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = ds
        uPage.PagePreRender()
    End Sub
    Private Sub Back_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Back.Click
        Response.Redirect("../pages/pg163BatchJobList.aspx")
    End Sub
End Class
