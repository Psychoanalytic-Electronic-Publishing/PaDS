﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'29/10/19  Julian Gates   Initial version
'13/2/20    James Woosnam   SIR5017 - ensure invalid links are handled more clearly
'17/8/20    James Woosnam   SIR5082 - Store SessionId in, and restored from, a new session cookie
'25/8/20    Julian Gates    SIR5121 - Add new redirect selection section shown when user sucessfully activates.
'20/05/21   Julian Gates    SIR5251 - Get UserName from RemoteUser using UserId
'25/5/21    James Woosnam   SIR5245 - Show PEPWeb logon after password reset
'08/9/21    James Woosnam   Hide old PEP link following switch over
'11/1/22    James Woosnam   SIR5405 - Restore session to try and avoid cocurrency issue
'24/2/22    James Woosnam   SIR5448 - Give user a better message if they try to reset their password once it has already been reset, and the session they opened this page with has been logged off.
'19/4/22    James Woosnam   SIR5465 - If use old reset link more than thrre times show different message and reset PasswordRetryAttempts
'20/6/22    Julian Gates    SIR5512 - Add Additional Language Support 

Partial Class pages_pg071UserAuthorisation
    Inherits System.Web.UI.Page
    Dim ds As New DataSet
    Dim StdCode As New BusinessLogic.StdCode()
    Enum PageModes
        Normal
        InvalidActivation
        AlreadyActive
        EmailSent
        Activated
    End Enum

    Private _RemoteUser As BusinessLogic.RemoteUser = Nothing
    Public Property RemoteUser() As BusinessLogic.RemoteUser
        Get
            If Me._RemoteUser Is Nothing Then
                Me._RemoteUser = New BusinessLogic.RemoteUser(Me.Master.db, Me.Master.UserSession)
            End If
            Return Me._RemoteUser
        End Get
        Set(ByVal value As BusinessLogic.RemoteUser)
            Me._RemoteUser = value
        End Set
    End Property

    Public Property DisplayLanguage As BusinessLogic.UserSession.DisplayLanguages
        Get
            Return Me.Master.UserSession.DisplayLanguage
        End Get
        Set(value As BusinessLogic.UserSession.DisplayLanguages)
            Me.Master.UserSession.DisplayLanguage = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '8/12/21    James Woosnam   Update Error reporting info
        Try
            'Put user code to initialize the page here
            '17/8/20    James Woosnam   SIR5082 - Store SessionId in, and restored from, a new session cookie
            'Must reset cookie when opening with tempPassword, tempPassword is striped off after execution so sessioncookie must then be used
            Dim ResetSessionCookieIfNotPostback As Boolean = Request.QueryString("TempPassword") <> "" And Not IsPostBack
            Master.Initilise("Account Activation & Password Reset", "00", "", "", "", ResetSessionCookieIfNotPostback)
            Master.ShowLanguageRBL = True
            If Page.IsPostBack Then

                Me.RemoteUser = New BusinessLogic.RemoteUser(Master.UserSession.UserId, Me.Master.db, Me.Master.UserSession)

            Else
                If Request.QueryString("EmailAddress") = "" _
                Or Request.QueryString("UserId") = "" _
                Or Request.QueryString("TempPassword") = "" _
                Then
                    Me.Master.WebForm.AddPageError(New Exception(Master.GetTranslatedText(248, 71, "Invalid activation. Please contact support"), New Exception("QueryString values UserId, EmailAddress or TempPassword are blank")))
                    ViewState("PageMode") = PageModes.InvalidActivation
                    Exit Sub
                End If

                ViewState("PageMode") = PageModes.Normal
                Me.EmailAddress.Text = Request.QueryString("EmailAddress")
                '20/05/21   Julian Gates    SIR5251 - Get UserName from RemoteUser using UserId
                If Master.UserSession.Data("AfterPasswordSetupReturnToPep") IsNot Nothing AndAlso Not CBool(Master.UserSession.Data("AfterPasswordSetupReturnToPep")) Then
                    Master.UserSession.Restore("") 'If come from PEP (AfterPasswordSetupReturnToPep-True), preserve session
                End If
                Me.Master.UserSession.UserSessionRow("UserId") = Request.QueryString("UserId") 'populate to help debugging
                Me.Master.UserSession.UserSessionRow("UserName") = Request.QueryString("UserId") 'populate to help debugging
                Me.Master.UserSession.Save()
                '11/1/22    James Woosnam   SIR5405 - Restore session to try and avoid cocurrency issue
                Master.UserSession = New BusinessLogic.UserSession(Master.db) '15/8/22   James   SIR5548 - Create new session object to try and avoid concurrency.
                Master.UserSession.Restore(Master.UserSession.UserSessionId)
                Me.UserName.Text = Me.Master.WebForm.db.DLookup("UserName", "RemoteUser", "UserId=" & Request.QueryString("UserId"))
                Try
                    Try
                        Master.UserSession.Logon(Me.UserName.Text, Request.QueryString("TempPassword"))
                    Catch ex As Exception
                        Master.AddAdditionalInfoForlog("P1:" & ex.ToString)
                        If ex.Message.Contains("Invalid user and/or password") Or ex.Message.Contains("You have exceeded your invalid logon attempts") Then
                            Try
                                Dim ru As New BusinessLogic.RemoteUser(Me.UserName.Text, Master.db, Master.UserSession)
                                Select Case ru.UserStatus
                                    Case BusinessLogic.RemoteUser.UserStates.Active
                                        Me.Master.WebForm.AddPageError(Master.GetTranslatedText(249, 71, "This user has already been activated"))
                                        ViewState("PageMode") = PageModes.AlreadyActive
                                        Exit Sub
                                    Case BusinessLogic.RemoteUser.UserStates.Emailed
                                        '20/12/21   James Woosnam   SIR5390 - If logon fails, but find a user with emailed status then new email probably sent
                                        Dim emailURL As String = Master.db.GetParameterValue("WebSiteURL") & "/Pages/pg070Logon.aspx?Action=RequestPassword&CallSource=PaDS&" & Master.UserSession.QueryString
                                        If CDate(ru.EmailAuthenticationSentDateTime) < Now.AddHours(ru.HoursToConfirmNewEmail * -1) Then
                                            Me.InvalidActivationMessage.Text = Master.GetTranslatedText(250, 71, "Your reset/activation email has expired.  Please use the link below to send a new one.")
                                            Me.Master.WebForm.AddPageError(New Exception(Me.InvalidActivationMessage.Text, ex))
                                            ViewState("PageMode") = PageModes.InvalidActivation
                                            Exit Sub
                                        End If
                                        If ex.Message.Contains("Invalid user and/or password") Then
                                            Me.InvalidActivationMessage.Text = Master.GetTranslatedText(1, 0, "A password reset email was sent " & ru.TimeDescSinceEmailSent & " ago, please use the link in that email, and delete any previous reset password emails.  If the email hasn't been received please use the link below to re-send it.")
                                        ElseIf ex.Message.Contains("You have exceeded your invalid logon attempts") Then
                                            '19/4/22    James Woosnam   SIR5465 - If use old reset link more than thrre times show different message and reset PasswordRetryAttempts
                                            Me.InvalidActivationMessage.Text = Master.GetTranslatedText(251, 71, "It looks like you are using a link from an old email, please check you haven't been sent a more recent email.")
                                            Master.db.ExecuteSQL("UPDATE RemoteUser SET PasswordRetryAttempts=0 WHERE UserId=" & ru.UserId)
                                        End If

                                        Me.Master.WebForm.AddPageError(New Exception(Me.InvalidActivationMessage.Text, ex))
                                        ViewState("PageMode") = PageModes.InvalidActivation
                                        Exit Sub
                                    Case Else
                                        Throw ex
                                End Select
                            Catch ex2 As Exception
                                Master.AddAdditionalInfoForlog("P2:" & ex2.ToString)
                                Me.InvalidActivationMessage.Text = Master.GetTranslatedText(252, 71, "This password reset link is no longer valid.")
                                Me.Master.WebForm.AddPageError(New Exception(Me.InvalidActivationMessage.Text, ex2))
                                ViewState("PageMode") = PageModes.InvalidActivation
                                Exit Sub
                            End Try


                        Else
                            Throw ex
                        End If
                    End Try
                    Me.RemoteUser = New BusinessLogic.RemoteUser(CInt(Request.QueryString("UserId")), Me.Master.db, Me.Master.UserSession)
                    If CDate(Me.RemoteUser.RemoteUserRow("EmailAuthenticationSentDateTime")) < Now.AddHours(Me.RemoteUser.HoursToConfirmNewEmail * -1) Then
                        Me.InvalidActivationMessage.Text = Master.GetTranslatedText(253, 71, "Your reset/activation email has expired.  Please use the link below to send a new one.")
                        Me.Master.WebForm.AddPageError(Me.InvalidActivationMessage.Text)
                        ViewState("PageMode") = PageModes.InvalidActivation
                        Exit Sub
                    End If
                    Me.UserName.Text = Me.RemoteUser.UserName
                Catch ex As Exception
                    Me.InvalidActivationMessage.Text = Master.GetTranslatedText(254, 71, "Unexpected error confirming the user. Please try again.")
                    Me.Master.WebForm.AddPageError(New Exception(Me.InvalidActivationMessage.Text, ex))
                    ViewState("PageMode") = PageModes.InvalidActivation
                End Try
                Me.NewPassword.Focus()

            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("Unexpected error loading the page.", ex))
            ViewState("PageMode") = PageModes.InvalidActivation
        End Try

        If Page.IsPostBack Then
        Else
        End If
        '25/8/20    Julian Gates    SIR5121 - Add new redirect selection section shown when user sucessfully activates.
        Me.PadsLink.NavigateUrl = "pg070Logon.aspx?Action=RedirectToUserHome&" & Me.Master.UserSession.QueryString
        Me.Post2021PEPWebLink.NavigateUrl = Master.db.GetParameterValue("PEPWeb2021URL") & "?SessionId=" & Me.Master.UserSession.UserSessionId
    End Sub

    Sub PageSetup()

        Master.PageTitle = Master.GetTranslatedText(247, 71, "Account Activation & Password Reset")
        Me.ActivateBtn.Text = Master.GetTranslatedText(232, 71, "Activate/Reset")
        Me.ActivateBtn.ToolTip = Master.GetTranslatedText(233, 71, "Update Password and Activate Account")
        Me.SendPasswordResetEmailBtn.Text = Master.GetTranslatedText(61, 0, "Send Password Reset Email")
        Me.SendPasswordResetEmailBtn.ToolTip = Master.GetTranslatedText(61, 0, "Send Password Reset Email")
        Me.PadsLink.Text = Master.GetTranslatedText(236, 71, "Here")
        Me.PadsLink.ToolTip = Master.GetTranslatedText(244, 71, "Click to go to PaDS System")
        Me.Post2021PEPWebLink.Text = Master.GetTranslatedText(236, 71, "Here")
        Me.Post2021PEPWebLink.ToolTip = Master.GetTranslatedText(245, 71, "Click here to go to PEP")

        Dim pm As PageModes = ViewState("PageMode")
        Me.InvalidActivationTable.Visible = pm = PageModes.InvalidActivation
        Me.AlreadyActiveTable.Visible = pm = PageModes.AlreadyActive
        Me.ResetTable.Visible = pm = PageModes.Normal
        Me.EmailSentTable.Visible = pm = PageModes.EmailSent
        '25/8/20    Julian Gates    SIR5121 - Add new redirect selection section shown when user sucessfully activates.
        Me.ActivatedLinkTable.Visible = pm = PageModes.Activated
        If pm = PageModes.Activated Then
            Me.ResetTable.Visible = False
            Me.RONamesTable.Visible = False
        End If

        '25/5/21    James Woosnam   SIR5263 - Show new PEPWeb link, only if user has subscription
        'If Master.UserSession.Data("HasSubscription") IsNot Nothing AndAlso CBool(Master.UserSession.Data("HasSubscription")) Then
        '    Me.Post2021PEPWebLink.Visible = True
        'End If
        '2/7/21     James Woosnam   SIR5263 - reverse above change and alway show link
        Me.Post2021PEPWebLink.Visible = True
    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus

            Case Else
                '24/2/22    James Woosnam   SIR5448 - Give user a better message if they try to reset their password once it has already been reset, and the session they opened this page with has been logged off.
                If Master.UserSession.UserId <> Request.QueryString("UserId") Then
                    Try
                        RemoteUser = New BusinessLogic.RemoteUser(CInt(Request.QueryString("UserId")), Master.db, Master.UserSession)
                        If RemoteUser.UserStatus = BusinessLogic.RemoteUser.UserStates.Active Then
                            Me.Master.WebForm.AddPageError(String.Format(Master.GetTranslatedText(255, 71, "The password for user '{0}' has already been reset.  This form can no longer be used."), RemoteUser.UserName))
                            Return False
                        End If
                    Catch ex As Exception

                    End Try
                    Me.Master.WebForm.AddPageError(Master.GetTranslatedText(256, 71, "This page has become invalid.  If you haven't already reset your password, please re-click the link in the email you were sent."))
                    Return False
                End If
                Me.Master.WebForm.FieldValidateMandatory(Me.NewPassword)
                Me.Master.WebForm.FieldValidateMandatory(Me.ConfirmPassword)

                If Me.NewPassword.Text <> Me.ConfirmPassword.Text Then
                    Me.Master.WebForm.AddPageError(Master.GetTranslatedText(257, 71, "Passwords do not match"))
                Else
                    Dim err As String = ""
                    If Not RemoteUser.IsValidPassword(Me.NewPassword.Text, err) Then
                        Me.Master.WebForm.FieldErrorControl(Me.NewPassword, err)
                    Else
                        Select Case RemoteUser.UserStatus
                            Case BusinessLogic.RemoteUser.UserStates.Emailed
                            Case Else
                                Me.Master.WebForm.AddPageError(String.Format(Master.GetTranslatedText(258, 71, "The users status is: {0}. Only users with an Emailed status can be activated.  It looks like this password was successfully reset elsewhere. Please contact support if further information required."), RemoteUser.UserStatus.ToString))
                        End Select
                    End If


                End If

        End Select

        Return Me.Master.WebForm.IsValid
    End Function

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ActivateBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ActivateBtn.Click
        Dim activateSuccessfull As Boolean = False
        If Not Me.Master.WebForm.IsValid Then
            Exit Sub
        End If
        Try
            If Me.IsPageValidForStatus("") Then

                Try
                    Me.RemoteUser.Activate(Me.NewPassword.Text)
                    Dim peps As New BusinessLogic.PEPSecurity(Master.db, New BusinessLogic.StdCode().GetIPAddress(Request), Master.UserSession)
                    peps.CompleteAuthentication(Me.RemoteUser, Me.Master.WebForm.AdditionalInfoForlog)
                    '13/6/21    James Woosnam   SIR5263 - If no subscription show message and don't automatically return to PEP
                    If Master.UserSession.Data("HasSubscription") Is Nothing OrElse Not CBool(Master.UserSession.Data("HasSubscription")) Then Me.NoSubscriptionWarning.Visible = True


                    activateSuccessfull = True
                    Me.Master.AddAdditionalInfoForlog("User Activated with new password")
                Catch ex As Exception
                    Me.Master.WebForm.AddPageError(New Exception(Master.GetTranslatedText(59, 0, "An Unexpected error has occured.  Please contact support"), ex))
                End Try

            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(Master.GetTranslatedText(59, 0, "An Unexpected error has occured.  Please contact support"), ex))
        Finally
        End Try

        If activateSuccessfull Then
            If Master.UserSession.Data("AfterPasswordSetupReturnToPep") IsNot Nothing AndAlso CBool(Master.UserSession.Data("AfterPasswordSetupReturnToPep")) Then
                '13/6/21    James Woosnam   SIR5263 - If no subscription show message and don't automatically return to PEP
                '2/7/21     James Woosnam   SIR5263 - Reverse above change
                'And Master.UserSession.Data("HasSubscription") IsNot Nothing AndAlso CBool(Master.UserSession.Data("HasSubscription")) Then
                Response.Redirect(Master.db.GetParameterValue("PEPWeb2021URL") & "?sessionId=" & Master.UserSession.UserSessionId)
            End If
            ViewState("PageMode") = PageModes.Activated
        End If
    End Sub
    Protected Sub SendPasswordResetEmailBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SendPasswordResetEmailBtn.Click
        Try
            Me.Master.WebForm.ClearPageErrors()
            'Send password reset email
            Dim ru As New BusinessLogic.RemoteUser(Me.UserName.Text, Master.db, Master.UserSession)
            ru.ResetPasswordAndEmail()
            ViewState("PageMode") = PageModes.EmailSent
            Me.Master.AddAdditionalInfoForlog("ResetPasswordAndEmail Complete")

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(Master.GetTranslatedText(59, 0, "An unexpected error has occured.  Please contact support."), ex))
        End Try

    End Sub
End Class

