﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        'Add Zedra36 URL
        Dim auth As String = Request.Url.Authority
        Dim url As String = ""
        If auth.ToLower.Contains("localhost") Then
            url = "http://" & auth & "/pages/pg070Logon.aspx"
        ElseIf auth.ToLower.Contains("zedra36") Then
            url = "http://" & auth & "/Pads/pages/pg070Logon.aspx"
        Else
            url = "https://" & auth & "/pages/pg070Logon.aspx"
        End If
        Response.Redirect(url)

    End Sub

End Class
