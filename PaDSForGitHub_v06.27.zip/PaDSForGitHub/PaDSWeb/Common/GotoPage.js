<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

function GotoPage( lngPageNo ) {
var ofrm = 	document.forms['Form1']
	ofrm['txtGotoPageNum'].value = lngPageNo
	ofrm.submit()

}

//-->
</SCRIPT>