﻿'Modification History
'10/9/21    James Woosnam   SIR5313 - Initial Version to send bulk emails from pre-populated EmailDistributionLog table, see process notes below
'15/12/21   James Woosnam   SIR5381 - Tweaked to work with SalesOrder.PopulateAndSubmitBlockConfirmationEmail and resubmit job if limits reached
Public Class Emailing
#Region "Class Properties"
    Dim SentEmailsCount As Integer = 0
    Dim BatchJobId As Integer = 0
    Dim UserSession As UserSession

    Private _db As BusinessLogic.Database = Nothing
    Private Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property
    Dim BatchLog As BatchLog = Nothing
    Public ProcessNotes As String = "
All people requiring emails need to to be added to the EmailDistributionLog table, key fields:
Status:          This must initially be set to NotSent
EmailName:       Unique name for this batch of emails, used when invoking Ron from Test harness.
TemplateFileName:Name of the template HTM file for this email that is stored in the main terms and conditions folder.  Fields from the table will be merged in to this file is surrounded by {{FieldName}}.  May need to check the text source as sometimes words can put in HTML between the {{ and the field name.
EmailAddress:    This must be populated
EmailSortOrder:  Can be use to dictate the order that the emails are sent, If NULL uses EmailDistributionLogId
EmailFromAccount,EmailBody,EmailSentDate,BatchLogId: Populated once the email is sent

A new section on the test harness will allow the following parameters to be entered and added to a new batch job:
EmailName:      As Above
NoOfEmailsInBatch:  Batch job will send this number of email and then stop
EmailFromAccount:   This is the account to send the email, the password comes from parameter SMPTPassword which is the same for sales@pep-web.org and sales@psychoanalystdatabase.com.  This will need more work if other accounts used.
"
#End Region

    Public Sub New(ByVal db As BusinessLogic.Database)
        Me.db = db
    End Sub
    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
    End Sub

    Public Sub Submit(EmailName As String,
                       NoOfEmailsInBatch As Integer,
                       EmailFromAccount As String,
                      Optional ScheduledStartDateTime As Date = Nothing
                                 )

        Dim bj As New BusinessLogic.BatchJob(db)
        bj.SubmittedByUserSessionId = Me.UserSession.UserSessionIdGUID
        bj.Parameters.Add("EmailName", EmailName)
        bj.Parameters.Add("NoOfEmailsInBatch", NoOfEmailsInBatch)
        bj.Parameters.Add("EmailFromAccount", EmailFromAccount)
        If ScheduledStartDateTime = Nothing Then ScheduledStartDateTime = Now()
        bj.ScheduledStartDateTime = ScheduledStartDateTime
        bj.CreateBatchJobEntry("SendDistributionEmails", db)

    End Sub

    Public Sub Execute(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.Execute(Parameters.GetValue("EmailName"),
                    Parameters.GetValue("NoOfEmailsInBatch"),
                    Parameters.GetValue("EmailFromAccount"))
    End Sub
    Dim EmailName As String
    Dim NoOfEmailsInBatch As Integer = 0
    Dim EmailFromAccount As String = ""
    Public Sub Execute(EmailName As String,
                       NoOfEmailsInBatch As Integer,
                       EmailFromAccount As String
                                 )
        Me.EmailName = EmailName
        Me.NoOfEmailsInBatch = NoOfEmailsInBatch
        Me.EmailFromAccount = EmailFromAccount
        Me.BatchLog = New BatchLog("Emailing" _
                                     , "EmailName:" & EmailName & ";EmailFromAccount:" & EmailFromAccount & ";NoOfEmailsInBatch:" & NoOfEmailsInBatch _
                                     , Me.db _
                                     , Me.BatchJobId)

        Try
            SendEmails()
            BatchLog.Update(SentEmailsCount & " emails sent in total")

            BatchLog.Update("Complete", "Complete")
        Catch ex As Exception
            BatchLog.Update("Emailing Failed:" & ex.ToString, "Failed")
            Throw New Exception("Emailing Failed:" & ex.ToString)
        End Try
    End Sub
    Public Sub SendEmails()
        '15/12/21   James Woosnam   SIR5381 - Tweaked to work with SalesOrder.PopulateAndSubmitBlockConfirmationEmail and resubmit job if limits reached

        Dim Body As String = ""
        Dim Subject As String = ""
        Dim EmailsSentInLast24Hours As Integer = db.DLookup("count(*)", "EmailDistributionLog", "EmailName = '" & Me.EmailName & "' AND EmailSentDate BETWEEN DATEADD(DAY,-1,GETDATE()) AND GETDATE() AND EmailFromAccount = '" & EmailFromAccount & "'")
        Dim EmailMaxIn24Hours As Integer = db.GetParameterValue("EmailMaxIn24Hours", 2)
        If EmailsSentInLast24Hours >= EmailMaxIn24Hours Then
            BatchLog.Update("Sending more emails will exceed EmailMaxIn24Hours parameter:" & EmailMaxIn24Hours & ".  A new job will start in 24 hours time.")
            Me.Submit(EmailFromAccount:=EmailFromAccount, NoOfEmailsInBatch:=Me.NoOfEmailsInBatch, EmailName:=EmailName, ScheduledStartDateTime:=Now.AddHours(24))
            Exit Sub
        End If
        Dim sql As String = "
SELECT TOP " & NoOfEmailsInBatch & "
*
FROM EmailDistributionLog l
WHERE l.EmailName = '" & Me.EmailName & "'
AND l.EmailDistributionStatus = 'NotSent'
AND  l.EmailSentDate IS NULL
ORDER BY 
ISNULL(EmailSortOrder,999999) 
,EmailDistributionLogId
"
        Dim stdCode As New BusinessLogic.StdCode
        Dim tblRecipients As DataTable = Me.db.GetDataTableFromSQL(sql)
        For Each row As DataRow In tblRecipients.Rows
            Dim strEmailToAddress As String = ""
            Subject = row("EmailSubject")
            Try
                Body = db.IsDBNull(row("EmailBody"), "")
                If Body = "" Then
                    Dim fiTemplate As New IO.FileInfo(IO.Path.Combine(db.GetParameterValue("TermsConditionsDirectoryPhysicalPath"), row("TemplateFileName")))
                    If Not fiTemplate.Exists Then Throw New Exception("Email Template:" & fiTemplate.FullName & " can't be found")

                    Body = stdCode.GetFileText(fiTemplate.FullName)

                Else
                    If db.IsDBNull(row("TemplateFileName"), "") <> "" Then
                        Throw New Exception("Both EmailBody and TemplateFileName have been entered in the EmailDistributionLog row for EmailDistributionLogId:" & row("EmailDistributionLogId") & ". one must be blank")
                    End If
                End If
                For Each col As DataColumn In tblRecipients.Columns
                    If Not db.IsDBNull(row(col.ColumnName)) Then Body = Body.Replace("{{" & col.ColumnName & "}}", row(col.ColumnName))
                Next
                If db.IsDBNull(row("EmailAddress"), "") = "" Then
                    Throw New Exception("Email Address Blank for EmailDistributionLogId:" & row("EmailDistributionLogId"))
                End If
                strEmailToAddress = row("EmailAddress")
                Dim email As New BusinessLogic.Email(db)
                If Not Me.db.IsOnLiveServer Then
                    Dim TestEmail As String = ""
                    Try
                        TestEmail = db.GetParameterValue("PEPRenewalEmailTestToAddress")
                    Catch ex As Exception
                        TestEmail = "Support@zedra.co.uk"
                    End Try
                    strEmailToAddress = strEmailToAddress.Substring(0, strEmailToAddress.IndexOf("@")) & TestEmail.Substring(TestEmail.IndexOf("@"), TestEmail.Length - TestEmail.IndexOf("@"))
                End If
                email.SendTo = strEmailToAddress
                email.From = EmailFromAccount
                email.Subject = row("EmailSubject")
                email.Body = Body
                email.Send()
                sql = "
                        UPDATE EmailDistributionLog
                        SET EmailSentDate = GETDATE()
                            ,EmailDistributionStatus = 'Successfull'
                            ,EmailFromAccount = @EmailFromAccount
                            ,EmailBody = @EmailBody
                            ,BatchLogId = " & Me.BatchLog.BatchLogId & "
                        WHERE EmailDistributionLogId = " & row("EmailDistributionLogId")
                Dim cmd As New SqlClient.SqlCommand(sql, db.DBConnection, db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailFromAccount", System.Data.SqlDbType.VarChar, 100, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , EmailFromAccount))
                cmd.Parameters.Add("@EmailBody", System.Data.SqlDbType.VarChar, 8000).Value = Body
                cmd.ExecuteNonQuery()

                BatchLog.Update(row("EmailFooterSystemText") & " sent.")
                SentEmailsCount += 1

            Catch ex As Exception
                Dim msg As String = ""
                sql = "
                        UPDATE EmailDistributionLog
                        SET EmailDistributionStatus = 'Failed'
                            ,ExtraInfo = @ExtraInfo
                        WHERE EmailDistributionLogId = " & row("EmailDistributionLogId")
                Dim cmd As New SqlClient.SqlCommand(sql, db.DBConnection, db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ExtraInfo", System.Data.SqlDbType.VarChar, 8000, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , ex.Message & Environment.NewLine & db.IsDBNull(row("ExtraInfo"), "")))
                cmd.ExecuteNonQuery()
                BatchLog.Update(strEmailToAddress & " failed:" & ex.Message)
            End Try


        Next
        BatchLog.Update("===================")
        BatchLog.Update("Emails successfully sent in this batch:" & SentEmailsCount)
        BatchLog.Update("===================")

        sql = "
SELECT 
EmailDistributionStatus
,NoOfEmails = count(*)
FROM EmailDistributionLog l
WHERE l.EmailName = '" & Me.EmailName & "'
GROUP BY EmailDistributionStatus
ORDER BY EmailDistributionStatus
"
        Dim tResults As DataTable = db.GetDataTableFromSQL(sql)
        Dim totalCount As Integer = 0
        For Each r As DataRow In tResults.Rows
            BatchLog.Update(r("EmailDistributionStatus") & ":" & CInt(r("NoOfEmails")).ToString("#,##0"))
            totalCount += r("NoOfEmails")
        Next
        BatchLog.Update("Total:" & totalCount.ToString("#,##0"))
        BatchLog.Update("===================")
        If tblRecipients.Rows.Count = NoOfEmailsInBatch Then
            '2/8/22 Don't start another job unless there were some processed in this 
            Dim EmailMinutesTilNextBatchJob As Integer = db.GetParameterValue("EmailMinutesTilNextBatchJob", 15)
            BatchLog.Update("Email distribution stopped as a batch of:" & SentEmailsCount & " have been processed has reached the batch limit.  A new job will start in " & EmailMinutesTilNextBatchJob & " minutes.")
            Me.Submit(EmailFromAccount:=EmailFromAccount, NoOfEmailsInBatch:=Me.NoOfEmailsInBatch, EmailName:=EmailName, ScheduledStartDateTime:=Now.AddMinutes(EmailMinutesTilNextBatchJob))
            Exit Sub
        Else
            BatchLog.Update("No More to process:")

        End If
        'must have completed all emails

    End Sub
    Public Function AddToSubscriberEmailToDitributionLog(EmailName As String,
                                        EmailSubject As String,
                                        EmailBody As String,
                                        SendToEmailAddress As String,
                                        SubscriberId As Integer,
                                        CompanyId As Integer,
                                        Optional OrderNumber As Integer = 0,
                                        Optional SalesOrderLineId As Integer = 0,
                                        Optional EmailDistributionStatus As String = "NotSent"
                                        ) As Integer
        Dim sql As String = ""
        Try
            sql = "

INSERT INTO EmailDistributionLog (
		EmailSubject
	  ,EmailDistributionStatus
      ,EmailName
      ,EmailBody
	  ,TemplateFileName
      ,SubscriberId
      ,SubscriberName
      ,FirstName
      ,LastName
      ,EmailAddress
      ,EmailFromAccount
      ,ExtraInfo
	  ,EmailFooterSystemText
      ,OrderNumber
      ,SalesOrderLineId
        ,EmailSentDate
	  )
SELECT 
	  EmailSubject= @EmailSubject
	  ,EmailDistributionStatus=@EmailDistributionStatus
      ,EmailName =  @EmailName
      ,EmailName =  @EmailBody
	  ,TemplateFileName=''
      ,SubsriberId = s.SubscriberId
      ,SubscriberName = s.SubscriberName
      ,FirstName = s.FirstName
      ,LastName = s.LastName
      ,EmailAddress = @SendToEmailAddress
      ,EmailFromAccount = dbo.fn017GetParameter('EmailFromForCompanyId:" & IIf(CompanyId = 0, 2, CompanyId) & "')
	  ,ExtraInfo = '' 
	  ,EmailFooterSystemText = ''
      ,OrderNumber= " & OrderNumber & "
      ,SalesOrderLineId = " & SalesOrderLineId & "
      ,EmailSentDate = " & IIf(EmailDistributionStatus = "Successfull", "GETDATE()", "NULL") & "
FROM Subscriber s
WHERE s.SubscriberId = " & SubscriberId

            Dim cmd As New SqlClient.SqlCommand(sql, db.DBConnection, db.DBTransaction)
            cmd.Parameters.Add("@EmailSubject", System.Data.SqlDbType.VarChar, 500).Value = EmailSubject
            cmd.Parameters.Add("@EmailDistributionStatus", System.Data.SqlDbType.VarChar, 20).Value = EmailDistributionStatus
            cmd.Parameters.Add("@EmailName", System.Data.SqlDbType.VarChar, 500).Value = EmailName
            cmd.Parameters.Add("@EmailBody", System.Data.SqlDbType.VarChar, -1).Value = EmailBody
            cmd.Parameters.Add("@SendToEmailAddress", System.Data.SqlDbType.VarChar, 200).Value = SendToEmailAddress
            cmd.ExecuteNonQuery()
            Return CInt(db.DLookup("MAX(EmailDistributionLogId)", "EmailDistributionLog", "SubscriberId=" & SubscriberId))
        Catch ex As Exception
            Throw New Exception("AddToSubscriberEmailForDitribution Failed:" & ex.Message)
        End Try
    End Function
    Public Sub UpdateStatus(EmailDistributionLogId As Integer, EmailDistributionStatus As String)

    End Sub
End Class
