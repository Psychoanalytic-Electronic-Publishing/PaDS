﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Text

Public Class BatchJob
    'Modifications
    '=============
    'Oct 08     James Woosnam   Initial Version
    '24/03/20	Julian Gates    SIR5049 - Add ReBuildPaDSTableIndexes

#Region "Class Properties"
    Dim StdCode As New BusinessLogic.StdCode
    Dim ErrorEmailSent As Boolean = False
    Private _RegistryKey As String
    Public Parameters As New BatchJobParameters
    Public BatchJobId As Integer = Nothing
    Public Property RegistryKey() As String
        Get
            Return _RegistryKey
        End Get
        Set(ByVal Value As String)
            If Value = "" Then
                Throw New Exception("No Registry key passed to BatchControl")
            End If
            _RegistryKey = Value
        End Set
    End Property
    Private _dbBatchControl As BusinessLogic.Database = Nothing
    Private Property dbBatchControl() As BusinessLogic.Database
        Get
            Return (Me._dbBatchControl)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._dbBatchControl = value
        End Set
    End Property
    Dim _ScheduledStartDateTime As Date = Nothing
    Public Property ScheduledStartDateTime() As Date
        Get
            If Me._ScheduledStartDateTime = Nothing Then
                Me._ScheduledStartDateTime = Now
            End If
            Return _ScheduledStartDateTime
        End Get
        Set(ByVal Value As Date)
            _ScheduledStartDateTime = Value
        End Set
    End Property
    Private _ReScheduleDelaySeconds As Integer = 0
    Public Property ReScheduleDelaySeconds() As Integer
        Get
            Return _ReScheduleDelaySeconds
        End Get
        Set(ByVal Value As Integer)
            _ReScheduleDelaySeconds = Value
        End Set
    End Property
    Private _ReScheduleFrom As String = "End"
    Public Property ReScheduleFrom() As String
        Get
            Return _ReScheduleFrom
        End Get
        Set(ByVal Value As String)
            _ReScheduleFrom = Value
        End Set
    End Property
    Public Property ProcessToPerform() As String
        Get
            Return Me.Parameters.GetValue("ProcessToPerform")
        End Get
        Set(ByVal Value As String)
            Me.Parameters.Add("ProcessToPerform", Value)
        End Set
    End Property
    Public SubmittedByUserSessionId As Guid = Nothing
#End Region

    Public Sub New(ByVal RegistryKey As String)
        Me.RegistryKey = RegistryKey
        Me.dbBatchControl = New BusinessLogic.Database(StdCode.ReadRegValue(Microsoft.Win32.RegistryHive.LocalMachine, Me.RegistryKey, "BatchControlConnection", ""))

    End Sub
    Public Sub New(ByVal dbApplication As BusinessLogic.Database)
        Try
            Me.RegistryKey = dbApplication.GetParameterValue("ServiceRegistryKey")
        Catch ex As Exception
            Throw ex
        End Try
        '6/2/11     James Wosonam   For PaDS the dbBatchControl is always the application database
        Me.dbBatchControl = dbApplication

    End Sub

    Private Sub ProcessJob(ByRef BatchJobStatus As String, ByVal dbProccess As BusinessLogic.Database)
        'Use paramters from the file to do whatever is requried
        Try
            Dim processToPerform As String = Me.Parameters.GetValue("ProcessToPerform")
            Dim db As New Database(CStr(Me.Parameters.GetValue("ConnectionString")))
            If Me.Parameters.Parameters.Rows.Find({"SecondaryConnectionString"}) IsNot Nothing Then db.SecondaryConnectionString = Me.Parameters.GetValue("SecondaryConnectionString")
            Try
                Select Case processToPerform

                    Case "MaskCashbookCreditAndBankFields"
                        Dim BatchLog As BatchLog = Nothing
                        Try
                            Dim cmd As New SqlClient.SqlCommand("sp009MaskCashbookCreditAndBankFields", db.DBConnection, db.DBTransaction)
                            cmd.CommandType = CommandType.StoredProcedure
                            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RecordsUpdated", System.Data.SqlDbType.Int, 0, System.Data.ParameterDirection.Output, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current _
                                                                             , 0))
                            cmd.ExecuteNonQuery()
                            Dim RecordsUpdated As Integer = Nothing
                            RecordsUpdated = cmd.Parameters("@RecordsUpdated").Value

                            If RecordsUpdated <> Nothing Then
                                'only write batch log if something changed
                                BatchLog = New BatchLog("MaskCashbookCreditAndBankFields", "Payment card and bank field masking", db)
                                BatchLog.Update(RecordsUpdated & " records updated", "Complete")
                            End If


                        Catch ex As Exception
                            BatchLog = New BatchLog("MaskCashbookCreditAndBankFields", "MaskCashbookCreditAndBankFields", db)
                            BatchLog.Update("MaskCashbookCreditAndBankFields Failed:" & ex.ToString, "Failed")
                            Throw New Exception("MaskCashbookCreditAndBankFields Failed:" & ex.ToString)
                        End Try
                    Case "SendRenewalEmail"
                        Dim SendRenewalEmail As New BusinessLogic.SendRenewalEmail("SendRenewalEmail", db)
                        SendRenewalEmail.Execute(Me.BatchJobId, Me.Parameters)
                    Case "RunReportGeneric"
                        Dim Report As New BusinessLogic.ReportGeneric(CStr(Me.Parameters.GetValue("ReportName")), CStr(Me.Parameters.GetValue("ReportType")), db, New Guid(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId"))))
                        Report.Execute(Me.BatchJobId, Me.Parameters)
                    Case "RunReportSpreadsheetGearExcel"
                        Select Case Me.Parameters.GetValue("ReportName")
                            Case "GroupedSales"
                                Dim rep As New ReportGroupedSales(db, New Guid(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId"))))
                                rep.Execute(Me.BatchJobId, Me.Parameters)
                            Case "AgedDebtor"
                                Dim rep As New ReportAgedDebtor(db, New Guid(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId"))))
                                rep.Execute(Me.BatchJobId, Me.Parameters)
                            Case "FixedCashbook"
                                Dim rep As New ReportFixedCashbook(db, New Guid(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId"))))
                                rep.Execute(Me.BatchJobId, Me.Parameters)
                            Case "ProductSubscriptions"
                                Dim rep As New ReportProductSubscriptions(db, New Guid(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId"))))
                                rep.Execute(Me.BatchJobId, Me.Parameters)
                            Case "SubscriberRenewal"
                                Dim rep As New ReportSubscriberRenewal(db, New Guid(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId"))))
                                rep.Execute(Me.BatchJobId, Me.Parameters)
                            Case Else
                                Throw New Exception("Doing RunReportSpreadsheetGearExcel ReportName:" & Me.Parameters.GetValue("ReportName") & " not known")
                        End Select
                    Case "DespatchSalesOrder"
                        Dim UserSession As New BusinessLogic.UserSession(db)
                        UserSession.Restore(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId")))
                        '21/1/21    James Woosnam   Add SecondaryConnectionString as it is needed for writing secondary audit log
                        db.SecondaryConnectionString = CStr(Me.Parameters.GetValue("SecondaryConnectionString"))
                        Dim SalesOrder As New BusinessLogic.SalesOrder(db, UserSession)
                        SalesOrder.ExecuteDespatchSalesOrder(Me.BatchJobId, Me.Parameters)
                    Case "AddBankDepositFromCashbookIds"
                        Dim UserSession As New BusinessLogic.UserSession(db)
                        db.SecondaryConnectionString = CStr(Me.Parameters.GetValue("SecondaryConnectionString"))
                        UserSession.Restore(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId")))
                        Dim BankDeposit As New BusinessLogic.BankDeposit(db, UserSession)
                        BankDeposit.ExecuteAddFromCashbookIds(Me.BatchJobId, Me.Parameters)
                    Case "DeleteOldRedundantAddresses"
                        Dim Subscriber As New BusinessLogic.Subscriber(db)
                        Subscriber.DeleteOldRedundantAddresses()
                    Case "DeleteFile"
                        Try
                            If System.IO.File.Exists(CStr(Me.Parameters.GetValue("FileName"))) Then
                                System.IO.File.Delete(CStr(Me.Parameters.GetValue("FileName")))
                            End If
                        Catch ex As Exception
                            Throw New Exception("File delete failed:" & ex.Message)
                        End Try
                    Case "CopyPaDSDatabaseToSecondary"
                        Dim utils As New BusinessLogic.PaDSSupportUtilities(db)
                        utils.CopyPaDSDatabaseToSecondary(Me.BatchJobId, Me.Parameters)
                    Case "RunAuditAndCleanUpJobs"
                        '5/12/19    James Woosnam   SIR4769 - Add RunAuditAndCleanUpJobs
                        Dim utils As New BusinessLogic.PaDSSupportUtilities(db)
                        utils.RunAuditAndCleanUpJobs(Me.BatchJobId)
                    Case "CheckFreeDiskSpace"
                        '14/01/20    Julian Gates   Add CheckFreeDiskSpace
                        '1/4/21     James Woosnam   Put into PaDSSupportUtilities class
                        Dim utils As New BusinessLogic.PaDSSupportUtilities(db)
                        utils.CheckFreeDiskSpace(Me.BatchJobId, Me.Parameters)
                    Case "ReBuildPaDSTableIndexes"
                        '24/03/20	Julian Gates SIR5049 - Add ReBuildPaDSTableIndexes
                        Dim utils As New BusinessLogic.PaDSSupportUtilities(db)
                        utils.ReBuildPaDSTableIndexes(Me.BatchJobId, Me.Parameters)
                    Case "RepopulateAllPEPWebContent"
                        Dim pwc As New BusinessLogic.PEPwebContent(db)
                        pwc.ExecuteRepopulateAllPEPWebContent(Me.BatchJobId, Me.Parameters)
                    Case "GetPEPWebSessionLog"
                        Dim UserSession As BusinessLogic.UserSession = Nothing
                        Try
                            UserSession = New BusinessLogic.UserSession(db)
                            UserSession.Restore(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId")))
                        Catch ex As Exception
                        End Try
                        Dim pwc As New BusinessLogic.PEPwebContent(db, UserSession)
                        pwc.ExecuteGetPEPWebSessionLog(Me.BatchJobId, Me.Parameters)
                    Case "PopulateUserActivityLog"
                        Dim UserSession As BusinessLogic.UserSession = Nothing
                        Try
                            UserSession = New BusinessLogic.UserSession(db)
                            UserSession.Restore(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId")))
                        Catch ex As Exception
                        End Try
                        Dim pwc As New BusinessLogic.PEPwebContent(db, UserSession)
                        pwc.PopulateUserActivityLog(Me.BatchJobId, Me.Parameters)
                    Case "ResetPadsTestData"
                        db.SecondaryConnectionString = CStr(Me.Parameters.GetValue("SecondaryConnectionString"))

                        Dim pt As New BusinessLogic.PaDSTesting(db, db.DBConnectionString)
                        pt.ResetTestData(db.GetParameterValue("TestUserPassword"), True)
                    Case "SendDistributionEmails"
                        '12/9/21    James Woosnam   SIR5313 - Handle SendDistributionEmails
                        db.SecondaryConnectionString = CStr(Me.Parameters.GetValue("SecondaryConnectionString"))
                        Dim UserSession As BusinessLogic.UserSession = Nothing
                        Try
                            UserSession = New BusinessLogic.UserSession(db)
                            UserSession.Restore(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId")))
                        Catch ex As Exception
                        End Try
                        Dim em As New BusinessLogic.Emailing(db, UserSession)
                        em.Execute(Me.BatchJobId, Me.Parameters)
                    Case "PopulatePEPUsage"
                        '28/9/21    James Woosnam   SIR5325 - Handle PopulatePEPUsage
                        Dim UserSession As BusinessLogic.UserSession = Nothing
                        Try
                            UserSession = New BusinessLogic.UserSession(db)
                            UserSession.Restore(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId")))
                        Catch ex As Exception
                        End Try
                        Dim rpu As New BusinessLogic.ReportPEPUsage(db, UserSession.UserSessionIdGUID)
                        rpu.ExecutePopulatePEPUsage(Me.BatchJobId, Me.Parameters)
                    Case "ActionSubscriberImportBatch"
                        Dim UserSession As BusinessLogic.UserSession = Nothing
                        Try
                            UserSession = New BusinessLogic.UserSession(db)
                            UserSession.Restore(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId")))
                        Catch ex As Exception
                        End Try
                        Dim sib As New BusinessLogic.SubscriberImportBatch(Me.Parameters.GetValue("SubscriberImportBatchId"), db, UserSession)
                        sib.ExecuteActionSubscriberImportBatch(Me.BatchJobId, Me.Parameters)
                    Case "PEPUsageReport"
                        '28/9/21    James Woosnam   SIR5325 - Handle PopulatePEPUsage
                        Dim UserSession As BusinessLogic.UserSession = Nothing
                        Try
                            UserSession = New BusinessLogic.UserSession(db)
                            UserSession.Restore(CStr(Me.Parameters.GetValue("SubmittedByUserSessionId")))
                        Catch ex As Exception
                        End Try
                        Dim rpu As New BusinessLogic.ReportPEPUsage(db, UserSession.UserSessionIdGUID)
                        rpu.Execute(Me.BatchJobId, Me.Parameters)
                    Case Else
                        Throw New Exception("Process:" & processToPerform & " is not handled")
                End Select
            Catch ex As Exception
                Throw ex
            Finally
                If db.DBConnection.State = ConnectionState.Open Then
                    Try
                        db.DBConnection.Close()
                    Catch ex As Exception
                    End Try
                End If
            End Try
            BatchJobStatus = "Completed"
            AddToLog("****************************** END " & processToPerform & " *********************************")
        Catch ex As Exception
            BatchJobStatus = "Failed"
            AddToLog("Process Failed" & vbCrLf & ex.ToString)
            Me.SendErrorEmail(ex.ToString, dbProccess)
            Throw ex
        End Try

    End Sub

    Public Sub CreateBatchJobEntry(ByVal ProcessToPerform As String, ByVal dbApplication As BusinessLogic.Database)
        Me.ProcessToPerform = ProcessToPerform
        Me.Parameters.Add("ConnectionString", dbApplication.DBConnectionString)
        Me.CreateBatchJobEntry()
    End Sub

    Public Sub CreateBatchJobEntry()
        Try

            'Create a dataadapter and table to insert with
            '31/1/22    James Woosnam   Add DBtransaction go dtaadaptor
            Dim cmd As New SqlClient.SqlCommand("Select * from BatchJob WHERE 1=2", dbBatchControl.DBConnection, dbBatchControl.DBTransaction)
            Dim daBatchJob As New SqlClient.SqlDataAdapter(cmd)
            Dim tableBatchJob As New DataTable
            daBatchJob.Fill(tableBatchJob)

            'Use the command builder to get the insert command
            Dim cmdBuilder As New SqlClient.SqlCommandBuilder(daBatchJob)
            daBatchJob.InsertCommand = cmdBuilder.GetInsertCommand

            'Add and populate the new row
            Dim newRow As DataRow = tableBatchJob.NewRow
            newRow("BatchJobId") = Me.dbBatchControl.DLookup("ISNULL(MAX(BatchJobId),1) + 1", "BatchJob", "")
            Me.BatchJobId = newRow("BatchJobId")
            newRow("BatchJobName") = Me.ProcessToPerform
            newRow("BatchJobStatus") = "Pending"
            newRow("ScheduledStartDateTime") = Me.ScheduledStartDateTime
            newRow("CreatedDateTime") = Now()
            newRow("ReScheduleDelaySeconds") = Me.ReScheduleDelaySeconds
            newRow("ReScheduleFrom") = Me.ReScheduleFrom
            If Not Me.SubmittedByUserSessionId = Nothing Then
                newRow("SubmittedByUserSessionId") = SubmittedByUserSessionId
                Me.Parameters.Add("SubmittedByUserSessionId", SubmittedByUserSessionId.ToString)
            End If
            If Me.Parameters.Parameters.Rows.Find({"SecondaryConnectionString"}) Is Nothing Then Me.Parameters.Add("SecondaryConnectionString", dbBatchControl.SecondaryConnectionString)  '5/7/21    SecondaryConnectionString is needed more and more often so add it always

            newRow("XMLParameters") = GetParameterXMLString(newRow("BatchJobId"))
            tableBatchJob.Rows.Add(newRow)
            'Update the database
            daBatchJob.Update(tableBatchJob)


        Catch ex As Exception
            Throw New Exception("Failed to Write BatchJob:" & ex.Message, ex)
        Finally
        End Try
    End Sub
    Public Sub SendErrorEmail(ByVal ErrorMessage As String, ByVal dbProcess As BusinessLogic.Database)
        'dbProcess could be received as Nothing and the email should still be sent
        Dim stdCde As New BusinessLogic.StdCode
        Try
            Dim Email As BusinessLogic.Email
            Try
                'If doesn't work with process then try without
                Email = New BusinessLogic.Email(dbProcess)
            Catch ex As Exception
                Email = New BusinessLogic.Email()
            End Try
            'Dim mail As New System.Web.Mail.MailMessage
            Dim subject As String
            Dim body As String = ""
            subject = "Error in PaDS Batch Control"
            body += ErrorMessage
            Dim logFileName As String = ""
            Try
                'Try and add some of the batch log as an attachment
                Dim sql As String = ""
                sql += "SELECT TOP 100 BatchLog.BatchLogId"
                sql += "		,BatchLog.BatchLogType"
                sql += "		,BatchLog.Description"
                sql += "		,BatchLog.BatchLogStatus"
                sql += "		,StartedDate = BatchLog.DateTime"
                sql += "		,LineDateTime = BatchLogLine.DateTime"
                sql += "		,BatchLogLineText"
                sql += " FROM BatchLog"
                sql += "	INNER JOIN BatchLogLine"
                sql += "	ON BatchLogLine.BatchLogId = BatchLog.BatchLogid"
                sql += " ORDER BY BatchLog.BatchLogId Desc , BatchLogLine.DateTime ASC"
                Dim logTable As DataTable = Me.dbBatchControl.GetDataTableFromSQL(sql)
                logFileName = stdCde.ReadRegValue(Microsoft.Win32.RegistryHive.LocalMachine, Me.RegistryKey, "LogDir", "") _
                                            & "BatchLog.csv"

                stdCde.ExportDataTableAsCSV(logTable, logFileName)
            Catch ex As Exception
                Me.AddToLog("Add BatchLog to Eamil Failed:" & ex.ToString)
            End Try
            Try
                'try and add the log file as an attachment
                logFileName = stdCde.ReadRegValue(Microsoft.Win32.RegistryHive.LocalMachine, Me.RegistryKey, "LogDir", "") _
                                            & "ServerSideLog" & Format(Now(), "yyyy-MM-dd") & ".txt"
            Catch ex As Exception
                Me.AddToLog("Add Log File to Eamil Failed:" & ex.ToString)
            End Try
            Email.SendErrorEmail(subject, body, logFileName)
            ErrorEmailSent = True
            Me.AddToLog("Error Email Sent")
            Me.AddToLog("Error Email Sent From:" & Email.MailMessage.From.Address)
            Me.AddToLog("Error Email Sent to:" & Email.SendTo)
        Catch ex As Exception
            Me.AddToLog("Send Error Email Failed:" & ex.ToString)
        End Try

    End Sub
    Public Sub ProcessNextBatchJob()
        Dim dbProcess As BusinessLogic.Database = Nothing

        Try
            Dim SQLCmd As String = Nothing
            '22/3/18    James Woosnam   Allow all jobs to run in parrallel, sql below only allows one BatchJobName to be started in each 30 miuntes, 30 mins allows for jobs being left as started
            SQLCmd = "
                SELECT top 1
                * 
                FROM BatchJob 
                WHERE BatchJobStatus = 'Pending' 
                AND ScheduledStartDateTime <= GETDATE()
                AND BatchJobName NOT IN (SELECT b2.BatchJobName FROM BatchJob b2 WHERE b2.BatchJobStatus = 'Started' AND b2.ActualStartDateTime  > DATEADD(MINUTE,-30,GETDATE()))
                ORDER BY BatchJobId
                "
            Dim da As New SqlDataAdapter(SQLCmd, Me.dbBatchControl.DBConnection)
            Dim batchJobTable As New DataTable
            da.Fill(batchJobTable)
            If batchJobTable.Rows.Count = 0 Then
                '  AddToLog("No Jobs to process.")
                Exit Sub
            End If
            Dim row As DataRow = batchJobTable.Rows(0)
            Me.BatchJobId = row("BatchJobId")
            Dim cmdBldAddress As SqlClient.SqlCommandBuilder = New System.Data.SqlClient.SqlCommandBuilder(da)
            da.UpdateCommand = cmdBldAddress.GetUpdateCommand()
            Dim BatchJobStatus As String
            BatchJobStatus = row("BatchJobStatus")

            Me.Parameters.ParameterDataset = GetParameterDatasetFromXMLString(row("XMLParameters"), row("BatchJobId"))


            row("ActualStartDateTime") = Now()
            row("BatchJobStatus") = "Started"

            If row("ReScheduleFrom") = "Start" _
            And row("ReScheduleDelaySeconds") <> 0 Then
                ReSchedlueJob(row)
            End If
            'Don't update the batchjob table to started until after schedulling the next job, just in case the ReSchedlueJob failes
            da.Update(batchJobTable)

            Try
                AddToLog("****************************** Start " & row("BatchJobName") & " *********************************")
                'Show values in the log
                AddToLog("Parameter Values in:'" & row("BatchJobName") & "'")
                For Each rowParam As DataRow In Parameters.Parameters.Rows
                    AddToLog(rowParam.Item("ParameterName") & "=" & rowParam.Item("ParameterValue"))
                Next
                Try
                    dbProcess = New BusinessLogic.Database(CStr(Parameters.GetValue("ConnectionString")))
                Catch ex As Exception
                    BatchJobStatus = "Failed"
                    Throw ex
                End Try
                Try
                    AddToLog("Opened DBConnection:" & dbProcess.DBConnection.ConnectionString)
                    'NOW PROCESS the JOB
                    Me.ProcessJob(BatchJobStatus, dbProcess)

                Catch ex As Exception
                    Throw ex
                Finally
                    dbProcess.DBConnection.Close()
                End Try

            Catch ex As Exception
                AddToLog(ex.ToString)
                BatchJobStatus = "Failed"
                Throw ex
            Finally
                row("EndDateTime") = Now()
                row("BatchJobStatus") = BatchJobStatus
                da.Update(batchJobTable)
                If row("ReScheduleFrom") = "End" _
                And row("ReScheduleDelaySeconds") <> 0 Then
                    ReSchedlueJob(row)
                End If
            End Try

        Catch ex As Exception
            If Not ErrorEmailSent Then
                Try
                    'don't care if email failes, email failer reason should be in log
                    Me.SendErrorEmail("Failed in ProcessBatch." & vbCrLf & ex.ToString, dbProcess)
                Catch ex1 As Exception
                End Try
            End If
            AddToLog("Failed in ProcessBatch." & vbCrLf & ex.ToString)
            Throw New Exception("Failed in ProcessBatch." & vbCrLf & ex.ToString)
        Finally
            Me.dbBatchControl.DBConnection.Close()
        End Try

    End Sub
    Sub ReSchedlueJob(ByVal BatchJobRow As DataRow)
        'Re-schedules the job
        Dim newBatchJob As New BusinessLogic.BatchJob(Me.RegistryKey)
        'newBatchJob.ProcessToPerform = Me.Parameters.GetValue("ProcessToPerform")
        For Each paramRow As DataRow In Me.Parameters.Parameters.Rows
            newBatchJob.Parameters.Add(paramRow("ParameterName"), New Database().IsDBNull(paramRow("ParameterValue"), ""))
        Next
        newBatchJob.ReScheduleFrom = BatchJobRow("ReScheduleFrom")
        newBatchJob.ReScheduleDelaySeconds = BatchJobRow("ReScheduleDelaySeconds")
        '5/1/05 James Woosnam   For ReScheduleFrom Start to be from the actual start + Delay
        '11/4/06    James Woosnam   Make sure rescheduled start time is after Now SIR433
        '16/5/06    James Woosnam   Stop Reschedule loop join infinaate in ReSchedule Job
        newBatchJob.ScheduledStartDateTime = CDate(BatchJobRow("ScheduledStartDateTime"))
        Do
            Select Case BatchJobRow("ReScheduleFrom")
                Case "Start"
                    newBatchJob.ScheduledStartDateTime = newBatchJob.ScheduledStartDateTime.AddSeconds(BatchJobRow("ReScheduleDelaySeconds"))
                Case Else
                    newBatchJob.ScheduledStartDateTime = Now().AddSeconds(BatchJobRow("ReScheduleDelaySeconds"))
            End Select
        Loop Until newBatchJob.ScheduledStartDateTime >= Now
        newBatchJob.CreateBatchJobEntry()
    End Sub
    Private Sub AddToLog(ByVal strErrorMessage As String)  '
        '*******************************************************************************************
        'Purpose:   Add a log message
        '*******************************************************************************************

        Dim msgText As String = Format(Now(), "HH:mm:ss") & " - " & strErrorMessage
        Dim directoryName As String = StdCode.ReadRegValue(Microsoft.Win32.RegistryHive.LocalMachine, Me.RegistryKey, "LogDir", "")
        If Not Directory.Exists(directoryName) Then
            Directory.CreateDirectory(directoryName)
        End If
        Dim fileName As String = directoryName & "ControlLog" & Format(Now(), "yyyy-MM-dd") & ".txt"
        Dim logFile As StreamWriter = New StreamWriter(fileName, True)
        Try
            logFile.WriteLine(msgText)
        Catch ex As Exception
        Finally
            logFile.Close()
        End Try

    End Sub

    Private Function GetParameterFileName(ByVal BatchLogId As Integer) As String
        Dim dir As String = StdCode.ReadRegValue(Microsoft.Win32.RegistryHive.LocalMachine, Me.RegistryKey, "LogDir", "") & "Params\"
        If Not IO.Directory.Exists(dir) Then
            IO.Directory.CreateDirectory(dir)
        End If
        Return dir & "Params" & BatchLogId & ".xml"
    End Function
    Private Function GetParameterXMLString(ByVal BatchJobId As Integer) As String

        Dim sbXML As New StringBuilder()

        sbXML.Append("<?xml version='1.0' standalone='yes'?>")
        sbXML.Append(Me.Parameters.ParameterDataset.GetXml())

        Return sbXML.ToString()

    End Function
    Private Function GetParameterDatasetFromXMLString(ByVal XMLString As String, ByVal BatchJobId As Integer) As DataSet
        Dim ds As New DataSet
        Dim sr As New System.IO.StringReader(XMLString)

        ds.ReadXml(sr)

        sr.Close()

        Return ds

    End Function



End Class

Public Class BatchJobParameters
    Public Sub New()

    End Sub
    Dim _ParameterDataset As New DataSet
    Public Property ParameterDataset() As DataSet
        Get
            Return Me._ParameterDataset
        End Get
        Set(ByVal value As DataSet)
            Me._ParameterDataset = value
            Dim keyFields() As System.Data.DataColumn = {Me._ParameterDataset.Tables("Parameters").Columns("ParameterName")}
            Me._ParameterDataset.Tables("Parameters").PrimaryKey = keyFields

        End Set
    End Property
    '  Dim _Parameters As DataTable = Nothing
    Public Property Parameters() As DataTable
        Get
            If Me._ParameterDataset.Tables("Parameters") Is Nothing Then
                Dim tbl As New DataTable
                tbl.TableName = "Parameters"
                Dim col As DataColumn
                Dim dt As System.Type
                dt = System.Type.GetType("System.String")

                col = New DataColumn("ParameterName", dt)
                tbl.Columns.Add(col)

                col = New DataColumn("ParameterValue", dt)
                tbl.Columns.Add(col)
                Dim keyFields() As System.Data.DataColumn = {tbl.Columns("ParameterName")}
                tbl.PrimaryKey = keyFields
                tbl.TableName = "Parameters"
                Me._ParameterDataset.Tables.Add(tbl)
            End If
            Return Me._ParameterDataset.Tables("Parameters")
        End Get
        Set(ByVal value As DataTable)
            If Not Me._ParameterDataset.Tables("Parameters") Is Nothing Then
                Me._ParameterDataset.Tables.Remove("Parameters")
            End If
            Me._ParameterDataset.Tables.Add(value)
            Dim keyFields() As System.Data.DataColumn = {Me._ParameterDataset.Tables("Parameters").Columns("ParameterName")}
            Me._ParameterDataset.Tables("Parameters").PrimaryKey = keyFields
        End Set
    End Property
    Public Sub Add(ByVal ParameterName As String, ByVal ParameterValue As String)

        Dim newRow As DataRow = Parameters.NewRow
        newRow.Item("ParameterName") = ParameterName
        newRow.Item("ParameterValue") = ParameterValue
        Parameters.Rows.Add(newRow)

    End Sub
    Public Sub AddTable(ByVal tbl As DataTable)
        If tbl.TableName Is Nothing Then
            Throw New Exception("Datatable added to parameters must have a name")
        End If
        Me._ParameterDataset.Tables.Add(tbl)
    End Sub
    Public Function GetTable(ByVal TableName As String) As DataTable
        If Me._ParameterDataset.Tables(TableName) Is Nothing Then
            Throw New Exception("Table '" & TableName & "' does not exist in Parameters dataset.")
        End If
        Return Me._ParameterDataset.Tables(TableName)
    End Function
    Public Sub Update(ByVal ParameterName As String, ByVal ParameterValue As String)
        '19/10/05   James Woosnam   Add updated parameter method

        Dim parameterFound As Boolean = False
        For Each row As DataRow In Parameters.Rows
            If row("ParameterName") = ParameterName Then
                row("ParameterValue") = ParameterValue
                parameterFound = True
                Exit For
            End If
        Next
        If Not parameterFound Then
            Throw New Exception("Paremeter:'" & ParameterName & "' not found")
        End If

    End Sub
    Function GetValue(ByVal ParameterName As String, Optional ValueIfNotFound As String = Nothing) As Object
        '14/12/21   James Woosnam   Add ValueIfNotFound for a default value if parameter not found
        Try
            Dim paramterRow As DataRow = Me.Parameters.Rows.Find(ParameterName)
            If paramterRow Is Nothing Then
                If ValueIfNotFound = Nothing Then Throw New Exception("Paramter:" & ParameterName & " could not be found")
                Return ValueIfNotFound
            Else
                Return paramterRow.Item("ParameterValue")
            End If
        Catch ex As Exception
            Throw New Exception("Error finding Paramter:" & ParameterName)
        End Try
    End Function

End Class