if  exists (select * from sysobjects where id = object_id(N'vwTableDefinitions') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP view vwTableDefinitions
go

CREATE View vwTableDefinitions
AS
--Stored in TFS ZedraOffice SQL
SELECT
*
,IsPrimarySmb = CASE WHEN cols.ISPrimary =1 THEN '*' ElSE '' END
,IsIndexSmb = CASE WHEN cols.IsIndex =1 THEN '#' ElSE '' END
FROM (
	select 
		TableName= t.name
		,t.id
		,ColumnName = c.name
		,ColumnType = c.xtype
		,ColumnLength = c.prec
		,ColumnIsNullable = c.IsNullable
		,ColumnOrder = c.colorder
		,TableDescription = (select Value 
						 FROM ::fn_listextendedproperty (N'MS_Description', 'user', 'dbo', 'table', t.Name, Null,Default))
		,ColumnDescription = (select Value 
						 FROM ::fn_listextendedproperty (N'MS_Description', 'user', 'dbo', 'table', t.Name, 'Column', c.Name))
		,[ISPrimary] = CASE WHEN (select i.object_id 
								from  sys.indexes i
									inner join sys.index_columns ic
									on ic.index_id = i.index_id 
									AND ic.column_id = c.colid
									and ic.object_id = i.object_id 
									and i.is_primary_key = 1
								WHERE i.object_id = c.id

								) IS NULL THEN 0 ELSE 1 END
		,[IsIndex] =  CASE WHEN (SELECT MAX(Id) FROM sysindexkeys WHERE sysindexkeys.Id = t.Id and sysindexkeys.colId = c.colid) IS NULL THEN 0 ELSE 1 END
		,IsRequired = 0
		,IsFK =  CASE WHEN (SELECT MAX(fkey) FROM sysforeignkeys WHERE fkeyId = t.Id and fkey = c.colid) IS NULL THEN 0 ELSE 1 END
		,NumberOfCols = (SELECT MAX(c2.colid) FROM syscolumns c2 where c2.id = t.Id)
		,ColTpDesc = CASE
			WHEN c.xtype IN (56) THEN 'Int' 
			WHEN c.xtype IN (48,52) THEN 'Int(tiny,Small)****' 
			WHEN c.xtype IN (167,231) THEN 'Text(' + CASE WHEN c.prec = -1 THEN 'MAX' ELSE CAST( c.prec   as varchar) END + ')'
			WHEN c.xtype IN (106) THEN 'Num(' + CASE WHEN c.prec = -1 THEN 'MAX' ELSE CAST( c.prec   as varchar) + ',' + CAST( c.scale    as varchar)END + ')'
			WHEN c.xtype IN (35) THEN 'Text(MAX)'
			WHEN c.xtype IN (61) THEN 'DateTime' 
			WHEN c.xtype IN (60) THEN 'Money' 
			WHEN c.xtype IN (59) THEN 'Numeric' 
			WHEN c.xtype IN (104) THEN 'Y/N' 
			WHEN c.xtype IN (239) THEN 'nchar********' 
			WHEN c.xtype IN (165) THEN 'Binary' + CASE WHEN c.prec = -1 THEN '' ELSE '(' + CAST( c.prec   as varchar) + ')' END 
			WHEN c.xtype IN (239) THEN 'nchar********' 
			WHEN c.xtype IN (241) THEN 'Info' 
			ELSE 'tba:' + CAST(c.xtype as varchar) END
	from sysobjects t
		INNER JOIN syscolumns c
		
		on c.id = t.id
	where t.xtype = 'U'
	) Cols


WHERE 1=1
AND (
cols.TableName like '%Content%'
--OR cols.TableName like 'Product'

)


--cols.TableName like '%Place%'
--OR cols.TableName like '%Staff%'
--OR cols.TableName like '%Household%'
--OR cols.TableName like '%Worker%'
--OR cols.TableName like '%team%'
--OR cols.TableName like '%Approval%'
--OR cols.TableName like '%Referral%'
--OR cols.TableName like '%LocalAuthority%'
--OR cols.TableName like '%Staff%'
--OR
--cols.TableName in (
--					'LocalAuthority'
--					,'LocalAuthority'
--					)
--)
--AND left(cols.TableName ,1) <> 'Z'
--AND RIGHT(cols.TableName ,1) <> 'Z'
--AND LEFT(cols.TableName ,4) <> 'stbl'
--AND LEFT(cols.TableName ,3) <> 'sys'
--AND cols.TableName NOT like '%dtproperties%'
--AND cols.TableName NOT like '%TableDefinitions%'
--AND cols.TableName NOT like '%xxx%'
--AND cols.TableName NOT like '%xxx%'
--AND cols.TableName NOT like '%xxx%'
--AND cols.TableName NOT like '%xxx%'
--AND cols.TableName NOT like '%xxx%'
--AND cols.TableName NOT like '%xxx%'
--AND cols.TableName NOT like '%xxx%'
GO


