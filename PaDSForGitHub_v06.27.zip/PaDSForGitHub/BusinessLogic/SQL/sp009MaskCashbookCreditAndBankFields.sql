if exists (select * from dbo.sysobjects where id = object_id(N'sp009MaskCashbookCreditAndBankFields') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp009MaskCashbookCreditAndBankFields
GO

CREATE    PROCEDURE sp009MaskCashbookCreditAndBankFields(@RecordsUpdated INT OUTPUT )
							
AS
-- Procedure 	: sp009MaskCashbookCreditAndBankFields
-- Description	: Masks credit card and bank details for all cashbook items more that have not been updated for 10 minutes for credit card and 1 day for bank details 
--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
DECLARE @Message VARCHAR(1000) = ''
SELECT @RecordsUpdated = ISNULL(@RecordsUpdated,0) 

BEGIN TRY
	UPDATE Cashbook
	SET 
		PaymentCardNumber = CASE WHEN LEN(PaymentCardNumber) > 4 THEN LEFT('xxxxxxxxxxxxxxxxxxxx',len(PaymentCardNumber) - 4) + RIGHT(PaymentCardNumber,4) ELSE PaymentCardNumber END
		,PaymentCardCVNumber = CASE WHEN ISNULL(PaymentCardCVNumber,'') <> '' THEN 'xxx' ELSE PaymentCardCVNumber END
		,Notes = LEFT( ISNULL(Notes,'') + CHAR(13) + CHAR(10) + 'Payment card Number Masked:' + CAST(GETDATE() AS VARCHAR),255)
	WHERE ISNULL(PaymentCardNumber,'') + ISNULL(PaymentCardCVNumber,'')  <> ''
		AND PaymentCardNumber NOT LIKE 'x%'
		AND LEN(PaymentCardNumber) > 4 
		AND LastUpdatedDateTime < DATEADD(MINUTE,-10,GETDATE())
	SELECT @RecordsUpdated = @@ROWCOUNT

	UPDATE Cashbook
	SET 
		BankAccountNumber = CASE WHEN LEN(BankAccountNumber) > 4 THEN LEFT('xxxxxxxxxxxxxxxxxxxx',len(BankAccountNumber) - 4) + RIGHT(BankAccountNumber,4) ELSE BankAccountNumber END
		,Notes = LEFT(ISNULL(Notes,'') + CHAR(13) + CHAR(10) + 'Bank Number Masked:' + CAST(GETDATE() AS VARCHAR),255)
	WHERE ISNULL(BankAccountNumber,'') <> ''
		AND BankAccountNumber NOT LIKE 'x%'
		AND LEN(BankAccountNumber) > 4 
		AND LastUpdatedDateTime < DATEADD(DAY,-1,GETDATE())
	SELECT @RecordsUpdated += @@ROWCOUNT


END TRY
BEGIN CATCH
	SELECT @Message = 'sp009MaskCashbookCreditAndBankFields failed: ' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE()
	
	RAISERROR ('%s', 18, 1,@Message)

END CATCH

go 