begin tran

select 
	ru.UserId 
	,ru.UserName 
	,ru.UserFullName 
	,PEPWebClientSettings 
	,NewSettings = REPLACE(PEPWebClientSettings,'"visibleWidgets": [','"visibleWidgets": [      "whoCitedThis",')
INTO #UserToChange
from RemoteUser ru
where ru.UserStatus in ('Active','Emailed')
and ru.AuthorityLevel = 'IndividualSubscriber'
and PEPWebClientSettings NOT LIKE '%"whoCitedThis"%'
and isnull(PEPWebClientSettings ,'') <> ''
and len(PEPWebClientSettings )>20

--and ru.UserName like 'test%'

SELECT COUNT(*) FROM #UserToChange 
SELECT * FROM #UserToChange 

update RemoteUser 
set PEPWebClientSettings = n.NewSettings 
FROM RemoteUser ru
	INNER JOIN #UserToChange n
	On n.UserId = ru.UserId 

DROP TABLE #UserToChange

rollback tran