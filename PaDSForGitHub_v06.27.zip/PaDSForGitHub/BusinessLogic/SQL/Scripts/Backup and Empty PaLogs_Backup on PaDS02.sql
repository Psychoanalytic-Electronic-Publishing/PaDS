/*
--23/8/22	Added to TFS D:\Projects\PaDS2\PaDS\BusinessLogic\SQL\Scripts\
--23/8/22	James Woosnam	SIR5493 - Compress both the restored copy and the original

12/12/21:Need to run the first bit upto the truncate before running the second.  The DB restore hasn't yet been run successfully, but should be OK next time.
Notes:
- Needs to be run on PaDS02
-Need to make sure Copy to secondary is paused
- PaDS02 will need 25GB free disk space
- The backup file can be deleted when restore complete
*/

DECLARE @Message varchar(max)=''
DECLARE @SQL varchar(max)=''
DECLARE @UpTodate DATETIME = (SELECT MAX(DATE) FROM PaDS_Logs_Backup..SessionLog  )

DECLARE @BackupDBName as VARCHAR(100) = 'PaDS_Logs_BackupUpTo' + FORMAT(@UpToDate,'yyyy_MM_dd_HHssmm')
print  @BackupDBName--PaDS_Logs_BackupUpTo2021_12_12_082200
DECLARE @BackupFileName as VARCHAR(100) = 'C:\Data\MSSQL\Backup\' + @BackupDBName + '.bak'
DECLARE @NewDBFileName as VARCHAR(100) = 'C:\Data\MSSQL\' + @BackupDBName + '.mdf'
DECLARE @NewLogFileName as VARCHAR(100) = 'C:\Data\MSSQL\' + @BackupDBName + '_Log.ldf'
BEGIN TRY

	--BACKUP DATABASE [PaDS_Logs_Backup] TO  DISK = @BackupFileName WITH NOFORMAT, NOINIT,  NAME = N'PaDS_Logs_Backup-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
	SET @SQL = 'BACKUP DATABASE [PaDS_Logs_Backup] TO  DISK = ''' + @BackupFileName + ''' WITH NOFORMAT, NOINIT,  NAME = N''PaDS_Logs_Backup-Full Database Backup'', SKIP, NOREWIND, NOUNLOAD,  STATS = 10'
	print @SQL
	execute(@SQL)
	--RESTORE DATABASE @BackupDBName FROM  DISK = @BackupFileName WITH  FILE = 1,  MOVE 'PaDS_LogsUpTo2021_09_22_1600' TO @NewDBFileName,  MOVE N'PaDS_LogsUpTo2021_09_22_1600_Log' TO @NewLogFileName,  NOUNLOAD,  STATS = 5
	set @SQL = 'RESTORE DATABASE ' + @BackupDBName + ' FROM  DISK = ''' + @BackupFileName + ''' WITH  FILE = 1,  MOVE ''PaDS_LogsUpTo2021_09_22_1600'' TO ''' + @NewDBFileName + ''',  MOVE N''PaDS_LogsUpTo2021_09_22_1600_Log'' TO ''' +  @NewLogFileName + ''',  NOUNLOAD,  STATS = 5'
	print @SQL
	execute(@SQL)
END TRY
BEGIN CATCH
	SELECT @Message = 'DB Backup and Restore failed ' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE()
	RAISERROR ('%s', 18, 1,@Message)
END CATCH

--Part 2
USE PaDS_Logs_Backup
DECLARE @UpTodate DATETIME = (SELECT MAX(DATE) FROM PaDS_Logs_Backup..SessionLog  )

DECLARE @BackupDBName as VARCHAR(100) = 'PaDS_Logs_BackupUpTo' + FORMAT(@UpToDate,'yyyy_MM_dd_HHssmm')


truncate table auditlog
truncate table AuditTableLog
truncate table PEPUsage
truncate table PEPWebSessionLog
truncate table PEPWebUsageLog
truncate table SessionLog
truncate table UserActionLog

DECLARE @SQL varchar(max) = '
set IDENTITY_INSERT AuditLog on
insert into AuditLog (	TableName	
	,AuditDate	
	,UpdatedByUserId	
	,UpdatedByUserName	
	,UpdatedRecordKey	
	,ModificationType	
	,Description	
	,DatabaseName	
	,AuditLogId	) 
select top 1 * from PaDS_LogsUpToDBNAME.dbo.AuditLog x order by x.AuditLogid desc
set IDENTITY_INSERT AuditLog off

set IDENTITY_INSERT AuditTableLog on;insert into AuditTableLog (	AuditTableLogId	
	,ServerName	
	,DatabaseName	
	,TableName	
	,AuditDate	
	,UpdatedByUserId	
	,UpdatedRecordFamily	
	,UpdatedRecordFamilyKey	
	,UpdatedRecordKey	
	,ModificationType	
	,BeforeDescription	
	,AfterDescription	) select top 1 * from PaDS_LogsUpToDBNAME.dbo.AuditTableLog x order by x.AuditTableLogid desc; set IDENTITY_INSERT AuditTableLog off
set IDENTITY_INSERT PEPWebSessionLog on;insert into PEPWebSessionLog (	PEPWebSessionLogId	
	,UserId	
	,UserSessionId	
	,SessionStart	
	,SessionEnd	
	,ItemOfInterest	
	,Endpoint	
	,Params	
	,ReturnStatusCode	
	,ReturnAddedStatusMessage	
	,LastUpdate	
	,SessionActivityId	) select top 1 * from PaDS_LogsUpToDBNAME.dbo.PEPWebSessionLog x order by x.PEPWebSessionLogid desc; set IDENTITY_INSERT PEPWebSessionLog off
set IDENTITY_INSERT PEPWebUsageLog on;insert into PEPWebUsageLog (	PEPWebUsageLogId	
	,DateTime	
	,DatabaseName	
	,ActionType	
	,LogonLocation	
	,LogonStatus	
	,SubscriberId	
	,UserName	
	,OrderNumber	
	,AccessibleContentSets	
	,ReasonForCheck	
	,DocumentId	
	,AdditionalDetails	
	,ProductCombinationId	
	,GatewayId	
	,UserSessionId	
	,RemoteIPAddress	) select top 1 * from PaDS_LogsUpToDBNAME.dbo.PEPWebUsageLog x order by x.PEPWebUsageLogid desc; set IDENTITY_INSERT PEPWebUsageLog off
set IDENTITY_INSERT SessionLog on;insert into SessionLog (	SessionLogId	
	,Date	
	,LogType	
	,PageId	
	,PageTitle	
	,UserId	
	,UserName	
	,Comment	
	,SessionId	
	,RemoteIPAddress	) select top 1 * from PaDS_LogsUpToDBNAME.dbo.SessionLog x order by x.SessionLogid desc; set IDENTITY_INSERT SessionLog off
set IDENTITY_INSERT UserActionLog on;insert into UserActionLog (	UserActionLogId	
	,FromLogRecordWithId	
	,UserSessionId	
	,DateTime	
	,MonthStartDate	
	,ActionType	
	,UserId	
	,LoggedInMethod	
	,UserType	
	,SubscriberId	
	,SubscriberName	
	,Institution_Id	
	,Institution_Name	
	,Access_Type	
	,Access_Method	
	,Data_Type	
	,Publisher_ID	
	,Section_Type	
	,TitleId	
	,TitleName	
	,ItemId	
	,ItemName	
	,YOP	
	,ISSN	
	,ISBN	
	,Language
	,OrderNumber	) select top 1 * from PaDS_LogsUpToDBNAME.dbo.UserActionLog x order by x.UserActionLogid desc; set IDENTITY_INSERT UserActionLog off

set IDENTITY_INSERT PEPUsage on;insert into PEPUsage (	PEPUsageId,
FromLogRecordWithId,
DateTime,
DateDay,
DateHour,
HourNumber,
GroupUserSessionBy,
Year,
Quarter,
Month,
ActionType,
LogonLocation,
LogonStatus,
LoggedUserName,
UserName,
UserFullName,
ReportingParentSubscriberName,
ReportingParentSubscriberId,
ReportingParentType,
OrderNumber,
UserCountry,
ReasonForCheck,
SubscriptionEndDate,
LoggedInMethod,
DocumentId,
documentRef,
PEPCode,
DocumentVolume,
DocumentYear,
authorMast,
UserSessionId,
UserActivitySessionCount,
AbstractCount,
ReadCount,
SearchCount,
PaDSSessionDurationMinutes,
ArchiveOrCurrent,
MonthStartDate,
MediaType
	) select top 1 * from PaDS_LogsUpToDBNAME.dbo.PEPUsage x order by x.PEPUsageid desc; set IDENTITY_INSERT PEPUsage off	
'
SET @sql = REPLACE(@SQL,'PaDS_LogsUpToDBNAME',@BackupDBName)
print @sql
execute(@SQL)

--23/8/22	James Woosnam	SIR5493 - Compress both the restored copy and the original
--Both databases have the same logical name "PaDS_LogsUpTo2021_09_22_1600"
--So USE each and shrink DBs
SET @SQL = '
USE ' + @BackupDBName + '
DBCC SHRINKFILE (N''PaDS_LogsUpTo2021_09_22_1600'' , 1000)
DBCC SHRINKFILE (N''PaDS_LogsUpTo2021_09_22_1600_Log'' , 50)
USE PaDS_Logs_Backup
DBCC SHRINKFILE (N''PaDS_LogsUpTo2021_09_22_1600'' , 1000)
DBCC SHRINKFILE (N''PaDS_LogsUpTo2021_09_22_1600_Log'' , 50)
'
print @sql
EXECUTE(@SQL)