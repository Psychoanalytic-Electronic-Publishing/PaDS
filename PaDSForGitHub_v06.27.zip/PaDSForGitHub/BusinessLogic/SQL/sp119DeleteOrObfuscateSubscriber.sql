if exists (select * from dbo.sysobjects where id = object_id(N'sp119DeleteOrObfuscateSubscriber') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp119DeleteOrObfuscateSubscriber
GO

CREATE PROCEDURE sp119DeleteOrObfuscateSubscriber(
				@SubscriberId INT
				,@RunByUserId INT
				,@ReturnMessage VARCHAR(MAX) = '' OUTPUT
				)
AS				
/*
If the subscriber has never been part of an order, then delete entirely
If it has been part of an order then, obfuscate all subscriber personal data

*/
--Modification History
--May 2019 - James Woosnam - Initial Version
--19/11/19	James Woosnam	SIR4763 - Nullify WebUser fields
	
DECLARE @Message varchar(8000) = ''

DECLARE @HasOrdersOrCashbook BIT = 0
SELECT @HasOrdersOrCashbook = 1 FROM  SalesOrder so WHERE so.SubscriberId = @SubscriberId 
SELECT @HasOrdersOrCashbook = 1 FROM  SalesOrderLine sol WHERE sol.SubscriberId = @SubscriberId 
SELECT @HasOrdersOrCashbook = 1 FROM  Cashbook c WHERE c.SubscriberId = @SubscriberId 


IF EXISTS(SELECT * FROM ProductAffiliateRate p where p.GroupSubscriberId = @SubscriberId )
BEGIN
	SET @Message = 'Remove SubscriberId:' + CAST(@SubscriberId AS VARCHAR) + ' failed as it is used in ProductAffiliateRate'
	RAISERROR (@Message, 16, 1)
END

BEGIN TRAN
BEGIN TRY
	IF @HasOrdersOrCashbook = 0 
	BEGIN
		DELETE FROM CompanyAccount WHERE SubscriberId = @SubscriberId 
		DELETE FROM SubscriberAffiliate  WHERE ChildSubscriberID = @SubscriberId 
		DELETE FROM SubscriberAffiliate  WHERE ParentSubscriberID = @SubscriberId 
		DELETE FROM SubscriberAddress WHERE SubscriberID = @SubscriberId 
		DELETE FROM Subscriber WHERE SubscriberID = @SubscriberId 
		SET @ReturnMessage = CAST(@SubscriberId AS VARCHAR) + ' deleted'

	END
	IF @HasOrdersOrCashbook = 1
	BEGIN
		UPDATE CompanyAccount 
		SET Notes = 'Obfuscated:' + FORMAT(GETDATE(),'dd-MMM-yy HH:mm')
			,LastUpdatedByUserId = @RunByUserId 
			,LastUpdatedDateTime = GETDATE()
		WHERE SubscriberId = @SubscriberId 
		IF PATINDEX('%zedra%',@@SERVERNAME) = 0 DELETE FROM SubscriberAffiliate  WHERE ChildSubscriberID = @SubscriberId AND ParentSubscriberID NOT IN (30000,29001,29002)
		DELETE FROM SubscriberAffiliate  WHERE ParentSubscriberID = @SubscriberId 
		UPDATE Cashbook 
		SET PaymentCardName = dbo.fn051ObfuscatedText(PaymentCardName)
			,PaymentCardExpiryDate = 'xx/xx'
			,PaymentCardNumber = 'xxxxx'
			,PaymentCardAuthorisationCode = 'xxxx'
			,PaymentCardAuthorisationReturnText = ''
			,CreatedByUserId = dbo.fn051ObfuscatedText(CreatedByUserId)
			,Notes = 'Obfuscated:' + FORMAT(GETDATE(),'dd-MMM-yy HH:mm')
		WHERE SubscriberId = @SubscriberId 
		UPDATE SubscriberAddress  
		SET Notes = 'Obfuscated:' + FORMAT(GETDATE(),'dd-MMM-yy HH:mm')
			,Address1 =  dbo.fn051ObfuscatedText(Address1)
			,Address2 =  dbo.fn051ObfuscatedText(Address2)
			,Address3 =  dbo.fn051ObfuscatedText(Address3)
			,Address4 =  dbo.fn051ObfuscatedText(Address4)
			,Town =  dbo.fn051ObfuscatedText(Town)
			,County =  dbo.fn051ObfuscatedText(County)
			,PostCode =  dbo.fn051ObfuscatedText(PostCode)
			,AddressText=  dbo.fn051ObfuscatedText(AddressText)

			,LastUpdatedByUserId = @RunByUserId 
			,LastUpdatedDateTime = GETDATE()
		WHERE SubscriberId = @SubscriberId 
		UPDATE Subscriber
		SET Notes = 'Obfuscated:' + FORMAT(GETDATE(),'dd-MMM-yy HH:mm')
			,SubscriberStatus = CASE WHEN  PATINDEX('%zedra%',@@SERVERNAME) = 0  THEN 'InActive' ELSE SubscriberStatus END
			,SubscriberName =  dbo.fn051ObfuscatedText(SubscriberName)
			,VATNumber =  dbo.fn051ObfuscatedText(VATNumber)
			,ContactName =  dbo.fn051ObfuscatedText(ContactName)
			,FirstName =  dbo.fn051ObfuscatedText(FirstName)
			,LastName =  dbo.fn051ObfuscatedText(LastName)
			,Title =  dbo.fn051ObfuscatedText(Title)
			,Salutation =  dbo.fn051ObfuscatedText(Salutation)
			,Position =  dbo.fn051ObfuscatedText(Position)
			,Qualifications =  dbo.fn051ObfuscatedText(Qualifications)
			,MembershipType =  dbo.fn051ObfuscatedText(MembershipType)
			,Spare1 =  dbo.fn051ObfuscatedText(Spare1)
			,Spare2 =  dbo.fn051ObfuscatedText(Spare2)
			,Spare3 =  dbo.fn051ObfuscatedText(Spare3)
			,LastUpdatedByUserId = @RunByUserId 
			,LastUpdatedDateTime = GETDATE()
		WHERE SubscriberId = @SubscriberId 
		SET @ReturnMessage = CAST(@SubscriberId AS VARCHAR) + ' Obfuscated'
	END
	commit TRAN
	print @ReturnMessage
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SET @Message = 'sp119DeleteOrObfuscateSubscriber Failed - ' + ERROR_MESSAGE()
	RAISERROR (@Message, 16, 1)
END CATCH


GO

Grant EXECUTE ON sp119DeleteOrObfuscateSubscriber to PaDSSQLServerUser



