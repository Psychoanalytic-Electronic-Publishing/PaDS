if exists (select * from dbo.sysobjects where id = object_id(N'sp115RejectSubscriber') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp115RejectSubscriber
GO
CREATE  PROCEDURE sp115RejectSubscriber (
				 @SubscriberId INT
				 ,@UserName20 VARCHAR(20) 
				)
AS
--10/1/20	James Woosnam	SIR4977 - Initial version
--21/4/22	Julian Gates	SIR5467 - Update LastUpdatedDateTime and LastUpdatedByUserId to show in Audit Log
DECLARE @Message VARCHAR(MAX)=''
DECLARE @UpdateToSubscriberId INT = (SELECT UpdateToSubscriberId FROM Subscriber WHERE SubscriberId = @SubscriberId )
BEGIN TRAN
BEGIN TRY
	UPDATE Subscriber 
	SET SubscriberStatus = 'Rejected'	
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName20
	WHERE SubscriberId = @SubscriberId

	IF @UpdateToSubscriberId IS NOT NULL
	BEGIN
		UPDATE RemoteUserRights 
		SET RightsToId = @UpdateToSubscriberId
		WHERE RightsToId = @SubscriberId
		UPDATE RemoteUser
		SET UserName = ru.UserNameBeforeProposed
		,EmailAddress = sa.AddressText 
		FROM RemoteUser ru
			INNER JOIN RemoteUserRights rur
				LEFT JOIN SubscriberAddress sa
				ON sa.SubscriberId = rur.RightsToId 
				AND sa.AddressType = 'Email'
				AND sa.AddressDescription = 'Main'
			ON rur.UserId = ru.UserId
			AND rur.RightsType = 'Subscriber'
		WHERE rur.RightsToId = @UpdateToSubscriberId
	END
	ELSE
	BEGIN
		UPDATE RemoteUser 
		SET UserStatus = 'InActive'
		FROM RemoteUser ru
			INNER JOIN RemoteUserRights rur
			ON rur.UserId = ru.UserId
			AND rur.RightsType = 'Subscriber'
		WHERE rur.RightsToId = @SubscriberId 
	END
	COMMIT TRAN
END TRY
BEGIN CATCH
	ROLLBACK TRAN		
	SELECT @Message = 'Subscriber Insert Failed - ' + ERROR_MESSAGE()
	RAISERROR (@Message, 16, 1)
END CATCH

GO
GRANT EXECUTE ON sp115RejectSubscriber TO PaDSSQLServerUser