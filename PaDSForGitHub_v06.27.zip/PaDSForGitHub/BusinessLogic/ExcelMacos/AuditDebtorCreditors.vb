'********************
' March 2022
' This code has been put in TFS file BusinessLogic\ExcelMacros\CashbookMacro.vb to allow change tracking
'*******************
'3/3/22     James Woosnam   SIR5439 - Remove amounts to base in pivot
'Option Explicit
Sub cmdSetDefault_Click()
    On Error Resume Next

    FormatPivot "Default"
End Sub

Public Function FormatPivot(strFormatType As String)
    On Error GoTo ProcedureError
    Dim pvt As Excel.PivotTable
    Dim fld As Excel.PivotField
    Dim wkb As Excel.Workbook
    Dim pi As Excel.PivotItem

    Set wkb = ActiveWorkbook
    
    Set pvt = wkb.Sheets("Pivot").PivotTables("Pivot")
    
     On Error Resume Next

    For Each fld In pvt.PivotFields
        fld.Orientation = xlHidden
    Next
    For Each fld In pvt.DataFields
        fld.Orientation = xlHidden
    Next
    On Error GoTo ProcedureError

    Select Case strFormatType
        Case "Default"
            '***************************************************
            '2022 - Code in TFS see top
            '******************************************************

            pvt.PivotFields("CurrencyCode").Orientation = xlRowField
            pvt.PivotFields("SubscriberName").Orientation = xlRowField
            pvt.PivotFields("Date").Orientation = xlRowField
            pvt.PivotFields("TransactionType").Orientation = xlRowField
            pvt.PivotFields("OrderNumber").Orientation = xlRowField
            pvt.PivotFields("Date").NumberFormat = "D-MMM-YY"

            For Each pi In pvt.PivotFields("SubscriberName").PivotItems
                pi.ShowDetail = False
            Next

            pvt.PivotFields("AmountInNative").Orientation = xlDataField
            '3/3/22     James Woosnam   SIR5439 - Remove amounts to base in pivot
            '  pvt.PivotFields("AmountInBase").Orientation = xlDataField

            For Each fld In pvt.DataFields
                fld.Function = xlSum
                fld.NumberFormat = "#,##0.00"

            Next

            With wkb.Sheets("Pivot").PageSetup
                .PrintTitleRows = ""
                .PrintTitleColumns = ""
                .Zoom = False
                .FitToPagesWide = 1
                .FitToPagesTall = False
            End With
            wkb.Sheets("Pivot").Columns("A:X").EntireColumn.AutoFit

    End Select
    wkb.Sheets("Pivot").Select
    wkb.Sheets("Pivot").Cells(5, 3).Select
    On Error Resume Next
    wkb.Sheets("Pivot").Shapes("cmdDefault").Select
    If Err <> 0 Then
        'Assume button not there so add it
        wkb.Sheets("Pivot").Buttons.Add(1, 1, 60, 20).Select
        wkb.Parent.Selection.Name = "cmdDefault"
    End If
    On Error GoTo ProcedureError
    wkb.Parent.Selection.OnAction = "cmdSetDefault_Click"
    wkb.Parent.Selection.Characters.Text = "Default"
    wkb.Parent.Selection.ShapeRange.Left = 0
    wkb.Parent.Selection.ShapeRange.Top = 20
    wkb.Parent.Selection.ShapeRange.Width = 50
    wkb.Parent.Selection.ShapeRange.Height = 15
    Range(Sheets("Criteria").Range("PivotStart").Value).Select

ProcedureExit:
    Exit Function

ProcedureError:
    Select Case Err.Number
        Case Else
            GlobalErr Err.Number, Err.Description, "FormatPivot"
        Resume ProcedureExit
            Resume
    End Select

End Function

Public Function GlobalErr(lngErrNumber As Long, strErrString As String, Optional strErrLocation As Variant)

    If IsMissing(strErrLocation) Then
        strErrLocation = "In Report Template"
    End If

    Sheets("Criteria").Range("a10").Value = "UNEXPECTED ERROR: " & lngErrNumber _
                & "-" & strErrString _
                & "-" & strErrLocation
End Function





