﻿Imports System.Data.SqlClient
Imports System.Data
Partial Class Pages_pg030DisqusTest
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Public DQPageId As String = "Test-001" 'IJPOPEN.001.0001A
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Disqus Test", "")
        Dim dq As New BusinessLogic.DisqusInterface(uPage.db, uPage.UserSession)

        ClientScript.RegisterClientScriptBlock(Me.GetType, "MyScript", dq.GetImbedScript(PageURL:="https://stage.pep-web.org/browse/IJPOPEN/volumes/1?preview=" & DQPageId,
                                                                                         PageId:=DQPageId))

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        uPage.PagePreRender()
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub
End Class

