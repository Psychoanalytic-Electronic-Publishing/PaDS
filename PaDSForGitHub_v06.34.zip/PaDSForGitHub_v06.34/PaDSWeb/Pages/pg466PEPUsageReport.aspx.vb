﻿Imports System.Data.SqlClient
Imports System.Data
Imports BusinessLogic.ReportPEPUsage
'Modification History
'24/09/21   Julian Gates    Initial version
'21/4/22	Julian Gates	SIR5467 - Set Batch Log line to top align in page.
'16/5/22    Julian Gates    SIR5459 - Change page to now use EntityServerModeDataSource for Usage reports
'26/6/22    James Woosnam   SIR5487 - PEPUsageReadsFromJan2020ByReportingParent added and rename and fix up submit 
'15/8/22    James Woosnam   SIR5532 - Add AuthorStats
'06/06/23   Julian Gates    SIR5660 - Create Excel Pivot button should not be shown for the summary by reporting parent option.

Partial Class Pages_pg466PEPUsageReport
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim _tblGroups As DataTable = Nothing
    Enum DisplayModes
        SummaryByReportingParent
        SummaryByYear
        SummaryByJournal
        PEPUsageSingleReportingParentDetail
        PEPUsageReadsFromJan2020ByReportingParent
        AuthorStats
    End Enum
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "PEP Usage Report", "")
        Me.pageHeaderTitle.Text = "PEP Usage Report"

        If Page.IsPostBack Then

        Else
            ReadRecord()
            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If

            If Request.QueryString("ReportType") <> "" And Request.QueryString("ReportingParentSubscriberId") <> "" Then
                Me.ReportDisplayMode.SelectedValue = DisplayModes.SummaryByReportingParent
                Me.ReportingParentSubscriberId.SelectedValue = Request.QueryString("ReportingParentSubscriberId")
            End If
            'With Me.UsageSummaryPivotGrid1
            '    .Fields.AddField(New DevExpress.Web.ASPxPivotGrid.PivotGridField("UserActivitySessionCount", DevExpress.XtraPivotGrid.PivotArea.DataArea))
            '    FormatDataField(.Fields("UserActivitySessionCount"))
            '    FormatDataField(.Fields("fieldAbstractCount"))
            'End With
            '  Me.UsageSummaryPivotGrid1.Groups.Add("Month")
            'Me.UsageSummaryPivotGrid1.Fields("UserCountry").Area = DevExpress.XtraPivotGrid.PivotArea.FilterArea
            'Me.UsageSummaryPivotGrid1.Fields("ReportingParentSubscriberName").Area = DevExpress.XtraPivotGrid.PivotArea.RowArea

        End If
    End Sub
    Sub PositionField(fld As DevExpress.Web.ASPxPivotGrid.PivotGridField, Area As DevExpress.XtraPivotGrid.PivotArea)
        fld.Area = Area
        Select Case Area
            Case DevExpress.XtraPivotGrid.PivotArea.ColumnArea
                fld.AreaIndex = colAreaIndex
                colAreaIndex += 1
            Case DevExpress.XtraPivotGrid.PivotArea.DataArea
                fld.AreaIndex = dataAreaIndex
                dataAreaIndex += 1
            Case DevExpress.XtraPivotGrid.PivotArea.RowArea
                fld.AreaIndex = rowAreaIndex
                rowAreaIndex += 1
                fld.TotalCellFormat.FormatString = "#,##0"
                fld.ValueFormat.FormatString = "#,##0"
                fld.TotalValueFormat.FormatString = "#,##0"
                fld.TotalCellFormat.FormatType = DevExpress.Utils.FormatType.Numeric
                fld.ValueFormat.FormatType = DevExpress.Utils.FormatType.Numeric
                fld.TotalValueFormat.FormatType = DevExpress.Utils.FormatType.Numeric
        End Select
    End Sub
    Dim rowAreaIndex As Integer
    Dim colAreaIndex As Integer
    Dim dataAreaIndex As Integer
    Sub PageSetup()
        'Default date field values
        Dim Sep2021Index As Integer = 0
        Dim StartIndex As Integer = Me.StartMonth.SelectedIndex
        Dim EndIndex As Integer = Me.EndMonth.SelectedIndex

        Dim periods As DataTable = Nothing
        Select Case Me.ReportDisplayMode.SelectedValue
            Case DisplayModes.PEPUsageReadsFromJan2020ByReportingParent, DisplayModes.AuthorStats
                periods = uPage.db.GetDataTableFromSQL("SELECT DISTINCT MonthStartDate=MonthStart FROM UsageByMonthDocument ORDER BY MonthStart")
            Case Else
                periods = uPage.db.GetDataTableFromSQL("SELECT DISTINCT MonthStartDate FROM PEPUsageSummary ORDER BY MonthStartDate")
        End Select

        Me.StartMonth.Items.Clear()
        For Each r As DataRow In periods.Rows
            Dim MonthStart As Date = r("MonthStartDate")
            Me.StartMonth.Items.Add(New ListItem(MonthStart.ToString("yyyy-MM MMM"), MonthStart.ToString("yyyy-MM-dd")))
            If CDate(r("MonthStartDate")) = CDate("01-Sep-2021") Then Sep2021Index = Me.StartMonth.Items.Count - 1
        Next
        Me.EndMonth.Items.Clear()
        For Each r As DataRowView In New DataView(periods, "", "MonthStartDate Desc", DataViewRowState.CurrentRows)
            Dim MonthStart As Date = r("MonthStartDate")
            Me.EndMonth.Items.Add(New ListItem(MonthStart.ToString("yyyy-MM MMM"), MonthStart.ToString("yyyy-MM-dd")))
        Next
        If Not IsPostBack Then
            Me.StartMonth.SelectedIndex = Sep2021Index 'Set start to sep 2021, until we get 24 months after sep 21, then just last 24 months
            If Me.StartMonth.Items.Count > 7 + (24) Then Me.StartMonth.SelectedIndex = Me.StartMonth.Items.Count - 24
            Me.EndMonth.SelectedIndex = 0
        Else
            Me.StartMonth.SelectedIndex = StartIndex
            Me.EndMonth.SelectedIndex = EndIndex
        End If


        SelectReportingParentSubscriberRow.Visible = {DisplayModes.PEPUsageSingleReportingParentDetail, DisplayModes.PEPUsageReadsFromJan2020ByReportingParent}.Contains(Me.ReportDisplayMode.SelectedValue)
        UsagePivotGridRow.Visible = Not {DisplayModes.PEPUsageSingleReportingParentDetail, DisplayModes.PEPUsageReadsFromJan2020ByReportingParent, DisplayModes.AuthorStats}.Contains(Me.ReportDisplayMode.SelectedValue)
        ' DateSelectTable.Visible = Not {DisplayModes.PEPUsageSingleReportingParentDetail, DisplayModes.PEPUsageReadsFromJan2020ByReportingParent}.Contains(Me.ReportDisplayMode.SelectedValue)
        '06/06/23   Julian Gates    SIR5660 -  Create Excel Pivot button should not be shown for the summary by reporting parent option.
        SubmitBtn.Visible = {DisplayModes.PEPUsageSingleReportingParentDetail, DisplayModes.PEPUsageReadsFromJan2020ByReportingParent, DisplayModes.AuthorStats}.Contains(Me.ReportDisplayMode.SelectedValue)
        For Each fld As DevExpress.Web.ASPxPivotGrid.PivotGridField In Me.UsageSummaryPivotGrid1.Fields
            Me.PositionField(fld, DevExpress.XtraPivotGrid.PivotArea.FilterArea)
        Next
        Select Case Me.ReportDisplayMode.SelectedValue
            Case DisplayModes.SummaryByReportingParent
                Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("ReportingParentSubscriberName"), DevExpress.XtraPivotGrid.PivotArea.RowArea)
                Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("UserActivitySessionCount"), DevExpress.XtraPivotGrid.PivotArea.DataArea)
                Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("AbstractCount"), DevExpress.XtraPivotGrid.PivotArea.DataArea)
                Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("ReadCount"), DevExpress.XtraPivotGrid.PivotArea.DataArea)
                Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("SearchCount"), DevExpress.XtraPivotGrid.PivotArea.DataArea)
            Case DisplayModes.SummaryByYear
                Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("fieldYearStartDate"), DevExpress.XtraPivotGrid.PivotArea.RowArea)
                Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("ReportingParentType"), DevExpress.XtraPivotGrid.PivotArea.ColumnArea)
                Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("UserActivitySessionCount"), DevExpress.XtraPivotGrid.PivotArea.DataArea)
            Case DisplayModes.SummaryByJournal
                Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("MediaType"), DevExpress.XtraPivotGrid.PivotArea.RowArea)
                Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("PEPCode"), DevExpress.XtraPivotGrid.PivotArea.RowArea)
                '    Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("DocumentYear"), DevExpress.XtraPivotGrid.PivotArea.RowArea)
                Me.UsageSummaryPivotGrid1.Fields("PEPCode").ExpandedInFieldsGroup = False
                '     Me.UsageSummaryPivotGrid1.Fields("DocumentYear").ExpandedInFieldsGroup = False
                Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("AbstractCount"), DevExpress.XtraPivotGrid.PivotArea.DataArea)
                Me.PositionField(Me.UsageSummaryPivotGrid1.Fields("ReadCount"), DevExpress.XtraPivotGrid.PivotArea.DataArea)
            Case DisplayModes.PEPUsageSingleReportingParentDetail, DisplayModes.PEPUsageReadsFromJan2020ByReportingParent
                Me.ReportingParentSubscriberId.Focus()
        End Select
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        'Populate all dropdown fields
        Dim dropDownIntialValue As String = "<---------Select--------->"
        uPage.PopulateDropDownListFromSQL(Me.ReportingParentSubscriberId, "SELECT DISTINCT Value = ReportingParentSubscriberId" _
                                                             & "    ,Text = ReportingParentSubscriberName" _
                                                             & " FROM PEPUsageSummary " _
                                                             & " ORDER BY ReportingParentSubscriberName" _
                                                             , uPage.PrimaryConnection, dropDownIntialValue
                                                             )
    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        PageSetup()
        uPage.PagePreRender()
    End Sub

    Protected Sub EntityServerModeDataSource1_Selecting(ByVal sender As Object, ByVal e As DevExpress.Data.Linq.LinqServerModeDataSourceSelectEventArgs)
        '***To Change Pivot Fields*****
        'See OneNote DevExpress PivotGrids
        Try
            Dim db = New BusinessLogic.PEPUsageSummaryForPivotModel()

            db.Database.Connection.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("PEPUsageSummaryModel").ToString
            db.Database.Connection.Open()
            e.KeyExpression = "PEPUsageSummaryId"
            e.QueryableSource = db.vw458PEPUsageSummaryForPivot.Where(Function(pu) pu.MonthStartDate >= CDate(Me.StartMonth.SelectedValue) And pu.MonthStartDate <= CDate(Me.EndMonth.SelectedValue))
            db.Database.Connection.Close()
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Protected Sub DataAwareExportButton_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Exports using the Data-Aware type.
        Me.UsageSummaryPivotGridExporter.ExportXlsxToResponse("ASPxPivotGrid", New DevExpress.XtraPrinting.XlsxExportOptionsEx With
            {.AllowFixedColumns = DevExpress.Utils.DefaultBoolean.False, .SheetName = "Pivot Grid Export"}, True)
    End Sub

    Protected Sub WysiwygExportButton_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Exports using the WYSIWYG type.
        UsageSummaryPivotGridExporter.ExportPdfToResponse("ASPxPivotGrid", New DevExpress.XtraPrinting.PdfExportOptions() With
            {.ShowPrintDialogOnOpen = True}, True)
    End Sub

    Private Sub ClearBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub

    Private Sub SubmitBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubmitBtn.Click
        Try
            Dim Rep As BusinessLogic.ReportPEPUsage = Nothing
            Dim repType As BusinessLogic.ReportPEPUsage.PEPUsageReportTypes = Nothing
            Select Case Me.ReportDisplayMode.SelectedValue
                Case DisplayModes.PEPUsageSingleReportingParentDetail
                    repType = PEPUsageReportTypes.PEPUsageSingleReportingParentDetail
                Case DisplayModes.PEPUsageReadsFromJan2020ByReportingParent
                    repType = PEPUsageReportTypes.PEPUsageReadsFromJan2020ByReportingParent
                Case DisplayModes.SummaryByReportingParent
                    repType = PEPUsageReportTypes.PEPUsageSummaryByReportingParent
                Case DisplayModes.AuthorStats
                    repType = PEPUsageReportTypes.PEPUsageAuthorStats

            End Select
            Rep = New BusinessLogic.ReportPEPUsage(Me.StartMonth.SelectedItem.Text, Me.EndMonth.SelectedItem.Text, repType, uPage.db, uPage.UserSession.UserSessionIdGUID)

            Dim SubId As Integer = 0
            Select Case Rep.PEPUsageReportType
                Case BusinessLogic.ReportPEPUsage.PEPUsageReportTypes.PEPUsageSingleReportingParentDetail, PEPUsageReportTypes.PEPUsageReadsFromJan2020ByReportingParent
                    uPage.DropDownValidateMandatory(Me.ReportingParentSubscriberId)
                    SubId = Me.ReportingParentSubscriberId.SelectedValue
            End Select
            If Me.uPage.IsValid Then
                Rep.Submit(SubId)
                ViewState("BatchJobId") = Rep.BatchJob.BatchJobId
            End If

        Catch ex As Exception
            uPage.PageError = "There was an unexpected problem generating this report.  Please contact support." & ex.ToString
        End Try

        If uPage.IsValid Then
            UpdateTimer_Tick(sender, e)
        End If
    End Sub
    Protected Sub UpdateTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateTimer.Tick
        Try
            If IsNumeric(ViewState("BatchJobId")) Then
                Me.TimedPanel.Visible = True
                Dim BatchLog As New BusinessLogic.BatchLog(uPage.db)
                Me.BatchLogLines.Text = BatchLog.GetBatchLogLinesHTML(ViewState("BatchJobId"))
                Select Case uPage.db.IsDBNull(uPage.db.DLookup("MAX(BatchLogStatus)", "BatchLog", "BatchJobId=" & ViewState("BatchJobId")), "")
                    Case "Failed"
                        Me.UpdateTimer.Enabled = False
                    Case "Complete"
                        Me.UpdateTimer.Enabled = False
                        '      Response.Redirect("pg483SubscriberImportFileLoad.aspx?SubscriberImportBatchId=" & Me.SubscriberImportBatchId.Text )
                    Case Else
                        Me.UpdateTimer.Enabled = True
                End Select
            Else
                Me.UpdateTimer.Enabled = False
                Me.TimedPanel.Visible = False
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub
End Class
