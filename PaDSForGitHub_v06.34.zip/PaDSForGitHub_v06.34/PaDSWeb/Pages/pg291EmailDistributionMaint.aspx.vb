﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web
Imports DevExpress.Web.Data
Imports BusinessLogic.EmailDistribution
'Modification History
'30/08/2022 Julian Gates    Initial Version
'24/5/23    James Woosnam   SIR5642 - Allow entered SubId list and email list

Partial Class Pages_pg291EmailDistributionMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Enum PageModes
        Add
        Update
    End Enum
    Property pageMode As PageModes
        Set(value As PageModes)
            ViewState("PageMode") = value

        End Set
        Get
            If ViewState("PageMode") Is Nothing Then ViewState("PageMode") = "Add"
            Return ViewState("PageMode")
        End Get
    End Property

    Private _EmailDistribution As BusinessLogic.EmailDistribution = Nothing
    Public Property EmailDistribution() As BusinessLogic.EmailDistribution
        Get
            If Me._EmailDistribution Is Nothing Then
                Me._EmailDistribution = New BusinessLogic.EmailDistribution(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._EmailDistribution
        End Get
        Set(ByVal value As BusinessLogic.EmailDistribution)
            Me._EmailDistribution = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "EmailDistribution Maint", "")
        Me.pageHeaderTitle.Text = "EmailDistribution Maint"

        If Request.QueryString("EmailDistributionId") <> "" Then
            Me.pageMode = PageModes.Update
            Me.EmailDistributionId.Text = Request.QueryString("EmailDistributionId")
        Else
            Me.pageMode = PageModes.Add
        End If

        If Page.IsPostBack Then
            Me.EmailDistribution.MainDataset = CType(ViewState("MainDataSet"), DataSet)
        Else
            If Request.QueryString("EmailDistributionId") <> "" Then
                Try
                    Me.EmailDistribution = New BusinessLogic.EmailDistribution(Request.QueryString("EmailDistributionId"), Me.uPage.db, Me.uPage.UserSession)
                Catch ex As Exception
                    Me.uPage.PageError = "Invalid Parameter has been passed in"
                End Try
                Me.pageMode = PageModes.Update
                Me.EmailName.Focus()
            Else
                Me.pageMode = PageModes.Add
                Me.EmailDistribution = New BusinessLogic.EmailDistribution(Me.uPage.db, Me.uPage.UserSession)
            End If

            If Me.uPage.IsValid Then
                ReadRecord()
            End If
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        If Me.pageMode = PageModes.Update AndAlso uPage.IsValid Then
            'Must be called each time to get filtering to work
            Me.SubscriberRecipientsGridView.DataSource = Me.EmailDistribution.SubscriberRecipients
            Me.SubscriberRecipientsGridView.DataBind()
        End If
    End Sub
    Sub PageSetup()
        Dim IsUpdate As Boolean = pageMode = PageModes.Update
        Me.pageHeaderTitle.Text = pageMode.ToString & " Bulk Email "
        Me.AddFieldsRow.Visible = pageMode = PageModes.Add
        Me.ProductCodeForAddRow.Visible = pageMode = PageModes.Add AndAlso Me.SubscriberSourceTypeForAdd.SelectedValue = SubscriberSourceTypes.CurrentSubscriptionToProducts
        Me.UpdateFieldsRow.Visible = IsUpdate
        Me.UpdateButtonRow.Visible = IsUpdate
        Me.EmailName.Enabled = IsUpdate AndAlso Me.EmailDistribution.EmailDistributionStatus = EmailDistributionStats.Initial
        Me.EmailSubject.Enabled = IsUpdate AndAlso Me.EmailDistribution.EmailDistributionStatus = EmailDistributionStats.Initial
        Me.ProductCodeForAdd.Enabled = Me.SubscriberSourceTypeForAdd.SelectedValue = SubscriberSourceTypes.CurrentSubscriptionToProducts
        Me.ProductCodeListRow.Visible = IsUpdate AndAlso Me.EmailDistribution.SubscriberSourceType = SubscriberSourceTypes.CurrentSubscriptionToProducts
        Me.ProductCodeList.Enabled = IsUpdate AndAlso Me.EmailDistribution.EmailDistributionStatus = EmailDistributionStats.Initial
        Me.EnteredSubscriberListRow.Visible = IsUpdate AndAlso {SubscriberSourceTypes.EnteredSubscriberIdList, SubscriberSourceTypes.EnteredEmailAddressList}.Contains(Me.EmailDistribution.SubscriberSourceType)
        Me.EnteredSubscriberListText.Enabled = IsUpdate AndAlso Me.EmailDistribution.EmailDistributionStatus = EmailDistributionStats.Initial
        Me.SubscriberCategoryFilter.Enabled = IsUpdate AndAlso Me.EmailDistribution.EmailDistributionStatus = EmailDistributionStats.Initial
        Me.CountryIdFilter.Enabled = IsUpdate AndAlso Me.EmailDistribution.EmailDistributionStatus = EmailDistributionStats.Initial

        Me.SaveBtn.Visible = IsUpdate AndAlso Me.EmailDistribution.EmailDistributionStatus = EmailDistributionStats.Initial
        Me.SendSampleBtn.Visible = IsUpdate AndAlso Me.EmailDistribution.EmailDistributionStatus = EmailDistributionStats.Initial
        Me.StartDistributionBtn.Visible = IsUpdate AndAlso Me.EmailDistribution.EmailDistributionStatus = EmailDistributionStats.Initial
        Me.RefreshBtn2.Visible = IsUpdate AndAlso Me.EmailDistribution.EmailDistributionStatus = EmailDistributionStats.Initial
        Me.RefreshBtn.Visible = IsUpdate AndAlso {EmailDistributionStats.Emailing, EmailDistributionStats.Complete}.Contains(Me.EmailDistribution.EmailDistributionStatus)


        Me.EmailHTMLRow.Visible = IsUpdate
        Me.EmailHTML.Enabled = IsUpdate AndAlso Me.EmailDistribution.EmailDistributionStatus = EmailDistributionStats.Initial
        Me.ProgressSummaryRow.Visible = IsUpdate 'AndAlso Me.EmailDistribution.EmailDistributionStatus <> EmailDistributionStats.Initial

        If IsUpdate AndAlso uPage.IsValid Then
            Select Case Me.EmailDistribution.EmailDistributionStatus
                Case EmailDistributionStats.Pending, EmailDistributionStats.Initial
                    Dim tSubs As DataTable = Me.EmailDistribution.SubscriberRecipients
                    Dim errCount As Integer = New DataView(tSubs, "ErrorMessage<>''", "", DataViewRowState.CurrentRows).Count
                    Me.ProgressSummaryLbl.Text = New DataView(tSubs, "ErrorMessage=''", "", DataViewRowState.CurrentRows).Count & " Subscribers match criteria, " & errCount & " have errors.  See list below."
                    If errCount <> 0 Then uPage.FieldErrorControl(Me.EnteredSubscriberListText, "Some of the subscribers entered have errors, see list at bottom of page.")

                    Me.SubscriberRecipientsListRow.Visible = tSubs.Rows.Count <> 0
                Case Else
                    Me.ProgressSummaryLbl.Text = "Distribution Status:" & Me.EmailDistribution.EmailDistributionStatus.ToString & "<br>" & Me.EmailDistribution.ProgressSummary
            End Select
        End If

        Dim sql As String = ""
        sql = "Select  p.ProductCode As Value" _
                & "     ,p.ProductCode + ' - ' + p.ProductName As Text" _
                & " FROM Product p" _
                & "     INNER JOIN " & uPage.CompanyTable("c", uPage.UserSession.UserId) _
                & "     ON c.CompanyId = p.CompanyId " _
                & " WHERE p.ProductStatus = 'Current'" _
                & " AND p.IsParent = 1"
        If Me.pageMode = PageModes.Add Then sql += " And p.CompanyId = " & IIf(Me.CompanyIdForAdd.SelectedValue = "", 0, Me.CompanyIdForAdd.SelectedValue)
        If IsUpdate Then sql += " And p.CompanyId = " & Me.EmailDistribution.EmailDistributionRow("CompanyId")
        sql += " ORDER BY p.ProductCode + ' - ' + p.ProductName Asc"
        If Me.pageMode = PageModes.Add Then Me.uPage.PopulateDropDownListFromSQL(Me.ProductCodeForAdd, sql, uPage.db.DBConnection, "<--Select-->")
        If IsUpdate Then Me.uPage.PopulateListBoxFromSql(Me.ProductCodeList, sql, Nothing)
        If IsUpdate AndAlso Me.SubscriberSourceTypeForAdd.SelectedValue = SubscriberSourceTypes.CurrentSubscriptionToProducts AndAlso uPage.db.IsDBNull(EmailDistribution.EmailDistributionRow("SubscribedToProductCodes"), "") <> "" Then
            For Each prodCode As String In EmailDistribution.EmailDistributionRow("SubscribedToProductCodes").ToString.Split(",")
                For Each item As ListItem In Me.ProductCodeList.Items
                    If item.Value = prodCode Then item.Selected = True
                Next
            Next
        End If

        If pageMode = PageModes.Update Then
            'Output BatchLogLines table
            Select Case Me.EmailDistribution.EmailDistributionStatus
                Case EmailDistributionStats.Complete, EmailDistributionStats.Failed, EmailDistributionStats.Emailing
                    Dim BatchLogId As String = uPage.db.IsDBNull(uPage.db.DLookup("MAX(BatchLogId)", "EmailDistributionLog", "EmailDistributionId=" & Me.EmailDistribution.EmailDistributionId), 0)
                    Dim BatchLog As New BusinessLogic.BatchLog(uPage.db)
                    Me.BatchLogLines.Text = BatchLog.GetBatchLogLinesHTML(uPage.db.IsDBNull(uPage.db.DLookup("MAX(BatchJobId)", "BatchLog", "BatchLogId=" & BatchLogId), 0))
            End Select
            Me.SubscriberRecipientsGridView.DataSource = Me.EmailDistribution.SubscriberRecipients
            Me.SubscriberRecipientsGridView.DataBind()
        End If
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Try
            Dim Sql As String = Nothing
            Select Case Me.pageMode
                Case PageModes.Add
                    Me.uPage.PopulateDropDownListFromSQL(Me.CompanyIdForAdd, "SELECT Value=CompanyId,Text=CompanyName FROM " & uPage.CompanyTable("c", uPage.UserSession.UserId), uPage.db.DBConnection, Nothing)
                Case PageModes.Update
                    Me.uPage.PopulatePageFieldsFromDataRow(Me.EmailDistribution.EmailDistributionRow)
                    Me.EmailHTML.Html = uPage.db.IsDBNull(Me.EmailDistribution.EmailDistributionRow("EmailHTML"), Nothing)
                    Me.CompanyName.Text = uPage.db.DLookup("CompanyName", "Company", "CompanyId=" & Me.EmailDistribution.EmailDistributionRow("CompanyId"))

                    Sql = "SELECT LookupItemKey As Value" _
                            & ", Name As Text" _
                            & " FROM Lookup" _
                            & " WHERE LookupName = 'SubscriberCategory'" _
                            & " AND Lookup.LookupStatus = 'Active'" _
                            & " AND CompanyId = " & uPage.db.DLookup("RightsToId", "RemoteUserRights", "RightsType = 'Company' AND UserId=" & uPage.UserSession.UserId) _
                            & " ORDER BY DisplayOrder,Name,LookupItemKey"
                    Me.uPage.PopulateDropDownListFromSQL(Me.SubscriberCategoryFilter, Sql, uPage.db.DBConnection, "<--Select-->")

                    Sql = "SELECT Country.CountryId as Value" _
                         & "     ,Country.CountryName As Text" _
                         & " FROM Country" _
                         & " ORDER BY Country.CountryName"
                    Me.uPage.PopulateDropDownListFromSQL(Me.CountryIdFilter, Sql, uPage.db.DBConnection, "<--Select-->")
            End Select
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.EmailDistribution.MainDataset
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Private Sub AddBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddBtn.Click
        Try
            If Me.SubscriberSourceTypeForAdd.SelectedValue = SubscriberSourceTypes.CurrentSubscriptionToProducts Then uPage.DropDownValidateMandatory(Me.ProductCodeForAdd)
            uPage.DropDownValidateMandatory(Me.CompanyIdForAdd)
            Me.EmailDistribution.AddNewEmailDistribution(Me.SubscriberSourceTypeForAdd.SelectedValue, Me.ProductCodeForAdd.SelectedValue, Me.CompanyIdForAdd.SelectedValue)
        Catch ex As Exception
            uPage.PageError = ex.ToString

        End Try
        If Me.uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?EmailDistributionId=" & Me.EmailDistribution.EmailDistributionId & "&InfoMsg=New Bulk Email Distribution has been added")
        End If
    End Sub
    Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click, RefreshBtn2.Click
        Try
            EmailName.CssClass = "fldEntry"
            ProductCodeList.CssClass = "fldEntry"
            EmailSubject.CssClass = "fldEntry"
            EmailHTML.CssClass = "fldEntry"
            EnteredSubscriberListText.CssClass = "fldEntry"
            If Me.EmailName.Text <> "" Then
                If Me.EmailName.Text = Me.uPage.db.DLookup("EmailName", "EmailDistribution", "EmailName='" & Me.EmailName.Text & "' AND EmailDistributionId <> '" & Me.EmailDistributionId.Text & "'") Then
                    uPage.FieldErrorControl(Me.EmailName, "Entered Email Name already exists, please enter another.")
                End If
            Else
                uPage.FieldErrorControl(Me.EmailName, "Email Name is mandatory")
            End If
            If Me.ProductCodeListRow.Visible Then
                uPage.ListBoxValidateMandatory(Me.ProductCodeList, "Product Code List")
            End If
            If Me.EmailSubject.Text = "" Then
                uPage.FieldErrorControl(Me.EmailSubject, "Email Subject is mandatory")
            End If

            If Me.EmailHTML.Html = "" Then
                Me.uPage.DXFieldErrorControl(Me.EmailHTML, "Email HTML is mandatory")
            End If

            If Not uPage.IsValid Then Exit Try

            Me.uPage.PopulateDataRowFromPageFields(Me.EmailDistribution.EmailDistributionRow)
            '18/12/23   James Woosnam   SIR5720 - For email address and subscriber ID lists, only check against current and pending subscribers.
            Dim validSubscriberIdsSQL As String = ""
            validSubscriberIdsSQL += "SELECT s.SubscriberId" & Environment.NewLine
            validSubscriberIdsSQL += "FROM Subscriber s" & Environment.NewLine
            validSubscriberIdsSQL += "Where s.SubscriberStatus IN ('Current','Pending')" & Environment.NewLine
            Me.EmailDistribution.EmailDistributionRow("EmailHTML") = Me.EmailHTML.Html
            Select Case Me.EmailDistribution.SubscriberSourceType
                Case SubscriberSourceTypes.EnteredSubscriberIdList
                    Me.EmailDistribution.EmailDistributionRow("SubscribedToProductCodes") = System.DBNull.Value
                    Dim subIdsInvalid As Boolean = False
                    Dim reformatedSubIds As String = ""
                    Dim SubListOriginal As String = Me.EnteredSubscriberListText.Text
                    If SubListOriginal <> "" Then
                        Try
                            If Not IsNumeric(SubListOriginal(0)) Then
                                Me.uPage.FieldErrorControl(Me.EnteredSubscriberListText, "First character must be a number")
                                Exit Try
                            End If
                            Dim IDsCSV As String = ""
                            Dim endOfNumberFound As Boolean = False
                            For i As Integer = 0 To SubListOriginal.Length - 1
                                If IsNumeric(SubListOriginal(i)) Then
                                    IDsCSV += SubListOriginal(i)
                                    endOfNumberFound = False
                                Else
                                    If Not endOfNumberFound Then IDsCSV += ","
                                    endOfNumberFound = True
                                End If
                            Next
                            If IDsCSV.Substring(IDsCSV.Length - 1, 1) = "," Then IDsCSV = IDsCSV.Substring(0, IDsCSV.Length - 2)
                            Dim subIds As String() = IDsCSV.Split(",")
                            For Each subId As String In subIds
                                If Not IsNumeric(subId) Then
                                    subIdsInvalid = True
                                Else
                                    Dim subName As String = uPage.db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & subId & " AND Subscriberid IN (" & validSubscriberIdsSQL & ")")
                                    If subName = Nothing Then
                                        uPage.FieldErrorControl(Me.EnteredSubscriberListText, "SubscriberId:" & subId & " is not a Current or Pending subsciber")
                                    Else
                                        reformatedSubIds += IIf(reformatedSubIds = "", "", ",") & subId
                                    End If
                                End If
                            Next
                        Catch ex As Exception
                            Me.uPage.FieldErrorControl(Me.EnteredSubscriberListText, "Unexpected error checking SubsciberIds:" & ex.Message)
                            subIdsInvalid = True
                        End Try

                    Else
                        subIdsInvalid = True
                    End If
                    If subIdsInvalid Then
                        uPage.FieldErrorControl(Me.EnteredSubscriberListText, "Please check the list of subscriber Ids")
                    Else
                        EmailDistribution.EmailDistributionRow("SubscriberIdList") = reformatedSubIds
                    End If
                Case SubscriberSourceTypes.EnteredEmailAddressList
                    '24/5/23    James Woosnam   SIR5642 - Allow entered SubId list and email list
                    Me.EmailDistribution.EmailDistributionRow("SubscribedToProductCodes") = System.DBNull.Value
                    Dim emailsInvalid As Boolean = False
                    Dim reformatedSubIds As String = ""
                    Dim SubListOriginal As String = Me.EnteredSubscriberListText.Text
                    If SubListOriginal <> "" Then
                        Try
                            Dim EmailsCSV As String = ""
                            Dim endOfEmailFound As Boolean = False
                            For i As Integer = 0 To SubListOriginal.Length - 1
                                If {",", " ", vbCr, vbLf}.Contains(SubListOriginal(i)) Then
                                    If i = 0 Then
                                        uPage.FieldErrorControl(Me.EnteredSubscriberListText, "Email Address list can't start with  delimiter character")
                                        Exit Try
                                    End If
                                    If Not endOfEmailFound Then EmailsCSV += ","
                                    endOfEmailFound = True
                                Else
                                    EmailsCSV += SubListOriginal(i)
                                    endOfEmailFound = False
                                End If
                            Next
                            If EmailsCSV.Substring(EmailsCSV.Length - 1, 1) = "," Then EmailsCSV = EmailsCSV.Substring(0, EmailsCSV.Length - 2)
                            Dim emails As String() = EmailsCSV.Split(",")
                            For Each email As String In emails

                                Dim subId As Integer = uPage.db.DLookup("SubscriberId", "SubscriberAddress", "AddressType = 'Email' AND AddressDescription = 'Main' AND AddressText='" & email & "'" & " AND Subscriberid IN (" & validSubscriberIdsSQL & ")")
                                If subId = Nothing Then
                                    uPage.FieldErrorControl(Me.EnteredSubscriberListText, "Email Address:" & email & " is not linked to a Current or Pending subscriber on PaDS")
                                Else
                                    reformatedSubIds += IIf(reformatedSubIds = "", "", ",") & subId
                                End If
                            Next
                        Catch ex As Exception
                            Me.uPage.FieldErrorControl(Me.EnteredSubscriberListText, "Unexpected error checking SubsciberIds:" & ex.Message)
                            emailsInvalid = True
                        End Try

                    Else
                        emailsInvalid = True
                    End If
                    If emailsInvalid Then
                        uPage.FieldErrorControl(Me.EnteredSubscriberListText, "Please check the list of subscriber emails")
                    Else
                        EmailDistribution.EmailDistributionRow("SubscriberIdList") = reformatedSubIds
                    End If
                Case SubscriberSourceTypes.CurrentSubscriptionToProducts
                    Dim comma As String = ""
                    Dim PCode As String = ""
                    For Each item As ListItem In Me.ProductCodeList.Items
                        If item.Selected = True Then
                            PCode += comma & item.Value
                            comma = ","
                        End If
                    Next
                    Me.EmailDistribution.EmailDistributionRow("SubscribedToProductCodes") = PCode
                    'Clear out SubscriberIdList if CurrentSubscriptionToProducts SubscriberSourceType
                    Me.EmailDistribution.EmailDistributionRow("SubscriberIdList") = System.DBNull.Value
            End Select
            If Me.uPage.IsValid And sender.clientid = "SaveBtn" Then Me.EmailDistribution.Save()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try

        If Me.uPage.IsValid And sender.clientid = "SaveBtn" Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?EmailDistributionId=" & Me.EmailDistribution.EmailDistributionId & "&InfoMsg=Bulk Email Distribution has been saved")
        End If
    End Sub

    Private Sub BackBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackBtn.Click, BackFromAddBtn.Click
        Response.Redirect("../Pages/pg290EmailDistributionSelect.aspx")
    End Sub

    Private Sub ClearBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?EmailDistributionId=" & Me.EmailDistributionId.Text)
    End Sub
    Dim SendTestEmailToCurrentUserAsIfFirstSubscriber As Boolean = Nothing
    Private Sub StartDistributionBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartDistributionBtn.Click
        Try
            Me.SaveBtn_Click(sender, e)
            If uPage.IsValid Then
                If Me.ConfirmStartOfDistribution.Checked Or SendTestEmailToCurrentUserAsIfFirstSubscriber Then
                    Me.EmailDistribution.StartDistribution(SendTestEmailToCurrentUserAsIfFirstSubscriber)
                Else
                    ConfirmStartOfDistributionMessageRow.Visible = True
                    Me.DistributionCountNumber.Text = Me.EmailDistribution.SubscriberRecipients.Rows.Count
                End If
            End If

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
        If Me.uPage.IsValid Then
            If Me.ConfirmStartOfDistribution.Checked Then
                Me.uPage.InfoMessage = "The emails will be sent as a batch job, <span class='logLink'><a href='./pg160BatchLogList.aspx' title='Go To Batch Log List' target='_blank'>Click Here</a></span> to check"
            End If
        End If
    End Sub
    Private Sub SendSampleBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SendSampleBtn.Click
        Try
            SendTestEmailToCurrentUserAsIfFirstSubscriber = True
            StartDistributionBtn_Click(sender, e)
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
        If uPage.IsValid Then Me.uPage.InfoMessage = "A sample email has been sent to you"

    End Sub
End Class
