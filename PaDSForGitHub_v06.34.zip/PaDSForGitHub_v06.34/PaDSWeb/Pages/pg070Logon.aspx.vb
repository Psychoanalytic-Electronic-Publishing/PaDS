﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.UserSession

'Modification History
'17/01/11  Julian Gates   Initial version
'10/05/11  Julian Gates   SIR2420 - Changed username / password resent text and reworked error message.
'22/12/11  Julian Gates   SIR2554 - Resend password message change
'11/07/12  Julian Gates   SIR2800 - Add new PEP data protection policy link.
'16/10/15  Julian Gates   SIR3982 - Change www.p-e-p.org links to support.pep-web.org
'15/01/16  Julian Gates   SIR4070 - Add entered password to Session("UserPassord") to be used to show password warning
'03/06/19  Julian Gates   SIR4850 - Change GDPR link text to PaDS has a GDPR compliant data protection policy available to read here.
'23/10/19  Julian Gates   SIR4943 - Add GroupRenewer redirect to pg462SubscriberRenewals
'1/11/19    James Woosnam   SIR4766 - Add support for spoof link
'11/12/19   James Woosnam   SIR4967-1 - SendEmailBtn_Click use email to lookup Username
'28/4/20    Julian Gates    SIR5032 - Add spanish translation
'25/8/20     James Woosnam   SIR5082 - Only reset cookie if required by Action and RedirectToUserHome changes for session cookie
'16/10/20   Julian Gates    SIR5139 - Add call to RequestPasswordBtn_Click if Action=RequestPassword
'28/01/21   Julian Gates    SIR5183 - Removed the Email Syntax check from this page.
'18/8/21    James Woosnam   SIR5279 - If CounterReportsOnly go straight to counter reports
'12/9/21    James Woosnam   SIR5315 - Don't let GroupUsers logon to PaDS or reset their password
'10/1/22    James Woosnam   SIR5242 - Give a better error and send an email to Zedra if email or username is duplcate
'11/1/22    James Woosnam   SIR5405 - Chaange page title for password reset & re-add save as conncurrency error was in 071.
'13/06/22   Julian Gates    SIR5512 - Change language translations to come from database table

Partial Class pages_pg070Logon
    Inherits System.Web.UI.Page
    Dim ds As New DataSet
    Dim StdCode As New BusinessLogic.StdCode()
    Public NewUserText As String = ""
    Public Property DisplayLanguage As BusinessLogic.UserSession.DisplayLanguages
        Get
            Return Me.Master.UserSession.DisplayLanguage
        End Get
        Set(value As BusinessLogic.UserSession.DisplayLanguages)
            Me.Master.UserSession.DisplayLanguage = value
        End Set
    End Property


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        Dim langDis As BusinessLogic.UserSession.DisplayLanguages = Me.Master.DisplayLanguageRBLSelectedValue
        '4/8/20     James Woosnam   SIR5082 - Only reset cookie if required by Action
        Dim ResetSessionCookie As Boolean = IIf(Request.QueryString("Action") = "ResetSessionCookie", True, False) ' (Not Me.IsPostBack And Not Request.QueryString("Action") = "SpoofLogon") Or (Not Me.IsPostBack And Request.QueryString("Action") = "Logout")
        Master.Initilise("Welcome to Pads", "00", "", "", "", ResetSessionCookie)
        Master.UserSession.DisplayLanguage = langDis
        Master.ShowLanguageRBL = True

        If Request.QueryString("Action") IsNot Nothing AndAlso {"SpoofToPaDSLogon".ToLower, "SpoofToPEPWebLogon".ToLower}.Contains(Request.QueryString("Action").ToLower) Then
            If Request.QueryString("UserName") = "" _
                            Or Request.QueryString("SpoofPassword") = "" _
                            Or Not IsNumeric(Request.QueryString("SpoofingUserId")) Then
                Master.WebForm.AddPageError("Invalid Spoof Logon")
            Else
                '1/11/19    James Woosnam   SIR4766 - Add support for spoof link
                '17/8/20    James Woosnam   SIR5082 - Store SessionId in, and restored from, a new session cookie
                Dim SpoofSess As New BusinessLogic.UserSession(Master.db)
                SpoofSess.Restore(InUserSessionId:="") 'restore with blank session id to generate a new one
                SpoofSess.Logon(Request.QueryString("UserName"), Request.QueryString("SpoofPassword"), True, Request.QueryString("SpoofingUserId"))
                '24/9/20    Spoof session are no longer stored in the cookie they are done by querystrig
                Me.Master.UserSession = SpoofSess
                If Request.QueryString("Action").ToLower = "SpoofToPEPWebLogon".ToLower Then
                    '25/5/21    James Woosnam   SIR5245 - Use PEPSecurity.CompleteAuthentication to complete PEPweb logon
                    '5/7/21     James Woosnam   SIR5245 - pass spoffSess rather than Master.UserSession
                    Dim peps As New BusinessLogic.PEPSecurity(Master.db, New BusinessLogic.StdCode().GetIPAddress(Request), SpoofSess)
                    Dim ReasonMsg As String = ""
                    Dim ru As New BusinessLogic.RemoteUser(SpoofSess.UserId, Master.db, SpoofSess)
                    peps.CompleteAuthentication(ru, ReasonMsg)
                    If ReasonMsg = "" Then
                        Response.Redirect(Master.db.GetParameterValue("PEPWeb2021URL") & "?sessionId=" & SpoofSess.UserSessionId)
                    Else
                        Me.Master.WebForm.AddPageError(ReasonMsg)
                    End If
                Else
                    Me.RedirectToUserHome(SpoofSess.AuthorityLevel, SpoofSess.QueryString, "Successful Spoof Login", SpoofSess)
                End If
            End If
        End If
        '8/4/21     James Woosnam   Sometimes a RequestPassword will have a logged on session which should be ignored
        If Master.UserSession.LoggedIn And Request.QueryString("Action") <> "RequestPassword" Then
            If Request.QueryString("Action") = "RedirectToUserHome" Then
                Me.RedirectToUserHome(Master.UserSession.AuthorityLevel, Master.UserSession.QueryString, Request.QueryString("InfoMsg"))
            Else
                Me.RedirectToUserHome(Master.UserSession.AuthorityLevel, Master.UserSession.QueryString, "You still have an active session so have been logged in automatically")
            End If
        End If

        If Page.IsPostBack Then
        Else
            If Request.QueryString("NewUserText") <> "" Then
                NewUserText = Request.QueryString("NewUserText")
            End If
            '16/10/20   Julian Gates    SIR5139 - Add call to RequestPasswordBtn_Click if Action=RequestPassword
            If Request.QueryString("Action") <> "" Then
                If Request.QueryString("Action") = "RequestPassword" Then
                    '10/4/21    James Woosnam   Assume this is coming from new PEPweb, SIR5390 if CallSource =""
                    If Request.QueryString("CallSource") <> "PaDS" Then Master.UserSession.Data("AfterPasswordSetupReturnToPep") = True
                    If Request.QueryString("PreviuosEmailWarningGiven") = "Yes" Then ViewState("PreviuosEmailWarningGiven") = "Yes"

                    RequestPasswordBtn_Click(sender, e)
                End If
            End If
            Me.UserName.Focus()
        End If
    End Sub

    Sub PageSetup()
        Me.LoginBtn.Text = Master.GetTranslatedText(96, 70, "Login", "Acceder")
        Me.LoginBtn.ToolTip = Master.GetTranslatedText(97, 70, "Login to PaDS", "Iniciar sesión en Pads")
        Me.RequestPasswordBtn.Text = Master.GetTranslatedText(98, 70, "Forgot Username/Password?", "¿Olvidó su usuario o contraseña?")
        Me.RequestPasswordBtn.ToolTip = Master.GetTranslatedText(99, 70, "Click here to have your password resent.", "Haga clic aquí para reenviar su contraseña.")

        Me.RequestActivateAcctBtn.Text = Master.GetTranslatedText(100, 70, "Need to Activate Account?", "¿Necesita activar su cuenta PaDS?")
        Me.RequestActivateAcctBtn.ToolTip = Master.GetTranslatedText(101, 70, "Click here to have your account activation email sent.", "Haga clic aquí para recibir el correo electrónico de activación de su cuenta.")

        Me.SendEmailBtn.Text = Master.GetTranslatedText(35, 0, "Send", "Enviar")
        Me.CancelEmailBtn.Text = Master.GetTranslatedText(62, 0, "Cancel", "Cancelar")

        Me.AddNewSubscriberBtn.Text = Master.GetTranslatedText(20, 0, "Click Here", "Haga click aquí")

        If Master.UserSession.IsAtZedraOrZedraUser Then
            Try


            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus

            Case Else
                Me.Master.WebForm.FieldValidateMandatory(Me.UserName, Master.GetTranslatedText(11, 0, "Username"))
                Me.Master.WebForm.FieldValidateMandatory(Me.Password, Master.GetTranslatedText(88, 0, "Password"))

        End Select

        Return Me.Master.WebForm.IsValid
    End Function

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub LoginBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LoginBtn.Click
        Dim logonSuccessfull As Boolean = False
        If Me.IsPageValidForStatus("") Then

            Try
                Dim ru As New BusinessLogic.RemoteUser(Me.UserName.Text, Master.db, Master.UserSession)
                Select Case ru.UserStatus
                    Case BusinessLogic.RemoteUser.UserStates.Emailed
                        '20/12/21   James Woosnam   SIR5390 - Enhanced message if user already emailed in Logon
                        Dim emailURL As String = Master.db.GetParameterValue("WebSiteURL") & "/Pages/pg070Logon.aspx?PreviuosEmailWarningGiven=Yes&Action=RequestPassword&CallSource=PaDS&" & Me.Master.UserSession.QueryString
                        If CDate(ru.EmailAuthenticationSentDateTime) < Now.AddHours(ru.HoursToConfirmNewEmail * -1) Then
                            Throw New Exception("The password reset email sent to this user has now expired please <a href='" & emailURL & "'>click here</a> to re-send it")
                        End If
                        Throw New Exception("A password reset email was sent " & ru.TimeDescSinceEmailSent & " ago, please use the link in the email.  If the email hasn't been received please <a href='" & emailURL & "'>click here</a> to re-send it")
                End Select

                Me.Master.UserSession.Logon(Me.UserName.Text, Me.Password.Text)
                'new session after login so need to reset langauge to what is choosen on page
                Me.Master.UserSession.DisplayLanguage = Me.Master.DisplayLanguageRBLSelectedValue
                Me.Master.WriteSessionLog("Successfull Logon", Me.UserName.Text)

                logonSuccessfull = True
                Me.Master.UserSession.SessionCookie.Save(Me.Response, False)
                Me.Master.AddAdditionalInfoForlog("Logon Successfull")

            Catch ex As Exception
                If ex.Message.Contains("UserError:") Then
                    Me.Master.WebForm.AddPageError(ex)
                Else
                    Me.Master.WebForm.AddPageError(New Exception(ex.Message, ex))
                End If
            End Try

        End If
        If logonSuccessfull Then
            Me.RedirectToUserHome(Me.Master.UserSession.AuthorityLevel, Master.UserSession.QueryString, "")
        End If
    End Sub
    Sub RedirectToUserHome(AuthorityLevel As BusinessLogic.UserSession.AuthorityLevels, QryStr As String, InfoMsg As String, Optional SpoofSess As BusinessLogic.UserSession = Nothing)
        '4/8/20     James Woosnam   SIR5082 - RedirectToUserHome changes for session cookie
        QryStr = "?" & QryStr & IIf(InfoMsg <> "", "&InfoMsg=" & InfoMsg, "")
        Select Case AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                '15/01/16  Julian Gates   SIR4070 - Add entered password to Session("UserPassord") to be used to show password warning
                Session("UserPassord") = Me.Password.Text
                Me.Master.Response.Redirect("pg100HomeAdmin.aspx" & QryStr)
            Case BusinessLogic.UserSession.AuthorityLevels.GroupAdmins
                '18/8/21    James Woosnam   SIR5279 - If CounterReportsOnly go straight to counter reports
                If SpoofSess IsNot Nothing AndAlso CBool(SpoofSess.Data("CounterReportsOnly")) Then
                    Me.Master.Response.Redirect("pg600CounterReports.aspx" & QryStr)
                Else
                    Me.Master.Response.Redirect("pg490GroupSubscriberSelect.aspx" & QryStr)
                End If
            Case BusinessLogic.UserSession.AuthorityLevels.IndividualSubscriber
                Dim targetSubscriberId As String = Nothing
                If SpoofSess IsNot Nothing Then
                    targetSubscriberId = SpoofSess.Data("SubscriberId")
                Else
                    targetSubscriberId = Me.Master.UserSession.Data("SubscriberId")
                End If
                If targetSubscriberId = Nothing Then
                    'can't open this page without sub id
                    Me.Master.UserSession.SessionCookie.Save(Me.Response, True)
                    Me.Master.UserSession.Logout()
                Else
                    Me.Master.Response.Redirect("pg101Home.aspx" & QryStr)
                End If
            Case AuthorityLevels.GroupUser
                '12/9/21    James Woosnam   SIR5315 - Don't let GroupUsers logon directly into PaDS
                Master.WebForm.AddPageError("Group users can't logon directly to PaDS.")
                Master.UserSession.Logout()'3/11/21 James Force logoff
            Case BusinessLogic.UserSession.AuthorityLevels.User
                Me.Master.Response.Redirect("pg100HomeAdmin.aspx" & QryStr)
                '23/10/19  Julian Gates   SIR4943 - Add GroupRenewer redirect to pg462SubscriberRenewals
            Case BusinessLogic.UserSession.AuthorityLevels.GroupRenewer
                Me.Master.Response.Redirect("pg462SubscriberRenewals.aspx" & QryStr)
        End Select

    End Sub
    Protected Sub RequestPasswordBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RequestPasswordBtn.Click
        Master.PageTitle = "Password Reset Request"
        Me.LogonTable.Visible = False
        Me.EnterPasswordTable.Visible = True
        Me.ResendPasswordTextRow.Visible = True
        Me.EmailAddress.Focus()
        Me.Master.AddAdditionalInfoForlog("RequestPasswordBtn_Click")
    End Sub

    Protected Sub RequestActivateAcctBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RequestActivateAcctBtn.Click
        Me.LogonTable.Visible = False
        Me.EnterPasswordTable.Visible = True
        Me.ActivateAccountTextRow.Visible = True
        Me.EmailAddress.Focus()
        Me.Master.AddAdditionalInfoForlog("RequestActivateAcctBtn_Click")
    End Sub

    Protected Sub SendEmailBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SendEmailBtn.Click
        Master.PageTitle = "Password Reset Request"
        If Me.EmailAddress.Text = "" Then
            Me.Master.WebForm.AddPageError(Master.GetTranslatedText(104, 70, "Email Address is mandatory.", "La dirección de correo electrónico es obligatoria."))
            Exit Sub
        End If
        Try
            '11/12/19   James Woosnam   SIR4967-1 - SendEmailBtn_Click use email to lookup Username
            '10/1/22    James Woosnam   SIR5242 - Give a better error and send an email to Zedra if email or username is duplcate
            Dim sql As String = "SELECT * FROM RemoteUser WHERE UserStatus IN ('Active','Emailed') AND EmailAddress='" & Me.EmailAddress.Text & "'"
            Dim tUsers As DataTable = Master.db.GetDataTableFromSQL(sql)
            Select Case tUsers.rows.Count
                Case 0
                    Me.Master.WebForm.AddPageError(Master.GetTranslatedText(105, 70, "Email address not linked to a User record.", "Dirección de correo electrónico no vinculada a un registro de usuario."))
                    Exit Sub
                Case 1
                Case Else
            End Select

            Dim rUser As DataRow = tUsers.Rows(0)
            Dim dupUserNameCount As Integer = Master.db.DLookup("Count(*)", "RemoteUser", "UserStatus IN ('Active','Emailed') AND UserName='" & rUser("UserName") & "'")
            If tUsers.Rows.Count > 1 Or dupUserNameCount > 1 Then
                Dim msg As String = "This Email address is linked to multiple users.  Support will fix the problem and send you an email."
                Try
                    Dim em As New BusinessLogic.Email(Master.db)
                    em.SendErrorEmail("PaDS - Duplicate email address on password reset request", "Email:'" & Me.EmailAddress.Text & "' is linked to " & tUsers.Rows.Count & " Active or Emails users, and UserName:'" & rUser("UserName") & "' is linked to " & dupUserNameCount & " users.The user was given the following error message: " & msg)
                Catch ex As Exception
                End Try
                Me.Master.WebForm.AddPageError(Master.GetTranslatedText(106, 70 _
                                        , msg _
                                        , "Esta dirección de correo electrónico está vinculada a varios usuarios. El soporte solucionará el problema y le enviará un correo electrónico."))
                Exit Sub
            End If

            Dim UserName As String = rUser("UserName")
            Dim ru As New BusinessLogic.RemoteUser(UserName, Master.db, Master.UserSession)
            Try
                Me.Master.UserSession.UserSessionRow("UserId") = ru.UserId  'populate to help debugging
                Me.Master.UserSession.UserSessionRow("UserName") = ru.UserName  'As user isn't logged-on user userId in Username
                '    Me.Master.UserSession.Save()21/12/21 - commented out as may be causing concurrency error, save not needed before WriteSessionLog
                '11/1/22    James Woosnam   SIR5405 - readd save as conncurrency error was in 071.
                Me.Master.UserSession.Save()
            Catch ex As Exception
                Me.Master.AddAdditionalInfoForlog("Update Session Info failed:" & ex.Message)
            End Try

            If ru.AuthorityLevel = AuthorityLevels.GroupUser Then
                '12/9/21    James Woosnam   SIR5315 - Don't let GroupUsers reset their password
                Me.Master.WebForm.AddPageError("GroupUsers can't reset their own password.")
                Exit Sub
            End If
            Select Case ru.UserStatus
                Case BusinessLogic.RemoteUser.UserStates.Emailed
                    '20/12/21   James Woosnam   SIR5390 - Enhanced message if user already emailed in Logon
                    If CDate(ru.EmailAuthenticationSentDateTime) < Now.AddHours(ru.HoursToConfirmNewEmail * -1) Then
                        'pevious email expired so ok to send new
                    Else
                        If Me.ViewState("PreviuosEmailWarningGiven") = "Yes" Then
                        Else
                            '25/11/22  James Woosnam    Add translation
                            Me.Master.WebForm.AddPageError(String.Format(Master.GetTranslatedText(273, 70, "A password reset email was sent {0} ago, please use the link in the email.  If the email hasn't been received, and you are sure that it is not in your spam folder, then please press send again to re-send it", "Se envió un correo electrónico de restablecimiento de contraseña hace {0}, use el enlace en el correo electrónico. Si el correo electrónico no se ha recibido y está seguro de que no está en su carpeta de correo no deseado, presione enviar nuevamente para volver a enviarlo."), ru.TimeDescSinceEmailSent))
                            Me.ViewState("PreviuosEmailWarningGiven") = "Yes"
                            Exit Sub
                        End If
                    End If
            End Select

            ru.ResetPasswordAndEmail()
            '   Me.LogonTable.Visible = True
            '   Me.EnterPasswordTable.Visible = False
            Me.EnterPasswordTable.Visible = False
            Me.RenewalEmailSentMessageTable.Visible = True
            Me.RenewalEmailSentMessage.Text = String.Format(Master.GetTranslatedText(107, 70, "A PaDS reactivation email has been sent to {0}"), Me.EmailAddress.Text)
            Me.EmailAddress.Text = ""
            Me.UserName.Focus()
            Me.Master.AddAdditionalInfoForlog("Password Reset Email Sent")

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(String.Format(Master.GetTranslatedText(108, 70 _
                                                       , "A password renewal email can't be sent, please contact "), Master.db.SupportEmailLink), ex))
        End Try
    End Sub

    Protected Sub CancelEmailBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelEmailBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub

    Protected Sub AddNewSubscriberBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AddNewSubscriberBtn.Click
        Me.Master.Response.Redirect("pg117AddNewSubscriber.aspx?DisplayLanguage=" & Me.Master.DisplayLanguageRBLSelectedValue)
    End Sub
End Class

