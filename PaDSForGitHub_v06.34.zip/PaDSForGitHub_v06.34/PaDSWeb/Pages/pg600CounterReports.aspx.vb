﻿Imports System.Data.SqlClient
Imports System.Data
Imports BusinessLogic.CounterReport
'Modification History
'26/02/2021 Julian Gates  Initial version
'15/11/23	James Woosnam	SIR5710 - Only allow one calendar year at a time
'30/10/24   Julian Gates    Change ReportingParentSubscriberId field to devexpress control
'19/11/24   James Woosnam   SIR5761 - Reworked for Counter v5.1


Partial Class Pages_pg600CounterReports
    Inherits System.Web.UI.Page
    Dim TargetReportingParentSubscriber As BusinessLogic.Subscriber = Nothing
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Master.Initilise("Counter Reports", "03a", "")

        Select Case Me.Master.UserSession.AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.GroupAdmins
                If Me.Master.UserSession.Data("PrimaryGroupSubscriberId") Is Nothing Then
                    Response.Redirect("pg070Logon.aspx?InfoMsg=PrimaryGroupSubscriberId not populated")
                End If
                'all fine
            Case BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                'all fine
            Case Else
                Response.Redirect("pg070Logon.aspx")
        End Select

        If Me.Master.UserSession.Data("PrimaryGroupSubscriberId") IsNot Nothing Then
            Me.TargetReportingParentSubscriber = New BusinessLogic.Subscriber(CInt(Me.Master.UserSession.Data("SubscriberId")), Master.db, Master.UserSession)
        End If

        If Page.IsPostBack Then

        Else
            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            ViewState("IsMetricTypeChanged") = "False"
        End If
    End Sub
    '14/11/23   Use PageSetupTemp to just show this message
    Sub PageSetupTemp()
        InfoMsgTemp.Text = "Counter reports are temporarily unavailable.  Please contact PEP support for more information."
    End Sub
    Sub PageSetup()
        If Me.TargetReportingParentSubscriber Is Nothing Then
            Me.Master.PageTitle = "Counter Reports"
            Me.SelectReportingParentSubscriberRow.Visible = True
        Else
            Me.SelectReportingParentSubscriberRow.Visible = False
            Me.Master.PageTitle = Me.TargetReportingParentSubscriber.SubscriberName & " - " & "Counter Reports"
        End If
        Dim periods As List(Of DateTime) = New BusinessLogic.CounterReport(Master.db, Master.UserSession).Periods

        If Not Page.IsPostBack Then
            If Me.SelectReportingParentSubscriberRow.Visible Then
                '30/10/2024     Julian Gates    Change ReportingParentSubscriberId field to devexpress control
                Me.Master.WebForm.PopulateDevExpressDropDownListFromSQL(Me.ReportingParentSubscriberId, "SELECT DISTINCT Value = l.Institution_Id ,Text = l.Institution_Name FROM CounterReportInstitution l ORDER BY l.Institution_Name", "All")
                Me.ReportingParentSubscriberId.Focus()
            End If

            '17/7/24: Required reports Tasha Mellins-Cohen (tasha@countermetrics.org)
            'Based on the HostTypes identified above, PEP - Web needs to deliver the following
            '● Platform Report, And the PR
            '       P1 standard view
            '● Database Report, And the DR
            '       D1 And DR
            '       D2 standard views
            '● Title Report, And both the TR
            '       B And TR
            '      J series of standard views
            'PEP-Web may elect To also oﬀer the Item Report, but this is not mandatory for Database Aggregated Or Multimedia Collection hosts.
            Me.Master.WebForm.PopulateRadioButtonListFromSql(Me.CounterReportsList, "SELECT Report_ID AS Value," _
                                                                                        & "     Report_ID + ' - ' + Report_Name AS Text" _
                                                                                        & " FROM CounterReport" _
                                                                                        & " WHERE ReportStatus = 'Active'" _
                                                                                        & " ORDER BY DisplayOrder")
            If Not Me.SelectReportingParentSubscriberRow.Visible Then
                Me.CounterReportsList.Focus()
            End If

            Dim Sep2021Index As Integer = 0
            For Each dt As DateTime In periods
                Me.UsageBeginDate.Items.Add(New ListItem(dt.ToString("yyyy-MM MMM"), dt))
                If dt = CDate("01-sep-2021") Then Sep2021Index = Me.UsageBeginDate.Items.Count - 1
            Next
            Me.UsageBeginDate.SelectedIndex = Sep2021Index 'Set start to sep 2021, until we get 24 months after sep 21, then just last 24 months
            If Me.UsageBeginDate.Items.Count > (24) Then Me.UsageBeginDate.SelectedIndex = Me.UsageBeginDate.Items.Count - 24
            For i As Integer = periods.Count - 1 To 0 Step -1
                Me.UsageEndDate.Items.Add(New ListItem(periods(i).ToString("yyyy-MM MMM"), periods(i)))
            Next
            Me.UsageEndDate.SelectedIndex = 0



        Else
            If Me.CounterReportsList.SelectedValue <> Nothing Then
                Me.SelectedCounterReportName.Text = Me.CounterReportsList.SelectedItem.Text
                Me.SelectedReportDetails.Text = Me.Master.db.DLookup("Details", "CounterReport", "Report_ID='" & Me.CounterReportsList.SelectedValue & "'")
                Me.ReportCriteriaPanel.Visible = True
                Me.UsageBeginDate.Focus()


            End If
        End If
    End Sub


    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '    '****************************************************** 
        '    'Description: Validate page fields and show error message 
        '    '****************************************************** 
        Select Case validatorStatus
            Case Else

                If Me.DateUsageRow.Visible Then
                    If Me.UsageBeginDate.SelectedValue <> Nothing And Me.UsageEndDate.SelectedValue <> Nothing Then
                        If CDate(Me.UsageBeginDate.SelectedValue) > CDate(Me.UsageEndDate.SelectedValue) Then
                            Me.Master.WebForm.AddPageError("Usage Begin Date must be before Usage End Date")
                        End If
                    End If
                End If
                If Me.MetricTypeRow.Visible Then
                    If Me.MetricTypeList.SelectedValue = "" Then
                        Me.Master.WebForm.ListBoxValidateMandatory(Me.MetricTypeList, "Choose one or more from Metric Type List")
                    Else
                        Me.MetricTypeList.CssClass = SetListBoxDefaultCSS()
                    End If
                End If
                If Me.DataTypeRow.Visible Then
                    If Not Me.CounterReportsList.SelectedValue = "PR_P1" Then
                        If Me.DataTypeList.SelectedValue = "" Then
                            Me.Master.WebForm.ListBoxValidateMandatory(Me.DataTypeList, "Choose one or more from Data Type List")
                        Else
                            Me.DataTypeList.CssClass = SetListBoxDefaultCSS()
                        End If
                    End If
                End If
                If Me.AccessTypeRow.Visible Then
                    If Me.AccessTypeList.SelectedValue = "" Then
                        Me.Master.WebForm.ListBoxValidateMandatory(Me.AccessTypeList, "Choose one or more from Access Type List")
                    Else
                        Me.AccessTypeList.CssClass = SetListBoxDefaultCSS()
                    End If
                End If

        End Select

        Return Me.Master.WebForm.IsValid
    End Function

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)
    End Sub

    Private Sub SubmitReportBtn_Click(sender As Object, e As EventArgs) Handles SubmitReportBtn.Click
        If Me.IsPageValidForStatus("") Then
            Dim lReportingParentSubscriberId As Integer = 0

            If Me.SelectReportingParentSubscriberRow.Visible Then
                If Me.ReportingParentSubscriberId.Value.ToString() <> "All" Then
                    lReportingParentSubscriberId = Me.ReportingParentSubscriberId.Value
                Else
                    Me.Master.WebForm.FieldErrorControl(Me.ReportingParentSubscriberId, "As an admin user you must select one Reporting Parent Subsciber")
                    Exit Sub
                End If
            Else
                lReportingParentSubscriberId = Me.TargetReportingParentSubscriber.SubscriberId
            End If
            Dim rep As New BusinessLogic.CounterReport(Me.CounterReportsList.SelectedValue, lReportingParentSubscriberId, Me.UsageBeginDate.SelectedValue, Me.UsageEndDate.SelectedValue, Master.db, Master.UserSession, ViewState("IsMetricTypeChanged"))
            Try
                For Each i As Integer In Me.MetricTypeList.GetSelectedIndices
                    rep.Metrics.Add([Enum].Parse(GetType(ReportMetricTypes), Me.MetricTypeList.Items(i).Value))
                Next
                If Me.DataTypeIncludeColumn.Checked Then rep.Attributes.Add([Enum].Parse(GetType(ReportAttributeTypes), "Data_Type"))
                If Me.YOPIncludeColumn.Checked Then rep.Attributes.Add([Enum].Parse(GetType(ReportAttributeTypes), "YOP"))
                If Me.AccessTypeIncludeColumn.Checked Then rep.Attributes.Add([Enum].Parse(GetType(ReportAttributeTypes), "Access_Type"))
                If Me.AccessMethodIncludeColumn.Checked Then rep.Attributes.Add([Enum].Parse(GetType(ReportAttributeTypes), "Access_Method"))

                For Each i As Integer In Me.DataTypeList.GetSelectedIndices
                    rep.FilterDataTypes.Add(Me.DataTypeList.Items(i).Value)
                Next
                For Each i As Integer In Me.AccessMethodList.GetSelectedIndices
                    rep.FilterAccessMethods.Add(Me.AccessMethodList.Items(i).Value)
                Next
                For Each i As Integer In Me.AccessTypeList.GetSelectedIndices
                    rep.FilterAccessTypes.Add(Me.AccessTypeList.Items(i).Value)
                Next
                Me.YOPText.CssClass = "fldEntry"
                If Me.YOPText.Text <> "" Then
                    If Not IsNumeric(Me.YOPText.Text) Then
                        Me.YOPText.CssClass = "fldEntryError"
                    Else
                        If Me.YOPText.Text.Length <> 4 OrElse CInt(Me.YOPText.Text) < 1850 Or CInt(Me.YOPText.Text) > Now.Year Then
                            Me.YOPText.CssClass = "fldEntryError"
                        End If
                    End If
                    If Me.YOPText.CssClass = "fldEntryError" Then
                        Master.WebForm.AddPageError("YOP must be a 4 digit year between 1850 and " & Now.Year)
                    End If
                End If


                If Not Me.Master.WebForm.IsValid Then Exit Try

                rep.FilterYOP = Me.YOPText.Text
                rep.ExcludeMonthlyDetails = Me.ExcludeMonthlyDetails.Checked
                rep.BuildSQL()
                rep.BuildReport()
                Try
                    Dim logs As New BusinessLogic.Logs(Master.db, Master.UserSession)
                    logs.LogErrorMessage(New Exception("CountSQL:" & rep.ReportSQL), False)
                Catch ex As Exception
                End Try
                Me.SQL.Text = rep.ReportSQL.Replace(Environment.NewLine, "<br>")

                'rep = New BusinessLogic.CounterReport()

            Catch ex As Exception
                Me.Master.WebForm.AddPageError(New Exception("Incorrect report analysis. Report spreadsheet criteria error." & IIf(Me.Master.db.IsOnLiveServer, "", ex.Message), ex))
                Try
                    Dim em As New BusinessLogic.Email(Me.Master.db)
                    Dim msg As String = ""
                    msg += "Error=" & ex.Message & Environment.NewLine
                    Try
                        msg += "UserSessionId=" & Me.Master.UserSession.UserSessionId & Environment.NewLine
                        msg += "User=" & Me.Master.UserSession.UserFullName & Environment.NewLine
                        msg += "lReportingParentSubscriberId=" & lReportingParentSubscriberId & Environment.NewLine
                        msg += "SQL=" & rep.ReportSQL & Environment.NewLine
                    Catch ex2 As Exception
                        msg += "ErrorGettingOtherInfo=" & ex2.Message & Environment.NewLine
                    End Try
                    em.SendErrorEmail("Counter report failed", msg)
                Catch ex1 As Exception
                End Try
            End Try
            If Me.Master.WebForm.IsValid Then
                Master.WebForm.PopOpenFileBytes(rep.Report_Name & ".xlsx", rep.ReportByteArray)
            End If
            'Me.Master.WebForm.OpenPopupWorkbook(rep.ExcelWorkBook)
        End If
    End Sub

    Private Sub CancelAddBtn_Click(sender As Object, e As EventArgs) Handles CancelBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?" & Me.Master.UserSession.QueryString)
    End Sub

    Private Sub BackToAdminReportsBtn_Click(sender As Object, e As EventArgs) Handles BackToAdminReportsBtn.Click
        Response.Redirect("../Pages/pg450Reports.aspx?" & Me.Master.UserSession.QueryString)
    End Sub

    Private Function GetListHeightForRows(ByVal NoOfRows As Integer) As Integer
        Dim extraLines As Integer = 0
        Select Case NoOfRows
            Case 1, 2, 3
                extraLines = (100 / 6)
        End Select
        Return (100 / 6 * NoOfRows) + extraLines
    End Function

    Private Function SetListBoxDefaultCSS() As String
        Dim listBoxCSS As String
        listBoxCSS = "fldEntry"
        Return listBoxCSS
    End Function

    Function GetSelectedItems(ByVal ListBox As System.Web.UI.WebControls.ListBox,
                             ByVal TableName As String) As DataTable

        Dim tbl As New DataTable(TableName)
        tbl.Columns.Add("Value")
        tbl.Columns.Add("Name")
        Dim i As Long = 0
        Try

            Do While i < ListBox.Items.Count
                If ListBox.Items(i).Selected Then
                    Dim row As DataRow = tbl.NewRow
                    row.Item("Value") = ListBox.Items(i).Value
                    row.Item("Name") = ListBox.Items(i).Text
                    tbl.Rows.Add(row)
                End If
                i = i + 1
            Loop
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured.  Please contact support", ex))
        End Try
        Return tbl
    End Function

    Private Sub CounterReportsList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CounterReportsList.SelectedIndexChanged
        Try
            Dim RepId As String = CounterReportsList.SelectedValue.ToUpper
            'Populate metric list
            Dim metTyps As Array = System.Enum.GetValues(GetType(ReportMetricTypes))
            Dim metTypsToShow As New List(Of String)
            Me.MetricTypeList.Items.Clear()
            Select Case RepId
                Case "PR"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Title_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Title_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Searches_Platform.ToString)
                Case "PR_P1"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Title_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Searches_Platform.ToString)
                Case "DR"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Title_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Title_Requests.ToString)
                    '   Me.MetricTypeList.Items.Add(ReportMetricTypes.Searches_Automated.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Searches_Regular.ToString)
                    '   Me.MetricTypeList.Items.Add(ReportMetricTypes.Searches_Federated.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Limit_Exceeded.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.No_License.ToString)
                Case "DR_D1"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Requests.ToString)
                    '   Me.MetricTypeList.Items.Add(ReportMetricTypes.Searches_Automated.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Searches_Regular.ToString)
                 '   Me.MetricTypeList.Items.Add(ReportMetricTypes.Searches_Federated.ToString)
                Case "DR_D2"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Limit_Exceeded.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.No_License.ToString)
                Case "TR"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Title_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Title_Requests.ToString)

                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Limit_Exceeded.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.No_License.ToString)
                Case "TR_B1"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Title_Requests.ToString)
                Case "TR_B2"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Limit_Exceeded.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.No_License.ToString)
                Case "TR_B3"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Requests.ToString)

                Case "TR_J1"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Requests.ToString)
                Case "TR_J2"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Limit_Exceeded.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.No_License.ToString)
                Case "TR_J3"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Title_Investigations.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Title_Requests.ToString)
                Case "TR_J4"
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Unique_Item_Requests.ToString)
                    Me.MetricTypeList.Items.Add(ReportMetricTypes.Total_Item_Requests.ToString)
                Case Else

            End Select
            For Each itm As ListItem In Me.MetricTypeList.Items
                itm.Selected = True
            Next

            Me.MetricTypeList.Height = GetListHeightForRows(Me.MetricTypeList.Items.Count)

            Me.MetricTypeList.Enabled = {"PR", "TR", "DR"}.Contains(RepId)

            'DataType selection
            Me.DataTypeList.Items.Clear()
            Me.DataTypeList.Items.Add("Book")
            '  Me.DataTypeList.Items.Add("Book_Segment")'Only needed for item level reports which are optional
            '  Me.DataTypeList.Items.Add("Article")'Only needed for item level reports which are optional
            Me.DataTypeList.Items.Add("Journal")
            Me.DataTypeList.Items.Add("Multimedia")
            Select Case Me.CounterReportsList.SelectedValue
                Case "DR", "DR_D1", "DR_D2"
                    Me.DataTypeList.Items.Add("Database_Aggregated")
                Case "PR"
                    Me.DataTypeList.Items.Add("Platform")
            End Select

            Me.DataTypeList.Height = GetListHeightForRows(Me.DataTypeList.Items.Count)
            Me.DataTypeRow.Visible = {"PR", "TR", "DR"}.Contains(RepId) Or RepId.Contains("TR")
            Me.DataTypeIncludeColumn.Checked = {"PR", "PR_P1", "TR", "TR_B1", "TR_B2", "TR_B3", "DR"}.Contains(RepId)
            Me.DataTypeIncludeColumn.Enabled = {"PR", "TR", "DR"}.Contains(RepId)
            For Each itm As ListItem In Me.DataTypeList.Items
                Select Case RepId
                    Case "PR"
                        itm.Selected = True
                    Case "TR"
                        If itm.Value = "Multimedia" Then
                            itm.Selected = False
                        Else
                            itm.Selected = True
                        End If
                    Case "TR_B1", "TR_B2", "TR_B3"
                        itm.Selected = itm.Value = "Book"
                    Case "TR_J1", "TR_J2", "TR_J3", "TR_J4"
                        itm.Selected = itm.Value = "Journal"

                    Case Else
                        itm.Selected = True
                End Select
            Next
            Me.DataTypeList.Enabled = {"PR", "TR", "DR"}.Contains(RepId)

            'Access Method selection
            Me.AccessMethodRow.Visible = True
            Me.AccessMethodIncludeColumn.Checked = {"PR", "TR", "DR"}.Contains(RepId)
            Me.AccessMethodIncludeColumn.Enabled = {"PR", "TR", "DR"}.Contains(RepId)
            For Each itm As ListItem In Me.AccessMethodList.Items
                itm.Selected = itm.Value = "Regular" Or {"PR", "TR", "DR"}.Contains(RepId)
            Next
            Me.AccessMethodList.Enabled = {"PR", "TR", "DR"}.Contains(RepId)

            'Access Type selection
            Me.AccessTypeRow.Visible = RepId.Contains("TR")
            Me.AccessTypeIncludeColumn.Enabled = {"TR"}.Contains(RepId)
            Me.AccessTypeIncludeColumn.Checked = {"TR", "TR_B3", "TR_J3"}.Contains(RepId)
            For Each itm As ListItem In Me.AccessTypeList.Items
                Select Case RepId
                    Case "TR_B1", "TR_J1", "TR_J4"
                        itm.Selected = itm.Value = "Controlled"
                    Case Else
                        itm.Selected = True
                End Select
            Next
            Me.AccessTypeList.Enabled = RepId = "TR"

            'Yop selection
            Me.YOPText.CssClass = "fldEntry"
            Me.YOPText.Text = ""
            Me.YOPRow.Visible = RepId.Contains("TR")
            Me.YOPIncludeColumn.Checked = {"TR", "TR_B1", "TR_B2", "TR_B3", "TR_J4"}.Contains(RepId)
            Me.YOPIncludeColumn.Enabled = {"TR"}.Contains(RepId)
            Me.YOPText.Enabled = {"TR"}.Contains(RepId)
            If {"PR", "DR"}.Contains(RepId) Then YOPText.Text = ""

            'Exclude Monthly Details selection
            Me.ExcludeMonthlyDetails.Checked = False
            Me.ExcludeMonthlyDetails.Enabled = {"PR", "TR", "DR"}.Contains(RepId)

            ViewState("IsMetricTypeChanged") = "False"
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured.  Please contact support", ex))
        End Try
    End Sub

    Private Sub MetricTypeList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles MetricTypeList.SelectedIndexChanged
        Select Case CounterReportsList.SelectedValue.ToUpper
            Case "PR", "TR"
                ViewState("IsMetricTypeChanged") = "True"
        End Select
    End Sub
    Private Sub ReportingParentSubscriberId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ReportingParentSubscriberId.SelectedIndexChanged
        Me.CounterReportsList.Focus()
    End Sub

    Private Sub SubmitPopulateUserActivityLog_Click(sender As Object, e As EventArgs) Handles SubmitPopulateUserActivityLog.Click
        Try
            Dim BatchJob As New BusinessLogic.BatchJob(Me.Master.db)
            BatchJob.SubmittedByUserSessionId = Me.Master.UserSession.UserSessionIdGUID
            BatchJob.CreateBatchJobEntry("PopulateUserActivityLog", Me.Master.db)
        Catch ex As Exception
            Me.Master.WebForm.AddPageError("SubmitPopulateUserActivityLog_Click failed:" & ex.Message)
        End Try
        Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=Add latest logs to UserActivityLog submitted. This will take several minutes to complete see batch log")

    End Sub


End Class
