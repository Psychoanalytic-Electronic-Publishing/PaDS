﻿
//Modification History
//25-5-11 Julian Gates Set internalLink to true to stop confirmExit being triggered
//11-9-12 Julian Gates SIR2861 - Modified  var ofrm = document.forms['aspnetForm'] to allow script to work in all browsers.

var reqXML;

function LoadXMLDoc(url) {
    if (window.XMLHttpRequest) { //Mozilla, Firefox, Opera 8.01, Safari
        reqXML = new XMLHttpRequest();
        reqXML.onreadystatechange = BuildXMLResults;
        reqXML.open("GET", url, true);
        reqXML.send(null);
    }
    else if (window.ActiveXObject) { //IE
        reqXML = new ActiveXObject("Microsoft.XMLHTTP");
        if (reqXML) {
            reqXML.onreadystatechange = BuildXMLResults;
            reqXML.open("GET", url, true);
            reqXML.send();
        }
    }
    else { //Older Browsers
        alert("Your Browser does not support Ajax!");
    }
}

function BuildXMLResults() {
    if (reqXML.readyState == 4) { //completed state
        if (reqXML.status == 200) { //We got a sucess page back

            //Check to verify the message from the server
            if (reqXML.responseText.indexOf("Session Updated - Next Timeout:") == 0) {
                window.status = reqXML.responseText; //display the message in the status bar
                SetTimer(); //restart timer
            }
            else {
                //display that that session expired
                //alert("Your session appears to have expired. You may loose your current data.");
            }
        }
        else {
            //display server code not be accessed
            //alert("There was a problem retrieving the XML data:\n" + reqXML.statusText);
        }
    }
}

function SubmitForm() {
    var ofrm = document.forms['aspnetForm']
    //25-5-11 Julian Gates Set internalLink to true to stop confirmExit being triggered
    internalLink = true;
    ofrm.submit()
}

var timerObj;
function SetSessionTimer() {

    var ofrm = document.forms['aspnetForm']
    if (ofrm['ctl00_SessionTimeValue'].value != '') {
        
        var dblTimeOutValue = parseInt(ofrm['ctl00_SessionTimeValue'].value)
        var dblMinutes = dblTimeOutValue + 1;
        //set timer to call function to submit form
        timerObj = setTimeout("SubmitForm()", 1000 * 60 * dblMinutes);
    }
}

//start the timer
SetSessionTimer();