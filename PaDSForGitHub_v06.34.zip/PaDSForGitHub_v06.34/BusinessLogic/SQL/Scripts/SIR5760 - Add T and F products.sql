begin tran
declare @NowDate datetime = '01-sep-2024'
declare @User varchar(20) = 'jwoosnam'
declare @CompanyID int =5
declare @SubscriberId int = 29005
select distinct
o.OrderNumber 
into #o
from SalesOrder o
where o.PrimaryProductCode like 'TF_%'
select * from SalesOrder where  ordernumber in (select ordernumber from #o)

select ContentSetId
into #cs
from ProductContentSet
where ProductCode like 'tf_%'
--select * from ContentSet where ContentSetId in (select * from #cs)


delete from Cashbook where ordernumber in (select ordernumber from #o)
delete from SalesOrderLinePart where ordernumber in (select ordernumber from #o)
delete from SalesOrderLine where ordernumber in (select ordernumber from #o)
delete from SalesOrder where ordernumber in (select ordernumber from #o)

delete from ProductContentSet where ProductCode like 'tf_%'
delete from ProductAffiliateRate where ProductCode like 'tf_%'
delete from ProductQualifyingProduct where ProductCode like 'tf_%'
delete from ProductRate where ProductCode like 'tf_%'
delete from Product where ProductCode like 'tf_%'

delete from ContentSetAccessClassification where ContentSetId in (select ContentSetId from #cs)
delete from ContentSetSource where ContentSetId in (select ContentSetId from #cs)
delete from ContentSetSourceItem where ContentSetSourceId in (select ContentSetSourceId from ContentSetSource where ContentSetId in (select ContentSetId from #cs))
delete from ContentSet where ContentSetId in (select ContentSetId from #cs)

DELETE FROM RemoteUserRights WHere RightsToId = @SubscriberId and RightsType='Subscriber'
DELETE FROM subscriber WHere SubscriberId = @SubscriberId 

IF @CompanyID = 5
BEGIN
	DELETE FROM CompanyAccount WHERE CompanyId = @CompanyID 
	DELETE FROM CompanyBankAccount WHERE CompanyId = @CompanyID 
	DELETE FROM Company WHERE CompanyId = @CompanyID 
	delete from RemoteUserRights where RightsType  = 'Company' and RightsToId = @CompanyID 
	delete from RemoteUserRights where RightsType  = 'Subscriber' and RightsToId = @SubscriberId 
	
	INSERT INTO Company (
	CompanyId
	,CompanyName
	,CompanyOfficer
	,CurrencyCode
	,BuildingStreet
	,Town
	,County
	,PostCode
	,CountryId
	,TelephoneNumber
	,FaxNumber
	,Email
	,RegisteredOfficeName
	,RegisteredOfficeBuildingStreet
	,RegisteredOfficeTown
	,RegisteredOfficeCounty
	,RegisteredOfficePostCode
	,RegisteredOfficeCountryId
	,RegisteredOfficeTelephoneNumber
	,RegisteredOfficeFaxNumber
	,RegistrationNumber
	,Notes
	,VATCode
	,VATNumber
	,LimitedCompanyNumber
	,RegisteredCharityNumber
	,CreatedDateTime
	,CreatedByUserId
	,LastUpdatedDateTime
	,LastUpdatedByUserId
	,GroupParentSubscriberId
	,DefaultAddressDescription
	,CompanyStatus
	,CompanyShortName
	)
	SELECT
	CompanyId = @CompanyId
	,CompanyName = 'Taylor and Francis Journals'
	,CompanyOfficer = ''
	,CurrencyCode = 'GBP'
	,BuildingStreet = ''
	,Town = ''
	,County = ''
	,PostCode = ''
	,CountryId = ''
	,TelephoneNumber = ''
	,FaxNumber = ''
	,Email = ''
	,RegisteredOfficeName = ''
	,RegisteredOfficeBuildingStreet = ''
	,RegisteredOfficeTown = ''
	,RegisteredOfficeCounty = ''
	,RegisteredOfficePostCode = ''
	,RegisteredOfficeCountryId = ''
	,RegisteredOfficeTelephoneNumber = ''
	,RegisteredOfficeFaxNumber = ''
	,RegistrationNumber = ''
	,Notes = ''
	,VATCode = ''
	,VATNumber = ''
	,LimitedCompanyNumber = ''
	,RegisteredCharityNumber = ''

	,CreatedDateTime=@NowDate
	,CreatedByUserId=@User
	,LastUpdatedDateTime=@NowDate
	,LastUpdatedByUserId=@User
	,GroupParentSubscriberId = NULL
	,DefaultAddressDescription = cc.DefaultAddressDescription
	,CompanyStatus = 'Active'
	,CompanyShortName = 'T&F'
	FROM Company cc
	where cc.CompanyId = 1

	INSERT INTO CompanyBankAccount (
	CompanyId
	,BankSortCode
	,BankAccountNumber
	,BankAccountName
	,CurrencyCode
	,CountryID
	,BankName
	,BankBuildingStreet
	,BankTown
	,BankCounty
	,BankPostCode
	,BankTelephoneNumber
	,BankFaxNumber
	,Notes
	,CreatedDateTime
	,CreatedByUserId
	,LastUpdatedDateTime
	,LastUpdatedByUserId
	)
	SELECT
	CompanyId = @CompanyId
	,BankSortCode = cc.BankSortCode
	,BankAccountNumber = cc.BankAccountNumber
	,BankAccountName = 'T&F USD'
	,CurrencyCode = 'USD'
	,CountryID = cc.CountryID
	,BankName = cc.BankName
	,BankBuildingStreet = cc.BankBuildingStreet
	,BankTown = cc.BankTown
	,BankCounty = cc.BankCounty
	,BankPostCode = cc.BankPostCode
	,BankTelephoneNumber = cc.BankTelephoneNumber
	,BankFaxNumber = cc.BankFaxNumber
	,Notes = cc.Notes
	,CreatedDateTime=@NowDate
	,CreatedByUserId=@User
	,LastUpdatedDateTime=@NowDate
	,LastUpdatedByUserId=@User

	FROM CompanyBankAccount cc
	WHERE cc.CompanyId = 2
	AND cc.BankSortCode = 'TBA2'
	INSERT INTO Subscriber (
	SubscriberId
	,SubscriberName
	,SubscriberStatus
	,EntityType
	,PrimaryCountryId
	,SubscriberCategory
	,IsAccount
	,ReportCategory
	,VATNumber
	,MailMethod
	,DefaultPostalAddressId
	,IsReceiveMail
	,UpdateToSubscriberId
	,ContactName
	,FirstName
	,LastName
	,Title
	,Salutation
	,Position
	,Qualifications
	,MembershipType
	,IsTrainingAnalyst
	,IsChildAnalyst
	,IsRetired
	,GeographicalStatus
	,Spare1
	,Spare2
	,Spare3
	,Notes
	,CreatedDateTime
	,CreatedByUserId
	,LastUpdatedDateTime
	,LastUpdatedByUserId
	,MetapressId
	,IsSpanishIJPESSubscriber
	,IsReportingParentOverride
	,PhoneNumberForCourier
	)
	SELECT
	SubscriberId = @SubscriberId
	,SubscriberName = 'Tylor & Francis Journals'
	,SubscriberStatus = cc.SubscriberStatus
	,EntityType = cc.EntityType
	,PrimaryCountryId = cc.PrimaryCountryId
	,SubscriberCategory = cc.SubscriberCategory
	,IsAccount = cc.IsAccount
	,ReportCategory = cc.ReportCategory
	,VATNumber = cc.VATNumber
	,MailMethod = cc.MailMethod
	,DefaultPostalAddressId = cc.DefaultPostalAddressId
	,IsReceiveMail = cc.IsReceiveMail
	,UpdateToSubscriberId = cc.UpdateToSubscriberId
	,ContactName = cc.ContactName
	,FirstName = cc.FirstName
	,LastName = cc.LastName
	,Title = cc.Title
	,Salutation = cc.Salutation
	,Position = cc.Position
	,Qualifications = cc.Qualifications
	,MembershipType = cc.MembershipType
	,IsTrainingAnalyst = cc.IsTrainingAnalyst
	,IsChildAnalyst = cc.IsChildAnalyst
	,IsRetired = cc.IsRetired
	,GeographicalStatus = cc.GeographicalStatus
	,Spare1 = cc.Spare1
	,Spare2 = cc.Spare2
	,Spare3 = cc.Spare3
	,Notes = cc.Notes
	,CreatedDateTime = cc.CreatedDateTime
	,CreatedByUserId = cc.CreatedByUserId
	,LastUpdatedDateTime = cc.LastUpdatedDateTime
	,LastUpdatedByUserId = cc.LastUpdatedByUserId
	,MetapressId = cc.MetapressId
	,IsSpanishIJPESSubscriber = cc.IsSpanishIJPESSubscriber
	,IsReportingParentOverride = cc.IsReportingParentOverride
	,PhoneNumberForCourier = cc.PhoneNumberForCourier

	FROM Subscriber cc
	WHERE cc.SubscriberId = 29001
	INSERT INTO RemoteUserRights (
		UserId
		,RightsType
		,RightsToId
		,LastUpdatedDateTime
		,LastUpdatedByUserId	
	)
	SELECT DISTINCT
	UserId = cc.UserId	
	,RightsType = cc.RightsType	
	,RightsToId = CASE cc.RightsType WHEN 'Company' THEN @CompanyID 
					WHEN 'Subscriber' THEN @SubscriberId 
					ELSE NULL END
	,LastUpdatedDateTime=@NowDate
	,LastUpdatedByUserId=@User	

	FROM RemoteUserRights cc
	WHERE cc.UserId IN (SELECT rur.UserId
						FROM RemoteUserRights rur
							INNER JOIn RemoteUser ru
							ON ru.UserId = rur.UserId
						WHERE 1=1
						AND ru.UserStatus = 'Active'
						AND ru.AuthorityLevel in ('CompanyAdmins','SuperCompanyAdmins')
						AND ((rur.RightsType = 'Company'	AND rur.RightsToId in (1,2))
							OR	(rur.RightsType = 'Subscriber'	AND rur.RightsToId in (1,2))
							)
						)

END
DECLARE @TandCHTML varchar(max) = '<ol><li><span style="font-size: 10pt;"><strong>Subscriptions to {{ProductName}} on the PEP-Web platform are available to individuals with personal log-in credentials to the PEP-Web platform and who have an active PEP-Web subscription.</strong> Subscriptions are <strong>valid for twelve months</strong> from date of purchase and are non-transferable and subject to the conditions of use set out below.  Each {{ProductName}} subscriber is an authorized user</span></li><li><strong style="font-size: 10pt;">Subscriptions are for personal use only</strong><span style="font-size: 10pt;">. The subscription may not be used for teaching or other activities for a 3rd party (for example a university or public hospital).</span></li><li><span style="font-size: 10pt;"><strong>Subscriptions to {{ProductName}} extends access to include all issues of {{ProductName}}, up to the latest available.  Access to the latest issues is only for those who have paid the relevant {{ProductName}} subscription fees.</strong> No authorized user may assist anyone other than another authorized user to access {{ProductName}} content and is expressly prohibited from doing so in any way whatsoever. Usage is monitored. Any breach of this condition will result in immediate removal of access rights without compensation and the imposition of a liability to indemnify PEP for any lost subscription fees.</span></li><li><span style="font-size: 10pt;"><strong>Fees.</strong> Taylor &amp; Francis, the publisher, sets the fees for the twelve-month subscription, to which PEP adds a 3% handling fee. The journal subscription price is set by November for the following calendar year. </span></li><li><span style="font-size: 10pt;"><strong>Refund Policy</strong>. Once a subscription is purchased, NO REFUND is possible. </span></li><li><span style="font-size: 10pt;"><strong>Each authorized user</strong> will already have selected and registered a username and password on PEP�s user database: <a href="http://www.psychoanalystdatabase.com/"><strong>www.psychoanalystdatabase.com</strong></a> (PaDS). Access to PEP-Web will be via each individual�s username and password which are input into the relevant boxes on <a href="https://pep-web.org/"><strong>https://pep-web.org/</strong></a> and which can be modified by a user through PaDS: <a href="http://www.psychoanalystdatabase.com/"><strong>www.psychoanalystdatabase.com</strong></a>. Users are liable for the security of their username and password and must not transfer it.</span></li><li><span style="font-size: 10pt;"><strong>Renewal</strong> is through the authorized user�s PaDS profile page, where an order can be placed and payment made. To make a new subscription order or renew, the user must have an active PEP-Web subscription. However, access to {{ProductName}} will continue for twelve months, irrespective of when or whether the PEP-Web subscription ends. </span></li><li><span style="font-size: 10pt;"><strong>Authorized Individual Users</strong> paying individual rates are entitled to free direct support from PEP Customer Support by contacting support@pep-web.org for one month after an order is placed - to ensure they can log-in and access articles. Subsequent support incidents may be charged at PEP''s discretion. PEP-Web and the PaDS database require a user to have Internet access and an approved browser. There are no limits on use, but users should log-out when finished as not to do so may affect the performance of the system.</span></li><li><span style="font-size: 10pt;"><strong>Availability</strong>. PEP has contracted its suppliers for PEP-Web to be available from a link 24 hours a day 7 days a week subject to routine maintenance and in all reasonable circumstances.</span></li><li><span style="font-size: 10pt;"><strong>Copyright. </strong>PEP-Web is owned by PEP or its suppliers and is protected by United States copyright laws and international treaty provisions</span><ol><li><span style="font-size: 10pt;">All copyright (electronic and other) of the text, images, photographs, and videos of the publications appearing on PEP-Web is retained by the original publishers of the Journals, Books, or Videos. Saving the exceptions noted below, no portion of any of the text, images, photographs, or videos may be reproduced or stored in any form without prior permission of the Copyright owners.</span></li><li><span style="font-size: 10pt;">Authorized Uses. Authorized Users may make all use of the Licensed Materials as is consistent with the Fair Use Provisions of United States and international law. Nothing in this Agreement is intended to limit in any way whatsoever any Authorized User''s rights under the Fair Use provisions of United States or international law to use the Licensed Materials.</span></li><li><span style="font-size: 10pt;">During the term of any subscription the Licensed Materials may be used for purposes of research, education or other non-commercial use as follows:</span><ol><li><span style="font-size: 10pt;">Digitally Copy. Authorized Users may download and digitally copy a reasonable portion of the Licensed Materials for their own use only.</span></li><li><span style="font-size: 10pt;">Print Copy. Authorized Users may print (one copy per user) reasonable portions of the Licensed Materials for their own use only.</span></li></ol></li></ol></li><li><span style="font-size: 10pt;"><strong>Termination</strong>. In the event of termination of subscription any material downloaded, printed, or otherwise stored as permitted in the preceding section should not continue to be available and as far as practicable must be destroyed. </span></li><li><span style="font-size: 10pt;"><strong>Commercial Reproduction.</strong> No purchaser or user shall use any portion of the Journal in any form of commercial exploitation, including, but not limited to, commercial print or broadcast media, and no purchaser or user shall reproduce as its own any material contained herein.</span></li><li><span style="font-size: 10pt;"><strong>LIMITATION OF LIABILITY</strong>. The publishers of the publications appearing on PEP-Web and PEP disclaim any liability to any party for the accuracy, completeness, or availability of any of the material herein, or for any damages arising out of the use or non-use of said material or any information contained therein.</span></li><li><span style="font-size: 10pt;"><strong>Copyright Warranty</strong>. Licensor warrants that it has the right to license the rights granted under this Agreement to use Licensed Materials, that it has obtained any and all necessary permissions from third parties to license the Licensed Materials, and that use of the Licensed Materials by Authorized Users in accordance with the terms of this Agreement shall not infringe the copyright of any third party. The Licensor shall indemnify and hold Licensee and Authorized Users harmless for any losses, claims, damages, awards, penalties, or injuries incurred, including reasonable attorney''s fees, which arise from any claim by any third party of an alleged infringement of copyright or any other property right arising out of the use of the Licensed Materials by the Licensee or any Authorized User in accordance with the terms of this Agreement. This indemnity shall survive the termination of this agreement.</span></li></ol><div><span style="font-size: 10pt;">NO LIMITATION OF LIABILITY SET FORTH ELSEWHERE IN THIS AGREEMENT IS APPLICABLE TO THIS INDEMNIFICATION.</span></div>'
DECLARE @RecieptHTML varchar(max) = '<table width="100%">
<tbody>
<tr style="height: 23px;">
<td>
<p><span style="font-family: Verdana;"><strong><span style="color: #0000ff;">PaDS - Psychoanalysts Database System</span></strong></span></p>

<p><span style="font-family: Verdana;"><strong><span style="color: #0000ff;"><br /></span></strong></span></p>
</td>
</tr>
<tr style="height: 36px;">
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>To: {{FirstName}} {{LastName}}<br />{{Address}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong>Our reference: {{OrderNumber}}<br /> Product: {{ProductName}}</strong></span></span></p>
</td>
</tr>
<tr>
<td>
<p><span style="font-family: Verdana; font-size: 10pt;">Thank you for your recent order for a one-year subscription to the <strong>digital edition</strong> of the {{ProductName}}. This note is to acknowledge that order and the receipt of your payment of $ {{Amount}}. Your credit card has now been charged and access has been enabled.</span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-family: Verdana; font-size: 10pt;">By a new agreement reached with Taylor &amp; Francis, content of this journal up to and including the latest three years are now available to you via PEP-Web. Go to [Journal Page]</span></p>
    <p><span style="font-family: Verdana; font-size: 10pt;">To read the full text you will need to log into PEP-Web. If you are unsure about your credentials, go to <a href="https://www.psychoanalystdatabase.com/">PaDS</a> (our online ordering system) and use the forgot username/password facility. Your email will be the one to which this email has been directed.<br /></span></p>
<p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"></span></p>
<div><span style="font-size: 10pt;"><span style="font-family: Verdana;">For help logging in and support in using the system, please go to [SUPPORT Page]</span></span></div><div><span style="font-size: 10pt;"><span style="font-family: Verdana;"><br /></span></span></div><div><span style="font-size: 10pt;"><span style="font-family: Verdana;">Your subscription to {{ProductName}} will expire 12 months from the date of this order. </span></span></div><div><br /></div><p><span style="font-size: 10pt;"></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>THIS LETTER CONFIRMS YOU HAVE PURCHASED A DIGITAL SUBSCRIPTION ONLY</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong><em>This is an automated message. Replies to this email address are routed to an unmonitored inbox. Please see our <a href="http://support.pep-web.org/">support pages</a> for ways to get in touch</em></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;"><strong></strong></span></span></p>
<p><span style="font-size: 10pt;"><span style="font-family: Verdana;">Please note that PaDS, the website through which your subscription has been processed, is fully compliant with European GDPR (privacy) legislation. See further details of how the privacy of your data is protected and what you can do at: <a href="https://eur01.safelinks.protection.outlook.com/?url=http%3A%2F%2Fsupport.pep-web.org%2Fsubscribe%2Fpads-and-its-data-protection-policy%2F&amp;data=02%7C01%7C%7C10671dbc658e43d0892408d7a5918422%7C1faf88fea9984c5b93c9210a11d9a5c2%7C0%7C0%7C637159916717170590&amp;sdata=M3r7xqfHuTucNpdOHmxZ48vquH0rH39ZwAh2F0nneW0%3D&amp;reserved=0">http://support.pep-web.org/subscribe/pads-and-its-data-protection-policy/</a></span></span><span style="font-size: 8pt; font-family: Verdana;">&nbsp;</span></p>
<p><span style="font-size: 8pt; font-family: Verdana;"><br /></span></p>
</td>
</tr>
</tbody>
</table>'
create table #p (
shortcode varchar(10)
,code varchar(50)
,name varchar(100)
,OrdinaryProductRate Money

)

insert into #p select 'IJPSPP','IJPSPPSC','Psychoanalysis, Self and Context',27.81
insert into #p select 'JICAP','JICAP','Journal of Infant, Child & Adolescent Psychotherapy',55.62
insert into #p select 'JCPTX','JCPTX','Journal of Child Psychotherapy',19.57
insert into #p select 'NP','NP','Neuropsychoanalysis',272.95
insert into #p select 'PAQ','PAQ','The Psychoanalytic Quarterly',587.10
insert into #p select 'PD','PD','Psychoanalytic Dialogues',10
insert into #p select 'PI','PI','Psychoanalytic Inquiry',10
insert into #p select 'PPERSP','PPERSP','Psychoanalytic Perspectives',30
insert into #p select 'PPTX','PPTX','Psychoanalytic Psychotherapy',40
insert into #p select 'PSC','PSC','The Psychoanalytic Study of the Child',50
insert into #p select 'PSW','PSW','Psychoanalytic Social Work',60
insert into #p select 'SGS','SGS','Studies in Gender and Sexuality',70
insert into #p select 'SPR','SPR','The Scandinavian Psychoanalytic Review',80
ALTER TABLE #p Add StudentProductRate MONEY
update #p set StudentProductRate = OrdinaryProductRate 


--parent products
insert into Product (
ProductCode
,ProductName
,ProductStatus
,CompanyID
,IsCarriageCharge
,IsParent
,ReleaseDate
,ParentProductCode
,AssociatedProductCode
,Notes
,ProductShortName
,IsForReporting
,ReportProportion
,ProductReportName
,CreatedDateTime
,CreatedByUserId
,LastUpdatedDateTime
,LastUpdatedByUserId
,RecurringSubscriptionFlag
,RecurringSubscriptionUnits
,SellOnWebFlag
,TermsAndConditionsFileName
,ProductGroupingName
,OnePerSubscriberFlag
,CheckAgainstOrderType
,RecurringSubscriptionUnitType
,ShippedProductFlag
,SalesReportProductGrouping
,DisableAutoRenewalFlag
,DisplayProductName
,FixedSubscriptionEndDate
,TermsAndConditionsHTML
,ReceiptEmailHTML
,BlockSpecificReceiptEmailHTML
,SuppressConfirmationEmail

)
select
ProductCode= 'TF_' + left(p.shortcode ,5)
,ProductName=p.code + ' - ' + p.name 
,ProductStatus='Current'
,CompanyID=@CompanyID
,IsCarriageCharge=0
,IsParent=1
,ReleaseDate='01-sep-2024'
,ParentProductCode=NULL
,AssociatedProductCode=NULL
,Notes=NULL
,ProductShortName= 'TF_'+ left(p.shortcode ,7)
,IsForReporting=0
,ReportProportion=NULL
,ProductReportName= 'TF_'+ left(p.shortcode ,7)
,CreatedDateTime=@NowDate
,CreatedByUserId=@User
,LastUpdatedDateTime=@NowDate
,LastUpdatedByUserId=@User
,RecurringSubscriptionFlag=1
,RecurringSubscriptionUnits=12
,SellOnWebFlag=1
,TermsAndConditionsFileName=NULL
,ProductGroupingName='TF_' + left(p.shortcode ,5)
,OnePerSubscriberFlag=1
,CheckAgainstOrderType='All'
,RecurringSubscriptionUnitType='Months'
,ShippedProductFlag=0
,SalesReportProductGrouping=NULL
,DisableAutoRenewalFlag=NULL
,DisplayProductName = p.code + ' - ' + p.name 
,FixedSubscriptionEndDate=NULL
,TermsAndConditionsHTML=REPLACE(@TandCHTML,'{{ProductName}}',p.name)
,ReceiptEmailHTML=REPLACE(@RecieptHTML,'{{ProductName}}',p.name)
,BlockSpecificReceiptEmailHTML=NULL
,SuppressConfirmationEmail=NULL

from #p p


--child products
insert into Product (
ProductCode
,ProductName
,ProductStatus
,CompanyID
,IsCarriageCharge
,IsParent
,ReleaseDate
,ParentProductCode
,AssociatedProductCode
,Notes
,ProductShortName
,IsForReporting
,ReportProportion
,ProductReportName
,CreatedDateTime
,CreatedByUserId
,LastUpdatedDateTime
,LastUpdatedByUserId
,RecurringSubscriptionFlag
,RecurringSubscriptionUnits
,SellOnWebFlag
,TermsAndConditionsFileName
,ProductGroupingName
,OnePerSubscriberFlag
,CheckAgainstOrderType
,RecurringSubscriptionUnitType
,ShippedProductFlag
,SalesReportProductGrouping
,DisableAutoRenewalFlag
,DisplayProductName
,FixedSubscriptionEndDate
,TermsAndConditionsHTML
,ReceiptEmailHTML
,BlockSpecificReceiptEmailHTML
,SuppressConfirmationEmail

)
select
ProductCode= p.ProductCode + 'C1'
,ProductName= p.ProductName  + 'Child1'
,ProductStatus='Current'
,CompanyID=@CompanyID 
,IsCarriageCharge=0
,IsParent=0
,ReleaseDate='01-sep-2024'
,ParentProductCode=p.ProductCode 
,AssociatedProductCode=NULL
,Notes=NULL
,ProductShortName=  p.ProductCode + 'C1'
,IsForReporting=1
,ReportProportion=1
,ProductReportName=null
,CreatedDateTime=@NowDate
,CreatedByUserId=@User
,LastUpdatedDateTime=@NowDate
,LastUpdatedByUserId=@User
,RecurringSubscriptionFlag=null
,RecurringSubscriptionUnits=null
,SellOnWebFlag=null
,TermsAndConditionsFileName=NULL
,ProductGroupingName =null
,OnePerSubscriberFlag = null
,CheckAgainstOrderType = null
,RecurringSubscriptionUnitType = null
,ShippedProductFlag = null
,SalesReportProductGrouping = null
,DisableAutoRenewalFlag = null
,DisplayProductName = null
,FixedSubscriptionEndDate = null
,TermsAndConditionsHTML = null
,ReceiptEmailHTML = null
,BlockSpecificReceiptEmailHTML = null
,SuppressConfirmationEmail = null

from Product p
where p.ProductCode like 'TF_%'


insert into ProductRate (
ProductCode
,CurrencyCode
,RateType
,AccountType
,SubscriberCategory
,DeliveryArea
,ProductRate
,CreatedDateTime
,CreatedByUserId
,LastUpdatedDateTime
,LastUpdatedByUserId
,NewUserRateFlag
,SellOnWebFlag)
select 
ProductCode = p.ProductCode 
,CurrencyCode = 'USD'
,RateType = 'Full'
,AccountType = 'Individual'
,SubscriberCategory = 'Ordinary'
,DeliveryArea = 'All'
,ProductRate = pn.OrdinaryProductRate 
,CreatedDateTime = @NowDate 
,CreatedByUserId = @User
,LastUpdatedDateTime = @NowDate
,LastUpdatedByUserId = @User
,NewUserRateFlag = null
,SellOnWebFlag = 1
FROM Product p
	inner join #p pN
	on 'TF_' + pn.shortcode =p.ProductCode collate database_default
--where p.ProductCode like 'TF_%'
insert into ProductRate (
ProductCode
,CurrencyCode
,RateType
,AccountType
,SubscriberCategory
,DeliveryArea
,ProductRate
,CreatedDateTime
,CreatedByUserId
,LastUpdatedDateTime
,LastUpdatedByUserId
,NewUserRateFlag
,SellOnWebFlag)
select 
ProductCode = p.ProductCode 
,CurrencyCode = 'USD'
,RateType = 'Full'
,AccountType = 'Individual'
,SubscriberCategory = 'Student'
,DeliveryArea = ''
,ProductRate = pn.StudentProductRate 
,CreatedDateTime = @NowDate 
,CreatedByUserId = @User
,LastUpdatedDateTime = @NowDate
,LastUpdatedByUserId = @User
,NewUserRateFlag = null
,SellOnWebFlag = 1
FROM Product p
	inner join #p pN
	on 'TF_' + pn.shortcode =p.ProductCode collate database_default
--where p.ProductCode like 'TF_%'

insert into ProductQualifyingProduct
(
ProductCode
,QualifyingProductCode
,SubscriberCategory
,ProductRateId
,MustBuyFlag
,TerminatedSubscriptionsGracePeriodMonths
,timestamp
,CheckAgainstOrderType
,LastUpdatedDateTime
,LastUpdatedByUserId

)
select
ProductCode = p.ProductCode 
,QualifyingProductCode = xp.ProductCode 
,SubscriberCategory = pr.SubscriberCategory 
,ProductRateId = pr.ProductRateId 
,MustBuyFlag = null
,TerminatedSubscriptionsGracePeriodMonths = 0
,timestamp = null
,CheckAgainstOrderType = 'All'
,LastUpdatedDateTime = @NowDate 
,LastUpdatedByUserId = @User
FROM Product p
	inner join Product xp
	on xp.ProductCode in ('pepwebs','pepweb','T-PEPweb')
	inner join ProductRate pr
	on pr.ProductCode = p.ProductCode 
where p.ProductCode like 'TF_%'

select * from product p where p.ProductCode in ('TF_PD','TF_PPTX')-- like 'TF_%'
select * from product p where p.parentProductCode in ('TF_PD','TF_PPTX')-- like 'TF_%'
select * from ProductRate p where p.ProductCode  in ('TF_PD','TF_PPTX')-- like 'TF_%'
select * from ProductQualifyingProduct p where p.ProductCode  in ('TF_PD','TF_PPTX')-- like 'TF_%'


insert into ContentSet (
ContentSetName
,ContentSetStatus
,Description
,GivesAccessToAllCurrentContent
,GivesAccessToAllArchiveContent
,LastUpdatedDateTime
,LastUpdatedByUserId
)
select
ContentSetName = 'TF ' + p.ProductName
,ContentSetStatus = 'Active'
,Description = null
,GivesAccessToAllCurrentContent = null
,GivesAccessToAllArchiveContent = null
,LastUpdatedDateTime = @NowDate
,LastUpdatedByUserId = @User
from product p where p.ProductCode like 'TF_%'

insert into ContentSetAccessClassification(
ContentSetId
,AccessClassification
,LastUpdatedDateTime
,LastUpdatedByUserId
)
select
ContentSetId = c.ContentSetId 
,AccessClassification = 'Archive'
,LastUpdatedDateTime = @NowDate 
,LastUpdatedByUserId = @User
from ContentSet c
where c.ContentSetName like 'TF %'

insert into ContentSetSource (
ContentSetId
,SourceType
,IncludeAllSourceItems
,ExcludeEmbargoedYears
,EmbargoedYearsOnly
,OverrideEmbargoYears
,SingleYearOnly
,LastUpdatedDateTime
,LastUpdatedByUserId
)
select
ContentSetId = c.ContentSetId 
,SourceType = 'Journal'
,IncludeAllSourceItems = 0
,ExcludeEmbargoedYears = 0
,EmbargoedYearsOnly = 1
,OverrideEmbargoYears = 0
,SingleYearOnly = null
,LastUpdatedDateTime = @NowDate
,LastUpdatedByUserId = @User
from ContentSet c
where c.ContentSetName like 'TF %'

insert into ContentSetSourceItem (
ContentSetSourceId
,ContentCode
,Volume
,DocumentId
,LastUpdatedDateTime
,LastUpdatedByUserId
)
select
ss.ContentSetSourceId 
,j.code
,null
,null
,LastUpdatedDateTime = @NowDate
,LastUpdatedByUserId = @User
from ContentSet c
	inner join ContentSetSource ss
	on ss.ContentSetId = c.ContentSetId
	inner join Product p
	on c.ContentSetName like '%' + p.ProductName collate database_default
	inner join #p j
	on j.shortcode =p.ProductCode collate database_default
where c.ContentSetName like 'TF %'

insert into ProductContentSet(
ProductCode
,ContentSetId
,LastUpdatedDateTime
,LastUpdatedByUserId
)
select
	p.ProductCode 
	,c.ContentSetId 
,LastUpdatedDateTime = @NowDate
,LastUpdatedByUserId = @User
from ContentSet c
	inner join Product p
	on c.ContentSetName like '%' + p.ProductName 
where c.ContentSetName like 'TF %'

select * from ProductContentSet  where ProductCode like 'TF_%'

drop table #o
drop table #cs
drop table #p

commit tran
--rollback tran