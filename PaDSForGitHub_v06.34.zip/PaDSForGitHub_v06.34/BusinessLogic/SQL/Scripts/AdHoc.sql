begin tran
select top 1000 * from UserActionLog order by datetime desc
declare @BatchlogId int = (select max(batchlogid) from batchlog)
exec sp601PopulateActivityLog @BatchLogId =@BatchLogId
select top 1000 * from UserActionLog order by datetime desc
select * from BatchLogLine where BatchLogId=@BatchlogId order by 1 desc
rollback tran