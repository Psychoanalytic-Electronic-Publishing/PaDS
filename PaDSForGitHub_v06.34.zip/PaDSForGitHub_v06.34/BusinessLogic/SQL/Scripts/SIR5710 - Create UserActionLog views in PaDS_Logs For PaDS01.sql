/*
Nov2023 - This should be run on PaDS01 server in PaDS_Logs DB
*/

if exists (select * from sysobjects where id = object_id(N'UserActionLog2021') and OBJECTPROPERTY(id, N'IsView') = 1) drop view UserActionLog2021
Go
CREATE VIEW UserActionLog2021 AS SELECT * FROM [PaDS_Logs_UserAction2021].dbo.UserActionLog
Go
if exists (select * from sysobjects where id = object_id(N'UserActionLog2022') and OBJECTPROPERTY(id, N'IsView') = 1) drop view UserActionLog2022
Go
CREATE VIEW UserActionLog2022 AS SELECT * FROM [PaDS_Logs_UserAction2022].dbo.UserActionLog
Go
if exists (select * from sysobjects where id = object_id(N'UserActionLog2023') and OBJECTPROPERTY(id, N'IsView') = 1) drop view UserActionLog2023
Go
CREATE VIEW UserActionLog2023 AS SELECT * FROM [PaDS_Logs_UserAction2023].dbo.UserActionLog
Go
if exists (select * from sysobjects where id = object_id(N'UserActionLog2024') and OBJECTPROPERTY(id, N'IsView') = 1) drop view UserActionLog2024
Go
CREATE VIEW UserActionLog2024 AS SELECT * FROM [PaDS_Logs_UserAction2024].dbo.UserActionLog
Go
if exists (select * from sysobjects where id = object_id(N'UserActionLog') and OBJECTPROPERTY(id, N'IsView') = 1) drop view UserActionLog
Go
CREATE VIEW [dbo].[UserActionLog] AS 
      SELECT * FROM [Pads_Logs_UserAction2021].dbo.UserActionLog
UNION SELECT * FROM [Pads_Logs_UserAction2022].dbo.UserActionLog
UNION SELECT * FROM [Pads_Logs_UserAction2023].dbo.UserActionLog
UNION SELECT * FROM [Pads_Logs_UserAction2024].dbo.UserActionLog
go

