﻿IF  exists (select * from dbo.sysobjects where id = object_id(N'sp601PopulateActivityLog') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp601PopulateActivityLog
GO
CREATE  PROCEDURE sp601PopulateActivityLog (
		@BatchLogId INT = NULL
)
AS
--12/8/21	James Woosnam	Re-arranged to reduce the amount of time the transaction is open for and to optimise some of the queries so as not to lock front end
--21/3/22	James Woosnam	SIR5463 - Change AffiliateRateSubscriber to ReportingParentSubscriber
--20/4/22	James Woosnam	SIR5486 - Use vw433SalesOrderReportingParent and don't add if no reporting parent
--27/2/23	Julian Gates	HOTFIX: ItemOfInterest very occasionally more than 50 so truncate
--31/10/23	James Woosnam	SIR5706 -  Populate publisher
--15/11/23	James Woosnam	SIR5710 - Put each year traffic in different tables, 2023 & 2024 hard coded
--10/01/24	Julian Gates	Add Pads_Logs file shrink code.
--7/11/24   James Woosnam   SIR5764 - Reworked to populate 3 denormalised tables (UserActionBase, ItemDetails & SessionDetails) in [PaDS_Counter_Data] to save space and have all years in 1 DB
DECLARE @Message VARCHAR(MAX) = ''
		,@RowCount INT = 0
		,@ThrowError BIT = 0
		,@NewLine VARCHAR(10) = '<br>'

DECLARE @UserActionLogLastPEPWebLogId INT = NULL
	,@UserActionLogLastPEPWebSessionLogIdForAbstract INT = NULL
	,@UserActionLogLastPEPWebSessionLogIdForSearch INT = NULL
	,@MaxUserActionLogIdBeforeInserts INT = NULL
	,@UserActionLogStartFromDateTime DATETIME = NULL


BEGIN TRY
	SELECT @UserActionLogStartFromDateTime = ParameterValue FROM stblParameters WHERE ParameterName = 'UserActionLogStartFromDateTime'
	IF @UserActionLogStartFromDateTime IS NULL SET @UserActionLogStartFromDateTime ='01-FEB-2021'
	SELECT @MaxUserActionLogIdBeforeInserts = ISNULL(MAX(UserActionLogId),0) FROM UserActionLog
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@MaxUserActionLogIdBeforeInserts=' +CAST(@MaxUserActionLogIdBeforeInserts AS VARCHAR) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message


--20/9/21	james Woosnam	SIR5325 - No longer user parameters as can get from FromLogRecordWithId in UserActionLog
	DELETE FROM stblParameters WHERE ParameterName IN ( 'UserActionLogLastPEPWebLogId','UserActionLogLastPEPWebSessionLogId')


	SELECT * INTO #UAB FROM [PaDS_Counter_Data].dbo.UserActionBase WHERE 1=2
--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add Requests from PEPwebUsageLog
	SELECT @UserActionLogLastPEPWebLogId = ISNULL(MAX(FromLogRecordWithId),0) FROM UserActionLog WHERE ActionType IN ('No_License','Request')
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@UserActionLogLastPEPWebLogId=' +CAST(@UserActionLogLastPEPWebLogId AS VARCHAR(20)) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	INSERT INTO #UAB (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,ActionType
		,Access_Type
		,Access_Method
		,Institution_Id
		,ItemId
	)

	SELECT
		FromLogRecordWithId = CAST(l.PEPWebUsageLogId AS VARCHAR(20))
		,l.UserSessionId 
		,l.DateTime 
		,ActionType =  CASE WHEN l.LogonStatus='Failed' THEN 'No_License'
						ELSE 'Request' END
		,Access_Type = CASE WHEN l.AdditionalDetails like '%universal access%' THEN 'OA_Gold' ELSE 'Controlled' END --OA_Gold (Gold Open Access) , Controlled
		,Access_Method = 'Regular'
		,Institution_Id = NULL
		,ItemId =l.documentId
	FROM PEPWebUsageLog l
	where 1=1
	and l.PEPWebUsageLogId >@UserActionLogLastPEPWebLogId
	AND l.DateTime >= @UserActionLogStartFromDateTime
	AND isnumeric(l.username)=1
	AND l.ActionType IN ( 'Authorise')
--20/9/21	james Woosnam	SIR5325 - Stop getting Abstarct from PEPWebUsageLog as un-reliable
	AND l.ReasonForCheck  IN ('DocumentView')
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAB records added for FullRead/Request';EXEC sp029UpdateBatchLog @BatchLogId, @Message

--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add Abstract Actions from PEPWebSessionLog
--20/9/21	james Woosnam	SIR5325 - Get Abstarct from PEPWebSessionLog
	SELECT @UserActionLogLastPEPWebSessionLogIdForAbstract = ISNULL(MAX(FromLogRecordWithId),0) FROM UserActionLog WHERE ActionType IN ('Investigation')
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@UserActionLogLastPEPWebSessionLogIdForAbstract=' +CAST(@UserActionLogLastPEPWebSessionLogIdForAbstract AS VARCHAR(20)) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message
	INSERT INTO #UAB (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,ActionType
		,Access_Type
		,Access_Method
		,Institution_Id
		,ItemId
	)

	SELECT
		FromLogRecordWithId = CAST(l.PEPWebSessionLogId AS VARCHAR(20))
		,UserSessionId = l.UserSessionId 
		,DateTime = l.LastUpdate
		,ActionType = 'Investigation'
		,Access_Type = 'Controlled'
		,Access_Method = 'Regular'
		,Institution_Id = NULL
--27/2/23	Julian Gates	HOTFIX: ItemOfInterest very occasionally more than 50 so truncate		
		,ItemId = LEFT(l.ItemOfInterest,50)
	FROM PEPWebSessionLog l
	where 1=1
	AND l.Endpoint = '/Documents/Abstracts/{documentID}/'
	and l.PEPWebSessionLogId  >@UserActionLogLastPEPWebSessionLogIdForAbstract
	AND l.LastUpdate >= @UserActionLogStartFromDateTime
	SET @RowCount = @@ROWCOUNT 
	SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAB Abstract/Investigation records added';EXEC sp029UpdateBatchLog @BatchLogId, @Message

--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
	DELETE FROM #UAB 
	WHERE UserActionLogId IN (
			SELECT DISTINCT
				l2.UserActionLogId 
			FROM #UAB l
				INNER JOIN #UAB l2
				ON l2.UserSessionId = l.UserSessionId 
				AND l2.ActionType = l.ActionType 
				AND l2.Access_Type = l.Access_Type 
				AND l2.Access_Method = l.Access_Method 
				AND l2.ItemId = l.ItemId 
				AND l2.DateTime BETWEEN DATEADD(SECOND,-30,l.DateTime) AND l.DateTime 
				AND l2.UserActionLogId <> l.UserActionLogId 
			WHERE l.UserActionLogId > @MaxUserActionLogIdBeforeInserts
			)
	SET @RowCount = @@ROWCOUNT ;SET @Message =  CAST(@RowCount AS VARCHAR) + ' #UAB rows deleted as within 30seconds of duplicate';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	SELECT DISTINCT
			Data_Type = CAST(ISNULL(c.Data_Type ,b.Data_Type) AS VARCHAR(50)) --Article, Book, Book_Segment, Database, Dataset, Journal, Multimedia, Newspaper_or_Newsletter, Other, Platform, Report, Repository_Item, and Thesis_or_Dissertation
			,TitleId = ISNULL(CASE WHEN c.Data_Type = 'Article' THEN c.PEPCode + CAST(d.year  AS VARCHAR) ELSE c.PEPCode END,b.PEPCode)
--31/10/23	James Woosnam	SIR5706 -  Populate publisher
			,publisher = ISNULL(c.publisher ,b.publisher)			
			,Publisher_ID = LEFT(dbo.fn021RemoveNonAlphanumericCharacters(ISNULL(c.publisher ,b.publisher)),50)
			,TitleName = ISNULL(CASE WHEN c.Data_Type = 'Article' THEN c.Title + ' ' + CAST(d.year  AS VARCHAR) ELSE c.Title END,b.Title)
			,ItemId = ISNULL(d.documentID,l.ItemId )
			,ItemName = ISNULL(d.documentRef ,b.title )
			,YOP = ISNULL(d.year ,b.pub_year)
			,ISSN = ISNULL(c.ISSN,b.ISSN)
			,ISBN = ISNULL(c.ISBN,b.ISBN)
			,Language = ISNULL(c.language,b.language)
	INTO #ID
	FROM #UAB l
			LEFT JOIN ContentDocuments d
				LEFT JOIN (
					SELECT j.PEPCode 
						,j.sourceType 
						,j.Title 
						,j.ISSN 
						,ISBN = CAST('' AS VARCHAR(50))
						,j.language 
						,Data_Type = CAST('Article' AS VARCHAR(50))
						,j.publisher
					FROM ContentJournals j
					UNION
					SELECT v.PEPCode 
						,v.sourceType 
						,v.Title 
						,v.ISSN 
						,ISBN = CAST('' AS VARCHAR(50))
						,v.language 
						,Data_Type = CAST('Multimedia' AS VARCHAR(50))
						,v.publisher
					FROM ContentVideos v
					) c
				ON c.PEPCode = d.PEPCode 
			ON d.documentID = l.ItemId  
			LEFT JOIN (
				SELECT b.PEPCode 
					,b.sourceType 
					,b.documentID 
					,b.Title 
					,b.ISSN 
					,ISBN = b.ISBN13 
					,b.language
					,Data_Type = 'Book_Segment' 
					,b.pub_year
					,b.publisher
				FROM ContentBooks b
				) b
		on b.documentID = l.ItemId   
		or replace(l.ItemId ,'.','') like b.PEPCode + '%'
	WHERE ISNULL(l.ItemId,'')<>''
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' records added to #ID';EXEC sp029UpdateBatchLog @BatchLogId, @Message



--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add additional Investigation for each request
	INSERT INTO #UAB (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,ActionType
		,Access_Type
		,Access_Method
		,Institution_Id
		,ItemId
	)
	SELECT
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,ActionType
		,Access_Type
		,Access_Method
		,Institution_Id
		,ItemId
	FROM #UAB 
	WHERE ActionType = 'Request'
	SET @RowCount = @@ROWCOUNT 
	SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAB Investigations records added for copy Requests';EXEC sp029UpdateBatchLog @BatchLogId, @Message


--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add Search Actions
	SELECT @UserActionLogLastPEPWebSessionLogIdForSearch = ISNULL(MAX(FromLogRecordWithId),0) FROM UserActionLog WHERE ActionType IN ('Search')
	SET @RowCount = @@ROWCOUNT ;SET @Message = '@UserActionLogLastPEPWebSessionLogIdForSearch=' +CAST(@UserActionLogLastPEPWebSessionLogIdForSearch AS VARCHAR(20)) + '';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	INSERT INTO #UAB (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,ActionType
		,Access_Type
		,Access_Method
	)
	SELECT
		FromLogRecordWithId = CAST(l.PEPWebSessionLogId AS VARCHAR(20))
		,l.UserSessionId 
		,l.LastUpdate 
		,ActionType = 'Search'
		,Access_Type = 'Controlled' 
		,Access_Method = 'Regular'
	FROM PEPWebSessionLog l
	where 1=1
	AND l.Endpoint = '/Database/Search/'
	AND l.Params LIKE '%user=true%'
	and l.PEPWebSessionLogId  >@UserActionLogLastPEPWebSessionLogIdForSearch
	AND l.LastUpdate >= @UserActionLogStartFromDateTime
	SET @RowCount = @@ROWCOUNT 
	SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAB Search records added';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	SELECT 
		us.UserSessionId 
		,UserId = MAX(us.UserId )
		,UserName = MAX(us.UserName )
		,SubscriberId = MAX(CASE WHEN usd.DataItemName = 'SubscriberId' THEN usd.DataItemValue ELSE '0' END)
		,OrderNumber = MAX(CASE WHEN usd.DataItemName  = 'SubscriptionOrderNumber' THEN usd.DataItemValue ELSE '0' END)
		,LoggedInMethod = MAX(CASE WHEN usd.DataItemName  = 'LoggedInMethod' THEN usd.DataItemValue ELSE '0' END)
		,UserType = MAX(CASE WHEN usd.DataItemName = 'UserType' THEN usd.DataItemValue ELSE '0' END)
	INTO #SessDetails
	FROM UserSession us  With (nolock)
		INNER JOIN UserSessionData usd With (nolock)
		ON usd.UserSessionId = us.UserSessionId
	WHERE us.UserId <> -1
	AND us.UserSessionId IN (SELECT DISTINCT UserSessionId FROM #UAB)
	GROUP BY
		us.UserSessionId 
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #SessDetails records added';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	UPDATE #UAB
	SET Institution_Id = so.ReportingParentSubscriberId
	FROM #UAB l
		INNER JOIN #SessDetails sd
--20/4/22	James Woosnam	SIR5486 - Use vw433SalesOrderReportingParent 
			INNER JOIN vw433SalesOrderReportingParent so
				INNER JOIN Subscriber rps
				ON rps.SubscriberId = so.ReportingParentSubscriberId
			ON so.OrderNumber = sd.OrderNumber
		ON sd.UserSessionId = l.UserSessionId 
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAB records updated with Institution_Id';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	--UPDATE #UAB
	--SET Data_Type = id.Data_Type 
	--FROM #UAB l
	--	INNER JOIN #ID id
	--	ON id.ItemId = l.ItemId 
	--SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAB records updated with Data_Type';EXEC sp029UpdateBatchLog @BatchLogId, @Message


END TRY
BEGIN CATCH
	
	SELECT @Message ='sp601PopulateActivityLog Part 1 (Temp tables) Failed:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE();EXEC sp029UpdateBatchLog @BatchLogId, @Message
	RAISERROR ('%s', 18, 1,@Message)
	RETURN
END CATCH

BEGIN TRY
--31/10/23	James Woosnam	SIR5706 -  Populate publisher
	INSERT INTO [PaDS_Counter_Data].dbo.UserActionBase (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,ActionType
		,Institution_Id
		,Access_Type
		,Access_Method
		,ItemId )
	SELECT 
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,ActionType
		,Institution_Id
		,Access_Type
		,Access_Method
		,ItemId 
	FROM #UAB 
	SET @RowCount = @@ROWCOUNT 
	SET @Message = CAST(@RowCount AS VARCHAR) + ' UserActionBase rows added from #UAB';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	UPDATE [PaDS_Counter_Data].dbo.ItemDetails
	SET    Publisher_ID= id2.Publisher_ID
		  ,TitleId = id2.TitleId
		  ,TitleName = id2.TitleName
		  ,ItemName = id2.ItemName
		  ,YOP = id2.YOP
		  ,ISSN = id2.ISSN
		  ,ISBN = id2.ISBN
		  ,Language = id2.Language
		  ,publisher = id2.publisher
	FROM [PaDS_Counter_Data].dbo.ItemDetails i
		INNER JOIN #id id2
		ON id2.ItemId = i.ItemId
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' ItemDetails records updated from #ID';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	INSERT INTO [PaDS_Counter_Data].dbo.ItemDetails (
		  ItemId
		  ,Publisher_ID
		  ,TitleId
		  ,TitleName
		  ,ItemName
		  ,YOP
		  ,ISSN
		  ,ISBN
		  ,Language
		  ,publisher
		  ,Data_Type
	)
	SELECT DISTINCT
		  i.ItemId
		  ,i.Publisher_ID
		  ,i.TitleId
		  ,i.TitleName
		  ,i.ItemName
		  ,i.YOP
		  ,i.ISSN
		  ,i.ISBN
		  ,i.Language
		  ,i.publisher
		  ,i.Data_Type
	FROM #ID i
		LEFT JOIN [PaDS_Counter_Data].dbo.ItemDetails i2
		On i2.ItemId = i.ItemId 
	WHERE i2.ItemId IS NULL
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' records added to ItemDetails';EXEC sp029UpdateBatchLog @BatchLogId, @Message

INSERT INTO [PaDS_Counter_Data].dbo.SessionDetails (
		UserSessionId 
		,UserId
		,SubscriberId
		,OrderNumber
		,LoggedInMethod 
		,UserType
)
select DISTINCT
		u.UserSessionId 
		,u.UserId
		,u.SubscriberId
		,u.OrderNumber
		,u.LoggedInMethod 
		,u.UserType
FROM #SessDetails u
	LEFT JOIN [PaDS_Counter_Data].dbo.SessionDetails u2
	ON u2.UserSessionId = u.UserSessionId
WHERE u2.UserSessionId IS NULL

	Update CounterReportInstitution
	SET Institution_Name = s.SubscriberName
	FROM CounterReportInstitution i
		INNER JOIN Subscriber s
		ON s.SubscriberId = i.Institution_Id 
	WHERE i.Institution_Name<>s.SubscriberName 
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' CounterReportInstitution records updated';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	INSERT INto CounterReportInstitution
	SELECT
		b.Institution_Id
		,s.SubscriberName 
	from #UAB  b
		inner join Subscriber s
		on s.SubscriberId = b.Institution_Id 
		LEFT JOIN (SELECT Institution_Id FROM CounterReportInstitution) i
		ON i.Institution_Id = b.Institution_Id 
	WHERE i.Institution_Id IS NULL
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' CounterReportInstitution records added';EXEC sp029UpdateBatchLog @BatchLogId, @Message

END TRY
BEGIN CATCH
	SELECT @Message ='Add records to [PaDS_Counter_Data] Datatbase Failed:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE() ;EXEC sp029UpdateBatchLog @BatchLogId, @Message
	RAISERROR ('%s', 18, 1,@Message)
END CATCH

--10/01/24	Julian Gates	Add Pads_Logs file shrink code.
DECLARE @DBName varchar(100)= DB_Name()

BEGIN TRY
	EXEC ('USE [PaDS_Counter_Data]; DBCC SHRINKFILE (N''PaDS_Counter_Data_log'' , 0, TRUNCATEONLY)')
	SET @Message = ' PaDS_Counter_Data_log file sucessfully shrunk';EXEC sp029UpdateBatchLog @BatchLogId, @Message
END TRY
BEGIN CATCH
	SELECT @Message ='Shrink PaDS_Counter_Data_log file Failed:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE() ;EXEC sp029UpdateBatchLog @BatchLogId, @Message
END CATCH

GO
GRANT EXECUTE ON sp601PopulateActivityLog to PaDSSQLServerUser
