﻿'Modification History
'30/08/22   Julian Gates    SIR5540 - Initial Version
'01/03/23   James Woosnam   SIR5565 - Add GetEmailDistributionProgressSummaryHTML
'24/5/23    James Woosnam   SIR5642 - Allow entered SubId list and email list

Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class EmailDistribution
#Region "Class Properties"
    Public MainDataset As New DataSet
    Public ReadonlyDataset As New DataSet
    Dim UserSession As BusinessLogic.UserSession
    Dim SentEmailsCount As Integer = 0
    Dim BatchLog As BatchLog = Nothing
    Dim BatchJobId As Integer = 0
    Public ProcessNotes As String = "
All people requiring emails need to to be added to the EmailDistributionLog table, key fields:
Status:          This must initially be set to NotSent
EmailName:       Unique name for this batch of emails, used when invoking Ron from Test harness.
TemplateFileName:Name of the template HTM file for this email that is stored in the main terms and conditions folder.  Fields from the table will be merged in to this file is surrounded by {{FieldName}}.  May need to check the text source as sometimes words can put in HTML between the {{ and the field name.
EmailAddress:    This must be populated
EmailSortOrder:  Can be use to dictate the order that the emails are sent, If NULL uses EmailDistributionLogId
EmailFromAccount,EmailBody,EmailSentDate,BatchLogId: Populated once the email is sent

A new section on the test harness will allow the following parameters to be entered and added to a new batch job:
EmailName:      As Above
NoOfEmailsInBatch:  Batch job will send this number of email and then stop
EmailFromAccount:   This is the account to send the email, the password comes from parameter SMPTPassword which is the same for sales@pep-web.org and sales@psychoanalystdatabase.com.  This will need more work if other accounts used.
"
    Dim _EmailDistributionId As Integer = Nothing
    Public Property EmailDistributionId() As Integer
        Get
            If Me._EmailDistributionId = Nothing Then
                If Me.MainDataset.Tables.Count > 0 Then
                    Me._EmailDistributionId = Me.EmailDistributionRow("EmailDistributionId")
                End If
            End If
            Return Me._EmailDistributionId
        End Get
        Set(ByVal Value As Integer)
            _EmailDistributionId = Value
            'initilise dataset
            Me.Initilise()
        End Set
    End Property
    Enum EmailDistributionStats
        Initial
        Pending
        Emailing
        Complete
        Failed
    End Enum
    Public Property EmailDistributionStatus As EmailDistributionStats
        Get
            Return [Enum].Parse(GetType(EmailDistributionStats), Me.EmailDistributionRow("EmailDistributionStatus"))
        End Get
        Set(value As EmailDistributionStats)
            Me.EmailDistributionRow("EmailDistributionStatus") = value.ToString
        End Set
    End Property
    Enum SubscriberSourceTypes
        CurrentSubscriptionToProducts
        EnteredSubscriberIdList
        SalesOrder
        EnteredEmailAddressList
    End Enum
    Public ReadOnly Property SubscriberSourceType As SubscriberSourceTypes
        Get
            Return [Enum].Parse(GetType(SubscriberSourceTypes), Me.EmailDistributionRow("SubscriberSourceType"))
        End Get
    End Property
    Public ReadOnly Property EmailName As String
        Get
            Return Me.EmailDistributionRow("EmailName")
        End Get
    End Property
    Private _db As Database = Nothing
    Public Property db() As Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As Database)

            Me._db = value
        End Set
    End Property
    Public ReadOnly Property ProductCodesForInClause As String
        Get
            Dim prodCodesSQL As String = ""
            If db.IsDBNull(Me.EmailDistributionRow("SubscribedToProductCodes"), "") = "" Then Return "''"
            For Each prodCode As String In Me.EmailDistributionRow("SubscribedToProductCodes").ToString.Split(",")
                prodCodesSQL += IIf(prodCodesSQL = "", "", ",") & "'" & prodCode & "'"
            Next
            Return prodCodesSQL
        End Get
    End Property
    Dim SendTestEmailToCurrentUserAsIfFirstSubscriber As Boolean = Nothing
    Dim _SubscriberRecipients As DataTable = Nothing
    Public ReadOnly Property SubscriberRecipients As DataTable
        Get

            Dim sql As String = "
SELECT 
	s.SubscriberId
	,s.SubscriberName
	,s.SubscriberStatus
	,s.FirstName
	,s.LastName
	,EmailAddress = sa.AddressText 
	,aff.SubscriberCategory 
	,s.PrimaryCountryId 
    ,c.CountryName
    ,ErrorMessage = CASE WHEN sa.SubscriberId IS NULL THEN 'No Email Address' ELSE '' END
                  + CASE WHEN s.SubscriberStatus NOT IN ('Current') THEN 'SubscriberStatus is ' + s.SubscriberStatus  ELSE '' END      
                  + CASE WHEN Aff.ParentSubscriberId IS NULL THEN 'Not affiliated to ' + (SELECT CompanyShortName FROM Company WHERE CompanyId =" & Me.EmailDistributionRow("CompanyId") & ")  ELSE '' END      
FROM Subscriber s
    LEFT JOIN Country c
    ON s.PrimaryCountryId = c.CountryId                
	LEFT JOIN SubscriberAddress sa
	ON sa.SubscriberId = s.SubscriberId 
	AND sa.AddressType = 'Email'
	AND sa.AddressDescription = 'Main'
    LEFT JOIN SubscriberAffiliate Aff
	ON aff.ChildSubscriberID = s.SubscriberId 
	AND aff.ParentSubscriberID = (SELECT c.GroupParentSubscriberId  FROM Company c WHERE c.CompanyId=" & Me.EmailDistributionRow("CompanyId") & ")"
            If Me.SubscriberSourceType = SubscriberSourceTypes.CurrentSubscriptionToProducts Then sql += "
	INNER JOIN SalesOrderLine sol
	    INNER JOIN SalesOrder so
	    ON so.OrderNumber = sol.OrderNumber 
	    AND so.SalesOrderStatus in ('Complete','Confirmed')
	ON sol.SubscriberId = s.SubscriberId
    AND sol.IsCancel <> 1
    AND ISNULL(sol.RecurringSubscriptionEndDate,'31-dec-4949') > GETDATE()
    AND sol.ProductCode IN (" & ProductCodesForInClause & ")"
            sql += "
WHERE 1 = 1"
            Select Case Me.SubscriberSourceType
                Case SubscriberSourceTypes.EnteredEmailAddressList, SubscriberSourceTypes.EnteredSubscriberIdList
                    sql += "
AND s.subscriberId IN (" & db.IsDBNull(EmailDistributionRow("SubscriberIdList"), "0") & ")"
            End Select

            If db.IsDBNull(EmailDistributionRow("SubscriberCategoryFilter"), "") <> "" Then sql += "
AND Aff.SubscriberCategory='" & EmailDistributionRow("SubscriberCategoryFilter") & "'"

            If db.IsDBNull(EmailDistributionRow("CountryIdFilter"), "") <> "" Then sql += "
AND s.PrimaryCountryId='" & EmailDistributionRow("CountryIdFilter") & "'"

            sql += "
ORDER BY 
	s.SubscriberName
"
            _SubscriberRecipients = db.GetDataTableFromSQL(sql)
            Return _SubscriberRecipients
        End Get
    End Property
    Public ReadOnly Property ProgressSummary As String
        Get
            Dim sql As String = "
SELECT
	l.EmailDistributionStatus 
	,NoOfSubscribers = count(*)
FROM EmailDistributionLog l WITH (NOLOCK)
WHERE l.EmailName = '" & Me.EmailName & "'
GROUP BY
	l.EmailDistributionStatus 
ORDER BY
	l.EmailDistributionStatus 
"
            Dim t As DataTable = db.GetDataTableFromSQL(sql)
            Dim html As String = ""
            If t.Rows.Count = 0 Then Return "Emails have not yet been submitted"
            html += "<table width='400' border='0' cellpadding='5' class='selectTable'>"
            html += "  <tr>"
            html += "    <td class='fldTitle'>Status</td>"
            html += "    <td class='fldTitle' align='right'>No of Subscribers</td>"
            html += "  </tr>"
            Dim lastProductCode As String = ""
            Dim afterTotalHTML As String = ""
            Dim totalSubs As Integer = 0
            For Each row As DataRow In t.Rows
                html += "  <tr>"
                html += "	    <td Class='fldView' align='left'>" & row("EmailDistributionStatus") & "</td>"
                html += "	    <td Class='fldView' align='right'>" & Format(db.IsDBNull(row("NoOfSubscribers"), 0), "#,##0") & "</td>"
                html += "  </tr>"
                totalSubs += db.IsDBNull(row("NoOfSubscribers"), 0)
            Next
            html += "  <tr>"
            html += "	    <td class='fldViewBoldRight'>Total</td>"
            html += "	    <td class='fldViewBoldRight'>" & Format(totalSubs, "#,##0") & "</td>"
            html += "  </tr>"
            html += "</table>"
            Return html
        End Get
    End Property
#End Region

#Region "DependantTables"
    '***********************************************
    'EmailDistribution
    Public ReadOnly Property EmailDistribution() As DataTable
        Get
            If Me.MainDataset.Tables("EmailDistribution") Is Nothing Then
                Me.daEmailDistribution.Fill(Me.MainDataset, "EmailDistribution")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("EmailDistribution").Columns("EmailDistributionId")}
            Me.MainDataset.Tables("EmailDistribution").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("EmailDistribution")
        End Get
    End Property
    Private _daEmailDistribution As SqlDataAdapter
    Private ReadOnly Property daEmailDistribution() As SqlDataAdapter
        Get
            If Me._daEmailDistribution Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM EmailDistribution"
                If Me.EmailDistributionId = Nothing Then
                    sql += " WHERE 1=2"
                Else
                    sql += " WHERE EmailDistributionId=" & Me.EmailDistributionId
                End If

                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daEmailDistribution = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daEmailDistribution)
                _daEmailDistribution.UpdateCommand = cmdBld.GetUpdateCommand()
                _daEmailDistribution.InsertCommand = cmdBld.GetInsertCommand()
                _daEmailDistribution.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daEmailDistribution.InsertCommand.Transaction = Me.db.DBTransaction
                _daEmailDistribution.UpdateCommand.Transaction = Me.db.DBTransaction
                _daEmailDistribution.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daEmailDistribution
        End Get
    End Property

    Public ReadOnly Property EmailDistributionRow() As DataRow
        Get
            If Me.EmailDistribution.Rows.Count = 0 Then
                Me.daEmailDistribution.Fill(Me.MainDataset.Tables("EmailDistribution"))
                If Me.EmailDistribution.Rows.Count = 0 Then
                    Throw New Exception("UserError: EmailDistribution Id can't be found")
                End If
            End If
            Return Me.EmailDistribution.Rows(0)
        End Get
    End Property

    Private Sub Initilise()
        Dim xx As Integer = 0
        MainDataset.Clear()
        Me._daEmailDistribution = Nothing
        xx = Me.EmailDistribution.Rows.Count
    End Sub
    '***********************************************
#End Region

    Sub New(ByVal db As Database)
        Me.db = db
    End Sub
    Sub New(ByVal EmailDistributionId As Integer, ByVal db As Database)
        Me.db = db
        Me.EmailDistributionId = EmailDistributionId
        Me.Initilise()
    End Sub
    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As BusinessLogic.UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.EmailDistributionId = 0
    End Sub

    Sub New(ByVal EmailDistributionId As String, ByVal db As BusinessLogic.Database, ByVal UserSession As BusinessLogic.UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.EmailDistributionId = EmailDistributionId
        Me.Initilise()
    End Sub


#Region "Actions"

    Public Sub Save()
        Dim sql As String = ""
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Me.daEmailDistribution.Update(Me.MainDataset, "EmailDistribution")

            If TranStartedHere Then
                Me.db.CommitTran()
            End If

        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try
    End Sub

    Sub AddNewEmailDistribution(SubscriberSourceType As SubscriberSourceTypes, ProductCode As String, CompanyId As Integer)
        Dim emailName As String = Now.ToString("yyyy-MM MMM") & " Bulk Email"
        Select Case SubscriberSourceType
            Case SubscriberSourceTypes.CurrentSubscriptionToProducts
                emailName = Now.ToString("yyyy-MM MMM") & " Letter to " & ProductCode
        End Select
        Me.AddNewEmailDistribution(emailName, SubscriberSourceType, ProductCode, CompanyId)
    End Sub
    Sub AddNewEmailDistribution(EmailName As String, SubscriberSourceType As SubscriberSourceTypes, ProductCode As String, CompanyId As Integer)
        Try

            Dim nr As DataRow = Me.EmailDistribution.NewRow
            nr("EmailDistributionId") = -1

            nr("EmailName") = emailName
            Dim DupNo As Integer = 1
            Do While db.DLookup("EmailName", "EmailDistribution", "EmailName='" & nr("EmailName") & "'") IsNot Nothing
                nr("EmailName") = emailName & "-" & DupNo
                DupNo += 1
            Loop

            nr("EmailDistributionStatus") = "Initial"
            nr("CompanyId") = CompanyId
            nr("SubscriberSourceType") = SubscriberSourceType.ToString
            nr("SubscribedToProductCodes") = ProductCode
            Me.EmailDistribution.Rows.Add(nr)
            Me.Save()
            Me.EmailDistributionId = db.DLookup("MAX(EmailDistributionId)", "EmailDistribution", "")
        Catch ex As Exception
            Throw New Exception("Add Email Distribution failed:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub PopulateEmailDistributionLog(emailName As String)
        db.BeginTran()
        Try
            For Each row As DataRow In Me.SubscriberRecipients.Rows
                Try
                    Dim sendToEmail As String = db.IsDBNull(row("EmailAddress"), "")
                    If SendTestEmailToCurrentUserAsIfFirstSubscriber Then sendToEmail = db.DLookup("ISNULL(EmailAddress,'')", "RemoteUser", "UserId=" & Me.UserSession.UserId)
                    If sendToEmail = "" Then Throw New Exception("No Email Address")
                    Me.AddToSubscriberEmailToDitributionLog(EmailName:=emailName,
                                                                  EmailSubject:=Me.EmailDistributionRow("EmailSubject"),
                                                                  EmailBody:=Me.EmailDistributionRow("EmailHTML"),
                                                                  SendToEmailAddress:=sendToEmail,
                                                                  SubscriberId:=row("SubscriberId"),
                                                                  CompanyId:=EmailDistributionRow("CompanyId"),
                                                                    EmailDistributionId:=Me.EmailDistributionId)
                    If SendTestEmailToCurrentUserAsIfFirstSubscriber Then Exit For
                Catch ex As Exception
                    Throw New Exception("PopulateEmailDistributionLog failed for SubId:" & row("SubscriberId") & ":" & ex.Message)
                End Try

            Next
            If Not SendTestEmailToCurrentUserAsIfFirstSubscriber Then

            End If

            db.CommitTran()
        Catch ex As Exception
            db.RollbackTran()
            Throw New Exception("PopulateEmailDistributionLog failed:" & ex.Message)
        End Try
    End Sub
    Public Sub StartDistribution(Optional SendTestEmailToCurrentUserAsIfFirstSubscriber As Boolean = Nothing)
        Try
            Me.SendTestEmailToCurrentUserAsIfFirstSubscriber = SendTestEmailToCurrentUserAsIfFirstSubscriber
            Dim lEmailName As String = Me.EmailName
            If SendTestEmailToCurrentUserAsIfFirstSubscriber Then
                lEmailName += "TestTo" & UserSession.UserName
                db.ExecuteSQL("DELETE FROM EmailDistributionLog WHERE EmailDistributionId=" & EmailDistributionId)
            End If

            Me.PopulateEmailDistributionLog(lEmailName)
            If SendTestEmailToCurrentUserAsIfFirstSubscriber Then
                Me.NoOfEmailsInBatch = 2
                SendEmails() 'PopulateEmailDistributionLog will only have put 1 sub on log
            Else
                Me.Submit(NoOfEmailsInBatch:=80)
            End If

        Catch ex As Exception
            Throw New Exception("StartDistribution failed:" & ex.Message)
        End Try
    End Sub


    Public Sub Submit(NoOfEmailsInBatch As Integer,
                      Optional ScheduledStartDateTime As Date = Nothing
                                 )

        Dim bj As New BusinessLogic.BatchJob(db)
        bj.SubmittedByUserSessionId = Me.UserSession.UserSessionIdGUID
        bj.Parameters.Add("EmailDistributionId", Me.EmailDistributionId)
        bj.Parameters.Add("NoOfEmailsInBatch", NoOfEmailsInBatch)

        If ScheduledStartDateTime = Nothing Then ScheduledStartDateTime = Now()
        bj.ScheduledStartDateTime = ScheduledStartDateTime
        bj.CreateBatchJobEntry("SendDistributionEmails", db)
        Me.EmailDistributionStatus = EmailDistributionStats.Pending
        Me.Save()
    End Sub

    Public Sub Execute(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.Execute(Parameters.GetValue("NoOfEmailsInBatch"))
    End Sub
    Dim NoOfEmailsInBatch As Integer = 0
    ReadOnly Property EmailFromAccount As String
        Get
            Return db.GetParameterValue("EmailFromForCompanyId:" & EmailDistributionRow("CompanyId"))
        End Get
    End Property
    Public Sub Execute(NoOfEmailsInBatch As Integer)
        Me.NoOfEmailsInBatch = NoOfEmailsInBatch
        Me.BatchLog = New BatchLog("Emailing" _
                                     , "EmailName:" & EmailName & ";NoOfEmailsInBatch:" & NoOfEmailsInBatch _
                                     , Me.db _
                                     , Me.BatchJobId)

        Try
            Me.EmailDistributionStatus = EmailDistributionStats.Emailing
            Me.Save()
            SendEmails()
            Me.EmailDistributionStatus = EmailDistributionStats.Complete
            Me.Save()
            BatchLog.Update(SentEmailsCount & " emails sent in total")

            BatchLog.Update("Complete", "Complete")
        Catch ex As Exception
            Me.EmailDistributionStatus = EmailDistributionStats.Failed
            BatchLog.Update("Emailing Failed:" & ex.ToString, "Failed")
            Throw New Exception("Emailing Failed:" & ex.ToString)
        End Try
    End Sub
    Public Sub SendEmails()
        '15/12/21   James Woosnam   SIR5381 - Tweaked to work with SalesOrder.PopulateAndSubmitBlockConfirmationEmail and resubmit job if limits reached
        Dim BatchlogId As Integer = 0
        If BatchLog IsNot Nothing Then BatchlogId = BatchLog.BatchLogId
        Dim Body As String = ""
        Dim Subject As String = ""
        Dim EmailsSentInLast24Hours As Integer = db.DLookup("count(*)", "EmailDistributionLog", "EmailName = '" & Me.EmailName & "' AND EmailSentDate BETWEEN DATEADD(DAY,-1,GETDATE()) AND GETDATE() AND EmailFromAccount = '" & EmailFromAccount & "'")
        Dim EmailMaxIn24Hours As Integer = db.GetParameterValue("EmailMaxIn24Hours", 2)
        If EmailsSentInLast24Hours >= EmailMaxIn24Hours Then
            BatchLog.Update("Sending more emails will exceed EmailMaxIn24Hours parameter:" & EmailMaxIn24Hours & ".  A new job will start in 24 hours time.")
            Me.Submit(NoOfEmailsInBatch:=Me.NoOfEmailsInBatch, ScheduledStartDateTime:=Now.AddHours(24))
            Exit Sub
        End If
        '24/1/23    James Woosnam   SIR5562 - Add additional fields
        Dim sql As String = "
SELECT TOP " & NoOfEmailsInBatch & "
l.*
,OrdererSubscriberName = ordSub.SubscriberName
,ru.UserName 
,p.DisplayProductName 
,StyleCode = ''
FROM EmailDistributionLog l
    LEFT JOIN SalesOrder so
        INNER JOIN Subscriber ordSub
        ON ordSub.SubscriberId = so.SubscriberId
		INNER JOIN Product p
		ON p.ProductCode=so.PrimaryProductCode 
    ON so.OrderNumber = l.OrderNumber
    LEFT JOIN RemoteUserRights ror
		INNER JOIN RemoteUser ru
		ON ru.UserId = ror.UserId 
	ON ror.RightsToId = l.SubscriberId 
	AND ror.RightsType = 'Subscriber'
	AND ror.UserId = (SELECT MAX(ror2.UserId) FROM RemoteUserRights ror2 WHERE ror2.RightsToId = l.SubscriberId AND ror2.RightsType = 'Subscriber')
WHERE l.EmailDistributionId = " & Me.EmailDistributionId & "
AND l.EmailDistributionStatus = 'NotSent'
AND  l.EmailSentDate IS NULL
ORDER BY 
ISNULL(EmailSortOrder,999999) 
,EmailDistributionLogId
"
        Dim stdCode As New BusinessLogic.StdCode
        Dim tblRecipients As DataTable = Me.db.GetDataTableFromSQL(sql)
        For Each row As DataRow In tblRecipients.Rows
            Dim strEmailToAddress As String = ""
            Subject = row("EmailSubject")
            Try
                If db.DLookup("EmailDistributionStatus", "EmailDistributionLog", "EmailDistributionLogId=" & row("EmailDistributionLogId")) <> "NotSent" Then
                    '6/3/23     James Woosnam   Double check it is still NotSent and skip if is, just in case two jobs are trying to send at the same time
                    Exit Try
                End If

                Body = db.IsDBNull(row("EmailBody"), "")
                If Body = "" Then
                    Dim fiTemplate As New IO.FileInfo(IO.Path.Combine(db.GetParameterValue("TermsConditionsDirectoryPhysicalPath"), row("TemplateFileName")))
                    If Not fiTemplate.Exists Then Throw New Exception("Email Template:" & fiTemplate.FullName & " can't be found")

                    Body = stdCode.GetFileText(fiTemplate.FullName)

                Else
                    If db.IsDBNull(row("TemplateFileName"), "") <> "" Then
                        Throw New Exception("Both EmailBody and TemplateFileName have been entered in the EmailDistributionLog row for EmailDistributionLogId:" & row("EmailDistributionLogId") & ". one must be blank")
                    End If
                End If
                For Each col As DataColumn In tblRecipients.Columns
                    If Not db.IsDBNull(row(col.ColumnName)) Then Body = Body.Replace("{{" & col.ColumnName & "}}", row(col.ColumnName))
                Next
                If db.IsDBNull(row("EmailAddress"), "") = "" Then
                    Throw New Exception("Email Address Blank for EmailDistributionLogId:" & row("EmailDistributionLogId"))
                End If
                strEmailToAddress = row("EmailAddress")
                Dim email As New BusinessLogic.Email(db)
                If Not Me.db.IsOnLiveServer Then
                    Dim TestEmail As String = ""
                    Try
                        TestEmail = db.GetParameterValue("PEPRenewalEmailTestToAddress")
                    Catch ex As Exception
                        TestEmail = "Support@zedra.co.uk"
                    End Try
                    strEmailToAddress = strEmailToAddress.Substring(0, strEmailToAddress.IndexOf("@")) & TestEmail.Substring(TestEmail.IndexOf("@"), TestEmail.Length - TestEmail.IndexOf("@"))
                End If
                email.SendTo = strEmailToAddress
                email.From = EmailFromAccount
                email.Subject = row("EmailSubject")
                email.Body = Body
                email.Send()
                sql = "
                        UPDATE EmailDistributionLog
                        SET EmailSentDate = GETDATE()
                            ,EmailDistributionStatus = 'Successfull'
                            ,EmailFromAccount = @EmailFromAccount
                            ,EmailBody = @EmailBody
                            ,BatchLogId = " & BatchlogId & "
                        WHERE EmailDistributionLogId = " & row("EmailDistributionLogId")
                Dim cmd As New SqlClient.SqlCommand(sql, db.DBConnection, db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailFromAccount", System.Data.SqlDbType.VarChar, 100, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , EmailFromAccount))
                cmd.Parameters.Add("@EmailBody", System.Data.SqlDbType.VarChar, 8000).Value = Body
                cmd.ExecuteNonQuery()

                If BatchlogId <> 0 Then BatchLog.Update(strEmailToAddress & " sent.")
                SentEmailsCount += 1

            Catch ex As Exception
                Dim msg As String = ""
                sql = "
                        UPDATE EmailDistributionLog
                        SET EmailDistributionStatus = 'Failed'
                            ,ExtraInfo = @ExtraInfo
                        WHERE EmailDistributionLogId = " & row("EmailDistributionLogId")
                Dim cmd As New SqlClient.SqlCommand(sql, db.DBConnection, db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ExtraInfo", System.Data.SqlDbType.VarChar, 8000, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , ex.Message & Environment.NewLine & db.IsDBNull(row("ExtraInfo"), "")))
                cmd.ExecuteNonQuery()
                If BatchlogId <> 0 Then BatchLog.Update(strEmailToAddress & " failed:" & ex.Message)
            End Try
            If SendTestEmailToCurrentUserAsIfFirstSubscriber Then Exit For

        Next
        If BatchlogId <> 0 Then BatchLog.Update("===================")
        If BatchlogId <> 0 Then BatchLog.Update("Emails successfully sent in this batch:" & SentEmailsCount)
        If BatchlogId <> 0 Then BatchLog.Update("===================")

        sql = "
SELECT 
EmailDistributionStatus
,NoOfEmails = count(*)
FROM EmailDistributionLog l
WHERE l.EmailName = '" & Me.EmailName & "'
GROUP BY EmailDistributionStatus
ORDER BY EmailDistributionStatus
"
        Dim tResults As DataTable = db.GetDataTableFromSQL(sql)
        Dim totalCount As Integer = 0
        For Each r As DataRow In tResults.Rows
            If BatchlogId <> 0 Then BatchLog.Update(r("EmailDistributionStatus") & ":" & CInt(r("NoOfEmails")).ToString("#,##0"))
            totalCount += r("NoOfEmails")
        Next
        If BatchlogId <> 0 Then BatchLog.Update("Total:" & totalCount.ToString("#,##0"))
        If BatchlogId <> 0 Then BatchLog.Update("===================")
        If tblRecipients.Rows.Count = NoOfEmailsInBatch Then
            '2/8/22 Don't start another job unless there were some processed in this 
            Dim EmailMinutesTilNextBatchJob As Integer = db.GetParameterValue("EmailMinutesTilNextBatchJob", 15)
            If BatchlogId <> 0 Then BatchLog.Update("Email distribution stopped as a batch of:" & SentEmailsCount & " have been processed has reached the batch limit.  A new job will start in " & EmailMinutesTilNextBatchJob & " minutes.")
            Me.Submit(NoOfEmailsInBatch:=Me.NoOfEmailsInBatch, ScheduledStartDateTime:=Now.AddMinutes(EmailMinutesTilNextBatchJob))
            Exit Sub
        Else
            If BatchlogId <> 0 Then BatchLog.Update("No More to process:")

        End If
        'must have completed all emails

    End Sub
    Public Function AddToSubscriberEmailToDitributionLog(EmailName As String,
                                        EmailSubject As String,
                                        EmailBody As String,
                                        SendToEmailAddress As String,
                                        SubscriberId As Integer,
                                        CompanyId As Integer,
                                        Optional EmailDistributionId As Integer = Nothing,
                                        Optional OrderNumber As Integer = 0,
                                        Optional SalesOrderLineId As Integer = 0,
                                        Optional EmailDistributionStatus As String = "NotSent"
                                        ) As Integer
        Dim sql As String = ""
        Try

            sql = "

INSERT INTO EmailDistributionLog (
		EmailSubject
	  ,EmailDistributionStatus
      ,EmailName
      ,EmailBody
	  ,TemplateFileName
      ,SubscriberId
      ,SubscriberName
      ,FirstName
      ,LastName
      ,EmailAddress
      ,EmailFromAccount
      ,ExtraInfo
	  ,EmailFooterSystemText
      ,OrderNumber
      ,SalesOrderLineId
        ,EmailSentDate
" & IIf(EmailDistributionId = Nothing, "", ",EmailDistributionId") & "
	  )
SELECT 
	  EmailSubject= @EmailSubject
	  ,EmailDistributionStatus=@EmailDistributionStatus
      ,EmailName =  @EmailName
      ,EmailName =  @EmailBody
	  ,TemplateFileName=''
      ,SubsriberId = s.SubscriberId
      ,SubscriberName = s.SubscriberName
      ,FirstName = s.FirstName
      ,LastName = s.LastName
      ,EmailAddress = @SendToEmailAddress
      ,EmailFromAccount = dbo.fn017GetParameter('EmailFromForCompanyId:" & IIf(CompanyId = 0, 2, CompanyId) & "')
	  ,ExtraInfo = '' 
	  ,EmailFooterSystemText = ''
      ,OrderNumber= " & OrderNumber & "
      ,SalesOrderLineId = " & SalesOrderLineId & "
      ,EmailSentDate = " & IIf(EmailDistributionStatus = "Successfull", "GETDATE()", "NULL") & "
" & IIf(EmailDistributionId = Nothing, "", ",EmailDistributionId=" & EmailDistributionId) & "
FROM Subscriber s
WHERE s.SubscriberId = " & SubscriberId

            Dim cmd As New SqlClient.SqlCommand(sql, db.DBConnection, db.DBTransaction)
            cmd.Parameters.Add("@EmailSubject", System.Data.SqlDbType.VarChar, 500).Value = EmailSubject
            cmd.Parameters.Add("@EmailDistributionStatus", System.Data.SqlDbType.VarChar, 20).Value = EmailDistributionStatus
            cmd.Parameters.Add("@EmailName", System.Data.SqlDbType.VarChar, 500).Value = EmailName
            cmd.Parameters.Add("@EmailBody", System.Data.SqlDbType.VarChar, -1).Value = EmailBody
            cmd.Parameters.Add("@SendToEmailAddress", System.Data.SqlDbType.VarChar, 200).Value = SendToEmailAddress
            cmd.ExecuteNonQuery()
            Return CInt(db.DLookup("MAX(EmailDistributionLogId)", "EmailDistributionLog", "SubscriberId=" & SubscriberId))
        Catch ex As Exception
            Throw New Exception("AddToSubscriberEmailForDitribution Failed:" & ex.Message)
        End Try
    End Function

#End Region
    '01/03/23   James Woosnam   SIR5565 - Add GetEmailDistributionProgressSummaryHTML
    Public Function GetEmailDistributionProgressSummaryHTML() As String


        Dim strSQL As String = ""
        Dim html As String = ""
        Dim quantityTotal As Integer = 0
        strSQL = "
SELECT
NoOfSubsInOrder =(SELECT Count(DISTINCT SubscriberId) FROM SalesOrderLine sol WHERE sol.OrderNumber = l.OrderNumber  )
,l.EmailDistributionStatus 
,StatusCount = Count(*)
FROM EmailDistributionLog l
WHERE l.EmailDistributionId = " & Me.EmailDistributionId & "
GROUP BY
l.OrderNumber
,l.EmailDistributionStatus  "
        Try
            Dim tblOrderSummary As DataTable = db.GetDataTableFromSQL(strSQL)
            If tblOrderSummary.Rows.Count <> 0 Then
                html += "<table width='400' border='0' cellpadding='5' class='selectTable'>"
                html += "  <tr>"
                html += "    <td class='fldTitle'>No of Subs in Order:</td>"
                html += "    <td class='fldTitle' align='right'>" & tblOrderSummary.Rows(0)("NoOfSubsInOrder") & "</td>"
                html += "  </tr>"
                html += "  <tr>"
                html += "    <td Class='fldTitle'>&nbsp;</td>"
                html += "    <td class='fldTitle' align='right'>&nbsp;</td>"
                html += "  </tr>"
                html += "  <tr>"
                html += "    <td class='fldTitle'>Status</td>"
                html += "    <td class='fldTitle' align='right'>Count</td>"
                html += "  </tr>"
                Dim lastProductCode As String = ""
                Dim afterTotalHTML As String = ""
                For Each row As DataRow In tblOrderSummary.Rows
                    Dim fldClass As String = "fldView"
                    html += "  <tr>"
                    html += "	    <td Class='" & fldClass & "'>" & row("EmailDistributionStatus") & "</td>"
                    html += "	    <td class='" & fldClass & "' align='right'>" & Format(db.IsDBNull(row("StatusCount"), 0), "#,##0") & "</td>"
                    html += "  </tr>"
                    quantityTotal += 1
                Next
                html += "  <tr>"
                html += "	    <td class='fldViewBoldRight'>Total</td>"
                html += "	    <td class='fldViewBoldRight'>" & Format(quantityTotal, "#,##0") & "</td>"
                html += "  </tr>"
                html += "</table>"
            Else
                html += "<table width='400' border='0' cellpadding='5' class='selectTable'>"
                html += "  <tr>"
                html += "    <td class='fldView'>No Order data available</td>"
                html += "  </tr>"
                html += "</table>"
            End If

            Return html

        Catch ex As Exception
            Throw New Exception("GetEmailDistributionProgressSummaryHTML Failed:" & ex.Message)
        End Try
    End Function

End Class
