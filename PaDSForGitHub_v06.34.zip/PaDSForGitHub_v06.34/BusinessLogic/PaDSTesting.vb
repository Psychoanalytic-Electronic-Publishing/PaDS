﻿Imports BusinessLogic
Imports System.Data.SqlClient
Imports System.Environment
Public Class PaDSTesting
#Region "Class Properties"
    Dim testProductsAdded As New ArrayList()
    Public ProgressMessage As String = ""
    Private _db As Database = Nothing
    Dim DBConnectionString As String = Nothing

    Public Property db() As Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As Database)

            Me._db = value
        End Set
    End Property
    Public Sub New(db As Database, DBConnectionString As String)
        Me.db = db
        Me.db.CommandTimeout = 600
        Me.DBConnectionString = DBConnectionString
    End Sub
    Dim _UsrSessGeneral As UserSession = Nothing
    Private ReadOnly Property UsrSessGeneral As UserSession
        Get
            If _UsrSessGeneral Is Nothing Then
                _UsrSessGeneral = New BusinessLogic.UserSession(db)
                _UsrSessGeneral.Restore("")
            End If
            Return _UsrSessGeneral
        End Get
    End Property
#End Region
    Dim RunStartTime As Date = Now()
    Dim LastStartTime As Date = Now()
    Sub AddProgressMessage(Message As String)
        Dim ts As New TimeSpan()
        ProgressMessage += (Now() - RunStartTime).TotalSeconds.ToString("000") & ":" & (Now() - LastStartTime).TotalSeconds.ToString("000") & "-" & Message & NewLine
        LastStartTime = Now()
        Batchlog.Update(Message)
    End Sub
    Public Sub DeleteAllTestData()
        Dim tranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            db.BeginTran()
            tranStartedHere = True
        End If
        Try
            DeleteImports()
            Me.DeleteProducts()
            AddProgressMessage("Products Deleted")
            Me.DeleteContentsets()
            AddProgressMessage("Content sets Deleted")
            Dim DeletedSubs As New List(Of Integer)
            For Each r As DataRow In Me.TestSubscribers.Rows
                If Not DeletedSubs.Contains(CInt(r("SubscriberId"))) Then Me.DeleteUserAndSubscriber(db.IsDBNull(r("UserName"), "sfgddghj"), r("SubscriberId"))
                DeletedSubs.Add(CInt(r("SubscriberId")))
                AddProgressMessage(r("SubscriberName") & " Deleted")
            Next
            Me.DeleteUserAndSubscriber("Test6", 0)
            DeleteOtherdata()
            If tranStartedHere Then db.CommitTran()
        Catch ex As Exception
            If tranStartedHere Then db.RollbackTran()
            Throw ex
        End Try
    End Sub
    Public Sub DeleteOtherdata()
        db.ExecuteSQL("
DELETE FROM BatchJob WHERE BatchJobName = 'RepopulateAllPEPWebContent' and ISNULL(ActualStartDateTime ,ScheduledStartDateTime ) > DATEADD(MINUTE,-65,GETDATE())

")
        AddProgressMessage("RepopulateAllPEPWebContent Jobs Deleted")
    End Sub
    Public Property SurpressEmails As Boolean
        Get
            Return db.GetParameterValue("SurpressEmails", False)
        End Get
        Set(value As Boolean)
            db.SetParameterValue("SurpressEmails", value)
        End Set
    End Property
    Dim BatchJobId As Integer = Nothing
    Dim _Batchlog As BatchLog = Nothing
    Public ReadOnly Property Batchlog As BatchLog
        Get
            If _Batchlog Is Nothing Then
                _Batchlog = New BatchLog("ResetTestData", "", db, BatchJobId)

            End If
            Return _Batchlog
        End Get
    End Property
    Dim _ReportOutDirectory As IO.DirectoryInfo = Nothing
    Public ReadOnly Property ReportOutDirectory As IO.DirectoryInfo
        Get
            If _ReportOutDirectory Is Nothing Then
                _ReportOutDirectory = New IO.DirectoryInfo(IO.Path.Combine(db.GetParameterValue("ReportsPhysicalDir"), db.GetParameterValue("ReportOutDirectory")))
            End If
            Return _ReportOutDirectory
        End Get
    End Property
    Dim EmailDistributionLogIdAtStart As Integer = 0
    Public Sub ResetTestData(TestUserPassword As String, SurpressEmails As Boolean, Optional BatchJobId As Integer = 0)

        Me.SurpressEmails = SurpressEmails
        Me.BatchJobId = BatchJobId
        Batchlog.Update("SurpressEmails:" & SurpressEmails.ToString)
        Try
            EmailDistributionLogIdAtStart = db.DLookup("MAX(EmailDistributionLogId)", "EmailDistributionLog", "")
            Dim tblRenewalSubscribers As DataTable = Me.db.GetDataTableFromSQL("EXEC sp236SubscribersRequiringReminders")
            If tblRenewalSubscribers.Rows.Count > 5 And Not Me.SurpressEmails Then
                Throw New Exception("In PaDsTesting.ResetTestData there are:" & tblRenewalSubscribers.Rows.Count & " subs requiring a renewal email, and the SupressEmails is False.  Please run first with emails surpressed.")
            End If
            '9/3/23 - Remove transaction as locking test too much
            '  db.BeginTran()
            Try
                If TestUserPassword = "" Then Throw New Exception("TestUserPassword must not be blank")
                Me.TestUserPassword = TestUserPassword
                If ReportOutDirectory.Exists Then
                    ReportOutDirectory.Delete(True)
                    ReportOutDirectory.Create()
                End If
                AddProgressMessage(ReportOutDirectory.FullName & " Deleted and re-created")

                Me.DeleteAllTestData()
                CreateTestProducts()
                AddProgressMessage("Products Created")
                CreateTestContent()
                AddProgressMessage("Content Created")
                CreateTestUsersSubsAndOrders()
                AddProgressMessage("Subs, Users and orders Created")
                DeleteOtherdata()

                db.ExecuteSQL("UPDATE BatchJob SET BatchJobStatus='PendingPaused' WHERE BatchJobStatus='Pending' AND ScheduledStartDateTime < DATEADD(MINUTE,5,GETDATE())")

                '   db.CommitTran()
            Catch ex As Exception
                '      If db.DBTransaction IsNot Nothing Then db.RollbackTran() 'might have already rollback to do correct logging in authenticate user
                Throw ex
            End Try

            Dim UsrSessGeneral As New BusinessLogic.UserSession(db)
            UsrSessGeneral.Restore("")
            UsrSessGeneral.Logon(db.GetParameterValue("AdminUserName"), db.GetParameterValue("AdminPassword"))

            Dim ru As New BusinessLogic.RemoteUser(500007, db, UsrSessGeneral)
            ru.ResetPasswordAndEmail()
            ru.RestoreOldPassword()
            ru.UserStatus = RemoteUser.UserStates.Active
            ru.Save()
            Dim rn As New BusinessLogic.SendRenewalEmail("TestRenewals", db)
            rn.Execute()
            AddProgressMessage("Renewl Email Sent")
            Dim UsrSess = New BusinessLogic.UserSession(db)
            UsrSess.Restore("")
            UsrSess.Logon("Test7", TestUserPassword)

            '=======Proposed and merge========
            Dim sb As New BusinessLogic.Subscriber(500007, db, UsrSess)
            sb.CreateProposedSubscriber()
            AddProgressMessage("50007 CreateProposedSubscriber")

            sb = New BusinessLogic.Subscriber(sb.SubscriberId, db, UsrSessGeneral)
            sb.MergeSubscriber(500007, sb.SubscriberId, True)
            AddProgressMessage("50007 MergeSubscriber")
            '***If additional merge added need to add delete audit log in DeleteUserAndSubscriber
            '======================================

            '=======Imports Tests========
            Me.RunImportFileTests(UsrSessGeneral)
            '======================================

            '=======Run Renewal report
            Dim report As BusinessLogic.ReportSubscriberRenewal = Nothing
            report = New BusinessLogic.ReportSubscriberRenewal(500011, 2, "", db, UsrSess.UserSessionIdGUID)
            report.ReportSQL = report.GetSQL(2 _
                             , "T-PEPweb" _
                             , "DateRange" _
                             , "Groups" _
                             , Nothing _
                             , Now.AddMonths(-1) _
                             , Now.AddMonths(13) _
                             , db.GetDataTableFromSQL("SELECT SubscriberId FROM Subscriber WHERE Subscriberid in (500011)")
                            )
            report.Submit(CreateSubscriberImportBatches:=True)
            ProcessNextBatchJob()
            '======================================

            '=======Despatch Tests========
            Dim sProdCode As String = ""
            sProdCode = "TPV" & IJPYear1ReleaseDate.ToString("yy")
            DespatchPartNo(sProdCode, IJPYear1ReleaseDate, 1)
            DespatchPartNo(sProdCode, IJPYear1ReleaseDate, 2)
            DespatchPartNo(sProdCode, IJPYear1ReleaseDate, 3)
            DespatchPartNo(sProdCode, IJPYear1ReleaseDate, 4)
            DespatchPartNo(sProdCode, IJPYear1ReleaseDate, 5)
            DespatchPartNo(sProdCode, IJPYear1ReleaseDate, 6)
            sProdCode = "TPV" & IJPYear2ReleaseDate.ToString("yy")
            DespatchPartNo(sProdCode, IJPYear2ReleaseDate, 1)
            DespatchPartNo(sProdCode, IJPYear2ReleaseDate, 2)
            '======================================
            '=========Delete tests
            Dim ReturnMessage As String = ""
            Dim ObfuscateNotDelete As Boolean = True
            sb = New BusinessLogic.Subscriber(db.DLookup("SubscriberId", "Subscriber", "FirstName='Sub14ForOkDELETE'"), db, UsrSessGeneral)
            sb.DeleteOrObfuscateSubscriber("Test", ObfuscateNotDelete, ReturnMessage)
            AddProgressMessage("Sub14ForOkDELETE-Test Delete:" & ReturnMessage)
            sb.DeleteOrObfuscateSubscriber("Delete", ObfuscateNotDelete, ReturnMessage)
            AddProgressMessage("Sub14ForOkDELETE- Delete:" & ReturnMessage)
            sb = New BusinessLogic.Subscriber(db.DLookup("SubscriberId", "Subscriber", "FirstName='Sub15ForObfuscate'"), db, UsrSessGeneral)
            sb.DeleteOrObfuscateSubscriber("Test", ObfuscateNotDelete, ReturnMessage)
            AddProgressMessage("Sub15ForObfuscate-Test Delete:" & ReturnMessage)
            sb.SubmitDeleteOrObfuscateSubscriber()
            AddProgressMessage("Sub15ForObfuscate- submitted:" & ReturnMessage)
            Me.ProcessNextBatchJob()

            '=========END Delete tests

            Dim ResultsFile As New IO.FileInfo(Me.SaveTestResultsAsXML)
            ResultsFile.CopyTo(IO.Path.Combine(ResultsFile.Directory.FullName, "PaDSTestResults.xml"), True)
            Batchlog.Update("Test Data Reset Complete", "Complete")
        Catch ex As Exception
            Batchlog.Update("Test Data Reset Failed:" & ex.ToString, "Failed")
            Throw ex
        End Try
    End Sub
    Public Sub DespatchPartNo(ProductCode As String, Releasedate As Date, PartNo As Integer)
        Dim childProd As String = ProductCode & "P" & PartNo
        Dim so As New BusinessLogic.SalesOrder(db, Me.UsrSessGeneral)
        so.ExecuteDespatchSalesOrder(0, so.GetDespatchSubscriberSQL(SalesOrder.DespatchSQLPurposes.FileColumns, childProd, "All", True), so.GetDespatchSubscriberSQL(SalesOrder.DespatchSQLPurposes.FileFrom, childProd, "All", True), "All", False, childProd, Me.UsrSessGeneral.UserSessionIdGUID)
        System.Threading.Thread.Sleep(1000) ' sleep for 1 second so files are named differently

        db.ExecuteSQL("UPDATE SalesOrderLinePart SET DateDespatched='" & Releasedate.AddMonths(1 + ((PartNo - 1) * 2)).ToString("dd-MMM-yy") & "' WHERE ProductCode='" & childProd & "'")
        AddProgressMessage("DespatchPart" & ProductCode & "No:" & PartNo)

    End Sub
#Region "Populate Data"
    Public IJPYear1ReleaseDate As Date = CDate("01-" & Now.Date.AddMonths(-18).ToString("MM-yyyy"))
    Public IJPYear2ReleaseDate As Date = CDate("01-" & Now.Date.AddMonths(-6).ToString("MM-yyyy"))
    Dim emailTemplate As String = "PaDSxx@zedra.net"
    Public ReadOnly Property TestSubscribers As DataTable
        Get
            'The sql below had to be grouped to allow it to work with the test harness
            Dim sql As String = "
SELECT DISTINCT	
	s.SubscriberId
	,s.SubscriberName 
	,sa.AddressText 
	,ru.UserName 
FROM Subscriber s
    INNER JOIN SubscriberAddress sa
	ON sa.SubscriberId = s.SubscriberId 
	AND sa.AddressType = 'Email'
	LEFT JOIN RemoteUserRights rur
		INNER JOIN RemoteUser ru
		ON ru.UserId = rur.UserId 
	ON rur.RightsToId = s.SubscriberId 
	AND rur.RightsType = 'Subscriber'
WHERE (sa.AddressText like '" & emailTemplate.Replace("xx", "Test%") & "'
AND s.CreatedDateTime > dateadd(MONTH,-12,GETDATE()))
OR s.subscriberId between 500000 and 500099

ORDER BY
    s.SubscriberId
"
            Return db.GetDataTableFromSQL(sql)
        End Get
    End Property
    Sub CreateTestUsersSubsAndOrders()
        db.ExecuteSQL("
            UPDATE stblTableNumber SET LastNumber = 500000 WHERE TableName = 'SalesOrder'
            UPDATE stblTableNumber SET LastNumber = 500000 WHERE TableName = 'Subscriber'
            UPDATE stblTableNumber SET LastNumber = 500000 WHERE TableName = 'RemoteUser'
")
        Dim Subscbr As Subscriber = Nothing
        Dim SubSess As UserSession = Nothing
        Dim usrNm As String = ""
        '*************************
        usrNm = "Test1"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="Archive and TJV" & IJPYear1ReleaseDate.ToString("yy"),
                                          EmailAddress:=emailTemplate.Replace("xx", usrNm),
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)
        Me.AddProgressMessage("Test1 Added")
        Me.AddOrder(Subscbr, SubSess, {"T-PEPweb"}, CandidateStudent:=False)
        Me.AddOrder(Subscbr, SubSess, {"TJV" & IJPYear2ReleaseDate.ToString("yy"), "TPV" & IJPYear2ReleaseDate.ToString("yy")}, CandidateStudent:=False)
        Me.AddProgressMessage("Test1 orders Added")
        '*************************
        usrNm = "Test2"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="Video7Day",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)
        Me.AddProgressMessage("Test2 Added")
        Me.AddOrder(Subscbr, SubSess, {"T-Vid7Dy"}, CandidateStudent:=False)
        Me.AddProgressMessage("Test2 order Added")
        '*************************
        usrNm = "Test3"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="IJP Only",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)
        Me.AddProgressMessage("Test3 Added")
        Me.AddOrder(Subscbr, SubSess, {"TJV" & IJPYear1ReleaseDate.ToString("yy")}, CandidateStudent:=False)
        Me.AddOrder(Subscbr, SubSess, {"TJV" & IJPYear2ReleaseDate.ToString("yy")}, CandidateStudent:=False)
        '  Me.AddOrder(Subscbr, SubSess, {"T-PV102"}, CandidateStudent:=False)
        'IJPOpen
        Me.AddOrder(Subscbr, SubSess, {"T-IJPOpn"}, CandidateStudent:=False)
        Me.AddProgressMessage("Test3 order Added")
        '*************************
        usrNm = "Test4"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="All PEP",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)
        Me.AddProgressMessage("Test4 Added")
        Me.AddOrder(Subscbr, SubSess, {"T-PEPCur"}, CandidateStudent:=False, FailIfNotValidWebProduct:=False)
        Me.AddOrder(Subscbr, SubSess, {"T-PEPweb"}, CandidateStudent:=False, FailIfNotValidWebProduct:=True)
        Me.AddProgressMessage("Test4 order Added")
        '*************************
        usrNm = "Test5"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="All PEP",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)

        SubSess = GetSubscriberSession(Subscbr)
        Me.AddProgressMessage("Test5 Added")
        'Çonvert into org
        Subscbr.SubscriberRow("EntityType") = "Organisation"
        Subscbr.SubscriberRow("SubscriberName") = "Test5 Organisation with T-PEPweb"
        Subscbr.Save()
        Dim ru As New RemoteUser(Subscbr.RemoteUser.UserId, db, SubSess)
        ru.RemoteUserRow("Authoritylevel") = "GroupUser"
        ru.Save()
        ru = New RemoteUser(Subscbr.RemoteUser.UserId, db, SubSess)
        Dim newRow As DataRow = ru.RemoteUserAutoLogon.NewRow


        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -2
        newRow("AutoLogonStatus") = "InActive"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.IPAddress.ToString
        newRow("UserId") = ru.UserId
        newRow("Notes") = "Zedra Plusnet Broadband"
        newRow("MinIPAddress") = "81.174.164.198" 'Zedra Plusnet Broadband
        newRow("MaxIPAddress") = "81.174.164.198"
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -6
        newRow("AutoLogonStatus") = "Active"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.IPAddress.ToString
        newRow("UserId") = ru.UserId
        newRow("Notes") = "Random IP for Zedra Postman testing using X-Forwarded-For-PEP header"
        newRow("MinIPAddress") = "101.101.101.101"
        newRow("MaxIPAddress") = "101.101.101.101"
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -3
        newRow("UserId") = ru.UserId
        newRow("AutoLogonStatus") = "InActive"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.IPAddress.ToString
        newRow("Notes") = "Gavant test user"
        newRow("MinIPAddress") = "66.152.101.226" 'Gavant test user
        newRow("MaxIPAddress") = "66.152.101.226"
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -4
        newRow("UserId") = ru.UserId
        newRow("AutoLogonStatus") = "Active"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.Federated.ToString
        newRow("Notes") = "Test OpenAthens User:oasptemptest"
        newRow("FederatedEntity") = "https://sd.openathens.net/entity" '
        newRow("FederatedScope") = "" '
        newRow("IsFederatedLinkRequired") = True '
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -7
        newRow("UserId") = ru.UserId
        newRow("AutoLogonStatus") = "Active"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.Federated.ToString
        newRow("Notes") = "OpenAthens user:peptesting"
        newRow("FederatedEntity") = "https://idp.scilab-inc.com/openathens" '
        newRow("FederatedScope") = "" '
        newRow("IsFederatedLinkRequired") = True '
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -5
        newRow("UserId") = ru.UserId
        newRow("AutoLogonStatus") = "Active"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.ReferrerURL.ToString
        newRow("Notes") = "Zedra Dev Pads Home"
        newRow("ReferrerURL") = "http://localhost:46339/Pages/pg100HomeAdmin.aspx" '
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        ru.Save()
        Me.AddOrderBlock(Subscbr, SubSess, {"T-PEPweb"}, New IO.FileInfo("D:\Projects\PaDS2\PaDS\TestData\SubscriberImportFiles\Test4 Import Subscribers01.xlsx"))

        Me.AddProgressMessage("Test5 order Added")
        '*************************
        usrNm = "Test6" 'PEP admin user
        'Only need to delete user as no orders or subscriber
        db.ExecuteSQL("
declare @UserId int = (select userid from RemoteUser where username = '" & usrNm & "')
delete from RemoteUserRights   where UserId =@UserId
delete from RemoteUserAutoLogon   where UserId =@UserId
delete From RemoteUser   Where UserId =@UserId")
        ru = New RemoteUser(db, UsrSessGeneral)
        ru.AddNew(EmailAddress:="PaDS" & usrNm & "@zedra.net", AuthorityLevel:=UserSession.AuthorityLevels.SuperCompanyAdmins, FullUserName:=usrNm & " PEP SuperCompanyAdmin")
        ru.UserName = usrNm
        ru.UserStatus = RemoteUser.UserStates.Active
        ru.AddRights(RemoteUser.RightsTypes.Company, 2) 'PEP
        ru.AddRights(RemoteUser.RightsTypes.Subscriber, 29002) 'PEP
        ru.SetPassword(Me.TestUserPassword)
        ru.Save()
        Me.AddProgressMessage("Test6 User Added")
        db.GetNextNumber("Subscriber") ' increment the table no for subscriber so next will be 7
        '*************************
        usrNm = "Test7"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="Archive & JV/PV Renewing",
                                          EmailAddress:=emailTemplate.Replace("xx", usrNm),
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)
        Me.AddProgressMessage(usrNm & " Added")
        Me.AddOrder(Subscbr, SubSess, {"T-PEPweb"}, CandidateStudent:=True)
        Dim ord As New SalesOrder(db.DLookup("MAX(OrderNumber)", "SalesOrder", "SubscriberId=" & Subscbr.SubscriberId), db, SubSess)
        ord.SalesOrderRow("OrderDate") = CType(ord.SalesOrderRow("OrderDate"), Date).AddYears(-1).AddDays(CType(db.GetParameterValue("FirstReminderDaysBefore"), Integer) - 3)
        ord.SalesOrderRow("SubscriptionStartDateForAdd") = ord.SalesOrderRow("OrderDate")

        ord.Save()
        ord = New SalesOrder(ord.OrderNumber, db, SubSess)
        ord.Save() 'Save again to set RecurringSubscriptionStartDate
        'JV/PV Year1
        Me.AddOrder(Subscbr, SubSess, {"TJV" & IJPYear1ReleaseDate.ToString("yy"), "TPV" & IJPYear1ReleaseDate.ToString("yy")}, CandidateStudent:=False)
        ord = New SalesOrder(db.DLookup("MAX(OrderNumber)", "SalesOrder", "SubscriberId=" & Subscbr.SubscriberId), db, SubSess)
        ord.SalesOrderRow("OrderDate") = CType(ord.SalesOrderRow("OrderDate"), Date).AddYears(-1).AddDays(CType(db.GetParameterValue("FirstReminderDaysBefore"), Integer) - 3)
        ord.SalesOrderRow("SubscriptionStartDateForAdd") = ord.SalesOrderRow("OrderDate")
        ord.Save()
        ord = New SalesOrder(ord.OrderNumber, db, SubSess)
        ord.Save() 'Save again to set RecurringSubscriptionStartDate
        'JV/PV Year2
        Me.AddOrder(Subscbr, SubSess, {"TJV" & IJPYear2ReleaseDate.ToString("yy"), "TPV" & IJPYear2ReleaseDate.ToString("yy")}, CandidateStudent:=False)
        ord = New SalesOrder(db.DLookup("MAX(OrderNumber)", "SalesOrder", "SubscriberId=" & Subscbr.SubscriberId), db, SubSess)
        ord.SalesOrderRow("OrderDate") = CType(ord.SalesOrderRow("OrderDate"), Date).AddMonths(-7).AddDays(CType(db.GetParameterValue("FirstReminderDaysBefore"), Integer) - 3)
        ord.SalesOrderRow("SubscriptionStartDateForAdd") = ord.SalesOrderRow("OrderDate")
        ord.Save()
        ord = New SalesOrder(ord.OrderNumber, db, SubSess)
        ord.Save() 'Save again to set RecurringSubscriptionStartDate
        Me.AddProgressMessage(usrNm & " orders Added")

        '*************************
        '*************************
        usrNm = "Test8"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="RegisteredUser",
                                          EmailAddress:=emailTemplate.Replace("xx", usrNm),
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)

        For Each r As DataRow In Subscbr.SubscriberAddress.Rows
            If r("AddressType") = "Postal" Then
                r.Delete()
            End If
        Next
        Subscbr.SubscriberRow("DefaultPostalAddressId") = DBNull.Value
        '  Subscbr.AddSubscriberAffiliate(500005)

        Subscbr.Save()
        Me.AddProgressMessage(usrNm & " Added")
        '*************************
        '*************************
        usrNm = "Test9"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="PEP Moderator",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)
        Me.AddProgressMessage(usrNm & " Added")
        Me.AddOrder(Subscbr, SubSess, {"T-PEPCur"}, CandidateStudent:=False, FailIfNotValidWebProduct:=False)
        Me.AddOrder(Subscbr, SubSess, {"T-PEPweb"}, CandidateStudent:=False, FailIfNotValidWebProduct:=True)
        ru = New RemoteUser(Subscbr.RemoteUser.UserId, db, SubSess)
        ru.RemoteUserRow("IsModerator") = True
        ru.Save()
        Me.AddProgressMessage(usrNm & " order Added")
        '*************************
        '*************************
        usrNm = "Test10"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="GroupUserExpiredSub",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)

        SubSess = GetSubscriberSession(Subscbr)
        Me.AddProgressMessage(usrNm & " Added")
        'Çonvert into org
        Subscbr.SubscriberRow("EntityType") = "Organisation"
        Subscbr.SubscriberRow("SubscriberName") = "Test10 Organisation Expired Sub"
        Subscbr.Save()
        ru = New RemoteUser(Subscbr.RemoteUser.UserId, db, SubSess)
        ru.RemoteUserRow("Authoritylevel") = "GroupUser"
        ru.Save()
        ru = New RemoteUser(Subscbr.RemoteUser.UserId, db, SubSess)
        newRow = ru.RemoteUserAutoLogon.NewRow


        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -2
        newRow("AutoLogonStatus") = "InActive"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.IPAddress.ToString
        newRow("UserId") = ru.UserId
        newRow("Notes") = "Zedra Plusnet Broadband"
        newRow("MinIPAddress") = "81.174.164.198" 'Zedra Plusnet Broadband
        newRow("MaxIPAddress") = "81.174.164.198"
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -6
        newRow("AutoLogonStatus") = "Active"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.IPAddress.ToString
        newRow("UserId") = ru.UserId
        newRow("Notes") = "Random IP for Zedra Postman testing using X-Forwarded-For-PEP header"
        newRow("MinIPAddress") = "101.101.101.102"
        newRow("MaxIPAddress") = "101.101.101.102"
        ru.RemoteUserAutoLogon.Rows.Add(newRow)
        ru.Save()
        Me.AddOrder(Subscbr, SubSess, {"T-PEPweb"}, CandidateStudent:=False)
        ord = New SalesOrder(db.DLookup("MAX(OrderNumber)", "SalesOrder", "SubscriberId=" & Subscbr.SubscriberId), db, SubSess)
        ord.SalesOrderRow("OrderDate") = CType(ord.SalesOrderRow("OrderDate"), Date).AddMonths(-13)
        ord.SalesOrderRow("SubscriptionStartDateForAdd") = ord.SalesOrderRow("OrderDate")
        ord.Save()
        ord = New SalesOrder(ord.OrderNumber, db, SubSess)
        ord.Save() 'Save again to set RecurringSubscriptionStartDate

        Me.AddProgressMessage(usrNm & " order Added")
        '*************************
        '*************************

        usrNm = "Test11"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="GroupUserForImport",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)

        SubSess = GetSubscriberSession(Subscbr)
        Me.AddProgressMessage(usrNm & " Added")
        'Çonvert into org
        Subscbr.SubscriberRow("EntityType") = "Organisation"
        Subscbr.SubscriberRow("SubscriberName") = "Test11 " & ImportGroupSubNamePart
        Subscbr.Save()
        ru = New RemoteUser(Subscbr.RemoteUser.UserId, db, SubSess)
        ru.RemoteUserRow("Authoritylevel") = "GroupUser"
        ru.Save()
        Subscbr.AddCompanyAccount(CompanyId:=2, AccountType:="Society", DiscountRateId:=4, RateType:="Full", db.DLookup("SubscriberAddressId", "SubscriberAddress", "SubscriberId=" & Subscbr.SubscriberId & " AND AddressDescription='Billing'"))
        Subscbr.AddCompanyAccount(CompanyId:=1, AccountType:="Society", DiscountRateId:=1, RateType:="Full", db.DLookup("SubscriberAddressId", "SubscriberAddress", "SubscriberId=" & Subscbr.SubscriberId & " AND AddressDescription='Billing'"))
        '*************************
        '*************************
        usrNm = "Test12"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="GroupUserForMOREImport",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)

        SubSess = GetSubscriberSession(Subscbr)
        Me.AddProgressMessage(usrNm & " Added")
        'Çonvert into org
        Subscbr.SubscriberRow("EntityType") = "Organisation"
        Subscbr.SubscriberRow("SubscriberName") = "Test12 MORE! " & ImportGroupSubNamePart
        Subscbr.Save()
        ru = New RemoteUser(Subscbr.RemoteUser.UserId, db, SubSess)
        ru.RemoteUserRow("Authoritylevel") = "GroupUser"
        ru.Save()
        Subscbr.AddCompanyAccount(CompanyId:=2, AccountType:="Society", DiscountRateId:=4, RateType:="Full", db.DLookup("SubscriberAddressId", "SubscriberAddress", "SubscriberId=" & Subscbr.SubscriberId & " AND AddressDescription='Billing'"))
        Subscbr.AddCompanyAccount(CompanyId:=1, AccountType:="Society", DiscountRateId:=1, RateType:="Full", db.DLookup("SubscriberAddressId", "SubscriberAddress", "SubscriberId=" & Subscbr.SubscriberId & " AND AddressDescription='Billing'"))


        '*************************
        '*************************
        usrNm = "Test13" 'GroupAdmin for Test11
        'Only need to delete user as no orders or subscriber
        db.ExecuteSQL("
declare @UserId int = (select userid from RemoteUser where username = '" & usrNm & "')
delete from RemoteUserRights   where UserId =@UserId
delete from RemoteUserAutoLogon   where UserId =@UserId
delete From RemoteUser   Where UserId =@UserId")
        ru = New RemoteUser(db, UsrSessGeneral)
        ru.AddNew(EmailAddress:="PaDS" & usrNm & "@zedra.net", AuthorityLevel:=UserSession.AuthorityLevels.GroupAdmins, FullUserName:=usrNm & " GroupAdmin for test11")
        ru.UserName = usrNm
        ru.UserStatus = RemoteUser.UserStates.Active
        ru.AddRights(RemoteUser.RightsTypes.Subscriber, 500011) 'GroupUserForImport
        ru.SetPassword(Me.TestUserPassword)
        ru.Save()
        Me.AddProgressMessage(usrNm & " User Added")
        db.GetNextNumber("Subscriber") ' increment the table no for subscriber so next will be 7

        '*************************
        '*************************
        usrNm = "Test14"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="Sub14ForOkDELETE",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)
        Me.AddProgressMessage("Test14 Added")
        '*************************
        '*************************
        usrNm = "Test15"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="Sub15ForObfuscate",
                                          EmailAddress:=emailTemplate.Replace("xx", usrNm),
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)
        Me.AddProgressMessage("Test15 Added")
        Me.AddOrder(Subscbr, SubSess, {"T-PEPweb"}, CandidateStudent:=False)
        Me.AddProgressMessage("Test15 orders Added")
        '*************************
        db.ExecuteSQL("
            UPDATE stblTableNumber SET LastNumber = (SELECT MAX(OrderNumber) FROM SalesOrder WHERE OrderNumber < 500000) WHERE TableName = 'SalesOrder'
            UPDATE stblTableNumber SET LastNumber = (SELECT MAX(SubscriberId) FROM Subscriber WHERE SubscriberId < 500000) WHERE TableName = 'Subscriber'
            UPDATE stblTableNumber SET LastNumber = (SELECT MAX(UserId) FROM RemoteUser WHERE UserId < 500000) WHERE TableName = 'RemoteUser'
")
    End Sub
    Dim ImportGroupSubNamePart As String = "Group For Imports"
    Sub CreateTestProducts()

        Me.DeleteProducts()
        Dim prod As Product = Nothing
        '*******************************
        Dim ReceiptEmailHTML As String = "Dear {{Title}} {{FirstName}} {{LastName}},<BR><BR>This is test product:{{DisplayProductName}}.<br><br>OrderNumber={{OrderNumber}}<br><br>OrdererSubscriberName={{OrdererSubscriberName}}<br><br>UserName={{UserName}}<br>{{NewUserActivateTextAndLink}}<br>ProductCode={{ProductCode}}<br><br>DisplayProductName={{DisplayProductName}}"
        prod = Me.AddProduct(ProductCode:="T-PEPweb",
                  CompanyId:=2,
                  AssociatedProductCode:="",
                  RecurringSubscriptionFlag:=True,
                    RecurringSubscriptionUnitType:="Months",
                    RecurringSubscriptionUnits:=12,
                    SellOnWebFlag:=True)
        prod.ProductRow("ReceiptEmailHTML") = ReceiptEmailHTML & "<br><br>For " & prod.ProductCode & "(Code in HTML)"
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=230,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=110,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Society",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=160,
                    NewUserRateFlag:=False,
                    SellOnWebFlag:=False
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Society",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=80,
                    NewUserRateFlag:=False,
                    SellOnWebFlag:=False
                    )
        '*******************************
        '*******************************
        prod = Me.AddProduct(ProductCode:="T-Vid7Dy",
              CompanyId:=2,
              AssociatedProductCode:="",
              RecurringSubscriptionFlag:=True,
                RecurringSubscriptionUnitType:="Hours",
                RecurringSubscriptionUnits:=(7 * 24),
                SellOnWebFlag:=True)
        prod.ProductRow("ReceiptEmailHTML") = ReceiptEmailHTML & "<br><br>For " & prod.ProductCode & "(Code in HTML)"
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=20,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=10,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )

        '*******************************
        prod = Me.AddProduct(ProductCode:="T-PEPCur",
                  CompanyId:=2,
                  AssociatedProductCode:="",
                  RecurringSubscriptionFlag:=True,
                    RecurringSubscriptionUnitType:="Months",
                    RecurringSubscriptionUnits:=1000,
                    SellOnWebFlag:=False)
        prod.ProductRow("ReceiptEmailHTML") = ReceiptEmailHTML & "<br><br>For " & prod.ProductCode & "(Code in HTML)"
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=0,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )

        '*******************************
        '*******************************
        prod = Me.AddProduct(ProductCode:="T-IJPOpn",
                  CompanyId:=2,
                  AssociatedProductCode:="",
                  RecurringSubscriptionFlag:=True,
                    RecurringSubscriptionUnitType:="Months",
                    RecurringSubscriptionUnits:=62,
                    SellOnWebFlag:=True)
        prod.ProductRow("ReceiptEmailHTML") = ReceiptEmailHTML & "<br><br>For " & prod.ProductCode & "(Code in HTML)"
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=0,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=0,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        '******************************
        '***Paper Journal year-2****************************
        prod = Me.AddProduct(ProductCode:="TPV" & IJPYear1ReleaseDate.ToString("yy"),
                  CompanyId:=1,
                 AssociatedProductCode:="",
                    ShippedProductFlag:=True,
                    ReleaseDate:=IJPYear1ReleaseDate)
        prod.ProductRow("ReceiptEmailHTML") = ReceiptEmailHTML & "<br><br>For TPV Print (in HTML)"
        prod.ProductRow("SuppressConfirmationEmail") = 1
        db.ExecuteSQL("UPDATE Product SET ProductCode='" & prod.ProductCode & "P1'
,ProductName ='" & prod.ProductCode & " Part:1'
,ReleaseDate ='" & IJPYear1ReleaseDate.AddMonths(1).ToString("dd-MMM-yy") & "'
WHERE ProductCode='" & prod.ProductCode & "C1'")
        Me.AddAdditionalChildProduct(prod, 2)
        Me.AddAdditionalChildProduct(prod, 3)
        Me.AddAdditionalChildProduct(prod, 4)
        Me.AddAdditionalChildProduct(prod, 5)
        Me.AddAdditionalChildProduct(prod, 6)
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=0,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=0,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        '*******************************
        '***Electronic Journal year-2****************************
        prod = Me.AddProduct(ProductCode:="TJV" & IJPYear1ReleaseDate.ToString("yy"),
                  CompanyId:=1,
                  RecurringSubscriptionFlag:=True,
                    RecurringSubscriptionUnitType:="Months",
                    RecurringSubscriptionUnits:=12,
                    SellOnWebFlag:=True,
                    AssociatedProductCode:="TPV" & IJPYear1ReleaseDate.ToString("yy"),
                    ShippedProductFlag:=True,
                    FixedSubscriptionEndDate:=IJPYear1ReleaseDate.AddYears(1).AddSeconds(-1),
                    ReleaseDate:=IJPYear1ReleaseDate)
        prod.ProductRow("ReceiptEmailHTML") = ReceiptEmailHTML & "<br><br>For TJV Electronic (in HTML)"
        prod.Save()
        prod.ProductRow("ReleaseDate") = IJPYear1ReleaseDate
        prod.Save()

        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=270,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=135,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )


        '***Parer Journal year-1****************************
        prod = Me.AddProduct(ProductCode:="TPV" & IJPYear2ReleaseDate.ToString("yy"),
                  CompanyId:=1,
                 AssociatedProductCode:="",
                    ShippedProductFlag:=True,
                    ReleaseDate:=IJPYear2ReleaseDate)
        prod.ProductRow("ReceiptEmailHTML") = ReceiptEmailHTML & "<br><br>For TPV Print (in HTML)"
        prod.ProductRow("SuppressConfirmationEmail") = 0
        db.ExecuteSQL("UPDATE Product SET ProductCode='" & prod.ProductCode & "P1'
,ProductName ='" & prod.ProductCode & " Part:1'
,ReleaseDate ='" & IJPYear2ReleaseDate.AddMonths(1).ToString("dd-MMM-yy") & "'
WHERE ProductCode='" & prod.ProductCode & "C1'")
        Me.AddAdditionalChildProduct(prod, 2)
        Me.AddAdditionalChildProduct(prod, 3)
        Me.AddAdditionalChildProduct(prod, 4)
        Me.AddAdditionalChildProduct(prod, 5)
        Me.AddAdditionalChildProduct(prod, 6)
        prod.Save()

        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=0,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=0,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Society",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=15,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Society",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=15,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        'Qualifying rate for subs buying paper after main journal, ProductQualifyingProduct added after JV102 created
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="rate D",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=30,
                    NewUserRateFlag:=False,
                    SellOnWebFlag:=True
                    )
        Dim PV102QualRateId As Integer = db.DLookup("MAX(ProductRateId)", "ProductRate", "ProductCode='" & prod.ProductCode & "'")
        '*******************************
        '***Electronic Journal year-1****************************
        prod = Me.AddProduct(ProductCode:="TJV" & IJPYear2ReleaseDate.ToString("yy"),
                  CompanyId:=1,
                  RecurringSubscriptionFlag:=True,
                    RecurringSubscriptionUnitType:="Months",
                    RecurringSubscriptionUnits:=12,
                    SellOnWebFlag:=True,
                    AssociatedProductCode:="TPV" & IJPYear2ReleaseDate.ToString("yy"),
                    ShippedProductFlag:=True,
                    FixedSubscriptionEndDate:=IJPYear2ReleaseDate.AddYears(1).AddSeconds(-1),
                    ReleaseDate:=IJPYear2ReleaseDate)
        prod.ProductRow("ReceiptEmailHTML") = ReceiptEmailHTML & "<br><br>For TJV Electronic (in HTML)"
        '   prod.ProductRow("ReleaseDate") = IIf(Now > CDate("01-jan-2020"), CDate("01-jan-2021"), Now.Date.AddDays(-1))
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=270,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=148,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Society",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=150,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Society",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=75,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=243,
                    NewUserRateFlag:=False,
                    SellOnWebFlag:=True
                    )
        prod.AddProductQualifyingProduct(QualifyingProductCode:="TJV" & IJPYear1ReleaseDate.ToString("yy"),
                                          SubscriberCategory:="Ordinary",
                                           ProductRateId:=db.DLookup("MAX(ProductRateId)", "ProductRate", "ProductCode='" & prod.ProductCode & "'"),
                                            MustBuyFlag:=False,'*** If true will be added to TJV order!!
                                             CheckAgainstOrderType:="All",
                                              TerminatedSubscriptionsGracePeriodMonths:=12
                                        )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=133,
                    NewUserRateFlag:=False,
                    SellOnWebFlag:=True
                    )
        prod.AddProductQualifyingProduct(QualifyingProductCode:="TJV" & IJPYear1ReleaseDate.ToString("yy"),
                                          SubscriberCategory:="Student",
                                           ProductRateId:=db.DLookup("MAX(ProductRateId)", "ProductRate", "ProductCode='" & prod.ProductCode & "'"),
                                            MustBuyFlag:=False,
                                             CheckAgainstOrderType:="All",
                                              TerminatedSubscriptionsGracePeriodMonths:=12
                                        )
        '*******************************
        prod = New BusinessLogic.Product("TPV" & IJPYear2ReleaseDate.ToString("yy"), db, UsrSessGeneral)
        'Add ProductQualifyingProduct for PV102 $30 after initial purchase
        prod.AddProductQualifyingProduct(QualifyingProductCode:="TJV" & IJPYear2ReleaseDate.ToString("yy"),
                                  SubscriberCategory:="Ordinary",
                                   ProductRateId:=PV102QualRateId,
                                    MustBuyFlag:=False,'*** If true will be added to TJV order!!
                                     CheckAgainstOrderType:="All",
                                      TerminatedSubscriptionsGracePeriodMonths:=12
                                )
    End Sub
    Sub CreateTestContent()

        Dim cs As New ContentSet(db, UsrSessGeneral)
        Me.DeleteContentsets()

        db.ExecuteSQL("
declare @maxId int = 1000
DBCC CHECKIDENT ('Contentset', RESEED, @maxId)
DBCC CHECKIDENT ('ContentSetAccessClassification', RESEED, @maxId)
DBCC CHECKIDENT ('ContentSetSource', RESEED, @maxId)
DBCC CHECKIDENT ('ContentSetSourceItem', RESEED, @maxId)
DBCC CHECKIDENT ('ProductContentSet', RESEED, @maxId)
")

        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="T-All NonEmbargoed (Archive)")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.ContentSetRow("GivesAccessToAllArchiveContent") = 1
        cs.AddContentSetAccessClassification("archive")
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = True
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Book)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Book)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Video)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Video)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.Save()
        Me.AddProductContentSet({"T-PEPweb"}, cs.ContentSetId)
        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="T-Video")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.AddContentSetAccessClassification("archive")
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Video)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Video)
            .Item("IncludeAllSourceItems") = True
        End With
        cs.Save()
        Me.AddProductContentSet({"T-Vid7Dy"}, cs.ContentSetId)
        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="T-IJP Year 0 & 1")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.AddContentSetAccessClassification("archive")
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = False
            .Item("ExcludeEmbargoedYears") = False
            .Item("EmbargoedYearsOnly") = True
            .Item("OverrideEmbargoYears") = 2
        End With
        cs.Save()
        cs = New ContentSet(cs.ContentSetId, db, UsrSessGeneral)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            Dim r As DataRow = cs.ContentSetSourceItem.NewRow
            r("ContentSetSourceItemId") = -1
            r("ContentSetSourceId") = .Item("ContentSetSourceId")
            r("ContentCode") = "IJP"
            cs.ContentSetSourceItem.Rows.Add(r)
        End With
        cs.Save()
        Me.AddProductContentSet({"TJV" & IJPYear1ReleaseDate.ToString("yy")}, cs.ContentSetId)
        Me.AddProductContentSet({"TJV" & IJPYear2ReleaseDate.ToString("yy")}, cs.ContentSetId)
        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="T-IJPOpn")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.AddContentSetAccessClassification("special")
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = False
            .Item("ExcludeEmbargoedYears") = False
            .Item("EmbargoedYearsOnly") = False
        End With
        cs.Save()
        cs = New ContentSet(cs.ContentSetId, db, UsrSessGeneral)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            Dim r As DataRow = cs.ContentSetSourceItem.NewRow
            r("ContentSetSourceItemId") = -1
            r("ContentSetSourceId") = .Item("ContentSetSourceId")
            r("ContentCode") = "IJPOPEN"
            cs.ContentSetSourceItem.Rows.Add(r)
        End With
        cs.Save()
        Me.AddProductContentSet({"T-IJPOpn"}, cs.ContentSetId)
        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="T-All Embargoed (Current)")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.AddContentSetAccessClassification("archive")
        cs.ContentSetRow("GivesAccessToAllCurrentContent") = 1
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = True
            .Item("EmbargoedYearsOnly") = True
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Book)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Book)
            .Item("IncludeAllSourceItems") = True
            .Item("EmbargoedYearsOnly") = False
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Video)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Video)
            .Item("IncludeAllSourceItems") = True
            .Item("EmbargoedYearsOnly") = False
        End With
        cs.Save()
        Me.AddProductContentSet({"T-PEPCur"}, cs.ContentSetId)
        '*******************************
        db.ExecuteSQL("
declare @maxId int = 1000
DECLARE @Newd  INT
SET @Newd = (SELECT MAX(ContentsetID) FROM Contentset WHERE ContentsetID< @maxId);DBCC CHECKIDENT ('Contentset', RESEED,@Newd)
SET @Newd = (SELECT MAX(ContentSetAccessClassificationID) FROM ContentSetAccessClassification WHERE ContentSetAccessClassificationId< @maxId );DBCC CHECKIDENT ('ContentSetAccessClassification', RESEED, @Newd)
SET @Newd = (SELECT MAX(ContentSetSourceID) FROM ContentSetSource WHERE ContentSetSourceId< @maxId );DBCC CHECKIDENT ('ContentSetSource', RESEED, @Newd)
SET @Newd = ISNULL((SELECT MAX(ContentSetSourceItemId) FROM ContentSetSourceItem WHERE ContentSetSourceItemId< @maxId),1);DBCC CHECKIDENT ('ContentSetSourceItem', RESEED, @Newd)
SET @Newd = ISNULL((SELECT MAX(ProductContentSetId) FROM ProductContentSet WHERE ProductContentSetId< @maxId),1);DBCC CHECKIDENT ('ProductContentSet', RESEED, @Newd)

")
        'Update JPT Journal so test still works
        db.ExecuteSQL("
UPDATE ContentJournals 
SET PEPRelease = 2022
,accessClassification = 'future'
where PEPCode = 'JPT' 
")
    End Sub

#End Region


#Region "Actions"


    Sub AddProductContentSet(products As String(), ContentSetId As Integer, Optional checkAddedTestProduct As Boolean = True)
        For Each prd As String In products
            If checkAddedTestProduct Then
                If Not testProductsAdded.Contains(prd) Then Throw New Exception("AddProductContentSet Test ProductCode:" & prd & " hasn't been added")
            End If
            db.ExecuteSQL("INSERT INTO ProductContentSet (ProductCode,ContentSetId) SELECT '" & prd & "' ," & ContentSetId)
        Next

    End Sub
    Function AddProduct(ProductCode As String,
                   CompanyId As Integer,
                   Optional AssociatedProductCode As String = "",
                   Optional RecurringSubscriptionFlag As Boolean = False,
                   Optional RecurringSubscriptionUnitType As String = "",
                   Optional RecurringSubscriptionUnits As String = "",
                   Optional SellOnWebFlag As Boolean = True,
                   Optional FixedSubscriptionEndDate As String = Nothing,
                   Optional ShippedProductFlag As Boolean = False,
                        Optional ReleaseDate As Date = Nothing) As Product
        Try
            If ProductCode.Length > 8 Then
                Throw New Exception("PrtoductCode: " & ProductCode & " must be no more than 8 characeters (2 added for child)")
            End If
            If ReleaseDate = Nothing Then ReleaseDate = CDate("01-" & Now.ToString("MMM-yyyy"))
            testProductsAdded.Add(ProductCode)
            Dim prod As New Product(db, Me.UsrSessGeneral)
            prod.AddNewProduct(ProductCode:=ProductCode,
                          ProductName:=ProductCode & " Testing",
                          ProductStatus:="Current",
                          CompanyID:=CompanyId,
                          Notes:="",
                          ShippedProductFlag:=ShippedProductFlag,
                          TermsAndConditionsFileName:="",
                          ProductGroupingName:=ProductCode,
                          ProductShortName:=ProductCode,
                          ReleaseDate:=ReleaseDate,
                          AssociatedProductCode:=AssociatedProductCode,
                          RecurringSubscriptionFlag:=RecurringSubscriptionFlag,
                          RecurringSubscriptionUnitType:=RecurringSubscriptionUnitType,
                          RecurringSubscriptionUnits:=RecurringSubscriptionUnits,
                          SellOnWebFlag:=SellOnWebFlag,
                          OnePerSubscriberFlag:=True,
                          CheckAgainstOrderType:="All",
                          DisplayProductName:=ProductCode & " Testing",
                          FixedSubscriptionEndDate:=FixedSubscriptionEndDate
                            )

            Return prod
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Sub AddAdditionalChildProduct(prod As Product, ChildNo As Integer)
        Dim row As DataRow = Nothing
        row = prod.Product.NewRow
        row("ProductCode") = prod.ProductCode & "P" & ChildNo
        row("ProductName") = prod.ProductCode & " Part:" & ChildNo
        row("ProductStatus") = prod.ProductRow("ProductStatus")
        row("CompanyID") = prod.ProductRow("CompanyID")
        row("IsParent") = False
        row("ProductGroupingName") = System.DBNull.Value
        row("ProductShortName") = prod.ProductRow("ProductShortName") & " P:" & ChildNo
        row("IsForReporting") = False
        'row("ReportProportion") = 0
        row("ProductReportName") = prod.ProductCode
        row("ReleaseDate") = CDate(prod.ProductRow("ReleaseDate")).AddMonths(1 + ((ChildNo - 1) * 2))
        row("ParentProductCode") = prod.ProductCode
        row("CreatedDateTime") = Now()
        row("CreatedByUserId") = Me.UsrSessGeneral.UserName20
        row("DisplayProductName") = prod.ProductRow("DisplayProductName")
        row("FixedSubscriptionEndDate") = System.DBNull.Value
        prod.Product.Rows.Add(row)
    End Sub

    Sub AddOrder(Subscbr As Subscriber, UserSess As UserSession, products() As String, CandidateStudent As Boolean, Optional FailIfNotValidWebProduct As Boolean = True)
        Try
            For Each prd As String In products
                If Not testProductsAdded.Contains(prd) Then Throw New Exception("Test ProductCode:" & prd & " hasn'True been added")
            Next
            Dim so As New SalesOrder(db, UserSess)
            Dim companyID As Integer = db.DLookup("CompanyId", "Product", "ProductCode='" & products(0) & "'")
            If New DataView(Subscbr.CompanyAccount, "CompanyId=" & companyID, "", DataViewRowState.CurrentRows).Count = 0 Then
                Dim vw As New DataView(Subscbr.SubscriberAddress, "AddressType='Postal'", "", DataViewRowState.CurrentRows)
                Subscbr.AddCompanyAccount(CompanyId:=companyID, AccountType:="Individual", DiscountRateId:=1, RateType:="Full", BillingAddressId:=vw(0)("SubscriberAddressId"))
            End If
            Subscbr.AddSubscriberAffiliate(ParentSubscriberId:=db.DLookup("GroupParentSubscriberId", "Company", "CompanyId=" & companyID), AffiliateReferenceId:="", SubscriberCategory:=IIf(CandidateStudent, "Student", "Ordinary"))
            Dim cmd As New SqlCommand("sp235WebProducts", db.DBConnection, db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            'cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CompanyId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
            '                                                              , companyID))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , Subscbr.SubscriberId))
            Dim webProds As DataTable = db.GetDataTableFromSQL(cmd)

            Dim tProd As New DataTable
            For Each col As DataColumn In webProds.Columns
                tProd.Columns.Add(New DataColumn(col.ColumnName))
            Next
            For Each r As DataRow In webProds.Rows
                If products.Contains(r("ProductCode")) Then
                    Dim nr As DataRow = tProd.NewRow
                    For Each col As DataColumn In webProds.Columns
                        nr(col.ColumnName) = r(col.ColumnName)
                    Next
                    tProd.Rows.Add(nr)
                End If
            Next
            If tProd.Rows.Count = 0 Then
                If FailIfNotValidWebProduct Then Throw New Exception("AddOrder failed for Sub:" & Subscbr.SubscriberName & ". Ordered prods not returned by sp235WebProducts, FirstProd:" & products(0))
                so.Add(ProductCode:=products(0),
                         CurrencyCode:="USD",
                         OrderType:="Individual",
                         SalesOrderStatus:="Partial",
                         SubscriberId:=Subscbr.SubscriberId,
                         SubscriptionStartDateForAdd:=Now())
                so = New SalesOrder(so.OrderNumber, db, UserSess)
                For i As Integer = 0 To products.Length - 1
                    Dim ProductRateId As Integer = db.DLookup("MIN(productRateId)", "ProductRate", "ProductCode='" & products(i) & "'")
                    so.AddNewSalesOrderLine(Product:=New BusinessLogic.Product(products(i), db, UserSess),
                                          SubscriberId:=Subscbr.SubscriberId,
                                           ProductRateId:=ProductRateId,
                                           RecurringStartDate:=Now().AddDays(-10)) 'if this is the same as SubscriptionStartDateForAdd then the end date doesn't get updated

                Next
                so.Save()
                Dim cb As New Cashbook(db, UserSess)
                cb.InternalAdd(OrderNumber:=so.OrderNumber,
                      CompanyId:=companyID,
                     EntryType:="payment",
                     PaymentType:="Cash",
                     SubscriberId:=Subscbr.SubscriberId)
                cb = New BusinessLogic.Cashbook(cb.CashbookId, db, UserSess)
                cb.CashbookRow("CashbookStatus") = "Confirmed"
                cb.Save()

            Else
                'web order
                so.Add(tProd)
                so.AddSalesOrderLines(tProd)
                so = New SalesOrder(so.OrderNumber, db, UserSess)
                '  so.Save()
                Dim cb As New Cashbook(db, UserSess)
                cb.RemoteAdd(OrderNumber:=so.OrderNumber,
                            SalesOrderRow:=so.SalesOrderRow,
                            PaymentCardType:="MasterCard",
                            PaymentCardNumber:="5555555555554444",
                            PaymentCardName:=Subscbr.SubscriberName,
                                PaymentCardExpiryDate:="12-25",
                                PaymentCardCVNumber:="123"
                                )
                If 1 = 2 And Not db.IsOnLiveServer And Not db.DBConnection.Database.ToLower.Contains("pads_try") Then
                    'Hard code credit card number as cashbook save corrupt them for security.
                    cb.AuthenticateCreditCard("5555555555554444", "123")
                Else
                    cb.CashbookRow("CashbookStatus") = "Confirmed"
                End If
                cb.Save()

                Select Case cb.CashbookRow("CashbookStatus")
                    Case "Confirmed"
                    Case Else
                        cb = New Cashbook(cb.CashbookId, db, UserSess)
                        cb.CashbookRow("CashbookStatus") = "Confirmed"
                        AddProgressMessage("Cashbook for:" & Subscbr.SubscriberName & " confirmed manually as authorisation failed:" & cb.CashbookRow("PaymentCardRejectDescription"))
                        cb.Save()
                End Select
            End If

            so = New SalesOrder(so.OrderNumber, db, UserSess)
            so.SalesOrderRow("SalesOrderStatus") = "Confirmed"
            so.SalesOrderRow("OrderDate") = System.DateTime.Now.Date
            so.SalesOrderRow("AmountCarriage") = 0
            so.SalesOrderRow("PercentVAT") = 0
            so.Save()
            so.SendEmailReceipt()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Sub AddOrderBlock(Subscbr As Subscriber, UserSess As UserSession, products() As String, ImportFile As IO.FileInfo)
        Try
            For Each prd As String In products
                If Not testProductsAdded.Contains(prd) Then Throw New Exception("Test ProductCode:" & prd & " hasn't been added")
            Next
            Dim so As New SalesOrder(db, UserSess)
            Dim companyID As Integer = db.DLookup("CompanyId", "Product", "ProductCode='" & products(0) & "'")
            If New DataView(Subscbr.CompanyAccount, "CompanyId=" & companyID, "", DataViewRowState.CurrentRows).Count = 0 Then
                Dim vw As New DataView(Subscbr.SubscriberAddress, "AddressType='Postal'", "", DataViewRowState.CurrentRows)
                Subscbr.AddCompanyAccount(CompanyId:=companyID, AccountType:="Society", DiscountRateId:=1, RateType:="Full", BillingAddressId:=vw(0)("SubscriberAddressId"))
            End If
            Subscbr.AddSubscriberAffiliate(ParentSubscriberId:=db.DLookup("GroupParentSubscriberId", "Company", "CompanyId=" & companyID), AffiliateReferenceId:="", SubscriberCategory:="Ordinary")

            'If Not ImportFile.Exists Then
            '    Throw New Exception("File:" & ImportFile.FullName & "does not exist")
            'End If

            'Dim ib As New BusinessLogic.SubscriberImportBatch(db)
            'ib.AddNew(Subscbr.SubscriberId, companyID, Subscbr.SubscriberName & " Import01")
            'ib.AddFile(SubscriberImportBatch.SubscriberImportBatchFileTypes.BeforeImport, IO.File.ReadAllBytes(ImportFile.FullName), ImportFile.Name)

            Dim primprod As New Product(products(0), db, UserSess)
            so = New SalesOrder(db, UserSess)
            so.Add(ProductCode:=primprod.ProductCode,
                         CurrencyCode:="USD",
                         OrderType:="Block",
                         SalesOrderStatus:="Partial",
                         SubscriberId:=Subscbr.SubscriberId,
                         SubscriptionStartDateForAdd:=Now())
            so = New SalesOrder(so.OrderNumber, db, UserSess)
            Dim rateID As Integer = db.DLookup("MAX(ProductRateId)", "ProductRate", "productCode='" & primprod.ProductCode & "' AND CurrencyCode='USD' AND RateType='Full' AND AccountType='Society'")
            If rateID = Nothing Then Throw New Exception("RateId not found")
            so.AddNewSalesOrderLine(primprod, Subscbr.SubscriberId, rateID, Now())
            so.SalesOrderRow("SalesOrderStatus") = "Confirmed"
            so.SalesOrderRow("OrderDate") = System.DateTime.Now.Date
            so.SalesOrderRow("AmountCarriage") = 0
            so.SalesOrderRow("PercentVAT") = 0.2
            so.Save()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Dim TestUserPassword As String = ""
    Public Function AddSubscriberAndUser(LastUserName As String, FirstName As String, EmailAddress As String, Optional CandidateStudent As Boolean = False) As Subscriber
        Try

            Me.DeleteUserAndSubscriber(LastUserName, 0)
            Me.DeleteUserAndSubscriber(LastUserName.Replace("Test", "Xxxx"), 0)
            Dim sb As New Subscriber(db, Me.UsrSessGeneral)

            sb.Add(EmailAddress:=EmailAddress,
                        Title:="Mr.",
                        FirstName:=FirstName,
                        LastName:=LastUserName,
                        BillingAddress:=LastUserName & " House, Somewhere",
                        Town:=FirstName,
                        County:="Hants",
                        CountyUS:="",
                        PostCode:="SO211DF",
                        CountryId:="58",
                        CandidateStudent:=CandidateStudent,
                        PrimaryCompanyId:=2,
                        IsReceiveMail:=True,
                        IsBillingAddressAndTitleRequired:=True
                        )
            sb.RemoteUser.UserName = LastUserName
            sb.RemoteUser.UserStatus = RemoteUser.UserStates.Active
            sb.RemoteUser.SetPassword(TestUserPassword)
            sb.RemoteUser.Save()
            sb.SubscriberStatus = Subscriber.SubscriberStates.Current
            sb.Save()
            Return sb

        Catch ex As Exception
            Throw ex
        End Try
        Return Nothing
    End Function

    Function GetSubscriberSession(Subscbr As Subscriber) As UserSession
        Dim pepS As New PEPSecurity(db, "ZedraTestHarness")
        Dim pepsAuthReq As New BusinessLogic.PEPSecurity.AuthenticationRequest
        pepsAuthReq.UserName = Subscbr.RemoteUser.UserName
        pepsAuthReq.Password = Me.TestUserPassword
        Dim authRes As New PEPSecurity.AuthenticationResponse
        authRes = pepS.AuthenticateUser(pepsAuthReq)
        If authRes.ReasonStr.Contains("does not belong to table") Then Throw New Exception("PaSDTesting.GetSubscriberSession failed:" & authRes.ReasonStr)
        Dim us As New UserSession(db)
        us.Restore(authRes.SessionId)
        Return us
    End Function
#End Region
#Region "Delete Data"


    Sub DeleteUserAndSubscriber(UserName As String, SubscriberId As Integer)
        'If SubscriberId > 0 Then
        '    Dim scbr As New Subscriber(SubscriberId, db, UsrSessGeneral)
        '    scbr.DeleteOrObfuscateSubscriber(RunMode:="Delete")
        'End If

        Dim sql As String = "
declare @UserName varchar(50)='" & UserName & "' 
select SubscriberId = rur.rightstoid , ru.UserId INTO #subs FROM RemoteUserRights rur inner join RemoteUser ru on ru.UserId = rur.UserId inner join subscriber s on s.SubscriberId = rur.RightsToId and s.CreatedDateTime> DATEADD(MONTH,-12,GETDATE()) where ru.UserName=@UserName or s.UpdateToSubscriberId  >= 500000
INSERT INTO #subs SELECT " & SubscriberId & ",UserId=0
INSERT INTO #subs SELECT 0,UserId FROM RemoteUser WHERE UserName =  @UserName
INSERT INTO #subs select s.UpdateToSubscriberId,ISNULL(rur.UserId ,0)   from Subscriber s LEFT JOIN RemoteUserRights rur ON rur.RightsToId = s.SubscriberId where s.SubscriberId in (select subscriberid from #subs ) and s.UpdateToSubscriberId IS NOT NULL

select ordernumber into #ords from SalesOrderLine where SubscriberId in (select SubscriberId from #subs)
INSERT INTO #ords select orderNumber from SalesOrder where SubscriberId in (select SubscriberId from #subs)
delete BankDeposit from BankDeposit b where b.BankDepositId in (select SubscriberId  from cashbook where SubscriberId in (select SubscriberId from #subs))
delete cashbook from  cashbook where SubscriberId in (select SubscriberId from #subs)

delete from SalesOrderLinePart where OrderNumber in (select ordernumber from #ords )
delete from SalesOrderLine where OrderNumber in (select ordernumber from #ords )
delete from SalesOrder where OrderNumber in (select ordernumber from #ords )

delete from SubscriberAffiliate where childSubscriberId in (select SubscriberId from #subs)
delete from SubscriberAffiliate where ParentSubscriberId in (select SubscriberId from #subs)
delete from CompanyAccount  where SubscriberId in (select SubscriberId from #subs)
delete from SubscriberAddress   where SubscriberId in (select SubscriberId from #subs)
delete from Subscriber   where SubscriberId in (select SubscriberId from #subs)
delete from EmailDistribution where EmailDistributionId IN (SELECT EmailDistributionId FROM EmailDistributionLog WHERE SubscriberId in (select SubscriberId from #subs))
delete from EmailDistributionLog where SubscriberId in (select SubscriberId from #subs)

delete from RemoteUserRights   where UserId in (select userid from #subs)
delete from RemoteUserAutoLogon   where UserId in (select userid from #subs)
delete from RemoteUser   where UserId in (select userid from #subs)
drop table #Subs
drop table #ords
--Special for Merge audit log which is displayed on sub maint page
delete from AuditLog where Description like '%Merged into 500007%'
delete from AuditLog where Description like '%500007 Merged into%'
"
        db.ExecuteSQL(sql)

    End Sub
    Sub DeleteContentsets()

        Dim sql As String = "
select ContentSetId  INTO #conts FROM ContentSet where ContentSetId >=1000
delete ContentSetSourceItem  where ContentSetSourceId in (select ContentSetSourceId from ContentSetSource where ContentSetId in (select ContentSetId from #conts ))
delete ProductContentSet   where ContentSetId in (select ContentSetId from #conts )
delete ContentSetSource  where ContentSetId in (select ContentSetId from #conts )
delete ContentSetAccessClassification  where ContentSetId in (select ContentSetId from #conts )
delete ContentSet  where ContentSetId in (select ContentSetId from #conts )

drop table #conts
DECLARE @ID INT = 0
SET @Id = ISNULL((SELECT MAX(ContentSetId) FROM ContentSet ),0) +1
DBCC CHECKIDENT ('Contentset', RESEED, @Id)
SET @Id = ISNULL((SELECT MAX(ContentSetSourceId) FROM ContentSetSource ),0) +1
DBCC CHECKIDENT ('ContentSetSource', RESEED, @id)
SET @Id = ISNULL((SELECT MAX(ContentSetSourceItemId) FROM ContentSetSourceItem ),0) +1
DBCC CHECKIDENT ('ContentSetSourceItem', RESEED, @id)
SET @Id = ISNULL((SELECT MAX(ProductContentSetId) FROM ProductContentSet ),0) +1
DBCC CHECKIDENT ('ProductContentSet', RESEED, @id)
"
        db.ExecuteSQL(sql)

    End Sub
    Sub DeleteProducts()

        Dim sql As String = "
select ProductCode   INTO #prods FROM product  where ( ProductCode like 'T-%' OR ProductCode like 'TPV%' OR ProductCode like 'TJV%') AND CreatedByUserId='Not Logged On'
delete ProductAffiliateRate  where ProductCode in (select productcode from #prods )
delete ProductContentSet  where ProductCode in (select productcode from #prods )
delete ProductQualifyingProduct   where ProductCode in (select productcode from #prods )
delete ProductRate   where ProductCode in (select productcode from #prods )
delete Product   where ProductCode in (select productcode from #prods )

drop table #prods 
"
        db.ExecuteSQL(sql)

    End Sub

#End Region

#Region "PopulateBase Content"
    Public Sub DeleteBaseContentSets()

        Dim sql As String = "
select ContentSetId  INTO #conts FROM ContentSet where ContentSetId <10
delete ContentSetSourceItem  where ContentSetSourceId in (select ContentSetSourceId from ContentSetSource where ContentSetId in (select ContentSetId from #conts ))
delete ProductContentSet   where ContentSetId in (select ContentSetId from #conts )
delete ContentSetAccessClassification  where ContentSetId in (select ContentSetId from #conts )
delete ContentSetSource  where ContentSetId in (select ContentSetId from #conts )
delete ContentSet  where ContentSetId in (select ContentSetId from #conts )
drop table #conts

"
        db.ExecuteSQL(sql)
        db.ExecuteSQL(GetBaseResetIdSQL)
        AddProgressMessage("Base content deleted")

    End Sub
    Function GetBaseResetIdSQL() As String
        Return "
DECLARE @ID INT = 0
SET @Id = ISNULL((SELECT MAX(ContentSetId) FROM ContentSet WHERE ContentSetId >1000  ),0) +1
IF @Id > 10  SET @Id=10 --Always set to at least 10
DBCC CHECKIDENT ('Contentset', RESEED, 10)
SET @Id = ISNULL((SELECT MAX(ContentSetSourceId) FROM ContentSetSource ),0) +1
DBCC CHECKIDENT ('ContentSetSource', RESEED, @id)
SET @Id = ISNULL((SELECT MAX(ContentSetSourceItemId) FROM ContentSetSourceItem ),0) +1
DBCC CHECKIDENT ('ContentSetSourceItem', RESEED, @id)
SET @Id = ISNULL((SELECT MAX(ProductContentSetId) FROM ProductContentSet ),0) +1
DBCC CHECKIDENT ('ProductContentSet', RESEED, @id)
"

    End Function
    Public Sub CreateBaseContentSets()
        Dim cs As New ContentSet(db, UsrSessGeneral)

        db.ExecuteSQL("
DBCC CHECKIDENT ('Contentset', RESEED, 0)
DBCC CHECKIDENT ('ContentSetSource', RESEED, 0)
DBCC CHECKIDENT ('ContentSetSourceItem', RESEED, 0)
DBCC CHECKIDENT ('ProductContentSet', RESEED, 0)
")

        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="All Content for Admin Users")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.ContentSetRow("GivesAccessToAllArchiveContent") = 1
        cs.ContentSetRow("GivesAccessToAllCurrentContent") = 1
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Book)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Book)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Video)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Video)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.Save()
        AddProgressMessage(cs.ContentSetName & " added")

        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="All NonEmbargoed (Archive)")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.ContentSetRow("GivesAccessToAllArchiveContent") = 1
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = True
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Book)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Book)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Video)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Video)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.Save()
        Me.AddProductContentSet({"PEPweb", "PEPWEBS", "Pepweb3y", "PEPWEB24"}, cs.ContentSetId, False)
        AddProgressMessage(cs.ContentSetName & " added")
        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="All Videos")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Video)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Video)
            .Item("IncludeAllSourceItems") = True
        End With
        cs.Save()
        Me.AddProductContentSet({"Video24"}, cs.ContentSetId, False)
        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="IJP TJV" & IJPYear1ReleaseDate.ToString("yy"))
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = False
            .Item("ExcludeEmbargoedYears") = False
            .Item("EmbargoedYearsOnly") = True
        End With
        cs.Save()
        cs = New ContentSet(cs.ContentSetId, db, UsrSessGeneral)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            Dim r As DataRow = cs.ContentSetSourceItem.NewRow
            r("ContentSetSourceItemId") = -1
            r("ContentSetSourceId") = .Item("ContentSetSourceId")
            r("ContentCode") = "IJP"
            cs.ContentSetSourceItem.Rows.Add(r)
        End With
        cs.Save()
        Me.AddProductContentSet({"TJV" & IJPYear1ReleaseDate.ToString("yy")}, cs.ContentSetId, False)
        AddProgressMessage(cs.ContentSetName & " added")
        db.ExecuteSQL(GetBaseResetIdSQL)

    End Sub

#End Region
#Region "SubscriberImport"
    Public Sub DeleteImports()
        db.ExecuteSQL("
Begin Tran

select distinct
o.OrderNumber
,b.SubscriberImportBatchId
,l.SubscriberId
,r.UserId
into #bo
From SubscriberImportBatch b
	left join  SalesOrder o
		inner join SalesOrderLine l 
			left join RemoteUserRights r
			on r.RightsToId = l.SubscriberId
			and r.RightsType = 'Subscriber'
		on l.OrderNumber = o.OrderNumber
	on b.BlockSubscriberId = o.SubscriberId
	and b.OrderNumber=o.OrderNumber
	and o.OrderDate > '01-jan-2000'
	and o.SubscriberId in (SELECT SubscriberId FROm Subscriber WHERE SubscriberName like '%" & ImportGroupSubNamePart & "%')
where b.BlockSubscriberId  in (SELECT SubscriberId FROm Subscriber WHERE SubscriberName like '%" & ImportGroupSubNamePart & "%')
and b.LastUpdatedDateTime > '01-jan-2000'

INSERT INTO #bo 
select distinct
o.OrderNumber
,0
,l.SubscriberId
,r.UserId
From  SalesOrder o
	left join SalesOrderLine l 
		left join RemoteUserRights r
		on r.RightsToId = l.SubscriberId
		and r.RightsType = 'Subscriber'
	on l.OrderNumber = o.OrderNumber
WHERE o.OrderDate > '01-jan-2000'
and o.SubscriberId in (SELECT SubscriberId FROm Subscriber WHERE SubscriberName like '%" & ImportGroupSubNamePart & "%')
INSERT INTO #bo 
select distinct
0
,0
,s.SubscriberId
,r.UserId
From  Subscriber s
	left join RemoteUserRights r
	on r.RightsToId = s.SubscriberId
	and r.RightsType = 'Subscriber'

WHERE s.CreatedDateTime > '01-jan-2000'
AND s.SubscriberId IN ( SELECT SubscriberId FROm Subscriber WHERE SubscriberName like '%TestImport%')  

delete from EmailDistribution where EmailDistributionId IN (SELECT EmailDistributionId FROM EmailDistributionLog WHERE SubscriberId in (select SubscriberId from #bo))
delete from EmailDistribution where EmailDistributionId IN (SELECT EmailDistributionId FROM EmailDistributionLog WHERE OrderNumber in (select OrderNumber from #bo))
delete from EmailDistributionLog where SubscriberId in (select SubscriberId from #bo)
delete from EmailDistributionLog where OrderNumber in (select OrderNumber from #bo)

delete from SubscriberImportBatchLog where SubscriberImportBatchId in (select b.SubscriberImportBatchId from #bo b)
delete from tmpSubscriberImport where SubscriberImportBatchId in (select b.SubscriberImportBatchId from #bo b)
delete from filestore where filestoreid in (select filestoreid=b.AfterImportFileStoreId from SubscriberImportBatch b where SubscriberImportBatchId in  (select b.SubscriberImportBatchId from #bo b)
											UNION select filestoreid=b.BeforeImportFileStoreId from SubscriberImportBatch b where SubscriberImportBatchId in  (select b.SubscriberImportBatchId from #bo b)
											UNION select filestoreid=b.ConfirmationFileStoreId from SubscriberImportBatch b where SubscriberImportBatchId in  (select b.SubscriberImportBatchId from #bo b)
											UNION select filestoreid=b.RenewalFileStoreId from SubscriberImportBatch b where SubscriberImportBatchId in  (select b.SubscriberImportBatchId from #bo b)
											UNION select filestoreid=b.UploadedFileStoreId from SubscriberImportBatch b where SubscriberImportBatchId in  (select b.SubscriberImportBatchId from #bo b)
											)
delete from SubscriberImportBatch where SubscriberImportBatchId in (select b.SubscriberImportBatchId from #bo b)
delete from SalesOrderLinePart where OrderNumber in (select b.OrderNumber from #bo b)
delete from SalesOrderLine where OrderNumber in (select b.OrderNumber from #bo b)
delete from SalesOrder where OrderNumber in (select b.OrderNumber from #bo b)

delete from RemoteUserRights where UserId in (select b.UserId from #bo b)
delete from RemoteUser where UserId in (select b.UserId from #bo b)
delete from SubscriberAffiliate where ChildSubscriberId in (select b.SubscriberId from #bo b)
delete from SubscriberAddress where SubscriberId in (select b.SubscriberId from #bo b)
delete from Subscriber where SubscriberId in (select b.SubscriberId from #bo b)
delete from CompanyAccount where SubscriberId in (select b.SubscriberId from #bo b)

drop table #bo
commit tran

")
        AddProgressMessage("Impot test data deleted")

    End Sub
    Dim ImportSubscbr As Subscriber = Nothing
    Dim ImportBtch As SubscriberImportBatch = Nothing
    Dim ImportMesg As String = ""
    Public Sub RunImportFileTests(UsrSess As UserSession)
        Try


            db.ExecuteSQL("
            UPDATE stblTableNumber SET LastNumber = (SELECT MAX(OrderNumber) FROM SalesOrder ) WHERE TableName = 'SalesOrder'
            UPDATE stblTableNumber SET LastNumber = (SELECT MAX(SubscriberId) FROM Subscriber ) WHERE TableName = 'Subscriber'
            UPDATE stblTableNumber SET LastNumber = (SELECT MAX(UserId) FROM RemoteUser ) WHERE TableName = 'RemoteUser'
")
            _UsrSessGeneral = UsrSess
            DeleteImports()



            ImportFile(500011, "ImportTest10SubscriberRenewalBadCols", "T-PEPweb", "")
            ImportFile(500012,"ImportTest20SubscriberRenewalBadSheets", "T-PEPweb", "")
            ImportFile(500011,"ImportTest30SubscriberRenewalErrors", "T-PEPweb", "")
            ImportFile(500011,"ImportTest40SubscriberRenewalTest11GroupPEP", "T-PEPweb", "'T-Vid7Dy'")

            ImportFile(500011,"ImportTest50SubscriberRenewalTest11GroupIJP", "TJV" & IJPYear2ReleaseDate.ToString("yy"), "")
            ImportFile(500012, "ImportTest55SubscriberRenewalTest12GroupMORE_PEP", "T-PEPweb", "")
            ImportFile(500011, "ImportTest56SubscriberRenewalTest11GroupExisting_PEP", "T-PEPweb", "")
            ImportFile(500011, "ImportTest60ValidationChecks", "T-PEPweb", "'T-Vid7Dy'")

        Catch ex As Exception
            Throw ex
        Finally
            db.ExecuteSQL("
            UPDATE stblTableNumber SET LastNumber = (SELECT MAX(OrderNumber) FROM SalesOrder WHERE OrderNumber < 500000) WHERE TableName = 'SalesOrder'
            UPDATE stblTableNumber SET LastNumber = (SELECT MAX(SubscriberId) FROM Subscriber WHERE SubscriberId < 500000) WHERE TableName = 'Subscriber'
            UPDATE stblTableNumber SET LastNumber = (SELECT MAX(UserId) FROM RemoteUser WHERE UserId < 500000) WHERE TableName = 'RemoteUser'
")
        End Try

    End Sub
    Sub ImportFile(GroupSubscriberId As Integer, TestImportFileName As String, ProductCode As String, AdditionalProductCodes As String)
        Try
            AddProgressMessage("Start:" & TestImportFileName)
            ImportSubscbr = New Subscriber(GroupSubscriberId, db, UsrSessGeneral)
            Dim Prod As New Product(ProductCode, db, UsrSessGeneral)
            Dim ImportFile As IO.FileInfo = Nothing
            Dim repDir As New IO.DirectoryInfo(db.GetParameterValue("ReportsPhysicalDir"))
            ImportFile = New IO.FileInfo(IO.Path.Combine(repDir.FullName.Replace(repDir.Name, "TestData\SubscriberImportFiles"), TestImportFileName & ".xlsx"))
            ImportBtch = New BusinessLogic.SubscriberImportBatch(db, UsrSessGeneral)
            ImportBtch.AddNew(ImportSubscbr.SubscriberId, CInt(Prod.ProductRow("CompanyId")), ImportFile.Name)
            ImportBtch.AddFile(SubscriberImportBatch.SubscriberImportBatchFileTypes.BeforeImport, IO.File.ReadAllBytes(ImportFile.FullName), ImportFile.Name)
            Dim fs As New FileStore(ImportBtch.SubscriberImportBatchRow(SubscriberImportBatch.SubscriberImportBatchFileTypes.BeforeImport.ToString & "FileStoreId"), db)
            ImportBtch.ValidateFile(fs)
            If ImportBtch.ErrorMessages <> "" Then
                Exit Try
            Else
                Dim so As New BusinessLogic.SalesOrder(db, UsrSessGeneral)
                so.Add(ProductCode,
                        ImportSubscbr.SubscriberId,
                        "Block",
                         "Partial",
                        "USD",
                        Now.Date)
                ImportBtch.SubscriberImportBatchRow("OrderNumber") = so.OrderNumber
                ImportBtch.Save()
                ImportBtch.SubscriberImportBatchRow("BeforeImportFileStoreId") = fs.FileStoreId
                ImportBtch.UpdateStatus(SubscriberImportBatch.SubscriberImportBatchStates.Importing, Nothing, Nothing)
                ImportBtch.ImportFiletoDB(AdditionalProductCodes, AdditionalProductCodes)
                Dim msg As String = ""
                Try
                    ImportBtch.Callsp483SubscriberImportStoredProcedure("Check", "", msg)
                Catch ex As Exception
                    Select Case TestImportFileName
                        Case "ImportTest55SubscriberRenewalTest12GroupMORE_PEP"
                            db.ExecuteSQL("UPDATE tmpSubscriberImport set ExistingSubscriptionAction = 'Ignore' WHERE ExistingSubscriptionFound=1 AND ISNULL(ExistingSubscriptionAction,'')='' AND SubscriberImportBatchId = " & ImportBtch.SubscriberImportBatchId)
                            ImportBtch.Callsp483SubscriberImportStoredProcedure("Check", "", msg)
                        Case "ImportTest56SubscriberRenewalTest11GroupExisting_PEP"
                            db.ExecuteSQL("UPDATE tmpSubscriberImport set ExistingSubscriptionAction = CASE WHEN LastName in ('TestImport31','TestImport29') THEN 'Ignore' ELSE 'GroupOnly' END WHERE ExistingSubscriptionFound=1 AND ISNULL(ExistingSubscriptionAction,'')=''  AND SubscriberImportBatchId = " & ImportBtch.SubscriberImportBatchId)
                            ImportBtch.Callsp483SubscriberImportStoredProcedure("Check", "", msg)
                        Case Else
                            Exit Try
                    End Select
                    If TestImportFileName = "ImportTest55SubscriberRenewalTest12GroupMORE_PEP" Then
                    Else
                    End If
                End Try
                If TestImportFileName = "ImportTest60ValidationChecks" Then Exit Try

                db.ExecuteSQL("UPDATE BatchJob SET BatchJobStatus='PendingPaused' WHERE BatchJobStatus='Pending' AND ScheduledStartDateTime < DATEADD(MINUTE,5,GETDATE())")
                ImportBtch.SubmitActionSubscriberImportBatch(AdditionalProductCodes)
                Me.ProcessNextBatchJob()
                so = New SalesOrder(so.OrderNumber, db, UsrSessGeneral)
                so.Save()
                so.SalesOrderRow("SalesOrderStatus") = "Confirmed"
                so.Save()
                ImportBtch = New SubscriberImportBatch(ImportBtch.SubscriberImportBatchId, db, UsrSessGeneral)
                db.ExecuteSQL("Update RemoteUser SET LastLoggedOn=GETDATE() WHERE EmailAddress IN (SELECT TOP 2 EmailAddress FROM tmpSubscriberImport t WHERE t.SubscriberImportBatchId = " & ImportBtch.SubscriberImportBatchId & " ORDER By SubscriberImportId)")
                'Only send emails for some orders depebding on the product 
                Select Case so.SalesOrderRow("PrimaryProductCode")
                    Case "T-PEPweb"
                        so.PopulateAndSubmitBlockConfirmationEmail(so.BulkConfirmationEmailDistribution.EmailDistributionRow("EmailSubject"), so.BulkConfirmationEmailDistribution.EmailDistributionRow("EmailHTML"))
                        Me.ProcessNextBatchJob()
                        so = New SalesOrder(so.OrderNumber, db, UsrSessGeneral)
                        ImportBtch = New SubscriberImportBatch(ImportBtch.SubscriberImportBatchId, db, UsrSessGeneral)
                        If TestImportFileName = "ImportTest55SubscriberRenewalTest12GroupMORE_PEP" Then
                            db.ExecuteSQL("UPDATE EmailDistributionLog set EmailDistributionStatus = 'Failed',ExtraInfo='Marked as failed for test display' FROM EmailDistributionLog l WHERE EmailDistributionLogId IN (SELECT TOP 1 l2.EmailDistributionLogId  FROM EmailDistributionLog l2 WHERE l2.OrderNumber = " & so.OrderNumber & " ORDER BY l2.SubscriberId )")
                            db.ExecuteSQL("UPDATE EmailDistributionLog set EmailDistributionStatus = 'NotSent',EmailSentDate=NULL,ExtraInfo='Marked as NotSent for test display' FROM EmailDistributionLog l WHERE EmailDistributionLogId IN (SELECT TOP 1 l2.EmailDistributionLogId  FROM EmailDistributionLog l2 WHERE l2.OrderNumber = " & so.OrderNumber & " ORDER BY l2.SubscriberId )")
                            db.ExecuteSQL("UPDATE EmailDistribution set EmailDistributionStatus = 'Emailing' FROM EmailDistribution d WHERE d.EmailDistributionId IN (SELECT MAX(d2.EmailDistributionId)  FROM EmailDistribution d2 WHERE d2.OrderNumber = " & so.OrderNumber & ")")

                        End If

                End Select

            End If

        Catch ex As Exception
            AddProgressMessage(TestImportFileName & " Failed:" & ex.Message)
            Throw ex
        End Try
        AddProgressMessage(TestImportFileName & " Complete:")

    End Sub
    Sub ProcessNextBatchJob()
        'need to fix time as servers are different and reset DB and SecondaryConnectionString
        db.ExecuteSQL("UPDATE BatchJob set ScheduledStartDateTime = DATEADD(MINUTE,-2,ScheduledStartDateTime) WHERE BatchJobID = (SELECT MAX(BatchJobID) FROM BatchJob )")
        Dim secondaryConnectionStg As String = db.SecondaryConnectionString
        Dim dbForBatchJob As New Database(Me.DBConnectionString)
        Dim BatchJob As New BusinessLogic.BatchJob(dbForBatchJob)
        BatchJob.ProcessNextBatchJob()
        db = New Database(Me.DBConnectionString) 'Connection is closed in ProcessNextBatchJob so re-open
        db.SecondaryConnectionString = secondaryConnectionStg

    End Sub
#End Region
    Public ReadOnly Property TestResultsDir As IO.DirectoryInfo
        Get
            Return New IO.DirectoryInfo(db.GetParameterValue("SQLFileDirectory").ToString.Replace("BusinessLogic\SQL", "\TestData\Results\"))

        End Get
    End Property

    Function SaveTestResultsAsXML() As String

        Dim sql As String = Nothing
        Dim TestReportName As String = ""

        Try
            If Not TestResultsDir.Exists Then
                TestResultsDir.Create()
            End If
            Dim cmd As New SqlClient.SqlCommand("", Me.db.DBConnection)
            Dim ds As New DataSet
            Dim da As New SqlClient.SqlDataAdapter(sql, Me.db.DBConnection)
            'reset the echoweb db so #temp tables will be deleted
            sql = "
SELECT
	PaDSersion='" & db.PaDSVersion & "'"
            da.SelectCommand.CommandText = sql
            da.Fill(ds, "Versions")
            sql = "
SELECT
BatchLogLineText
from BatchLog l
	inner join BatchLogLine ll
	on ll.BatchLogId = l.BatchLogId 
where l.BatchLogId = (select max(batchlogid) from BatchLog where BatchLogType='ResetTestData')
ORDER BY ll.BatchLogLineId "
            da.SelectCommand.CommandText = sql
            da.Fill(ds, "ResetTestBatchLog")
            sql = "
SELECT
p.ProductCode
,p.ProductName
,p.AssociatedProductCode
,p.RecurringSubscriptionFlag
,p.RecurringSubscriptionUnits
,p.RecurringSubscriptionUnitType
,p.CheckAgainstOrderType
,p.SellOnWebFlag
,p.OnePerSubscriberFlag
,p.ShippedProductFlag
,FixedSubscriptionEndDate = FORMAT(p.FixedSubscriptionEndDate,'dd-xxx-xx HH:mm:ss')
,pr.CurrencyCode
,pr.AccountType
,pr.RateType
,pr.ProductRate
FROM Product p
	LEFT Join ProductRate pr
	ON pr.ProductCode=p.ProductCode
WHERE p.ProductCode like 'T%'
AND p.ProductStatus = 'Current'
AND p.IsParent = 1
ORDER BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
"
            da.SelectCommand.CommandText = sql
            da.Fill(ds, "Products")
            sql = "
SELECT
	OrdererSub = CAST(sp.SubscriberId as VARCHAR) + '-' + sp.SubscriberName
	,o.PrimaryProductCode
	,SubSub = CAST(sC.SubscriberId as VARCHAR) + '-' + sC.SubscriberName
	,l.ProductCode
	,l.ProductRate
	,pr.SubscriberCategory
FROM SalesOrder o
	inner join Subscriber sP
	on sP.SubscriberId = o.SubscriberId
	inner join SalesOrderLine l
		LEFT JOIN ProductRate pr
		ON pr.ProductRateId = l.ProductRateId
		inner join Subscriber sC
		on sC.SubscriberId = l.SubscriberId
	on l.OrderNumber = o.OrderNumber 
where o.OrderNumber>500000
ORDER BY 1,2,3,4,5
"
            da.SelectCommand.CommandText = sql
            da.Fill(ds, "OrdersAndSubs")
            sql = "
SELECT 
ib.SubscriberImportBatchName
,ib.SubscriberImportBatchStatus
,ib.OrderNumber
,ib.WarningMessages
,ib.ErrorMessages
,si.FirstName
,si.LastName
,si.EmailAddress
,si.AffiliateReferenceId
,si.Address1
,si.Address2
,si.Address3
,si.Address4
,si.Town
,si.County
,si.PostCode
,si.CountryName
,si.PrintedCopy
,si.Status
,si.OverwriteWebUserName
,si.WebUserOverwriteActionReviewed
,si.DuplicateFound
,si.DuplicateAction
,si.ExistingSubscriptionFound
,si.ExistingSubscriptionAction
,LineErrors = LEFT(si.ErrorMessage,75)

FROM SubscriberImportBatch ib
	LEFT Join tmpSubscriberImport si
	ON si.SubscriberImportBatchId = ib.SubscriberImportBatchId
WHERE ib.SubscriberImportBatchName like 'Importtest%'
ORDER BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14
"
            If EmailDistributionLogIdAtStart = 0 Then EmailDistributionLogIdAtStart = db.DLookup("min(EmailDistributionLogId)", "EmailDistributionLog", "EmailSentDate>DATEADD(MINUTE,-2,(SELECT MAX(EmailSentDate) FROM EmailDistributionLog))")
            da.SelectCommand.CommandText = sql
            da.Fill(ds, "SubImpotrs")
            sql = "
select
l.EmailDistributionStatus 
,l.EmailSubject 
,l.EmailName
,l.SubscriberName 
,l.EmailAddress
,l.OrderNumber 
from EmailDistributionLog l 
WHERE EmailDistributionLogId >= " & EmailDistributionLogIdAtStart & "
ORDER BY 1,2
"
            da.SelectCommand.CommandText = sql
            da.Fill(ds, "EmailDistributionLog")
            '   WriteWorksheetToTextFile(ECHOReportTestResults, repRankingByFunds.ExcelWorkBook, TestReportName)
            Dim files As New List(Of IO.FileInfo)
            For Each file As IO.FileInfo In Me.ReportOutDirectory.GetFiles("*.xlsx", IO.SearchOption.AllDirectories)
                files.Add(file)
            Next '.OrderBy(Function(f) f.Name)
            Dim SortedList As List(Of IO.FileInfo) = files.OrderBy(Function(o) o.Name).ToList()
            Dim repNo As Integer = 1
            For Each RepFile As IO.FileInfo In SortedList
                Dim nameToUse As String = RepFile.Name
                If nameToUse.Contains("DespatchReport") Then nameToUse = "DespatchReport" & repNo.ToString("00")
                WriteWorksheetToTextFile(IO.File.ReadAllBytes(RepFile.FullName), nameToUse, False)
                repNo += 1
            Next
            Dim textResultsfile As System.IO.StreamWriter = New System.IO.StreamWriter(TestResultsDir.FullName & "PaDSReportTestResults.txt", False, System.Text.Encoding.UTF8)
            textResultsfile.Write(PaDSReportTestResults)
            textResultsfile.Close()

            Dim fileName As String = IO.Path.Combine(TestResultsDir.FullName, "PaDSTestResults_" & Now.ToString("yyyy-MM-dd HHmmss") & ".xml")
            ds.WriteXml(fileName)
            Return fileName

        Catch ex As Exception
            Throw ex
        End Try

        Return Nothing

    End Function
    Dim PaDSReportTestResults As String = ""

    Sub WriteWorksheetToTextFile(wb As SpreadsheetGear.IWorkbook, ReportName As String, Optional KeepEachWorksheetCSVFile As Boolean = True)
        Dim RepCSV As IO.FileInfo = Nothing
        PaDSReportTestResults += vbCrLf & ReportName & vbCrLf & "==================================================="

        For Each ws As SpreadsheetGear.IWorksheet In wb.Worksheets
            If KeepEachWorksheetCSVFile Then
                RepCSV = New IO.FileInfo(IO.Path.Combine(TestResultsDir.FullName, "Results", "Reports", ReportName & "TAB_" & ws.Index & ".csv"))
            Else
                RepCSV = New IO.FileInfo(IO.Path.Combine(TestResultsDir.FullName, ReportName & "TAB_" & ws.Index & ".csv"))
            End If

            If Not RepCSV.Directory.Exists Then RepCSV.Directory.Create()
            ws.SaveAs(RepCSV.FullName, SpreadsheetGear.FileFormat.CSV)
            PaDSReportTestResults += vbCrLf & ws.Index.ToString("00") & " " & ws.Name
            Dim sr As IO.StreamReader = RepCSV.OpenText
            PaDSReportTestResults += vbCrLf & sr.ReadToEnd
            sr.Close()

            If Not KeepEachWorksheetCSVFile Then
                RepCSV.Delete()
            End If

        Next
    End Sub
    Sub WriteWorksheetToTextFile(FileBytes() As Byte, ReportName As String, Optional KeepEachWorksheetCSVFile As Boolean = True)
        Dim workbookSet As SpreadsheetGear.IWorkbookSet = SpreadsheetGear.Factory.GetWorkbookSet()
        Dim wb As SpreadsheetGear.IWorkbook = Nothing
        wb = workbookSet.Workbooks.OpenFromMemory(FileBytes)
        Me.WriteWorksheetToTextFile(wb, ReportName, KeepEachWorksheetCSVFile)

    End Sub
End Class
