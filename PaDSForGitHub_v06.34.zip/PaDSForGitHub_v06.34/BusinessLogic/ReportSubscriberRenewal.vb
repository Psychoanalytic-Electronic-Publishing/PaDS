﻿'Modification History
'Oct 2019       James Woosnam   SIR4945 - Initial Version
'25/11/19   James Woosnam   SIR4959 - Add optional Notes field
'13/1/22    james Woosnam   SIR5388 - Remove EmailOpt Out column
'6/3/23     James Woosnam   SIR5561 - Remove WebUerName and password from template

Public Class ReportSubscriberRenewal
    Inherits ReportSSG
#Region "Class Properties"
    Dim BatchJobId As Integer = Nothing
    Dim BlockSubscriberId As Integer
    Dim CompanyId As Integer
    Enum RenenalReportTypes
        Recurring
        NonRecurring
    End Enum
    Dim RenenalReportType As RenenalReportTypes = Nothing
#End Region

    Public Sub New(ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("SubscriberRenewal", "Excel", db, SubmittedByUserSessionId)
    End Sub
    Public Sub New(BlockSubscriberId As Integer, CompanyId As Integer, ReportSQL As String, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("SubscriberRenewal", "Excel", db, SubmittedByUserSessionId)
        Me.BlockSubscriberId = BlockSubscriberId
        Me.ReportSQL = ReportSQL
        Me.CompanyId = CompanyId
    End Sub
    Public Sub New(CompanyId As Integer, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("SubscriberRenewal", "Excel", db, SubmittedByUserSessionId)
        Me.CompanyId = CompanyId
    End Sub
    Public Overloads Sub Submit(CreateSubscriberImportBatches As Boolean)

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSessionId
        BatchJob.Parameters.Add("ReportName", Me.ReportName)
        BatchJob.Parameters.Add("RenenalReportType", RenenalReportTypes.Recurring)
        BatchJob.Parameters.Add("ReportSQL", Me.ReportSQL)
        BatchJob.Parameters.Add("BlockSubscriberId", Me.BlockSubscriberId)
        BatchJob.Parameters.Add("CreateSubscriberImportBatches", CreateSubscriberImportBatches)
        BatchJob.Parameters.Add("CompanyId", Me.CompanyId)

        BatchJob.CreateBatchJobEntry("RunReportSpreadsheetGearExcel", Me.db)

    End Sub

    Public Overloads Sub Execute(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.JobParameters = Parameters
        Select Case CType(Parameters.GetValue("RenenalReportType"), RenenalReportTypes)
            Case RenenalReportTypes.Recurring
                Me.ReportSQL = Parameters.GetValue("ReportSQL")
                Me.BlockSubscriberId = Parameters.GetValue("BlockSubscriberId")
                Me.CompanyId = Parameters.GetValue("CompanyId")
                Me.Execute(Parameters.GetValue("CreateSubscriberImportBatches"))
            Case RenenalReportTypes.NonRecurring
                Me.CompanyId = Parameters.GetValue("CompanyId")
                Me.ExecuteNonRecurring(Parameters.GetValue("SubscribedToProductCodes"), Parameters.GetValue("SpreadsheetsForSubscriberIds"), Parameters.GetValue("CreateSubscriberImportBatches"))
            Case Else
                Throw New Exception("RenenalReportType not handled")
        End Select

    End Sub

    Public Overloads Sub Execute(CreateSubscriberImportBatches As Boolean, Optional ByVal InBatchLog As BatchLog = Nothing)
        Dim blockSubscriberName As String = db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & Me.BlockSubscriberId)

        Dim batchLogCreatedHere As Boolean = False
        If InBatchLog Is Nothing Then
            Me.BatchLog = New BatchLog("Report-" & Me.ReportName _
                                          , ";BlockSubscriberId=" & Me.BlockSubscriberId _
                                          & ";BlockName=" & blockSubscriberName _
                                         , Me.db _
                                         , BatchJobId _
                                         , Me.SubmittedByUserSessionId)
            batchLogCreatedHere = True
        Else
            Me.BatchLog = InBatchLog
        End If
        Try
            MyBase.Execute(Me.BatchLog)
            Dim tblRep As DataTable = db.GetDataTableFromSQL(Me.ReportSQL)

            Me.ExcelWorkBook = SpreadsheetGear.Factory.GetWorkbook(Me.ExcelTemplate.FullName)
            Dim wsData As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Data")


            Dim rgBase As SpreadsheetGear.IRange
            rgBase = wsData.Cells("DataRows")
            rgBase.CopyFromDataTable(tblRep, SpreadsheetGear.Data.SetDataFlags.InsertCells + SpreadsheetGear.Data.SetDataFlags.None) '+ SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders)

            If Me.BlockSubscriberId <> Nothing And CreateSubscriberImportBatches Then
                Try
                    ReportName += " " & blockSubscriberName
                    'FileStore.AddNewFile(Me.ReportByteArray, Me.ReportName & ".xlsx", ReportType)
                    Dim srb As New SubscriberImportBatch(db, Me.SubmittedByUserSession)
                    '2/3/20     James Woosnam   SIR5030 - Make import batch name unique
                    srb.AddNew(BlockSubscriberId, CompanyId, srb.GetSubscriberImportBatchNameForAdd(Me.CompanyId,
                                                                                                    Me.BlockSubscriberId,
                                                                                                    Left(db.DLookup("CompanyShortName", "Company", "CompanyId=" & Me.CompanyId).ToString, 40) & " Renewal " & Now.ToString("yyyy")))
                    'srb.SubscriberImportBatchRow("RenewalFileStoreId") = FileStore.FileStoreId
                    srb.UpdateStatus(SubscriberImportBatch.SubscriberImportBatchStates.Available, Me.ReportByteArray, Me.ReportName)
                    BatchLog.Update("Import Batch:" & srb.SubscriberImportBatchId & " created")
                Catch ex As Exception
                    Throw New Exception("Add import batch Failed:" & ex.ToString)
                End Try


            End If
            ExcelWorkBook.SaveAs(Me.ReportFile.FullName, SpreadsheetGear.FileFormat.OpenXMLWorkbook)

            BatchLog.Update(Me.FileLink)

            If batchLogCreatedHere Then
                BatchLog.Update("Process Complete", "Complete")
            End If
        Catch ex As Exception
            BatchLog.Update("Report Failed:" & ex.Message, "Failed")
            Throw New Exception("Report Failed:" & ex.Message, ex)

        End Try

    End Sub
    Public Overloads Sub SubmitNonRecurring(SubscribedToProductCodes As String, SpreadsheetsForSubscriberIds As String, CreateSubscriberImportBatches As Boolean)

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSessionId
        BatchJob.Parameters.Add("ReportName", Me.ReportName)
        BatchJob.Parameters.Add("RenenalReportType", RenenalReportTypes.NonRecurring)
        BatchJob.Parameters.Add("SubscribedToProductCodes", SubscribedToProductCodes)
        BatchJob.Parameters.Add("SpreadsheetsForSubscriberIds", SpreadsheetsForSubscriberIds)
        BatchJob.Parameters.Add("CreateSubscriberImportBatches", CreateSubscriberImportBatches)
        BatchJob.Parameters.Add("CompanyId", Me.CompanyId)

        BatchJob.CreateBatchJobEntry("RunReportSpreadsheetGearExcel", Me.db)

    End Sub
    Public Overloads Sub ExecuteNonRecurring(SubscribedToProductCodes As String, SpreadsheetsForSubscriberIds As String, CreateSubscriberImportBatches As Boolean, Optional ByVal InBatchLog As BatchLog = Nothing)

        Dim batchLogCreatedHere As Boolean = False
        If InBatchLog Is Nothing Then
            Me.BatchLog = New BatchLog("Report-" & Me.ReportName _
                                          , ";SubscribedToProductCodes=" & SubscribedToProductCodes _
                                          & ";SpreadsheetsForSubscriberIds=" & SpreadsheetsForSubscriberIds _
                                          & ";CreateSubscriberImportBatches=" & CreateSubscriberImportBatches.ToString _
                                         , Me.db _
                                         , BatchJobId _
                                         , Me.SubmittedByUserSessionId)
            batchLogCreatedHere = True
        Else
            Me.BatchLog = InBatchLog
        End If
        Try
            MyBase.Execute(Me.BatchLog)
            Dim sql As String
            sql = "
SELECT DISTINCT
	so.OrderNumber
	,sol.SubscriberId
	,so.OrderType
	,SubAff.AffiliateReferenceID 
	,OrderedBySubscriberId = OrderedBySubscriber.SubscriberId
	,OrderedBySubscriberName = OrderedBySubscriber.SubscriberName 
FROM SalesorderLine sol
	INNER JOIN Salesorder so
		INNER JOIN Subscriber OrderedBySubscriber 
		On OrderedBySubscriber.SubscriberId = so.SubscriberId
	On so.OrderNumber = sol.OrderNumber
	AND so.SalesorderStatus IN ('Confirmed','Complete')
	INNER JOIN Product ParentProduct 
	On ParentProduct.ProductCode = sol.ProductCode
	AND ParentProduct.ProductCode IN (" & SubscribedToProductCodes & ")
	INNER JOIN SubscriberAffiliate SubAff
	ON SubAff.ParentSubscriberId = so.SubscriberId
	AND SubAff.ChildSubscriberId = sol.SubscriberId
WHERE ISNULL(sol.IsCancel,0) <> 1
AND so.SubscriberId IN (" & SpreadsheetsForSubscriberIds & ")
ORDER BY
	 OrderedBySubscriber.SubscriberName 
	,sol.SubscriberId
"
            Dim tbl As DataTable = db.GetDataTableFromSQL(sql)
            If tbl.Rows.Count = 0 Then
                Throw New Exception("There are no rows to output")
            End If
            Dim OrderedBySubscriberName As String = ""
            For Each row As DataRow In tbl.Rows
                If OrderedBySubscriberName <> row("OrderedBySubscriberName") Then
                    Dim subIds As String = ""
                    For Each r2 As DataRow In tbl.Rows
                        If r2("OrderedBySubscriberName") = row("OrderedBySubscriberName") Then
                            subIds += IIf(subIds = "", "", ",") & r2("SubscriberId")
                        End If
                    Next
                    '25/11/19   James Woosnam   SIR4959 - Add optional Notes field
                    '12/12/19   James Woosnam   SIR4978 - Re-add blank webusername and password fields
                    '13/1/22    james Woosnam   SIR5388 - Remove EmailOpt Out column
                    '6/3/23     James Woosnam   SIR5561 - Remove WebUerName and password from template
                    sql = "
                        SELECT DISTINCT
                            AffiliateReferenceID = ISNULL(SubAff.AffiliateReferenceID,Subscriber.SubscriberId)
                            ,SubscriberAffiliate.SubscriberCategory
                            ,ParentSubscriberName='" & row("OrderedBySubscriberName").ToString.Replace("'", "''") & "'
                            ,Subscriber.FirstName
                            ,Subscriber.LastName
                            ,SubscriberAddress.Address1
                            ,SubscriberAddress.Address2
                            ,SubscriberAddress.Address3
                            ,SubscriberAddress.Address4
                            ,City = SubscriberAddress.Town
                            ,State = SubscriberAddress.County
                            ,SubscriberAddress.PostCode
                            ,Country.CountryName
                            ,EmailAddress = Email.AddressText
                            ,PrintedCopy = 'Y'
                            ,Notes = ''
                         FROM  Subscriber Subscriber 
	                        INNER JOIN SubscriberAffiliate
			                        INNER JOIN Company
			                        On Company.CompanyId = " & Me.CompanyId & "
			                        AND Company.GroupParentSubscriberId = SubscriberAffiliate.ParentSubscriberId
	                        ON SubscriberAffiliate.ChildSubscriberId = Subscriber.SubscriberId
	                        AND GetDate() BETWEEN SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate
	                        Left JOIN SubscriberAddress
 		                        LEFT JOIN Country
 		                        ON Country.CountryId = SubscriberAddress.CountryId
 	                        ON SubscriberAddress.SubscriberAddressId = (SELECT top 1 sa.SubscriberAddressId
 											                        FROM SubscriberAddress sa
                                                                   WHERE(sa.SubscriberId = Subscriber.SubscriberId)
											                        AND sa.AddressType = 'Postal'
 											                        AND sa.AddressDescription <> 'Redundant'
 											                        Order BY CASE WHEN  sa.AddressDescription = Company.DefaultAddressDescription THEN 0 ELSE 1 End
 											                            ,sa.LastUpdatedDateTime 
 											                        )
 	                        Left JOIN SubscriberAddress Email
 	                        ON Email.SubscriberId = Subscriber.SubscriberID
 	                        AND Email.AddressType = 'Email'
 	                        AND Email.AddressDescription = 'Main'
	                        LEFT JOIN SubscriberAffiliate SubAff
	                        ON SubAff.ParentSubscriberId   IN (" & row("OrderedBySubscriberId") & ")
	                        AND SubAff.ChildSubscriberId = subscriber.SubscriberId
	                        AND GetDate() BETWEEN SubAff.StartDate AND SubAff.EndDate

                         WHERE Subscriber.SubscriberStatus='Current'
                         AND Subscriber.SubscriberId in (" & subIds & ")
                         ORDER BY  Subscriber.LastName 
		                        ,Subscriber.FirstName  
  
                        "
                    Dim outtbl As DataTable = db.GetDataTableFromSQL(sql)
                    Me.ExcelWorkBook = SpreadsheetGear.Factory.GetWorkbook(Me.ExcelTemplate.FullName)
                    Dim wsData As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Data")

                    Dim rgBase As SpreadsheetGear.IRange
                    rgBase = wsData.Cells("DataRows")
                    rgBase.CopyFromDataTable(outtbl, SpreadsheetGear.Data.SetDataFlags.InsertCells + SpreadsheetGear.Data.SetDataFlags.None) '+ SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders)
                    Dim fi As New IO.FileInfo(IO.Path.Combine(Me.RandomOutputDirectory.FullName, row("OrderedBySubscriberName") & " RenewalFile.xlsx"))
                    If CreateSubscriberImportBatches Then
                        'FileStore.AddNewFile(Me.ReportByteArray, Me.ReportName & ".xlsx", ReportType)
                        Dim srb As New SubscriberImportBatch(db, Me.SubmittedByUserSession)
                        '2/3/20     James Woosnam   SIR5030 - Make import batch name unique
                        srb.AddNew(row("OrderedBySubscriberId"), CompanyId, srb.GetSubscriberImportBatchNameForAdd(Me.CompanyId,
                                                                                                    Me.BlockSubscriberId,
                                                                                                    Left(db.DLookup("CompanyShortName", "Company", "CompanyId=" & Me.CompanyId).ToString, 40) & " Renewal " & Now.ToString("yyyy")))
                        Dim memoryStream As New System.IO.MemoryStream()
                        Me.ExcelWorkBook.SaveToStream(memoryStream, SpreadsheetGear.FileFormat.OpenXMLWorkbook)
                        srb.UpdateStatus(SubscriberImportBatch.SubscriberImportBatchStates.Available, memoryStream.ToArray, fi.Name)
                    End If
                    ExcelWorkBook.SaveAs(fi.FullName, SpreadsheetGear.FileFormat.OpenXMLWorkbook)

                    BatchLog.Update(Me.GetFileLink(fi.Name.Replace(".xlsx", "")))

                End If

                OrderedBySubscriberName = row("OrderedBySubscriberName")
            Next


            If batchLogCreatedHere Then BatchLog.Update("Process Complete", "Complete")
        Catch ex As Exception
            If batchLogCreatedHere Then BatchLog.Update("Report Failed:" & ex.Message, "Failed")
            Throw New Exception("Report Failed:" & ex.Message, ex)

        End Try

    End Sub
    Public Function GetSQL(ByVal CompanyId As Integer _
                    , ByVal SubscribedProduct As String _
                    , ByVal DateType As String _
                    , ByVal SubscriberRenewalReportType As String _
                    , ByVal OrderOnDate As Date _
                    , ByVal ExpireBetweenFromDate As Date _
                    , ByVal ExpireBetweenToDate As Date _
                    , ByVal SelectedGroupSubscribers As DataTable) As String

        Dim SQLColumns As String
        Dim SQLFrom As String
        Dim SQLWhere As String
        Dim SQLGroup As String
        Dim SQLOrderBy As String
        Dim sqlForTemp As String = Nothing
        Dim Line As String = System.Environment.NewLine
        Dim GroupSubscribers As String = " IN ("
        If SubscriberRenewalReportType = "Groups" Then
            For Each row As DataRow In SelectedGroupSubscribers.Rows
                GroupSubscribers += row("SubscriberId") & ","
            Next
            GroupSubscribers = GroupSubscribers.Substring(0, GroupSubscribers.Length - 1) & ")"
        End If

        sqlForTemp = "SELECT " & Line
        sqlForTemp += "      SalesOrder.OrderNumber" & Line
        sqlForTemp += "		,SalesOrderLine.SubscriberId" & Line
        sqlForTemp += "		,SalesORder.OrderType" & Line
        sqlForTemp += "		,OrderedBySubscriberId = OrderedBySubscriber.SubscriberId" & Line
        sqlForTemp += "		,OrderedBySubscriberName = OrderedBySubscriber.SubscriberName " & Line
        sqlForTemp += "INTO #SalesorderLine" & Line
        sqlForTemp += "FROM SalesorderLine " & Line
        sqlForTemp += "	INNER JOIN Salesorder " & Line
        sqlForTemp += "		INNER JOIN Subscriber OrderedBySubscriber " & Line
        sqlForTemp += "		On OrderedBySubscriber.SubscriberId = Salesorder.SubscriberId" & Line
        sqlForTemp += "	On SalesOrder.OrderNumber = SalesorderLine.OrderNumber" & Line
        sqlForTemp += "	AND SalesOrder.SalesorderStatus IN ('Confirmed','Complete')" & Line
        sqlForTemp += "	INNER JOIN Product ParentProduct " & Line
        sqlForTemp += "	On ParentProduct.ProductCode = SalesOrderLine.ProductCode" & Line
        sqlForTemp += "	INNER JOIN Product ChildProduct " & Line
        sqlForTemp += "	On ChildProduct.ParentProductCode = SalesOrderLine.ProductCode" & Line
        sqlForTemp += "	AND ChildProduct.ProductReportName = '" & SubscribedProduct & "'" & Line
        sqlForTemp += "	AND IsNull(ChildProduct.ProductReportName ,'') <> ''" & Line
        If SubscriberRenewalReportType = "Groups" Then
            '2/12/19    James Woosnam   SIR4952 - Only show subs who order through selected group(s)
            sqlForTemp = sqlForTemp + "     INNER JOIN SubscriberAffiliate SubAff" & Line _
                 & "        ON SubAff.ParentSubscriberId  " & GroupSubscribers & Line _
                 & "        AND SubAff.ChildSubscriberId = SalesorderLine.SubscriberId" & Line _
                 & "        AND SubAff.ParentSubscriberId = Salesorder.SubscriberId" & Line
        End If
        Select Case DateType
            Case "SingleDate"
                sqlForTemp += " WHERE SalesorderLine.RecurringSubscriptionStartDate = " & db.vFQ(OrderOnDate, "D")
            Case "DateRange"
                sqlForTemp += " WHERE SalesorderLine.RecurringSubscriptionEndDate BETWEEN " & db.vFQ(ExpireBetweenFromDate, "D") & " AND  " & db.vFQ(ExpireBetweenToDate, "D") _
                          & " AND ISNULL(ParentProduct.RecurringSubscriptionFlag,0) = 1" & Line _
                          & "		AND SalesOrderLine.RecurringSubscriptionEndDate = (Select MAX(sol.RecurringSubscriptionEndDate)" & Line _
                          & "									FROM SalesOrder SO" & Line _
                          & "										INNER JOIN SalesOrderLine sol" & Line _
                          & "										On sol.ordernumber = so.ordernumber" & Line _
                          & "									WHERE sol.SubscriberId = SalesOrderLine.SubscriberId " & Line _
                          & "									AND SO.CompanyId = SalesOrder.CompanyId" & Line _
                          & "									AND SO.OrderType = SalesOrder.OrderType" & Line _
                          & "									AND SO.PrimaryProductCode = SalesOrder.PrimaryProductCode" & Line _
                          & "									AND SO.SalesorderStatus = SalesOrder.SalesorderStatus)" & Line

            Case Else
                Throw New Exception("DateType:'" & DateType & "' not recongnised")
        End Select
        '19/4/22    James Woosnam   SIR5477 - Exclude cancelled lines
        sqlForTemp += " AND SalesorderLine.IsCancel <> 1" & Line

        If SubscriberRenewalReportType = "Individual" Then
            sqlForTemp += " AND SalesOrder.OrderType IN ('Individual','IndividualRemote')	" & Line
        End If

        SQLFrom = " FROM Subscriber" & Line

        SQLWhere = " WHERE Subscriber.SubscriberStatus='Current'" & Line
        '20/11/19   James Woosnam   SIR4763 - Get UserName from RemoteUser
        SQLFrom += "    LEFT JOIN RemoteUserRights rur" & Line
        SQLFrom += "         INNER JOIN RemoteUser ru" & Line
        SQLFrom += "         ON ru.UserId = rur.UserId" & Line
        SQLFrom += "    ON rur.RightsToId = Subscriber.SubscriberId" & Line
        SQLFrom += "    AND rur.RightsType = 'Subscriber'" & Line

        SQLFrom = SQLFrom + "	INNER JOIN SubscriberAffiliate" & Line _
             & "			INNER JOIN Company" & Line _
             & "			On Company.CompanyId = " & CompanyId & Line _
             & "			AND Company.GroupParentSubscriberId = SubscriberAffiliate.ParentSubscriberId" & Line _
             & "		ON SubscriberAffiliate.ChildSubscriberId = Subscriber.SubscriberId" & Line _
             & "		AND GetDate() BETWEEN SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate" & Line

        SQLFrom = SQLFrom + "	INNER JOIN #SalesorderLine SalesorderLine " & Line _
             & "		ON SalesorderLine.SubscriberId = Subscriber.SubscriberId" & Line _
             & "		" & Line

        '20/4/07	James Woosnam	Use RecurringSubscriptionStartDate instead of order date 		
        'Process new group subscribers list
        If SubscriberRenewalReportType = "Groups" Then
            SQLFrom = SQLFrom + "	INNER JOIN SubscriberAffiliate SubAff" & Line _
                 & "		ON SubAff.ParentSubscriberId  " & GroupSubscribers & Line _
                 & "		AND SubAff.ChildSubscriberId = SalesorderLine.SubscriberId" & Line
        End If
        If SubscriberRenewalReportType = "Individual" Then
            SQLWhere = SQLWhere + " AND SalesorderLine.OrderType IN ('Individual','IndividualRemote')	" & Line
        End If
        SQLGroup = " GROUP BY Subscriber.SubscriberId" & Line
        SQLColumns = "SELECT "
        If SubscriberRenewalReportType = "Groups" Then
            SQLColumns = SQLColumns & "	MIN(SubAff.AffiliateReferenceID) as AffiliateReferenceID" & Line
        Else
            SQLColumns = SQLColumns & "	'' as AffiliateReferenceID" & Line
        End If

        SQLColumns = SQLColumns & " ,SubscriberCategory = MIN(SubscriberAffiliate.SubscriberCategory) " & Line
        '24/10/2006  James Woosnam   Add SQL below to populate ParentSubscriberName in CSV
        SQLColumns = SQLColumns & "	,CASE WHEN MIN(SalesorderLine.OrderType) = 'Block' " & Line _
          & "							  THEN MIN(SalesorderLine.OrderedBySubscriberName) " & Line _
          & "							 ELSE '' END as ParentSubscriberName" & Line

        '03/10/14   Julian Gates    SIR3621 - Add IsReceive Mail field to Function GetSQL
        '09/02/16   Julian Gates    SIR4045 - Change Town/County to City/State in SQLColumns below
        '25/11/19   James Woosnam   SIR4959 - Add optional Notes field and remove webusername and password fields
        '12/12/19   James Woosnam   SIR4978 - Re-add blank webusername and password fields
        '13/1/22    james Woosnam   SIR5388 - Remove IsReceive Mail/EmailOpt Out column
        '6/3/23     James Woosnam   SIR5561 - Remove WebUerName and password from template
        SQLColumns = SQLColumns _
          & "		,MIN( Subscriber.FirstName) AS FirstName" & Line _
          & "		,MIN( Subscriber.LastName) AS LastName" & Line _
          & "		,MIN( SubscriberAddress.Address1) AS Address1" & Line _
          & "		,MIN( SubscriberAddress.Address2) AS Address2" & Line _
          & "		,MIN( SubscriberAddress.Address3) AS Address3" & Line _
          & "		,MIN( SubscriberAddress.Address4) As Address4" & Line _
          & "		,MIN( SubscriberAddress.Town) AS City" & Line _
          & "		,MIN( SubscriberAddress.County) As State" & Line _
          & "		,MIN( SubscriberAddress.PostCode) AS PostCode" & Line _
          & "		,MIN( Country.CountryName) As CountryName" & Line _
          & "		,MIN( Email.AddressText) As EmailAddress" & Line _
          & "		,'' As Notes" & Line

        '31/3/11    James Woosnam   SIR2401 - Use the company specific address if available else use latest address
        SQLFrom = SQLFrom _
         & "	Left JOIN SubscriberAddress" & Line _
          & " 		LEFT JOIN Country" & Line _
          & " 		ON Country.CountryId = SubscriberAddress.CountryId" & Line _
          & " 	ON SubscriberAddress.SubscriberAddressId = (SELECT top 1 sa.SubscriberAddressId" & Line _
          & " 											FROM SubscriberAddress sa" & Line _
          & "                                           WHERE(sa.SubscriberId = Subscriber.SubscriberId)" & Line _
          & "											AND sa.AddressType = 'Postal'" & Line _
          & " 											AND sa.AddressDescription <> 'Redundant'" & Line _
          & " 											Order BY CASE WHEN  sa.AddressDescription = Company.DefaultAddressDescription THEN 0 ELSE 1 End" & Line _
          & " 											    ,sa.LastUpdatedDateTime " & Line _
          & " 											)" & Line _
          & " 	Left JOIN SubscriberAddress Email" & Line _
          & " 	ON Email.SubscriberId = Subscriber.SubscriberID" & Line _
          & " 	AND Email.AddressType = 'Email'" & Line _
          & " 	AND Email.AddressDescription = 'Main'"

        SQLOrderBy = " ORDER BY  CASE WHEN MIN(SalesorderLine.OrderType) = 'Block' " & Line _
          & "							  THEN MIN(SalesorderLine.OrderedBySubscriberName) " & Line _
          & "							 ELSE '' END" & Line _
          & "                   ,MIN(Subscriber.SubscriberName)"
        Return sqlForTemp & SQLColumns & SQLFrom & SQLWhere & SQLGroup & SQLOrderBy


    End Function

End Class
