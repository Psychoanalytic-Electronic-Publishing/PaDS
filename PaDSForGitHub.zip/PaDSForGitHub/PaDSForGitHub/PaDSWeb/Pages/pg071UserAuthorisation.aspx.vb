﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'29/10/19  Julian Gates   Initial version
'13/2/20    James Woosnam   SIR5017 - ensure invalid links are handled more clearly
'17/8/20    James Woosnam   SIR5082 - Store SessionId in, and restored from, a new session cookie
'25/8/20    Julian Gates    SIR5121 - Add new redirect selection section shown when user sucessfully activates.

Partial Class pages_pg071UserAuthorisation
    Inherits System.Web.UI.Page
    Dim ds As New DataSet
    Dim StdCode As New BusinessLogic.StdCode()
    Enum PageModes
        Normal
        InvalidActivation
        AlreadyActive
        EmailSent
        Activated
    End Enum

    Private _RemoteUser As BusinessLogic.RemoteUser = Nothing
    Public Property RemoteUser() As BusinessLogic.RemoteUser
        Get
            If Me._RemoteUser Is Nothing Then
                Me._RemoteUser = New BusinessLogic.RemoteUser(Me.Master.db, Me.Master.UserSession)
            End If
            Return Me._RemoteUser
        End Get
        Set(ByVal value As BusinessLogic.RemoteUser)
            Me._RemoteUser = value
        End Set
    End Property


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        '17/8/20    James Woosnam   SIR5082 - Store SessionId in, and restored from, a new session cookie
        'Must reset cookie when opening with tempPassword, tempPassword is striped off after execution so sessioncookie must then be used
        Dim ResetSessionCookieIfNotPostback As Boolean = Request.QueryString("TempPassword") <> ""
        Master.Initilise("Welcome to Pads Account Activation & Password Reset", "00", "", "", "", ResetSessionCookieIfNotPostback)
        If Page.IsPostBack Then
        Else
            ViewState("PageMode") = PageModes.Normal
        End If
        If Request.QueryString("UserName") = "" _
            Or Request.QueryString("EmailAddress") = "" _
            Or Request.QueryString("TempPassword") = "" _
            Then
            Me.Master.WebForm.AddPageError(New Exception("Invalid activation. Please contact support", New Exception("QueryString values UserName, EmailAddress or TempPassword are blank")))
            ViewState("PageMode") = PageModes.InvalidActivation
            Exit Sub
        End If
        Me.EmailAddress.Text = Request.QueryString("EmailAddress")
        Me.UserName.Text = Request.QueryString("UserName")
        Try
            Try
                Master.UserSession.Logon(Request.QueryString("UserName"), Request.QueryString("TempPassword"))
            Catch ex As Exception
                If ex.Message.Contains("Invalid user and/or password") Then
                    Try
                        Dim ru As New BusinessLogic.RemoteUser(Request.QueryString("UserName"), Master.db, Master.UserSession)
                        Select Case ru.UserStatus
                            Case BusinessLogic.RemoteUser.UserStates.Active
                                Me.Master.WebForm.AddPageError("This user has already been activated")
                                ViewState("PageMode") = PageModes.AlreadyActive
                                Exit Sub
                            Case Else
                                Throw ex
                        End Select
                    Catch ex2 As Exception
                        Me.Master.WebForm.AddPageError(New Exception("This password reset link is no longer valid.", ex2))
                        ViewState("PageMode") = PageModes.InvalidActivation
                        Exit Sub
                    End Try
                Else
                    Throw ex
                End If
            End Try
            Me.RemoteUser = New BusinessLogic.RemoteUser(Master.UserSession.UserId, Me.Master.db, Me.Master.UserSession)
            If CDate(Me.RemoteUser.RemoteUserRow("EmailAuthenticationSentDateTime")) < Now.Date.AddHours(Me.RemoteUser.HoursToConfirmNewEmail * -1) Then
                Me.Master.WebForm.AddPageError("Your reset/activation email has expired.")
                ViewState("PageMode") = PageModes.InvalidActivation
                Exit Sub
            End If
            Me.UserName.Text = Me.RemoteUser.UserName
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("Invalid activation.", ex))
            ViewState("PageMode") = PageModes.InvalidActivation
        End Try

        If Page.IsPostBack Then
        Else
            Me.NewPassword.Focus()
        End If
        '25/8/20    Julian Gates    SIR5121 - Add new redirect selection section shown when user sucessfully activates.
        Me.PadsLink.NavigateUrl = "pg070Logon.aspx?Action=RedirectToUserHome&" & Me.Master.UserSession.QueryString
        Me.PEPWebLink.NavigateUrl = Master.db.GetParameterValue("PEPGatewayTargetURL") & "?SessionId=" & Me.Master.UserSession.UserSessionId
    End Sub

    Sub PageSetup()
        Dim pm As PageModes = ViewState("PageMode")
        Me.InvalidActivationTable.Visible = pm = PageModes.InvalidActivation
        Me.AlreadyActiveTable.Visible = pm = PageModes.AlreadyActive
        Me.ResetTable.Visible = pm = PageModes.Normal
        Me.EmailSentTable.Visible = pm = PageModes.EmailSent
        '25/8/20    Julian Gates    SIR5121 - Add new redirect selection section shown when user sucessfully activates.
        Me.ActivatedLinkTable.Visible = pm = PageModes.Activated
        If pm = PageModes.Activated Then
            Me.ResetTable.Visible = False
            Me.RONamesTable.Visible = False
        End If
    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus

            Case Else
                Me.Master.WebForm.FieldValidateMandatory(Me.NewPassword)
                Me.Master.WebForm.FieldValidateMandatory(Me.ConfirmPassword)

                If Me.NewPassword.Text <> Me.ConfirmPassword.Text Then
                    Me.Master.WebForm.AddPageError("Passwords do not match")
                Else
                    Dim err As String = ""
                    If Not RemoteUser.IsValidPassword(Me.NewPassword.Text, err) Then
                        Me.Master.WebForm.FieldErrorControl(Me.NewPassword, err)
                    Else
                        Select Case RemoteUser.UserStatus
                            Case BusinessLogic.RemoteUser.UserStates.Emailed
                            Case Else
                                Me.Master.WebForm.AddPageError("Only users with an emailed status can be activated.  Please contact support.")
                        End Select
                    End If


                End If

        End Select

        Return Me.Master.WebForm.IsValid
    End Function

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ActivateBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ActivateBtn.Click
        Dim resetSuccessfull As Boolean = False
        If Not Me.Master.WebForm.IsValid Then
            Exit Sub
        End If
        If Me.IsPageValidForStatus("") Then

            Try
                Me.RemoteUser.Activate(Me.NewPassword.Text)
                resetSuccessfull = True
                Dim peps As New BusinessLogic.PEPSecurity(Master.db, New BusinessLogic.StdCode().GetIPAddress(Request))
                Select Case Master.UserSession.LoggedInMethod
                    Case BusinessLogic.UserSession.LoggedInMethods.Federated
                        peps.AuthenticateFromFederated(Master.UserSession,
                                    Master.UserSession.Data("LoggedInWithFederatedEntity"),
                                    Master.UserSession.Data("LoggedInWithFederatedScope"),
                                    Master.UserSession.Data("LoggedInWithFederatedPersonId")
                            )
                    Case BusinessLogic.UserSession.LoggedInMethods.ReferrerURL
                End Select
            Catch ex As Exception
                Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured.  Please contact support", ex))
            End Try

        End If
        If resetSuccessfull Then
            ViewState("PageMode") = PageModes.Activated
        End If
    End Sub
    Protected Sub SendPasswordResetEmailBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SendPasswordResetEmailBtn.Click
        Try
            Me.Master.WebForm.ClearPageErrors()
            'Send password reset email
            Dim ru As New BusinessLogic.RemoteUser(Request.QueryString("UserName"), Master.db, Master.UserSession)
            ru.ResetPasswordAndEmail()
            ViewState("PageMode") = PageModes.EmailSent
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("An unexpected error has occured.  Please contact support.", ex))
        End Try

    End Sub

End Class

