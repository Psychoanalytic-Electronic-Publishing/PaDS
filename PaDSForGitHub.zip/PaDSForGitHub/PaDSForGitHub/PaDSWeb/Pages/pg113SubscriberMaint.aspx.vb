﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.Subscriber
'Modification History
'30/03/20   Julian Gates    Initial New version
'24/8/20    Julian Gates    SIR5119 - Remove Postal from address field prompts.
'30/03/20  Julian Gates   Initial New version
'19/08/20   Julian Gates    SIR5099 - Add Audit link
'8/1/21     James Woosnam   SIR5143 - Make address optional and add AreAdressesSame functionality
Partial Class Pages_pg113SubscriberMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                Me._Subscriber = New BusinessLogic.Subscriber(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Subscriber Maintenance ", "")
        Try
            If Page.IsPostBack Then
                Me.Subscriber.MainDataset = CType(ViewState("MainDataSet"), DataSet)
            Else
                If Request.QueryString("SubscriberId") <> "" Then
                    Try
                        Me.txtSubscriberId.Value = Request.QueryString("SubscriberId")
                        Me.Subscriber = New BusinessLogic.Subscriber(CInt(Request.QueryString("SubscriberId")), Me.uPage.db, Me.uPage.UserSession)
                    Catch ex As Exception
                        Me.uPage.PageError = "Invalid Parameter has been passed in"
                    End Try
                End If

                If Me.uPage.IsValid Then
                    ReadRecord()
                End If
                Me.FirstName.Focus()
            End If
        Catch ex As Exception
            uPage.PageError = "An unexpected error has occured.  Please contact support." & ex.ToString
        End Try

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

    End Sub

    Sub PageSetup()
        uPage.pageTitle = "SID Maint: " & Subscriber.SubscriberId & " - " & Subscriber.SubscriberName
        Me.pageHeaderTitle.Text = uPage.pageTitle

        'Setuppage buttons
        Me.InActiveBtnTd.Visible = Subscriber.SubscriberStatus = SubscriberStates.Current
        Me.SetProposedBtnTd.Visible = Subscriber.SubscriberStatus = SubscriberStates.Current
        Me.MergeBtnTd.Visible = Subscriber.SubscriberStatus = SubscriberStates.Proposed And Not uPage.db.IsDBNull(Me.Subscriber.SubscriberRow("UpdateToSubscriberId"))
        Me.RejectBtnTd.Visible = Subscriber.SubscriberStatus = SubscriberStates.Proposed
        Me.AcceptAsNewBtnTd.Visible = (Subscriber.SubscriberStatus = SubscriberStates.Proposed Or Subscriber.SubscriberStatus = SubscriberStates.InActive) And uPage.db.IsDBNull(Me.Subscriber.SubscriberRow("UpdateToSubscriberId"))
        Select Case Subscriber.SubscriberStatus
            Case SubscriberStates.InActive
                Me.AcceptAsNewBtn.Text = "Re-Make Current"
        End Select

        Select Case Me.EntityType.Text
            Case "Person"
                Me.OrganisationNameRow.Visible = False
                Me.FirstNameRow.Visible = True
                Me.LastNameRow.Visible = True
                Me.TitleRow.Visible = True
                Me.FirstName.Focus()
            Case "Organisation"
                Me.OrganisationNameRow.Visible = True
                Me.FirstNameRow.Visible = False
                Me.LastNameRow.Visible = False
                Me.TitleRow.Visible = False
                Me.SubscriberName.Focus()
        End Select

        'setup duplicate check list
        If Subscriber.SubscriberStatus = SubscriberStates.Proposed And uPage.db.IsDBNull(Me.Subscriber.SubscriberRow("UpdateToSubscriberId"), Nothing) = Nothing Then
            Me.PotentialDuplicatesGridTable.Visible = True
            If Not Page.IsPostBack Then
                If Me.DupCheckSubscriberName.Text = Nothing Then
                    If Me.EntityType.Text = "Person" Then
                        Me.DupCheckSubscriberName.Text = Me.LastName.Text
                    Else
                        Me.DupCheckSubscriberName.Text = Me.SubscriberName.Text
                    End If

                End If
            End If
            BuildPotentialDuplicatesGridViewHTML()
        Else
            Me.PotentialDuplicatesGridTable.Visible = False
        End If
        Me.BillingAddressDiv.Visible = Not AreAddressesTheSame.Checked
        'Hide some buttons and sections based on AuthorityLevel
        Select Case Me.uPage.UserSession.AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
            Case Else
                Me.MergeBtnTd.Visible = False
                Me.RejectBtnTd.Visible = False
                Me.SetProposedBtnTd.Visible = False
                Me.AcceptAsNewBtnTd.Visible = False
                Me.PotentialDuplicatesGridTable.Visible = False
                Me.InActiveBtnTd.Visible = False
        End Select

        '19/08/20   Julian Gates    SIR5099 - Add Audit link
        Me.AuditLink.NavigateUrl = "../pages/pg040AuditLogDisplay.aspx?FltrUpdatedRecordFamily=Subscriber&FltrUpdatedRecordFamilyKey=" & Me.Subscriber.SubscriberId & "&" & uPage.UserSession.QueryString
        Me.AuditLink.Text = "View Audit"
        Me.AuditLink.ToolTip = "View Audit for this record"
    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else
                Select Case Me.EntityType.Text
                    Case "Person"
                        Me.uPage.FieldValidateMandatory(Me.FirstName)
                        Me.uPage.FieldValidateMandatory(Me.LastName)
                    Case "Organisation"
                        If Me.SubscriberName.Text.Replace(vbCrLf, Nothing) = Nothing Then
                            Me.uPage.PageError = "Organisation is mandatory"
                            Me.SubscriberName.CssClass = "fldEntryError"
                        Else
                            Me.SubscriberName.CssClass = "fldEntry"
                        End If
                End Select
                If Me.PrimaryCountryId.SelectedValue = Nothing Then
                    Me.uPage.PageError = "Country is mandatory"
                    Me.PrimaryCountryId.CssClass = "fldEntryError"
                Else
                    Me.PrimaryCountryId.CssClass = "fldEntry"
                End If



                If Me.EmailAddress.Text <> "" Then
                    If Not Me.uPage.StdCode.IsValidEmail(Me.EmailAddress.Text) Then
                        Me.uPage.PageError = "Email Address is syntactically invalid"
                        Me.EmailAddress.CssClass = "fldEntryError"
                    Else
                        Me.EmailAddress.CssClass = "fldEntry"
                    End If
                End If

                If Me.BuildingStreet.Text <> "" And Me.Town.Text <> "" Then
                    'jan2020    James Woosnam   If building and town are blank then assume address isn't required
                    'Mailing Address validation
                    If Me.BuildingStreet.Text.Replace(vbCrLf, Nothing) = Nothing Then
                        Me.uPage.PageError = "Mailing Building Street is mandatory"
                        Me.BuildingStreet.CssClass = "fldEntryError"
                    Else
                        Me.BuildingStreet.CssClass = "fldEntry"
                    End If
                    If Me.Town.Text = Nothing Then
                        Me.uPage.PageError = "Mailing City is mandatory"
                        Me.Town.CssClass = "fldEntryError"
                    Else
                        Me.Town.CssClass = "fldEntry"
                    End If

                    If Me.uPage.db.IsDBNull(Me.CountryId.SelectedValue, "") = "11" Or Me.uPage.db.IsDBNull(Me.CountryId.SelectedValue, "") = "56" Then 'US or Canada
                        Me.uPage.DropDownValidateMandatory(Me.CountyUS, "Mailing State (US or Canada)")
                    End If
                    If Me.PostCode.Text = Nothing Then
                        Me.uPage.PageError = "Mailing Postcode is mandatory"
                        Me.PostCode.CssClass = "fldEntryError"
                    Else
                        Me.PostCode.CssClass = "fldEntry"
                    End If

                    If String.IsNullOrEmpty(Me.CountryId.SelectedValue) _
                    Or Me.CountryId.SelectedValue = "0" Then
                        Me.uPage.PageError = "Mailing Country is mandatory"
                        Me.CountryId.CssClass = "fldEntryError"
                    Else
                        Me.CountryId.CssClass = "DropDownList"
                    End If
                    If Not Me.AreAddressesTheSame.Checked Then
                        'Billing Address validation
                        If Me.BillBuildingStreet.Text.Replace(vbCrLf, Nothing) = Nothing Then
                            Me.uPage.PageError = "Billing Building Street is mandatory"
                            Me.BillBuildingStreet.CssClass = "fldEntryError"
                        Else
                            Me.BillBuildingStreet.CssClass = "fldEntry"
                        End If
                        If Me.BillTown.Text = Nothing Then
                            Me.uPage.PageError = "Billing City is mandatory"
                            Me.BillTown.CssClass = "fldEntryError"
                        Else
                            Me.BillTown.CssClass = "fldEntry"
                        End If
                        If Me.uPage.db.IsDBNull(Me.BillCountryId.SelectedValue, "") = "11" Or Me.uPage.db.IsDBNull(Me.BillCountryId.SelectedValue, "") = "56" Then 'US or Canada
                            Me.uPage.DropDownValidateMandatory(Me.BillCountyUS, "Billing State (US or Canada)")
                        End If
                        If Me.BillPostCode.Text = Nothing Then
                            Me.uPage.PageError = "Billing Postcode is mandatory"
                            Me.BillPostCode.CssClass = "fldEntryError"
                        Else
                            Me.BillPostCode.CssClass = "fldEntry"
                        End If

                        If String.IsNullOrEmpty(Me.BillCountryId.SelectedValue) _
                        Or Me.BillCountryId.SelectedValue = "0" Then
                            Me.uPage.PageError = "Billing Country is mandatory"
                            Me.BillCountryId.CssClass = "fldEntryError"
                        Else
                            Me.BillCountryId.CssClass = "DropDownList"
                        End If
                    End If

                End If

        End Select

        Return Me.uPage.IsValid
    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Dim hasPostalAddress As Boolean = False
        Dim hasBillingAddress As Boolean = False

        'Read all data from dataset into page fields
        If Not Me.Subscriber.GetAddressRow("Postal", "Main") Is Nothing Then
            hasPostalAddress = True
        End If
        If Not Me.Subscriber.GetAddressRow("Postal", "Billing") Is Nothing Then
            hasBillingAddress = True
        End If

        Me.uPage.PopulatePageFieldsFromDataRow(Me.Subscriber.SubscriberRow)
        Me.SubNotes.Text = Me.uPage.db.IsDBNull(Me.Subscriber.SubscriberRow("Notes"), "")
        Me.SubLastUpdatedDateTime.Text = Me.uPage.db.IsDBNull(Me.Subscriber.SubscriberRow("LastUpdatedDateTime"), "")
        Me.SubLastUpdatedByUserId.Text = Me.uPage.db.IsDBNull(Me.Subscriber.SubscriberRow("LastUpdatedByUserId"), "")

        If Not Me.Subscriber.GetAddressRow("Email", "Main") Is Nothing Then
            Me.EmailAddress.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Email").Item("AddressText"), "")
        End If

        If hasPostalAddress _
         And hasBillingAddress = False Then

            Me.uPage.PopulatePageFieldsFromDataRow(Me.Subscriber.GetAddressRow("Postal"))
            If Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("CountryId"), 0) <> 0 Then
                If CInt(Me.Subscriber.GetAddressRow("Postal").Item("CountryId")) = 11 Or CInt(Me.Subscriber.GetAddressRow("Postal").Item("CountryId")) = 56 Then 'US or Canada
                    If Me.Subscriber.GetAddressRow("Postal").Item("County").ToString.Length > 2 Then
                        Me.CountyUS.SelectedValue = ""
                    Else
                        Me.CountyUS.SelectedValue = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("County").ToString.ToUpper, "")
                    End If
                    Me.County.Text = ""
                Else
                    Me.County.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("County"), "")
                End If
            End If
            Me.BuildingStreet.Text = SetMultiLineAddress("Main")
            PopulateBillingAddressFields("Main")
            Me.PostalNotes.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("Notes"), "")
            Me.PostalLastUpdatedDateTime.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("LastUpdatedDateTime"), "")
            Me.PostalLastUpdatedByUserId.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("LastUpdatedByUserId"), "")

        ElseIf hasPostalAddress = False And hasBillingAddress Then
            Me.uPage.PopulatePageFieldsFromDataRow(Me.Subscriber.GetAddressRow("Postal", "Billing"))
            Me.BuildingStreet.Text = SetMultiLineAddress("Billing")
            PopulateBillingAddressFields("Billing")
            Me.BillingNotes.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", "Billing").Item("Notes"), "")
            Me.BillingLastUpdatedDateTime.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", "Billing").Item("LastUpdatedDateTime"), "")
            Me.BillingLastUpdatedByUserId.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", "Billing").Item("LastUpdatedByUserId"), "")
        ElseIf hasPostalAddress And hasBillingAddress Then
            Me.uPage.PopulatePageFieldsFromDataRow(Me.Subscriber.GetAddressRow("Postal"))
            If Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("CountryId"), 0) <> 0 Then
                If CInt(Me.Subscriber.GetAddressRow("Postal").Item("CountryId")) = 11 Or CInt(Me.Subscriber.GetAddressRow("Postal").Item("CountryId")) = 56 Then 'US or Canada
                    If Me.Subscriber.GetAddressRow("Postal").Item("County").ToString.Length > 2 Then
                        Me.CountyUS.SelectedValue = ""
                    Else
                        Me.CountyUS.SelectedValue = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("County").ToString.ToUpper, "")
                    End If
                    Me.County.Text = ""
                Else
                    Me.County.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("County"), "")
                End If
            End If
            Me.BuildingStreet.Text = SetMultiLineAddress("Main")
            PopulateBillingAddressFields("Billing")
            Me.BillingNotes.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", "Billing").Item("Notes"), "")
            Me.BillingLastUpdatedDateTime.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", "Billing").Item("LastUpdatedDateTime"), "")
            Me.BillingLastUpdatedByUserId.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", "Billing").Item("LastUpdatedByUserId"), "")

            Me.PostalNotes.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("Notes"), "")
            Me.PostalLastUpdatedDateTime.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("LastUpdatedDateTime"), "")
            Me.PostalLastUpdatedByUserId.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("LastUpdatedByUserId"), "")
        End If
        If Me.BuildingStreet.Text = Me.BillBuildingStreet.Text _
            And Me.Town.Text = Me.BillTown.Text _
            And Me.County.Text = Me.BillCounty.Text _
            And Me.CountyUS.Text = Me.BillCountyUS.Text _
            And Me.PostCode.Text = Me.BillPostCode.Text _
            And Me.CountryId.Text = Me.BillCountryId.Text _
            Then
            Me.AreAddressesTheSame.Checked = True
        End If
        'populate dropdowns
        Me.uPage.PopulateDropDownListFromLookup(Me.Title, "Title", uPage.db.DBConnection, "<--Select-->")

        Dim sql As String = "SELECT SubscriberAddressId Value" _
                            & "     ,LEFT( AddressDescription + ' - ' + AddressText ,30) As Text" _
                            & " FROM SubscriberAddress" _
                            & " WHERE AddressType = 'Postal'" _
                            & " AND SubscriberId = " & Me.Subscriber.SubscriberId _
                            & " ORDER BY 2"
        Me.uPage.PopulateDropDownListFromSQL(Me.DefaultPostalAddressId, sql, uPage.db.DBConnection, Nothing)

        sql = "SELECT Country.CountryId as Value" _
                            & "     ,Country.CountryName As Text" _
                            & " FROM Country" _
                            & " ORDER BY Country.CountryName"
        Me.uPage.PopulateDropDownListFromSQL(Me.PrimaryCountryId, sql, uPage.db.DBConnection, "<--Select-->")

        Me.uPage.PopulateDropDownListFromSQL(Me.CountryId, sql, uPage.db.DBConnection, "<--Select-->")
        Me.uPage.PopulateDropDownListFromLookup(Me.CountyUS, "US_CanadaStateCode", uPage.db.DBConnection, "<--Select-->")
        Me.uPage.PopulateDropDownListFromLookup(Me.BillCountyUS, "US_CanadaStateCode", uPage.db.DBConnection, "<--Select-->")

        Me.uPage.PopulateDropDownListFromSQL(Me.BillCountryId, sql, uPage.db.DBConnection, "<--Select-->")

        MergeHistoryGridViewHTML()
    End Sub

    Private Sub PopulateBillingAddressFields(ByVal AddressDescription As String)

        Me.BillBuildingStreet.Text = SetMultiLineAddress(AddressDescription)

        If Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("County"), "") <> "" Then
            Me.BillCounty.Text = Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("County")
        End If
        If Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Town"), "") <> "" Then
            Me.BillTown.Text = Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Town")
        End If
        If Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("PostCode"), "") <> "" Then
            Me.BillPostCode.Text = Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("PostCode")
        End If
        If Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("CountryId"), 0) <> 0 Then
            Me.BillCountryId.SelectedValue = CInt(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("CountryId"))

            If CInt(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("CountryId")) = 11 Or CInt(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("CountryId")) = 56 Then 'US or Canada
                If Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("County").ToString.Length > 2 Then
                    Me.BillCountyUS.SelectedValue = ""
                Else
                    Me.BillCountyUS.SelectedValue = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("County").ToString.ToUpper, "")
                End If
                Me.BillCounty.Text = ""
            Else
                Me.BillCounty.Text = Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("County"), "")
            End If
        End If
    End Sub

    Private Function SetMultiLineAddress(ByVal AddressDescription As String) As String
        Dim postalAddress As String = ""

        postalAddress += Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address1") & System.Environment.NewLine

        If Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address2"), "") <> "" Then
            postalAddress += Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address2") & System.Environment.NewLine
        End If
        If Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address3"), "") <> "" Then
            postalAddress += Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address3") & System.Environment.NewLine
        End If
        If Me.uPage.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address4"), "") <> "" Then
            postalAddress += Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address4")
        End If

        Return postalAddress
    End Function

    Sub SaveRecord()
        '******************************************************
        'Description:	Save the record either by updating
        '******************************************************
        Try
            uPage.db.BeginTran()
            Try

                Me.uPage.PopulateDataRowFromPageFields(Me.Subscriber.SubscriberRow)
                Me.Subscriber.SubscriberRow("Notes") = Me.SubNotes.Text
                'Me.Subscriber.SubscriberRow("IsReceiveMail") = Not Me.IsReceiveMail.Checked

                Select Case EntityType.Text
                    Case "Person"
                        'Change SubscriberName if FirstName or Lastname has been changed
                        If Me.uPage.db.IsDBNull(Subscriber.SubscriberRow("FirstName", DataRowVersion.Current), "") <> Me.uPage.db.IsDBNull(Subscriber.SubscriberRow("FirstName", DataRowVersion.Original), "") _
                             Or Me.uPage.db.IsDBNull(Subscriber.SubscriberRow("LastName", DataRowVersion.Current), "") <> Me.uPage.db.IsDBNull(Subscriber.SubscriberRow("LastName", DataRowVersion.Original), "") Then
                            '17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .
                            Me.Subscriber.SubscriberRow("SubscriberName") = Left(Me.LastName.Text & ", " & Me.FirstName.Text, 150)
                        End If
                End Select

                If Me.CountryId.SelectedValue <> "" AndAlso (Me.CountryId.SelectedValue = 11 Or Me.CountryId.SelectedValue = 56) Then 'US or Canada
                    Me.County.Text = Me.CountyUS.SelectedValue
                End If
                'Add update Email address
                Me.Subscriber.SaveSimpleSubscriberAddress("Email", "Main", Me.EmailAddress.Text)

                If AreAddressesTheSame.Checked Then
                    Me.BillBuildingStreet.Text = Me.BuildingStreet.Text
                    Me.BillTown.Text = Me.Town.Text
                    Me.BillCounty.Text = Me.County.Text
                    Me.BillCountyUS.Text = Me.CountyUS.Text
                    Me.BillPostCode.Text = Me.PostCode.Text
                    Me.BillCountryId.Text = Me.CountryId.Text
                End If
                'Add UpdateExistingOrdersDeliveryAddress to Sub SavePostalSubscriberAddress
                If Me.BuildingStreet.Text <> "" And Me.Town.Text <> "" Then Me.Subscriber.SavePostalSubscriberAddress("Main", Me.BuildingStreet.Text.TrimEnd, Me.Town.Text, Me.County.Text, Me.PostCode.Text, Me.CountryId.SelectedValue, Me.PostalNotes.Text, True)
                If Me.BillCountryId.SelectedValue <> "" AndAlso (Me.BillCountryId.SelectedValue = 11 Or Me.BillCountryId.SelectedValue = 56) Then 'US or Canada
                    Me.BillCounty.Text = Me.BillCountyUS.SelectedValue
                End If
                If Me.BillBuildingStreet.Text <> "" And Me.BillTown.Text <> "" Then Me.Subscriber.SavePostalSubscriberAddress("Billing", Me.BillBuildingStreet.Text.TrimEnd, Me.BillTown.Text, Me.BillCounty.Text, Me.BillPostCode.Text, Me.BillCountryId.SelectedValue, Me.BillingNotes.Text)

                'Check if subscriber DefaultPostalAddressId is populated if not populate
                If Me.uPage.db.IsDBNull(Me.Subscriber.SubscriberRow("DefaultPostalAddressId")) And Me.Subscriber.GetAddressRow("Postal") IsNot Nothing Then
                    Me.Subscriber.SubscriberRow("DefaultPostalAddressId") = Me.Subscriber.GetAddressRow("Postal")("SubscriberAddressId")
                End If

                Me.Subscriber.Save()
                Me.uPage.db.CommitTran()

            Catch ex As Exception
                uPage.db.RollbackTran()
                Throw ex
            End Try

        Catch ex As Exception
            'Show 4 lines error message to user
            'Show Building Street Address individual lines must be less than 50 characters message to user
            If ex.ToString.Contains("Building Street can only be 4 lines") Then
                Me.uPage.PageError = "Building Street can only be 4 lines"
            ElseIf ex.ToString.Contains("Building Street Address individual lines must be less than 50 characters") Then
                Me.uPage.PageError = "Building Street Address individual lines must be less than 50 characters"
            Else
                Me.uPage.PageError = "An Unexpected error has occured.  Please contact support" & ex.ToString
            End If
        End Try

        If Me.uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=Subcriber details has been saved&SubscriberId=" & Me.Subscriber.SubscriberId & "&" & Me.uPage.UserSession.QueryString)
        End If
    End Sub

    Protected Sub SaveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveBtn.Click ', AreAddressesTheSame.CheckedChanged
        Try
            If Me.IsPageValidForStatus("") Then SaveRecord()
        Catch ex As Exception
            Me.uPage.PageError = "An unexpected error has occured. Please contact support." & ex.ToString
        End Try
    End Sub

    Protected Sub BackBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        Response.Redirect("../pages/pg111SubscriberDisplay.aspx?&SubscriberId=" & Me.Subscriber.SubscriberId & "&" & Me.uPage.UserSession.QueryString)
    End Sub

    Protected Sub InActiveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles InActiveBtn.Click
        Try
            Me.Subscriber.InActivateSubscriber()
        Catch ex As Exception
            Me.uPage.PageError = "An Unexpected error has occured.  Please contact support. " & ex.Message
        End Try

        If Me.uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=Subcriber Inactivated&SubscriberId=" & Me.Subscriber.SubscriberId & "&" & Me.uPage.UserSession.QueryString)
        End If

    End Sub

    Protected Sub SetProposedBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SetProposedBtn.Click
        If IsPageValidForStatus() Then
            Me.SubscriberStatus.Text = SubscriberStates.Proposed.ToString
            Me.SaveRecord()
        End If


    End Sub

    Protected Sub RejectBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RejectBtn.Click
        Try

            Me.Subscriber.RejectSubscriber()
        Catch ex As Exception
            Me.uPage.PageError = "An Unexpected error has occured.  Please contact support. " & ex.Message
        End Try

        If Me.uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=Subcriber Rejected&SubscriberId=" & Me.Subscriber.SubscriberId & "&" & Me.uPage.UserSession.QueryString)
        End If
    End Sub

    Protected Sub MergeBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MergeBtn.Click
        Try
            Me.Subscriber.MergeSubscriber(Me.Subscriber.SubscriberRow("UpdateToSubscriberId"), Me.Subscriber.SubscriberId, Me.SendConfimation.Checked)
        Catch ex As Exception
            Me.uPage.PageError = "An Unexpected error has occured.  Please contact support. " & ex.Message
        End Try

        If Me.uPage.IsValid Then
            Response.Redirect("../pages/pg111SubscriberDisplay.aspx?InfoMsg=Subcriber:" & Me.Subscriber.SubscriberId & " sucessfully merged into this Subscriber&SubscriberId=" & Me.Subscriber.SubscriberRow("UpdateToSubscriberId") & "&" & Me.uPage.UserSession.QueryString)
        End If
    End Sub
    Private Sub AcceptAsNewBtn_Click(sender As Object, e As EventArgs) Handles AcceptAsNewBtn.Click
        If IsPageValidForStatus() Then
            Me.SubscriberStatus.Text = SubscriberStates.Current.ToString
            Me.SaveRecord()
        End If

    End Sub
    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.Subscriber.MainDataset
        Me.PageSetup()
    End Sub

    Sub BuildPotentialDuplicatesGridViewHTML()
        Dim strHtml As String = Nothing
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""

            Sql = "Select TOP 20 SubscriberId " & sCR
            Sql += "	, SubscriberName " & sCR
            Sql += "    , CountryName " & sCR
            Sql += " FROM Subscriber" & sCR
            Sql += "    LEFT JOIN Country" & sCR
            Sql += "    ON Country.CountryId = Subscriber.PrimaryCountryId" & sCR
            Sql += " WHERE Subscriber.SubscriberId <> " & Me.Subscriber.SubscriberId & sCR
            Sql += " And SubscriberStatus IN ('Current','Proposed')" & sCR

            Select Case Me.EntityType.Text
                Case "Organisation"
                    Sql += " AND Subscriber.SubscriberName Like '%" & Me.DupCheckSubscriberName.Text.Replace("'", " ") & "%'" & sCR
                    Sql += " AND EntityType = 'Organisation' " & sCR
                Case "Person"
                    Sql += " AND Subscriber.LastName Like '" & Me.DupCheckSubscriberName.Text.Replace("'", " ") & "%'" & sCR
                    Sql += " AND EntityType = 'Person' " & sCR
            End Select
            If Me.PrimaryCountryId.SelectedValue <> "" Then
                Sql += " AND Country.CountryName = '" & Me.PrimaryCountryId.SelectedItem.Text & "'"
            End If
            Sql += " ORDER BY SubscriberName"

            Dim tblMerge As DataTable = uPage.db.GetDataTableFromSQL(Sql)
            If tblMerge.Rows.Count <> 0 Then
                For Each row As DataRow In tblMerge.Rows
                    strHtml += "    <tr>"
                    strHtml += "        <td><a href=""../pages/pg113SubscriberIsolatedAction.aspx?" _
                                                & "MergeIntoSubscriberId=" & row("SubscriberId") _
                                                & "&Action=Merge" _
                                                & "&MergeFromSubscriberId=" & Me.Subscriber.SubscriberId _
                                                & "&" & Me.uPage.UserSession.QueryString _
                                                & """ Title='Merge'>" & sCR
                    strHtml += "                <span class=""fldLink"">Merge</span>" & sCR
                    strHtml += "              </a></td>" & sCR
                    strHtml += "    <td><a href='../pages/pg111SubscriberDisplay.aspx" _
                                                & "?SubscriberId=" & row("SubscriberId") _
                                                & "&" & Me.uPage.UserSession.QueryString _
                                                & "' title='Maintain Subscriber'>" & sCR
                    strHtml += "                <span class=""fldLink"">" & row("SubscriberId") & "</span>" & sCR
                    strHtml += "              </a></td>" & sCR
                    strHtml += "        <td Class=""fldView"">" & row("SubscriberName") & "</td>"
                    strHtml += "        <td Class=""fldView"">" & row("CountryName") & "</td>"

                    strHtml += "    </tr>"
                Next
                Me.PotentialDuplicatesGridview.Text = strHtml
            End If
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Sub MergeHistoryGridViewHTML()
        Dim strHtml As String = Nothing
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""

            Sql = "SELECT AuditDate " & sCR
            Sql += "	,UpdatedByUserName " & sCR
            Sql += "    ,ModificationType " & sCR
            Sql += "    ,Description " & sCR
            Sql += " FROM AuditLog" & sCR
            Sql += " WHERE UpdatedRecordKey = '" & Me.txtSubscriberId.Value & "'" & sCR
            Sql += " AND ModificationType Like 'Merge%'" & sCR
            Sql += " AND DatabaseName = '" & uPage.DatabaseName & "'" & sCR
            Sql += " ORDER BY AuditDate"

            Dim tblMerge As DataTable = uPage.db.GetDataTableFromSQL(Sql)
            If tblMerge.Rows.Count <> 0 Then
                For Each row As DataRow In tblMerge.Rows
                    strHtml += "    <tr>"
                    strHtml += "        <td Class=""fldView"">" & row.Item("AuditDate") & "</td>"
                    strHtml += "        <td Class=""fldView"">" & row.Item("UpdatedByUserName") & "</td>"
                    strHtml += "        <td Class=""fldView"">" & row.Item("ModificationType") & "</td>"
                    strHtml += "    </tr>"
                    strHtml += "    <tr>"
                    strHtml += "        <td class=""fldView"" colspan=""3"">" & row.Item("Description").ToString.Replace(vbCrLf, "<BR>") & "</td>"
                    strHtml += "    </tr>"
                Next
                Me.MergeHistoryGridGridView.Text = strHtml
                Me.MergeHistoryDiv.Visible = True
            Else
                Me.MergeHistoryDiv.Visible = False
            End If
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try

    End Sub


End Class
