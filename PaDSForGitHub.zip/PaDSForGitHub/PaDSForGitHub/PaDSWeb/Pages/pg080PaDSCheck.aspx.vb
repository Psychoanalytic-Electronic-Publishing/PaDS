Imports System.Data
Imports System.Data.SqlClient

'Modification History
'10/11/15   Julian Gates    Change Dropbox file check delete to be 20mins
'03/10/16   Julian Gates    Dropbox synch check removed as dropbox not used very often now and check is causing problems.
'17/02/21   Julian Gates    SIR5166 - Removed PEP Product Service check

Partial Class pg080PaDSCheck
    Inherits System.Web.UI.Page
    '  Public uPage As UserPage
    Dim ErrorFound As Boolean = False

    Public IsDatabaseServerPrimaryOrSecondary As String = "Unknown"
    Public IsReadOnlyOnSecondary As Boolean = False
    Public ReadOnly Property IsWebServerPrimaryOrSecondary() As String
        Get
            Return System.Configuration.ConfigurationManager.AppSettings("IsPrimaryOrSeconday")
        End Get
    End Property
    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            If Me._db Is Nothing Then
                Dim FailOver As New BusinessLogic.Failover()
                Me._db = New BusinessLogic.Database(FailOver.ChooseConnectionString(
                                                    System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringPrimary").ToString _
                                                    , System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringSecondary").ToString _
                                                    , System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringSecurityOnSecondary").ToString _
                                                    , "ASP.NET - PaDSCheck.vb - " _
                                                    , Me.IsWebServerPrimaryOrSecondary
                                                    ))
                Me.IsDatabaseServerPrimaryOrSecondary = FailOver.IsDatabaseServerPrimaryOrSecondary
                Me.IsReadOnlyOnSecondary = FailOver.IsReadOnlyOnSecondary
            End If
            Return (Me._db)
        End Get


        Set(ByVal value As BusinessLogic.Database)
            Me._db = value
        End Set
    End Property

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Function GetTableLine(ByVal Prompt As String, ByVal Message As String, Optional ByVal IsError As Boolean = False, Optional ByVal IsTitle As Boolean = False) As String
        Dim h As String = ""
        h = "<tr"
        If IsError Then
            h += " bgcolor=""#FF99FF"""
        End If
        If IsTitle Then
            h += " bgcolor=""#99CCFF"""
        End If
        h += ">"
        h += System.Environment.NewLine
        h += "<td width=""230"""
        If IsTitle Then
            h += " colspan=""2"" align=""center"""
        End If
        h += ">"
        If IsTitle Then
            h += "<strong><BR>"
        End If
        h += Prompt
        If IsTitle Then
            h += "</strong>"
        End If
        h += "</td>"
        h += System.Environment.NewLine
        If Not IsTitle Then
            h += "<td>" & Message & "</td>"
        End If
        h += "</tr>"
        h += System.Environment.NewLine
        If IsError Then
            ErrorFound = True
        End If
        Return h
    End Function

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim html As String = ""
        Try
            'Put user code to initialize the page here
            '      uPage = New UserPage


            Dim sql As String

            html += "PaDS Consistancy Checks" & "<BR>"
            html += System.Environment.NewLine
            html += "======================" & "<BR>"
            html += System.Environment.NewLine
            html += "<Table boder=1>"
            html += System.Environment.NewLine
            If Not Me.Request.QueryString.Item("SendEmail") = Nothing Then
                html += GetTableLine("QueryString='SendEmail' ", Me.Request.QueryString.Item("SendEmail"), False)
            Else
                html += GetTableLine("QueryString='SendEmail' ", "Not Set - Values 'Yes','No'", True)
            End If
            If Not Me.Request.QueryString.Item("ErrorType") = Nothing Then
                html += GetTableLine("QueryString='ErrorType' ", Me.Request.QueryString.Item("ErrorType"), False)
            Else
                html += GetTableLine("QueryString='ErrorType' ", "Not Set - Values 'ASPERROR','INVALIDPAGE'", True)
            End If

            Try

                '03/12/15   Julian Gates    Add LookupStatus to Lookup criteria
                Dim tbl As DataTable = db.GetDataTableFromSQL("Select * from Lookup WHERE LookupStatus = 'Active'")

                html += GetTableLine("Server Date/Time: ", Now.ToString)
                html += GetTableLine("Running On: ", Me.Request.ServerVariables("SERVER_NAME"))
                html += GetTableLine("IP: ", New BusinessLogic.StdCode().GetIPAddress(HttpContext.Current.Request))
                html += GetTableLine("Page running on:", System.Configuration.ConfigurationManager.AppSettings("IsPrimaryOrSeconday"))
                html += GetTableLine("Database running on:", Me.IsDatabaseServerPrimaryOrSecondary, Me.IsDatabaseServerPrimaryOrSecondary <> "Primary")
                If Me.IsDatabaseServerPrimaryOrSecondary <> "Primary" Then
                    html += GetTableLine("Failover Parameters", "", False, True)
                    Try
                        html += GetTableLine("FailoverStartedFailingAtDateTime:", db.GetParameterValue("FailoverStartedFailingAtDateTime"), CDate(db.GetParameterValue("FailoverStartedFailingAtDateTime")) <> CDate("31-dec-4949"))
                    Catch ex As Exception
                    End Try
                    Try
                        html += GetTableLine("FailoverThisIsMasterServerDesc:", db.GetParameterValue("FailoverThisIsMasterServerDesc"))
                    Catch ex As Exception
                    End Try
                    Try
                        html += GetTableLine("FailoverThisIsMasterServer:", db.GetParameterValue("FailoverThisIsMasterServer"), CBool(db.GetParameterValue("FailoverThisIsMasterServer")))
                    Catch ex As Exception
                    End Try
                End If
                Dim CheckSection As String = Nothing
                '****************************************************************************************************************************************************************************************
                '****************************************************************************************************************************************************************************************
                CheckSection = "Live Server Identification Check"
                html += GetTableLine(CheckSection, "", False, True)
                Dim primDB As BusinessLogic.Database
                Dim secDB As BusinessLogic.Database
                Try
                    Try
                        primDB = New BusinessLogic.Database(System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringPrimary").ToString)
                    Catch ex As Exception
                        Throw New Exception("Primary DB logon failed:" & ex.Message)
                    End Try
                    '21/2/21    James       If CopyPaDSDatabaseToSecondary is running and started in last 15mins then restore of PaDS DB might bee locking secondary so skip check.
                    Dim skipSecondaryDBChecksAsDBPossiblyRestoring As Boolean = 0 < CInt(db.DLookup("COUNT(*)", "BatchJob", "BatchJobName = 'CopyPaDSDatabaseToSecondary' AND BatchJobStatus='Started' AND ActualStartDateTime > DATEADD(MINUTE,-15,GETDATE())"))
                    Try
                        secDB = New BusinessLogic.Database(System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringSecondary").ToString)
                        html += GetTableLine("Secondary DB Check", "OK", False)
                    Catch ex As Exception
                        If skipSecondaryDBChecksAsDBPossiblyRestoring Then
                            html += GetTableLine("Secondary DB Check", "skipSecondaryDBChecksAsDBPossiblyRestoring=" & skipSecondaryDBChecksAsDBPossiblyRestoring, False, False)
                        Else
                            html += GetTableLine("Secondary DB Check", "Failed:" & ex.Message, True)
                        End If
                    End Try

                    '22/8/16    James Woosnam   This shoudl only run on the live server so if not live server error
                    '                           This is to catch an issue where the serverer is stopped and restarted thereby changing the internal IP address.
                    html += GetTableLine("primDB.IsOnLiveServer", primDB.IsOnLiveServer, Not primDB.IsOnLiveServer, False)

                    If Not primDB.IsOnLiveServer Then
                        html += GetTableLine("PrimDB not on live", "Could be triggering because the server instance has been stopped and restarted and the internal IP address need to be updated in stblParameters (LiveIPAddresses)", Not primDB.IsOnLiveServer, False)
                    End If
                    '22/2/21     James Woosnam   Don't need to run IsOnLiveServer on secondary DB as does same as on primary, just picks up parameter LiveIPAddresses from secondary which might fail as DB restoring

                Catch ex As Exception
                    html += GetTableLine(CheckSection, "Failed:" & ex.Message, True)
                End Try
                '****************************************************************************************************************************************************************************************
                '****************************************************************************************************************************************************************************************
                '12/3/13    James Woosnam   Add a check for the database backup
                CheckSection = "Check Database Backup and Copy to Secondary"
                html += GetTableLine(CheckSection, "", False, True)
                Try
                    Dim SecondaryDatabaseBackupDirectory As New IO.DirectoryInfo(db.GetParameterValue("SecondaryDatabaseBackupDirectory"))
                    If Not SecondaryDatabaseBackupDirectory.Exists Then
                        '1/11/18    Julian Gates   Make Database last Backup check report as an error by adding True
                        html += GetTableLine("Database last Backup", "Directory not found:" & SecondaryDatabaseBackupDirectory.FullName, True)
                        Exit Try
                    End If
                    Dim lastDBBackup As Date = Nothing
                    For Each fl As IO.FileInfo In SecondaryDatabaseBackupDirectory.GetFiles("*.bak")
                        If fl.LastWriteTime > lastDBBackup Then
                            lastDBBackup = fl.LastWriteTime
                        End If
                    Next
                    If lastDBBackup > Now.AddHours(-1) Then
                        html += GetTableLine("Database last Backup", lastDBBackup.ToString)
                    Else
                        html += GetTableLine("Database last Backup", "Failed: " & lastDBBackup.ToString, True)
                    End If

                    Try
                        sql = "SELECT  * "
                        sql += " FROM BatchJob "
                        sql += " WHERE ActualStartDateTime > DATEADD(DAY, -1, GETDATE()) "
                        sql += " And BatchJobName = 'CopyPaDSDatabaseToSecondary' "
                        sql += " And BatchJobStatus = 'Completed' "
                        sql += " ORDER BY BatchJobId desc "
                        Dim tblJobs As DataTable = db.GetDataTableFromSQL(sql)
                        Select Case tblJobs.Rows.Count
                            Case 0
                                html += GetTableLine("Completed Copy DB Jobs in last day", "Failed (None Found) ", True)
                            Case Else
                                Dim jobCount As Integer = 0
                                For Each row As DataRow In tblJobs.Rows
                                    If CDate(row("EndDateTime")) > Now.AddMinutes(-65) Then
                                        jobCount += 1
                                    End If
                                Next
                                Select Case jobCount
                                    Case 0
                                        html += GetTableLine("Completed Copy DB Jobs in last hour", "Failed (None Found) ", True)
                                    Case 1
                                        html += GetTableLine("Completed Copy DB Jobs in last hour", "1 Warning:" & CDate(tblJobs.Rows(0)("EndDateTime")).ToString, False)
                                    Case Else
                                        html += GetTableLine("Completed Copy DB Jobs in last hour", "2 OK:" & CDate(tblJobs.Rows(0)("EndDateTime")).ToString, False)
                                End Select
                        End Select
                    Catch ex As Exception
                        html += GetTableLine("Completed Copy DB Jobs", "Failed: " & ex.Message, True)
                    End Try
                Catch ex As Exception
                    html += GetTableLine(CheckSection, "Failed: " & ex.Message, True)
                End Try


                '****************************************************************************************************************************************************************************************
                '****************************************************************************************************************************************************************************************
                CheckSection = "PEP Service"
                html += GetTableLine(CheckSection, "", False, True)
                Try
                    System.Net.ServicePointManager.Expect100Continue = False

                    Dim GatewayId As Integer = Nothing
                    Dim ProductCode As String = Nothing
                    Dim PEPProd As Object = Nothing
                    '   Throw New Exception("Need to Reference PEPProduct")
                    PEPProd = New PaDSLive.PEPProduct

                    Dim message As String = ""
                    PEPProd.AuthenticateUser("ZedraCheck", "", ProductCode, GatewayId, message)
                    If message <> "No Password passed" Then
                        html += GetTableLine("PEP Product Service", "Unexpected Message:" & message, True)
                    Else
                        html += GetTableLine("PEP Product Service", "OK")

                    End If
                Catch ex As Exception
                    html += GetTableLine(CheckSection, "Failed:" & ex.Message, True)
                End Try


                '****************************************************************************************************************************************************************************************
                '****************************************************************************************************************************************************************************************
                CheckSection = "PEP Renewal Emails"
                html += GetTableLine(CheckSection, "", False, True)
                Try
                    'check renewal emails
                    sql = "SELECT FirstEmails = (SELECT Count(*) FROM RenewalReminderLog WHERE FirstReminderSentDate BETWEEN DATEADD(D,-1,GETDATE()) AND GETDATE())"
                    sql += "    ,SecondEmails = (SELECT Count(*) FROM RenewalReminderLog WHERE SecondReminderSentDate BETWEEN DATEADD(D,-1,GETDATE()) AND GETDATE())"
                    sql += "    ,Batchlogs = (SELECT Count(*) FROM BatchLog WHERE BatchLogType = 'SendRenewalEmail' AND BatchLogStatus = 'Complete' AND DateTime BETWEEN DATEADD(D,-3,GETDATE()) AND GETDATE())"
                    Dim row As DataRow = primDB.GetDataTableFromSQL(sql).Rows(0)
                    html += GetTableLine("First emails in last day", row("FirstEmails"), False, False)
                    html += GetTableLine("Second emails in last day", row("SecondEmails"), False, False)
                    If primDB.IsDBNull(row("BatchLogs"), 0) = 0 Then
                        html += GetTableLine("Renewal Batch Job", "This has not run in the last 3 days", True, False)
                    Else
                        html += GetTableLine("Renewal Batch Jobs in last 3 days", row("Batchlogs"), False, False)
                    End If
                Catch ex As Exception
                    html += GetTableLine(CheckSection, "Failed:" & ex.Message, True)
                End Try






                '****************************************************************************************************************************************************************************************
                '****************************************************************************************************************************************************************************************
                CheckSection = "Other Components"
                html += GetTableLine(CheckSection, "", False, True)
                Dim CheckResult As String = ""
                CheckResult = CheckPagePageForText(db.GetParameterValue("PaDSFederatedPortalURL"), "Federated")
                html += GetTableLine("Federated Portal ", CheckResult, CheckResult <> "OK", False)
                'CheckResult = CheckPagePageForText(db.GetParameterValue("PEPWeb2021URL"), "Psychoanalytic Electronic Publishing")
                'html += GetTableLine("PEPweb Client ", CheckResult, CheckResult <> "OK", False) 'might remove this??

                CheckResult = CheckAPI(db.GetParameterValue("PaDSPEPSecureAPIURL", "https://localhost:44385/") & "api/Authenticate/ip", """HasSubscription"":false")
                html += GetTableLine("PEPSecure Authenticate/ip ", CheckResult, CheckResult <> "OK", False) 'might remove this??

                CheckResult = CheckAPI(db.GetParameterValue("PaDSPEPSecureAPIURL") & "api/Configuration", """PaDSPasswordResetURL")
                html += GetTableLine("PEPSecure Configuration ", CheckResult, CheckResult <> "OK", False) 'might remove this??


            Catch ex As Exception
                html += GetTableLine("Database not available: ", ex.Message, True)
            End Try


        Catch ex As Exception
            html += GetTableLine("Page Error Found ", "", True, True)
            html += GetTableLine("Error", ex.ToString, True, True)

            ErrorFound = True


        Finally
            If ErrorFound Then
                html += GetTableLine("***Error Found******", "", False, True)
                html += GetTableLine("Error Status ", "PaDSCheckErrorFound", True)
                Try
                    If Not Me.Request.QueryString.Item("SendEmail") = Nothing Then
                        html += GetTableLine("QueryString='SendEmail' ", Me.Request.QueryString.Item("SendEmail"), False)
                        If Me.Request.QueryString.Item("SendEmail").ToUpper = "YES" Then
                            Dim ChecksEmailLastSentDateTime As Date = Nothing
                            Try
                                ChecksEmailLastSentDateTime = CDate(db.GetParameterValue("ChecksEmailLastSentDateTime"))
                            Catch ex As Exception
                                ChecksEmailLastSentDateTime = Now.AddHours(-3) ' set 3 hours in past so always triggers
                            End Try
                            If Now.AddHours(-1) > ChecksEmailLastSentDateTime Then
                                Me.SendSupportMail("PaDS Check Error", html)
                                html += GetTableLine("Email ", "Sent", False)
                                db.SetParameterValue("ChecksEmailLastSentDateTime", Now().ToString("dd-MMM-yyyy HH:mm:ss"))
                            Else
                                html += GetTableLine("Email ", "Not Sent as less than 1 hour since last", False)
                            End If

                        End If
                    Else
                        html += GetTableLine("QueryString='SendEmail' ", "Not Set - Values 'Yes','No'", True)
                    End If
                Catch ex As Exception

                End Try
                If Not Me.Request.QueryString.Item("ErrorType") = Nothing Then
                    html += GetTableLine("QueryString='ErrorType' ", Me.Request.QueryString.Item("ErrorType"), False)
                    Select Case Me.Request.QueryString.Item("ErrorType").ToUpper
                        Case "ASPERROR"
                            Throw New Exception(Me.PageMessage.Text)
                        Case "INVALIDPAGE"
                            Response.Redirect("http://ERROR?")
                        Case Else

                    End Select
                Else
                    html += GetTableLine("QueryString='ErrorType' ", "Not Set - Values 'ASPERROR','INVALIDPAGE'", True)
                End If
            End If
        End Try


        Me.PageMessage.Text = html


    End Sub
    Private Function CheckPagePageForText(CheckURL As String, SearchPageForText As String) As String
        Try
            Dim webReq As System.Net.HttpWebRequest
            Dim WebPageText As System.Net.WebResponse
            Dim WebPageSource As System.IO.Stream
            Dim WebPageSourceText As System.IO.StreamReader


            webReq = System.Net.WebRequest.Create(CheckURL)
            'webReq.Proxy = System.Net.WebProxy.GetDefaultProxy
            'webGetDefaultProxy()
            webReq.Proxy.Credentials = System.Net.CredentialCache.DefaultCredentials
            webReq.UseDefaultCredentials = True
            webReq.ImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Delegation
            webReq.PreAuthenticate = True
            webReq.KeepAlive = True
            webReq.AuthenticationLevel = System.Net.Security.AuthenticationLevel.MutualAuthRequested And System.Net.Security.AuthenticationLevel.MutualAuthRequired
            WebPageText = webReq.GetResponse()
            WebPageSource = WebPageText.GetResponseStream

            WebPageSourceText = New System.IO.StreamReader(WebPageSource, System.Text.Encoding.ASCII)
            Dim pageText As String = WebPageSourceText.ReadToEnd()
            If Not pageText.Contains(SearchPageForText) Then
                Return "URL:" & CheckURL & " does not contain text '" & SearchPageForText & "'" & System.Environment.NewLine & pageText
            End If
            WebPageSourceText.Close()
            WebPageSource.Close()
        Catch ex As Exception
            Return "CheckPagePageForText for:" & CheckURL & " failed:" & ex.Message
        End Try
        Return "OK"

    End Function
    Public Function CheckAPI(URLQuery As String, SearchReturnForText As String) As String
        Try
            Dim webReq As System.Net.HttpWebRequest
            Dim response As System.Net.HttpWebResponse = Nothing
            Dim reader As IO.StreamReader
            webReq = System.Net.WebRequest.Create(URLQuery)
            webReq.UserAgent = "PaDS"
            webReq.Method = "GET"
            webReq.Headers("client-id") = db.GetParameterValue("PaDSClientIdForOPAS", 3)

            response = webReq.GetResponse()
            reader = New IO.StreamReader(response.GetResponseStream())
            Dim rawresp As String
            rawresp = reader.ReadToEnd()
            If Not rawresp.Contains(SearchReturnForText) Then
                Return "Doesn't contain:'" & SearchReturnForText & "' Does contain:" & rawresp
            End If
            Return "OK"
        Catch ex As Exception
            Throw New Exception("CheckAPI Failed:" & ex.Message & " URL:" & URLQuery, ex)
        End Try
    End Function
    Function GetLastUpdatedHTML(ByVal TableName As String, ByVal primDB As BusinessLogic.Database, ByVal secDB As BusinessLogic.Database) As String
        Dim sql As String = ""
        Dim html As String = ""
        html += GetTableLine(TableName, "", False, True)
        Dim doCheck As Boolean = True

        Dim tblPrim As DataTable = Nothing
        Dim tblSec As DataTable = Nothing
        sql = "SELECT LastUpdatedDateTime = MAX(LastUpdatedDateTime)"
        sql += " FROM " & TableName
        sql += " WHERE LastUpdatedDateTime <= DATEADD(HOUR,-1,GETDATE())"
        Try
            tblPrim = primDB.GetDataTableFromSQL(sql)
        Catch ex As Exception
            html += GetTableLine("Primary " & TableName, "Failed:" & ex.ToString, True)
            doCheck = False
        End Try
        Try
            tblSec = secDB.GetDataTableFromSQL(sql)
        Catch ex As Exception
            html += GetTableLine("Secondary  " & TableName, "Failed:" & ex.ToString, True)
            doCheck = False

        End Try
        If doCheck Then
            If CDate(tblPrim.Rows(0)(0)).AddHours(-1) > CDate(tblSec.Rows(0)(0)) _
             Or CDate(tblSec.Rows(0)(0)).AddHours(-1) > CDate(tblPrim.Rows(0)(0)) Then
                html += GetTableLine(TableName, "NOT replicating correctly. More than 1 order apart", True)
            Else
            End If
            html += GetTableLine("Last Primary", CDate(tblPrim.Rows(0)(0)).ToString)
            html += GetTableLine("Last Secondary", CDate(tblSec.Rows(0)(0)).ToString)
        End If
        Return html
    End Function

    Sub SendSupportMail(ByVal strSubject As String, ByVal strMessage As String)
        Try
            Dim email As New BusinessLogic.Email(Me.db)
            email.IsBodyHTML = True
            email.SendErrorEmail(strSubject, strMessage)

        Catch ex As Exception
            Throw New Exception(strMessage & "<BR>" & "Email Failed:" & "<BR>" & ex.ToString)
        End Try
    End Sub

    'Public Function GetParam(ByVal strParam, ByVal strConn)
    '    Dim myConn As New SqlClient.SqlConnection(strConn)
    '    Dim result As Object
    '    'Dim cmd As SqlCommand = myConn.CreateCommand()

    '    Try
    '        myConn.Open()

    '        Dim scalarCommand As New SqlClient.SqlCommand("SELECT ParameterValue " + _
    '                                            "FROM stblParameters " + _
    '                                            "WHERE ParameterName = '" + strParam + "'" _
    '                                            , myConn)

    '        result = scalarCommand.ExecuteScalar()

    '        myConn.Close()
    '    Catch ex As SqlClient.SqlException
    '    End Try

    '    Return result
    'End Function
End Class
