﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.Subscriber
Imports DevExpress.Web

'Modification History
'17/04/20  Julian Gates   Initial New version

Partial Class Pages_pg131SubscriberAffiliateMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Enum PageModes
        Add
        Update
    End Enum
    ReadOnly Property PageMode As PageModes
        Get
            Return ViewState("PageMode")
        End Get
    End Property
    Private _ParentSubscriber As BusinessLogic.Subscriber = Nothing
    Public Property ParentSubscriber() As BusinessLogic.Subscriber
        Get
            If Me._ParentSubscriber Is Nothing Then
                If ViewState("ParentSubscriberId") IsNot Nothing Then
                    _ParentSubscriber = New BusinessLogic.Subscriber(ViewState("ParentSubscriberId"), Me.uPage.db, Me.uPage.UserSession)
                End If
            End If
            Return Me._ParentSubscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._ParentSubscriber = value
        End Set
    End Property
    Private _ChildSubscriber As BusinessLogic.Subscriber = Nothing
    Public Property ChildSubscriber() As BusinessLogic.Subscriber
        Get
            If Me._ChildSubscriber Is Nothing Then
                If ViewState("ChildSubscriberId") IsNot Nothing Then
                    _ChildSubscriber = New BusinessLogic.Subscriber(ViewState("ChildSubscriberId"), Me.uPage.db, Me.uPage.UserSession)
                End If
            End If
            Return Me._ChildSubscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._ChildSubscriber = value
        End Set
    End Property
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Add  ", "")
        Try
            If Page.IsPostBack Then
            Else
                If Request.QueryString("ParentSubscriberId") <> "" Then
                    Try
                        ViewState("ParentSubscriberId") = CInt(Request.QueryString("ParentSubscriberId"))
                        ViewState("PageMode") = PageModes.Add
                    Catch ex As Exception
                        Me.uPage.PageError = "Invalid Parameter has been passed in"
                    End Try
                End If
                If Request.QueryString("ChildSubscriberId") <> "" Then
                    Try
                        If Request.QueryString("ParentSubscriberId") = "" Then
                            Me.uPage.PageError = "If ChildSubscriberId is passed, ParentSubscriberId must also be passed"
                            Exit Sub
                        End If
                        ViewState("ChildSubscriberId") = CInt(Request.QueryString("ChildSubscriberId"))
                        ViewState("PageMode") = PageModes.Update
                    Catch ex As Exception
                        Me.uPage.PageError = "Invalid Parameter has been passed in"
                    End Try
                End If
                If Me.uPage.IsValid And PageMode = PageModes.Update Then
                    ReadRecord()
                End If
                Me.ChildSubscriberNameSearch.Focus()
            End If
        Catch ex As Exception
            uPage.PageError = "An unexpected error has occured.  Please contact support." & ex.ToString
        End Try

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        PotentialAffiliatesGridSetup()

    End Sub

    Sub PageSetup()
        Select Case Me.PageMode

            Case PageModes.Add
                Me.AddModeFields.Visible = True
                Me.UpdateModeFields.Visible = False
                uPage.pageTitle = "Add New Subscriber Affiliation to SID:" & Me.ParentSubscriber.SubscriberId & " - " & Me.ParentSubscriber.SubscriberName
                Me.AddModeParentSubscriberNameLink.Text = Me.ParentSubscriber.SubscriberName & " (" & Me.ParentSubscriber.SubscriberId & ")"
                Me.AddModeParentSubscriberNameLink.NavigateUrl = "pg111SubscriberDisplay.aspx?SubscriberId=" & Me.ParentSubscriber.SubscriberId & "&" & uPage.UserSession.QueryString

                If Me.ChildSubscriberNameSearch.Text <> "" Then
                    PotentialAffiliatesGridViewRow.Visible = True
                Else
                    PotentialAffiliatesGridViewRow.Visible = False
                End If
                Me.AddedAffiliatesTableDiv.Visible = AddedAffiliates.Text <> ""
            Case PageModes.Update
                uPage.pageTitle = "Affiliate Maint Parent:" & Me.ParentSubscriber.SubscriberId & " Child:" & Me.ChildSubscriber.SubscriberId
                Me.AddModeFields.Visible = False
                Me.UpdateModeFields.Visible = True
                Me.SubscriberCategoryRow.Visible = Me.ParentSubscriber.IsCompanyGroupParentSubscriber
        End Select
        Me.pageHeaderTitle.Text = uPage.pageTitle
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        Me.uPage.PopulatePageFieldsFromDataRow(Me.ChildSubscriber.ParentAffiliateRow(Me.ParentSubscriber.SubscriberId))
        Me.ParentSubscriberName.Text = Me.ParentSubscriber.SubscriberName & " (" & Me.ParentSubscriber.SubscriberId & ")"
        Me.ParentSubscriberName.NavigateUrl = "pg111SubscriberDisplay.aspx?SubscriberId=" & Me.ParentSubscriber.SubscriberId & "&" & uPage.UserSession.QueryString

        Me.ChildSubscriberName.Text = Me.ChildSubscriber.SubscriberName & " (" & Me.ChildSubscriber.SubscriberId & ")"
        Me.ChildSubscriberName.NavigateUrl = "pg111SubscriberDisplay.aspx?SubscriberId=" & Me.ChildSubscriber.SubscriberId & "&" & uPage.UserSession.QueryString

        Dim sql As String = "SELECT Distinct LookupItemKey as Value" _
                                & ", Name As Text" _
                                & " FROM Lookup" _
                                & " WHERE LookupName = 'SubscriberCategory'" _
                                & " AND LookupStatus = 'Active'" _
                                & " ORDER BY Name,LookupItemKey"
        Me.uPage.PopulateDropDownListFromSQL(Me.SubscriberCategory, sql, uPage.db.DBConnection, "<--Select-->")
    End Sub

    Sub PotentialAffiliatesGridSetup()
        Dim sCR As String = System.Environment.NewLine
        Dim Sql As String = ""
        Try
            If Me.ChildSubscriberNameSearch.Text = "" Then Exit Sub
            Sql = "Select DISTINCT Subscriber.SubscriberId " & sCR
            Sql += "		,Subscriber.SubscriberName " & sCR
            Sql += "		,c.CountryName " & sCR
            Sql += " FROM " & uPage.SubscriberTable("Subscriber") & sCR
            Sql += "		INNER JOIN Country c" & sCR
            Sql += "		ON c.CountryId = Subscriber.PrimaryCountryId" & sCR
            Sql += " WHERE SubscriberStatus IN ('Current','Proposed')" & sCR
            Sql += " AND Subscriber.SubscriberName Like '%" & Me.ChildSubscriberNameSearch.Text & "%'" & sCR
            Sql += " AND Subscriber.SubscriberId NOT IN (SELECT ChildSubscriberId FROM SubscriberAffiliate WHERE ParentSubscriberId=" & Me.ParentSubscriber.SubscriberId & ")" & sCR
            Sql += " ORDER BY SubscriberName" & sCR

            Me.PotentialAffiliatesDatasource.SelectCommand = Sql
            Me.PotentialAffiliatesDatasource.DataBind()
            Me.PotentialAffiliatesGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Protected Sub grid_CustomButtonCallback(ByVal sender As Object, ByVal e As ASPxGridViewCustomButtonCallbackEventArgs)
        Dim fileImportLogId As Integer = Nothing
        If e.ButtonID <> "AddThisSubAsNewAffiliate" Then
            Return
        End If
        Try
            Dim childSub As New BusinessLogic.Subscriber(PotentialAffiliatesGridView.GetRowValues(e.VisibleIndex, "SubscriberId"), uPage.db, uPage.UserSession)
            childSub.AddSubscriberAffiliate(Me.ParentSubscriber.SubscriberId)
            Me.AddedAffiliates.Text += "<br><a href='../Pages/pg111SubscriberDisplay.aspx?SubscriberId=" & childSub.SubscriberId & "&" & uPage.UserSession.QueryString & "' target=""_blank""  title=""View Subscriber"">" & childSub.SubscriberName & " (" & childSub.SubscriberId & ")</a>"

        Catch ex As Exception
            uPage.PageError = "Add new affiliate failed" & ex.ToString
        End Try
        Me.PageSetup()
    End Sub

    Protected Sub BackBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackBtn.Click, BackBtn1.Click
        Response.Redirect("../pages/pg130SubscriberAffiliateSelect.aspx?SubscriberId=" & Me.ParentSubscriber.SubscriberId & "&" & Me.uPage.UserSession.QueryString)
    End Sub

    Protected Sub ResetBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ResetBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?ParentSubscriberId=" & Me.ParentSubscriber.SubscriberId & "&ChildSubscriberId=" & Me.ChildSubscriber.SubscriberId & "&" & Me.uPage.UserSession.QueryString)
    End Sub

    Protected Sub AddAffiliateBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AddAffiliateBtn.Click
        Response.Redirect("../pages/pg131SubscriberAffiliateMaint.aspx?ParentSubscriberId=" & Me.ParentSubscriber.SubscriberId & "&" & Me.uPage.UserSession.QueryString)
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
    End Sub

    Private Sub SearchBtn_Click(sender As Object, e As EventArgs) Handles SearchBtn.Click
        uPage.FieldValidateMandatory(Me.ChildSubscriberNameSearch)
        Me.PotentialAffiliatesGridSetup()
    End Sub

    Private Sub SaveBtn_Click(sender As Object, e As EventArgs) Handles SaveBtn.Click
        Try
            Me.uPage.FieldValidateDate(Me.StartDate, True)
            Me.uPage.FieldValidateDate(Me.EndDate, True)
            If Me.SubscriberCategoryRow.Visible Then
                Me.uPage.DropDownValidateMandatory(Me.SubscriberCategory, "Subscriber Category")
            End If
            If uPage.IsValid Then
                If CDate(Me.StartDate.Text) >= CDate(Me.EndDate.Text) Then
                    uPage.PageError = "Start Date must be before End Date"
                End If
            End If

            If uPage.IsValid Then
                Me.uPage.PopulateDataRowFromPageFields(Me.ChildSubscriber.ParentAffiliateRow(Me.ParentSubscriber.SubscriberId))
                Me.ChildSubscriber.Save()
            End If

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
        If uPage.IsValid Then
            Me.InfoMsg.Text = "Affiliation record saved."
        End If
    End Sub
End Class
