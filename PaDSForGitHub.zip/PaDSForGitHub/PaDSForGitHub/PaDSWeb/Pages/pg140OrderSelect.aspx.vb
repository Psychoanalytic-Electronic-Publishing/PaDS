﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'05/02/2020    Julian Gates   Initial Version
'23/3/20    James Woosnam   Subscriber security was causing a timeout so was removed as security is ensured by company

Partial Class Pages_pg140OrderSelect
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Order Search and List", "")
        Me.pageHeaderTitle.Text = "Order Search and List"

        If Page.IsPostBack Then

        Else
            If Request.QueryString("SubscriberId") <> "" Then
                Me.OrderGridView.FilterExpression = "SubscriberId='" & Request.QueryString("SubscriberId") & "'"
            End If

            If Request.QueryString("SubscriberName") <> "" Then
                Me.OrderGridView.FilterExpression = "Contains(SubscriberName, '" & Request.QueryString("SubscriberName") & "')"
            End If
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        GridSetup()

    End Sub

    Sub PageSetup()

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub GridSetup()
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT so.SubscriberId" & sCR
            Sql += " ,s.SubscriberName" & sCR
            Sql += " ,so.OrderNumber" & sCR
            Sql += " ,so.SalesOrderStatus" & sCR
            Sql += " ,so.OrderDate" & sCR
            Sql += " ,OrderDateText = FORMAT(OrderDate,'dd-MMM-yy')" & sCR
            Sql += " ,so.PrimaryProductCode" & sCR
            Sql += " ,so.CurrencyCode" & sCR
            Sql += " ,so.AmountGross" & sCR
            Sql += " ,so.CompanyId" & sCR
            Sql += " ,c.CompanyShortName" & sCR
            Sql += " ,HasCashbook = CASE WHEN EXISTS(select * FROM Cashbook WHERE OrderNumber=so.OrderNumber) THEN 'CB' ELSE Null END " & sCR
            Sql += " ,IsOverdue = CASE WHEN so.SalesOrderStatus IN ('Confirmed','Complete') AND ISNULL(so.IsPaid,0) = 0 THEN 1   ELSE 0 END " & sCR
            Sql += " FROM SalesOrder so" & sCR
            '23/3/20    James Woosnam   Subscriber security was causing a timeout so was removed as security is ensured by company
            Sql += "    INNER JOIN Subscriber s" & sCR
            Sql += "    ON s.SubscriberId = so.SubscriberId" & sCR
            Sql += "    INNER JOIN " & uPage.CompanyTable("c", uPage.UserSession.UserId) & sCR
            Sql += "    ON c.CompanyId = so.CompanyId" & sCR
            Select Case Me.uPage.UserSession.AuthorityLevel
                Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                    Sql += " WHERE 1 = 1" & sCR
                Case Else
                    Sql += "    INNER JOIN RemoteUserRights rur" & sCR
                    Sql += "    ON rur.RightsToId = s.SubscriberId" & sCR
                    Sql += "    AND rur.RightsType= 'Subscriber'" & sCR
                    Sql += "    AND rur.Userid = " & uPage.UserSession.UserId & sCR
                    Sql += " WHERE 1=1" & sCR
            End Select
            If Me.AccentSubscriberNameSearch.Text <> "" Then
                '17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .
                Sql += " AND CAST(s.SubscriberName AS NVARCHAR(150)) Like N'%" & Me.AccentSubscriberNameSearch.Text & "%'  COLLATE SQL_Latin1_General_CP1_CI_AI" & sCR
            End If
            Sql += " ORDER BY so.OrderNumber Desc" & sCR

            Me.OrderDatasource.SelectCommand = Sql
            Me.OrderDatasource.DataBind()
            Me.OrderGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Protected Sub AccentSubscriberNameSearchBtn_Click(sender As Object, e As EventArgs) Handles AccentSubscriberNameSearchBtn.Click
        Me.GridSetup()
    End Sub
    Protected Sub ClearSearchBtn_Click(sender As Object, e As EventArgs) Handles ClearSearchBtn.Click
        Response.Redirect("pg140OrderSelect.aspx?" & uPage.UserSession.QueryString)
    End Sub


    Protected Sub OrderGridView_HtmlDataCellPrepared(ByVal sender As Object, ByVal e As ASPxGridViewTableDataCellEventArgs)
        'Sets the font color of the SubmissionStatus column
        Dim gridView As ASPxGridView = CType(sender, ASPxGridView)
        If e.DataColumn.FieldName = "AmountGross" Then
            If e.GetValue("IsOverdue") Then
                e.Cell.ForeColor = System.Drawing.Color.Red
            End If
        End If
    End Sub

End Class
