﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.UserSession

'Modification History
'17/01/11  Julian Gates   Initial version
'10/05/11  Julian Gates   SIR2420 - Changed username / password resent text and reworked error message.
'22/12/11  Julian Gates   SIR2554 - Resend password message change
'11/07/12  Julian Gates   SIR2800 - Add new PEP data protection policy link.
'16/10/15  Julian Gates   SIR3982 - Change www.p-e-p.org links to support.pep-web.org
'15/01/16  Julian Gates   SIR4070 - Add entered password to Session("UserPassord") to be used to show password warning
'03/06/19  Julian Gates   SIR4850 - Change GDPR link text to PaDS has a GDPR compliant data protection policy available to read here.
'23/10/19  Julian Gates   SIR4943 - Add GroupRenewer redirect to pg462SubscriberRenewals
'1/11/19    James Woosnam   SIR4766 - Add support for spoof link
'11/12/19   James Woosnam   SIR4967-1 - SendEmailBtn_Click use email to lookup Username
'28/4/20    Julian Gates    SIR5032 - Add spanish translation
'25/8/20     James Woosnam   SIR5082 - Only reset cookie if required by Action and RedirectToUserHome changes for session cookie
'16/10/20   Julian Gates    SIR5139 - Add call to RequestPasswordBtn_Click if Action=RequestPassword
'28/01/21   Julian Gates    SIR5183 - Removed the Email Syntax check from this page.

Partial Class pages_pg070Logon
    Inherits System.Web.UI.Page
    Dim ds As New DataSet
    Dim StdCode As New BusinessLogic.StdCode()
    Public NewUserText As String = ""
    Public Property DisplayLanguage As BusinessLogic.UserSession.DisplayLanguages
        Get
            Return Me.Master.UserSession.DisplayLanguage
        End Get
        Set(value As BusinessLogic.UserSession.DisplayLanguages)
            Me.Master.UserSession.DisplayLanguage = value
        End Set
    End Property


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        Dim langDis As BusinessLogic.UserSession.DisplayLanguages = Me.Master.DisplayLanguageRBLSelectedValue
        '4/8/20     James Woosnam   SIR5082 - Only reset cookie if required by Action
        Dim ResetSessionCookie As Boolean = IIf(Request.QueryString("Action") = "ResetSessionCookie", True, False) ' (Not Me.IsPostBack And Not Request.QueryString("Action") = "SpoofLogon") Or (Not Me.IsPostBack And Request.QueryString("Action") = "Logout")
        Master.Initilise("Welcome to Pads", "00", "", "", "", ResetSessionCookie)
        Master.UserSession.DisplayLanguage = langDis
        Master.ShowLanguageRBL = True

        If Request.QueryString("Action") IsNot Nothing AndAlso {"SpoofToPaDSLogon".ToLower, "SpoofToPEPWebLogon".ToLower}.Contains(Request.QueryString("Action").ToLower) Then
            If Request.QueryString("UserName") = "" _
                            Or Request.QueryString("SpoofPassword") = "" _
                            Or Not IsNumeric(Request.QueryString("SpoofingUserId")) Then
                Master.WebForm.AddPageError("Invalid Spoof Logon")
            Else
                '1/11/19    James Woosnam   SIR4766 - Add support for spoof link
                '17/8/20    James Woosnam   SIR5082 - Store SessionId in, and restored from, a new session cookie
                Dim SpoofSess As New BusinessLogic.UserSession(Master.db)
                SpoofSess.Restore(InUserSessionId:="") 'restore with blank session id to generate a new one
                SpoofSess.Logon(Request.QueryString("UserName"), Request.QueryString("SpoofPassword"), True, Request.QueryString("SpoofingUserId"))
                '24/9/20    Spoof session are no longer stored in the cookie they are done by querystrig
                Me.Master.UserSession = SpoofSess
                If Request.QueryString("Action").ToLower = "SpoofToPEPWebLogon".ToLower Then
                    Me.Response.Redirect(Master.db.GetParameterValue("PEPWeb2021URL") & "?sessionId=" & SpoofSess.UserSessionId)
                End If
                Me.RedirectToUserHome(SpoofSess.AuthorityLevel, SpoofSess.QueryString, "Successful Spoof Login", SpoofSess)
            End If
        End If
        If Master.UserSession.LoggedIn Then
            If Request.QueryString("Action") = "RedirectToUserHome" Then
                Me.RedirectToUserHome(Master.UserSession.AuthorityLevel, Master.UserSession.QueryString, Request.QueryString("InfoMsg"))
            Else
                Me.RedirectToUserHome(Master.UserSession.AuthorityLevel, Master.UserSession.QueryString, "You still have an active session so have been logged in automatically")
            End If
        End If

        If Page.IsPostBack Then
        Else
            If Request.QueryString("NewUserText") <> "" Then
                NewUserText = Request.QueryString("NewUserText")
            End If
            '16/10/20   Julian Gates    SIR5139 - Add call to RequestPasswordBtn_Click if Action=RequestPassword
            If Request.QueryString("Action") <> "" Then
                If Request.QueryString("Action") = "RequestPassword" Then
                    RequestPasswordBtn_Click(sender, e)
                End If
            End If
            Me.UserName.Focus()
        End If
    End Sub

    Sub PageSetup()
        Me.LoginBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                , "Login" _
                                , "Acceder")
        Me.LoginBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                , "Login to PaDS" _
                                , "Iniciar sesión en Pads")
        Me.RequestPasswordBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                        , "Forgot Username/Password?" _
                        , "¿Olvidó su usuario o contraseña?")
        Me.RequestPasswordBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                        , "Click here to have your password resent." _
                        , "Haga clic aquí para reenviar su contraseña.")

        Me.RequestActivateAcctBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                        , "Need to Activate Account?" _
                        , "¿Necesita activar su cuenta PaDS?")
        Me.RequestActivateAcctBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                        , "Click here to have your account activation email sent." _
                        , "Haga clic aquí para recibir el correo electrónico de activación de su cuenta.")

        Me.SendEmailBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                , "Send" _
                , "Enviar")
        Me.CancelEmailBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                , "Cancel" _
                , "Cancelar")

        Me.AddNewSubscriberBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                , "Click Here" _
                , "Haga click aquí")

        If Master.UserSession.IsAtZedraOrZedraUser Then
            Try

                Dim lb As New Label
                TestTools.Visible = True
                TestTools.CssClass = "productLink"
                Dim lk As New HyperLink
                lk.NavigateUrl = Master.db.GetParameterValue("PaDSFederatedPortalURL") & "?" & Master.UserSession.QueryString
                lk.Text = "Federated Interface"
                lk.CssClass = "productLink"
                Me.TestTools.Controls.Add(lk)
                lb = New Label
                lb.Text = "<br>"
                Me.TestTools.Controls.Add(lb)
                TestTools.Visible = True
                TestTools.CssClass = "productLink"
                lk = New HyperLink
                lk.NavigateUrl = Master.db.GetParameterValue("PaDSFederatedPortalURL") & "?FederatedEntity=Default&" & Master.UserSession.QueryString
                lk.Text = "OpenAthens Default"
                lk.CssClass = "productLink"
                Me.TestTools.Controls.Add(lk)
                lb = New Label
                lb.Text = "<br>"
                Me.TestTools.Controls.Add(lb)
                Dim tbFederations As New Table
                Dim t As DataTable = Master.db.GetDataTableFromSQL("SELECT al.RemoteUserAutoLogonId ,al.FederatedEntity ,ru.UserFullName ,al.IsFederatedLinkRequired FROM RemoteUserAutoLogon al INNER JOIN RemoteUser ru ON ru.UserId = al.UserId WHERE ru.UserStatus = 'Active' AND al.AutoLogonStatus = 'Active' AND al.AutoLogonType = 'Federated' ORDER BY ISNULL(al.IsFederatedLinkRequired,0) DESC ,ru.UserFullName ")
                For Each r As DataRow In t.Rows
                    Dim tr As New TableRow
                    Dim tc As New TableCell
                    lk = New HyperLink
                    lk.NavigateUrl = Master.db.GetParameterValue("PaDSFederatedPortalURL") & "?FederatedEntity=" & r("FederatedEntity") & "&" & Master.UserSession.QueryString
                    lk.Text = r("UserFullName")
                    lk.CssClass = "productLink"
                    tc.Controls.Add(lk)
                    tr.Cells.Add(tc)

                    tc = New TableCell
                    tc.Text = r("FederatedEntity")
                    tr.Cells.Add(tc)

                    tc = New TableCell
                    Dim ck As New CheckBox
                    ck.Checked = Master.db.IsDBNull(r("IsFederatedLinkRequired"), False)
                    tc.Controls.Add(ck)
                    tr.Cells.Add(tc)

                    tbFederations.Rows.Add(tr)
                Next
                Me.TestTools.Controls.Add(tbFederations)

            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case "RequestPassword"
                If Me.EmailAddress.Text = "" Then
                    Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Email Address is mandatory." _
                               , "La dirección de correo electrónico es obligatoria."))
                End If
            Case Else
                If Me.UserName.Text = "" Then
                    Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Username is mandatory." _
                               , "El nombre de usuario es obligatorio."))
                End If
                If Me.Password.Text = "" Then
                    Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Password is mandatory." _
                               , "La contraseña es obligatoria."))
                End If
        End Select

        Return Me.Master.WebForm.IsValid
    End Function

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub LoginBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LoginBtn.Click
        Dim logonSuccessfull As Boolean = False
        If Me.IsPageValidForStatus("") Then

            Try
                Me.Master.UserSession.Logon(Me.UserName.Text, Me.Password.Text)
                'new session after login so need to reset langauge to what is choosen on page
                Me.Master.UserSession.DisplayLanguage = Me.Master.DisplayLanguageRBLSelectedValue
                Me.Master.WriteSessionLog("Successfull Logon", Me.UserName.Text)

                logonSuccessfull = True
                Me.Master.UserSession.SessionCookie.Save(Me.Response, False)
            Catch ex As Exception
                If ex.Message.Contains("UserError:") Then
                    Me.Master.WebForm.AddPageError(ex)
                Else
                    Me.Master.WebForm.AddPageError(New Exception(ex.Message, ex))
                End If
            End Try

        End If
        If logonSuccessfull Then
            Me.RedirectToUserHome(Me.Master.UserSession.AuthorityLevel, Master.UserSession.QueryString, "")
        End If
    End Sub
    Sub RedirectToUserHome(AuthorityLevel As BusinessLogic.UserSession.AuthorityLevels, QryStr As String, InfoMsg As String, Optional SpoofSess As BusinessLogic.UserSession = Nothing)
        '4/8/20     James Woosnam   SIR5082 - RedirectToUserHome changes for session cookie
        QryStr = "?" & QryStr & IIf(InfoMsg <> "", "&InfoMsg=" & InfoMsg, "")
        Select Case AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                '15/01/16  Julian Gates   SIR4070 - Add entered password to Session("UserPassord") to be used to show password warning
                Session("UserPassord") = Me.Password.Text
                Me.Master.Response.Redirect("pg100HomeAdmin.aspx" & QryStr)
            Case BusinessLogic.UserSession.AuthorityLevels.GroupAdmins
                Me.Master.Response.Redirect("pg490GroupSubscriberSelect.aspx" & QryStr)

            Case BusinessLogic.UserSession.AuthorityLevels.IndividualSubscriber, AuthorityLevels.GroupUser
                Dim targetSubscriberId As String = Nothing
                If SpoofSess IsNot Nothing Then
                    targetSubscriberId = SpoofSess.Data("SubscriberId")
                Else
                    targetSubscriberId = Me.Master.UserSession.Data("SubscriberId")
                End If
                If targetSubscriberId = Nothing Then
                    'can't open this page without sub id
                    Me.Master.UserSession.SessionCookie.Save(Me.Response, True)
                    Me.Master.UserSession.Logout()
                Else
                    Me.Master.Response.Redirect("pg101Home.aspx" & QryStr)
                End If
            Case BusinessLogic.UserSession.AuthorityLevels.User
                Me.Master.Response.Redirect("pg100HomeAdmin.aspx" & QryStr)
                '23/10/19  Julian Gates   SIR4943 - Add GroupRenewer redirect to pg462SubscriberRenewals
            Case BusinessLogic.UserSession.AuthorityLevels.GroupRenewer
                Me.Master.Response.Redirect("pg462SubscriberRenewals.aspx" & QryStr)
        End Select

    End Sub
    Protected Sub RequestPasswordBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RequestPasswordBtn.Click
        Me.LogonTable.Visible = False
        Me.EnterPasswordTable.Visible = True
        Me.ResendPasswordTextRow.Visible = True
        Me.EmailAddress.Focus()
    End Sub

    Protected Sub RequestActivateAcctBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RequestActivateAcctBtn.Click
        Me.LogonTable.Visible = False
        Me.EnterPasswordTable.Visible = True
        Me.ActivateAccountTextRow.Visible = True
        Me.EmailAddress.Focus()
    End Sub

    Protected Sub SendEmailBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SendEmailBtn.Click
        If Me.IsPageValidForStatus("RequestPassword") Then
            Try
                '11/12/19   James Woosnam   SIR4967-1 - SendEmailBtn_Click use email to lookup Username
                Dim UserName As String = Master.db.DLookup("UserName", "RemoteUser", "UserStatus IN ('Active','Emailed') AND EmailAddress='" & Me.EmailAddress.Text & "'", True)
                If UserName = Nothing Then
                    Throw New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Email address not linked to a User record." _
                               , "Dirección de correo electrónico no vinculada a un registro de usuario."))
                End If
                Dim ru As New BusinessLogic.RemoteUser(UserName, Master.db, Master.UserSession)
                ru.ResetPasswordAndEmail()
                Me.EmailAddress.Text = ""
                '   Me.LogonTable.Visible = True
                '   Me.EnterPasswordTable.Visible = False
                Me.RenewalEmailSentMessage.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                       , "A PaDS reactivation email has been sent to this address." _
                                                       , "Un correo de reactivación de PaDS le ha sido enviado a esta dirección.")
                Me.RenewalEmailSentMessage.Visible = True
                Me.UserName.Focus()

            Catch ex As Exception
                Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                       , "A password renewal email can't be sent, please contact " _
                                                       , "No se puede enviar un correo electrónico de renovación de contraseña, comuníquese con ") & Master.db.SupportEmailLink, ex))
            End Try
        End If
    End Sub

    Protected Sub CancelEmailBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelEmailBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub

    Protected Sub AddNewSubscriberBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AddNewSubscriberBtn.Click
        Me.Master.Response.Redirect("pg117AddNewSubscriber.aspx?DisplayLanguage=" & Me.Master.DisplayLanguageRBLSelectedValue & "&" & Me.Master.UserSession.QueryString)
    End Sub
End Class

