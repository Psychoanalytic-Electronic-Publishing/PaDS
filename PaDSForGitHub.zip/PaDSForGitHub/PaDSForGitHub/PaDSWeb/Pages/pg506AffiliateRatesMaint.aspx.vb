﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'28/05/2015 Julian Gates   Initial Version
'18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified

Partial Class Pages_pg506AffiliateRatesMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Private copiedValues As Hashtable = Nothing
    Private copiedFields() As String = {"ProductCode", "GroupSubscriberId", "SubscriberCategory", "ProductRateId"}

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Affiliate Rates View", "")
        Me.pageHeaderTitle.Text = "Affiliate Rates View"

        If Page.IsPostBack Then

        Else

        End If
        If Request.QueryString("ProductCode") <> "" And Request.QueryString("CompanyId") <> "" Then
            Me.ProductCode.Text = Request.QueryString("ProductCode")
            Me.TargetProductCode.Value = Me.ProductCode.Text
            Me.TargetCompanyId.Value = Request.QueryString("CompanyId")
            Session("ProductCode") = Me.ProductCode.Text
            Session("CompanyId") = Me.TargetCompanyId.Value
        Else
            uPage.PageError = "Invalid Parameter has been passed in."
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If
        BuildInitailDropdowns()
    End Sub

    Sub PageSetup()
        Me.pageHeaderTitle.Text = "Affiliate Rates for: " & Me.ProductCode.Text
        Me.ProductName.Text = uPage.db.DLookup("ProductName", "Product", "ProductCode='" & Me.ProductCode.Text & "'")

        'show filter row menu
        Me.ProductAffiliateRateGridView.Settings.ShowFilterRowMenu = True
        Me.ProductAffiliateRateGridView.SettingsEditing.Mode = GridViewEditingMode.Inline

        Me.ProductSelectLink.NavigateUrl = "../pages/pg503ProductSelect.aspx?" & uPage.UserSession.QueryString
        Me.ProductMaintLink.NavigateUrl = "../pages/pg504ProductMaint.aspx?" & uPage.UserSession.QueryString & "&PageMode=Update&ProductCode=" & Me.ProductCode.Text
        Me.ProductRatesLink.NavigateUrl = "../pages/pg502ProductRatesMaint.aspx?" & uPage.UserSession.QueryString & "&ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.TargetCompanyId.Value
        Me.QualifyingProductsLink.NavigateUrl = "../pages/pg505QualifyingProductMaint.aspx?" & uPage.UserSession.QueryString & "&ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.TargetCompanyId.Value
        Me.ProductContentSetLink.NavigateUrl = "../pages/pg507ProductContentSetMaint.aspx?" & uPage.UserSession.QueryString & "&ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.TargetCompanyId.Value
    End Sub

    Sub BuildInitailDropdowns()
        Try
            'Populate dropdown fields
            CType(Me.ProductAffiliateRateGridView.Columns("GroupSubscriberId"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL(Me.GroupSubscriberDropdownSQL())
            CType(Me.ProductAffiliateRateGridView.Columns("SubscriberCategory"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL(Me.SubscriberCategoryDropdownSQL())
            CType(Me.ProductAffiliateRateGridView.Columns("ProductRateId"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL(Me.GetProductRateSql(Me.TargetProductCode.Value))

        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Protected Sub ProductAffiliateRate_RowValidating(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataValidationEventArgs)
        If e.NewValues("GroupSubscriberId") Is Nothing Then
            AddError(e.Errors, ProductAffiliateRateGridView.Columns("GroupSubscriberId"), "Please enter a Group Subscriber Id.")
        End If

        If e.NewValues("SubscriberCategory") Is Nothing Then
            AddError(e.Errors, ProductAffiliateRateGridView.Columns("SubscriberCategory"), "Please select a Subscriber Category.")
        End If

        If e.NewValues("ProductRateId") Is Nothing Then
            AddError(e.Errors, ProductAffiliateRateGridView.Columns("ProductRateId"), "Please select a Product Rate value.")
        End If

        If String.IsNullOrEmpty(e.RowError) AndAlso e.Errors.Count > 0 Then
            e.RowError = "Please, correct all errors."
        End If

        uPage.PageError = e.RowError

        BuildDropdownsForPostback()
    End Sub

    Private Sub AddError(ByVal errors As Dictionary(Of GridViewColumn, String), ByVal column As GridViewColumn, ByVal errorText As String)
        If errors.ContainsKey(column) Then
            Return
        End If
        errors(column) = errorText
    End Sub

    Protected Sub ProductQualifyingProductGridView_ItemInserting(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInsertingEventArgs) Handles ProductAffiliateRateGridView.RowInserting

        CType(Me.ProductAffiliateRateGridView.Columns("ProductRateId"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL(Me.GetProductRateSql(Me.TargetProductCode.Value))
    End Sub

    Protected Sub ProductQualifyingProductGridView_ItemUpdated(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataUpdatedEventArgs) Handles ProductAffiliateRateGridView.RowUpdated
        CType(Me.ProductAffiliateRateGridView.Columns("ProductRateId"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL(Me.GetProductRateSql(Me.TargetProductCode.Value))
    End Sub

    Protected Sub grid_CellEditorInitialize(ByVal sender As Object, ByVal e As ASPxGridViewEditorEventArgs)
        If uPage Is Nothing Then
            uPage = New UserPage(Me, "Affiliate Rates View", "")
        End If
        If (Not ProductAffiliateRateGridView.IsEditing) OrElse e.Column.FieldName <> "ProductRateId" Then
            Return
        End If
        Dim combo As ASPxComboBox = TryCast(e.Editor, ASPxComboBox)

        If Not ProductAffiliateRateGridView.IsNewRowEditing Then
            Dim val As Object = ProductAffiliateRateGridView.GetRowValuesByKeyValue(e.KeyValue, "SubscriberCategory")
            If val Is DBNull.Value Then
                Return
            End If
            Dim subscriberCategory As String = CStr(val)

            FillProductRateCombo(combo, subscriberCategory)
        End If

        AddHandler combo.Callback, AddressOf cmbProductRateId_OnCallback
    End Sub

    Protected Sub FillProductRateCombo(ByVal cmb As ASPxComboBox, ByVal subscriberCategory As String)
        If String.IsNullOrEmpty(subscriberCategory) Then
            Return
        End If

        'Refill product rates dropdown based on subscriberCategory value
        Dim ProductRates As DataTable = Me.uPage.db.GetDataTableFromSQL(Me.GetProductRateSql(Session("ProductCode"), subscriberCategory))
        cmb.Items.Clear()
        For Each row As DataRow In ProductRates.Rows
            cmb.Items.Add(row("ProductRate"), row("ProductRateId"))
        Next row
    End Sub

    Private Sub cmbProductRateId_OnCallback(ByVal source As Object, ByVal e As CallbackEventArgsBase)
        FillProductRateCombo(TryCast(source, ASPxComboBox), e.Parameter)
    End Sub

    Protected Sub grid_CustomButtonCallback(ByVal sender As Object, ByVal e As ASPxGridViewCustomButtonCallbackEventArgs)
        If e.ButtonID <> "Copy" Then
            Return
        End If
        copiedValues = New Hashtable()
        For Each fieldName As String In copiedFields
            copiedValues(fieldName) = ProductAffiliateRateGridView.GetRowValues(e.VisibleIndex, fieldName)
        Next fieldName
        ProductAffiliateRateGridView.AddNewRow()
    End Sub

    Protected Sub grid_InitNewRow(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInitNewRowEventArgs)
        If copiedValues Is Nothing Then
            Return
        End If
        For Each fieldName As String In copiedFields
            e.NewValues(fieldName) = copiedValues(fieldName)
        Next fieldName
    End Sub

    Function GetProductRateSql(ByVal ProductCode As String, Optional SubscriberCategory As String = Nothing) As String
        Dim sql As String = Nothing
        sql = "SELECT ProductRate.ProductRateId"
        sql += " ,ProductRate = Cast(ProductRate.ProductRate as varchar) + ' ' + ProductRate.CurrencyCode + ' ' + ProductRate.RateType + ' ' + ProductRate.AccountType + ' ' + ProductRate.SubscriberCategory + ' ' + ProductRate.DeliveryArea"
        sql += " FROM ProductRate"
        sql += " WHERE ProductRate.ProductCode = '" & ProductCode & "'"
        If SubscriberCategory <> Nothing Then
            sql += " AND ProductRate.SubscriberCategory = '" & SubscriberCategory & "'"
        End If
        sql += " ORDER BY ProductRate.CurrencyCode, ProductRate.ProductRate"
        Return sql
    End Function

    Protected Sub ProductAffiliateRateGridView_InitNewRow(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInitNewRowEventArgs) Handles ProductAffiliateRateGridView.InitNewRow
        BuildDropdownsForPostback()
    End Sub

    Protected Sub ProductAffiliateRateGridView_StartRowEditing(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxStartRowEditingEventArgs) Handles ProductAffiliateRateGridView.StartRowEditing
        BuildDropdownsForPostback()
    End Sub

    Protected Sub ProductAffiliateRateGridView_RowInserted(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInsertedEventArgs) Handles ProductAffiliateRateGridView.RowInserted
        BuildDropdownsForPostback()
        '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
        e.NewValues("LastUpdatedDateTime") = Now()
        e.NewValues("LastUpdatedByUserId") = uPage.UserSession.UserName20
    End Sub

    Protected Sub ProductAffiliateRateGridView_RowUpdated(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataUpdatedEventArgs) Handles ProductAffiliateRateGridView.RowUpdated
        BuildDropdownsForPostback()
        '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
        e.NewValues("LastUpdatedDateTime") = Now()
        e.NewValues("LastUpdatedByUserId") = uPage.UserSession.UserName20
    End Sub

    Sub BuildDropdownsForPostback()
        Try
            Dim combo As GridViewDataComboBoxColumn = TryCast(ProductAffiliateRateGridView.Columns("GroupSubscriberId"), GridViewDataComboBoxColumn)
            combo.PropertiesComboBox.ValueType = GetType(String)

            If combo.PropertiesComboBox.Items.Count = 0 Then
                For Each row As DataRow In Me.uPage.db.GetDataTableFromSQL(Me.GroupSubscriberDropdownSQL()).Rows
                    combo.PropertiesComboBox.Items.Add(row("SubscriberName"), row("SubscriberId"))
                Next
            End If

            combo = TryCast(ProductAffiliateRateGridView.Columns("SubscriberCategory"), GridViewDataComboBoxColumn)
            combo.PropertiesComboBox.ValueType = GetType(String)

            If combo.PropertiesComboBox.Items.Count = 0 Then
                For Each row As DataRow In Me.uPage.db.GetDataTableFromSQL(Me.SubscriberCategoryDropdownSQL()).Rows
                    combo.PropertiesComboBox.Items.Add(row("Name"), row("LookupItemKey"))
                Next
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub

    '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active 
    Function SubscriberCategoryDropdownSQL() As String
        Dim sql As String = "SELECT Lookup.LookupItemKey"
        sql += "   ,Lookup.Name"
        sql += "   FROM Lookup"
        sql += " WHERE LookupName = 'SubscriberCategory'"
        sql += " AND CompanyId = " & Me.TargetCompanyId.Value
        sql += " AND LookupStatus = 'Active'"
        sql += " ORDER BY Lookup.Name"
        Return sql
    End Function

    Function GroupSubscriberDropdownSQL() As String
        Dim sql As String = "SELECT s.SubscriberId"
        sql += "        ,SubscriberName = s.SubscriberName + ' (' + CAST(s.SubscriberId as VARCHAR) + ')'"
        sql += "  FROM Subscriber s "
        sql += "    INNER JOIN SubscriberAffiliate sa"
        sql += "        INNER JOIN Company "
        sql += "        ON Company.CompanyId =" & Me.TargetCompanyId.Value
        sql += "       AND Company.GroupParentSubscriberId = sa.ParentSubscriberID"
        sql += "    ON sa.ChildSubscriberId = s.SubscriberId"
        sql += " WHERE s.EntityType = 'Organisation'"
        sql += " AND (SELECT COUNT(*) "
        sql += "    FROM SubscriberAffiliate"
        sql += "    WHERE SubscriberAffiliate.ParentSubscriberID = s.SubscriberId) <> 0 "
        sql += " ORDER BY s.SubscriberName"

        Return sql
    End Function
End Class

