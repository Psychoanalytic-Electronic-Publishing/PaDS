﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'04/02/2020    Julian Gates   Initial Version
'12/2/20    James Woosnam   SIR5016 - Filter on subscriber name correctly
'17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name.
'19/2/21    James Woosnam   SIR5202 - Exclude 'Deleted','Merged','Redundant' address records from Address Search

Partial Class Pages_pg110SubscriberSelect
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Subscriber Search and List", "")
        Me.pageHeaderTitle.Text = "Subscriber Search and List"

        If Page.IsPostBack Then

        Else
            If Request.QueryString("SubscriberName") <> "" Then
                '12/2/20    James Woosnam   SIR5016 - Filter on subscriber name correctly
                Me.SubscriberGridView.FilterExpression = "Contains(SubscriberName, '" & Request.QueryString("SubscriberName") & "')"
            End If
            If Request.QueryString("AddressText") <> "" Then
                Me.AddressSearch.Text = Request.QueryString("AddressText")
            End If
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        GridSetup()

    End Sub

    Sub PageSetup()

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub GridSetup()
        Try

            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT s.SubscriberId" & sCR
            Sql += " ,s.SubscriberName" & sCR
            Sql += " ,s.EntityType" & sCR
            Sql += " ,s.SubscriberStatus" & sCR
            Sql += " ,WebUserName = ru.UserName" & sCR
            Sql += " ,HasAffiliates = CASE WHEN EXISTS(select * FROM SubscriberAffiliate WHERE ParentSubscriberId=s.SubscriberId) THEN 'Affils' ELSE Null END " & sCR
            Sql += " ,HasOrders = CASE WHEN EXISTS(select * FROM SalesOrder WHERE SubscriberId=s.SubscriberId) THEN 'Ords' ELSE Null END " & sCR
            Sql += " ,HasCashbook = CASE WHEN EXISTS(select * FROM Cashbook WHERE SubscriberId=s.SubscriberId) THEN 'CB' ELSE Null END " & sCR
            If AddressSearch.Text <> "" Then
                Sql += " ,Address=Min(sa.AddressText)" & sCR
            Else
                Sql += " ,Address='xx'" & sCR
            End If
            Sql += " FROM " & uPage.SubscriberTable("s") & sCR
            Sql += "    LEFT JOIN RemoteUserRights rur" & sCR
            Sql += "        INNER JOIN RemoteUser ru" & sCR
            Sql += "        ON ru.UserId = rur.userId" & sCR
            Sql += "        AND ru.AuthorityLevel = 'IndividualSubscriber'" & sCR
            Sql += "    ON rur.RightsToId= s.SubscriberId" & sCR
            Sql += "    AND rur.RightsType= 'Subscriber'" & sCR
            '19/02/21   James Woosnam   SIR5202 - Remove deleted addresses from AddressSearch
            If AddressSearch.Text <> "" Then
                Sql += "    INNER Join SubscriberAddress sa" & sCR
                Sql += "    On sa.SubscriberId = s.SubscriberId" & sCR
                '19/2/21    James Woosnam   SIR5202 - exclude 'Deleted','Merged','Redundant' address records from
                Sql += "    AND sa.AddressDescription NOT IN ('Deleted','Merged','Redundant')" & sCR
                Sql += "	INNER Join Country c" & sCR
                Sql += "    On c.CountryId = s.PrimaryCountryId" & sCR
                Sql += " And ( CAST(sa.AddressText AS NVARCHAR(255)) Like N'%" & AddressSearch.Text & "%' COLLATE SQL_Latin1_General_CP1_CI_AI" & sCR
                Sql += "	   Or CAST(sa.Address1 AS NVARCHAR(255)) Like N'%" & AddressSearch.Text & "%' COLLATE SQL_Latin1_General_CP1_CI_AI" & sCR
                Sql += "	   Or CAST(sa.Address2 As NVARCHAR(255)) Like N'%" & AddressSearch.Text & "%' COLLATE SQL_Latin1_General_CP1_CI_AI" & sCR
                Sql += "	   Or CAST(sa.Address3 AS NVARCHAR(255)) Like N'%" & AddressSearch.Text & "%' COLLATE SQL_Latin1_General_CP1_CI_AI" & sCR
                Sql += "	   Or CAST(sa.Address4 As NVARCHAR(255)) Like N'%" & AddressSearch.Text & "%' COLLATE SQL_Latin1_General_CP1_CI_AI" & sCR
                Sql += "	   Or CAST(sa.Town AS NVARCHAR(255)) Like N'%" & AddressSearch.Text & "%' COLLATE SQL_Latin1_General_CP1_CI_AI" & sCR
                Sql += "	   Or CAST(sa.County As NVARCHAR(255)) Like N'%" & AddressSearch.Text & "%' COLLATE SQL_Latin1_General_CP1_CI_AI" & sCR
                Sql += "	   Or sa.Postcode Like '%" & AddressSearch.Text & "%'" & sCR
                Sql += "	   Or c.CountryName Like '%" & AddressSearch.Text & "%'" & sCR
                Sql += "     )" & sCR
            End If
            Sql += " WHERE 1=1" & sCR
            If Me.CurrentAndProposedOnly.Checked Then
                Sql += " AND s.SubscriberStatus IN ('Current','Proposed')" & sCR
            End If
            If Me.AccentSubscriberNameSearch.Text <> "" Then
                '17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .
                Sql += " AND CAST(s.SubscriberName AS NVARCHAR(150)) Like N'%" & Me.AccentSubscriberNameSearch.Text & "%'  COLLATE SQL_Latin1_General_CP1_CI_AI" & sCR
            End If
            Sql += " GROUP BY s.SubscriberId" & sCR
            Sql += " ,s.SubscriberName" & sCR
            Sql += " ,s.EntityType" & sCR
            Sql += " ,s.SubscriberStatus" & sCR
            Sql += " ,ru.UserName" & sCR
            Sql += " ORDER BY s.SubscriberName" & sCR

            Me.SubscriberDatasource.SelectCommand = Sql
            Me.SubscriberDatasource.DataBind()
            Me.SubscriberGridView.DataBind()
            Dim cAddress As GridViewDataTextColumn = TryCast(Me.SubscriberGridView.Columns("Address"), GridViewDataTextColumn)
            cAddress.Visible = AddressSearch.Text <> ""
            'Me.SubscriberGridView.Font.Size = 5
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Protected Sub AddNewBtn_Click(sender As Object, e As EventArgs) Handles AddNewBtn.Click
        Response.Redirect("../Pages/pg114AddSubscriber.aspx?" & uPage.UserSession.QueryString)
    End Sub


    Protected Sub AddressSearchBtn_Click(sender As Object, e As EventArgs) Handles AddressSearchBtn.Click
        Me.GridSetup()
    End Sub
    Protected Sub AccentSubscriberNameSearchBtn_Click(sender As Object, e As EventArgs) Handles AccentSubscriberNameSearchBtn.Click
        Me.GridSetup()
    End Sub
    Protected Sub ClearSearchBtn_Click(sender As Object, e As EventArgs) Handles ClearSearchBtn.Click
        Response.Redirect("pg110SubscriberSelect.aspx?" & uPage.UserSession.QueryString)
    End Sub
End Class
