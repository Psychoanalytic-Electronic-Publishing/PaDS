﻿Imports System.Data.SqlClient
Public Class Form1

    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)
            'For batch log create a new connection so the log remains even if the tans is rolled back
            Me._db = value

        End Set
    End Property


    Private Sub DeleteTestData_Click(sender As Object, e As EventArgs) Handles DeleteTestData.Click
        RefreshDB()
        Try

            Dim pt As New PaDSTesting(db)
            pt.DeleteAllTestData()
            AddProgressMsg(pt.ProgressMessage)

        Catch ex As Exception
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub
    Private Sub RunTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteAddTestData.Click
        RefreshDB()
        Dim pt As New PaDSTesting(db)
        Try

            pt.ResetTestData()
            AddProgressMsg(pt.ProgressMessage)

        Catch ex As Exception
            AddProgressMsg(pt.ProgressMessage)
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub
    Public ReadOnly Property RunningOnClientServer As Boolean
        Get
            If System.Security.Principal.WindowsIdentity.GetCurrent.Name.ToUpper.Contains("ZEDRA\") Then
                Return False
            Else
                Return True
            End If

        End Get
    End Property

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.ErrorMessage.Text = ""
        If Not RunningOnClientServer Then
            'Passwords as blanked out in GitHub version
            Me.PrimaryConnection.Text = "Integrated Security=SSPI;Initial Catalog=Pads_test;Data Source=zedra46\zedra46sql2017;Connect Timeout=1"
            Me.SecondaryConnection.Text = "UID=PaDSSQLServerUser;PWD=7nHk98Ak; Initial Catalog=Pads_test;Data Source=ZEDRA48\sql2017;Connect Timeout=1"
            Me.SecurityConnection.Text = "Integrated Security=SSPI;Initial Catalog=Pads_test;Data Source=zedra48\sql2017;Connect Timeout=1;"
        Else
            Me.PrimaryConnection.Text = "Integrated Security=SSPI;Initial Catalog=pads_live;Data Source=PaDS01;Connect Timeout=1"
            '            Me.PrimaryConnection.Text = "UID=PaDSSQLServerUser;PWD=7nHk98Ak; Initial Catalog=Pads_Live;Data Source=pads01;"
            Me.SecondaryConnection.Text = "UID=PaDSSQLServerUser;PWD=xxObscuredPasswordxx; Initial Catalog=Pads_Live;Data Source=PaDS02;"
            Me.SecurityConnection.Text = "UID=PaDSSQLSecurityUser;PWD=xxObscuredPasswordxx; Initial Catalog=Pads_Live;Data Source=PaDS02;"
        End If
        RefreshDB()
    End Sub
    Public Sub RefreshDB()
        Try
            Me.ProgressLog.Text = ""
            Me.ErrorMessage.Text = ""
            db = New BusinessLogic.Database(New BusinessLogic.Failover().ChooseConnectionString(Me.PrimaryConnection.Text,
                                                                     Me.SecondaryConnection.Text,
                                                                     Me.SecurityConnection.Text,
                                                                     "Primary",
                                                                     "Primary"))
            db.SecondaryConnectionString = Me.SecondaryConnection.Text
        Catch ex As Exception
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub

    Private Sub ConnectionString_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrimaryConnection.TextChanged
        '   RefreshDB()
    End Sub
    Dim FileNamePrefix As String = ""
    Dim LogFile As BusinessLogic.LogFile = Nothing
    Sub AddProgressMsg(ByVal Message As String, Optional InFileNamePrefix As String = "")
        If InFileNamePrefix = "" Then
            InFileNamePrefix = "Root"
        End If
        'If a InFileNamePrefix supplied then needs to be a new log file with the prefix which is used from then on
        If LogFile Is Nothing Then

            LogFile = New BusinessLogic.LogFile(IO.Path.Combine(Application.StartupPath, "Logs"), InFileNamePrefix)
        Else
            If InFileNamePrefix <> LogFile.FileNamePrefix Then
                LogFile = New BusinessLogic.LogFile(IO.Path.Combine(Application.StartupPath, "Logs"), InFileNamePrefix)
            End If
        End If

        AddProgressMsg(Message)
    End Sub
    Sub AddProgressMsg(ByVal Message As String)

        If LogFile Is Nothing Then
            LogFile = New BusinessLogic.LogFile(IO.Path.Combine(Application.StartupPath, "Logs"), "Root")
        End If
        LogFile.Write(Message)
        Me.ProgressLog.Text = LogFile.NewMessageWithPrefix & ControlChars.NewLine & Me.ProgressLog.Text

        Me.Refresh()
    End Sub
    Private Sub RunNextbatchJob_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RunNextbatchJob.Click
        RefreshDB()
        Me.ErrorMessage.Text = ""
        Try
            Dim sql As String = ""
            sql = "update BatchJob set BatchJobStatus = 'Pending' where BatchJobId = (select MAX(Batchjobid) from		BatchJob )"
            Dim cmd As New SqlClient.SqlCommand(sql, db.DBConnection)
            cmd.ExecuteNonQuery()
            Dim BatchJob As New BusinessLogic.BatchJob(Me.db)
            BatchJob.ProcessNextBatchJob()
        Catch ex As Exception
            Me.ErrorMessage.Text = ex.ToString
        End Try

    End Sub

    'SIR4070 - Update RemoteUser password to encrypted versions
    Private Sub EncryptPasswordBtn_Click(sender As Object, e As EventArgs) Handles EncryptPasswordBtn.Click
        ' db.BeginTran()
        Try
            Dim lf As String = System.Environment.NewLine
            Dim sql As String = ""
            sql = "SELECT *"
            sql += " FROM RemoteUser"
            sql += " WHERE AuthorityLevel = 'IndividualSubscriber'"
            sql += " AND len(password) <>40"
            Dim cmd As New SqlClient.SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
            Dim da = New SqlClient.SqlDataAdapter(cmd)
            Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(da)
            da.UpdateCommand = cmdBld.GetUpdateCommand()

            da.UpdateCommand.Transaction = Me.db.DBTransaction
            Dim tbl As New DataTable("RemoteUser")
            da.Fill(tbl)

            sql = ""
            Dim ru As New BusinessLogic.RemoteUser(Me.db)
            For Each row As DataRow In tbl.Rows
                db.ExecuteSQL("Update remoteuser set 
IsPasswordValid = " & IIf(ru.IsValidPassword(row("password")), 1, 0) & "
,Password='" & System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(row("Password"), "SHA1") & "'
WHERE UserId = " & row("UserId"))
            Next
            '        da.Update(tbl)
            Me.ErrorMessage.Text = "Passwords sucessfully Encrypted"
            Me.EncryptPasswordBtn.Enabled = False
            '     db.CommitTran()
        Catch ex As Exception
            '  db.RollbackTran()
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub

    Private Sub RunReport_Click(sender As Object, e As EventArgs) Handles RunReport.Click
        RefreshDB()
        Me.ErrorMessage.Text = ""
        Try


            Me.RunNextbatchJob_Click(sender, e)
        Catch ex As Exception
            Me.ErrorMessage.Text = ex.ToString
        End Try

    End Sub

    Private Sub CopyDBToSecondary_Click(sender As Object, e As EventArgs) Handles CopyDBToSecondary.Click
        RefreshDB()
        Me.ErrorMessage.Text = ""
        Try
            Dim BatchJob As New BusinessLogic.BatchJob(Me.db)
            BatchJob.SubmittedByUserSessionId = New Guid("11111111111111111111111111111111")
            BatchJob.Parameters.Add("SecondaryConnectionString", Me.SecurityConnection.Text)

            BatchJob.CreateBatchJobEntry("CopyPaDSDatabaseToSecondary", Me.db)

            Me.RunNextbatchJob_Click(sender, e)
        Catch ex As Exception
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub

    Private Sub CompileSQL_Click(sender As Object, e As EventArgs) Handles Complie1stSQL.Click
        RefreshDB()
        AddProgressMsg("SQL Compile Started for Primary", "CompileSQL_Click")

        Try
            AddProgressMsg("Connection:" & db.DBConnection.ConnectionString)
            Dim utils As New BusinessLogic.PaDSSupportUtilities(db)
            Dim compileMsg As String = ""
            utils.RunDatabaseSQL(db.GetParameterValue("SQLFileDirectory"), compileMsg, Me.ErrorMessage.Text)
            AddProgressMsg(compileMsg & Me.ErrorMessage.Text)

            AddProgressMsg("**********All SQL File Complete********")
        Catch ex As Exception
            AddProgressMsg(ex.ToString)
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub

    Private Sub Complie2ndSQL_Click(sender As Object, e As EventArgs) Handles Complie2ndSQL.Click
        RefreshDB()
        AddProgressMsg("SQL Compile Started for Secondary", "Complie2ndSQL_Click")

        Try
            Dim dbSecondarySecure As New BusinessLogic.Database(Me.SecurityConnection.Text)
            AddProgressMsg("Connection:" & dbSecondarySecure.DBConnection.ConnectionString)
            Dim utils As New BusinessLogic.PaDSSupportUtilities(dbSecondarySecure)
            Dim compileMsg As String = ""
            utils.RunDatabaseSQL(dbSecondarySecure.GetParameterValue("SQLFileDirectory"), compileMsg, Me.ErrorMessage.Text)
            AddProgressMsg(compileMsg & Me.ErrorMessage.Text)
            'For Secondary DB reset oblect rights to read only
            dbSecondarySecure.ExecuteSQL("EXEC sp510GrantObjectRights @MakeReadOnly=1")
            AddProgressMsg("Readonly object rights complete")

            AddProgressMsg("**********All SQL File Complete********")
        Catch ex As Exception
            AddProgressMsg(ex.ToString)
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub

    Private Sub SendEmailToSupport_Click(sender As Object, e As EventArgs) Handles SendEmailToSupport.Click
        RefreshDB()
        AddProgressMsg("SQL Compile Started for Secondary", "Complie2ndSQL_Click")

        Try
            Dim email As New BusinessLogic.Email(db)
            email.SendTo = "support@zedra.co.uk"
            email.From = "sales@psychoanalystdatabase.com"
            'newMessage.From = "support@zedra.co.uk"

            email.Subject = "Test Renewal"

            email.IsBodyHTML = True

            email.Body = "Hello"

            email.Send()

            AddProgressMsg("**********SendEmailToSupport_Click********")
        Catch ex As Exception
            AddProgressMsg(ex.ToString)
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub

    Private Sub RunIsOnLiveServer_Click(sender As Object, e As EventArgs) Handles RunIsOnLiveServer.Click
        RefreshDB()
        AddProgressMsg("RunIsOnLiveServer_Click started")

        Try
            If Me.db.IsOnLiveServer Then
                AddProgressMsg("IsOnLiveServer:Yes")
            Else
                AddProgressMsg("IsOnLiveServer:No")
            End If

        Catch ex As Exception
            AddProgressMsg(ex.ToString)
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub

    Private Sub RunLogonTests_Click(sender As Object, e As EventArgs) Handles RunLogonTests.Click
        AddProgressMsg("RunLogonTests_Click started")
        Dim dir As New IO.DirectoryInfo(db.GetParameterValue("SQLFileDirectory"))
        If Not dir.Exists Then Throw New Exception(dir.FullName & " can't be found")
        dir = New IO.DirectoryInfo(IO.Path.Combine(dir.FullName.Replace(dir.Name, ""), "TestResults"))
        If Not dir.Exists Then dir.Create()

        Dim fi As New IO.FileInfo(IO.Path.Combine(dir.FullName, "PEPProductLogonResults" & Now.ToString("yyyyMMdd HHmm") & ".txt"))
        Dim outputFile As System.IO.StreamWriter = New System.IO.StreamWriter(fi.FullName, True, System.Text.Encoding.Default)

        Try
            Dim tbl As DataTable = db.GetDataTableFromSQL("select distinct top 3  subscriberid,webusername,webuserpassword  from zTestProductUsers order by SubscriberId")
            Dim Message As String = Nothing
            Dim PEPProd As New PEPProduct.PEPProductSoapClient("PEPProductSoap", "http://localhost:43677/PEPProduct.asmx")

            For Each row As DataRow In tbl.Rows
                System.Net.ServicePointManager.Expect100Continue = False


                Me.ErrorMessage.Text = ""
                '  Exit Sub

                Dim GatewayId As Integer = Nothing
                Dim ProductCode As String = Nothing
                Dim msg As String = ""
                Try
                    If PEPProd.AuthenticateUser(row("WebUserName"), row("WebUserPassword"), ProductCode, GatewayId, Message) Then
                        msg = "SID:" & row("SubscriberId") & " Gateway:" & GatewayId & " Prod:" & ProductCode

                    Else
                        msg = "SID:" & row("SubscriberId") & " AuthenticateUser Failed:" & Message
                        'MsgBox("Failed")
                    End If
                Catch ex As Exception
                    msg = "SID:" & row("SubscriberId") & " Failed:" & ex.Message

                End Try
                outputFile.WriteLine(msg)
                AddProgressMsg(msg)
            Next

        Catch ex As Exception
            AddProgressMsg(ex.ToString)
            Me.ErrorMessage.Text = ex.ToString
        Finally
            outputFile.Close()
        End Try
    End Sub

    Private Sub DoJSON_Click(sender As Object, e As EventArgs) Handles DoJSON.Click
        RefreshDB()
        AddProgressMsg("DoJSON_Click started")


        Try
            Dim jwt As String = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJleHAiOjE1MDY2NjU0OTQsImltbWZhX2lkIjoyODcsImVtYWlsIjoiaXJpc3IyQGRlc2lnbnNlZWRzLmNvLnVrIiwibmFtZSI6IklSSVMgUmVwb3J0ZXIgbGV2ZWwgMiIsImlyaXNfcm9sZXMiOlsiSVJJU19SRVBPUlRFUl9MMiJdfQ.BWa6IVxpPdKhctradjtTr6EvyeS5Ob1T0aK-Lq24ggJ0OP5FcJGwM8-h3usvgvqBjsaSOWscd5wmyIurLbKc_pK4zokLIKGliJtdA3Wx3gLLrsCeidx0-6v-emhX3w2eTP-56XIw0ZCJ2zVQypshV5FEGIBtxzsJ1g2JAdpwXXvYF9rRrfBlobcgQ3Iv4QqwRgm8vYuP0ZbD2VJUtbRhzLnJrMAWtw-DmNP8kbpJZjWkqINhfd2cvZdgiM0I7SDQNZ9quaZLv-jk-LRJ8o4MGuy1Pa0MllNkuGwUJqiT6y2FhYnK1CIhxZKXirmhjN9RLU0JrBzak6XBBBuliSi6pg"
            Dim privatekey As String = "MIICXQIBAAKBgQC+xGvYKFYVnc0MTolFD8CCWpXvTJaFXnejG/2080MrcFm/Nupe
Qe8XtZe2107oj44+4WX2coP0qgt9CJrVnw/Pfj973wPdaLZxdc6NgJ+8S2BJngYn
gGkgYQvLctuk4Mje5cDWbKkJsPnBskDfu8l0U0luBuJh9vE6YGI4DlDwgwIDAQAB
AoGAI7LOG50wvsrQ3ES2G15fQAWDmUxTvpF3AebzCzGamD5mDQpRwWHFREKPKYAR
HCQBEnNLiVrUpqxLihJaJy+k3XSXy9bWa8NfdxvDgyN1Yrh1FaS7hlPo9C39jrjO
qnEvtqQaB2qUTyo/OzGC5e9mMOxMI5eoUc8zb3e3tqB64IECQQDk8igNWArCTFdw
65JZu7X1+zpdhNKzVpyXvA9Gem9Xv+5wzU5Mb1flmtTGgrB7mampKR0yJOwyTHV+
snVKEZQJAkEA1U9SgvhrE7o01mhuZgDJF5yKdGpjrNuSgPehp9eKCWhLuOdEkIil
TNLfNkL0lppTi/Y8YO6xOkObZswEZAc7KwJAaAhxkr6zBN9TzIf/FK9rW78xIlW8
uKletsRJ3Ki9943Ld46TScA+nKLilOHF+CQ3KBr6nVKR0blUmqHVEjcyoQJBAIQq
7QYnpDkJ9DkxZc4gCHlvzj4JuY7eUe1FAk37+BSSIfEEovAnKrzqH9IANIqoPsIH
JSwuWXOvdjeAi+vqqxcCQQCGHhs2VGi2LMm7AWPX+febCQhtdml1J5plsb33c5u0
FsGGfzRaoHfKwHmhrbBN4Jss1fihco98znOs8r5djeH7"
            Dim publickey As String = "-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC+xGvYKFYVnc0MTolFD8CCWpXv
TJaFXnejG/2080MrcFm/NupeQe8XtZe2107oj44+4WX2coP0qgt9CJrVnw/Pfj97
3wPdaLZxdc6NgJ+8S2BJngYngGkgYQvLctuk4Mje5cDWbKkJsPnBskDfu8l0U0lu
BuJh9vE6YGI4DlDwgwIDAQAB
-----END PUBLIC KEY-----"

            Dim j As New BusinessLogic.JWTToken(jwt)
            'privatekey = privatekey.Replace(Environment.NewLine, "")
            'publickey = publickey.Replace(Environment.NewLine, "")
            Me.ProgressLog.Text = j.test(publickey, privatekey)
            Exit Sub




            Dim bj As New BusinessLogic.BatchJob(db)
            bj.SubmittedByUserSessionId = New Guid("11111111111111111111111111111111")
            bj.CreateBatchJobEntry("RepopulateAllPEPWebContent", db)
            Exit Sub
            Dim pc As New BusinessLogic.PEPwebContent(db)
            pc.RepopulateVolumesAndDocs()
            Exit Sub
            Dim vols As DataTable = pc.GetContentTable(BusinessLogic.PEPwebContent.ContentTypes.Volumes, "IJP", "limit=20000")
            vols.TableName = "Volumes"
            pc.AddToLocalContentTableFromTable(BusinessLogic.PEPwebContent.ContentTypes.Volumes, vols, False)

            For Each r2 As DataRow In vols.Rows
                Dim docs As DataTable = pc.GetContentTable(BusinessLogic.PEPwebContent.ContentTypes.Documents, "IJP" & "/" & r2("vol"))
                docs.TableName = "Documents"
                pc.AddToLocalContentTableFromTable(BusinessLogic.PEPwebContent.ContentTypes.Documents, docs, False)
            Next
            Exit Sub

            pc.RepopulateLocalContentTable(BusinessLogic.PEPwebContent.ContentTypes.Journals)
            pc.RepopulateLocalContentTable(BusinessLogic.PEPwebContent.ContentTypes.Books)
            pc.RepopulateLocalContentTable(BusinessLogic.PEPwebContent.ContentTypes.Videos)
            '     Exit Sub
            pc.RepopulateVolumesAndDocs()
            Exit Sub



            Dim webReq As System.Net.HttpWebRequest
            Dim response As System.Net.HttpWebResponse = Nothing
            Dim reader As IO.StreamReader

            'webReq = System.Net.WebRequest.Create("http://headers.jsontest.com/")
            webReq = System.Net.WebRequest.Create("http://api.psybrarian.com/v2/Metadata/Journals/")
            'http://api.psybrarian.com/v2/Metadata/Journals/
            ' webReq = System.Net.WebRequest.Create("http://www.pep-web.org/api/v1/Metadata/Journals/")
            webReq.UserAgent = "PaDS"

            webReq.Method = "GET"


            response = webReq.GetResponse()

            reader = New IO.StreamReader(response.GetResponseStream())

            Dim rawresp As String
            rawresp = reader.ReadToEnd()
            Dim xxx As Object = Newtonsoft.Json.JsonConvert.DeserializeObject(rawresp)
            Me.ProgressLog.Text = "" 'xxx.ToString
            Dim rss As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(rawresp)
            For Each x As Newtonsoft.Json.Linq.JToken In rss.Children
                '  Me.ProgressLog.Text += Environment.NewLine & x.ToString

            Next
            Dim Journals = From p In rss("sourceInfo")("responseSet")
                           Select sourceType = p("sourceType"),
                                    PEPCode = p("PEPCode"),
                                    bannerURL = p("bannerURL"),
                                    displayTitle = p("displayTitle"),
                                    srcTitle = p("srcTitle"),
                                    title = p("title"),
                                    abbrev = p("abbrev"),
                                    ISSN = p("ISSN"),
                                    language = p("language"),
                                    yearFirst = p("yearFirst"),
                                    yearLast = p("yearLast"),
                                    embargoYears = p("embargoYears")


            For Each Journal In Journals

                Me.ProgressLog.Text += Environment.NewLine & Journal.ISSN.ToString

                'For Each col In Journal
                '    Me.ProgressLog.Text += Environment.NewLine & col.ToString

                'Next
            Next
        Catch exweb As Net.WebException
            Dim res As Net.WebResponse = exweb.Response
            Dim str As IO.Stream = res.GetResponseStream
            Me.ProgressLog.Text += New IO.StreamReader(str).ReadToEnd



        Catch ex As Exception
            AddProgressMsg(ex.ToString)
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub

    Private Sub SubmitRepopAllContent_Click(sender As Object, e As EventArgs) Handles SubmitRepopAllContent.Click
        RefreshDB()
        AddProgressMsg("SubmitRepopAllContent_Click started")


        Try
            Dim bj As New BusinessLogic.BatchJob(db)
            bj.SubmittedByUserSessionId = New Guid("11111111111111111111111111111111")
            bj.CreateBatchJobEntry("RepopulateAllPEPWebContent", db)
        Catch ex As Exception
            AddProgressMsg(ex.ToString)
            Me.ErrorMessage.Text = ex.ToString
        End Try

    End Sub

    Private Sub DeleteAddBaseContentData_Click(sender As Object, e As EventArgs) Handles DeleteAddBaseContentData.Click
        RefreshDB()
        Dim pt As New PaDSTesting(db)
        Try
            db.BeginTran()
            Try
                pt.DeleteBaseContentSets()
                pt.CreateBaseContentSets()
                AddProgressMsg(pt.ProgressMessage)
                db.CommitTran()
            Catch ex As Exception
                db.RollbackTran()
                Throw ex
            End Try


        Catch ex As Exception
            AddProgressMsg(pt.ProgressMessage)
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub

    Private Sub BuildTriggers_Click(sender As Object, e As EventArgs) Handles BuildTriggers.Click
        RefreshDB()
        Dim psu As New BusinessLogic.PaDSSupportUtilities(db)
        Dim msg As String = ""
        Try
            psu.BuildTriggers(db.GetParameterValue("SQLFileDirectory"), Me.TestDataDirectory.Text, "PaDS", msg)
            AddProgressMsg(msg)


        Catch ex As Exception
            AddProgressMsg(msg)
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub

    Private Sub ReportAPI_Click(sender As Object, e As EventArgs) Handles ReportAPI.Click
        RefreshDB()
        Dim psu As New BusinessLogic.PaDSSupportUtilities(db)
        Dim msg As String = ""
        Try
            Dim bj As New BusinessLogic.BatchJob(db)
            bj.SubmittedByUserSessionId = New Guid("11111111111111111111111111111111")
            bj.CreateBatchJobEntry("GetPEPWebSessionLog", db)
            Me.RunNextbatchJob_Click(sender, e)

            AddProgressMsg(msg)


        Catch ex As Exception
            AddProgressMsg(msg)
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub

    Private Sub TableToJSONandBack_Click(sender As Object, e As EventArgs) Handles TableToJSONandBack.Click

        RefreshDB()
        Dim psu As New BusinessLogic.PaDSSupportUtilities(db)
        Dim msg As String = ""
        Try
            Dim t As DataTable = db.GetDataTableFromSQL("select top 5 * from lookup")
            t.TableName = "Lookup"
            Dim d As New DataSet
            d.Tables.Add(t)
            Dim s As String = Newtonsoft.Json.JsonConvert.SerializeObject(d)



            AddProgressMsg("******JSON********")
            AddProgressMsg(s)
            Dim o As Object = Newtonsoft.Json.JsonConvert.DeserializeObject(s)
            Dim data As DataSet = Newtonsoft.Json.JsonConvert.DeserializeObject(Of DataSet)(s)
            AddProgressMsg("******JSON********")
            For Each t2 As DataTable In data.Tables
                AddProgressMsg("Table:" & t2.TableName & " Rows;" & t2.Rows.Count)

                For Each r As DataRow In t2.Rows

                Next
            Next
            ''     Dim t2 As DataTable = CType(Newtonsoft.Json.JsonConvert.DeserializeObject(s), DataTable)

            AddProgressMsg(msg)


        Catch ex As Exception
            AddProgressMsg(msg)
            Me.ErrorMessage.Text = ex.ToString
        End Try
    End Sub
End Class
