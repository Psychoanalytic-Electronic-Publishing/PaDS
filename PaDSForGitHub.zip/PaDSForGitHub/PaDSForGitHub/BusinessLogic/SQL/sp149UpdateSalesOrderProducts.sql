if exists (select * from dbo.sysobjects where id = object_id(N'sp149UpdateSalesOrderProducts') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp149UpdateSalesOrderProducts
Go
CREATE PROCEDURE sp149UpdateSalesOrderProducts(
			@OrderNumber INT
			,@ProductCode VARCHAR(10)
			,@Included BIT
			,@ProductRateId INT
			,@Quantity INT
			,@UserName20 VARCHAR(20)
			,@IncludesAssociatedProduct BIT=0
			)				
AS
/**********************************************
Modifications
=============
06/05/20	Julian Gates Add  Initial Version
2/11/20		James Woosnam	SIR5145 - Populate rates correctly
***********************************************/
DECLARE @Message VARCHAR(MAX)
 

	DECLARE @PrimaryProductCode VARCHAR(10)
			,@ProductRate MONEY
			 ,@AssociatedProductCode VARCHAR(10)
			,@AssociatedProductRate MONEY
			,@AssociatedProductRateId INT
			,@DeliveryAddressId INT
			,@SubscriberId INT
			,@PrimaryhasAssociated BIT
	SELECT
		@PrimaryProductCode = p.ProductCode 
		,@ProductRate  = pr.ProductRate 
		,@AssociatedProductCode = assp.ProductCode 
		,@AssociatedProductRate  = assPr.ProductRate 
		,@AssociatedProductRateId  = assPr.ProductRateId
		,@DeliveryAddressId = ISNULL(s.DefaultPostalAddressId ,(SELECT MAX(SubscriberAddressId) FROM SubscriberAddress sa WHERE sa.AddressType = 'Postal' and sa.AddressDescription IN ('Main','Billing')))
		,@SubscriberId = so.SubscriberId 
		,@PrimaryhasAssociated = CASE WHEN assp.ProductCode IS NULL THEN 0 ELSE 1 END
 FROM Product p
		INNER JOIN SalesOrder so
			INNER JOIN Subscriber s
			ON s.SubscriberId = so.SubscriberId 
		ON so.OrderNumber = @OrderNumber 
		LEFT JOIN ProductRate pr
		ON pr.ProductRateId = @ProductRateId 
		AND pr.ProductCode = p.ProductCode 
		LEFT JOIN Product assP
		ON assP.ProductCode = p.AssociatedProductCode 
		LEFT JOIN ProductRate assPR
		ON assPr.ProductCode = assP.ProductCode 
		AND assPR.AccountType = pr.AccountType 
		AND assPR.DeliveryArea  = pr.DeliveryArea 
		AND assPR.RateType  = pr.RateType 
		AND assPR.SubscriberCategory  = pr.SubscriberCategory 
		AND assPR.CurrencyCode  = pr.CurrencyCode 
WHERE p.ProductCode = @ProductCode 		
IF @Included = 0
BEGIN
	DELETE FROM SalesOrderLine WHERE ProductCode IN ( @ProductCode,@AssociatedProductCode ) AND OrderNumber = @OrderNumber 
END
ELSE
BEGIN
	IF @PrimaryProductCode IS NULL
	BEGIN
		SELECT @Message = 'PrimaryProductCode not found. O:' + CAST(@OrderNumber as varchar)
		RAISERROR ('%s', 18, 1,@Message)
	END
	IF @ProductRate  IS NULL
	BEGIN
		SELECT @Message = 'PrimaryProductRate not found'
		RAISERROR ('%s', 18, 1,@Message)
	END
	IF @AssociatedProductCode IS NULL AND @IncludesAssociatedProduct =1 AND @PrimaryhasAssociated=1
	BEGIN
		SELECT @Message = 'Associated product code not found, when @IncludesAssociatedProduct=1'
		RAISERROR ('%s', 18, 1,@Message)
	END
	IF @AssociatedProductRate   IS NULL  AND @IncludesAssociatedProduct =1 AND @PrimaryhasAssociated=1
	BEGIN
		SELECT @Message = 'AssociatedProductRate not found'
		RAISERROR ('%s', 18, 1,@Message)
	END

	IF EXISTS(SELECT OrderNumber FROM SalesOrderLine WHERE ProductCode = @ProductCode AND OrderNumber = @OrderNumber )
	BEGIN
		UPDATE SalesOrderLine 
		SET ProductRateId = @ProductRateId 
			,ProductRate = @ProductRate
			,Quantity = @Quantity
			,AmountProduct = @ProductRate * @Quantity
		WHERE ProductCode = @ProductCode 
		AND OrderNumber = @OrderNumber
	END
	ELSE
	BEGIN
		INSERT INTO SalesOrderLine (
			OrderNumber,
			SubscriberId,
			ProductCode,
			ProductRateId,
			DeliveryAddressId,
			ProductRate,
			Quantity,
			AmountProduct,
			CreatedDateTime,
			CreatedByUserId,
			LastUpdatedDateTime,
			LastUpdatedByUserId
		)
		SELECT
			OrderNumber = @OrderNumber ,
			SubscriberId = @SubscriberId ,
			ProductCode = @ProductCode ,
			ProductRateId = @ProductRateId ,
			DeliveryAddressId = @DeliveryAddressId ,
			ProductRate = @ProductRate,
			Quantity = @Quantity,
			AmountProduct = @ProductRate * @Quantity,
			CreatedDateTime = GetDate(),
			CreatedByUserId = @UserName20,
			LastUpdatedDateTime = GETDATE(),
			LastUpdatedByUserId = @UserName20

	END
	IF @Included = 1 AND @IncludesAssociatedProduct = 1 AND @AssociatedProductCode IS NOT NULL
	BEGIN
		IF EXISTS(SELECT OrderNumber FROM SalesOrderLine WHERE OrderNumber = @OrderNumber AND ProductCode = @AssociatedProductCode  )
		BEGIN
			UPDATE SalesOrderLine 
			SET DeliveryAddressId = @DeliveryAddressId 
				,ProductRateId = @AssociatedProductRateId 
				,ProductRate = @AssociatedProductRate
				,Quantity = @Quantity
				,AmountProduct = @AssociatedProductRate * @Quantity
			WHERE ProductCode  = @AssociatedProductCode 
			AND OrderNumber = @OrderNumber
		END
		ELSE
		BEGIN
			INSERT INTO SalesOrderLine (
				OrderNumber,
				SubscriberId,
				ProductCode,
				ProductRateId,
				DeliveryAddressId,
				ProductRate,
				Quantity,
				AmountProduct,
				CreatedDateTime,
				CreatedByUserId,
				LastUpdatedDateTime,
				LastUpdatedByUserId
			)
			SELECT
				OrderNumber = @OrderNumber ,
				SubscriberId = @SubscriberId ,
				ProductCode = @AssociatedProductCode  ,
				ProductRateId = @AssociatedProductRateId  ,
				DeliveryAddressId = @DeliveryAddressId ,
				ProductRate = @AssociatedProductRate ,
				Quantity = @Quantity,
				AmountProduct = @AssociatedProductRate * @Quantity,
				CreatedDateTime = GetDate(),
				CreatedByUserId = @UserName20,
				LastUpdatedDateTime = GETDATE(),
				LastUpdatedByUserId = @UserName20

		END
	END
	IF @IncludesAssociatedProduct = 0 AND @AssociatedProductCode IS NOT NULL
	BEGIN
		DELETE FROM SalesOrderLine WHERE OrderNumber = @OrderNumber AND ProductCode = @AssociatedProductCode 
	END
END
GO

GRANT EXECUTE ON sp149UpdateSalesOrderProducts TO PaDSSQLServerUser
