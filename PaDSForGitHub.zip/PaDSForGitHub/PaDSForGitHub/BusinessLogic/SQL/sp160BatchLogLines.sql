if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp160BatchLogLines]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].sp160BatchLogLines
GO

CREATE  PROCEDURE sp160BatchLogLines(
				@BatchLogId VARCHAR(20)
				,@RecordsRequired INT   = 50 	--Number of recods to return
				,@ReturnTotalRecordCount INT = 0 --1 if we need to count all records
				)
AS
-- =============================================
-- Author:		Julian Gates
-- Create date: 21 Feb 2011
-- Description:	GetsBatchLogLinesList
-- Modification History
-- =============================================
set nocount on
set arithignore on
DECLARE @ReturnError INT
DECLARE @From VARCHAR(2000)
DECLARE @Where VARCHAR(2000)
DECLARE @Columns VARCHAR(2000)
DECLARE @SQL VARCHAR(4000)
DECLARE @LF Varchar(5)
DECLARE @Records INT
DECLARE @RecordCount INT

SET @LF = CHAR(13) + CHAR(10)
SET @Where ='WHERE 1=1
			AND BatchLogLine.BatchLogId=' + CAST(@BatchLogId as VARCHAR)

-- Filter on paramaters, if passed in

SET @From = '		
	FROM BatchLogLine      
		LEFT JOIN BatchLogLine PrevBatchLogLine     
		ON PrevBatchLogLine.BatchLogId = BatchLogLine.BatchLogId     
		AND PrevBatchLogLine.BatchLogLineId = (Select Max(BatchLogLineId)                                     
		FROM BatchLogLine bll                                    
		WHERE bll.BatchLogId = BatchLogLine.BAtchLogId                                     
		AND bll.BatchLogLineId < BatchLogLine.BatchLogLineId) 
	 ' 
	+ @Where

IF @ReturnTotalRecordCount = 1
BEGIN
	--Count records into Temp table
	CREATE TABLE #RecordCount(RecordCount INT)

	SET @SQL = '
	INSERT INTO #RecordCount
	SELECT (SELECT Count1=COUNT(*)  

				FROM (Select 1 Num ' + @From + ') ResultSet)
	'			
	execute (@SQL)
	SELECT @RecordCount = RecordCount
	FROM #RecordCount
END
ELSE
BEGIN
	SELECT @RecordCount = -1
END
Print 100
Print @SQL
--select columns to show
SELECT @Columns = '
	SELECT  Top '  + CAST(@RecordsRequired as VARCHAR) + '
		TotalRecordCount = ' + CAST(@RecordCount as VARCHAR) 

		
SET @Columns = @Columns + '
		, BatchLogLine.DateTime      
	,LastLineLogTime = IsNull(PrevBatchLogLine.DateTime,BatchLogLine.DateTime)      
	,BatchLogLine.BatchLogLineText  

'

SET @From = @From + '
		ORDER BY BatchLogLine.DateTime,BatchLogLine.BatchLogLineId'

--Now Run the query
SET @SQL =  @Columns
			+ @From
print @SQL
execute (@SQL)
SELECT @ReturnError = @@Error, @Records= @@ROWCOUNT 
IF @ReturnError <> 0
BEGIN
	SELECT ReturnError=@ReturnError
		,ReturnMessage=master..sysmessages.description 
		from master..sysmessages where error=@returnerror
	RETURN
END	
set nocount off
set arithignore off

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO