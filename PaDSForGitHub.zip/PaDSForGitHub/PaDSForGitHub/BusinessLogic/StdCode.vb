Imports System.Data
Imports System.Text.RegularExpressions
Public Class StdCode
    'Modifications
    '=============
    '23/8/05    James Woosnam   Change to HH 24 hour clock in vFQ
    '23/8/05    James Woosnam   Add ReadRegValue
    '07/02/06   Add new dlookup with optional transaction facility
    '17/2/06    James Woosnam   un-comment original dlookup so that the two version overload, this makes compiling with previous version easiler
    '19/06/06   Julian Gates    Add IsValidEmail to Validate an Email Address as syntactically valid 
    '04/07/06   Julian Gates    Add IsValidEmail as modification
    '23/11/06   Julian Gates    Add ExportDataTableAsXLS to create a XLS file SIR509
    '03/12/15   Julian Gates    Add LookupStatus to Lookup criteria
    '20/07/16   Julian Gates    SIR4166 - Add Text.Encoding.Default to StreamWriter in ExportDataTableAsCSV

    Private strCommand As String

    Function Lookup(ByVal strLookup As String, ByRef cnt As System.Data.SqlClient.SqlConnection) As System.Data.DataView
        Dim objDataAdapter As System.Data.SqlClient.SqlDataAdapter
        Dim DataSet2 As New DataSet

        strCommand = "Select Name" _
           & " From Lookup" _
           & " WHERE Lookup.LookUpName = '" & strLookup & "'" _
           & " AND Lookup.LookupStatus = 'Active'"

        objDataAdapter = New System.Data.SqlClient.SqlDataAdapter(strCommand, cnt)
        objDataAdapter.Fill(DataSet2, "Lookup")
        Lookup = DataSet2.Tables("Lookup").DefaultView
        Return Lookup
    End Function
    Function DLookup(ByVal strColumnName As String, ByVal strTableName As String, ByVal strCriteria As String, ByRef cnt As System.Data.SqlClient.SqlConnection) As Object
        '*******************************************************************************************
        'Purpose:   Replicates the Access DLookup function
        '			Only difference is that the criteria is not optional
        '*******************************************************************************************
        '17/2/06    James Woosnam   un-comment original dlookup so that the two version overload, this makes compiling with previous version easiler
        strCommand = "Select " & strColumnName _
          & " FROM " & strTableName

        If strCriteria <> "" Then
            strCommand = strCommand & " WHERE " & strCriteria
        End If

        Dim dr As SqlClient.SqlDataReader = New SqlClient.SqlCommand(strCommand, cnt).ExecuteReader()
        If dr.Read() Then
            If IsDBNull(dr(0)) Then
                DLookup = ""
            Else
                DLookup = dr(0)
            End If
        Else
            DLookup = ""
        End If
        dr.Close()

    End Function
    Function DLookup(ByVal strColumnName As String, ByVal strTableName As String, ByVal strCriteria As String, ByRef cnt As System.Data.SqlClient.SqlConnection, ByVal Transaction As SqlClient.SqlTransaction) As Object
        '*******************************************************************************************
        'Purpose:   Replicates the Access DLookup function
        '			Only difference is that the criteria is not optional
        '*******************************************************************************************
        '26/11/05   James Woosnam   Add DBTransaction
        strCommand = "Select " & strColumnName _
          & " FROM " & strTableName

        If strCriteria <> "" Then
            strCommand = strCommand & " WHERE " & strCriteria
        End If
        Dim cmd As New SqlClient.SqlCommand(strCommand, cnt)
        If Not Transaction Is Nothing Then
            cmd.Transaction = Transaction
        End If
        Dim dr As SqlClient.SqlDataReader = cmd.ExecuteReader
        If dr.Read() Then
            If IsDBNull(dr(0)) Then
                DLookup = Nothing
            Else
                DLookup = dr(0)
            End If
        Else
            DLookup = Nothing
        End If
        dr.Close()

    End Function


    Function vFQ(ByVal vrtInValue As Object, ByVal strDataType As String) As String
        '***************************************************************************
        ' Purpose:      Takes in a vartiant and a type and returns a variant
        '               that can be used in a query criteria expresion
        ' Returns:      query expresion number
        'Mods
        '====
        '3/5/05     James Woosnam   Chnage Date to do Month-day not Day-day!!
        '23/6/05    James Woosnam   Change to differnt date format dd-MMM-yyyy hh:mm:ss
        '23/8/05    James Woosnam   Change to HH 24 hour clock in vFQ
        '06/2/06    Julian Gates    Add return null value
        '07/02/06   Julian Gates    Add BOOLEAN and DECIMAL
        '*****************************************************************
        Dim vrtSQLType
        vrtSQLType = "SQLServer"
        If vrtInValue Is System.DBNull.Value Then
            Return "NULL"
        End If
        Select Case UCase(strDataType)
            Case "NUMBER", "N"
                Return vrtInValue
            Case "DATE", "D"
                Select Case vrtSQLType
                    Case "SQLServer"
                        '                        vFQ = "'" & Year(vrtInValue) & "-" & Month(vrtInValue) & "-" & Day(vrtInValue) & " " & CDate(vrtInValue).ToString("HH:mm:ss") & "','yyyy-mm-dd hh24:mi:ss'"
                        Dim dt As Date

                        If Not IsDate(vrtInValue) Then
                            Throw New Exception("Value:" & vrtInValue & " is not a date. In vFQ")
                        Else
                            dt = CDate(vrtInValue)
                        End If
                        Return "'" & dt.ToString("dd-MMM-yyyy HH:mm:ss") & "'"
                End Select
            Case "STRING", "S"
                Return "'" & vrtInValue & "'"
            Case "BOOLEAN", "B"
                If vrtInValue = "False" Then
                    vrtInValue = 0
                Else
                    vrtInValue = 1
                End If
                Return vrtInValue
            Case "DECIMAL", "DEC"
                Return CDbl(vrtInValue)
            Case Else
                'Trace.write("SYSTEM ERROR: Invalid dataype used in vFQ:" & strDataType)
                Return ""
        End Select
        Return ""
    End Function

    Public Function BooleanForCheckbox(ByVal booleanValue As Boolean) As String
        'Outputs either "Checked" or "" depending on boolean
        If booleanValue Then
            Return "Checked"
        Else
            Return ""
        End If
    End Function
    Function IsValidDate(ByVal myDate)
        Dim blnErr

        blnErr = True
        If Not (IsDate(myDate)) Then
            blnErr = False
        Else
            myDate = CDate(myDate)
        End If

        IsValidDate = blnErr
    End Function
    Public Sub ReleaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
        Catch
        Finally
            obj = Nothing
        End Try
    End Sub
    Public Function IsNull(ByVal InDBValue As Object, ByVal ReplaceNullWith As Object) As Object
        If InDBValue Is System.DBNull.Value Then
            Return ReplaceNullWith
        Else
            Return InDBValue
        End If
    End Function
    Public Sub ExportDataTableAsCSV(ByVal dt As DataTable, ByVal FileName As String, Optional ByVal AppendRows As Boolean = False)
        '20/07/16   Julian Gates    SIR4166 - Add Text.Encoding.Default to StreamWriter in ExportDataTableAsCSV
        Dim outputFile As System.IO.StreamWriter = New System.IO.StreamWriter(FileName, AppendRows, Text.Encoding.Default)
        Try
            Dim line As String = Nothing
            If Not AppendRows Then
                'only add the header records if we are not appending
                For Each col As DataColumn In dt.Columns
                    line = line & col.ColumnName & ","
                Next
                line = Left(line, Len(line) - 1)
                outputFile.WriteLine(line)
            End If

            For Each row As DataRow In dt.Rows
                If Not row.RowState = DataRowState.Deleted Then
                    line = ""
                    For Each col As DataColumn In dt.Columns
                        line = line & GetValueForCSV(row.Item(col.ColumnName))
                    Next
                    line = Left(line, Len(line) - 1)
                    outputFile.WriteLine(line)
                End If
            Next

        Catch ex As Exception
            Throw New Exception(ex.ToString)
        Finally
            'close the file eben if there is an error
            outputFile.Close()
        End Try
    End Sub

    Private Shared Function ParseLine(ByVal oneLine As String, Optional ByVal RemoveLeadingTrailingQuotes As Boolean = False) As String()
        'Modifications
        '==============
        '25/8/05    James Woosnam   This code was sourced from Expert Exchange
        'It should deal with
        '"""quoted"",nonquoted,""comma, """"inner-quoted-comma"""", chamelean"",,after-empty"

        ' Returns an array containing the values of the comma-separated fields.

        ' This pattern actually recognizes the correct commas.
        ' The Regex.Split() command later gets text between the commas.
        Dim pattern As String = ",(?=(?:[^""]*""[^""]*"")*(?![^""]*""))"
        Dim r As System.Text.RegularExpressions.Regex = _
                New System.Text.RegularExpressions.Regex(pattern)
        Dim fieldValues As String() = r.Split(oneLine)
        'this bit removes " around test strings
        If RemoveLeadingTrailingQuotes Then
            For i As Integer = 0 To fieldValues.Length - 1
                If Len(fieldValues(i)) >= 2 Then
                    If Left(fieldValues(i), 1) = """" Then
                        fieldValues(i) = Mid(fieldValues(i), 2)
                    End If
                    If Right(fieldValues(i), 1) = """" Then
                        fieldValues(i) = Left(fieldValues(i), Len(fieldValues(i)) - 1)
                    End If
                End If
            Next
        End If
        Return fieldValues
    End Function
    Public Function ImportCSVAsDataTable(ByVal TableName As String, ByVal FileName As String) As DataTable
        '14/7/05    James Woosnam   Change how the field type is derived.
        '25/8/05    James Woosnam   Change how the field type is derived again
        '25/8/05    James Woosnam   Use new code ParseLine for CSV
        '7/9/05     James Woosnam   Handle empty file and file with no data

        Dim inFile As System.IO.StreamReader = New System.IO.StreamReader(FileName)
        Dim table As New DataTable(TableName)
        Try
            Dim line As String
            Dim fieldValues As String()

            line = inFile.ReadLine
            If line = "" Then
                Throw New Exception("File:'" & FileName & "' is empty")
            End If

            Dim headerFields = ParseLine(line)
            'Even if there are is not data we can set up the columns
            For i As Integer = 0 To headerFields.Length - 1
                'Setting the column types does not seem to work so make them all text
                'If IsDate(fieldValues(i)) And fieldValues(i).IndexOf("/") > 0 Then
                '    table.Columns.Add(headerFields(i), System.Type.GetType("System.DateTime"), "")
                'ElseIf IsNumeric(fieldValues(i)) Then
                '    table.Columns.Add(headerFields(i), System.Type.GetType("System.Double"), "")
                'Else
                table.Columns.Add(headerFields(i), System.Type.GetType("System.String"), "")
                'End If
            Next

            line = inFile.ReadLine
            Do While Not line Is Nothing
                fieldValues = ParseLine(line, True)
                Dim row As DataRow = table.NewRow

                For i As Integer = 0 To fieldValues.Length - 1
                    Try
                        If fieldValues(i).trim = "" Then
                            row.Item(i) = System.DBNull.Value
                        Else
                            Select Case table.Columns(i).DataType.ToString
                                Case "System.Double"
                                    row.Item(i) = CDbl(fieldValues(i))
                                Case "System.DateTime"
                                    row.Item(i) = CDate(fieldValues(i))
                                Case "System.String"
                                    If fieldValues(i) = "" Then
                                        row.Item(i) = System.DBNull.Value
                                    Else
                                        row.Item(i) = fieldValues(i)
                                    End If
                            End Select
                        End If

                    Catch ex As Exception
                        Throw New Exception("Error in Field:'" & headerFields(i) & "' Value:'" & fieldValues(i) & "'" & vbCrLf & ex.ToString)
                    End Try

                Next
                table.Rows.Add(row)
                line = inFile.ReadLine
            Loop

        Catch ex As Exception
            Throw New Exception(ex.ToString)
        Finally
            'close the file eben if there is an error
            inFile.Close()
        End Try
        Return table
    End Function
    Public Function GetValueForCSV(ByVal value As Object) As String
        Dim st As String = ""
        Dim dt As Date = #1/1/2000#
        Dim outValue As String
        Try
            If value Is System.DBNull.Value Then
                'Null is just a blank
                outValue = "" & ","
            ElseIf value = Nothing Then
                'If nothing put out 0 of "" depending on type
                If Object.ReferenceEquals(value.GetType(), st.GetType()) Then
                    outValue = """"","
                Else
                    outValue = "0" & ","
                End If
            Else
                If Object.ReferenceEquals(value.GetType(), st.GetType()) Then
                    'for string add "
                    outValue = """" & value & ""","
                ElseIf Object.ReferenceEquals(value.GetType(), dt.GetType()) Then
                    'for dates control the format
                    outValue = "" & Format(value, "dd/MM/yyyy HH:mm:ss") & ","
                Else
                    outValue = value & ","
                End If
            End If

        Catch ex As Exception
            'IF there is a problem just output nothing
            outValue = "" & ","
        End Try
        Return outValue
    End Function
    Function TranslatePhysicalPathToVirtualPath(ByVal PhysicalPath As String, ByVal server As Object) As String
        Dim PhysicalSitePath As String = server.MapPath("../")
        If PhysicalSitePath.ToUpper = Left(PhysicalPath, Len(PhysicalSitePath)).ToUpper Then
            Return ".." & Mid(PhysicalPath, Len(PhysicalSitePath)).Replace("\", "/")
        Else
            Return "no match"
        End If

    End Function
    Public Function IsInGroup(ByVal GroupName As String, ByVal DBConnection As SqlClient.SqlConnection) As Boolean
        '*******************************************************************************************
        'Purpose:   Returns true if the user is in the SQL group passed in.
        '*******************************************************************************************

        Dim selectSQL As String
        Dim lIsInGroup As Boolean = False
        selectSQL = "Select CASE WHEN IS_Member('" & GroupName & "') = 1" _
             & "	OR IS_Member('DB_OWNER') = 1 THEN 1 ELSE 0 END ,Current_user"
        Try
            Dim dr As SqlClient.SqlDataReader = New SqlClient.SqlCommand(selectSQL, DBConnection).ExecuteReader
            Try
                If dr.Read Then
                    If dr.Item(0) Is System.DBNull.Value Then
                        lIsInGroup = False
                    ElseIf dr.Item(0) = 1 Then
                        lIsInGroup = True
                    Else
                        lIsInGroup = False
                    End If
                End If

            Catch ex As Exception
            Finally
                dr.Close()
                dr = Nothing
            End Try
        Catch ex As Exception
            lIsInGroup = False
        End Try
        Return lIsInGroup
    End Function
    Public Function GetRandomName(ByVal Length As Int16) As String
        '*******************************************************************************************
        'Purpose:   Returns a randomly generated name.
        '*******************************************************************************************
        Dim i As Int16
        Dim characterCount As Int16 = Nothing
        Dim OutRandomeName As String = Nothing
        Randomize()
        Do While characterCount < Length
            i = CInt(Rnd(1) * 1000)
            'Check this this is an A-Z or a-z or 0-9
            Do While i < 48 Or (i > 57 And i < 97) Or i > 122
                i = CInt(Rnd(1) * 1000)
            Loop
            OutRandomeName = OutRandomeName & Chr(i)
            characterCount = characterCount + 1
        Loop

        Return OutRandomeName
    End Function
    Public Function ReadRegValue(ByVal Hive As Microsoft.Win32.RegistryHive, _
           ByVal Key As String, ByVal ValueName As String, _
        ByVal ErrInfo As String) As String
        'Modiciations
        '============
        '23/8/05    James Woosnam   Intial Version - Copied from a version sourced by Mik with beefed up error handling

        Dim objParent As Microsoft.Win32.RegistryKey = Nothing
        Dim objSubkey As Microsoft.Win32.RegistryKey = Nothing
        Dim sAns As String = Nothing
        Select Case Hive
            Case Microsoft.Win32.RegistryHive.ClassesRoot
                objParent = Microsoft.Win32.Registry.ClassesRoot
            Case Microsoft.Win32.RegistryHive.CurrentConfig
                objParent = Microsoft.Win32.Registry.CurrentConfig
            Case Microsoft.Win32.RegistryHive.CurrentUser
                objParent = Microsoft.Win32.Registry.CurrentUser
            Case Microsoft.Win32.RegistryHive.DynData
                '  objParent = Microsoft.Win32.Registry.DynData
            Case Microsoft.Win32.RegistryHive.LocalMachine
                objParent = Microsoft.Win32.Registry.LocalMachine
            Case Microsoft.Win32.RegistryHive.PerformanceData
                objParent = Microsoft.Win32.Registry.PerformanceData
            Case Microsoft.Win32.RegistryHive.Users
                objParent = Microsoft.Win32.Registry.Users

        End Select

        Try
            objSubkey = objParent.OpenSubKey(Key)
            'if can't be found, object is not initialized
            If Not objSubkey Is Nothing Then
                sAns = (objSubkey.GetValue(ValueName))
            End If

        Catch ex As Exception

            Throw New Exception("Error getting registry key:'" & Key & "' ValueName:'" & ValueName & "'" & vbCrLf & ex.ToString)
        Finally

            'if no error but value is empty, populate errinfo
            If ErrInfo = "" And sAns = "" Then
                Throw New Exception("No value found for requested registry key:'" & Key & "' ValueName:'" & ValueName & "'")
            End If
        End Try
        ReadRegValue = sAns
    End Function

    Public Function IsValidEmail(ByVal inputEmailAddress As String) As Boolean
        '*******************************************************************************************
        'Purpose:   Validates a Email Address as syntactically valid 
        '*******************************************************************************************
        Dim strRegex As String
        Dim MyRegex As Regex

        strRegex = "^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" _
               & "\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" _
               & ".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"

        MyRegex = New Regex(strRegex)

        If (MyRegex.IsMatch(inputEmailAddress)) Then
            Return True
        Else
            Return False
        End If
    End Function
    '28/11/2006  Julian Gates   Add new ExportDataTableAsXLS to export data to XLS file using SpreadsheetGear SIR509
    'Public Sub ExportDataTableAsXLS(ByVal dt As DataTable, ByVal FileName As String, ByVal fileNameXLSTemplate As String)
    '    Dim i As Integer
    '    Dim workbook As SpreadsheetGear.IWorkbook = SpreadsheetGear.Factory.GetWorkbook(fileNameXLSTemplate)
    '    Dim worksheet As SpreadsheetGear.IWorksheet = workbook.Worksheets("Sheet1")

    '    worksheet.Name = "Exported Data"
    '    Try
    '        For col As Integer = 0 To dt.Columns.Count - 1
    '            worksheet.Cells(0, col).Value = dt.Columns(col).ColumnName
    '        Next
    '        i = 0
    '        For row As Integer = 0 To dt.Rows.Count - 1
    '            If Not dt.Rows(row).RowState = DataRowState.Deleted Then
    '                For col As Integer = 0 To dt.Columns.Count - 1
    '                    worksheet.Cells(i + 1, col).Value = CStr(Me.IsNull(dt.Rows(row)(col), ""))
    '                Next
    '                i = i + 1
    '            End If
    '        Next
    '        workbook.SaveAs(FileName, SpreadsheetGear.FileFormat.XLS97)
    '    Catch e As Exception
    '        Throw New Exception(e.ToString)
    '    End Try
    'End Sub
    Function GetFileText(ByVal FileName As String) As String
        Try
            Dim reader As System.IO.StreamReader
            reader = New System.IO.StreamReader(FileName, System.Text.Encoding.Default)
            Try
                Return reader.ReadToEnd()
            Catch ex As Exception
                Throw ex
            Finally
                reader.Close()
            End Try
        Catch ex As Exception
            Throw New Exception("Failed to get text:" & ex.Message)
            Return ""
        End Try
    End Function
    Public Function RemoveNonNonFileNameFriendlyCharacters(sIn As String) As String
        '2/3/20     James Woosnam   SIR5030 - remove non alphanumeric to get link working
        '14/2/21    James Woosnam   Allow - for date seperator
        Dim sOut As String = sIn
        For i = 0 To sIn.Length - 1
            If "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ -".Contains(sIn.Substring(i, 1).ToUpper) Then
                'OK
            Else
                sOut = sOut.Replace(sIn.Substring(i, 1), "")
            End If
        Next
        Return sOut
    End Function
    Public Function GetValueFromQueryString(QueryString As String, ParameterName As String) As String
        GetValueFromQueryString = Nothing
        If ParameterName <> "" Then
            For Each qsv As String In QueryString.Replace("?", "").Split("&")
                If qsv.Split("=")(0) = ParameterName Then
                    GetValueFromQueryString = qsv.Split("=")(1)
                    Exit For
                End If
            Next
        End If

        Return GetValueFromQueryString
    End Function
    Public Function GetIPAddressAsNumber(IPAddress As String) As Long
        Dim msg As String = Nothing
        If Not IsValidIPAddress(IPAddress, msg) Then
            Throw New Exception(msg)
        End If
        If IsNumeric(IPAddress) AndAlso Not IPAddress.Contains(".") Then
            Return CLng(IPAddress) ' IP address is just a plain number
        End If
        If IPAddress = "::1" Then Return 1 ' local server
        Dim sOut As String = ""
        Dim sParts() As String = IPAddress.Split(".")
        For Each pt As String In sParts
            sOut += "1" & CInt(pt).ToString("000")
        Next
        Return CLng(sOut)  'If sOut hasn't been set to anything other than "" then this will error which means IsValidIPAddress isn't working correctly
    End Function
    Public Function IsValidIPAddress(IPAddress As String, Optional ByRef Msg As String = Nothing) As Boolean
        Dim ISValid As Boolean = True
        If IPAddress = "" Then
            Msg = "IP Address not populated"
            Return False
        End If
        If IPAddress = "::1" Then Return True ' local server
        Dim sParts() As String = IPAddress.Split(".")
        If sParts.Length <> 4 Then
            ISValid = False

        End If
        For Each pt As String In sParts
            If pt.Length > 3 Or pt.Length = 0 Then
                Msg += "Each number must be no more than 3 digits in :" & IPAddress
                ISValid = False
            End If
            If Not IsNumeric(pt) Then
                Msg += "Part:'" & pt & "' is not a valid number in :" & IPAddress
                ISValid = False
            End If
        Next
        Return ISValid
    End Function
    Public Function GetIPAddress(Req As System.Web.HttpRequest) As String
        '29/9/20    James Woosnam   If request is coming through Amazon load ballancer then then IP address is in X-Forwarded-For header not UserHostAddress
        Dim IPAddress As String = ""
        'X-Forwarded-For-PEP was added by Gavant as there initial call comes from their server not the client
        IPAddress = Req.Headers("X-Forwarded-For-PEP")
        If Not IsValidIPAddress(IPAddress) Then
            IPAddress = Req.Headers("X-Forwarded-For")
            '2/3/21 James Woosnam   If X-Forwarded-For populated with comma separated list, get the  first one as his should be the original client
            If IPAddress IsNot Nothing AndAlso IPAddress.Split(",").Count > 0 Then
                IPAddress = IPAddress.Split(",")(0)
            End If
        End If
        If Not IsValidIPAddress(IPAddress) Then IPAddress = Req.UserHostAddress

        Return IPAddress
    End Function
End Class

