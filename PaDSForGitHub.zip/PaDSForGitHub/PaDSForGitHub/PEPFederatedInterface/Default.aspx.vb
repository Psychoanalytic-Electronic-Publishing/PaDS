﻿Imports System.Net
Imports System.Security.Claims
Imports BusinessLogic

Public Class _Default
    Inherits Page
    ReadOnly Property SM As SiteMaster
        Get
            Return CType(Me.Master, SiteMaster)
        End Get
    End Property
    ReadOnly Property Db As Database
        Get
            Return SM.Db
        End Get
    End Property
    Enum PageModes
        Standard
        EnvokeFederatedLogon
        ReturnFromFederated
    End Enum
    Dim PageMode As PageModes = PageModes.Standard
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        Dim RedirectToURL As String = Nothing
        Try
            SM.Initialise(False) 'In some instances this is rerun below to reset the cookie 
            Dim SessionLogComment As String = ""
            Try
                Dim PEPwebURL As String = Db.GetParameterValue("PEPWeb2021URL")
                SessionLogComment += "IsAuthenticated=" & Request.IsAuthenticated.ToString & Environment.NewLine
                SessionLogComment += "FederatedEntity=" & Request.QueryString("FederatedEntity") & Environment.NewLine
                If Not Request.IsAuthenticated AndAlso Request.QueryString("iss") <> "" Then
                    'have returned from openAthens after a non Default redirect 
                    SessionLogComment += "Comment=" & "Returned from openAthens after a non Default redirect" & Environment.NewLine
                    HttpContext.Current.GetOwinContext().Authentication.Challenge()
                ElseIf Request.IsAuthenticated And (Request.QueryString("FederatedEntity") <> Nothing OrElse Request.QueryString("iss") <> Nothing) Then
                    'Has been authenticated at openathens and is returnig, 
                    SessionLogComment += "Comment=" & "Has been authenticated at openathens and is returnig" & Environment.NewLine
                    PageMode = PageModes.EnvokeFederatedLogon
                    Dim claims = ClaimsPrincipal.Current.Claims
                    Dim entity As String = Nothing
                    Dim scope As String = Nothing
                    Dim federatedPersonId As String = Nothing
                    For Each c As Claim In claims
                        Select Case c.Type
                            Case "realmName" 'entity
                                entity = c.Value
                            Case "derivedEduPersonScope" 'scope'
                                scope = c.Value
                            Case "eduPersonTargetedID" 'Logged on user's identity
                                federatedPersonId = c.Value
                                SM.UserSession.Data("FederatedPersonId") = federatedPersonId
                        End Select
                    Next
                    SessionLogComment += "Entity=" & entity & Environment.NewLine
                    SessionLogComment += "Scope=" & scope & Environment.NewLine
                    SessionLogComment += "FederatedPersonId=" & federatedPersonId & Environment.NewLine
                    Dim PEPSec As New PEPSecurity(Db, SM.IPAddress)
                    Dim resp As PEPSecurity.AuthenticationResponse = PEPSec.AuthenticateFromFederated(SM.UserSession, entity, scope, federatedPersonId)
                    If resp.ReasonStr = "" Then
                        If Db.DBConnection.DataSource.ToLower.Contains("zedra") Then
                            RedirectToURL = Request.ServerVariables("Path_Info").ToLower.Replace(".aspx", "").Replace("/default", "/claims.aspx") & "?UserSessionId=" & SM.UserSession.UserSessionId
                        Else
                            RedirectToURL = PEPwebURL & "?sessionId=" & SM.UserSession.UserSessionId
                        End If
                        Exit Try
                    Else
                        '  SM.PageErrorDisplay.Text = "Federated logon failed:" & resp.ReasonStr
                        Me.InfoMessage.Text = "Your login via OpenAthens has failed:" & resp.ReasonStr & " . Please use one of the links below to try again, or <a href=""" & SM.Db.GetParameterValue("PEPWeb2021URL") & """>click here</a> to return to the PEP Web site"
                        Me.InfoMessage.Visible = True
                        Me.AdminView.Visible = False
                        Exit Try
                    End If


                ElseIf Request.QueryString("FederatedEntity") <> Nothing Then
                    SM.Initialise(True) 'Reset the cookie to start new session

                    'Need to redirect to OpenAthens for authentication
                    SessionLogComment += "Comment=" & "Need to redirect to OpenAthens for authentication" & Environment.NewLine
                    Dim FederatedEntity As String = Request.QueryString("FederatedEntity")
                    If FederatedEntity.ToLower = "default" Then
                        'Default doesn't need to pass an entity
                        SM.UserSession.Data("EnvokedFederatedLogonDateTime") = Now.ToString
                        SM.UserSession.Data("EnvokedFederatedEntity") = FederatedEntity
                        HttpContext.Current.GetOwinContext().Authentication.Challenge()
                    Else
                        'need to do a redirect passing the non default entity
                        Dim ru As RemoteUser = New RemoteUser(Db).GetRemoteUserFromFederatedEntityAndScope(FederatedEntity, "", 0)
                        If ru Is Nothing Then
                            '  SM.PageErrorDisplay.Text = "Fererated Entity:" & FederatedEntity & " is not known to PaDS."
                            Me.InfoMessage.Text = "This Federated link has an entity '" & FederatedEntity & "' which is not recognised by PaDS.  An email has been sent to PaDS Admin to address this issue.  Please use one of the links below to try again, or <a href=""" & SM.Db.GetParameterValue("PEPWeb2021URL") & """>click here</a> to return to the PEP Web site"
                            Me.InfoMessage.Visible = True
                            Me.AdminView.Visible = False
                            Try
                            Dim em As New Email(SM.Db)
                                Dim msg As String = ""
                                msg = Me.InfoMessage.Text & Environment.NewLine
                                msg += "UserSessionId:<a href=""" & SM.Db.GetParameterValue("WebSiteURL") & "/Pages/pg090SessionData.aspx?" & SM.UserSession.QueryString & """>" & SM.UserSession.UserSessionId & "</a>"
                                em.SendErrorEmail("Invalid Federated Login", msg)
                            Catch ex As Exception
                            End Try
                            Exit Try
                        End If
                        SM.UserSession.Data("EnvokedFederatedLogonDateTime") = Now.ToString
                        SM.UserSession.Data("EnvokedFederatedEntity") = FederatedEntity
                        RedirectToURL = Db.GetParameterValue("OidcLogonURL") & "?entity=" & FederatedEntity
                        Exit Try
                    End If
                ElseIf Request.UrlReferrer IsNot Nothing And Request.QueryString.Count = 0 Then
                    'Only process referrer is no query strin and a referrer URL
                    SessionLogComment += "UrlReferrer=" & Request.UrlReferrer.AbsoluteUri & Environment.NewLine
                    SessionLogComment += "Comment=" & "Referrer found" & Environment.NewLine
                    Dim PEPSec As New PEPSecurity(Db, SM.IPAddress)
                    Dim resp As PEPSecurity.AuthenticationResponse = PEPSec.AuthenticateFromReferrerURL(SM.UserSession, Request.UrlReferrer.AbsoluteUri)
                    If resp.ReasonStr = "" Then
                        RedirectToURL = PEPwebURL & "?sessionId=" & SM.UserSession.UserSessionId
                        '    RedirectToURL = "http://localhost:46339/Pages/pg100HomeAdmin.aspx?UserSessionId=" & SM.UserSession.UserSessionId
                        Exit Try
                    Else
                        Me.ReferrerURLMsg.Text = resp.ReasonStr
                    End If
                End If
            Catch ex As Exception
                SessionLogComment += "UnexpectedError:" & ex.Message & Environment.NewLine
                Throw ex
            Finally
                Dim lg As New BusinessLogic.Logs(Db, SM.UserSession)
                lg.WriteSessionLog(LogType:="PageLoad",
                                 PageId:=701,
                                 PageTitle:="FederatedDefault",
                                  UserId:=SM.UserSession.UserId,
                                  UserName:=SM.UserSession.UserName,
                                 RemoteIPAddress:=SM.IPAddress,
                                 Comment:=SessionLogComment,
                                 IsReadOnlyOnSecondary:=False,
                                 IsDatabaseServerPrimaryOrSecondary:=Db.IsDatabaseServerPrimaryOrSecondary,
                                 IsWebServerPrimaryOrSecondary:=Db.IsWebServerPrimaryOrSecondary)
            End Try



        Catch ex As Exception
            Dim showFullError As Boolean = False
            Try
                showFullError = Db.ShowFullError Or Db.DBConnection.DataSource.ToLower.Contains("zedra")
            Catch ex1 As Exception
            End Try
            SM.PageErrorDisplay.Text = "Unexpected Error:" & ex.Message & IIf(showFullError, " " & ex.ToString, "")
        End Try
        If RedirectToURL <> Nothing Then
            Response.Redirect(RedirectToURL)
        End If
    End Sub
    Sub PageSetup()
        Try
            Me.SessionDetails.Text = "UserSessionId=" & SM.UserSession.UserSessionId & "  StartDate:" & SM.UserSession.StartDate.ToString("dd-MMM-yy HH:mm:ss")
            Dim lk As New HyperLink
            lk.Text = "Open Athens Invalid Entity"
            lk.NavigateUrl = Request.ServerVariables("Path_Info") & "?FederatedEntity=Invalid&UserSessionId=" 'pass blan entity for default OpenAthens
            Me.lkInvalid.Controls.Add(lk)

            'Me.Logout.Enabled = Request.IsAuthenticated

            Dim t As DataTable = Db.GetDataTableFromSQL("
                    SELECT 
	                    al.RemoteUserAutoLogonId 
	                    ,al.FederatedEntity 
	                    ,ru.UserFullName 
                        ,al.IsFederatedLinkRequired
                    FROM RemoteUserAutoLogon al
	                    INNER JOIN RemoteUser ru
	                    ON ru.UserId = al.UserId 
                    WHERE ru.UserStatus = 'Active'
                    AND al.AutoLogonStatus = 'Active'
                    AND al.AutoLogonType = 'Federated'
                    AND al.IsFederatedLinkRequired = 1
                    ORDER BY
                        ISNULL(al.IsFederatedLinkRequired,0) DESC
	                    ,ru.UserFullName 
                    ")

            Dim tr As New TableRow
            Dim tc As New TableCell
            Dim lk1 As New HyperLink
            lk1.Text = "Open Athens Direct"
            lk1.NavigateUrl = Request.ServerVariables("Path_Info") & "?FederatedEntity=Default&UserSessionId=" 'pass blan entity for default OpenAthens
            tc.Controls.Add(lk1)
            tr.Cells.Add(tc)
            Me.tbFederations.Rows.Add(tr)

            For Each r As DataRow In t.Rows
                tr = New TableRow
                tc = New TableCell
                lk = New HyperLink
                lk.NavigateUrl = Request.ServerVariables("Path_Info") & "?FederatedEntity=" & r("FederatedEntity") & "&UserSessionId="
                lk.Text = r("UserFullName")
                tc.Controls.Add(lk)
                tr.Cells.Add(tc)

                'tc = New TableCell
                'tc.Text = r("FederatedEntity")
                'tr.Cells.Add(tc)

                'tc = New TableCell
                'Dim ck As New CheckBox
                'ck.Checked = Db.IsDBNull(r("IsFederatedLinkRequired"), False)
                'tc.Controls.Add(ck)
                'tr.Cells.Add(tc)

                Me.tbFederations.Rows.Add(tr)
            Next
        Catch ex As Exception
            Dim showFullError As Boolean = False
            Try
                showFullError = Db.ShowFullError Or Db.DBConnection.DataSource.ToLower.Contains("zedra")
            Catch ex1 As Exception
            End Try
            SM.PageErrorDisplay.Text = "Unexpected Error:" & ex.Message & IIf(showFullError, " " & ex.ToString, "")
        End Try

    End Sub
    Private Sub Federated_Unload(sender As Object, e As EventArgs) Handles Me.Unload
        Try
            Db.DBConnection.Close()
            Db.DBConnection.Dispose()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub _Default_PreRender(sender As Object, e As EventArgs) Handles Me.PreRender
        Me.PageSetup()
        SM.UserSession.SessionCookie.Save(Me.Response)

    End Sub

    Private Sub _Default_Error(sender As Object, e As EventArgs) Handles Me.[Error]
        SM.HandlePageError(Me.Server.GetLastError())
    End Sub
End Class