﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web.Http

Public Module WebApiConfig
    Public Sub Register(ByVal config As HttpConfiguration)
        ' Web API configuration and services
        config.EnableCors
        ' Web API routes
        config.MapHttpAttributeRoutes()
        'config.Routes.MapHttpRoute(
        '    name:="Users",
        '    routeTemplate:="api/Users/",
        '    defaults:=New With {.controller = "Users"}
        ')
        config.Routes.MapHttpRoute(
            name:="Defaultv1Api",
            routeTemplate:="api/v1/{controller}",
            defaults:=New With {.controller = "Authenticate"}
        )
        config.Routes.MapHttpRoute(
            name:="DefaultApi",
            routeTemplate:="api/{controller}/",
            defaults:=New With {.controller = "Authenticate"}
        )
    End Sub
End Module
