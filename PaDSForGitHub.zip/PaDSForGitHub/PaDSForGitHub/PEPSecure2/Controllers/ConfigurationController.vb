﻿Imports System.Net
Imports System.Net.Http
Imports System.Web.Http
Imports BusinessLogic
Imports System.Web.Http.Cors

Namespace Controllers
    'Dec 2020   James Woosnam    - Initial Version
    <EnableCors("http://localhost:10691,http://localhost:4200,http://gavant.pep-web.rocks:4200,https://stage.pep-web.rocks,https://pep-web.rocks,https://www.pep-web.rocks,https://pep-web.org,https://www.pep-web.org", "*", "*")>
    Public Class ConfigurationController
        Inherits ApiController

        Public Class ErrorResponse
            Public ReasonId As HttpStatusCode = HttpStatusCode.OK
            Public ReasonDescription As String = Nothing
        End Class

        <HttpGet>
        Public Function GetConfiguration() As HttpResponseMessage
            Return GetConfiguration("")
        End Function

        <HttpGet>
        Public Function GetConfiguration(SessionId As String) As HttpResponseMessage
            '  Public Function GetUser(ByVal [me] As Boolean) As HttpResponseMessage
            Dim ClntConfig As New PEPSecurity.ClientConfiguration
            Dim errRes As New ErrorResponse
            Try
                If SessionId <> Nothing Then
                    'if not blank must be a valid GUID
                    Dim tryGUID As Guid = Nothing
                    If Not Guid.TryParse(SessionId, tryGUID) Then
                        ClntConfig.ReasonDescription = "SessionId is not a valid GUID"
                        Exit Try
                    End If
                End If

                Dim PaDSDB As BusinessLogic.Database = New PaDSDB().db
                Try
                    Dim pepS As New PEPSecurity(PaDSDB, New StdCode().GetIPAddress(HttpContext.Current.Request))
                    If HttpContext.Current.Request.Headers.AllKeys.Contains("X-Forwarded-For") AndAlso HttpContext.Current.Request.Headers("X-Forwarded-For") IsNot Nothing Then pepS.SessionLogExtraComment += "X-Forwarded-For:" & HttpContext.Current.Request.Headers("X-Forwarded-For")
                    ClntConfig = pepS.GetClientConfiguration(SessionId)
                    errRes.ReasonDescription = ClntConfig.ReasonDescription
                Catch ex As Exception
                    errRes.ReasonId = HttpStatusCode.Unauthorized
                    errRes.ReasonDescription = ex.Message
                Finally
                    Try
                        PaDSDB.DBConnection.Close()
                        PaDSDB.DBConnection.Dispose()
                    Catch ex As Exception
                    End Try
                End Try
            Catch ex As Exception
                '****LOG ERROR****
                errRes.ReasonDescription = "Unexpected error encountered."
                errRes.ReasonId = HttpStatusCode.InternalServerError
                Try
                    If New PaDSDB().db.ShowFullError Then
                        errRes.ReasonDescription += " ShowFullError:" & ex.Message
                    Else
                        errRes.ReasonDescription += " Set ShowFullError for more."
                    End If
                Catch ex1 As Exception
                End Try
            End Try
            '19/1/21    James Woosnam   Only do a error return for InternalServerError
            If errRes.ReasonId = HttpStatusCode.InternalServerError Then Return Request.CreateResponse(Of String)(errRes.ReasonId, errRes.ReasonDescription)

            Return Request.CreateResponse(errRes.ReasonId, ClntConfig)
        End Function


    End Class

End Namespace