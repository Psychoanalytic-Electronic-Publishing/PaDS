﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web.Http
Imports System.Web.Http.Cors

Public Module WebApiConfig
    Private Function GetAllowedOrigins() As String
        Try
            Dim PaDSDB As BusinessLogic.Database = New PaDSDB().db
            Try
                Return PaDSDB.GetParameterValue("CORSAllowedOrigins", "http://localhost:4200,http://gavant.pep-web.rocks:4200,https://localhost:4200,https://gavant.pep-web.rocks:4200,https://stage.pep-web.rocks,https://pep-web.rocks,https://www.pep-web.rocks,https://pep-web.org,https://www.pep-web.org")
            Catch ex As Exception
                Throw ex
            Finally
                Try
                    PaDSDB.DBConnection.Close()
                    PaDSDB.DBConnection.Dispose()
                Catch ex As Exception
                End Try
            End Try
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Sub Register(ByVal config As HttpConfiguration)
        ' Web API configuration and services
        Dim origins As String = GetAllowedOrigins()
        Dim cors = New EnableCorsAttribute(origins, "*", "*")
        config.EnableCors(cors)
        ' Web API routes
        config.MapHttpAttributeRoutes()
        'config.Routes.MapHttpRoute(
        '    name:="Users",
        '    routeTemplate:="api/Users/",
        '    defaults:=New With {.controller = "Users"}
        ')
        config.Routes.MapHttpRoute(
            name:="Defaultv1Api",
            routeTemplate:="api/v1/{controller}",
            defaults:=New With {.controller = "Authenticate"}
        )
        config.Routes.MapHttpRoute(
            name:="DefaultApi",
            routeTemplate:="api/{controller}/",
            defaults:=New With {.controller = "Authenticate"}
        )
    End Sub
End Module
