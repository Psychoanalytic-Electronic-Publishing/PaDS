﻿Imports System.Net
Imports System.Net.Http
Imports System.Web.Http
Imports BusinessLogic

Namespace Controllers
    'Dec 2020   James Woosnam    - Initial Version
    Public Class UserAlertsController
        Inherits ApiController

        Public Class ErrorResponse
            Public ReasonId As HttpStatusCode = HttpStatusCode.OK
            Public ReasonDescription As String = Nothing
        End Class

        <HttpGet>
        Public Function GetUserAlerts() As HttpResponseMessage
            Return GetUserAlerts("")
        End Function

        <HttpGet>
        Public Function GetUserAlerts(SessionId As String) As HttpResponseMessage
            '  Public Function GetUser(ByVal [me] As Boolean) As HttpResponseMessage
            Dim ClntConfig As New PEPSecurity.UserAlerts
            Dim errRes As New ErrorResponse
            Try
                If SessionId <> Nothing Then
                    'if not blank must be a valid GUID
                    Dim tryGUID As Guid = Nothing
                    If Not Guid.TryParse(SessionId, tryGUID) Then
                        ClntConfig.ReasonDescription = "SessionId is not a valid GUID"
                        Exit Try
                    End If
                End If
                If Not HttpContext.Current.Request.Headers.AllKeys.Contains("UserAlertSecurityKey") _
                    OrElse HttpContext.Current.Request.Headers("UserAlertSecurityKey") = "" Then
                    ClntConfig.ReasonDescription = "Header security key not found"
                    Exit Try
                End If
                Dim PaDSDB As BusinessLogic.Database = New PaDSDB().db
                Try
                    If HttpContext.Current.Request.Headers("UserAlertSecurityKey") <> PaDSDB.GetParameterValue("PEPSecureUserAlertSecurityKey") Then
                        ClntConfig.ReasonDescription = "Wrong Header security key found"
                        Exit Try
                    End If
                    Dim pepS As New PEPSecurity(PaDSDB, New StdCode().GetIPAddress(HttpContext.Current.Request))
                    If HttpContext.Current.Request.Headers.AllKeys.Contains("X-Forwarded-For") AndAlso HttpContext.Current.Request.Headers("X-Forwarded-For") IsNot Nothing Then pepS.SessionLogExtraComment += "X-Forwarded-For:" & HttpContext.Current.Request.Headers("X-Forwarded-For")
                    ClntConfig = pepS.GetUserAlerts(SessionId)
                    errRes.ReasonDescription = ClntConfig.ReasonDescription
                Catch ex As Exception
                    errRes.ReasonId = HttpStatusCode.Unauthorized
                    errRes.ReasonDescription = ex.Message
                Finally
                    Try
                        PaDSDB.DBConnection.Close()
                        PaDSDB.DBConnection.Dispose()
                    Catch ex As Exception
                    End Try
                End Try
            Catch ex As Exception
                '****LOG ERROR****
                errRes.ReasonDescription = "Unexpected error encountered."
                errRes.ReasonId = HttpStatusCode.InternalServerError
                Try
                    If New PaDSDB().db.ShowFullError Then
                        errRes.ReasonDescription += " ShowFullError:" & ex.Message
                    Else
                        errRes.ReasonDescription += " Set ShowFullError for more."
                    End If
                Catch ex1 As Exception
                End Try
            End Try
            '19/1/21    James Woosnam   Only do a error return for InternalServerError
            If errRes.ReasonId = HttpStatusCode.InternalServerError Then Return Request.CreateResponse(Of String)(errRes.ReasonId, errRes.ReasonDescription)

            Return Request.CreateResponse(errRes.ReasonId, ClntConfig)
        End Function


    End Class

End Namespace