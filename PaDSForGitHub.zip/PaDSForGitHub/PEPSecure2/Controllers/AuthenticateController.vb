﻿Imports System.Net
Imports System.Net.Http
Imports System.Web.Http
Imports BusinessLogic
Imports System.Web.Http.Cors
Namespace Controllers
    'May 2020   James Woosnam   SIR5039 - Initial Version
    '24/11/20   James Woosnam   http://localhost:4200 add to cors for Neil
    <EnableCors("http://localhost:10691,http://localhost:4200,http://gavant.pep-web.rocks:4200,https://stage.pep-web.rocks,https://pep-web.rocks,https://www.pep-web.rocks,https://pep-web.org,https://www.pep-web.org", "*", "*")>
    Public Class AuthenticateController
        Inherits ApiController
        Public Class AuthenticationRequest
            Public UserName As String
            Public Password As String
        End Class

        <HttpPost>
        Public Function AuthenticateWithSession(<FromBody> req As AuthenticationRequest) As HttpResponseMessage
            Return Me.AuthenticateWithSession(SessionId:="", req:=req)

        End Function
        <HttpPost>
        Public Function AuthenticateWithSession(SessionId As String, <FromBody> req As AuthenticationRequest) As HttpResponseMessage ' PEPSecurity.AuthenticationResponse
            Dim resp As New PEPSecurity.AuthenticationResponse
            Try
                If req Is Nothing Then
                    resp.ReasonStr = "UserName And Password can't be found in body"
                    resp.ReasonId = HttpStatusCode.BadRequest
                    Exit Try
                End If

                If req.UserName = "" Then resp.ReasonStr += IIf(resp.ReasonStr = "", "", Environment.NewLine) + "UserName must be populated"
                If req.Password = "" Then resp.ReasonStr += IIf(resp.ReasonStr = "", "", Environment.NewLine) + "Password must be populated"
                If resp.ReasonStr <> "" Then
                    resp.ReasonId = HttpStatusCode.BadRequest
                    Exit Try
                End If
                Dim PaDSDB As BusinessLogic.Database = New PaDSDB().db
                Try
                    If req.UserName.ToLower.Contains("error") Then
                        Throw New Exception("Text error found in username")
                    End If
                    If req.UserName = "SendEmail353" Then
                        Dim em As New Email(PaDSDB)
                        em.SendErrorEmail("Test In PEPSecurity", "Test")
                    End If
                    Dim pepS As New PEPSecurity(PaDSDB, New StdCode().GetIPAddress(HttpContext.Current.Request))
                    If HttpContext.Current.Request.Headers.AllKeys.Contains("X-Forwarded-For") AndAlso HttpContext.Current.Request.Headers("X-Forwarded-For") IsNot Nothing Then pepS.SessionLogExtraComment += "X-Forwarded-For:" & HttpContext.Current.Request.Headers("X-Forwarded-For")
                    Dim pepsAuthReq As New BusinessLogic.PEPSecurity.AuthenticationRequest
                    pepsAuthReq.UserName = req.UserName
                    pepsAuthReq.Password = req.Password
                    pepsAuthReq.SessionId = SessionId
                    resp = pepS.AuthenticateUser(pepsAuthReq)
                    If resp.ReasonStr <> "" Then
                        resp.ReasonId = HttpStatusCode.Unauthorized
                    End If

                Catch ex As Exception
                    Throw ex
                Finally
                    Try
                        PaDSDB.DBConnection.Close()
                        PaDSDB.DBConnection.Dispose()
                    Catch ex As Exception
                    End Try
                End Try

            Catch ex As Exception
                '****LOG ERROR****
                resp.ReasonStr = ex.Message
                Dim errMsg As String = "Unexpected error encountered."
                resp.ReasonId = HttpStatusCode.InternalServerError
                Try
                    If New PaDSDB().db.ShowFullError Then
                        errMsg += " ShowFullError:" & ex.Message
                    Else
                        errMsg += " Set ShowFullError for more."
                    End If
                Catch ex1 As Exception
                End Try
                Return Request.CreateResponse(Of String)(resp.ReasonId, errMsg)

            End Try

            Return Request.CreateResponse(resp.ReasonId, resp)
        End Function
        <Route("api/v1/Authenticate/ip")>
        <Route("api/Authenticate/ip")>
        <HttpGet>
        Public Function IP() As HttpResponseMessage
            Return Me.IPWithSession("")
        End Function
        <Route("api/v1/Authenticate/ip")>
        <Route("api/Authenticate/ip")>
        <HttpGet>
        Public Function IPWithSession(SessionId As String) As HttpResponseMessage
            Dim resp As New PEPSecurity.AuthenticationResponse
            Dim msgDebug As String = ""
            Try
                Dim PaDSDB As BusinessLogic.Database = New PaDSDB().db
                Try
                    'IPAddress cn be overridden by using the X-Forwarded-For-PEP header
                    'TESTING: the IP login is achieved by adding the IP address desired to the X-Forwarded-For-PEP header
                    Dim IPAddress As String = New StdCode().GetIPAddress(HttpContext.Current.Request)
                    Dim pepS As New PEPSecurity(PaDSDB, IPAddress)
                    If HttpContext.Current.Request.Headers.AllKeys.Contains("X-Forwarded-For") AndAlso HttpContext.Current.Request.Headers("X-Forwarded-For") IsNot Nothing Then pepS.SessionLogExtraComment += "||X-Forwarded-For:" & HttpContext.Current.Request.Headers("X-Forwarded-For")
                    Dim pepsAuthReq As New BusinessLogic.PEPSecurity.AuthenticationRequest
                    Dim ReferrerURL As String = Nothing
                    If HttpContext.Current.Request.Headers.AllKeys.Contains("ReferrerURL-For-PEP") AndAlso HttpContext.Current.Request.Headers("ReferrerURL-For-PEP") IsNot Nothing Then
                        ReferrerURL = HttpContext.Current.Request.Headers("ReferrerURL-For-PEP")
                        pepS.SessionLogExtraComment += "||ReferrerURL:" & ReferrerURL
                    End If
                    resp = pepS.AuthenticateFromIP(SessionId, IPAddress, ReferrerURL)
                    If resp.ReasonStr <> "" Then
                        resp.ReasonId = HttpStatusCode.Unauthorized
                    End If
                Catch ex As Exception
                    Throw ex
                Finally
                    Try
                        PaDSDB.DBConnection.Close()
                        PaDSDB.DBConnection.Dispose()
                    Catch ex As Exception
                    End Try
                End Try
            Catch ex As Exception
                '****LOG ERROR****
                resp.ReasonStr = ex.Message
                Dim errMsg As String = "Unexpected error encountered."
                resp.ReasonId = HttpStatusCode.InternalServerError
                Try
                    If New PaDSDB().db.ShowFullError Then
                        errMsg += " ShowFullError:" & ex.Message
                    Else
                        errMsg += " Set ShowFullError for more."
                    End If
                Catch ex1 As Exception
                End Try
                Return Request.CreateResponse(Of String)(resp.ReasonId, errMsg)

            End Try

            Return Request.CreateResponse(resp.ReasonId, resp)
        End Function





    End Class
End Namespace