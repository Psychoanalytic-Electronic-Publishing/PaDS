﻿Imports System.Net
Imports System.Net.Http
Imports System.Web.Http
Imports BusinessLogic
Public Class HomeController
    Inherits System.Web.Mvc.Controller

    Function Index() As ActionResult
        ViewData("Title") = "PaDS PEP Secure Home"
        ViewData("PaDSVersion") = New BusinessLogic.Database().PaDSVersion

        Return View()
    End Function

End Class
