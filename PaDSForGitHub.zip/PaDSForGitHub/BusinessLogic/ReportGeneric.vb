﻿'Modification History
'03/06/09  Julian Gates   Initial version
'27/6/2011      James Woosnam   Missing last row of data for pivot, need to add one row to the data.
'15/5/12        James Woosnam   SIR2725 - Create pivot against explicit source rather then defining a range first 
'15/5/12    James Woosnam       SIR2725 - .PivotCaches.Create doesn't work for EXCEL 2003 so revert to old code using PivotCaches.Add if <60,000 rows
Imports Microsoft.Office.Interop

Public Class ReportGeneric
    Inherits Report
#Region "Class Properties"
    Dim BatchJobId As Integer = Nothing
    Public TemplateName As String = ""
    Public HeaderSQL As String = ""
    Public DataSQL As String = ""
#End Region

    Public Sub New(ByVal ReportName As String, ByVal ReportType As String, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New(ReportName, ReportType, db, SubmittedByUserSessionId)
    End Sub

    Public Overloads Sub Submit(ByVal TemplateName As String, ByVal HeaderSQL As String, ByVal DataSQL As String)

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSessionId
        BatchJob.Parameters.Add("FileName", Me.FileName)
        BatchJob.Parameters.Add("ReportName", Me.ReportName)
        BatchJob.Parameters.Add("ReportType", Me.ReportType)
        BatchJob.Parameters.Add("TemplateName", TemplateName)
        BatchJob.Parameters.Add("HeaderSQL", HeaderSQL)
        BatchJob.Parameters.Add("DataSQL", DataSQL)
        BatchJob.CreateBatchJobEntry("RunReportGeneric", Me.db)

    End Sub

    Public Overloads Sub Execute(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.JobParameters = Parameters
        Me.ReportName = Parameters.GetValue("ReportName")
        Me.FileName = Parameters.GetValue("FileName")
        Me.TemplateName = Parameters.GetValue("TemplateName")
        Me.HeaderSQL = Parameters.GetValue("HeaderSQL")
        Me.DataSQL = Parameters.GetValue("DataSQL")
        Me.Execute(Me.TemplateName, Parameters.GetValue("HeaderSQL"), Parameters.GetValue("DataSQL"))
    End Sub

    Public Overloads Sub Execute(ByVal TemplateName As String, ByVal HeaderSQL As String, ByVal DataSQL As String, Optional ByVal InBatchLog As BatchLog = Nothing)
        Me.TemplateName = TemplateName
        Me.HeaderSQL = HeaderSQL
        Me.DataSQL = DataSQL
        Dim batchLogCreatedHere As Boolean = False
        If InBatchLog Is Nothing Then
            Me.BatchLog = New BatchLog("Report-" & Me.ReportName _
                                         , "FileName=" & Me.FileName _
                                         & ";TemplateName=" & Me.TemplateName _
                                         , Me.db _
                                         , BatchJobId _
                                         , Me.SubmittedByUserSessionId)
            batchLogCreatedHere = True
        Else
            Me.BatchLog = InBatchLog
        End If
        Try
            MyBase.Execute(Me.BatchLog)

            Select Case Me.ReportType
                Case "GenericPivot"
                    BuildGenericPivot()
                Case "GenericWord"
                    BuildGenericWord()
                Case "GenericCSV"
                    BuildCSV()
                Case "GenericExcel"
                    BuildExcel()
                Case Else
                    Throw New Exception("ReportType:'" & Me.ReportType & "' not supported")
            End Select
            If batchLogCreatedHere Then
                BatchLog.Update("Process Complete", "Complete")
            End If
        Catch ex As Exception
            BatchLog.Update("Report Failed:" & ex.Message, "Failed")
            Throw New Exception("Report Failed:" & ex.Message, ex)

        End Try

    End Sub

    Private Sub BuildGenericPivot()
        Dim dislpayAlters As Boolean = False

        Try
            Me.FileName += ".xlsm"
            Dim tbl As DataTable = db.GetDataTableFromSQL(Me.DataSQL)
            If tbl.Rows.Count = 0 Then
                Throw New Exception("These critieria do not produce any data")
            End If
            BatchLog.Update("SQL Table Built")
            Dim ex As New Excel.Application
            Try
                ex.DisplayAlerts = dislpayAlters

                Select Case Me.ReportName
                    Case "PEPWebStatsPost2020"
                        '263/21 James Woosnam   Get latest WebSessionLog before running usage report
                        Try
                            Dim pepConent As New PEPwebContent(db, New UserSession(Me.SubmittedByUserSessionId, db))
                            pepConent.ExecuteGetPEPWebSessionLog(BatchLog)
                        Catch ex1 As Exception
                            BatchLog.Update("ExecuteGetPEPWebSessionLog failed:" & ex1.Message)
                        End Try

                End Select


                Dim wrk As Excel.Workbook
                wrk = ex.Workbooks.Add(db.GetParameterValue("ReportTemplateDirectory") & "\" & TemplateName)
                BatchLog.Update("Workbook Created")

                ' Me.ExportDataToExcel(wrk, Me.GetSQL("Data"))
                Me.ExportDataToExcel(wrk.Worksheets("Data"), tbl)
                BatchLog.Update("Data Exported. (" & tbl.Rows.Count & " lines)")

                Me.UpdateHeaders(wrk, Me.HeaderSQL)
                BatchLog.Update("Header Data Updated")
                Try
                    wrk.Parent.Application.DisplayAlerts = dislpayAlters
                    '15/5/12    James Woosnam       SIR2725 - .PivotCaches.Create doesn't work for EXCEL 2003 so revert to old code using PivotCaches.Add if <60,000 rows
                    Dim PivotName As String = "Pivot"
                    If tbl.Rows.Count > 60000 Then
                        '15/5/12    James Woosnam       SIR2725 - Create pivot against explicit source rather then defining a range first 
                        Dim DataSource As String = "Data!R1C1:R" & tbl.Rows.Count + 1 & "C" & tbl.Columns.Count
                        With wrk.PivotCaches.Create(Excel.XlPivotTableSourceType.xlDatabase, SourceData:=DataSource, Version:=Excel.XlPivotTableVersionList.xlPivotTableVersion14)
                            .CreatePivotTable(wrk.Sheets(PivotName).Range(wrk.Sheets("Criteria").Range("PivotStart").Value), PivotName, True)
                        End With
                        wrk.Sheets("Pivot").PivotTables(PivotName).InGridDropZones = True
                    Else
                        Dim wst As Excel.Worksheet
                        wst = wrk.Sheets("Data")
                        '27/6/2011      James Woosnam   Missing last row of data for pivot, need to add one row to the data.
                        Dim rg As Excel.Range
                        rg = wst.Range(wst.Cells(1, 1), wst.Cells(tbl.Rows.Count + 1, tbl.Columns.Count))

                        With wrk.PivotCaches.Add(Excel.XlPivotTableSourceType.xlDatabase, SourceData:=rg)
                            .CreatePivotTable(wrk.Sheets(PivotName).Range(wrk.Sheets("Criteria").Range("PivotStart").Value), PivotName, True)
                        End With

                    End If
                    BatchLog.Update("Pivot Created")

                Catch ex1 As Exception
                    Throw ex1
                End Try
                '  ex.Visible = True
                Try
                    wrk.Sheets("xxxx").Delete()
                Catch ex1 As Exception
                End Try
                wrk.Sheets("Criteria").Range("FirstFormat") = 0
                'Adding a new sheet triggers a "Private Sub Workbook_NewSheet(ByVal Sh As Object)" sub in the workbook, which in turn runs the FormatPivot code
                With wrk.Sheets.Add
                    .Name = "xxxx"
                End With
                Try
                    wrk.Parent.Application.DisplayAlerts = dislpayAlters
                    wrk.Sheets("xxxx").Delete()
                Catch ex1 As Exception
                End Try

                wrk.SaveAs(Me.FullFilePath, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbookMacroEnabled)
                wrk.Close()

                BatchLog.Update("File Saved:" & Me.FileLink)
            Catch ex1 As Exception
                Throw ex1
            Finally
                Try
                    'this is a totally over the top way of doing this but becuase of the horrors of com it is the only way practical.
                    'There would be a problem if 2 people were running a report at the same time but using the service should elimitant this
                    Dim procs() As Process = System.Diagnostics.Process.GetProcessesByName("Excel")
                    For Each proc As Process In procs
                        proc.Kill()
                    Next
                Catch ex2 As Exception
                End Try
            End Try
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub BuildGenericWord()
        Dim dislpayAlters As Boolean = False

        Try
            Me.FileName += ".docx"
            Dim tbl As DataTable = db.GetDataTableFromSQL(Me.DataSQL)
            If tbl.Rows.Count = 0 Then
                Throw New Exception("These critieria do not produce any data")
            End If
            BatchLog.Update("SQL Table Built")
            Dim wrd As New Word.Application
            ' wrd.Visible = True
            Try
                wrd.DisplayAlerts = dislpayAlters

                Dim doc As Word.Document
                Try
                    doc = wrd.Documents.Add(db.GetParameterValue("ReportTemplateDirectory") & "\" & TemplateName)

                Catch ex As Exception
                    Throw New Exception("Failed to open template:" & TemplateName & " - " & ex.Message)
                End Try

                BatchLog.Update("Document Created")

                If tbl.Rows.Count > 1 Then
                    CreateRows(wrd, tbl.Rows.Count, "bkDataLine")
                    BatchLog.Update("Table rows added")
                End If

                For Each row As DataRow In tbl.Rows
                    For Each col As DataColumn In tbl.Columns
                        wrd.Selection.WholeStory()
                        wrd.Selection.Collapse(Word.WdCollapseDirection.wdCollapseStart)
                        '31/5/11    James Woosnam   BuildGenericWord - When update the detail table only update 1 occurance
                        '                           As you go round the foreach it will then move to the next line
                        Select Case col.DataType
                            Case System.Type.GetType("System.Int32"), System.Type.GetType("System.Double"), System.Type.GetType("System.Decimal")
                                If db.IsDBNull(row(col.ColumnName)) Then
                                    ReplaceWordField(wrd, col.ColumnName, "", Word.WdReplace.wdReplaceOne)
                                Else
                                    ReplaceWordField(wrd, col.ColumnName, CDbl(row(col.ColumnName)).ToString("#,##0.00"), Word.WdReplace.wdReplaceOne)
                                End If
                            Case Else
                                ReplaceWordField(wrd, col.ColumnName, IIf(db.IsDBNull(row(col.ColumnName)), "", row(col.ColumnName)), Word.WdReplace.wdReplaceOne)
                        End Select

                    Next

                Next
                BatchLog.Update("Table rows Updated")
                wrd.Selection.WholeStory()
                wrd.Selection.Collapse(Word.WdCollapseDirection.wdCollapseStart)
                Dim tblheader As DataTable = db.GetDataTableFromSQL(Me.HeaderSQL)
                If tblheader.Rows.Count > 0 Then
                    Dim row As DataRow = tblheader.Rows(0)
                    '31/5/11    James Woosnam   BuildGenericWord - When update the header table Update all occurances
                    For Each col As DataColumn In tblheader.Columns
                        Select Case col.DataType
                            Case System.Type.GetType("System.Int32"), System.Type.GetType("System.Double"), System.Type.GetType("System.Decimal")
                                If db.IsDBNull(row(col.ColumnName)) Then
                                    ReplaceWordField(wrd, col.ColumnName, "", Word.WdReplace.wdReplaceAll)
                                Else
                                    ReplaceWordField(wrd, col.ColumnName, CDbl(row(col.ColumnName)).ToString("#,##0.00"), Word.WdReplace.wdReplaceAll)
                                End If
                            Case Else
                                ReplaceWordField(wrd, col.ColumnName, IIf(db.IsDBNull(row(col.ColumnName)), "", row(col.ColumnName)), Word.WdReplace.wdReplaceAll)
                        End Select
                    Next
                End If
                BatchLog.Update("Header fields updated")


                doc.SaveAs2(Me.FullFilePath, Word.WdSaveFormat.wdFormatXMLDocument)
                '    doc.SaveAs2(Me.FullFilePath, FileFormat:=Word.WdSaveFormat.wdFormatOpenDocumentText)

                doc.Close()
                BatchLog.Update("File Saved:" & Me.FileLink)
            Catch ex1 As Exception
                Throw ex1
            Finally
                Try
                    'this is a totally over the top way of doing this but becuase of the horrors of com it is the only way practical.
                    'There would be a problem if 2 people were running a report at the same time but using the service should elimitant this
                    Dim procs() As Process = System.Diagnostics.Process.GetProcessesByName("WINWORD")
                    For Each proc As Process In procs
                        proc.Kill()
                    Next
                Catch ex2 As Exception
                End Try
            End Try
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Private Sub BuildCSV()
        Try
            Me.FileName += ".csv"
            Dim tbl As DataTable = db.GetDataTableFromSQL(Me.DataSQL)
            If tbl.Rows.Count = 0 Then
                Throw New Exception("These critieria do not produce any data")
            End If
            BatchLog.Update("SQL Table Built")

            Dim std As New BusinessLogic.StdCode

            std.ExportDataTableAsCSV(tbl, Me.FullFilePath, False)
            BatchLog.Update("Data Exported. (" & tbl.Rows.Count & " lines)")
            BatchLog.Update("File Saved:" & Me.FileLink)

        Catch ex As Exception
            Throw ex
        End Try

    End Sub
    Private Sub BuildExcel()

        Dim dislpayAlters As Boolean = False
        Try
            Me.FileName += ".xlsx"
            Dim tbl As DataTable = db.GetDataTableFromSQL(Me.DataSQL)
            If tbl.Rows.Count = 0 Then
                Throw New Exception("These critieria do not produce any data")
            End If
            BatchLog.Update("SQL Table Built")
            Dim ex As New Excel.Application
            Try
                ex.DisplayAlerts = dislpayAlters

                Dim wrk As Excel.Workbook
                wrk = ex.Workbooks.Add(db.GetParameterValue("ReportTemplateDirectory") & "\" & TemplateName)
                BatchLog.Update("Workbook Created")

                ' Me.ExportDataToExcel(wrk, Me.GetSQL("Data"))
                Me.ExportDataToExcel(wrk.Worksheets("Data"), tbl)
                BatchLog.Update("Data Exported. (" & tbl.Rows.Count & " lines)")
                wrk.Worksheets("Data").UsedRange.Columns.AutoFit()

                wrk.SaveAs(Me.FullFilePath, FileFormat:=Excel.XlFileFormat.xlOpenXMLWorkbook)
                wrk.Close()

                BatchLog.Update("File Saved:" & Me.FileLink)
            Catch ex1 As Exception
                Throw ex1
            Finally
                Try
                    'this is a totally over the top way of doing this but becuase of the horrors of com it is the only way practical.
                    'There would be a problem if 2 people were running a report at the same time but using the service should elimitant this
                    Dim procs() As Process = System.Diagnostics.Process.GetProcessesByName("Excel")
                    For Each proc As Process In procs
                        proc.Kill()
                    Next
                Catch ex2 As Exception
                End Try
            End Try
        Catch ex As Exception
            Throw ex
        End Try

    End Sub
End Class
