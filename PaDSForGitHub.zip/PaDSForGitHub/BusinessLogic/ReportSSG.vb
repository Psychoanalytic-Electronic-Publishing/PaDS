﻿'Modifications
'=============
'Feb 2018       James Woosnam   SIR4571 - Initial Version to support SpreadSheetGear Report
'30/6/21    James Woosnam   SIR5275 - Use file name as link text in GetFileLink

'Imports SpreadsheetGear
Public MustInherit Class ReportSSG

#Region "Class Properties"

    Public SubmittedByUserSessionId As Guid = Nothing
    Public ReportType As String = Nothing

    Public ExcelWorkBook As SpreadsheetGear.IWorkbook

    Dim _RandomOutputDirectory As IO.DirectoryInfo = Nothing
    Public ReadOnly Property RandomOutputDirectory As IO.DirectoryInfo
        Get
            If _RandomOutputDirectory Is Nothing Then
                _RandomOutputDirectory = New IO.DirectoryInfo(IO.Path.Combine(Me.ReportsPhysicalDir.FullName, Me.db.GetParameterValue("ReportOutDirectory"), New BusinessLogic.StdCode().GetRandomName(20)))
                If Not _RandomOutputDirectory.Exists Then _RandomOutputDirectory.Create()
            End If
            Return _RandomOutputDirectory
        End Get
    End Property
    Dim _ReportsPhysicalDir As IO.DirectoryInfo = Nothing
    Public ReadOnly Property ReportsPhysicalDir As IO.DirectoryInfo
        Get
            If _ReportsPhysicalDir Is Nothing Then
                _ReportsPhysicalDir = New IO.DirectoryInfo(db.GetParameterValue("ReportsPhysicalDir"))
                If Not _ReportsPhysicalDir.Exists Then _ReportsPhysicalDir.Create()
            End If
            Return _ReportsPhysicalDir
        End Get
    End Property
    Dim _ReportFile As IO.FileInfo = Nothing
    Public Property ReportFile As IO.FileInfo
        Get
            If Me._ReportFile Is Nothing Then
                '2/3/20     James Woosnam   SIR5030 - remove non alphanumeric to get link working
                Me._ReportFile = New IO.FileInfo(IO.Path.Combine(Me.RandomOutputDirectory.FullName, New StdCode().RemoveNonNonFileNameFriendlyCharacters(Me.ReportName) & ".xlsx"))
            End If
            Return Me._ReportFile
        End Get
        Set(ByVal value As IO.FileInfo)
            Me._ReportFile = value
        End Set
    End Property
    Public Function GetFileLink(FileName As String) As String
        Dim link As String = ""
        link = "<a href="""
        '10/1/21    James Woosnam   Add missing .xlsx
        link += IO.Path.Combine("../", Me.db.GetParameterValue("ReportOutDirectory"), Me.RandomOutputDirectory.Name, FileName & IIf(FileName.ToLower.Contains(".xlsx"), "", ".xlsx"))
        link += """ target=""blank"">"
        '30/6/21    James Woosnam   SIR5275 - Use file name as link text in GetFileLink
        link += FileName
        link += "</a>"
        Return link
    End Function


    Public ReadOnly Property FileLink As String
        Get
            Return Me.GetFileLink(Me.ReportName)
        End Get
    End Property
    Public ReadOnly Property ReportByteArray As Byte()
        Get
            If Me.ExcelWorkBook Is Nothing Then
                Throw New Exception("Need ExcelWorkBook to return ByteArray ")
            End If
            Dim memoryStream As New System.IO.MemoryStream()
            Me.ExcelWorkBook.SaveToStream(memoryStream, SpreadsheetGear.FileFormat.OpenXMLWorkbook)
            Return memoryStream.ToArray
        End Get
    End Property

    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)
            'For batch log create a new connection so the log remains even if the tans is rolled back
            Me._db = value
            Me.db.CommandTimeout = 600
        End Set
    End Property
    Private _BatchJob As BusinessLogic.BatchJob
    Public Property BatchJob() As BusinessLogic.BatchJob
        Get
            Return Me._BatchJob
        End Get
        Set(ByVal value As BusinessLogic.BatchJob)
            Me._BatchJob = value
        End Set
    End Property

    Public BatchLog As BusinessLogic.BatchLog
    Dim _JobParameters As BusinessLogic.BatchJobParameters
    Public Property JobParameters() As BusinessLogic.BatchJobParameters
        Get
            Return Me._JobParameters
        End Get
        Set(ByVal value As BusinessLogic.BatchJobParameters)
            Me._JobParameters = value
        End Set
    End Property
    Public ReadOnly Property ExcelTemplate() As IO.FileInfo
        Get
            Return New IO.FileInfo(IO.Path.Combine(Me.db.GetParameterValue("ReportTemplateDirectory"), Me.ReportName & ".xlsx"))
        End Get
    End Property
    '   Public ExcelWorkBook As SpreadsheetGear.IWorkbook
    Dim _ReportName As String
    Public Property ReportName As String
        '14/2/21    James Woosnam   Third attempt to get the file names working...
        Get
            Return _ReportName
        End Get
        Set(value As String)
            Me._ReportName = New StdCode().RemoveNonNonFileNameFriendlyCharacters(value)
        End Set
    End Property
    Public ReportSQL As String
    Public ReportSQLForTotals As String
    Dim _SubmittedByUserSession As UserSession = Nothing
    Public Property SubmittedByUserSession As UserSession
        Get
            If _SubmittedByUserSession Is Nothing Then
                _SubmittedByUserSession = New UserSession(Me.SubmittedByUserSessionId, db)
            End If
            Return _SubmittedByUserSession
        End Get
        Set(value As BusinessLogic.UserSession)

        End Set
    End Property
#End Region

    Public Sub New(ByVal ReportName As String, ByVal ReportType As String, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        Me.db = db
        Me.ReportName = ReportName
        Me.ReportType = ReportType
        Me.SubmittedByUserSessionId = SubmittedByUserSessionId
    End Sub
    'Public Sub Submit(ByVal Parameters As BusinessLogic.BatchJobParameters)

    '    Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
    '    Me.BatchJob.Parameters = Parameters
    '    Me.BatchJob.ProcessToPerform = Me.ReportName
    '    Me.BatchJob.CreateBatchJobEntry()
    'End Sub
    Public Sub Execute(ByVal BatchLog As BusinessLogic.BatchLog)
        'Delete old reports
        Dim delCount As Integer = 0
        Dim DaysToKeepReports As Integer = 14
        Try
            DaysToKeepReports = db.GetParameterValue("DaysToKeepReports")
        Catch ex As Exception
            'If no parameter then don't worry just use the 14 day default
        End Try
        For Each Dir As String In System.IO.Directory.GetDirectories(IO.Path.Combine(Me.ReportsPhysicalDir.FullName, Me.db.GetParameterValue("ReportOutDirectory")))
            Dim dirInfo As New System.IO.DirectoryInfo(Dir)
            If dirInfo.CreationTime.AddDays(DaysToKeepReports) < Now() Then
                Try
                    System.IO.Directory.Delete(Dir, True)
                    delCount += 1
                Catch ex As Exception
                    'If error don't waorry try and delete next
                End Try
            End If

        Next
        If delCount > 0 Then
            BatchLog.Update(delCount & " reports more than " & DaysToKeepReports & " days old deleted")
        End If
    End Sub


End Class
