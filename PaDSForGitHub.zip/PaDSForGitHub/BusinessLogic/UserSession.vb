﻿Imports Microsoft.VisualBasic
Imports System.Data.SqlClient
Imports System.Data
Imports System.Web
Imports System.Runtime.Remoting.Channels
'Modification History
'04/12/15   Julian Gates    SIR4012 - Modify 'This user name belongs to more then one user. Please contact support' message
'21/01/16   Julian Gates    SIR4070 - Add code to encrypt and compare remote user password
'09/10/17   Julian Gates    SIR4490 - Add pepSupportEmailLink to resend password error text.
'23/10/19   Julian Gates    SIR4943 - Add GroupRenewer AuthorityLevel
'28/10/19	James Woosnam	SIR4763 - Combine IndividualSubscribers into the RemoteUser Table
'1/11/19    James Woosnam   SIR4766 - Add support for spoof link
'13/1/20    James Woosnam   SIR4977 - Change IsProposedSubscriber to HasOrIsAProposedSubscriber in SessionData
'13/2/20    James Woosnam   SIR5017 - ensure LastLoggedOn only update if successdul logon
'17/8/20    James Woosnam   SIR5082 - Store SessionId in, and restored from, a new session cookie
'14/12/20   James Woosnam   SIR5148 - Rework create,restored & data to be all in vb to improve performance and simplify
'16/3/21    Julian Gates    SIR5213 - Add ShowCounterReports
Public Class UserSession
#Region "Class Properties"
    Public MainDataset As New DataSet
    Private strWebUserSessionId As String
    Public SessionCookie As SessionCookie = Nothing
    Public Property UserSessionId As String
        Get
            Return _UserSessionIdGUID.ToString
        End Get
        Set(value As String)
            If value = Nothing Then
                UserSessionIdGUID = Nothing
            Else
                UserSessionIdGUID = New Guid(value)
            End If
        End Set
    End Property
    Dim _UserSessionIdGUID As Guid = Nothing
    Public Property UserSessionIdGUID As Guid
        Get

            Return _UserSessionIdGUID
        End Get
        Set(value As Guid)
            _UserSessionIdGUID = value
        End Set
    End Property

    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            If Me._db Is Nothing Then
                Throw New Exception("UserSession has not been passed the database")
            End If
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)
            Me._db = value
        End Set
    End Property
    Public ReadOnly Property QueryString() As String
        Get
            '29/1/21    Build querystring each time rather than store in data as is needed before logged on
            Dim qs As String = "UserSessionId=" & Me.UserSessionId.ToString
            If Me.Data("IsSpoofSession") IsNot Nothing AndAlso Me.Data("IsSpoofSession") Then qs += "&IsSpoofSession=True"
            Return qs
        End Get
    End Property
    Public Enum UserSessionTypes
        None
        Individual
        Group
    End Enum
    Public Property UserSessionType() As UserSessionTypes
        Get
            If db.IsDBNull(Me.UserSessionrow("UserSessionType"), "") = "" Then
                Me.UserSessionrow("UserSessionType") = UserSessionTypes.None.ToString
            End If
            Return Me.UserSessionrow("UserSessionType")
        End Get
        Set(ByVal value As UserSessionTypes)
            Me.UserSessionRow("UserSessionType") = value
        End Set
    End Property
    Enum LoggedInMethods
        Individual
        IPAddress
        Federated
        ReferrerURL
        IPAddressIndividual
        FederatedIndividual
        ReferrerURLIndividual
    End Enum
    Public Property LoggedInMethod As LoggedInMethods
        Get
            If Me.Data("LoggedInMethod") Is Nothing Then Return Nothing
            Return [Enum].Parse(GetType(LoggedInMethods), Me.Data("LoggedInMethod"))
        End Get
        Set(value As LoggedInMethods)
            Me.Data("LoggedInMethod") = value.ToString
        End Set
    End Property
    Public Enum AuthorityLevels
        IndividualSubscriber = 1
        CompanyAdmins = 2
        GroupAdmins = 3
        SuperCompanyAdmins = 4
        User = 5
        GroupRenewer = 6
        GroupUser = 7 'where a PEPweb group authenticates using an IP address or feederated logon
    End Enum
    Public ReadOnly Property AuthorityLevel() As AuthorityLevels
        Get
            Dim al As AuthorityLevels = Nothing

            If [Enum].TryParse(Me.Data("AuthorityLevel"), al) Then
                Return al
            Else
                Return Nothing
            End If
        End Get

    End Property
    Public ReadOnly Property LoggedIn As Boolean
        Get
            If Me.Data("LoggedIn") = Nothing Then
                Me.Data("LoggedIn") = False
                Return False
            Else
                Return CBool(Me.Data("LoggedIn"))
            End If
        End Get
        '10/12/20 - SET - UserName & UserId are both Data fields and attributes on UserSession, there is special code in sp506SessionSetData to keep them in sync
    End Property
    Public ReadOnly Property UserName As String
        Get
            Return Me.UserSessionrow("UserName")
        End Get
        '10/12/20 - SET - UserName & UserId are both Data fields and attributes on UserSession, there is special code in sp506SessionSetData to keep them in sync
    End Property
    Public ReadOnly Property UserName20 As String
        Get
            Return Left(Me.UserName, 20)
        End Get
    End Property
    Public ReadOnly Property UserId As Integer
        Get
            Return Me.UserSessionrow("UserId")
        End Get
    End Property
    Public ReadOnly Property UserFullName As String
        Get
            Return Me.Data("UserFullName")
        End Get
    End Property

    Public ReadOnly Property StartDate As DateTime
        Get
            Return db.IsDBNull(Me.UserSessionrow("StartDate"), Nothing)
        End Get
    End Property
    Public ReadOnly Property Expires As Date
        Get
            If Me.Data("Expires") Is Nothing Then
                Me.Data("Expires") = Me.StartDate.AddMinutes(Me.Timeout)
            End If
            Return Me.Data("Expires")
        End Get
    End Property
    Public Property Data(ByVal DataItemName As String) As String
        Get
            Dim ReturnedData As String = Nothing
            Try
                Dim r As DataRow = Me.UserSessionData.Rows.Find({DataItemName})
                If r IsNot Nothing Then
                    ReturnedData = r("DataItemValue")
                End If
            Catch ex As Exception
                Throw New Exception("Return session parameter:" & DataItemName & " Failed:" & ex.Message)

            End Try
            Return ReturnedData
        End Get
        Set(ByVal Value As String)
            Dim r As DataRow = Me.UserSessionData.Rows.Find({DataItemName})
            If r Is Nothing Then
                r = Me.UserSessionData.NewRow
                r("UserSessionId") = Me.UserSessionIdGUID
                r("DataItemName") = DataItemName
                Me.UserSessionData.Rows.Add(r)
            End If
            r("DataItemValue") = Value
            If Me.db.DBTransaction Is Nothing Then
                Me.daUserSessionData.Update(MainDataset, "UserSessionData")
            End If
        End Set
    End Property

    Public ReadOnly Property IsSpoofSession As Boolean
        Get
            If Me.Data("IsSpoofSession") Is Nothing Then Return False
            Return Me.Data("IsSpoofSession")
        End Get
    End Property

    Public ReadOnly Property SpoofPassword As String
        '1/11/19    James Woosnam   SIR4766 - Add spoof link
        Get
            Dim pw As String = ""
            Try
                pw = db.GetParameterValue("SpoofPassword")
            Catch ex As Exception
                pw = "bhj67GHB2#$VGbN*JkJu0"
                db.SetParameterValue("SpoofPassword", pw)
            End Try
            'by adding in today's date it limits the link to the current day
            pw = Now().ToString("yyyy-MMM-dd") & pw
            pw = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(pw, "SHA1")
            Return pw
        End Get
    End Property
    Public ReadOnly Property SpoofToPaDSLogonURL(LogonForUserName As String) As String
        '1/11/19    James Woosnam   SIR4766 - Add spoof link
        Get
            Return "pg070Logon.aspx?Action=SpoofToPaDSLogon&IsSpoofSession=True&SpoofingUserId=" & Me.UserId & "&UserName=" & LogonForUserName & "&SpoofPassword=" & Me.SpoofPassword

        End Get
    End Property
    Public ReadOnly Property SpoofToPEPWebLogonURL(LogonForUserName As String) As String
        '27/1/21    James Woosnam   Add spoof link
        Get
            Return "pg070Logon.aspx?Action=SpoofToPEPWebLogon&IsSpoofSession=True&SpoofingUserId=" & Me.UserId & "&UserName=" & LogonForUserName & "&SpoofPassword=" & Me.SpoofPassword

        End Get
    End Property
    Enum DisplayLanguages
        English
        Spanish
    End Enum
    Public Property DisplayLanguage As DisplayLanguages
        Get
            Return Me.Data("DisplayLanguage")
        End Get
        Set(value As DisplayLanguages)
            Me.Data("DisplayLanguage") = value
        End Set
    End Property
    Private _Timeout As Int16
    Public Property Timeout() As Int16
        '*******************************************************************************************
        'Returns the number of minutes before the session times out
        '*******************************************************************************************
        Get
            If Me._Timeout = Nothing Then
                Me._Timeout = Me.db.GetParameterValue("SessionTimeout")
            End If
            Return Me._Timeout

        End Get
        Set(ByVal Value As Int16)
            Me._Timeout = Value
        End Set
    End Property
    Public ReadOnly Property AuthenticationResponse As PEPSecurity.AuthenticationResponse
        Get
            Dim res As New PEPSecurity.AuthenticationResponse
            With res
                If Me.UserSessionId <> Nothing Then
                    .SessionId = Me.UserSessionId
                    .SessionExpires = (Me.Expires - Now()).TotalSeconds
                    .IsValidUserName = db.IsDBNull(Me.Data("IsValidUserName"), False)
                    .IsValidLogon = db.IsDBNull(Me.Data("IsValidLogon"), False)
                    .HasSubscription = db.IsDBNull(Me.Data("HasSubscription"), False)

                End If

            End With
            Return res
        End Get
    End Property

    Public ReadOnly Property IsAtZedraOrZedraUser As Boolean
        Get
            Dim rtn As Boolean = False
            Try
                If db.DBConnection.DataSource.ToLower.Contains("zedra") Then rtn = True
                If {"jwoosnam", "jgates"}.Contains(Me.UserName.ToLower) Then rtn = True
            Catch ex As Exception
            End Try
            Return rtn
        End Get
    End Property
#End Region

#Region "DependantTables"
    '***********************************************
    'UserSession
    Private Sub Initilise()
        Dim xx As Integer = 0
        Me.MainDataset = New DataSet
        Me._daUserSession = Nothing
        Me._daUserSessionData = Nothing
        xx = Me.UserSession.Rows.Count
        xx = Me.UserSessionData.Rows.Count
        If Me.SessionCookie IsNot Nothing Then Me.SessionCookie.SessionId = Me.UserSessionId
    End Sub
    Public ReadOnly Property UserSession() As DataTable
        Get
            If Me.MainDataset.Tables("UserSession") Is Nothing Then
                Me.daUserSession.Fill(Me.MainDataset, "UserSession")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("UserSession").Columns("UserSessionId")}
            Me.MainDataset.Tables("UserSession").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("UserSession")
        End Get
    End Property
    Private _daUserSession As SqlDataAdapter

    Private ReadOnly Property daUserSession() As SqlDataAdapter
        Get
            If Me._daUserSession Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM UserSession"
                sql += " WHERE UserSessionId=@UserSessionId"
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserSessionId", System.Data.SqlDbType.UniqueIdentifier, 36, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , Me.UserSessionIdGUID))
                _daUserSession = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daUserSession)
                _daUserSession.UpdateCommand = cmdBld.GetUpdateCommand()
                _daUserSession.InsertCommand = cmdBld.GetInsertCommand()
                _daUserSession.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daUserSession.InsertCommand.Transaction = Me.db.DBTransaction
                _daUserSession.UpdateCommand.Transaction = Me.db.DBTransaction
                _daUserSession.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daUserSession
        End Get
    End Property

    Public ReadOnly Property UserSessionRow() As DataRow
        Get
            If Me.UserSession.Rows.Count = 0 Then
                Me.daUserSession.Fill(Me.MainDataset.Tables("UserSession"))
                '22/12/20 - Test below removed as was being triggered when initialse being called in restore
                'If Me.UserSession.Rows.Count = 0 Then
                '    Throw New Exception("UserError: UserSessionId:" & Me.UserSessionId & " can't be found")
                'End If
            End If
            Return Me.UserSession.Rows(0)
        End Get
    End Property


    '***********************************************
    'UserSessionData
    Public ReadOnly Property UserSessionData() As DataTable
        Get
            If Me.MainDataset.Tables("UserSessionData") Is Nothing Then
                Me.daUserSessionData.Fill(Me.MainDataset, "UserSessionData")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("UserSessionData").Columns("DataItemName")}
            Me.MainDataset.Tables("UserSessionData").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("UserSessionData")
        End Get
    End Property
    Private _daUserSessionData As SqlDataAdapter
    Public ReadOnly Property daUserSessionData() As SqlDataAdapter
        Get
            If Me._daUserSessionData Is Nothing Then
                Dim sql As String = ""
                sql = "SELECT *"
                sql += " FROM UserSessionData"
                sql += " WHERE UserSessionId=@UserSessionId"
                sql += " ORDER BY DataItemName"
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserSessionId", System.Data.SqlDbType.UniqueIdentifier, 36, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , Me.UserSessionIdGUID))
                _daUserSessionData = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daUserSessionData)
                _daUserSessionData.UpdateCommand = cmdBld.GetUpdateCommand()
                _daUserSessionData.InsertCommand = cmdBld.GetInsertCommand()
                _daUserSessionData.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daUserSessionData.InsertCommand.Transaction = Me.db.DBTransaction
                _daUserSessionData.UpdateCommand.Transaction = Me.db.DBTransaction
                _daUserSessionData.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daUserSessionData
        End Get
    End Property


    '***********************************************

#End Region

    Public Sub New(ByVal db As BusinessLogic.Database)
        Me.db = db
    End Sub
    Public Sub New(UserSessionId As Guid, ByVal db As BusinessLogic.Database)
        Me.db = db

        Me.UserSessionIdGUID = UserSessionId
    End Sub
#Region "Actions"
    Public Sub Logon(ByVal UserName As String, ByVal Password As String, Optional IsSpoofLogon As Boolean = False, Optional SpoofingUserId As Integer = 0, Optional IsAutoLogon As Boolean = False)

        If IsSpoofLogon Then
            If Password <> Me.SpoofPassword Then
                Throw New Exception("Invalid Spoof Logon")
            End If
        End If
        Dim sql As String = ""
        Dim sqlForUpdate As String = ""
        Dim tblUser As DataTable = Nothing
        Dim rowUser As DataRow = Nothing
        Dim ExceededLogonAttempts As Boolean = False
        Dim EncryptedPassword As String = Nothing
        Dim lf As String = System.Environment.NewLine

        Try
            Me.Data("LoggedIn") = False

            sql = "
                Select 
                    ru.UserId
                     ,ru.UserName
                     ,ru.Password
                     ,ru.ValidUntil
                     ,ru.AuthorityLevel
                     ,ru.PasswordRetryAttempts
                     ,ru.UserStatus
                     ,ru.PEPWebClientSettings
                     ,UserFullName = ISNULL(UserFullName,ru.UserName)
                    ,ru.EmailAddress
                    ,ru.SendJournalAlerts
                    ,ru.SendVideoAlerts
                    ,ru.ShowCounterReports
                 FROM RemoteUser ru
                 WHERE UserName = @UserName
                 AND UserStatus IN ('Active','Emailed')
                " & lf
            'sql += " AND AuthorityLevel<>'IndividualSubscriber'" & lf
            Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)

            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, UserName))
            Dim tblRemoteUser As DataTable = db.GetDataTableFromSQL(cmd)
            Select Case tblRemoteUser.Rows.Count
                Case 0
                    Throw New Exception("Invalid user and/or password.  Please remember the password is case sensitive", New Exception("User:'" & UserName & "' can't be found"))
                Case 1
                    rowUser = tblRemoteUser.Rows(0)

                    sqlForUpdate = "UPDATE RemoteUser" & lf
                    sqlForUpdate += " SET UserName=UserName" 'just use user To mainatian sql

                    'encrypt the passed in clear text password and then compare with database password
                    EncryptedPassword = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(Password, "SHA1")
                    Dim dbpassword As String = db.IsDBNull(rowUser(“password”), "")
                    Dim passwordDifferent As Boolean = False
                    If Not IsSpoofLogon And Not IsAutoLogon Then
                        If EncryptedPassword.Length <> dbpassword.Length Then
                            passwordDifferent = True
                        Else
                            For i As Integer = 0 To EncryptedPassword.Length - 1
                                If EncryptedPassword.Substring(i, 1) <> dbpassword.Substring(i, 1) Then
                                    passwordDifferent = True
                                    Exit For
                                End If
                            Next
                        End If
                    End If
                    '8/2/21     James Woosnam   SIR5188 - Logon - Move initial user update out of the transaction so PasswordRetryAttempts is saved and ensure it isn't reset with a valid logon after 3 attempts
                    Dim LogonSuccessful As Boolean = False
                    If Not passwordDifferent Then ' rowUser("Password").ToString = EncryptedPassword Then
                        If CDate(db.IsDBNull(rowUser("ValidUntil"), "01-jan-1990")) < Now() Then
                            Throw New Exception("Your userid has expired.  Please contact support")
                        End If
                        If Not IsSpoofLogon And Not IsAutoLogon Then
                        End If
                        LogonSuccessful = True
                    Else
                        sqlForUpdate += " , PasswordRetryAttempts=" & (db.IsDBNull(rowUser("PasswordRetryAttempts"), 0) + 1) & lf
                    End If
                    If db.IsDBNull(rowUser("PasswordRetryAttempts"), 0) >= 3 Then ExceededLogonAttempts = True
                    '13/2/20    James Woosnam   SIR5017 - ensure LastLoggedOn only update if successdul logon
                    ' 31/2/20    James Woosnam   Only set LastLoggedOn if logged in and not spoof
                    If LogonSuccessful And Not IsSpoofLogon And Not ExceededLogonAttempts Then
                        sqlForUpdate += " ,LastLoggedOn=GETDATE()"
                    End If

                    If LogonSuccessful And Not IsSpoofLogon And Not ExceededLogonAttempts And Not IsAutoLogon Then
                        sqlForUpdate += " , PasswordRetryAttempts=0" & lf
                    End If

                    sqlForUpdate += " WHERE UserId=" & rowUser("UserId") & lf
                    cmd = New SqlCommand(sqlForUpdate, db.DBConnection, db.DBTransaction)
                    cmd.ExecuteNonQuery()
                    If ExceededLogonAttempts Then
                        If UserName.ToLower = "test8" And LogonSuccessful And db.IsDBNull(rowUser("PasswordRetryAttempts"), 0) >= 4 Then
                            '6/2/21 - Special testing code to reset this user after 3 incorrect logon attempts
                            db.ExecuteSQL("UPDATE REmoteUser SET PasswordRetryAttempts=0
                                                            ,FederatedPersonId = NULL
                                                            ,LastLoggedInMethod = NULL
                                                            ,LastAutoLoginGroupUserId = NULL
                                                            WHERE UserId = 500008")
                        Else
                            Throw New Exception("You have exceeded your invalid logon attempts, please contact PaDS to have your account reactivated.")
                        End If
                    End If
                    If Not LogonSuccessful Then
                        Throw New Exception("Invalid user and/or password.  Please remember the password is case sensitive")
                    End If
                Case Else
                    Throw New Exception("This user name belongs to more then one user.  Please contact " & db.SupportEmailLink)
            End Select
            '6/2/21     James Woosnam   Don't start transaction until after main remote user updates, as we will lose PasswordRetryAttempts
            Dim tranStartedHere As Boolean = False
            If db.DBTransaction Is Nothing Then
                db.BeginTran()
                tranStartedHere = True
            End If
            Try

                Me.Data("LoggedIn") = True

                '24/3/21    James Woosnam   SIR5217 - Record last group login details
                Dim ru As New RemoteUser(CInt(rowUser("UserId")), db, Me)
                Select Case Me.LoggedInMethod
                    Case LoggedInMethods.IPAddress
                        ru.RemoteUserRow("LastAutoLoginGroupUserId") = Me.UserSessionRow("UserId")
                        Me.LoggedInMethod = LoggedInMethods.IPAddressIndividual
                    Case LoggedInMethods.ReferrerURL
                        ru.RemoteUserRow("LastAutoLoginGroupUserId") = Me.UserSessionRow("UserId")
                        Me.LoggedInMethod = LoggedInMethods.ReferrerURLIndividual
                    Case LoggedInMethods.Federated
                        ru.RemoteUserRow("LastAutoLoginGroupUserId") = Me.UserSessionRow("UserId")
                        'Before updating the loggedInMethod Call UpdateFederatedPersonIdFromSession which will update when available and required
                        ru.UpdateFederatedPersonIdFromSession()
                        Me.LoggedInMethod = LoggedInMethods.FederatedIndividual
                    Case LoggedInMethods.FederatedIndividual, LoggedInMethods.IPAddressIndividual, LoggedInMethods.ReferrerURLIndividual
                        'don't change
                    Case Else
                        Me.LoggedInMethod = LoggedInMethods.Individual
                End Select
                Select Case Me.LoggedInMethod
                    Case LoggedInMethods.IPAddressIndividual, LoggedInMethods.ReferrerURLIndividual, LoggedInMethods.FederatedIndividual
                        ru.RemoteUserRow("LastLoggedInMethod") = Me.LoggedInMethod.ToString
                End Select
                ru.Save()
                '10/12/20 - SET - UserName & UserId are both Data fields and attributes on UserSession, there is special code in sp506SessionSetData to keep them in sync
                Me.UserSessionRow("UserId") = rowUser("UserId")
                Me.UserSessionRow("UserName") = Left(rowUser("UserName") & IIf(IsSpoofLogon, " SpoofedBy" & SpoofingUserId, ""), 50)
                Me.Data("IsValidLogon") = True
                Me.Data("IsSpoofSession") = IsSpoofLogon

                Me.Data("UserFullName") = rowUser("UserFullName") & IIf(IsSpoofLogon, " SpoofedBy" & SpoofingUserId, "")
                Me.Data("EmailAddress") = db.IsDBNull(rowUser("EmailAddress"), "")

                If IsSpoofLogon Then Me.Data("SpoofingUserId") = SpoofingUserId
                Me.Data("AuthorityLevel") = rowUser("AuthorityLevel")
                '2/3/21     Put UserType in te Sessiondata
                Select Case Me.AuthorityLevel
                    Case AuthorityLevels.IndividualSubscriber
                        Me.Data("UserType") = "Individual"
                    Case AuthorityLevels.GroupUser
                        Me.Data("UserType") = "Group"
                    Case AuthorityLevels.SuperCompanyAdmins, AuthorityLevels.CompanyAdmins
                        Me.Data("UserType") = "Admin"
                    Case Else
                        Me.Data("UserType") = Me.AuthorityLevel.ToString
                End Select
                Me.Data("PEPWebClientSettings") = db.IsDBNull(rowUser("PEPWebClientSettings"), "")
                Me.Data("UserStatus") = db.IsDBNull(rowUser("UserStatus"), "")
                '9/2/21     James Woosnam   SIR5176 - Add SendJournalAlerts & SendVideoAlerts
                Me.Data("SendJournalAlerts") = CBool(db.IsDBNull(rowUser("SendJournalAlerts"), False))
                Me.Data("SendVideoAlerts") = CBool(db.IsDBNull(rowUser("SendVideoAlerts"), False))
                '16/3/21    Julian Gates    SIR5213 - Add ShowCounterReports
                Me.Data("ShowCounterReports") = CBool(db.IsDBNull(rowUser("ShowCounterReports"), False))
                Me.Data("QueryString") = Me.QueryString
                Me.Data("Expires") = Me.Expires
                sql = "Select RightsType, RightsToId
                 From [RemoteUserRights]
                 Where UserId = " & rowUser("UserId")
                Dim tblRights As DataTable = db.GetDataTableFromSQL(sql)
                For Each row As DataRow In tblRights.Rows
                    Me.Data("Authorised" & row("RightsType") & "s") += "," & row("RightsToID")
                    Select Case Me.AuthorityLevel
                        Case AuthorityLevels.GroupAdmins, AuthorityLevels.GroupRenewer
                            Select Case row("RightsType")
                                Case "Subscriber"
                                    Me.Data("PrimaryGroupSubscriberId") = CInt(row("RightsToID"))
                                    Me.Data("GroupSubscriberName") = db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & row("RightsToID"))
                                Case "Company"
                                    Me.Data("CompanyId") = CInt(row("RightsToID"))
                            End Select
                    End Select
                Next
                Select Case Me.AuthorityLevel
                    Case AuthorityLevels.IndividualSubscriber, AuthorityLevels.GroupAdmins, AuthorityLevels.GroupRenewer, AuthorityLevels.GroupUser
                        '13/1/20    James Woosnam   SIR4977 - Change IsProposedSubscriber to HasOrIsAProposedSubscriber in SessionData
                        '30/10/20   James Woosnam   Need additional subscriber info for Group logons
                        '16/11/20   James Woosnam   Only raise error if more then 1 subscriber rights
                        sql = "
                    SELECT 
				         SubscriberId = CASE WHEN sProp.SubscriberId IS NULL THEN s.SubscriberId ELSE sProp.SubscriberId END
				         ,SubscriberName = CASE WHEN sProp.SubscriberId IS NULL THEN s.SubscriberName ELSE sProp.SubscriberName END
				         ,BaseSubscriberId = CASE WHEN sProp.SubscriberId IS NULL THEN sProp.SubscriberId ELSE s.SubscriberId END
				         ,HasOrIsAProposedSubscriber = CASE WHEN sProp.SubscriberId IS NOT NULL OR s.SubscriberStatus = 'Proposed' THEN 1 ELSE 0 END
				         ,IsSpanishIJPESSubscriber = CASE WHEN sProp.SubscriberId IS NULL THEN s.IsSpanishIJPESSubscriber ELSE sProp.IsSpanishIJPESSubscriber END
                     FROM RemoteUserRights rur
					        INNER JOIN Subscriber s
						        LEFT JOIN Subscriber sProp
						        ON sProp.UpdateToSubscriberId = s.SubscriberId 
						        AND sProp.SubscriberStatus = 'Proposed'
					        ON s.SubscriberId = rur.RightsToId 
			        WHERE rur.RightsType = 'Subscriber'
			        AND 1 = (SELECT COUNT(*) FROM RemoteUserRights rur2 where rur2.UserId = rur.UserId AND rur2.RightsType = 'Subscriber')
                    AND rur.UserId = " & Me.UserId
                        Dim tblIdvdSub As DataTable = db.GetDataTableFromSQL(sql)
                        Select Case tblIdvdSub.Rows.Count
                            Case 0
                                Throw New Exception("User:" & UserName & " is recorded as an " & Me.AuthorityLevel.ToString & ", but no linked rights and subscriber can be found")
                            Case 1
                            Case Else
                                Throw New Exception("User:" & UserName & " is recorded as an " & Me.AuthorityLevel.ToString & ", but " & tblIdvdSub.Rows.Count & " linked subscriber rights can be found")
                        End Select
                        Dim rowIdvdSub = tblIdvdSub.Rows(0)
                        Me.Data("HasOrIsAProposedSubscriber") = rowIdvdSub("HasOrIsAProposedSubscriber")
                        Me.Data("SubscriberId") = rowIdvdSub("SubscriberId") 'If proposed this is the proposed one
                        Me.Data("SubscriberName") = rowIdvdSub("SubscriberName") 'If proposed this is the proposed one
                        Me.Data("BaseSubscriberId") = db.IsDBNull(rowIdvdSub("BaseSubscriberId"), 0)
                        Me.Data("CompanyId") = 2
                        Me.Data("IsSpanishIJPESSubscriber") = CBool(db.IsDBNull(rowIdvdSub("IsSpanishIJPESSubscriber"), False))
                    Case Else
                        Me.Data("IsSpanishIJPESSubscriber") = False

                End Select
                Me.Save()
                If tranStartedHere Then db.CommitTran()
            Catch ex As Exception
                If tranStartedHere Then db.RollbackTran()
                Throw ex
            End Try
        Catch ex As Exception
            Throw New Exception("Logon Failed:" & ex.Message)

        End Try
    End Sub
    Public Sub ResetData()
        Dim tranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            db.BeginTran()
            tranStartedHere = True
        End If
        Try

            Me.Save()
            If tranStartedHere Then db.CommitTran()
        Catch ex As Exception
            If tranStartedHere Then db.RollbackTran()
            Throw New Exception("ResetData Failed:" & ex.Message)
        End Try
    End Sub
    Public Sub Restore(ByRef FormFields As Object, ByRef QueryFields As Object)
        Dim OutUserSessionId As String = Nothing

        OutUserSessionId = FormFields("UserSessionId")
        If OutUserSessionId = "" Then
            OutUserSessionId = QueryFields("UserSessionId")
        End If
        Restore(OutUserSessionId)
    End Sub
    Public Sub RestoreFromCookie(ByRef PageRequest As HttpRequest, ByRef RedirectURL As String, ResetSessionCookie As Boolean)
        '17/8/20    James Woosnam   SIR5082 - Store SessionId in, and restored from, a new session cookie
        ''24/9/20   James Woosnam   SIR5082 - If there is a sessionid in the query string use that first, this will allow spoof session to work properly
        '                                     'The session cookie wont be saved for spoof sessions 

        Try
            Me.SessionCookie = New SessionCookie(PageRequest, Me, ResetSessionCookie)
            Dim SessionIdToUse As String = Nothing
            Dim tryCookie As Boolean = False
            If PageRequest.QueryString.AllKeys.Contains("UserSessionId") Then
                SessionIdToUse = PageRequest.QueryString("UserSessionId")
                Try
                    Me.Restore(SessionIdToUse)
                Catch ex As Exception
                    'If restore from querystring fails try and use the cookie
                    tryCookie = True
                End Try
            Else
                tryCookie = True
            End If
            If tryCookie Then
                If Me.SessionCookie.Expires < Now() Then
                    Throw New Exception("Session has expired.")
                End If
                SessionIdToUse = Me.SessionCookie.SessionId
                Me.Restore(SessionIdToUse)
            End If

            Me.SessionCookie.SessionId = Me.UserSessionId

        Catch ex As Exception
            If ex.Message = "PaDS is currently unavailable" Then
                RedirectURL = "../pages/pg051PadsUnavailable.htm"
                Exit Try
            End If
            RedirectURL = "../pages/pg070Logon.aspx?Action=ResetSessionCookie&InfoMsg=" & ex.Message.Replace(System.Environment.NewLine, " ")
        End Try
    End Sub
    Public Sub Restore(ByVal InUserSessionId As String, Optional NewSessionIfTimedOut As Boolean = True)
        Try


            Try
                If InUserSessionId = "" Then
                    _UserSessionIdGUID = Guid.NewGuid

                Else
                    _UserSessionIdGUID = New Guid(InUserSessionId)
                End If

            Catch ex As Exception
                Throw New Exception("UserSessionId:" & InUserSessionId & " can't be converted to a GUID")
            End Try
            Dim tranStartedHere As Boolean = False
            If db.DBTransaction Is Nothing Then
                db.BeginTran()
                tranStartedHere = True
            End If
            Try
                '22/12/20-Added for something in Federated logon, but found to cause multipl errors in may autheticate
                '4/2/21 - having Initilise commented out was causing problems as session was not removing old dataset lines, so re-added
                '18/2/21 - Me.Initilise was in IF/Else above, but brought into tran to try tp stop concurrency error
                Me.Initilise()
                If Me.UserSession.Rows.Count <> 0 AndAlso Now > Me.Expires Then
                    If NewSessionIfTimedOut Then
                        _UserSessionIdGUID = Guid.NewGuid
                        Initilise()
                    Else
                        Throw New Exception("Session:" & Me.UserSessionId & " has timed out.")
                    End If

                End If
                If Me.UserSession.Rows.Count = 0 Then
                    Dim rSess As DataRow = Nothing
                    rSess = Me.UserSession.NewRow
                    rSess("UserSessionId") = Me.UserSessionIdGUID
                    rSess("UserSessionType") = "None"
                    rSess("UserId") = -1
                    rSess("UserName") = "Not Logged On"
                    rSess("StartDate") = Now()
                    rSess("LastAccessedDate") = Now()
                    Me.UserSession.Rows.Add(rSess)
                    Me.Save()
                Else
                    Me.UserSessionRow("LastAccessedDate") = Now()
                End If
                Try
                    Me.Save()
                Catch ex As DBConcurrencyException
                    'not fussed if just updating LastAccessedDate fails for conncurrency
                End Try
                If tranStartedHere Then db.CommitTran()
            Catch ex As Exception
                If tranStartedHere Then db.RollbackTran()
                Throw ex
            End Try
        Catch ex As Exception
            Throw New Exception("Session.Restore failed:" & ex.Message)
        End Try
    End Sub


    Public Sub Logout()
        'logout session

        Try
            '11/11/20   James       Do Not delete session data as this could be needed for reporting
            '10/12/20   James       Set LoggedIn to false on existing session and run me.restore with blank session ID to create a new one
            Me.Data("LoggedIn") = False
            Me.Data("Expires") = CDate("01-jan-1900")
            Me.Restore("")

        Catch ex As Exception
            Throw New Exception("Logout not completed successfully")

        End Try
    End Sub
    Public Sub Logout(ByRef PageResponse As HttpResponse)
        'Logout session then cookie
        Try
            Me.SessionCookie.Logout(PageResponse)
            Me.Logout()
        Catch ex As Exception
            Throw New Exception("Logout not completed successfully")
        End Try
    End Sub

    Public Sub Save()
        Dim sql As String = ""
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Me.daUserSession.Update(Me.MainDataset, "UserSession")

            If Me.MainDataset.Tables("UserSessionData") IsNot Nothing Then
                Me.daUserSessionData.Update(Me.MainDataset, "UserSessionData")
            End If
            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try
    End Sub

#End Region

End Class

