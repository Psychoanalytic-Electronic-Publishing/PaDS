﻿'Modifications
'=============
'31/5/11    James Woosnam   Change ReplaceWordField to allow either wdReplaceOne or wdReplaceAll
'15/5/12    James Woosnam   SIR2725 - Remove redundant "BuildPivot"

Imports Microsoft.Office.Interop
Public MustInherit Class Report

#Region "Class Properties"

    Public SubmittedByUserSessionId As Guid = Nothing
    Public ReportType As String = Nothing

    Const strFIELD_START = "{{"
    Const strFIELD_END = "}}"

    Private _RandomOutputDirectoryName As String
    Public ReadOnly Property RandomOutputDirectoryName As String
        Get
            If Me._RandomOutputDirectoryName = Nothing Then
                Me._RandomOutputDirectoryName = IO.Path.Combine(Me.db.GetParameterValue("ReportOutDirectory"), New BusinessLogic.StdCode().GetRandomName(20))
                System.IO.Directory.CreateDirectory(System.IO.Path.Combine(Me.ReportsPhysicalDir.FullName, Me._RandomOutputDirectoryName))

            End If
            Return Me._RandomOutputDirectoryName
        End Get
    End Property
    Dim _FileName As String = ""
    Public Property FileName As String
        Get
            If Me._FileName = "" Then
                Me._FileName = Me.ReportName
            End If
            Return Me._FileName
        End Get
        Set(ByVal value As String)
            Me._FileName = value
        End Set
    End Property
    Dim _ReportsPhysicalDir As IO.DirectoryInfo = Nothing
    Public ReadOnly Property ReportsPhysicalDir As IO.DirectoryInfo
        Get
            If _ReportsPhysicalDir Is Nothing Then
                _ReportsPhysicalDir = New IO.DirectoryInfo(db.GetParameterValue("ReportsPhysicalDir"))
                If Not _ReportsPhysicalDir.Exists Then _ReportsPhysicalDir.Create()
            End If
            Return _ReportsPhysicalDir
        End Get
    End Property
    Public ReadOnly Property FullFilePath As String
        Get
            Return IO.Path.Combine(IO.Path.Combine(Me.ReportsPhysicalDir.FullName, Me.RandomOutputDirectoryName), Me.FileName)
        End Get
    End Property
    Public ReadOnly Property FileLink As String
        Get
            Dim link As String = ""
            link = "<a href="""
            link += IO.Path.Combine("../", IO.Path.Combine(Me.RandomOutputDirectoryName, Me.FileName))
            link += """ target=""blank"">"
            link += Me.FileName
            link += "</a>"
            Return link
        End Get
    End Property


    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)
            'For batch log create a new connection so the log remains even if the tans is rolled back
            Me._db = value
            Me.db.CommandTimeout = 600
        End Set
    End Property
    Private _BatchJob As BusinessLogic.BatchJob
    Public Property BatchJob() As BusinessLogic.BatchJob
        Get
            Return Me._BatchJob
        End Get
        Set(ByVal value As BusinessLogic.BatchJob)
            Me._BatchJob = value
        End Set
    End Property

    Public BatchLog As BusinessLogic.BatchLog
    Dim _JobParameters As BusinessLogic.BatchJobParameters
    Public Property JobParameters() As BusinessLogic.BatchJobParameters
        Get
            Return Me._JobParameters
        End Get
        Set(ByVal value As BusinessLogic.BatchJobParameters)
            Me._JobParameters = value
        End Set
    End Property
    Dim _ExcelTemplateName As String = Nothing
    Public ReadOnly Property ExcelTemplateName() As String
        Get
            If Me._ExcelTemplateName = Nothing Then
                Me._ExcelTemplateName = Me.db.GetParameterValue("ReportTemplateDirectory") & Me.ReportName & ".xlsx"
            End If
            Return Me._ExcelTemplateName
        End Get
    End Property
    '   Public ExcelWorkBook As SpreadsheetGear.IWorkbook
    Public ReportName As String
    Public ReportSQL As String
    Public ReportSQLForTotals As String
#End Region

    Public Sub New(ByVal ReportName As String, ByVal ReportType As String, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        Me.db = db
        Me.ReportName = ReportName
        Me.ReportType = ReportType
        Me.SubmittedByUserSessionId = SubmittedByUserSessionId
    End Sub
    Public Sub Submit(ByVal Parameters As BusinessLogic.BatchJobParameters)

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        Me.BatchJob.Parameters = Parameters
        Me.BatchJob.ProcessToPerform = Me.ReportName
        Me.BatchJob.CreateBatchJobEntry()
    End Sub
    Public Sub Execute(ByVal BatchLog As BusinessLogic.BatchLog)
        'Delete old reports
        Dim delCount As Integer = 0
        Dim DaysToKeepReports As Integer = 14
        Try
            DaysToKeepReports = db.GetParameterValue("DaysToKeepReports")
        Catch ex As Exception
            'If no parameter then don't worry just use the 14 day default
        End Try
        For Each Dir As String In System.IO.Directory.GetDirectories(IO.Path.Combine(Me.ReportsPhysicalDir.FullName, Me.db.GetParameterValue("ReportOutDirectory")))
            Dim dirInfo As New System.IO.DirectoryInfo(Dir)
            If dirInfo.CreationTime.AddDays(DaysToKeepReports) < Now() Then
                Try
                    System.IO.Directory.Delete(Dir, True)
                    delCount += 1
                Catch ex As Exception
                    'If error don't waorry try and delete next
                End Try
            End If

        Next
        If delCount > 0 Then
            BatchLog.Update(delCount & " reports more than " & DaysToKeepReports & " days old deleted")
        End If
    End Sub



    Public Sub CreateRows(ByVal oWord As Word.Application _
                            , ByVal intRows As Integer, _
                            ByVal strRowName As String)


        Try
            Dim intRow As Integer

            Try
                oWord.Selection.GoTo(What:=Word.WdGoToItem.wdGoToBookmark, Name:=strRowName)
            Catch ex1 As Exception
                Throw New Exception("Failed to goto bookmark:'" & strRowName & "' - " & ex1.ToString)
            End Try

            oWord.Selection.Copy()
            oWord.Selection.MoveDown(Unit:=Word.WdUnits.wdLine, Count:=1)
            For intRow = 1 To intRows - 1
                oWord.Selection.Paste()
            Next
        Catch ex As Exception
            Throw ex
        End Try



    End Sub
    Public Sub ReplaceWordField(ByVal wrd As Word.Application _
                                , ByVal FieldName As String, _
                                ByVal Value As String _
                                , ByVal ReplaceType As Word.WdReplace)
        '31/5/11    James Woosnam   Change ReplaceWordField to allow either wdReplaceOne or wdReplaceAll
        With wrd.Selection.Find
            .ClearFormatting()
            .Replacement.ClearFormatting()
            .Text = strFIELD_START & FieldName & strFIELD_END
            .Replacement.Text = Value
            .Forward = True
            .Wrap = Word.WdFindWrap.wdFindContinue
        End With
        wrd.ActiveWindow.ActivePane.View.SeekView = Word.WdSeekView.wdSeekCurrentPageHeader
        wrd.Selection.Find.Execute(Replace:=ReplaceType)
        wrd.ActiveWindow.ActivePane.View.SeekView = Word.WdSeekView.wdSeekCurrentPageFooter
        wrd.Selection.Find.Execute(Replace:=ReplaceType)

        wrd.ActiveWindow.ActivePane.View.SeekView = Word.WdSeekView.wdSeekMainDocument
        wrd.Selection.Find.Execute(Replace:=ReplaceType)

    End Sub

    Public Sub ExportDataToExcel(ByVal wks As Excel.Worksheet, ByVal tbl As DataTable)
        '25/5/11    James Woosnam   Set array sLines as type object to populate Excel correctly.
        Try
            Dim iCol As Integer = 0
            Dim iRow As Integer = 0
            '            Dim sHeaders(tbl.Columns.Count) As String
            Dim sLines(tbl.Rows.Count, tbl.Columns.Count - 1) As Object
            Dim i As Integer = 0
            For Each col As DataColumn In tbl.Columns
                sLines(iRow, iCol) = col.ColumnName
                'wks.Cells(iRow, iCol).value = col.ColumnName
                iCol += 1
            Next

            iRow = 1
            For Each row As DataRow In tbl.Rows
                iCol = 0
                For Each col As DataColumn In tbl.Columns
                    Try
                        sLines(iRow, iCol) = db.IsDBNull(row(col.ColumnName), "")
                    Catch ex As Exception
                        Throw ex
                    End Try
                    iCol += 1
                Next
                iRow += 1
            Next
            Dim rng As Excel.Range
            rng = wks.Range(wks.Cells(1, 1), wks.Cells(iRow, iCol))
            rng.Value = sLines
            iCol = 1
            For Each col As DataColumn In tbl.Columns
                rng = wks.Range(wks.Cells(1, iCol), wks.Cells(tbl.Rows.Count + 1, iCol))
                Select Case col.DataType.Name
                    Case "Int32"
                        rng.NumberFormat = "0"
                    Case "Double", "Decimal"
                        rng.NumberFormat = "#,##0.00"
                    Case "DateTime"
                        rng.NumberFormat = "dd-mmm-yyyy"
                End Select

                iCol += 1
            Next
        Catch ex As Exception
            Throw New Exception("Failed to export Data to Excel:" & ex.Message, ex)
        End Try
    End Sub

    Public Sub ExportDataToExcel(ByVal wkb As Excel.Workbook, ByVal sql As String)
        '***************************************
        'Reterieves the data in the SQL and puts it in a work sheet called "Data"
        '**************************************
        Try
            ExportDataToExcel(wkb.Worksheets("Data"), db.GetDataTableFromSQL(sql))
        Catch ex As Exception
            Throw ex
        End Try

    End Sub

    Public Sub UpdateHeaders(ByVal wkb As Excel.Workbook, ByVal SQL As String)

        Dim tbl As DataTable = db.GetDataTableFromSQL(SQL)

        For Each col As DataColumn In tbl.Columns
            wkb.Sheets("Pivot").Activate()
            wkb.Parent.Range("A1:z50").Select()
            wkb.Parent.Selection.Replace(strFIELD_START & col.ColumnName & strFIELD_END, tbl.Rows(0)(col.ColumnName))
            'With wkb.Sheets("Pivot").PageSetup
            '    '     .LeftHeader = StringReplaceAll(.LeftHeader, strFIELD_START & fld.Name & strFIELD_END, fld.Value)
            '    '     .CenterHeader = StringReplaceAll(.CenterHeader, strFIELD_START & fld.Name & strFIELD_END, fld.Value)
            '    '     .RightHeader = StringReplaceAll(.RightHeader, strFIELD_START & fld.Name & strFIELD_END, fld.Value)
            '    '     .LeftFooter = StringReplaceAll(.LeftFooter, strFIELD_START & fld.Name & strFIELD_END, fld.Value)
            '    '     .CenterFooter = StringReplaceAll(.CenterFooter, strFIELD_START & fld.Name & strFIELD_END, fld.Value)
            '    '     .RightFooter = StringReplaceAll(.RightFooter, strFIELD_START & fld.Name & strFIELD_END, fld.Value)
            'End With
        Next

    End Sub

End Class
