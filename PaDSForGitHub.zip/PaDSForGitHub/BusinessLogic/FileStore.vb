﻿'Oct 2019       James Woosnam   SIR4571 - Initial Version
Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO

Public Class FileStore
    Enum FileTypes
        Unknown = 1
        Excel = 2
        csv = 3
    End Enum
#Region "Class Properties"
    Public MainDataset As New DataSet
    Dim _FileStoreId As Long = Nothing
    Public Property FileStoreId() As Integer
        Get
            If Me._FileStoreId = Nothing Then

            End If
            Return Me._FileStoreId
        End Get
        Set(ByVal Value As Integer)
            _FileStoreId = Value
            'initilise dataset
            Me.Initilise()
        End Set
    End Property

    Private Sub Initilise()
        Dim xx As Integer = 0
        Me.MainDataset = New DataSet
        Me._daFile = Nothing
        xx = Me.File.Rows.Count
    End Sub
    Private _db As Database = Nothing
    Public Property db() As Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As Database)

            Me._db = value
        End Set
    End Property
    Public ReadOnly Property HasFile As Boolean
        Get
            Return Me.File.Rows.Count > 0
        End Get
    End Property
    Public ReadOnly Property FileBytes() As Byte()
        Get
            Dim FileByteArray As Byte() = Nothing

            Try
                FileByteArray = DirectCast(Me.FileRow("FileImage"), Byte())
                Return FileByteArray
            Catch ex As Exception
                Return Nothing
            Finally

            End Try
        End Get
    End Property
    Public ReadOnly Property FileExists As Boolean
        Get
            If Me.File.Rows.Count = 0 Then
                Return False
            Else
                Return Not db.IsDBNull(Me.FileRow("FileImage"))
            End If
        End Get
    End Property
    Public ReadOnly Property OriginalFileName As String
        Get
            If Me.File.Rows.Count = 0 Then
                Return ""
            Else
                Return db.IsDBNull(Me.FileRow("OriginalFileName"), "")
            End If
        End Get
    End Property
#End Region

#Region "DependantTables"
    '***********************************************
    'Image
    Public ReadOnly Property File() As DataTable
        Get
            If Me.MainDataset.Tables("FileStore") Is Nothing Then
                Me.daFile.Fill(Me.MainDataset, "FileStore")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("FileStore").Columns("FileStoreId")}
            Me.MainDataset.Tables("FileStore").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("FileStore")
        End Get
    End Property
    Private _daFile As SqlDataAdapter
    Private ReadOnly Property daFile() As SqlDataAdapter
        Get
            If Me._daFile Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM FileStore"
                sql += " WHERE FileStoreId=" & Me.FileStoreId
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daFile = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daFile)
                _daFile.UpdateCommand = cmdBld.GetUpdateCommand()
                _daFile.InsertCommand = cmdBld.GetInsertCommand()
                _daFile.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daFile.InsertCommand.Transaction = Me.db.DBTransaction
                _daFile.UpdateCommand.Transaction = Me.db.DBTransaction
                _daFile.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daFile
        End Get
    End Property

    Public ReadOnly Property FileRow() As DataRow
        Get
            If Me.File.Rows.Count = 0 Then
                Me.daFile.Fill(Me.MainDataset.Tables("FileStore"))
                If Me.File.Rows.Count = 0 Then
                    Throw New Exception("UserError: FileStoreId:" & Me.FileStoreId & " can't be found")
                End If
            End If
            Return Me.File.Rows(0)
        End Get
    End Property
#End Region

    Sub New(ByVal db As Database)
        Me.db = db
    End Sub
    Sub New(FileStoreId As Integer, ByVal db As Database)
        Me.db = db
        Me.FileStoreId = FileStoreId
    End Sub

#Region "Actions"
    Public Sub Save()
        Dim sql As String = ""
        Dim tranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            db.BeginTran()
            tranStartedHere = True
        End If
        Try
            Me.daFile.Update(Me.MainDataset, "FileStore")
            If tranStartedHere Then Me.db.CommitTran()
        Catch eDBCon As System.Data.DBConcurrencyException
            If tranStartedHere Then Me.db.RollbackTran()
            Throw eDBCon
        Catch e As Exception
            If tranStartedHere Then Me.db.RollbackTran()
            Throw e
        End Try
    End Sub

    Public Sub AddNewFile(
                          ByVal NewFile As Byte(),
                          OriginalFileName As String,
                          FileSourceDescription As String
                         )
        Try
            Dim newRow As DataRow = Me.File.NewRow
            newRow("FileStoreId") = 0
            newRow("FileImage") = NewFile
            newRow("OriginalFileName") = Left(OriginalFileName, 500)
            newRow("FileSourceDescription") = Left(FileSourceDescription, 500)
            newRow("CreatedDateTime") = Now
            newRow("LastUpdatedDateTime") = Now
            Me.File.Rows.Add(newRow)

            Me.Save()
            Me.FileStoreId = db.DLookup("MAX(FileStoreId)", "FileStore", "")
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Sub DeleteFile(ByVal FileStoreId As Integer)
        Try
            For Each drow As DataRow In Me.File.Rows
                If drow.Item("FileStoreId") = FileStoreId Then
                    drow.Delete()
                    Exit For
                End If
            Next

            Me.Save()
        Catch ex As Exception
            Throw New Exception(" File Store record has not been deleted", ex)
        End Try
    End Sub
#End Region

End Class
