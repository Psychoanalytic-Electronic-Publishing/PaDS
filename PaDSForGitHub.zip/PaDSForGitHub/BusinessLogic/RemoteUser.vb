﻿'Updates
'======
'Oct 2019       James Woosnam   SIR4571 - Initial Version
'11/12/19   James Woosnam   SIR4967-4 - Set IsPasswordValid
'29/01/20   Julian Gates    SIR4987 - Change Subject to PaDS Password Reset/User Activation in Sub ResetPasswordAndEmail()
'19/6/20    James Woosnam   SIR5084 - Ignore Inactive users in new by username 
'18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
'23/9/20    James Woosnam   SIR5043 - Allow users to be set up for Organisations with authoritylevel GroupUser
'23/9/20    Julian Gates    SIR5043 - Add RemoteUserAutoLogon to class
'19/02/21   Julian Gates    SIR5202 - Set PasswordRetryAttempts to 0

Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.UserSession
Imports System.Runtime.Serialization.Formatters.Binary
Imports System.IO
Imports Newtonsoft.Json

Public Class RemoteUser
#Region "Class Properties"

    Public MainDataset As New DataSet
    Dim _UserId As Long
    Dim UserSession As UserSession
    Public Property UserId() As Integer
        Get
            If Me._UserId = Nothing Then
                If Me.MainDataset.Tables.Count <> 0 Then
                    Me._UserId = Me.RemoteUserRow("UserId")
                End If
            End If
            Return Me._UserId
        End Get
        Set(ByVal Value As Integer)
            _UserId = Value
            'initilise dataset
            'Me.Initilise()
        End Set
    End Property
    Public Property UserName() As String
        Get
            Return db.IsDBNull(Me.RemoteUserRow("UserName"), "")
        End Get
        Set(ByVal value As String)
            Me.RemoteUserRow("UserName") = value
        End Set
    End Property
    Public Enum UserStates
        Pending
        Emailed
        Active
        InActive

    End Enum


    Public Property UserStatus() As UserStates
        Get
            Return [Enum].Parse(GetType(UserStates), Me.RemoteUserRow("UserStatus"))
        End Get
        Set(ByVal value As UserStates)
            Me.RemoteUserRow("UserStatus") = value.ToString
        End Set
    End Property
    Public Property EmailAddress() As String
        Get
            Return db.IsDBNull(Me.RemoteUserRow("EmailAddress"), "")
        End Get
        Set(ByVal value As String)
            Me.RemoteUserRow("EmailAddress") = value
        End Set
    End Property
    Dim _AuthorityLevel As AuthorityLevels = Nothing
    Public Property AuthorityLevel() As AuthorityLevels
        Get
            Return [Enum].Parse(GetType(AuthorityLevels), Me.RemoteUserRow("AuthorityLevel"))
        End Get
        Set(value As AuthorityLevels)
            Me.RemoteUserRow("AuthorityLevel") = value.ToString
        End Set
    End Property

    Private ReadOnly Property RemoteUser() As DataTable
        Get
            If Me.MainDataset.Tables("RemoteUser") Is Nothing Then
                Me.daRemoteUser.Fill(Me.MainDataset, "RemoteUser")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("RemoteUser").Columns("UserId")}
            Me.MainDataset.Tables("RemoteUser").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("RemoteUser")
        End Get
    End Property
    Private _daRemoteUser As SqlDataAdapter
    Private ReadOnly Property daRemoteUser() As SqlDataAdapter
        Get
            If Me._daRemoteUser Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM RemoteUser"
                sql += " WHERE UserId=" & Me.UserId
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daRemoteUser = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daRemoteUser)
                _daRemoteUser.UpdateCommand = cmdBld.GetUpdateCommand()
                _daRemoteUser.InsertCommand = cmdBld.GetInsertCommand()
                _daRemoteUser.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daRemoteUser.InsertCommand.Transaction = Me.db.DBTransaction
                _daRemoteUser.UpdateCommand.Transaction = Me.db.DBTransaction
                _daRemoteUser.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daRemoteUser
        End Get
    End Property
    Public ReadOnly Property RemoteUserRow() As DataRow
        Get
            If Me.RemoteUser.Rows.Count = 0 Then
                Me.daRemoteUser.Fill(Me.MainDataset.Tables("RemoteUser"))
                If Me.RemoteUser.Rows.Count = 0 Then
                    Throw New Exception("UserError: UserId:" & Me._UserId & " can't be found")
                End If
            End If
            Return Me.RemoteUser.Rows(0)
        End Get
    End Property
    Public ReadOnly Property RemoteUserRights() As DataTable
        Get
            If Me.MainDataset.Tables("RemoteUserRights") Is Nothing Then
                Me.daRemoteUserRights.Fill(Me.MainDataset, "RemoteUserRights")
            End If
            'Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("RemoteUserRights").Columns("RemoteUserRightsId")}
            'Me.MainDataset.Tables("RemoteUserRights").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("RemoteUserRights")
        End Get
    End Property
    Private _daRemoteUserRights As SqlDataAdapter
    Private ReadOnly Property daRemoteUserRights() As SqlDataAdapter
        Get
            If Me._daRemoteUserRights Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM RemoteUserRights"
                sql += " WHERE UserId=" & Me.UserId
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daRemoteUserRights = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daRemoteUserRights)
                _daRemoteUserRights.UpdateCommand = cmdBld.GetUpdateCommand()
                _daRemoteUserRights.InsertCommand = cmdBld.GetInsertCommand()
                _daRemoteUserRights.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daRemoteUserRights.InsertCommand.Transaction = Me.db.DBTransaction
                _daRemoteUserRights.UpdateCommand.Transaction = Me.db.DBTransaction
                _daRemoteUserRights.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daRemoteUserRights
        End Get
    End Property

    '23/9/20    Julian Gates    SIR5043 - Add RemoteUserAutoLogon to class
    Public ReadOnly Property RemoteUserAutoLogon() As DataTable
        Get
            If Me.MainDataset.Tables("RemoteUserAutoLogon") Is Nothing Then
                Me.daRemoteUserAutoLogon.Fill(Me.MainDataset, "RemoteUserAutoLogon")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("RemoteUserAutoLogon").Columns("RemoteUserAutoLogonId")}
            Me.MainDataset.Tables("RemoteUserAutoLogon").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("RemoteUserAutoLogon")
        End Get
    End Property

    Private _daRemoteUserAutoLogon As SqlDataAdapter
    Private ReadOnly Property daRemoteUserAutoLogon() As SqlDataAdapter
        Get
            If Me._daRemoteUserAutoLogon Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM RemoteUserAutoLogon"
                sql += " WHERE UserId=" & Me.UserId
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daRemoteUserAutoLogon = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daRemoteUserAutoLogon)
                _daRemoteUserAutoLogon.UpdateCommand = cmdBld.GetUpdateCommand()
                _daRemoteUserAutoLogon.InsertCommand = cmdBld.GetInsertCommand()
                _daRemoteUserAutoLogon.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daRemoteUserAutoLogon.InsertCommand.Transaction = Me.db.DBTransaction
                _daRemoteUserAutoLogon.UpdateCommand.Transaction = Me.db.DBTransaction
                _daRemoteUserAutoLogon.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daRemoteUserAutoLogon
        End Get
    End Property

    Private Sub Initilise()
        Dim xx As Integer = 0
        Me.MainDataset = New DataSet
        Me._daRemoteUser = Nothing
        Me._daRemoteUserRights = Nothing
        Me._daRemoteUserAutoLogon = Nothing
        xx = Me.RemoteUser.Rows.Count
        xx = Me.RemoteUserRights.Rows.Count
        xx = Me.RemoteUserAutoLogon.Rows.Count

    End Sub
    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property
    Public ReadOnly Property HoursToConfirmNewEmail As Integer
        Get
            Return db.GetParameterValue("HoursToConfirmNewEmail")
        End Get
    End Property
#End Region
    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserId = 0
        Me.UserSession = UserSession
        'Me._CalledByUserId = _CalledByUserId
    End Sub
    Sub New(ByVal UserId As Integer, ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserId = UserId
        Me.UserSession = UserSession
        Me.Initilise()
    End Sub
    Sub New(ByVal UserName As String, ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
        '19/6/20    James Woosnam   SIR5084 - Ignore Inactive users in new by username 
        Dim Sql As String = "
                SELECT UserId
                FROM RemoteUser
                WHERE UserName=@UserName
                AND UserStatus <>'InActive'
                "
        Dim cmd As New SqlCommand(Sql, db.DBConnection, db.DBTransaction)

        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                  UserName))
        Dim tbl As DataTable = db.GetDataTableFromSQL(cmd)
        Select Case tbl.Rows.Count
            Case 0
                Throw New Exception("Your UserName has not been found in our records, please contact " & db.SupportEmailLink & " for assistance.")
            Case 1
                Me.UserId = tbl.Rows(0)("UserId")
            Case Else
                Throw New Exception("Your UserName is attached to more than one user in our records, please contact " & db.SupportEmailLink & " for assistance.")
        End Select
        Me.Initilise()
    End Sub

    Sub New(ByVal db As BusinessLogic.Database)
        Me.db = db
    End Sub
    Public Sub Save()
        Dim sql As String = ""
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            If Me.UserStatus <> UserStates.InActive Then
                sql = "
                SELECT UserId
                FROM RemoteUser
                WHERE UserId <> " & Me.UserId & "
                AND UserStatus <>'InActive'
                "
                Dim cmd As New SqlCommand(sql & " AND UserName=@UserName", db.DBConnection, db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          Me.UserName))
                Dim tbl As DataTable = db.GetDataTableFromSQL(cmd)
                If tbl.Rows.Count <> 0 Then
                    Throw New Exception(" UserName:'" & Me.UserName & "' is already a user on PaDS UserId:" & tbl.Rows(0)(0))
                End If
                If Me.EmailAddress <> Nothing Then
                    cmd = New SqlCommand(sql & " AND EmailAddress=@EmailAddress", db.DBConnection, db.DBTransaction)
                    cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailAddress", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                        Me.EmailAddress))
                    tbl = db.GetDataTableFromSQL(cmd)
                    If tbl.Rows.Count <> 0 Then
                        Throw New Exception(" EmailAddress:'" & Me.EmailAddress & "' is already a user on PaDS UserId:" & tbl.Rows(0)(0))
                    End If
                End If
            End If

            '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
            Select Case Me.RemoteUserRow.RowState
                Case DataRowState.Added, DataRowState.Modified
                    Me.RemoteUserRow("LastUpdatedDateTime") = Now()
                    Me.RemoteUserRow("LastUpdatedByUserId") = Me.UserSession.UserName20
            End Select

            If Me.MainDataset.Tables("RemoteUserRights") IsNot Nothing Then
                '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
                For Each row As DataRow In Me.MainDataset.Tables("RemoteUserRights").Rows
                    Select Case row.RowState
                        Case DataRowState.Added, DataRowState.Modified
                            row("LastUpdatedDateTime") = Now()
                            row("LastUpdatedByUserId") = UserSession.UserName20
                    End Select
                Next
                Me.daRemoteUserRights.Update(Me.MainDataset, "RemoteUserRights")
            End If
            If Me.MainDataset.Tables("RemoteUserAutoLogon") IsNot Nothing Then
                For Each row As DataRow In Me.MainDataset.Tables("RemoteUserAutoLogon").Rows
                    Select Case row.RowState
                        Case DataRowState.Added, DataRowState.Modified
                            row("LastUpdatedDateTime") = Now()
                            row("LastUpdatedByUserId") = UserSession.UserName20
                    End Select
                Next
                Me.daRemoteUserAutoLogon.Update(Me.MainDataset, "RemoteUserAutoLogon")
            End If
            Me.daRemoteUser.Update(Me.MainDataset, "RemoteUser")

            Dim al As New AuditLog(db, UserSession)
            al.WriteAuditLog(AuditLog.RecordTables.RemoteUser, Me.UserId)

            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try

    End Sub
    Public Sub AddNew(ByVal EmailAddress As String,
                      ByVal AuthorityLevel As AuthorityLevels,
                      ByVal FullUserName As String
                   )

        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try

            Dim row As DataRow = Me.RemoteUser.NewRow
            row("UserId") = db.GetNextNumber("RemoteUser")
            If EmailAddress = Nothing Then
                row("UserName") = row("UserId")
            Else
                row("UserName") = EmailAddress
            End If
            row("EmailAddress") = EmailAddress
            '17/2/20    James Woosnam   SIR5021 - RemoteUser.AddNew tuncate longer sub name to 50 in remote user full name .
            row("UserFullName") = Left(FullUserName, 50)
            row("AuthorityLevel") = AuthorityLevel
            row("ValidUntil") = CDate("31-dec-4949")
            row("UserStatus") = UserStates.Pending.ToString
            row("CreatedDateTime") = Now()
            row("CreatedByUserId") = Me.UserSession.UserName20

            Me.RemoteUser.Rows.Add(row)

            Me.Save()
            Me.UserId = row("UserId")
            Me.Initilise()
            If TranStartedHere Then db.CommitTran()
        Catch ex As Exception
            If TranStartedHere Then db.RollbackTran()
            Throw New Exception("UserError: Add RemoteUser failed", ex)
        End Try
    End Sub
    Public Sub AddNewSubscriberUser(ByVal EmailAddress As String,
                      ByVal RightsToSubscriberId As Integer,
                                    ByVal AuthorityLevel As AuthorityLevels
                   )
        '23/9/20    James Woosnam   SIR5043 - Allow users to be set up for Organisations with authoritylevel GroupUser

        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Dim RightsToSub As New Subscriber(RightsToSubscriberId, db, UserSession)
            Me.AddNew(EmailAddress, AuthorityLevel, RightsToSub.SubscriberName)

            Me.AddRights(RightsTypes.Subscriber, RightsToSub.SubscriberId)
            Me.Save()
            If TranStartedHere Then db.CommitTran()
        Catch ex As Exception
            If TranStartedHere Then db.RollbackTran()
            Throw New Exception("UserError: AddNewIndividualSubscriber failed", ex)
        End Try
    End Sub
    Enum RightsTypes
        Company
        Subscriber
    End Enum
    Public Sub AddRights(RightsType As RightsTypes,
                         RightsToId As Integer)
        Try

            Dim rightsrow As DataRow = Me.RemoteUserRights.NewRow
            rightsrow("UserId") = Me.UserId
            rightsrow("RightsType") = RightsType.ToString
            Select Case RightsType
                Case RightsTypes.Company
                    If db.DLookup("CompanyId", "Company", "CompanyId=" & RightsToId) Is Nothing Then
                        Throw New Exception("CompanyId:" & RightsToId & " does not exist")
                    End If
                Case RightsTypes.Subscriber
                    If db.DLookup("SubscriberId", "Subscriber", "SubscriberId=" & RightsToId) Is Nothing Then
                        Throw New Exception("SubscriberId:" & RightsToId & " does not exist")
                    End If
            End Select
            rightsrow("RightsToId") = RightsToId
            rightsrow("LastUpdatedDateTime") = Now()
            rightsrow("LastUpdatedByUserId") = UserSession.UserName20
            Me.RemoteUserRights.Rows.Add(rightsrow)
            Me.Save()
        Catch ex As Exception
            Throw New Exception("UserError: Add RemoteUser failed", ex)
        End Try
    End Sub
    Enum AutoLogonTypes
        IPAddress
        ReferrerURL
        Federated
    End Enum
    Public Sub AddAutoLogon(AutoLogonType As AutoLogonTypes)
        'Notes As String,
        '                    MinIPAddress As String,
        '                    MaxIPAddress As String,
        '                    ReferrerURL As String,
        '                    FederatedEntity As String,
        '                    FederatedScope As String,
        '                    IsFederatedLinkRequired As Boolean)
        Try
            Dim newRow As DataRow = Me.RemoteUserAutoLogon.NewRow
            newRow("RemoteUserAutoLogonId") = Now.ToOADate * 100
            newRow("UserId") = Me.UserId
            newRow("AutoLogonStatus") = "Active"
            newRow("AutoLogonType") = AutoLogonType.ToString
            Select Case AutoLogonType
                Case AutoLogonTypes.IPAddress
                    newRow("MinIPAddress") = "0.0.0.0"
                    newRow("MaxIPAddress") = "0.0.0.0"
                Case AutoLogonTypes.ReferrerURL
                    newRow("ReferrerURL") = ""
                Case AutoLogonTypes.Federated
                    newRow("FederatedEntity") = ""
                    newRow("FederatedScope") = ""
                    newRow("IsFederatedLinkRequired") = False
            End Select
            newRow("Notes") = ""


            Me.RemoteUserAutoLogon.Rows.Add(newRow)
        Catch ex As Exception
            Throw New Exception("AddAutoLogon failed:" & ex.Message)
        End Try

    End Sub
    Public Sub SetPassword(Password As String)
        Try
            Dim msg As String = ""
            If Not Me.IsValidPassword(Password, msg) Then
                Throw New Exception("Invalid Password:" & msg)
            End If
            '11/12/19   James Woosnam   SIR4967-4 - Set IsPasswordValid
            Me.RemoteUserRow("IsPasswordValid") = 1
            Me.RemoteUserRow("OldPassword") = Me.RemoteUserRow("Password")
            Me.RemoteUserRow("OldPasswordFromDateTime") = Now()
            Me.RemoteUserRow("Password") = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(Password, "SHA1")
        Catch ex As Exception
            Throw New Exception("SetPassword failed:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub RestoreOldPassword()
        Try
            Me.RemoteUserRow("Password") = Me.RemoteUserRow("OldPassword")
            Me.RemoteUserRow("OldPassword") = System.DBNull.Value
            Me.RemoteUserRow("OldPasswordFromDateTime") = System.DBNull.Value
        Catch ex As Exception
            Throw New Exception("RestoreOldPassword failed:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub ResetPasswordAndEmail()
        Try
            'This sub resests the users password and sends them a link which allows them to choiose another one
            Dim password As String = Nothing
            password = New StdCode().GetRandomName(20) & "Ab1" 'meet password complexity rules
            Dim email As New Email(db)
            '29/01/20   Julian Gates    SIR4987 - Change Subject to PaDS Password Reset/User Activation
            email.Subject = "PaDS Password Reset/User Activation"
            email.From = db.GetParameterValue("EmailFromForCompanyId:2")
            email.SendTo = Me.RemoteUserRow("EmailAddress")
            email.IsBodyHTML = True
            Try
                email.BCC = db.GetParameterValue("BlindCopyEmailAddress")
            Catch ex As Exception

            End Try
            Dim Body As String = ""
            Dim stdCode As New BusinessLogic.StdCode

            Body = stdCode.GetFileText(db.GetParameterValue("TermsConditionsDirectoryPhysicalPath") & "EmailPasswordReset.html")

            If Body = "" Then
                Throw New Exception("Can't find HTML body file EmailPasswordReset.html or file is empty")
            End If
            Dim resetLink As String = Nothing
            resetLink += "   <a href=""" & db.GetParameterValue("WebSiteURL") & "/Pages/pg071UserAuthorisation.aspx"
            resetLink += "?EmailAddress=" & Me.RemoteUserRow("EmailAddress").ToString()
            resetLink += "&UserName=" & Me.RemoteUserRow("UserName").ToString()
            resetLink += "&TempPassword=" & password
            resetLink += "&" & UserSession.QueryString 'needed for federated and referral users
            resetLink += """style=""color:#002063;font-weight:bold;text-decoration:underline;"">PaDS Password Reset/Activation</a>"
            Dim mailToLink As String = Nothing
            mailToLink += " <a href=mailto:" & db.GetParameterValue("PepSupportEmailAddress") & "><span style=""color:#002063;font-weight:bold;text-decoration:underline;"">" & db.GetParameterValue("PepSupportEmailAddress") & "</span></a>"
            Body = Body.Replace("{{HoursToConfirmNewEmail}}", Me.HoursToConfirmNewEmail)
            Body = Body.Replace("{{PasswordSetupLink}}", resetLink)
            Body = Body.Replace("{{PaDSSupportDetails}}", mailToLink)

            email.Body = Body

            email.Send()
            Me.RemoteUserRow("EmailAuthenticationSentDateTime") = Now
            Me.SetPassword(password)
            Me.RemoteUserRow("PasswordRetryAttempts") = 0
            Me.UserStatus = UserStates.Emailed

            Me.Save()
        Catch ex As Exception
            Throw New Exception("ResetPasswordAndEmail failed", ex)
        End Try
    End Sub

    Public Sub Activate(ByVal NewPassword As String)
        Select Case Me.UserStatus
            Case UserStates.Emailed
            Case Else
                Throw New Exception("Only 'Emailed' Accounts csn be activated")
        End Select

        If Not Me.IsValidPassword(NewPassword) Then
            Throw New Exception("Invalid password")
        End If
        Me.RemoteUserRow("Password") = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(NewPassword, "SHA1")
        '11/12/19   James Woosnam   SIR4967-4 - Set IsPasswordValid
        Me.RemoteUserRow("IsPasswordValid") = 1
        Me.RemoteUserRow("OldPassword") = System.DBNull.Value
        Me.RemoteUserRow("OldPasswordFromDateTime") = System.DBNull.Value
        Me.UserStatus = UserStates.Active
        Me.Save()
    End Sub
    Public Sub InActivate()
        Select Case Me.UserStatus
            Case UserStates.Active, UserStates.InActive
            Case Else
                Throw New Exception("Only 'Active' users csn be Inactivated")
        End Select
        Me.UserStatus = UserStates.InActive
        Me.Save()
    End Sub
    Public Function IsValidPassword(PasswordToCheck As String, Optional ByRef ErrorMessage As String = "") As Boolean
        'Do more complex password validation in own sub so it can be called from page validation 
        ErrorMessage = ""
        Try
            If PasswordToCheck.Length < Me.db.GetParameterValue("MinPasswordLength") Then
                ErrorMessage += IIf(ErrorMessage = "", "", vbCrLf) & "Password must be more than 8 characters"
            End If
            Dim CapitalFound As Boolean = False
            Dim LowerCaseFound As Boolean = False
            Dim NumericFound As Boolean = False
            Dim NonAlphaNumericFound As Boolean = False
            For i As Integer = 0 To PasswordToCheck.Length - 1
                Dim sChar As String = PasswordToCheck.Substring(i, 1)
                If "ABCDEFGHIJKLMNOPQRSTUVWXYZ".Contains(sChar) Then
                    CapitalFound = True
                End If
                If "abcdefghijklmnopqrstuvwxyz".Contains(sChar) Then
                    LowerCaseFound = True
                End If
                If "0123456789".Contains(sChar) Then
                    NumericFound = True
                End If
                'If Not Me.db.GetParameterValue("AllowedAlphaNumericCharacters").Contains(sChar) Then
                '    NonAlphaNumericFound = True
                'End If
            Next
            If Not CapitalFound Then
                ErrorMessage += IIf(ErrorMessage = "", "", vbCrLf) & "Capital letter not found"
            End If
            If Not LowerCaseFound Then
                ErrorMessage += IIf(ErrorMessage = "", "", vbCrLf) & "Lowercase character not found"
            End If
            If Not NumericFound Then
                ErrorMessage += IIf(ErrorMessage = "", "", vbCrLf) & "Numeric character not found"
            End If
            If NonAlphaNumericFound Then
                ErrorMessage += IIf(ErrorMessage = "", "", vbCrLf) & "Non-Alphanumeric character found"
            End If
        Catch ex As Exception
            Throw New Exception("IsValidPassword failed:" & ex.Message)
        End Try
        Return ErrorMessage = ""
    End Function
    Public Function GetRemoteUserFromIPAddress(IPAddress As String, Optional IgnoreRemoteUserAutoLogonId As Integer = 0) As RemoteUser
        Dim ru As RemoteUser = Nothing
        Dim sql As String = "
            SELECT
	            ru.UserId 
	            ,ru.UserName 
	            ,rual.MinIPAddress 
	            ,rual.MaxIPAddress 
            FROM RemoteUser ru
	            INNER JOIN RemoteUserAutoLogon rual
	            On rual.UserId  = ru.UserId
            WHERE ru.UserStatus = 'Active'
            AND rual.AutoLogonStatus = 'Active'
            AND rual.AutoLogonType = 'IPAddress'
            AND rual.RemoteUserAutoLogonId <> " & IgnoreRemoteUserAutoLogonId
        Dim t As DataTable = db.GetDataTableFromSQL(sql)
        Dim stdCd As New BusinessLogic.StdCode()
        Dim matchCount As Integer = 0
        Dim matchedUsers As String = ""
        For Each r As DataRow In t.Rows
            If stdCd.GetIPAddressAsNumber(r("MinIPAddress")) <= stdCd.GetIPAddressAsNumber(IPAddress) And stdCd.GetIPAddressAsNumber(r("MaxIPAddress")) >= stdCd.GetIPAddressAsNumber(IPAddress) Then
                If ru Is Nothing Then ru = New RemoteUser(CInt(r("UserId")), db, UserSession)
                matchCount += 1
                matchedUsers += IIf(matchedUsers = "", "", ",") & r("UserId")
            End If
        Next
        If matchCount > 1 Then
            Throw New Exception("Overlapping RemoteUserAutoLogon for IP adress found in users:" & matchedUsers)
        End If
        Return ru
    End Function
    Public Function GetRemoteUserFromReferrerURL(referrerURL As String, Optional IgnoreRemoteUserAutoLogonId As Integer = 0) As RemoteUser
        '
        Dim ru As RemoteUser = Nothing
        Dim sql As String = "
            SELECT
	            ru.UserId 
	            ,ru.UserName 
            FROM RemoteUser ru
	            INNER JOIN RemoteUserAutoLogon rual
	            On rual.UserId  = ru.UserId
            WHERE ru.UserStatus = 'Active'
            AND rual.AutoLogonType = 'ReferrerURL'
            AND rual.AutoLogonStatus = 'Active'
            AND  (@ReferrerURL LIKE rual.ReferrerURL + '%'
                OR @ReferrerURL= LEFT(rual.ReferrerURL,LEN(@ReferrerURL)))
            AND ISNULL(rual.ReferrerURL,'') <> ''
            AND rual.RemoteUserAutoLogonId <> " & IgnoreRemoteUserAutoLogonId
        Dim cmd As New SqlCommand(sql, db.DBConnection, db.DBTransaction)
        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReferrerURL", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          referrerURL))
        Dim t As DataTable = db.GetDataTableFromSQL(cmd)
        Select Case t.Rows.Count
            Case 0
                'don't throw any error just return nothing
            Case 1
                ru = New RemoteUser(CInt(t.Rows(0)("UserId")), db, UserSession)
            Case Else
                Dim matchedUsers As String = ""
                For Each r As DataRow In t.Rows
                    matchedUsers += IIf(matchedUsers = "", "", ",") & r("UserId")
                Next
                Throw New Exception("Referrer URL matches multiple users:" & matchedUsers)
        End Select
        Return ru
    End Function

    Public Function GetRemoteUserFromFederatedEntityAndScope(FederatedEntity As String, FederatedScope As String, IgnoreRemoteUserAutoLogonId As Integer) As RemoteUser
        '
        Dim ru As RemoteUser = Nothing
        Dim sql As String = "
            SELECT
	            ru.UserId 
	            ,ru.UserName 
	            ,rual.FederatedEntity 
	            ,rual.FederatedScope 
                ,rual.RemoteUserAutoLogonId
            FROM RemoteUser ru
	            INNER JOIN RemoteUserAutoLogon rual
	            On rual.UserId  = ru.UserId
            WHERE ru.UserStatus = 'Active'
            AND rual.AutoLogonStatus = 'Active'
            AND rual.AutoLogonType = 'Federated'
            AND rual.FederatedEntity = @FederatedEntity
            AND rual.RemoteUserAutoLogonId <> " & IgnoreRemoteUserAutoLogonId
        Dim cmd As New SqlCommand(sql, db.DBConnection, db.DBTransaction)
        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@FederatedEntity", System.Data.SqlDbType.VarChar, 400, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          FederatedEntity))
        Dim t As DataTable = db.GetDataTableFromSQL(cmd)
        Select Case t.Rows.Count
            Case 0
            Case 1 And IgnoreRemoteUserAutoLogonId = 0
                Dim uRow As DataRow = t.Rows(0)
                If db.IsDBNull(uRow("FederatedScope"), "") <> "" And FederatedScope <> "" AndAlso uRow("FederatedScope").ToString.ToLower <> FederatedScope.ToLower Then
                    'The record has a scope and a scope is passed in, so they must match, if not just return nothing user
                    Exit Select
                ElseIf db.IsDBNull(uRow("FederatedScope"), "") = "" AndAlso FederatedScope <> "" Then
                    'user record hasn't got a scope but one was passed in so add it
                    cmd = New SqlCommand("UPDATE RemoteUserAutoLogon SET FederatedScope=@FederatedScope WHERE RemoteUserAutoLogonId=" & uRow("RemoteUserAutoLogonId"), db.DBConnection, db.DBTransaction)
                    cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@FederatedScope", System.Data.SqlDbType.VarChar, 400, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          FederatedScope))
                    cmd.ExecuteNonQuery()
                End If
                ru = New RemoteUser(CInt(uRow("UserId")), db, UserSession)
            Case Else
                Dim vw As New DataView(t, "FederatedScope='" & FederatedScope & "'", "", DataViewRowState.CurrentRows)
                Select Case vw.Count
                    Case 0
                        'multiple matching records with passed Entity but none match the passed scope 
                    Case 1
                        ru = New RemoteUser(CInt(vw(0)("UserId")), db, UserSession)
                    Case Else
                        Dim matchedUsers As String = ""
                        For Each r As DataRowView In vw
                            matchedUsers += IIf(matchedUsers = "", "", ",") & r("UserId")
                        Next
                        Throw New Exception("Duplicate RemoteUserAutoLogon Federated Entity and/or Scope found in users:" & matchedUsers)
                End Select

        End Select

        Return ru
    End Function
    Public Function GetRemoteUserFromFederatedPersonId(FederatedPersonId As String) As RemoteUser
        Dim ru As RemoteUser = Nothing
        If FederatedPersonId <> "" Then
            Dim cmd2 As New SqlCommand("SELECT UserId FROM RemoteUser WHERE FederatedPersonId=@FederatedPersonId AND UserStatus='Active'", db.DBConnection, db.DBTransaction)
            cmd2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@FederatedPersonId", System.Data.SqlDbType.VarChar, 100, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          FederatedPersonId))
            Dim tUser As DataTable = db.GetDataTableFromSQL(cmd2)
            Select Case tUser.Rows.Count
                Case 0
                Case 1
                    ru = New RemoteUser(CInt(tUser.Rows(0)("UserId")), db, UserSession)
                Case Else
                    Dim matchedUsers As String = ""
                    For Each r As DataRow In tUser.Rows
                        matchedUsers += IIf(matchedUsers = "", "", ",") & r("UserId")
                    Next
                    Throw New Exception("Duplicate Active Users with same FederatedPersonId, users:" & matchedUsers)
            End Select
        End If
        Return ru
    End Function

    Public Sub UpdateFederatedPersonIdFromSession()
        Dim tranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            db.BeginTran()
            tranStartedHere = True

        End If
        Try
            If Me.UserSession.Data("LoggedInWithFederatedPersonId") IsNot Nothing _
                      AndAlso Len(Me.UserSession.Data("LoggedInWithFederatedPersonId")) > 5 _
                      AndAlso Me.UserSession.LoggedInMethod = LoggedInMethods.Federated _
                      AndAlso [Enum].Parse(GetType(AuthorityLevels), Me.RemoteUserRow("AuthorityLevel").ToString) = AuthorityLevels.IndividualSubscriber Then
                Dim ruDup As New RemoteUser(db, Me.UserSession)
                ruDup = ruDup.GetRemoteUserFromFederatedPersonId(Me.UserSession.Data("LoggedInWithFederatedPersonId"))
                If ruDup IsNot Nothing AndAlso ruDup.UserId <> RemoteUserRow("UserId") Then
                    Me.RemoteUserRow("FederatedPersonId") = System.DBNull.Value
                    Me.RemoteUserRow("Notes") = db.IsDBNull(RemoteUserRow("Notes"), "") & Now.ToString("yyyy-MM-dd") & ":FederatedPersonId moved to UserId:" & RemoteUserRow("UserId")
                    ruDup.Save()
                End If
                Me.RemoteUserRow("FederatedPersonId") = Me.UserSession.Data("LoggedInWithFederatedPersonId")
                Me.Save()
            End If
            If tranStartedHere Then db.CommitTran()
        Catch ex As Exception
            If tranStartedHere Then db.RollbackTran()
            Throw New Exception("UpdateFederatedPersonId failed:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub ExpireAllSessions()
        Try
            db.ExecuteSQL("
UPDATE UserSessionData 
SET DataItemValue = CASE DataItemName 
						WHEN 'LoggedIn' THEN 'False'
						WHEN 'Expires' THEN '01-Jan-1900'
					ELSE DataItemValue END
WHERE UserSessionId IN (SELECT UserSessionId FROM UserSession WHERE UserId = " & Me.UserId & ")
AND DataItemName IN ('LoggedIn','Expires')
")
        Catch ex As Exception
            Throw New Exception("ExpireAllSessions failed:" & ex.Message)
        End Try
    End Sub
End Class
