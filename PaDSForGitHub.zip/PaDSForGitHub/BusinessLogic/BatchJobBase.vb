﻿Public MustInherit Class BatchJobBase

#Region "Class Properties"

    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)
            'For batch log create a new connection so the log remains even if the tans is rolled back
            Me._db = value

        End Set
    End Property
    Private _BatchJob As BusinessLogic.BatchJob
    Public Property BatchJob() As BusinessLogic.BatchJob
        Get
            Return Me._BatchJob
        End Get
        Set(ByVal value As BusinessLogic.BatchJob)
            Me._BatchJob = value
        End Set
    End Property

    Public BatchLog As BusinessLogic.BatchLog
    Dim _JobParameters As BusinessLogic.BatchJobParameters
    Public Property JobParameters() As BusinessLogic.BatchJobParameters
        Get
            Return Me._JobParameters
        End Get
        Set(ByVal value As BusinessLogic.BatchJobParameters)
            Me._JobParameters = value
        End Set
    End Property
    Public JobName As String
#End Region

    Public Sub New(ByVal JobName As String, ByVal db As BusinessLogic.Database)
        Me.db = db
        Me.JobName = JobName

    End Sub

    Public Sub Submit(ByVal Parameters As BusinessLogic.BatchJobParameters)

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        Me.BatchJob.Parameters = Parameters
        Me.BatchJob.ProcessToPerform = Me.JobName
        Me.BatchJob.CreateBatchJobEntry()
    End Sub
    Public Sub Execute(ByVal Parameters As BusinessLogic.BatchJobParameters)

    End Sub
End Class
