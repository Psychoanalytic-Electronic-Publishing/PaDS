﻿Imports System.Data.SqlClient
Imports BusinessLogic.UserSession
Imports System.Environment


Public Class PEPwebContent
#Region "Class Properties"

    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property


#End Region
    Sub New(ByVal db As BusinessLogic.Database)
        Me.db = db
    End Sub
    Public Function GetAPIJObject(URLQuery As String) As Newtonsoft.Json.Linq.JObject
        Dim url As String = ""
        Dim tryCout As Integer = 3
        Try
            Dim webReq As System.Net.HttpWebRequest
            Dim response As System.Net.HttpWebResponse = Nothing
            Dim reader As IO.StreamReader
            url = db.GetParameterValue("PEPwebAPIRoot", "https://stage-api.pep-web.rocks/v2/") & URLQuery
            webReq = System.Net.WebRequest.Create(url)
            webReq.UserAgent = "PaDS"
            webReq.Method = "GET"
            webReq.Headers("client-id") = db.GetParameterValue("PaDSClientIdForOPAS", 3)
            webReq.Headers("x-api-authorize") = db.GetParameterValue("PEPWebAPIKey")
            While tryCout > 0
                Try
                    response = webReq.GetResponse()
                    tryCout = 0
                Catch ex As Exception
                    If tryCout = 1 Then
                        batchLog.Update("Tried:" & 3 - tryCout & " times for URL:" & url & " but failed and continued:" & ex.Message)
                        Return Nothing
                    End If

                End Try
                tryCout -= 1
            End While

            reader = New IO.StreamReader(response.GetResponseStream())

            Dim rawresp As String
            rawresp = reader.ReadToEnd()

            Dim rss As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(rawresp)
            Return rss
        Catch ex As Exception
            Throw New Exception("GetMetadataJObject Failed:" & ex.Message & " URL:" & url & " Try:" & 3 - tryCout, ex)
        End Try
    End Function
    Private Function GetMetadataJObject(URLQuery As String) As Newtonsoft.Json.Linq.JObject
        Dim url As String = ""
        Dim tryCout As Integer = 3
        Try
            Dim webReq As System.Net.HttpWebRequest
            Dim response As System.Net.HttpWebResponse = Nothing
            Dim reader As IO.StreamReader
            url = db.GetParameterValue("PEPwebContentMetadataRoot", "http://api.psybrarian.com/v2/Metadata/") & URLQuery
            webReq = System.Net.WebRequest.Create(url)
            webReq.UserAgent = "PaDS"
            webReq.Method = "GET"
            webReq.Headers("client-id") = db.GetParameterValue("PaDSClientIdForOPAS", 3)
            While tryCout > 0
                Try
                    response = webReq.GetResponse()
                    tryCout = 0
                Catch ex As Exception
                    If tryCout = 1 Then
                        batchLog.Update("Tried:" & 3 - tryCout & " times for URL:" & url & " but failed and continued:" & ex.Message)
                        Return Nothing
                    End If

                End Try
                tryCout -= 1
            End While

            reader = New IO.StreamReader(response.GetResponseStream())

            Dim rawresp As String
            rawresp = reader.ReadToEnd()
            Dim rss As Newtonsoft.Json.Linq.JObject = Newtonsoft.Json.Linq.JObject.Parse(rawresp)
            Return rss
        Catch ex As Exception
            Throw New Exception("GetMetadataJObject Failed:" & ex.Message & " URL:" & url & " Try:" & 3 - tryCout, ex)
        End Try
    End Function
    Enum ContentTypes
        Journals
        Books
        Videos
        Volumes
        Documents
    End Enum
    Public Function GetContentTable(ContentType As ContentTypes, Optional SubDirectory As String = Nothing, Optional query As String = Nothing) As DataTable
        Try
            Select Case ContentType
                Case ContentTypes.Documents
                    If SubDirectory = Nothing Then
                        Throw New Exception("For Documents a subdirectory must be supplied")
                    End If

            End Select
            Dim qs As String = IIf(ContentType = ContentTypes.Documents, "Contents", ContentType.ToString) & IIf(SubDirectory <> Nothing, "/" & SubDirectory, "") & IIf(query <> Nothing, "/?" & query, "")
            Dim metadatObj As Newtonsoft.Json.Linq.JObject = GetMetadataJObject(qs)
            If metadatObj Is Nothing Then Return Nothing
            Dim sourceData = From p In metadatObj(metadatObj.First.Path)("responseSet")
                             Select p
            Dim t As DataTable = db.GetDataTableFromSQL("SELECT * FROM Content" & ContentType.ToString & " WHERE 1=2")
            For Each sourceItem In sourceData
                Dim nr As DataRow = t.NewRow
                For Each col As DataColumn In t.Columns
                    nr(col.ColumnName) = sourceItem(col.ColumnName)
                Next
                t.Rows.Add(nr)
            Next
            Return t
        Catch ex As Exception
            Throw New Exception("GetContentTable Failed:" & ex.Message, ex)

        End Try
    End Function
    Public Sub RepopulateLocalContentTable(ContentType As ContentTypes)
        Try
            Dim t As DataTable = Me.GetContentTable(ContentType)
            Dim sql As String = ""
            sql += "DELETE FROM Content" & ContentType.ToString & NewLine
            db.ExecuteSQL(sql)
            Me.AddToLocalContentTableFromTable(ContentType, t, True)
        Catch ex As Exception
            Throw New Exception("RepopulateLocalContent Failed:" & ex.Message, ex)


        End Try
    End Sub
    Public Sub AddToTableFromTable(tbl As DataTable, IgnoreDuplicates As Boolean, SkipColumnNames As String)
        Dim sql As String = ""
        If tbl.TableName = "" Then Throw New Exception("Table must have a name in AddToTableFromTable")
        Try
            Dim tableName As String = tbl.TableName
            For Each r As DataRow In tbl.Rows
                If IgnoreDuplicates Then
                    sql += "If Not EXISTS(Select * FROM " & tableName & " WHERE 1=1 " & NewLine
                    Dim ds As New DataSet
                    Dim da As New SqlDataAdapter(New SqlCommand("Select * from " & tableName & " WHERE 1=2 ", db.DBConnection, db.DBTransaction))
                    da.FillSchema(ds, SchemaType.Mapped, tableName)
                    da.Fill(ds, tableName)
                    da.FillSchema(ds, SchemaType.Mapped, tableName)
                    For Each c As DataColumn In ds.Tables(tableName).PrimaryKey

                        If db.IsDBNull(r(c.ColumnName)) Then
                        Else
                            sql += " AND " & c.ColumnName & " = '" & Left(CStr(r(c.ColumnName)), 200).Replace("'", "''") & "'"
                        End If
                    Next
                    sql += ")" & NewLine
                End If
                sql += "INSERT INTO " & tableName & NewLine
                sql += " ("
                Dim colSQL As String = ""
                For Each c As DataColumn In tbl.Columns
                    If SkipColumnNames.ToLower.Contains(c.ColumnName.ToLower) Then
                    Else
                        colSQL += IIf(colSQL <> "", ",", "")
                        colSQL += c.ColumnName
                    End If

                Next
                sql += colSQL & " )"
                sql += " VALUES("
                colSQL = ""
                For Each c As DataColumn In tbl.Columns
                    If SkipColumnNames.ToLower.Contains(c.ColumnName.ToLower) Then
                    Else
                        colSQL += IIf(colSQL <> "", ",", "")
                        If db.IsDBNull(r(c.ColumnName)) Then
                            colSQL += "NULL"
                        Else
                            colSQL += "'" & Left(CStr(r(c.ColumnName)), 200).Replace("'", "''") & "'"
                        End If
                    End If

                Next
                sql += colSQL & " )" & NewLine

            Next
            If sql <> "" Then db.ExecuteSQL(sql)
        Catch ex As Exception
            Throw New Exception("RepopulateLocalContent Table:" & tbl.TableName & " Failed:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub AddToLocalContentTableFromTable(ContentType As ContentTypes, ContentTable As DataTable, IgnoreDuplicates As Boolean)
        Dim sql As String = ""
        Try
            '     Dim t As DataTable = Me.GetContentTable(ContentType)'
            Dim tableName As String = "Content" & ContentType.ToString
            For Each r As DataRow In ContentTable.Rows
                If IgnoreDuplicates Then
                    sql += "If Not EXISTS(Select * FROM " & tableName & " WHERE 1=1 " & NewLine
                    Dim ds As New DataSet
                    Dim da As New SqlDataAdapter(New SqlCommand("Select * from " & tableName & " WHERE 1=2 ", db.DBConnection, db.DBTransaction))
                    da.FillSchema(ds, SchemaType.Mapped, tableName)
                    da.Fill(ds, tableName)
                    da.FillSchema(ds, SchemaType.Mapped, tableName)
                    For Each c As DataColumn In ds.Tables(tableName).PrimaryKey

                        If db.IsDBNull(r(c.ColumnName)) Then
                        Else
                            sql += " AND " & c.ColumnName & " = '" & Left(CStr(r(c.ColumnName)), 200).Replace("'", "''") & "'"
                        End If
                    Next
                    sql += ")" & NewLine
                End If
            sql += "INSERT INTO " & tableName & NewLine
            sql += " VALUES("
                For Each c As DataColumn In ContentTable.Columns
                    Dim val As String = IIf(c.Ordinal = 0, "", ",")
                    If db.IsDBNull(r(c.ColumnName)) Then
                        val += "NULL"
                    Else
                        val += "'" & Left(CStr(r(c.ColumnName)), 200).Replace("'", "''") & "'"
                    End If
                    sql += val
                Next
                sql += " )" & NewLine

            Next
            If sql <> "" Then db.ExecuteSQL(sql)
        Catch ex As Exception
            Throw New Exception("RepopulateLocalContent ContentType:" & ContentType.ToString & " ContentTable:" & ContentTable.TableName & " Failed:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub RepopulateVolumesAndDocs()
        Dim sql As String = ""
        Dim t As DataTable = Me.GetContentTable(BusinessLogic.PEPwebContent.ContentTypes.Journals)
        t.TableName = "Journals"
        Dim jofrnCount As Integer = 1
        Dim msg As String = ""
        '  For Each r As DataRow In t.Rows
        Dim r2 As DataRow = Nothing
        db.BeginTran()
        Try
            sql = "
                    DELETE FROM ContentVolumes  
                    DELETE FROM ContentDocuments 
                    "
            ' WHERE PEPCode = '" & r("PEPCode") & "'
            'WHERE PEPCode = '" & r("PEPCode") & "'
            db.CommandTimeout = 1200 ' 20minutes
            db.ExecuteSQL(sql)
            batchLog.Update("ContentVolumes & ContentDocuments Deleted:")
            Dim vols As DataTable = Me.GetContentTable(BusinessLogic.PEPwebContent.ContentTypes.Volumes, "", "limit=30000")
            vols.TableName = "Volumes"
            Me.AddToLocalContentTableFromTable(ContentTypes.Volumes, vols, True)


            For Each r2 In vols.Rows
                Try
                    Dim docs As DataTable = Me.GetContentTable(BusinessLogic.PEPwebContent.ContentTypes.Documents, r2("PEPCode") & "/" & r2("vol"), "limit=10000")
                    If docs Is Nothing Then
                        batchLog.Update(r2("PEPCode") & "/" & r2("vol") & " no content retrieved:")
                        Exit Try
                    End If
                    docs.TableName = "Documents"
                    Me.AddToLocalContentTableFromTable(ContentTypes.Documents, docs, True)
                    batchLog.Update(r2("PEPCode") & "/" & r2("vol") & " added:")
                Catch ex As Exception
                    Throw New Exception(r2("PEPCode") & "/" & r2("vol") & " failed:" & ex.Message)
                End Try

            Next
            jofrnCount += 1
            '  msg += r("PEPCode") & " Compltete" & Environment.NewLine
            db.CommitTran()
        Catch ex As Exception
            Dim rollbackTimeoutMsg As String = Nothing
            Try
                db.RollbackTran()
            Catch ex1 As Exception
                If ex1.Message.Contains("Execution Timeout Expired") Then
                    'Roolback can timeout as the rollback uses the timeout in the connection string which for pads is set to 2 sec.  It throws an error even though rollback contiunes, so we can ignore it
                    rollbackTimeoutMsg = "Rollback timed out, but should have continued"
                Else
                    Throw ex
                End If
            End Try
            Throw New Exception("RepopulateVolumesAndDocs failed:" & ex.Message & IIf(rollbackTimeoutMsg <> Nothing, Environment.NewLine & rollbackTimeoutMsg, "") & Environment.NewLine & jofrnCount & "  " & msg, ex)
        End Try
        '    Next
    End Sub
    Dim batchLog As BatchLog = Nothing
    Sub ExecuteRepopulateAllPEPWebContent(ByVal Parameters As BusinessLogic.BatchJobParameters)
        batchLog = New BatchLog("ExecuteRepopulateAllPEPWebContent", "", Me.db)
        Try

            Me.RepopulateLocalContentTable(BusinessLogic.PEPwebContent.ContentTypes.Journals)
            batchLog.Update("Journals repopulated")
            Me.RepopulateLocalContentTable(BusinessLogic.PEPwebContent.ContentTypes.Books)
            batchLog.Update("Books repopulated")
            Me.RepopulateLocalContentTable(BusinessLogic.PEPwebContent.ContentTypes.Videos)
            batchLog.Update("Videos repopulated")
            Me.RepopulateVolumesAndDocs()
            batchLog.Update("Valumes and docs repopulated")
            batchLog.Update("ExecuteRepopulateAllPEPWebContent Complete", "Complete")

        Catch ex As Exception
            batchLog.Update(ex.Message, "Failed")
            Throw New Exception("ExecuteRepopulateAllPEPWebContent failed:" & ex.Message, ex)
        End Try
    End Sub

    Sub ExecuteGetPEPWebSessionLog(ByVal Parameters As BusinessLogic.BatchJobParameters)
        batchLog = New BatchLog("ExecuteGetPEPWebSessionLog", "", Me.db)
        Try

            Dim pc As New BusinessLogic.PEPwebContent(db)
            Dim cmd As New SqlCommand("SELECT top 1 * FROM PEPWebSessionLog ORDER BY LastUpdate DESC", Me.db.DBConnection, Me.db.DBTransaction)
            Dim da As New SqlDataAdapter(cmd)
            Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(da)
            da.InsertCommand = cmdBld.GetInsertCommand()
            Dim t As New DataTable
            t.TableName = "PEPWebSessionLog"
            da.Fill(t)
            Dim StartFrom As Date = Now().AddDays(-7)
            If t.Rows.Count <> 0 Then StartFrom = t.Rows(0)("LastUpdate")
            '22/2/21    Change reports endpoint to be under Admin
            Dim qs As String = "Admin/Reports/Session-Log?startdate=" & StartFrom.ToString("yyyy-MM-dd") & "&limit=10000&offset=0&download=false"
            batchLog.Update("OPAS Query:" & qs)
            Dim metadatObj As Newtonsoft.Json.Linq.JObject = pc.GetAPIJObject(qs)
            If metadatObj Is Nothing Then
                batchLog.Update("No data reterived")
            Else
                batchLog.Update("Data reterived")
                Dim sourceData = From p In metadatObj(metadatObj.First.Path)("responseSet")
                                 Select p
                Dim rowCount As Integer = 0
                For Each sourceItem As Newtonsoft.Json.Linq.JObject In sourceData
                    If CDate(sourceItem("row")("last_update")) >= StartFrom Then
                        Dim nr As DataRow = t.NewRow
                        For Each col As DataColumn In t.Columns
                            If col.ColumnName = "UserId" And sourceItem("row")("global_uid").ToString <> "" Then nr("UserId") = sourceItem("row")("global_uid").ToString
                            If col.ColumnName = "UserSessionId" And sourceItem("row")("session_id").ToString <> "" Then nr("UserSessionId") = sourceItem("row")("session_id").ToString
                            If col.ColumnName = "SessionStart" And sourceItem("row")("session_start").ToString <> "" Then nr("SessionStart") = sourceItem("row")("session_start")
                            If col.ColumnName = "SessionEnd" And sourceItem("row")("session_end").ToString <> "" Then nr("SessionEnd") = sourceItem("row")("session_end")
                            If col.ColumnName = "ItemOfInterest" And sourceItem("row")("item_of_interest").ToString <> "" Then nr("ItemOfInterest") = Left(sourceItem("row")("item_of_interest").ToString, 300)
                            If col.ColumnName = "Endpoint" And sourceItem("row")("endpoint").ToString <> "" Then nr("Endpoint") = Left(sourceItem("row")("endpoint").ToString, 500)
                            If col.ColumnName = "Params" And sourceItem("row")("params").ToString <> "" Then nr("Params") = Left(sourceItem("row")("params").ToString, 3000)
                            If col.ColumnName = "ReturnStatusCode" And sourceItem("row")("return_status_code").ToString <> "" Then nr("ReturnStatusCode") = Left(sourceItem("row")("return_status_code").ToString, 50)
                            If col.ColumnName = "ReturnAddedStatusMessage" And sourceItem("row")("return_added_status_message").ToString <> "" Then nr("ReturnAddedStatusMessage") = Left(sourceItem("row")("return_added_status_message").ToString, 3000)
                            If col.ColumnName = "LastUpdate" And sourceItem("row")("last_update").ToString <> "" Then nr("LastUpdate") = sourceItem("row")("last_update")
                        Next
                        t.Rows.Add(nr)
                        rowCount += 1
                    End If



                Next
                batchLog.Update("DataSet populated with:" & rowCount & " rows")

                da.Update(t)
                batchLog.Update("DataBase updated with:" & rowCount & " rows")

            End If

            batchLog.Update("ExecuteGetPEPWebSessionLog Complete", "Complete")

        Catch ex As Exception
            batchLog.Update(ex.Message, "Failed")
            Throw New Exception("ExecuteGetPEPWebSessionLog failed:" & ex.Message, ex)
        End Try
    End Sub
End Class

