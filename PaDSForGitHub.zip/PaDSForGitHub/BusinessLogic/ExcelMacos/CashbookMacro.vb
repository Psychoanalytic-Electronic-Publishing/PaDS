Option Explicit On

Sub cmdSetDefault_Click()

    FormatPivot "Default"
End Sub
Sub cmdSetIJP_Click()

    FormatPivot "IJP"
End Sub
Public Function FormatPivot(strFormatType As String)
    On Error GoTo ProcedureError

    Dim pvt As Excel.PivotTable
    Dim fld As Excel.PivotField
    Dim wkb As Excel.Workbook
    Dim pi As Excel.PivotItem

    Set wkb = ActiveWorkbook
    
    Set pvt = wkb.Sheets("Pivot").PivotTables("Pivot")
    
    'GoTo EndMark
    On Error Resume Next
    For Each fld In pvt.PivotFields
        fld.Orientation = xlHidden
    Next
    On Error GoTo ProcedureError

    Select Case strFormatType
        Case "IJP"
            'pvt.PivotFields("CompanyName").Orientation = xlPageField
            pvt.PivotFields("CurrencyCode").Orientation = xlPageField
            pvt.PivotFields("BankedDate").Orientation = xlRowField
            ' pvt.PivotFields("BankedDate").NumberFormat = "d-mmm-yy"
            pvt.PivotFields("EntryType").Orientation = xlRowField
            pvt.PivotFields("PaymentType").Orientation = xlRowField
            pvt.PivotFields("AccountName").Orientation = xlRowField
            pvt.PivotFields("CashbookId").Orientation = xlRowField
            For Each pi In pvt.PivotFields("EntryType").PivotItems
                If pi.Name = "Payment" Then
                    pi.ShowDetail = True
                Else
                    pi.ShowDetail = True
                End If
            Next
            For Each pi In pvt.PivotFields("PaymentCardMerchant").PivotItems
                If pi.Name = "Payment" Then
                    pi.ShowDetail = True
                Else
                    pi.ShowDetail = True
                End If
            Next

            'Check if there is already a total fiels by referencing it and seeing if there is an error
            On Error Resume Next
            pvt.DataFields("Sum of AmountInNative").Name = "Sum of AmountInNative"
            If Err <> 0 Then
                pvt.PivotFields("AmountInNative").Orientation = xlDataField
            End If
            On Error GoTo ProcedureError

            For Each fld In pvt.DataFields
                fld.Function = xlSum
                fld.NumberFormat = "#,##0.00"

            Next
            'Delete the total Rows
            On Error Resume Next
            wkb.Sheets("Pivot").Cells.Find(What:="total", After:=ActiveCell, LookIn:=xlFormulas, LookAt _
                :=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlNext, MatchCase:=
                False).Activate
            If Err = 0 Then Selection.Delete
            On Error Resume Next
            wkb.Sheets("Pivot").Cells.Find(What:="total", After:=ActiveCell, LookIn:=xlFormulas, LookAt _
                :=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlNext, MatchCase:=
                False).Activate
            If Err = 0 Then Selection.Delete
            On Error Resume Next
            wkb.Sheets("Pivot").Cells.Find(What:="total", After:=ActiveCell, LookIn:=xlFormulas, LookAt _
                :=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlNext, MatchCase:=
                False).Activate
            If Err = 0 Then Selection.Delete
            On Error GoTo ProcedureError

            With wkb.Sheets("Pivot").PageSetup
                .PrintTitleRows = ""
                .PrintTitleColumns = ""
                .Zoom = False
                .FitToPagesWide = 1
                .FitToPagesTall = False
            End With
            wkb.Sheets("Pivot").Columns("A:X").EntireColumn.AutoFit
        Case "Default"
            pvt.PivotFields("Month").Orientation = xlRowField
            pvt.PivotFields("CurrencyCode").Orientation = xlRowField
            pvt.PivotFields("PaymentType").Orientation = xlRowField
            pvt.PivotFields("BankedDate").Orientation = xlRowField
            '      pvt.PivotFields("BankedDate").NumberFormat = "d-mmm-yy" - doesn't work!
            For Each pi In pvt.PivotFields("Month").PivotItems
                pi.ShowDetail = True
            Next
            For Each pi In pvt.PivotFields("CurrencyCode").PivotItems
                pi.ShowDetail = True
            Next
            '      For Each pi In pvt.PivotFields("PaymentType").PivotItems
            '          pi.ShowDetail = True
            '     Next
            'Check if there is already a total fiels by referencing it and seeing if there is an error
            On Error Resume Next
            pvt.DataFields("Sum of AmountInNative").Name = "Sum of AmountInNative"
            If Err <> 0 Then
                pvt.PivotFields("AmountInNative").Orientation = xlDataField
            End If
            On Error GoTo ProcedureError

            For Each fld In pvt.DataFields
                fld.Function = xlSum
                fld.NumberFormat = "#,##0.00"

            Next

            '    Sheets("Pivot").PivotTables("Pivot").PivotCache.Refresh

            'Delete the total Rows
            Sheets("Pivot").PivotTables("Pivot").PivotFields("PaymentType").Subtotals = Array(False, False, False, False, False, False, False, False, False, False, False, False)
            Sheets("Pivot").PivotTables("Pivot").PivotFields("BankedDate").Subtotals = Array(False, False, False, False, False, False, False, False, False, False, False, False)

            With wkb.Sheets("Pivot").PageSetup
                .PrintTitleRows = ""
                .PrintTitleColumns = ""
                .Zoom = False
                .FitToPagesWide = 1
                .FitToPagesTall = False
            End With
            wkb.Sheets("Pivot").Columns("A:X").EntireColumn.AutoFit
    End Select
EndMark:
    wkb.Sheets("Pivot").Select
    wkb.Sheets("Pivot").Cells(5, 3).Select

    On Error Resume Next
    wkb.Sheets("Pivot").Shapes("cmdDefault").Select
    If Err <> 0 Then
        'Assume button not there so add it
        wkb.Sheets("Pivot").Buttons.Add(1, 1, 60, 20).Select
        wkb.Parent.Selection.Name = "cmdDefault"
    End If
    On Error GoTo ProcedureError
    wkb.Parent.Selection.OnAction = "cmdSetDefault_Click"
    wkb.Parent.Selection.Characters.Text = "Default"
    wkb.Parent.Selection.ShapeRange.Left = 0
    wkb.Parent.Selection.ShapeRange.Top = 20
    wkb.Parent.Selection.ShapeRange.Width = 50
    wkb.Parent.Selection.ShapeRange.Height = 15
    On Error Resume Next
    wkb.Sheets("Pivot").Shapes("cmdIJP").Select
    If Err <> 0 Then
        'Assume button not there so add it
        wkb.Sheets("Pivot").Buttons.Add(1, 1, 60, 20).Select
        wkb.Parent.Selection.Name = "cmdIJP"
    End If
    On Error GoTo ProcedureError
    wkb.Parent.Selection.OnAction = "cmdSetIJP_Click"
    wkb.Parent.Selection.Characters.Text = "IJP"
    wkb.Parent.Selection.ShapeRange.Left = 51
    wkb.Parent.Selection.ShapeRange.Top = 20
    wkb.Parent.Selection.ShapeRange.Width = 50
    wkb.Parent.Selection.ShapeRange.Height = 15

    Range(Sheets("Criteria").Range("PivotStart").Value).Select

ProcedureExit:
    Exit Function

ProcedureError:
    Select Case Err.Number
        Case Else
            GlobalErr Err.Number, Err.Description, "FormatPivot"
        Resume ProcedureExit
            Resume
    End Select

End Function

Public Function GlobalErr(lngErrNumber As Long,
                        strErrString As String,
                        Optional strErrLocation As Variant _
                          )

    If IsMissing(strErrLocation) Then
        strErrLocation = "In Report Template"
    End If

    Sheets("Criteria").Range("a10").Value = "UNEXPECTED ERROR: " & lngErrNumber _
                & "-" & strErrString _
                & "-" & strErrLocation
End Function









