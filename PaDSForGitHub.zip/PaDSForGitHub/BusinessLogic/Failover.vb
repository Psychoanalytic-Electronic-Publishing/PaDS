﻿Imports System.Data.SqlClient
Public Class Failover
    Public Sub New()
        'Can be opened without a DB and should still work, just!!
    End Sub
    Public IsDatabaseServerPrimaryOrSecondary As String = "Primary"

    'This parameter is set to true if the primary has been unavailable for less than FailoverIfPrimaryDownForMoreThanXMinutes 
    'and should only be used read only
    Public IsReadOnlyOnSecondary As Boolean = False
    Public dbSecondary As BusinessLogic.Database = Nothing

    Public Function ChooseConnectionString(ByVal PrimaryConnectionString As String _
                                           , ByVal SecondaryConnectionString As String _
                                           , ByVal ConnectionStringSecurityOnSecondary As String _
                                           , ByVal SourceSystem As String _
                                           , ByVal SourceServer As String
                                            ) As String
        '          , Optional ByVal TriggerFailover As Boolean = True
        '
        Dim TriggerFailover As Boolean = True 'Apr 2020: This is no longer used, it used to be passed false from all but PaDS Checks so only PaDS checks triggered failover.  
        'Since time before failover is now 1 day, not needed.
        Dim IsSecondaryMaster As Boolean = False
        Dim IsSecondaryAvailable As Boolean = True
        Dim dbSecondary As BusinessLogic.Database = Nothing
        Try
            dbSecondary = New BusinessLogic.Database(SecondaryConnectionString)
            Try
                IsSecondaryMaster = CBool(dbSecondary.GetParameterValue("FailoverThisIsMasterServer"))
            Catch ex As Exception
                'parameter not found so create it
                dbSecondary.SetParameterValue("FailoverThisIsMasterServer", False)
            End Try
            If IsSecondaryMaster Then
                IsDatabaseServerPrimaryOrSecondary = "Secondary"
            End If
        Catch ex As Exception
            IsSecondaryAvailable = False

        End Try

        ' Is failover flag set on secondary server?
        If IsSecondaryMaster Then
            ' Y = use secondary server
            Try
                dbSecondary.DBConnection.Close()
            Catch ex As Exception
            End Try
            Return SecondaryConnectionString
        Else
            ' N = use primary server
            ' Can we contact primary server?
            Dim myConn As New SqlConnection(PrimaryConnectionString)
            Try
                myConn.Open()
                Dim db As New Database(PrimaryConnectionString)
                Try
                    'if primary available but secondary isn't thrn send error if happens for more than 10 minutes
                    If Not IsSecondaryAvailable Then
                        Dim DateTimeSecondaryConenctionUnavailable As String = ""
                        Try
                            DateTimeSecondaryConenctionUnavailable = db.GetParameterValue("DateTimeSecondaryConenctionUnavailable")
                        Catch ex As Exception
                            db.SetParameterValue("DateTimeSecondaryConenctionUnavailable", "")
                        End Try

                        If IsDate(DateTimeSecondaryConenctionUnavailable) Then
                            If CDate(DateTimeSecondaryConenctionUnavailable).AddMinutes(10) < Now() Then
                                'only send email if not running restore on secondary
                                Dim RunningSecondaryDBRestore As Boolean = False
                                Try
                                    RunningSecondaryDBRestore = db.GetParameterValue("RunningSecondaryDBRestore")
                                Catch ex As Exception
                                End Try
                                If Not RunningSecondaryDBRestore Then
                                    Dim e As New Email(db) '24/8/21 - Pass email to correct Bug
                                    e.SendErrorEmail("PaDS Secondary connection error", "Secondary Connection unavailable since:" & CDate(DateTimeSecondaryConenctionUnavailable).ToString("dd-MMM-yyyy HH:mm:ss") & ".  Next email shouldn't be for 2 hours.")
                                End If
                                'set DateTimeSecondaryConenctionUnavailable so not emailed again for 2 hours
                                db.SetParameterValue("DateTimeSecondaryConenctionUnavailable", Now().AddHours(2).ToString("dd-MMM-yyyy HH:mm:ss"))
                            End If
                        Else
                            db.SetParameterValue("DateTimeSecondaryConenctionUnavailable", Now().ToString("dd-MMM-yyyy HH:mm:ss"))

                        End If
                    Else
                        db.SetParameterValue("DateTimeSecondaryConenctionUnavailable", "")
                    End If
                Catch ex1 As Exception
                Finally
                    db.DBConnection.Close()
                    db = Nothing
                End Try
            Catch ex As SqlException
                '4/11/15    James Woosnam   Put secondary procesing in try catch so we close secondary connection even if secondary processing failes
                Try
                    ' Cannot contect primary server!
                    ' Use secondary server
                    If Not IsSecondaryAvailable Then
                        Throw New Exception("PaDS is currently unavailable")
                    End If
                    Dim Message As String = ""
                    Message = "SourceWebServer=" & SourceServer _
                            & ";SourcePaDSSystem:" & SourceSystem _
                            & ";Datetime:" & Now.ToString()

                    'Check to see when first started failing, if less than "FailoverIfPrimaryDownForMoreThanXMinutes"
                    Dim FailoverStartedFailingAtDateTime As Date = Now()
                    Dim FailoverIfPrimaryDownForMoreThanXMinutes As Integer = 1440 '1 day
                    Try
                        FailoverIfPrimaryDownForMoreThanXMinutes = CInt(dbSecondary.GetParameterValue("FailoverIfPrimaryDownForMoreThanXMinutes"))
                    Catch ex2 As Exception
                        dbSecondary.SetParameterValue("FailoverIfPrimaryDownForMoreThanXMinutes", FailoverIfPrimaryDownForMoreThanXMinutes)
                    End Try
                    Try
                        Try
                            FailoverStartedFailingAtDateTime = CDate(dbSecondary.GetParameterValue("FailoverStartedFailingAtDateTime"))
                        Catch ex2 As Exception
                            dbSecondary.SetParameterValue("FailoverStartedFailingAtDateTime", CDate("31-dec-4949"))
                            FailoverStartedFailingAtDateTime = CDate("31-dec-4949")
                        End Try
                        If FailoverStartedFailingAtDateTime = CDate("31-dec-4949") Then
                            'Start Failover timer: If not initilised then set to now and send email
                            Dim MakeReadOnlyMessage As String = ""
                            If TriggerFailover Then 'TriggerFailover boolean: see note at top
                                dbSecondary.SetParameterValue("FailoverStartedFailingAtDateTime", Now())
                                'Make secondary DB reasonly
                                Dim dbForSecurity As Database = Nothing
                                Try
                                    dbForSecurity = New Database(ConnectionStringSecurityOnSecondary)
                                    Try
                                        ExecuteDBPermissions(dbForSecurity, True)
                                    Catch ex2 As Exception
                                        MakeReadOnlyMessage = "Make Secondary Read only failed:" & ex2.Message
                                    End Try
                                Catch ex2 As Exception
                                    MakeReadOnlyMessage += "Open ConnectionStringSecurityOnSecondary failed:" & ex2.Message
                                Finally
                                    Try
                                        dbForSecurity.DBConnection.Close()
                                    Catch ex3 As Exception
                                    End Try
                                End Try

                            End If
                            Try
                                Dim email As New BusinessLogic.Email(dbSecondary)
                                Dim Body As String = ""
                                Body = "**** PaDS Primary Server Not Available ****<BR>"
                                Body += "<BR><BR><B>You have:" & FailoverIfPrimaryDownForMoreThanXMinutes & " minutes before failover"
                                Body += "<BR><BR>Details:" & Message.Replace(";", "<br>")
                                Body += "<BR><BR>Connection String:" & dbSecondary.DBConnection.ConnectionString
                                If Not TriggerFailover Then
                                    Body += "<BR><BR>***Please Note***<BR>This message was initiated by the PaDS Check page (Usually initiated by PingDom) and will therefore not start the failover count.<br>****"
                                End If
                                If MakeReadOnlyMessage <> "" Then
                                    Body += "<BR><BR>***Please Note***<BR>" & MakeReadOnlyMessage & "<br>****"
                                End If
                                email.SendErrorEmail("PaDS Primary Unavailable.  You have " & FailoverIfPrimaryDownForMoreThanXMinutes & " minutes before failover", Body)
                            Catch ex3 As Exception
                            End Try

                        End If
                    Catch ex2 As Exception
                        dbSecondary.SetParameterValue("FailoverStartedFailingAtDateTime", FailoverStartedFailingAtDateTime)
                    End Try
                    If FailoverStartedFailingAtDateTime.AddMinutes(FailoverIfPrimaryDownForMoreThanXMinutes) < Now() _
                        And TriggerFailover Then
                        'If promary down for more than 1440 (1day) miuntes then fail over, otherwise just return secondry string
                        ' Set FailoverThisIsMasterServer flag on secondary server
                        dbSecondary.SetParameterValue("FailoverThisIsMasterServer", "1")
                        dbSecondary.SetParameterValue("FailoverThisIsMasterServerDesc", Message)

                        'Make secondary DB reasonly
                        Dim MakeWritableMessage As String = ""
                        Dim ReseedMessage As String = ""
                        Dim dbForSecurity As Database = Nothing
                        Try
                            dbForSecurity = New Database(ConnectionStringSecurityOnSecondary)
                            Try
                                ExecuteDBPermissions(dbForSecurity, False)
                            Catch ex2 As Exception
                                MakeWritableMessage = "Make Secondary writeable failed:" & ex2.Message
                            End Try
                            Try
                                Dim cmd As New SqlCommand("Exec sp500Reseed", dbForSecurity.DBConnection)
                                cmd.ExecuteNonQuery()
                            Catch ex2 As SqlException
                                ReseedMessage = "Exec sp500Reseed failed:" & ex2.Message
                            End Try
                        Catch ex2 As Exception
                            MakeWritableMessage += "Open ConnectionStringSecurityOnSecondary failed:" & ex2.Message
                        Finally
                            Try
                                dbForSecurity.DBConnection.Close()
                            Catch ex3 As Exception
                            End Try
                        End Try
                        Try
                            Dim email As New BusinessLogic.Email(dbSecondary)
                            Dim Body As String = ""
                            Body = "**** PaDS has failed over ****<BR>"
                            Body += "<BR><BR>PaDS Failover:" & Message.Replace(";", "<br>")
                            Body += "<BR><BR>Connection String:" & dbSecondary.DBConnection.ConnectionString
                            If MakeWritableMessage <> "" Then
                                Body += "<BR><BR>***Please Note***<BR>" & MakeWritableMessage & "<br>****"
                            End If
                            If ReseedMessage <> "" Then
                                Body += "<BR><BR>***Please Note***<BR>" & ReseedMessage & "<br>****"
                            End If

                            email.SendErrorEmail("PaDS Failover:" & Message, Body)
                        Catch ex3 As Exception
                        End Try
                    Else
                        'Promary not available, but don't failover for now 
                        IsReadOnlyOnSecondary = True
                    End If

                    IsDatabaseServerPrimaryOrSecondary = "Secondary"
                    Try
                        dbSecondary.DBConnection.Close()
                    Catch ex3 As Exception
                    End Try
                    Return SecondaryConnectionString

                Catch ex1 As Exception
                    '4/11/15    James Woosnam   Put secondary procesing in try catch so we close secondary connection even if secondary processing failes
                    Try
                        dbSecondary.DBConnection.Close()
                    Catch ex3 As Exception
                    End Try
                    Throw ex1
                End Try
            End Try

            ' Yes we can connect to the primary server, so all is well
            ' Close connection and return primary server connection string
            If myConn.State = ConnectionState.Open Then
                myConn.Close()
            End If
            If IsSecondaryAvailable Then
                dbSecondary.SetParameterValue("FailoverStartedFailingAtDateTime", "31-Dec-4949")
            End If

            Try
                dbSecondary.DBConnection.Close()
            Catch ex3 As Exception
            End Try
            Return PrimaryConnectionString
        End If

    End Function
    Sub ExecuteDBPermissions(ByVal db As BusinessLogic.Database, ByVal MakeReadOnly As Boolean)
        Try
            Dim cmd As New SqlCommand("sp510GrantObjectRights", db.DBConnection, db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@MakeReadOnly", System.Data.SqlDbType.Bit, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                      , MakeReadOnly))
            cmd.ExecuteNonQuery()
        Catch ex2 As SqlException
            Throw New Exception("Could not apply DB Permissions:" & ex2.Message)
        End Try

    End Sub
End Class
