﻿Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class CompanyAccount
#Region "Class Properties"
    Public MainDataset As New DataSet
    Public ReadonlyDataset As New DataSet
    Dim UserSession As UserSession

    Dim _CompanyAccountId As Long = Nothing
    Public Property CompanyAccountId() As Integer
        Get
            If Me._CompanyAccountId = Nothing Then
                If Me.MainDataset.Tables.Count > 0 Then
                    Me._CompanyAccountId = Me.CompanyAccountRow("CompanyAccountId")
                End If
            End If
            Return Me._CompanyAccountId
        End Get
        Set(ByVal value As Integer)
            _CompanyAccountId = value
        End Set
    End Property
    Public ReadOnly Property CompanyAccountName As String
        Get
            Return Me.CompanyAccountRow("CompanyAccountName")
        End Get
    End Property

    Private Sub Initilise()
        Dim xx As Integer = 0
        Me.MainDataset = New DataSet
        Me._daCompanyAccount = Nothing
        xx = Me.CompanyAccount.Rows.Count
    End Sub

    Private _db As Database = Nothing
    Public Property db() As Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As Database)

            Me._db = value
        End Set
    End Property
#End Region

#Region "DependantTables"
    '***********************************************
    'CompanyAccount
    Public ReadOnly Property CompanyAccount() As DataTable
        Get
            If Me.MainDataset.Tables("CompanyAccount") Is Nothing Then
                Me.daCompanyAccount.Fill(Me.MainDataset, "CompanyAccount")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("CompanyAccount").Columns("CompanyAccountId")}
            Me.MainDataset.Tables("CompanyAccount").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("CompanyAccount")
        End Get
    End Property
    Private _daCompanyAccount As SqlDataAdapter

    Private ReadOnly Property daCompanyAccount() As SqlDataAdapter
        Get
            If Me._daCompanyAccount Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM CompanyAccount"
                sql += " WHERE CompanyAccountId=" & Me.CompanyAccountId
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daCompanyAccount = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daCompanyAccount)
                _daCompanyAccount.UpdateCommand = cmdBld.GetUpdateCommand()
                _daCompanyAccount.InsertCommand = cmdBld.GetInsertCommand()
                _daCompanyAccount.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daCompanyAccount.InsertCommand.Transaction = Me.db.DBTransaction
                _daCompanyAccount.UpdateCommand.Transaction = Me.db.DBTransaction
                _daCompanyAccount.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daCompanyAccount
        End Get
    End Property

    Public ReadOnly Property CompanyAccountRow() As DataRow
        Get
            If Me.CompanyAccount.Rows.Count = 0 Then
                Me.daCompanyAccount.Fill(Me.MainDataset.Tables("CompanyAccount"))
                If Me.CompanyAccount.Rows.Count = 0 Then
                    Throw New Exception("UserError: CompanyAccountId:" & Me.CompanyAccountId & " can't be found")
                End If
            End If
            Return Me.CompanyAccount.Rows(0)
        End Get
    End Property
#End Region

    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.CompanyAccountId = 0
    End Sub
    Sub New(ByVal CompanyAccountId As Integer, ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.CompanyAccountId = CompanyAccountId
        Me.Initilise()
    End Sub

#Region "Actions"
    Public Sub Save()
        Dim sql As String = ""
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Dim logs As New BusinessLogic.Logs(db, Me.UserSession)

            Select Case Me.CompanyAccountRow.RowState
                Case DataRowState.Added, DataRowState.Modified
                    CompanyAccountRow("LastUpdatedDateTime") = Now()
                    CompanyAccountRow("LastUpdatedByUserId") = UserSession.UserName20
                    Try
                        logs.WriteAuditLog("CompanyAccount", CompanyAccountRow("CompanyAccountId"), UserSession.UserId, UserSession.UserName, Me.CompanyAccountRow.RowState.ToString(), "")
                    Catch ex As Exception
                    End Try
            End Select

            Me.daCompanyAccount.Update(Me.MainDataset, "CompanyAccount")

            If TranStartedHere Then
                Me.db.CommitTran()
            End If

        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try
    End Sub
    Public Sub AddCompanyAccount(ByVal SubscriberId As Integer _
                                 , ByVal CompanyId As Integer _
                                 , ByVal AccountNumber As String _
                                 , ByVal AccountType As String _
                                 , ByVal DiscountRateID As Integer _
                                 , ByVal RateType As String _
                                 , ByVal BillingAddressId As Integer _
                                 , ByVal Notes As String _
                                 , ByVal RequireReceipt As Boolean _
                                 , ByVal RequireInvoice As Boolean
                                 )

        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Dim row As DataRow = Me.CompanyAccount.NewRow
            row("CompanyAccountId") = 0
            row("SubscriberId") = SubscriberId
            row("CompanyId") = CompanyId
            row("CompanyAccountStatus") = "Live"
            row("AccountNumber") = AccountNumber
            row("AccountType") = AccountType
            row("DiscountRateID") = DiscountRateID
            row("RateType") = RateType
            row("BillingAddressId") = BillingAddressId
            row("Notes") = Notes
            row("RequireReceipt") = RequireReceipt
            row("RequireInvoice") = RequireInvoice
            row("CreatedDateTime") = Now()
            row("CreatedByUserId") = UserSession.UserName20
            row("LastUpdatedDateTime") = Now()
            row("LastUpdatedByUserId") = UserSession.UserName20

            Me.CompanyAccount.Rows.Add(row)
            Me.daCompanyAccount.Update(Me.MainDataset, "CompanyAccount")

            Me.CompanyAccountId = db.DLookup("max(CompanyAccountId)", "CompanyAccount", "")
            Me.Initilise()

            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try
    End Sub
End Class

#End Region