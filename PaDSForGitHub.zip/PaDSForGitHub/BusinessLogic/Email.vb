Imports System.Net.Mail
Public Class Email
    Public MailMessage As New MailMessage

#Region "Class Properties"

    Public WriteOnly Property From() As String
        Set(ByVal Value As String)
            MailMessage.From = New MailAddress(Value)
        End Set
    End Property
    Public Property SendTo() As String
        Get
            Return MailMessage.To.ToString
        End Get
        Set(ByVal Value As String)
            MailMessage.To.Add(Value)
        End Set

    End Property
    Public Property CC() As String
        Get
            Return MailMessage.CC.ToString
        End Get
        Set(ByVal Value As String)
            MailMessage.CC.Add(Value)
        End Set
    End Property
    Public Property BCC() As String
        Get
            Return MailMessage.Bcc.ToString
        End Get
        Set(ByVal Value As String)
            MailMessage.Bcc.Add(Value)
        End Set
    End Property
    Public Property Subject() As String
        Get
            Return MailMessage.Subject()
        End Get
        Set(ByVal Value As String)
            MailMessage.Subject = Value
        End Set
    End Property
    Public Property Body() As String
        Get
            Return MailMessage.Body
        End Get
        Set(ByVal Value As String)
            MailMessage.Body = Value
        End Set
    End Property
    Public Property IsBodyHTML() As Boolean
        Get
            Return MailMessage.IsBodyHtml
        End Get
        Set(ByVal Value As Boolean)
            MailMessage.IsBodyHtml = Value
        End Set
    End Property
    Public Property BodyEncoding() As System.Text.Encoding
        Get
            Return MailMessage.BodyEncoding()
        End Get
        Set(ByVal Value As System.Text.Encoding)
            MailMessage.BodyEncoding = Value
        End Set
    End Property
    Dim _SMTPClient As SmtpClient = Nothing
    Public Property SMTPClient() As SmtpClient
        Get
            If Me._SMTPClient Is Nothing Then
                'Try and find the host in params, if this doesn't work just use the default
                Try
                    Me._SMTPClient = New SmtpClient(Me.db.GetParameterValue("SMTPServer"))
                Catch ex As Exception
                    'AS it is so important that email get out even if DB not available the emergency details are hardcoded
                    Me._SMTPClient = New SmtpClient("smtp.gmail.com")
                End Try

            End If
            Return Me._SMTPClient
        End Get
        Set(ByVal Value As SmtpClient)
            Me._SMTPClient = Value
        End Set
    End Property
    Private _db As BusinessLogic.Database = Nothing
    Private Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property
    Public ReadOnly Property EnableSSL As Boolean
        Get
            Try
                If CBool(Me.db.GetParameterValue("SMTPEnableSsl")) Then
                    Return True
                Else
                    Return False
                End If
            Catch ex As Exception
                Return True
            End Try
        End Get
    End Property

#End Region
    Public Sub New()
        'Can be opened without a DB and should still work, just!!
    End Sub
    Public Sub New(ByVal DB As BusinessLogic.Database)
        Me.db = DB
    End Sub
    Public Sub New(ByVal SMTPHost As String)
        Me.SMTPClient = New SmtpClient(SMTPHost)
    End Sub
    Public Sub New(ByVal SMTPClient As SmtpClient)
        Me.SMTPClient = SMTPClient
    End Sub

    Public Sub Send()
        Dim alternateView As System.Net.Mail.AlternateView = System.Net.Mail.AlternateView.CreateAlternateViewFromString(Me.Body, Nothing, "text/html")

        Me.MailMessage.AlternateViews.Add(alternateView)

        Try
            If Me.db.GetParameterValue("SMTPUser") <> "" Then
                Me.SMTPClient.Credentials = New System.Net.NetworkCredential(Me.db.GetParameterValue("SMTPUser"), Me.db.GetParameterValue("SMTPPassword"))

            End If

        Catch ex As Exception
            Me.SMTPClient.Credentials = New System.Net.NetworkCredential("ZedraSupport@googlemail.com", "1sItAHotSummer")
        End Try
        Me.SMTPClient.EnableSsl = Me.EnableSSL
        Me.SMTPClient.Send(Me.MailMessage)

    End Sub
    'Public Sub Attach(ByVal FileName As String)

    '    If Not System.IO.File.Exists(FileName) Then
    '        Throw New Exception("Can't add email attachment:" & FileName)
    '    End If
    '    MailMessage.Attachments.Add(New Net.Mail.Attachment(AccessViolationException, ))
    '    Dim Encoding As MailEncoding
    '    dim xx As New System.Net.Mime.ContentType(System.Net.Mime.MediaTypeNames.Application.
    '    Select Case System.IO.Path.GetExtension(FileName)
    '        Case "XLS", "PDF"
    '            Encoding = Web.Mail.MailEncoding.UUEncode
    '        Case Else
    '            Encoding = Web.Mail.MailEncoding.Base64
    '    End Select
    '    Me.Attach(FileName, Encoding)
    'End Sub
    Public Sub Attach(ByVal FileName As String)

        If Not System.IO.File.Exists(FileName) Then
            Throw New Exception("Can't add email attachment:" & FileName)
        End If
        MailMessage.Attachments.Add(New Attachment(FileName))

    End Sub
    Public Sub SendErrorEmail(ByVal Subject As String, ByVal ErrorMessage As String, Optional ByVal AttachmentFileName As String = "")
        '29/10/08   James Woosnam   SIR1614 - Move SendErrorEmail from BatchControl
        Dim RegistryKey As String = ""
        Try
            RegistryKey = db.GetParameterValue("ServiceRegistryKey")
        Catch ex As Exception
        End Try
        Dim stdCde As New BusinessLogic.StdCode
        Try
            Me.SendTo = stdCde.ReadRegValue(Microsoft.Win32.RegistryHive.LocalMachine, RegistryKey, "ErrorToEmailAddress", "")
            If Me.SendTo = "" Then
                Me.SendTo = "Support@Zedra.co.uk"
            End If
        Catch ex As Exception
            Me.SendTo = "Support@Zedra.co.uk"
        End Try
        Try
            Me.From = stdCde.ReadRegValue(Microsoft.Win32.RegistryHive.LocalMachine, RegistryKey, "ErrorFromEmailAddress", "")
        Catch ex As Exception
            'If nothing in Reg then just use support
            Me.From = "Support@Zedra.co.uk"
        End Try
        If Subject = "" Then
            Subject = "PaDS Web Error"
        Else
            Me.Subject = Subject
        End If
        Me.Body = "<html>"
        Me.Body += "    <head></head>"
        Me.Body += "    <body>"
        Try
            Me.Body += "<br>Version:" & Me.db.PaDSVersion
        Catch ex As Exception
        End Try
        Try
            Me.Body += "<br>ConnectionString:" & Me.db.DBConnection.ConnectionString
        Catch ex As Exception
        End Try
        Try
            Dim host = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName())

            For Each ip In host.AddressList

                If ip.AddressFamily = System.Net.Sockets.AddressFamily.InterNetwork Then
                    Me.Body += "<br>IP Address:" & ip.ToString
                End If
            Next
        Catch ex As Exception
        End Try
        Try
            Me.Body += "<br>Server Description::" & Me.db.GetParameterValue("ServerDescription")
        Catch ex As Exception
            Me.Body += "<br>Server Description::*** stblParameter ServerDescription not populated *****"
        End Try
        Me.Body += "        <br>" & ErrorMessage.Replace(vbCrLf, "<br>")
        Me.Body += "    </body>"
        Me.Body += "</html>"

        Me.IsBodyHTML = True
        If AttachmentFileName <> "" Then
            Try
                Me.Attach(AttachmentFileName)
            Catch ex As Exception
            End Try
        End If
        Try
            Me.Send()
        Catch ex As Exception
            Throw New Exception("Send in SendErrorEmail failed:" & ex.ToString & "}}}}")
        End Try

    End Sub
End Class
