﻿Imports System.Web
Public Class SessionCookie

#Region "Class Properties"
    Dim UserSession As UserSession = Nothing
    Dim SessionCookieName As String = "PaDSSession"
    Dim Cookie As HttpCookie = Nothing
    Dim CurrentPage As Object = Nothing
    Public Property SessionId As String
        Get
            Return Cookie("SessionId")
        End Get
        Set(value As String)
            Cookie("SessionId") = value
        End Set
    End Property
    Public ReadOnly Property Expires As Date
        Get
            If Me.Cookie.Expires = Nothing Then
                Me.Cookie.Expires = Now.AddMinutes(Me.UserSession.Timeout)

            End If
            Return Me.Cookie.Expires
        End Get
    End Property
    Public Property SpoofSessionId As String
        Get
            Return Cookie("SpoofSessionId")
        End Get
        Set(value As String)
            Cookie("SpoofSessionId") = value
        End Set
    End Property
#End Region


    Public Sub New(ByVal PageRequest As HttpRequest, UserSession As UserSession, ResetSessionCookie As Boolean)
        Me.UserSession = UserSession
        Me.Cookie = If(HttpContext.Current.Response.Cookies.AllKeys.Contains(SessionCookieName), HttpContext.Current.Response.Cookies(SessionCookieName), HttpContext.Current.Request.Cookies(SessionCookieName))
        If Me.Cookie Is Nothing Or ResetSessionCookie Then
            Me.Cookie = New HttpCookie(SessionCookieName)
            Cookie.Secure = PageRequest.IsSecureConnection
            Cookie.Expires = Now.AddHours(1) 'start with 1 hour, this will be amended to UserSession.Timeout when in save

        End If
    End Sub


    Public Sub Save(ByRef PageResponse As HttpResponse, Optional ExpireCookie As Boolean = False)
        Try
            Cookie.HttpOnly = True
            If ExpireCookie Then
                'set expires to the past abd save which makes the browser remove the cookie
                Cookie.Expires = Now.AddDays(-1)
            Else
                If UserSession.LoggedIn Then Cookie.Expires = UserSession.Expires
            End If

            'Don't save as a cookie for spoof sessions
            If Not UserSession.IsSpoofSession Then
                If PageResponse.Cookies(SessionCookieName) Is Nothing Then
                    PageResponse.Cookies.Add(Me.Cookie)
                Else
                    PageResponse.Cookies.Set(Me.Cookie)
                End If
            End If
        Catch ex As Exception
            Throw New Exception("Cookie not saved:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub Logout(ByRef PageResponse As HttpResponse)
        If Me.UserSession.IsSpoofSession And Me.SpoofSessionId <> Nothing Then
            Me.Cookie.Values.Remove("SpoofSessionId")
            Me.Save(PageResponse, False)
        Else
            Me.Cookie.Expires = Now.AddDays(-1)
            Me.Save(PageResponse, True)
        End If
    End Sub
End Class
