﻿'Modification History
'Mar 2018       James Woosnam   SIR4596 - Initial Version


Public Class ReportFixedCashbook
    Inherits ReportSSG
#Region "Class Properties"
    Dim BatchJobId As Integer = Nothing
    Dim StartDate As Date = Nothing
    Dim EndDate As Date = Nothing
    Dim CompanyId As Integer = Nothing
#End Region

    Public Sub New(ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("FixedCashbook", "Excel", db, SubmittedByUserSessionId)
    End Sub
    Public Sub New(ByVal StartDate As Date, ByVal EndDate As Date, CompanyId As Integer, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("FixedCashbook", "Excel", db, SubmittedByUserSessionId)
        Me.StartDate = StartDate
        Me.EndDate = EndDate
        Me.CompanyId = CompanyId
    End Sub
    Public Overloads Sub Submit()

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSessionId
        BatchJob.Parameters.Add("ReportName", Me.ReportName)
        BatchJob.Parameters.Add("CompanyId", CompanyId)
        BatchJob.Parameters.Add("StartDate", StartDate.ToString("dd-MMM-yyyy"))
        BatchJob.Parameters.Add("EndDate", EndDate.ToString("dd-MMM-yyyy"))
        BatchJob.CreateBatchJobEntry("RunReportSpreadsheetGearExcel", Me.db)

    End Sub

    Public Overloads Sub Execute(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.JobParameters = Parameters
        Me.StartDate = Parameters.GetValue("StartDate")
        Me.EndDate = Parameters.GetValue("EndDate")
        Me.CompanyId = Parameters.GetValue("CompanyId")
        Me.Execute()
    End Sub

    Public Overloads Sub Execute(Optional ByVal InBatchLog As BatchLog = Nothing)

        Dim batchLogCreatedHere As Boolean = False
        If InBatchLog Is Nothing Then
            Me.BatchLog = New BatchLog("Report-" & Me.ReportName _
                                          , ";StartDate=" & Me.StartDate _
                                         & ";EndDate=" & Me.EndDate _
                                         , Me.db _
                                         , BatchJobId _
                                         , Me.SubmittedByUserSessionId)
            batchLogCreatedHere = True
        Else
            Me.BatchLog = InBatchLog
        End If
        Try
            MyBase.Execute(Me.BatchLog)

            Me.ExcelWorkBook = SpreadsheetGear.Factory.GetWorkbook(Me.ExcelTemplate.FullName)

            Me.ReportSQL = "
                SELECT    
	                c.CurrencyCode
	                ,rc.[Month]
	                , c.PaymentType 
	                ,[BankedDate] =  ISNULL( cast(Cast(bd.DateBanked As Varchar(11)) As DateTime),c.EntryDate)
	                ,AmountInNative = SUM( c.Amount)
 --If unbanked non Payements wanted                    ,NotBank = CASE WHEN bd.BankDepositId IS NULL '**** NOT BANKED ****' ELSE '' END
                FROM  Cashbook c
	                LEFT JOIN BankDeposit bd
	                On bd.BankDepositId = c.BankDepositId
	                LEFT JOIN ReportingCalendar rc
	                ON rc.CalendarDate = ISNULL( cast(Cast(bd.DateBanked As Varchar(11)) As DateTime),c.EntryDate)
                WHERE c.CashbookStatus = 'Confirmed'
                AND ((bd.BankDepositId IS NOT NULL AND EntryType = 'Payment') OR EntryType <> 'Payment')
                AND c.CompanyId = " & CompanyId & "
                AND ISNULL( cast(Cast(bd.DateBanked As Varchar(11)) As DateTime),c.EntryDate) BETWEEN  " & db.vFQ(StartDate, "d") & " AND " & db.vFQ(EndDate, "d") & "
                GROUP BY
                    c.CurrencyCode
	                ,rc.[Month]
	                , c.PaymentType 
	                , ISNULL( cast(Cast(bd.DateBanked As Varchar(11)) As DateTime),c.EntryDate)

            "
            Dim tblRep As DataTable = db.GetDataTableFromSQL(Me.ReportSQL)

            Dim Currencies As New List(Of String)

            For Each row As DataRow In tblRep.Rows
                If Not Currencies.Contains(row("CurrencyCode")) Then
                    Currencies.Add(row("CurrencyCode"))
                End If
            Next

            Dim wsData As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Data")
            Dim wsCriteria As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Criteria")

            wsCriteria.Cells("CompanyName").Value = db.DLookup("CompanyName", "Company", "CompanyId=" & CompanyId)
            wsCriteria.Cells("StartDate").Value = StartDate
            wsCriteria.Cells("EndDate").Value = EndDate
            wsCriteria.Cells("DateRun").Value = Now.ToString("dd-MMM-yyyy HH:mm")
            wsCriteria.Cells("UserName").Value = Me.SubmittedByUserSession.UserFullName
            wsCriteria.Cells("SQL").Value = Me.ReportSQL

            Dim rgBase As SpreadsheetGear.IRange
            Dim rowsBetweenCurrencies As Integer = 6
            rgBase = wsData.Cells("CurrencyTemplate")
            Dim iCurr As Integer = 1
            For iCurr = 1 To Currencies.Count - 1
                rgBase.Copy(wsData.Cells(rgBase.Row + (rowsBetweenCurrencies * iCurr), rgBase.Column))
            Next
            iCurr = Currencies.Count - 1
            For Each Currency As String In Currencies
                Dim rg As SpreadsheetGear.IRange
                rg = wsData.Cells(rgBase.Row + 1 + (rowsBetweenCurrencies * iCurr), rgBase.Column + 1, rgBase.Row + (rgBase.RowCount - 2) + (rowsBetweenCurrencies * iCurr), rgBase.Column + (rgBase.ColumnCount - 1))
                Dim vw As New DataView(tblRep, "CurrencyCode='" & Currency & "'", "Month,PaymentType, BankedDate", DataViewRowState.CurrentRows)
                Dim tbl As DataTable = vw.ToTable()
                rg.CopyFromDataTable(tbl, SpreadsheetGear.Data.SetDataFlags.InsertCells + SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders) '+ SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders)
                iCurr -= 1
            Next

            ReportName = ReportName & StartDate.ToString(" dd-MMM-yyyy") & " to " & EndDate.ToString("dd-MMM-yyyy")
            ExcelWorkBook.SaveAs(Me.ReportFile.FullName, SpreadsheetGear.FileFormat.OpenXMLWorkbook)
            BatchLog.Update(Me.FileLink)

            If batchLogCreatedHere Then
                BatchLog.Update("Process Complete", "Complete")
            End If
        Catch ex As Exception
            BatchLog.Update("Report Failed:" & ex.Message, "Failed")
            Throw New Exception("Report Failed:" & ex.Message, ex)

        End Try

    End Sub

End Class
