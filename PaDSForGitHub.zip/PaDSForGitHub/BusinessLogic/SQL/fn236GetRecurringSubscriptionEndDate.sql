if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fn236GetRecurringSubscriptionEndDate]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[fn236GetRecurringSubscriptionEndDate]
GO
CREATE  FUNCTION dbo.fn236GetRecurringSubscriptionEndDate ( @ProductCode VARCHAR(10)
															,@RecurringSubscriptionStartDate DATETIME
															 )
RETURNS DATETIME
AS
BEGIN
DECLARE @RecurringSubscriptionEndDate DATETIME

SELECT	@RecurringSubscriptionEndDate = CASE WHEN ISNULL(Product.RecurringSubscriptionFlag,0)=0 THEN '01-jan-1900'
								ELSE DATEADD(S,-1,CASE Product.RecurringSubscriptionUnitType
													WHEN 'Months' THEN DATEADD(M,Product.RecurringSubscriptionUnits, @RecurringSubscriptionStartDate) 
													WHEN 'Hours' THEN DATEADD(hh,Product.RecurringSubscriptionUnits, @RecurringSubscriptionStartDate) 
													ELSE Product.RecurringSubscriptionUnitType + ' not handled' 
			   									   END
											)
								END
FROM Product
WHERE ProductCode = @ProductCode 

RETURN ( @RecurringSubscriptionEndDate)

END
Go

--select dbo.fn236GetRecurringSubscriptionEndDate( 'PEPWEBS','17-nov-2006 00:00:00.000')
