if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp236SubscribersRequiringReminders') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp236SubscribersRequiringReminders
Go
CREATE PROCEDURE sp236SubscribersRequiringReminders
As
/*
DESCRIPTION
===========
This sp is used to build a list of subs that need to be sent renewal reminder emails.  
It is currently designed to work for PEPWeb products only and is called from 
PEPRenewalEmailReminders.vb in Zedra Utilities.

Modifications
=============
Nov 2008	James Woosnam	SIR1615 - Initial version
18/12/08	James Woosnam	Add criteriato only look at latest order
8/6/10		James Woosnam	Reworked to impprove performance
19/7/11		James Woosnam	SIR2470 - Include all products with a Monthly Recurring subscription which are for sale on the Web
15/11/12	James Woosnam	SIR2890 - Do not send reminder if they have a current block subscription to PEPweb
01/10/20	Julian Gates	SIR5118 - Exclude products with DisableAutoRenewalFlag set to true
*/
DECLARE @FirstReminderDaysBefore INT
DECLARE @SecondReminderDaysBefore INT
SELECT @FirstReminderDaysBefore = dbo.fn017GetParameter('FirstReminderDaysBefore')
SET @SecondReminderDaysBefore = dbo.fn017GetParameter('SecondReminderDaysBefore')

CREATE TABLE #SalesOrderLines 
	(
	OrderNumber INT
	,SubscriberId INT
	,RecurringSubscriptionStartDate DATETIME
	,RecurringSubscriptionEndDate DATETIME
	,ProductGroupingName VARCHAR(25)
	,ProductCode VARCHAR(10)
	)
INSERT INTO #SalesOrderLines
SELECT so.OrderNumber	
	,sol.SubscriberId 
	,sol.RecurringSubscriptionStartDate 
	,sol.RecurringSubscriptionEndDate
	,p.ProductGroupingName  
	,sol.ProductCode
FROM SalesOrderLine sol
	INNER JOIN SalesOrder so
	ON so.OrderNumber = sol.OrderNumber 
	INNER JOIN Product p
	ON p.ProductCode = sol.ProductCode 
WHERE  so.OrderType Like 'Individual%'
--19/7/11	James Woosnam	SIR2470 - Include all products with a Monthly Recurring subscription which are for sale on the Web
AND p.RecurringSubscriptionFlag = 1
AND p.RecurringSubscriptionUnitType = 'Months'
AND p.SellOnWebFlag = 1
AND p.ProductStatus = 'Current'
AND so.SalesOrderStatus IN ('Confirmed','Complete')
--01/10/20	Julian Gates	SIR5118 - Exclude products with DisableAutoRenewalFlag set to true
AND ISNULL(p.DisableAutoRenewalFlag,0) <> 1


SELECT  SalesOrderLine.SubscriberId
		,CurrentSubscriptionOrderNumber = SalesOrderLine.OrderNumber
		,CurrentSubscriptionEndDate = MAX(SalesOrderLine.RecurringSubscriptionEndDate)
		,EmailAddress = MAX(SubscriberAddress.AddressText)
		,ReminderType = CASE WHEN MAX(RenewalReminderLog.SubscriberId) IS NULL THEN 'First' ELSE 'Second' END
		,SalesOrderLine.ProductGroupingName
FROM #SalesOrderLines SalesOrderLine
	LEFT JOIN dbo.RenewalReminderLog
	ON RenewalReminderLog.SubscriberId = SalesOrderLine.SubscriberId
	AND RenewalReminderLog.OrderNumber = SalesOrderLine.OrderNumber
	INNER JOIN SubscriberAddress
	ON SubscriberAddress.SubscriberId = SalesOrderLine.SubscriberId
	AND AddressType='Email' 
	AND AddressDescription='Main'
--15/11/12	James Woosnam	SIR2890 - Do not send reminder if they have a current block subscription to PEPweb
	LEFT JOIN 	(
				SELECT sol.SubscriberId
					,sol.ProductCode
				FROM #SalesOrderLines sol
					INNER JOIN SalesOrderLine solBlock
						INNER JOIN SalesOrder soBlock
						ON soBlock.OrderNumber = solBlock.OrderNumber 
					On solBlock.SubscriberId = sol.SubscriberId
					AND solBlock.ProductCode IN ('PEPWeb')
					AND Getdate() BETWEEN solBlock.RecurringSubscriptionStartDate and solBlock.RecurringSubscriptionEndDate 
					AND soBlock.OrderType = 'Block'
				WHERE sol.productCode IN ('PEPweb','PEPwebs','PEPweb3y')
			) BlockSubs
	ON BlockSubs.SubscriberId = SalesOrderLine.SubscriberId 
	AND BlockSubs.ProductCode = SalesOrderLine.ProductCode 
WHERE ISNULL(RecurringSubscriptionStartDate,'1900-01-01 00:00:00.000') > '1900-01-01 00:00:00.000'
AND ((DATEADD(day,-1 * @FirstReminderDaysBefore,RecurringSubscriptionEndDate) < GETDATE() AND RenewalReminderLog.SubscriberId IS NULL )
	OR 
	(DATEADD(day,-1 * @SecondReminderDaysBefore,RecurringSubscriptionEndDate) < GETDATE() AND RenewalReminderLog.SecondReminderSentDate IS NULL )
	)
--18/12/08	James Woosnam	Add criteriato only look at latest order
AND SalesOrderLine.RecurringSubscriptionEndDate = (SELECT MAX(sol.RecurringSubscriptionEndDate)
													FROM #SalesOrderLines sol
													WHERE sol.SubscriberId = SalesOrderLine.SubscriberId
													AND sol.ProductGroupingName = SalesOrderLine.ProductGroupingName
												   )
AND SalesOrderLine.RecurringSubscriptionEndDate < DATEADD(DAY,@FirstReminderDaysBefore,GETDATE())
--15/11/12	James Woosnam	SIR2890 - Do not send reminder if they have a current block subscription to PEPweb
AND BlockSubs.SubscriberId IS NULL

GROUP BY SalesOrderLine.SubscriberId
		,SalesOrderLine.OrderNumber
		,SalesOrderLine.ProductGroupingName

GO
