if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fn495GetGroupProductSubscriptions]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[fn495GetGroupProductSubscriptions]
GO
CREATE  FUNCTION dbo.fn495GetGroupProductSubscriptions (@GroupSubscriberId INT
														,@CompanyId INT )
RETURNS TABLE
AS
--13/5/08	James Woosnam	HOT FIX - Look at correct rate
--18/6/08	James Woosnam	SIR1550 - Do not assume ProductRate is present
RETURN 
(
SELECT 
	SubscriberId = SalesOrderLine.SubscriberId
	,SalesOrder.OrderNumber
	,ProductName = ISNULL(ChildProduct.ProductReportName,Product.ProductName)
	,RecurringSubscriptionStartDate = MAX(ISNULL(SalesOrderLine.RecurringSubscriptionStartDate,'01-jan-1900'))
	,RecurringSubscriptionEndDate = MAX(ISNULL(SalesOrderLine.RecurringSubscriptionEndDate,'31-DEC-4949'))
	,ProductAffiliateRateUsed = CASE WHEN ProductAffiliateRate.ProductAffiliateRateId IS NULL THEN 0 ELSE 1 END
FROM SalesOrderLine
	INNER JOIN SalesOrder
	On SalesOrder.OrderNumber = SalesOrderLine.OrderNumber
	AND SalesOrder.SalesOrderStatus IN ('Confirmed','Complete')
	INNER JOIN  Product 
		LEFT JOIN Product ChildProduct
		ON ChildProduct.ParentProductCode = Product.ProductCode
	ON SalesOrderLine.ProductCode = Product.ProductCode
	AND Product.CompanyId = @CompanyId
--18/6/08	James Woosnam	SIR1550 - Do not assume ProductRate is present
	LEFT JOIN ProductRate
	ON ProductRate.ProductRateId = SalesOrderLine.ProductRateId
	LEFT JOIN ProductAffiliateRate
	ON ProductAffiliateRate.ProductCode = SalesOrderLine.ProductCode
	AND ProductAffiliateRate.GroupSubscriberId = @GroupSubscriberId
--13/5/08	James Woosnam	HOT FIX - Look at correct rate
	AND ProductAffiliateRate.ProductRateId = SalesOrderLine.ProductRateId
WHERE  ( SalesOrder.SubscriberId = @GroupSubscriberId
	OR ProductAffiliateRate.ProductAffiliateRateId IS NOT NULL)
GROUP BY SalesOrderLine.SubscriberId
	,SalesOrder.OrderNumber
	 ,ISNULL(ChildProduct.ProductReportName,Product.ProductName)
	,CASE WHEN ProductAffiliateRate.ProductAffiliateRateId IS NULL THEN 0 ELSE 1 END
)
GO
