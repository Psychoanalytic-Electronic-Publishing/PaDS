IF  exists (select * from dbo.sysobjects where id = object_id(N'sp601PopulateActivityLog') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp601PopulateActivityLog
GO
CREATE  PROCEDURE sp601PopulateActivityLog (
		@BatchLogId INT = NULL
)
AS
--12/8/21	James Woosnam	Re-arranged to reduce the amount of time the transaction is open for and to optimise some of the queries so as not to lock front end
DECLARE @Message VARCHAR(MAX) = ''
		,@RowCount INT = 0
		,@ThrowError BIT = 0
		,@NewLine VARCHAR(10) = '<br>'

DECLARE @UserActionLogLastPEPWebLogId INT = NULL
	,@UserActionLogLastPEPWebSessionLogId INT = NULL
	,@MaxUserActionLogIdBeforeInserts INT = NULL
	,@UserActionLogStartFromDateTime DATETIME = NULL


BEGIN TRY
	SELECT @UserActionLogStartFromDateTime = ParameterValue FROM stblParameters WHERE ParameterName = 'UserActionLogStartFromDateTime'
	IF @UserActionLogStartFromDateTime IS NULL SET @UserActionLogStartFromDateTime ='01-FEB-2021'

	SELECT * INTO #UAL FROM UserActionLog WHERE 1=2
--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add Investigations & Requests from PEPwebUsageLog
	SELECT @MaxUserActionLogIdBeforeInserts = ISNULL(MAX(UserActionLogId),0) FROM UserActionLog
	SELECT @UserActionLogLastPEPWebLogId = ParameterValue FROM stblParameters WHERE ParameterName = 'UserActionLogLastPEPWebLogId'

	IF @UserActionLogLastPEPWebLogId IS NULL SET @UserActionLogLastPEPWebLogId =0
	INSERT INTO #UAL (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,LoggedInMethod
		,UserType
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Publisher_ID
		,Section_Type

		,ItemId

	)

	SELECT
		FromLogRecordWithId = CAST(l.PEPWebUsageLogId AS VARCHAR(20))
		,l.UserSessionId 
		,l.DateTime 
		,MonthStartDate = '01-' + FORMAT(l.dateTime,'MMM-yyyy')
		,ActionType = CASE WHEN l.ReasonForCheck = 'AbstractView' THEN 'Investigation'
							WHEN l.ReasonForCheck = 'DocumentView' THEN CASE WHEN l.LogonStatus='Failed' THEN 'No_License'
																		ELSE 'Request' END
							ELSE 'UnknownActionType' + l.ReasonForCheck END
		,ru.UserId 
		,LoggedInMethod ='' --(SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='LoggedInMethod' AND CAST(usd.UserSessionId AS VARCHAR(50))=l.UserSessionId )
		,UserType ='' --(SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='UserType' AND CAST(usd.UserSessionId AS VARCHAR(50))=l.UserSessionId )
		,s.SubscriberId 
		,s.SubscriberName 
		,Institution_Id = so.AffiliateRateSubscriberId
		,Institution_Name = so.AffiliateRateSubscriberName 
		,Access_Type = CASE WHEN l.AdditionalDetails like '%universal access%' THEN 'OA_Gold' ELSE 'Controlled' END --OA_Gold (Gold Open Access) , Controlled
		,Access_Method = 'Regular'
		,Publisher_ID = 'xxxx'
		,Section_Type = 'Artical' --Identifies the type of section that was accessed by the user, including Article, Book, Chapter, Other and Section. Used primarily for reporting on book usage where content is delivered by section.

		,ItemId =l.documentId

	FROM PEPWebUsageLog l
		LEFT JOIN (
			SELECT l.UserSessionId 
				,UserName = MAX(l.UserName )
				,SubscriberId = MAX(l.SubscriberId )
				,OrderNumber = MAX(l.OrderNumber)
			FROM PEPWebUsageLog l
			WHERE l.UserName <>'0'
			and l.DateTime >='01-dec-2020'
			AND isnumeric(l.username) =1
			GROUP BY l.UserSessionId 
		) u
		ON u.UserSessionId = l.UserSessionId  collate database_default
		LEFT JOIN Subscriber s
		ON s.SubscriberId = u.SubscriberId 
		LEFT JOIN RemoteUser ru
		ON CAST(ru.UserId AS VARCHAR) = u.UserName 
		LEFT JOIN (SELECT so.OrderNumber 
						,AffiliateRateSubscriberName = MAX(so.AffiliateRateSubscriberName )
						,AffiliateRateSubscriberId = MAX(so.AffiliateRateSubscriberId )
						,AffiliateRateType = MAX(so.AffiliateRateType )
					FROM vw430SalesDetails so
					GROUP BY so.OrderNumber ) so
		ON so.OrderNumber = u.OrderNumber 

	
	where 1=1
	and l.PEPWebUsageLogId >@UserActionLogLastPEPWebLogId
	AND l.DateTime >= @UserActionLogStartFromDateTime
	AND isnumeric(l.username)=1
	AND l.ActionType IN ( 'Authorise')
	AND (l.LogonStatus  = 'Success' OR l.ReasonForCheck  = 'DocumentView')
	AND l.ReasonForCheck  IN ( 'AbstractView','DocumentView')
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAL records added for Investigations & Requests';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	SELECT @UserActionLogLastPEPWebLogId = (SELECT  MAX(CAST(ISNULL(FromLogRecordWithId,0) AS INT)) FROM #UAL WHERE ActionType IN ('Investigation' ,'Request' ))

--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
	DELETE FROM #UAL 
	WHERE UserActionLogId IN (
			SELECT DISTINCT
				l2.UserActionLogId 
			FROM #UAL l
				INNER JOIN #UAL l2
				ON l2.UserSessionId = l.UserSessionId 
				AND l2.ActionType = l.ActionType 
				AND l2.Access_Type = l.Access_Type 
				AND l2.Access_Method = l.Access_Method 
				AND l2.ItemId = l.ItemId 
				AND l2.DateTime BETWEEN DATEADD(SECOND,-30,l.DateTime) AND l.DateTime 
				AND l2.UserActionLogId <> l.UserActionLogId 
			WHERE l.UserActionLogId > @MaxUserActionLogIdBeforeInserts
			)
	SET @RowCount = @@ROWCOUNT ;SET @Message =  CAST(@RowCount AS VARCHAR) + ' #UAL rows deleted as within 30seconds of duplicate';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	UPDATE #UAL
	SET 
			Data_Type = CAST(ISNULL(c.Data_Type ,b.Data_Type) AS VARCHAR(50)) --Article, Book, Book_Segment, Database, Dataset, Journal, Multimedia, Newspaper_or_Newsletter, Other, Platform, Report, Repository_Item, and Thesis_or_Dissertation
			,TitleId = ISNULL(c.PEPCode,b.PEPCode)
			,TitleName = ISNULL(c.Title,b.Title)
			,ItemId = ISNULL(d.documentID,l.ItemId )
			,ItemName = ISNULL(d.documentRef ,b.title )
			,YOP = ISNULL(d.year ,b.pub_year)
			,ISSN = ISNULL(c.ISSN,b.ISSN)
			,ISBN = ISNULL(c.ISBN,b.ISBN)
			,Language = ISNULL(c.language,b.language)
	FROM #UAL l
			LEFT JOIN ContentDocuments d
				LEFT JOIN (
					SELECT j.PEPCode 
						,j.sourceType 
						,j.Title 
						,j.ISSN 
						,ISBN = CAST('' AS VARCHAR(50))
						,j.language 
						,Data_Type = CAST('Journal' AS VARCHAR(50))
					FROM ContentJournals j
					UNION
					SELECT v.PEPCode 
						,v.sourceType 
						,v.Title 
						,v.ISSN 
						,ISBN = CAST('' AS VARCHAR(50))
						,v.language 
						,Data_Type = CAST('Multimedia' AS VARCHAR(50))
					FROM ContentVideos v
					) c
				ON c.PEPCode = d.PEPCode 
			ON d.documentID = l.ItemId  
			LEFT JOIN (
				SELECT b.PEPCode 
					,b.sourceType 
					,b.documentID 
					,b.Title 
					,b.ISSN 
					,ISBN = b.ISBN13 
					,b.language
					,Data_Type = 'Book' --Might be book????  Book_Segment  A book segment (e.g. chapter, section, etc.). Note that Data_Type Book_Segment is only applicable for Item Reports when the book segment is the item, in Title Reports this is represented by the Section_Type.
					,b.pub_year
				FROM ContentBooks b
				) b
		on b.documentID = l.ItemId   
		or replace(l.ItemId ,'.','') like b.PEPCode + '%'
	WHERE ISNULL(l.ItemId,'')<>''
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAL records updated with Document details';EXEC sp029UpdateBatchLog @BatchLogId, @Message


--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add additional Investigation for each request
	INSERT INTO #UAL (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,LoggedInMethod
		,UserType
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type
		,Publisher_ID
		,Section_Type
		,TitleId
		,TitleName
		,ItemId
		,ItemName
		,YOP
		,ISSN
		,ISBN
		,[Language]
	)
	SELECT
		FromLogRecordWithId = CAST(FromLogRecordWithId AS VARCHAR(20))
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType='Investigation'
		,UserId
		,LoggedInMethod
		,UserType
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type
		,Publisher_ID
		,Section_Type
		,TitleId
		,TitleName
		,ItemId
		,ItemName
		,YOP
		,ISSN
		,ISBN
		,[Language]
	FROM #UAL 
	WHERE ActionType = 'Request'
	SET @RowCount = @@ROWCOUNT 
	SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAL Investigations records added for copy Requests';EXEC sp029UpdateBatchLog @BatchLogId, @Message

--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add Search Actions
	SELECT @UserActionLogLastPEPWebSessionLogId = ParameterValue FROM stblParameters WHERE ParameterName = 'UserActionLogLastPEPWebSessionLogId'
	IF @UserActionLogLastPEPWebSessionLogId IS NULL SET @UserActionLogLastPEPWebSessionLogId =0
	INSERT INTO #UAL (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type 
	)
	SELECT
		FromLogRecordWithId = CAST(l.PEPWebSessionLogId AS VARCHAR(20))
		,l.UserSessionId 
		,l.LastUpdate 
		,MonthStartDate = '01-' + FORMAT(l.LastUpdate,'MMM-yyyy')
		,ActionType = 'Search'
		,ru.UserId 
		,s.SubscriberId 
		,s.SubscriberName 
		,Institution_Id = so.AffiliateRateSubscriberId
		,Institution_Name = so.AffiliateRateSubscriberName
		,Access_Type = 'Controlled' 
		,Access_Method = 'Regular'
		,Data_Type ='Database'
	FROM PEPWebSessionLog l
		LEFT JOIN (
			SELECT l.UserSessionId 
				,UserName = MAX(l.UserName )
				,SubscriberId = MAX(l.SubscriberId )
				,OrderNumber = MAX(l.OrderNumber)
			FROM PEPWebUsageLog l
			WHERE l.UserName <>'0'
			and l.DateTime >='01-dec-2020'
			AND isnumeric(l.username) =1
			GROUP BY l.UserSessionId 
		) u
		ON u.UserSessionId = l.UserSessionId 
		LEFT JOIN Subscriber s
		ON s.SubscriberId = u.SubscriberId 
		LEFT JOIN RemoteUser ru
		ON CAST(ru.UserId AS VARCHAR) = u.UserName 
		LEFT JOIN (SELECT so.OrderNumber 
						,AffiliateRateSubscriberName = MAX(so.AffiliateRateSubscriberName )
						,AffiliateRateSubscriberId = MAX(so.AffiliateRateSubscriberId )
						,AffiliateRateType = MAX(so.AffiliateRateType )
					FROM vw430SalesDetails so
					GROUP BY so.OrderNumber ) so
		ON so.OrderNumber = u.OrderNumber 
	where 1=1
	AND l.Endpoint = '/Database/Search/'
	AND l.Params LIKE '%user=true%'
	and l.PEPWebSessionLogId  >@UserActionLogLastPEPWebSessionLogId
	AND l.LastUpdate >= @UserActionLogStartFromDateTime
	SET @RowCount = @@ROWCOUNT 
	SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAL Search records added';EXEC sp029UpdateBatchLog @BatchLogId, @Message
	SELECT @UserActionLogLastPEPWebSessionLogId =  (SELECT MAX(CAST(ISNULL(FromLogRecordWithId,0) AS INT)) FROM #UAL WHERE ActionType IN ('Search' ))

	UPDATE #UAL 
	set		LoggedInMethod = (SELECT max(CAST(usd.DataItemValue AS VARCHAR(100)))  FROM UserSessionData usd where usd.DataItemName='LoggedInMethod' AND CAST(usd.UserSessionId AS VARCHAR(50))=UserSessionId )
			,UserType = (SELECT max(CAST(usd.DataItemValue AS VARCHAR(100)))  FROM UserSessionData usd where usd.DataItemName='UserType' AND CAST(usd.UserSessionId AS VARCHAR(50))=UserSessionId )
	SET @RowCount = @@ROWCOUNT ;SET @Message = CAST(@RowCount AS VARCHAR) + ' #UAL records updated with UserSession Details';EXEC sp029UpdateBatchLog @BatchLogId, @Message


END TRY
BEGIN CATCH
	
	SELECT @Message ='sp601PopulateActivityLog Failed:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE();EXEC sp029UpdateBatchLog @BatchLogId, @Message
	RAISERROR ('%s', 18, 1,@Message)
	RETURN
END CATCH

BEGIN TRAN
BEGIN TRY
	DELETE FROM stblParameters WHERE ParameterName = 'UserActionLogLastPEPWebLogId'
	INSERT INTO stblParameters SELECT 'UserActionLogLastPEPWebLogId' ,'System','All',@UserActionLogLastPEPWebLogId,NULL,NULL
	DELETE FROM stblParameters WHERE ParameterName = 'UserActionLogLastPEPWebSessionLogId'
	INSERT INTO stblParameters SELECT 'UserActionLogLastPEPWebSessionLogId' ,'System','All',@UserActionLogLastPEPWebSessionLogId ,NULL,NULL

	INSERT INTO UserActionLog (
			FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,LoggedInMethod
		,UserType
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type
		,Publisher_ID
		,Section_Type
		,TitleId
		,TitleName
		,ItemId
		,ItemName
		,YOP
		,ISSN
		,ISBN
		,[Language])
	SELECT 
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,LoggedInMethod
		,UserType
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type
		,Publisher_ID
		,Section_Type
		,TitleId
		,TitleName
		,ItemId
		,ItemName
		,YOP
		,ISSN
		,ISBN
		,[Language]
	FROM #UAL 
	SET @RowCount = @@ROWCOUNT 
	SET @Message = CAST(@RowCount AS VARCHAR) + ' UserActionLog rows added from #UAL';EXEC sp029UpdateBatchLog @BatchLogId, @Message

	COMMIT TRAN
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SELECT @Message ='sp601PopulateActivityLog Failed:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE() ;EXEC sp029UpdateBatchLog @BatchLogId, @Message
	RAISERROR ('%s', 18, 1,@Message)
END CATCH	

GO
GRANT EXECUTE ON sp601PopulateActivityLog to PaDSSQLServerUser
