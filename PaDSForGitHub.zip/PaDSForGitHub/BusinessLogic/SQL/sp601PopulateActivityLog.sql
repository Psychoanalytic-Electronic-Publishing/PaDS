IF  exists (select * from dbo.sysobjects where id = object_id(N'sp601PopulateActivityLog') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp601PopulateActivityLog
GO
CREATE  PROCEDURE sp601PopulateActivityLog (
		@BatchLogId INT = NULL
)
AS
DECLARE @Message VARCHAR(MAX) = ''
		,@RowCount INT = 0
		,@ThrowError BIT = 0
		,@NewLine VARCHAR(10) = '<br>'

DECLARE @UserActionLogLastPEPWebLogId INT = NULL
	,@UserActionLogLastPEPWebSessionLogId INT = NULL
	,@MaxUserActionLogIdBeforeInserts INT = NULL
	,@UserActionLogStartFromDateTime DATETIME = NULL


BEGIN TRAN
BEGIN TRY
	SELECT @UserActionLogStartFromDateTime = ParameterValue FROM stblParameters WHERE ParameterName = 'UserActionLogStartFromDateTime'
	IF @UserActionLogStartFromDateTime IS NULL SET @UserActionLogStartFromDateTime ='01-FEB-2021'

--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add Investigations & Requests from PEPwebUsageLog
	SELECT @MaxUserActionLogIdBeforeInserts = ISNULL(MAX(UserActionLogId),0) FROM UserActionLog
	SELECT @UserActionLogLastPEPWebLogId = ParameterValue FROM stblParameters WHERE ParameterName = 'UserActionLogLastPEPWebLogId'
	IF @UserActionLogLastPEPWebLogId IS NULL SET @UserActionLogLastPEPWebLogId =0
	INSERT INTO UserActionLog (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,LoggedInMethod
		,UserType
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type
		,Publisher_ID
		,Section_Type
		,TitleId
		,TitleName
		,ItemId
		,ItemName
		,YOP
		,ISSN
		,ISBN
		,[Language]
	)

	SELECT
		FromLogRecordWithId = CAST(l.PEPWebUsageLogId AS VARCHAR(20))
		,l.UserSessionId 
		,l.DateTime 
		,MonthStartDate = '01-' + FORMAT(l.dateTime,'MMM-yyyy')
		,ActionType = CASE WHEN l.ReasonForCheck = 'AbstractView' THEN 'Investigation'
							WHEN l.ReasonForCheck = 'DocumentView' THEN CASE WHEN l.LogonStatus='Failed' THEN 'No_License'
																		ELSE 'Request' END
							ELSE 'UnknownActionType' + l.ReasonForCheck END
		,ru.UserId 
		,LoggedInMethod = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='LoggedInMethod' AND CAST(usd.UserSessionId AS VARCHAR(50))=l.UserSessionId )
		,UserType = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='UserType' AND CAST(usd.UserSessionId AS VARCHAR(50))=l.UserSessionId )
		,s.SubscriberId 
		,s.SubscriberName 
		,Institution_Id = so.AffiliateRateSubscriberId
		,Institution_Name = so.AffiliateRateSubscriberName 
		,Access_Type = CASE WHEN l.AdditionalDetails like '%universal access%' THEN 'OA_Gold' ELSE 'Controlled' END --OA_Gold (Gold Open Access) , Controlled
		,Access_Method = 'Regular'
		,Data_Type = CAST(ISNULL(c.Data_Type ,b.Data_Type) AS VARCHAR(50)) --Article, Book, Book_Segment, Database, Dataset, Journal, Multimedia, Newspaper_or_Newsletter, Other, Platform, Report, Repository_Item, and Thesis_or_Dissertation
		,Publisher_ID = 'xxxx'
		,Section_Type = 'Artical' --Identifies the type of section that was accessed by the user, including Article, Book, Chapter, Other and Section. Used primarily for reporting on book usage where content is delivered by section.
		,TitleId = ISNULL(c.PEPCode,b.PEPCode)
		,TitleName = ISNULL(c.Title,b.Title)
		,ItemId = ISNULL(d.documentID,l.documentId)
		,ItemName = ISNULL(d.documentRef ,b.title )
		,YOP = ISNULL(d.year ,b.pub_year)
		,ISSN = ISNULL(c.ISSN,b.ISSN)
		,ISBN = ISNULL(c.ISBN,b.ISBN)
		,Language = ISNULL(c.language,b.language)
	FROM PEPWebUsageLog l
		LEFT JOIN (
			SELECT l.UserSessionId 
				,UserName = MAX(l.UserName )
				,SubscriberId = MAX(l.SubscriberId )
				,OrderNumber = MAX(l.OrderNumber)
			FROM PEPWebUsageLog l
			WHERE l.UserName <>'0'
			and l.DateTime >='01-dec-2020'
			AND isnumeric(l.username) =1
			GROUP BY l.UserSessionId 
		) u
		ON u.UserSessionId = l.UserSessionId  collate database_default
		LEFT JOIN Subscriber s
		ON s.SubscriberId = u.SubscriberId 
		LEFT JOIN RemoteUser ru
		ON CAST(ru.UserId AS VARCHAR) = u.UserName 
		LEFT JOIN (SELECT so.OrderNumber 
						,AffiliateRateSubscriberName = MAX(so.AffiliateRateSubscriberName )
						,AffiliateRateSubscriberId = MAX(so.AffiliateRateSubscriberId )
						,AffiliateRateType = MAX(so.AffiliateRateType )
					FROM vw430SalesDetails so
					GROUP BY so.OrderNumber ) so
		ON so.OrderNumber = u.OrderNumber 
		LEFT JOIN ContentDocuments d
			LEFT JOIN (
				SELECT j.PEPCode 
					,j.sourceType 
					,j.Title 
					,j.ISSN 
					,ISBN = CAST('' AS VARCHAR(50))
					,j.language 
					,Data_Type = CAST('Journal' AS VARCHAR(50))
				FROM ContentJournals j
				UNION
				SELECT v.PEPCode 
					,v.sourceType 
					,v.Title 
					,v.ISSN 
					,ISBN = CAST('' AS VARCHAR(50))
					,v.language 
					,Data_Type = CAST('Multimedia' AS VARCHAR(50))
				FROM ContentVideos v
				) c
			ON c.PEPCode = d.PEPCode 
		ON d.documentID = l.DocumentId 
		LEFT JOIN (
			SELECT b.PEPCode 
				,b.sourceType 
				,b.documentID 
				,b.Title 
				,b.ISSN 
				,ISBN = b.ISBN13 
				,b.language
				,Data_Type = 'Book' --Might be book????  Book_Segment  A book segment (e.g. chapter, section, etc.). Note that Data_Type Book_Segment is only applicable for Item Reports when the book segment is the item, in Title Reports this is represented by the Section_Type.
				,b.pub_year
			FROM ContentBooks b
			) b
	on b.documentID = l.DocumentId  
	or replace(l.documentID,'.','') like b.PEPCode + '%'
	
	where 1=1
	and l.PEPWebUsageLogId >@UserActionLogLastPEPWebLogId
	AND l.DateTime >= @UserActionLogStartFromDateTime
	AND isnumeric(l.username)=1
	AND l.ActionType IN ( 'Authorise')
	AND (l.LogonStatus  = 'Success' OR l.ReasonForCheck  = 'DocumentView')
	AND l.ReasonForCheck  IN ( 'AbstractView','DocumentView')
	SET @RowCount = @@ROWCOUNT 
	SET @Message += CAST(@RowCount AS VARCHAR) + ' UserActionLog records added for Investigations & Requests' + @NewLine
	DELETE FROM stblParameters WHERE ParameterName = 'UserActionLogLastPEPWebLogId'
	INSERT INTO stblParameters SELECT 'UserActionLogLastPEPWebLogId' ,'System','All', (SELECT  MAX(CAST(ISNULL(FromLogRecordWithId,0) AS INT)) FROM UserActionLog WHERE ActionType IN ('Investigation' ,'Request' )),NULL,NULL


--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
	DELETE FROM UserActionLog 
	WHERE UserActionLogId IN (
			SELECT DISTINCT
				l2.UserActionLogId 
			FROM UserActionLog l
				INNER JOIN UserActionLog l2
				ON l2.UserSessionId = l.UserSessionId 
				AND l2.ActionType = l.ActionType 
				AND l2.Access_Type = l.Access_Type 
				AND l2.Access_Method = l.Access_Method 
				AND l2.ItemId = l.ItemId 
				AND l2.DateTime BETWEEN DATEADD(SECOND,-30,l.DateTime) AND l.DateTime 
				AND l2.UserActionLogId <> l.UserActionLogId 
			WHERE l.UserActionLogId > @MaxUserActionLogIdBeforeInserts
			)
	SET @RowCount = @@ROWCOUNT 
	SET @Message += CAST(@RowCount AS VARCHAR) + ' UserActionLog deleted as within 30seconds of duplicate' + @NewLine


--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add additional Investigation for each request
	INSERT INTO UserActionLog (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,LoggedInMethod
		,UserType
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type
		,Publisher_ID
		,Section_Type
		,TitleId
		,TitleName
		,ItemId
		,ItemName
		,YOP
		,ISSN
		,ISBN
		,[Language]
	)
	SELECT
		FromLogRecordWithId = CAST(FromLogRecordWithId AS VARCHAR(20))
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType='Investigation'
		,UserId
		,LoggedInMethod
		,UserType
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type
		,Publisher_ID
		,Section_Type
		,TitleId
		,TitleName
		,ItemId
		,ItemName
		,YOP
		,ISSN
		,ISBN
		,[Language]
	FROM UserActionLog 
	WHERE UserActionLogId > @MaxUserActionLogIdBeforeInserts
	AND ActionType = 'Request'
	SET @RowCount = @@ROWCOUNT 
	SET @Message += CAST(@RowCount AS VARCHAR) + ' UserActionLog Investigations records added for copy Requests' + @NewLine

--************************************************************************************************************************************************************
--************************************************************************************************************************************************************
--Add Search Actions
	SELECT @UserActionLogLastPEPWebSessionLogId = ParameterValue FROM stblParameters WHERE ParameterName = 'UserActionLogLastPEPWebSessionLogId'
	IF @UserActionLogLastPEPWebSessionLogId IS NULL SET @UserActionLogLastPEPWebSessionLogId =0
	INSERT INTO UserActionLog (
		FromLogRecordWithId
		,UserSessionId
		,DateTime
		,MonthStartDate
		,ActionType
		,UserId
		,LoggedInMethod
		,UserType
		,SubscriberId
		,SubscriberName
		,Institution_Id
		,Institution_Name
		,Access_Type
		,Access_Method
		,Data_Type 
	)
	SELECT
		FromLogRecordWithId = CAST(l.PEPWebSessionLogId AS VARCHAR(20))
		,l.UserSessionId 
		,l.LastUpdate 
		,MonthStartDate = '01-' + FORMAT(l.LastUpdate,'MMM-yyyy')
		,ActionType = 'Search'
		,ru.UserId 
		,LoggedInMethod = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='LoggedInMethod' AND CAST(usd.UserSessionId AS VARCHAR(50))=l.UserSessionId )
		,UserType = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='UserType' AND CAST(usd.UserSessionId AS VARCHAR(50))=l.UserSessionId )
		,s.SubscriberId 
		,s.SubscriberName 
		,Institution_Id = so.AffiliateRateSubscriberId
		,Institution_Name = so.AffiliateRateSubscriberName
		,Access_Type = 'Controlled' 
		,Access_Method = 'Regular'
		,Data_Type ='Database'
	FROM PEPWebSessionLog l
		LEFT JOIN (
			SELECT l.UserSessionId 
				,UserName = MAX(l.UserName )
				,SubscriberId = MAX(l.SubscriberId )
				,OrderNumber = MAX(l.OrderNumber)
			FROM PEPWebUsageLog l
			WHERE l.UserName <>'0'
			and l.DateTime >='01-dec-2020'
			AND isnumeric(l.username) =1
			GROUP BY l.UserSessionId 
		) u
		ON u.UserSessionId = l.UserSessionId 
		LEFT JOIN Subscriber s
		ON s.SubscriberId = u.SubscriberId 
		LEFT JOIN RemoteUser ru
		ON CAST(ru.UserId AS VARCHAR) = u.UserName 
		LEFT JOIN (SELECT so.OrderNumber 
						,AffiliateRateSubscriberName = MAX(so.AffiliateRateSubscriberName )
						,AffiliateRateSubscriberId = MAX(so.AffiliateRateSubscriberId )
						,AffiliateRateType = MAX(so.AffiliateRateType )
					FROM vw430SalesDetails so
					GROUP BY so.OrderNumber ) so
		ON so.OrderNumber = u.OrderNumber 
	where 1=1
	AND l.Endpoint = '/Database/Search/'
	AND l.Params LIKE '%user=true%'
	and l.PEPWebSessionLogId  >@UserActionLogLastPEPWebSessionLogId
	AND l.LastUpdate >= @UserActionLogStartFromDateTime
	SET @RowCount = @@ROWCOUNT 
	SET @Message += CAST(@RowCount AS VARCHAR) + ' UserActionLog Search records added' + @NewLine
	DELETE FROM stblParameters WHERE ParameterName = 'UserActionLogLastPEPWebSessionLogId'
	INSERT INTO stblParameters SELECT 'UserActionLogLastPEPWebSessionLogId' ,'System','All', (SELECT MAX(CAST(ISNULL(FromLogRecordWithId,0) AS INT)) FROM UserActionLog WHERE ActionType IN ('Search' )),NULL,NULL


	COMMIT TRAN
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SELECT @Message +='sp601PopulateActivityLog Failed:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE()  + @NewLine; SET @ThrowError = 1
	RAISERROR ('%s', 18, 1,@Message)
END CATCH	
exec sp029UpdateBatchLog @BatchLogId,@Message;IF @ThrowError<>0 RAISERROR ('%s', 18, 1,@Message) 

GO
