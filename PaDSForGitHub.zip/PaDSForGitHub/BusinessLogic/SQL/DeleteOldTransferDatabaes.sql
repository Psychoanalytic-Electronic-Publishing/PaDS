USE MASTER
DECLARE @DBName VARCHAR(200)
		,@CRDate DATETIME
		, @KeepDB BIT = 0
		,@SQL VARCHAR(MAX)


DECLARE cur CURSOR FOR
	SELECT
		Name
		,crdate
	FROM sysdatabases
	WHERE name like 'PaDS_LiveBefore20%'
	ORDER BY crdate 
Open cur 
FETCH cur INTO @DBName, @CRDate
WHILE @@FETCH_STATUS = 0 
BEGIN
	SET @KeepDB = 0
	--Delete DBs if not set to @KeepDB below
	--1/4/21	James Woosnam	Reduce number of copies
	IF DATEPART(HOUR,@CRDate) = 0 AND DATEPART(MINUTE,@CRDate) < 15 AND @CRDATE > DATEADD(DAY,-2,GETDATE()) SET @KeepDB = 1 --Last 2 days
	IF DATEPART(HOUR,@CRDate) = 0 AND DATEPART(MINUTE,@CRDate) < 15 AND DATEPART(WEEKDAY ,@CRDate) = 1 AND @CRDATE > DATEADD(day,-15,GETDATE()) SET @KeepDB = 1 --every week for 2 weeks
	IF DATEPART(HOUR,@CRDate) = 0 AND DATEPART(MINUTE,@CRDate) < 15 AND DATEPART(DAY ,@CRDate) = 1 AND @CRDATE > DATEADD(MONTH,-4,GETDATE()) SET @KeepDB = 1 --every month for last 4 months
	IF DATEPART(HOUR,@CRDate) = 0 AND DATEPART(MINUTE,@CRDate) < 15 AND DATEPART(DAY ,@CRDate) = 1 AND DATEPART(MONTH ,@CRDate) = 1 AND @CRDATE > DATEADD(YEAR,-2,GETDATE())  SET @KeepDB = 1 --last 2 years
	
	IF @KeepDB <> 1
	BEGIN
		SET @SQL = 'ALTER Database ' + @DBName + ' SET SINGLE_USER WITH ROLLBACK IMMEDIATE; DROP Database ' + @DBName
		EXEC(@SQL)
	END
	FETCH cur INTO @DBName, @CRDate
END
CLOSE cur 
DEALLOCATE cur 
