--Added PaDSSuperCompanyAdminUser on 05/05/2004 as a modification by jgates
--Sep 2019		James Woosnam	Remove old logons and use PaDSSQLServerUser only
Use PaDS_Logs

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp510WriteToAuditLog]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp510WriteToAuditLog]
GO
CREATE PROCEDURE sp510WriteToAuditLog ( 
					@TableName varchar(50)
					,@UpdatedByUserId int
					,@UpdatedByUserName Varchar(50)
					,@UpdatedRecordKey varchar(50)
					,@ModificationType varchar(20)
					,@Description varchar(4000)
					,@DatabaseName varchar(50)
					)
As
	INSERT INTO AuditLog
		( TableName
		, AuditDate
		, UpdatedByUserId
		, UpdatedByUserName
		, UpdatedRecordKey
		, ModificationType
		, [Description]
		, [DatabaseName]
		)
	VALUES ( @TableName
		,GetDate()
		,@UpdatedByUserId
		,@UpdatedByUserName
		,@UpdatedRecordKey
		,@ModificationType
		,@Description
		,@DatabaseName
		)
Go

Grant Execute On sp510WriteToAuditLog to PaDSSQLServerUser



