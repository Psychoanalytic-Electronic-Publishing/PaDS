if exists (select * from dbo.sysobjects where id = object_id(N'fn275ContentSetSourceDesc') and xtype in (N'FN', N'IF', N'TF'))
drop function fn275ContentSetSourceDesc
GO
CREATE FUNCTION fn275ContentSetSourceDesc( @ContentSetId INT, @SourceType VARCHAR(20))
RETURNS Varchar(max)
AS
BEGIN
DECLARE @Out VARCHAR(max) = '--'


DECLARE @SourceItem VARCHAR(200)
DECLARE @SourceItems VARCHAR(max) = ''


DECLARE cur CURSOR FOR 
SELECT
Item = cssi.ContentCode 
FROM ContentSetSource css
	INNER JOIN ContentSetSourceItem cssi
	ON cssi.ContentSetSourceId = css.ContentSetSourceId 
WHERE css.ContentSetId = @ContentSetId
AND css.SourceType = @SourceType 
ORDER BY cssi.ContentCode 
Open cur 
FETCH cur 
INTO @SourceItem
WHILE @@FETCH_STATUS = 0 
BEGIN
	SET @SourceItems += CASE WHEN @SourceItems='' THEN '' ELSE ', ' END + @SourceItem
	FETCH cur 
	INTO @SourceItem
END
CLOSE cur 
DEALLOCATE cur 

SELECT @Out = CASE 
					WHEN css.IncludeAllSourceItems=1 THEN 'All ' + css.SourceType + CASE WHEN css.ExcludeEmbargoedYears = 1 AND ISNULL(css.OverrideEmbargoYears,0)=0 THEN ' (Excluding standard Embargoed years)' ELSE '' END
																					+ CASE WHEN css.ExcludeEmbargoedYears = 1 AND ISNULL(css.OverrideEmbargoYears,0)<>0 THEN ' (Excluding ' + FORMAT(css.OverrideEmbargoYears,'0') + ' Embargoed years)' ELSE '' END
					ELSE css.SourceType + ': ' + @SourceItems END		
FROM ContentSetSource css
WHERE css.ContentSetId = @ContentSetId 
AND css.SourceType = @SourceType 

RETURN ( @Out)

END

GO
GRANT  EXECUTE ON fn275ContentSetSourceDesc TO PaDSSQLServerUser

 