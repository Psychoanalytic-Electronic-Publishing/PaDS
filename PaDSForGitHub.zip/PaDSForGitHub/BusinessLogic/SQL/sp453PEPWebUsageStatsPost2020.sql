IF  exists (select * from dbo.sysobjects where id = object_id(N'sp453PEPWebUsageStatsPost2020') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp453PEPWebUsageStatsPost2020
GO
CREATE  PROCEDURE sp453PEPWebUsageStatsPost2020 (
					@FromDate DATETIME = '01-Jan-2021'
					,@ToDate DATETIME = '31-DEC-4949'
)
AS

CREATE TABLE #Log (
	DateTime datetime NOT NULL,
	DateTime datetime NOT NULL,
	DateDay varchar(20) NULL,
	DateHour varchar(20) NULL,
	HourNumber varchar(20) NULL,
	GroupUserSessionBy varchar(20) NULL,
	Year varchar(30) NULL,
	Quarter varchar(30) NULL,
	Month varchar(30) NULL,
	ActionType varchar(20) NOT NULL,
	LogonLocation varchar(20) NOT NULL,
	LogonStatus varchar(20) NOT NULL,
	LoggedUserName varchar(200)  NULL,
	UserName varchar(200) NULL,
	UserFullName varchar(200) NULL,
	AffiliateRateSubscriberName varchar(150) NULL,
	AffiliateRateSubscriberId int NULL,
	AffiliateRateType varchar(10) NULL,
	OrderNumber int NULL,
	UserCountry varchar(100)  NULL,
	ReasonForCheck varchar(20) NULL,
	SubscriptionEndDate VARCHAR(50) NULL,
	LoggedInMethod VARCHAR(50) NULL,
	DocumentId varchar(50) NULL,
	documentRef varchar(200) NULL,
	PEPCode varchar(200) NULL,
	DocumentVolume varchar(200) NULL,
	DocumentYear varchar(4) NULL,
	authorMast varchar(200) NULL,
	UserSessionId varchar(50) NULL
)

--Add FullReads & Logons
INSERT INTO #Log ( DateTime,	DateDay,	DateHour,	HourNumber,	GroupUserSessionBy,	Year,	Quarter,	Month,	ActionType,	LogonLocation,	LogonStatus,	LoggedUserName,	UserName,	UserFullName,	AffiliateRateSubscriberName,	AffiliateRateSubscriberId,	AffiliateRateType,	OrderNumber,	UserCountry,	ReasonForCheck,	SubscriptionEndDate,	LoggedInMethod,	DocumentId,	documentRef,	PEPCode,	DocumentVolume,	DocumentYear,	authorMast,	UserSessionId)
SELECT
	l.DateTime 
	,DateDay = FORMAT(l.DateTime ,'dd-MMM-yy')
	,DateHour = FORMAT(l.DateTime ,'dd-MMM-yy HH') + ':00:00'
	,HourNumber = FORMAT(l.DateTime ,'HH')
	,GroupUserSessionBy = FORMAT(l.DateTime ,'dd-MMM-yy') --day
	,rc.[Year]
	,rc.[Quarter]
	,rc.[Month]
	,ActionType = CASE 
						WHEN l.ActionType = 'Authorise' AND l.ReasonForCheck  = 'DocumentView' AND l.LogonStatus  = 'Success' THEN 'FullRead' 
						WHEN l.ActionType = 'Authorise' AND l.ReasonForCheck  = 'DocumentView' AND l.LogonStatus  = 'Failed' THEN 'FailedRead' 
						WHEN l.ActionType = 'Authorise' THEN 'Abstract' 
						WHEN l.ActionType = 'Authenticate' AND l.LogonStatus  = 'Success' THEN 'Logon' 
						WHEN l.ActionType = 'Authenticate' AND l.LogonStatus  = 'Failed' THEN 'FailedLogon' 
						ELSE 'Unknown' END
	,l.LogonLocation 
	,l.LogonStatus 
	,LoggedUserName = l.UserName 
	,ru.UserName   
	,ru.UserFullName   
	,so.AffiliateRateSubscriberName
	,so.AffiliateRateSubscriberId
	,so.AffiliateRateType 
	,l.OrderNumber 
	,UserCountry = ISNULL((SELECT c.CountryName FROM Country c WHERE c.CountryId= s.PrimaryCountryId ),'Unknown')
	,l.ReasonForCheck
	,SubscriptionEndDate = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='SubscriptionEndDate' AND usd.UserSessionId = CAST(l.UserSessionId AS uniqueidentifier ) )
	,LoggedInMethod = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='LoggedInMethod' AND usd.UserSessionId = CAST(l.UserSessionId AS uniqueidentifier ) )
	,l.DocumentId 
	,d.documentRef
	,d.PEPCode
	,DocumentVolume = d.vol 
	,DocumentYear = CAST(d.year AS VARCHAR(4))
	,d.authorMast 
	,l.UserSessionId
FROM PEPWebUsageLog l
	LEFT JOIN (
		SELECT l.UserSessionId 
			,UserName = MAX(l.UserName )
			,SubscriberId = MAX(l.SubscriberId )
			,OrderNumber = MAX(l.OrderNumber)
		FROM PEPWebUsageLog l
		WHERE l.UserName <>'0'
		and l.DateTime >='01-dec-2020'
		AND isnumeric(l.username) =1
		GROUP BY l.UserSessionId 
	) u
	ON u.UserSessionId = l.UserSessionId 
	LEFT JOIN RemoteUser ru
	ON CAST(ru.UserId AS VARCHAR(20)) = u.UserName 
	LEFT JOIN Subscriber s
	ON s.SubscriberId = u.SubscriberId 
	LEFT JOIN (SELECT so.OrderNumber 
					,AffiliateRateSubscriberName = MAX(so.AffiliateRateSubscriberName )
					,AffiliateRateSubscriberId = MAX(so.AffiliateRateSubscriberId )
					,AffiliateRateType = MAX(so.AffiliateRateType )
				FROM vw430SalesDetails so
				GROUP BY so.OrderNumber ) so
	ON so.OrderNumber = u.OrderNumber 
	left join contentdocuments d
		left join contentjournals j
		on j.pepcode = d.pepcode
	on d.DocumentId = l.DocumentId collate database_default
	LEFT JOIN ReportingCalendar rc
	ON rc.CalendarDate = CAST(FORMAT(l.DateTime ,'dd-MMM-yy') AS DATETIME)
where 1=1
and l.DateTime BETWEEN @FromDate AND @ToDate 
and l.LogonLocation = 'PEPSecurity'
AND isnumeric(l.username)=1
AND l.ActionType IN ( 'Authorise','Authenticate')

--Add Searches
INSERT INTO #Log (DateTime,	DateDay,	DateHour,	HourNumber,	GroupUserSessionBy,	Year,	Quarter,	Month,	ActionType,	LogonLocation,	LogonStatus,	LoggedUserName,	UserName,	UserFullName,	AffiliateRateSubscriberName,	AffiliateRateSubscriberId,	AffiliateRateType,	OrderNumber,	UserCountry,	ReasonForCheck,	SubscriptionEndDate,	LoggedInMethod,	DocumentId,	documentRef,	PEPCode,	DocumentVolume,	DocumentYear,	authorMast,	UserSessionId)
SELECT
	l.LastUpdate 
	,DateDay = FORMAT(l.LastUpdate ,'dd-MMM-yy')
	,DateHour = FORMAT(l.LastUpdate ,'dd-MMM-yy HH') + ':00:00'
	,HourNumber = FORMAT(l.LastUpdate ,'HH')
	,GroupUserSessionBy = FORMAT(LastUpdate,'yyyy-MM-dd HH:mm:ss')--For search each one counts
	,rc.[Year]
	,rc.[Quarter]
	,rc.[Month]
	,ActionType = 'Search'
	,LogonLocation = 'PEPSecurity'
	,LogonStatus ='Seccess'
	,LoggedUserName = ru.UserName 
	,ru.UserName   
	,ru.UserFullName   
	,so.AffiliateRateSubscriberName
	,so.AffiliateRateSubscriberId
	,so.AffiliateRateType 
	,u.OrderNumber 
	,UserCountry = ISNULL((SELECT c.CountryName FROM Country c WHERE c.CountryId= s.PrimaryCountryId ),'Unknown')
	,ReasonForCheck = 'Search'
	,SubscriptionEndDate = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='SubscriptionEndDate' AND usd.UserSessionId = CAST(l.UserSessionId AS uniqueidentifier ))
	,LoggedInMethod = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='LoggedInMethod' AND usd.UserSessionId = CAST(l.UserSessionId AS uniqueidentifier ) )
	,DocumentId = ''
	,documentRef = ''
	,PEPCode = ''
	,DocumentVolume = '' 
	,DocumentYear = ''
	,authorMast  = ''
	,l.UserSessionId

FROM PEPWebSessionLog l
	LEFT JOIN (
		SELECT l.UserSessionId 
			,UserName = MAX(l.UserName )
			,SubscriberId = MAX(l.SubscriberId )
			,OrderNumber = MAX(l.OrderNumber)
		FROM PEPWebUsageLog l
		WHERE l.UserName <>'0'
		and l.DateTime >='01-dec-2020'
		AND isnumeric(l.username) =1
		GROUP BY l.UserSessionId 
	) u
	ON u.UserSessionId = l.UserSessionId 
	LEFT JOIN Subscriber s
	ON s.SubscriberId = u.SubscriberId 
	LEFT JOIN RemoteUser ru
	ON CAST(ru.UserId AS VARCHAR) = u.UserName 
	LEFT JOIN (SELECT so.OrderNumber 
					,AffiliateRateSubscriberName = MAX(so.AffiliateRateSubscriberName )
					,AffiliateRateSubscriberId = MAX(so.AffiliateRateSubscriberId )
					,AffiliateRateType = MAX(so.AffiliateRateType )
				FROM vw430SalesDetails so
				GROUP BY so.OrderNumber ) so
	ON so.OrderNumber = u.OrderNumber 
	LEFT JOIN ReportingCalendar rc
	ON rc.CalendarDate = CAST(FORMAT(l.LastUpdate ,'dd-MMM-yy') AS DATETIME)
where 1=1
AND l.Endpoint = '/Database/Search/'
AND l.Params LIKE '%user=true%'
and l.LastUpdate BETWEEN @FromDate AND @ToDate 



SELECT
DateTime,	DateDay,	DateHour,	HourNumber,	GroupUserSessionBy,	Year,	Quarter,	Month,	ActionType,	LogonLocation,	LogonStatus,	LoggedUserName,	UserName,	UserFullName,	AffiliateRateSubscriberName,	AffiliateRateSubscriberId,	AffiliateRateType,	OrderNumber,	UserCountry,	ReasonForCheck,	SubscriptionEndDate,	LoggedInMethod,	DocumentId,	documentRef,	PEPCode,	DocumentVolume,	DocumentYear,	authorMast,	UserSessionId
,UserSessionCount=CASE WHEN l.Id = (SELECT Min(l2.Id ) 
					FROM #Log l2
					WHERE l2.UserName = l.UserName 
					AND l2.GroupUserSessionBy = l.GroupUserSessionBy 
				 )	THEN 1 ELSE 0 END
,SessionDurationMinutes = DATEDIFF(MINUTE,(SELECT MIN(l2.DateTime) FROM #Log l2 WHERE l2.UserSessionId = l.UserSessionId) , (SELECT MAX(l3.DateTime) FROM #Log l3 WHERE l3.UserSessionId = l.UserSessionId))
FROM #Log l
WHERE 1=1
AND l.DateTime = (SELECT MAX(l2.DateTime ) 
					FROM #Log l2
					WHERE l2.UserName = l.UserName 
					and l2.DocumentId = l.DocumentId 
					and l2.ActionType = l.ActionType 
					and l2.LoggedInMethod  = l.LoggedInMethod  
					AND l2.GroupUserSessionBy = l.GroupUserSessionBy 
				 )

order by l.DateTime desc

DROP TABLE #Log
GO
--EXEC sp453PEPWebUsageStatsPost2020