IF  exists (select * from dbo.sysobjects where id = object_id(N'sp453PEPWebUsageStatsPost2020') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp453PEPWebUsageStatsPost2020
GO
CREATE  PROCEDURE sp453PEPWebUsageStatsPost2020 (
					@FromDate DATETIME = '01-Jan-2021'
					,@ToDate DATETIME = '31-DEC-4949'
)
AS


SELECT
	l.DateTime 
	,DateDay = FORMAT(l.DateTime ,'dd-MMM-yy')
	,DateHour = FORMAT(l.DateTime ,'dd-MMM-yy HH') + ':00:00'
	,HourNumber = FORMAT(l.DateTime ,'HH')
	,GroupUserSessionBy = FORMAT(l.DateTime ,'dd-MMM-yy') --day
	,rc.[Year]
	,rc.[Quarter]
	,rc.[Month]
	,ActionType = CASE WHEN l.ActionType = 'Authorise' THEN 'FullRead' WHEN l.ActionType = 'Authenticate' THEN 'Logon' ELSE 'Unknown' END
	,l.LogonLocation 
	,l.LogonStatus 
	,LoggedUserName = l.UserName 
	,ru.UserName   
	,ru.UserFullName   
	,so.AffiliateRateSubscriberName
	,so.AffiliateRateSubscriberId
	,so.AffiliateRateType 
	,l.OrderNumber 
	,UserCountry = ISNULL((SELECT c.CountryName FROM Country c WHERE c.CountryId= s.PrimaryCountryId ),'Unknown')
	,l.ReasonForCheck
	,SubscriptionEndDate = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='SubscriptionEndDate' AND CAST(usd.UserSessionId AS VARCHAR(50))=l.UserSessionId )
	,l.DocumentId 
	,d.documentRef
	,d.PEPCode
	,DocumentVolume = d.vol 
	,DocumentYear = d.year
	,d.authorMast 
	,l.UserSessionId
--,d.*
INTO #Log
FROM PEPWebUsageLog l
	LEFT JOIN (
		SELECT l.UserSessionId 
			,UserName = MAX(l.UserName )
			,SubscriberId = MAX(l.SubscriberId )
			,OrderNumber = MAX(l.OrderNumber)
		FROM PEPWebUsageLog l
		WHERE l.UserName <>'0'
		and l.DateTime >='01-dec-2020'
		AND isnumeric(l.username) =1
		GROUP BY l.UserSessionId 
	) u
	ON u.UserSessionId = l.UserSessionId 
	LEFT JOIN RemoteUser ru
	ON CAST(ru.UserId AS VARCHAR(20)) = u.UserName 
	LEFT JOIN Subscriber s
	ON s.SubscriberId = u.SubscriberId 
	LEFT JOIN (SELECT so.OrderNumber 
					,AffiliateRateSubscriberName = MAX(so.AffiliateRateSubscriberName )
					,AffiliateRateSubscriberId = MAX(so.AffiliateRateSubscriberId )
					,AffiliateRateType = MAX(so.AffiliateRateType )
				FROM vw430SalesDetails so
				GROUP BY so.OrderNumber ) so
	ON so.OrderNumber = u.OrderNumber 
	left join contentdocuments d
		left join contentjournals j
		on j.pepcode = d.pepcode
	on d.DocumentId = l.DocumentId collate database_default
	LEFT JOIN ReportingCalendar rc
	ON rc.CalendarDate = CAST(FORMAT(l.DateTime ,'dd-MMM-yy') AS DATETIME)
where 1=1
and l.DateTime BETWEEN @FromDate AND @ToDate 
AND isnumeric(l.username)=1
AND l.ActionType IN ( 'Authorise','Authenticate')
AND l.LogonStatus  = 'Success'
AND l.ReasonForCheck  <> 'AbstractView'

SELECT
*
,SessionDurationMinutes = DATEDIFF(MINUTE,(SELECT MIN(l2.DateTime) FROM #Log l2 WHERE l2.UserSessionId = l.UserSessionId) , (SELECT MAX(l3.DateTime) FROM #Log l3 WHERE l3.UserSessionId = l.UserSessionId))
FROM #Log l
WHERE 1=1
AND l.DateTime = (SELECT MAX(l2.DateTime ) 
					FROM #Log l2
					WHERE l2.UserName = l.UserName 
					and l2.DocumentId = l.DocumentId 
					AND l2.GroupUserSessionBy = l.GroupUserSessionBy 
				 )

order by l.DateTime desc

DROP TABLE #Log
GO
--EXEC sp453PEPWebUsageStatsPost2020