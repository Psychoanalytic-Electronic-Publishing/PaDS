IF  exists (select * from dbo.sysobjects where id = object_id(N'sp453PEPWebUsageStatsPost2020') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp453PEPWebUsageStatsPost2020
GO
CREATE  PROCEDURE sp453PEPWebUsageStatsPost2020
AS
SELECT
l.DateTime 
,DateDay = FORMAT(l.DateTime ,'dd-MMM-yy')
,DateHour = FORMAT(l.DateTime ,'dd-MMM-yy HH') + ':00:00'
,HourNumber = FORMAT(l.DateTime ,'HH')
,GroupUserSessionBy = FORMAT(l.DateTime ,'dd-MMM-yy') --day
,l.ActionType 
,l.LogonLocation 
,l.LogonStatus 
,l.UserName 
,ru.UserFullName   
,s.SubscriberName 
,l.OrderNumber 
,UserCountry = ISNULL((SELECT c.CountryName FROM Country c WHERE c.CountryId= s.PrimaryCountryId ),'Unknown')
,l.ReasonForCheck
,SubscriptionEndDate = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='SubscriptionEndDate' AND usd.UserSessionId=l.UserSessionId )
,l.DocumentId 
,d.documentRef
,d.PEPCode
,d.vol 
,d.year
,d.authorMast 
--,d.*
INTO #Log
FROM PEPWebUsageLog l
	LEFT JOIN RemoteUser ru
		
	ON ru.UserId = l.UserName 
	LEFT JOIN Subscriber s
	ON s.SubscriberId = (SELECT MAX(rur.RightsToId ) FROM RemoteUserRights rur WHERE rur.UserId = ru.UserId and rur.RightsType = 'Subscriber')
	left join contentdocuments d
		left join contentjournals j
		on j.pepcode = d.pepcode
	on d.DocumentId = l.DocumentId collate database_default
where 1=1
and l.DateTime >='01-oct-2020'
AND l.ActionType IN ( 'Authorise','Authenticate')
AND l.LogonStatus  = 'Success'
AND l.ReasonForCheck  <> 'Check'

SELECT
*
FROM #Log l
WHERE 1=1
AND l.DateTime = (SELECT MAX(l2.DateTime ) 
					FROM #Log l2
					WHERE l2.UserName = l.UserName 
					and l2.DocumentId = l.DocumentId 
					AND l2.GroupUserSessionBy = l.GroupUserSessionBy 
				 )

order by l.DateTime desc

DROP TABLE #Log
GO
EXEC sp453PEPWebUsageStatsPost2020