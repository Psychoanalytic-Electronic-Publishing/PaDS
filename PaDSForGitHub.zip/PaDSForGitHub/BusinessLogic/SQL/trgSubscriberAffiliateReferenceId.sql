if exists (select * from sysobjects where id = object_id(N'[dbo].[trgSubscriberAffiliateReferenceId]') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER trgSubscriberAffiliateReferenceId
Go
CREATE TRIGGER trgSubscriberAffiliateReferenceId ON [SubscriberAffiliate]
FOR Update,Insert
AS
Update SubscriberAffiliate
SET AffiliateReferenceId = INSERTED.ChildSubscriberId
	,LastUpdatedDateTime = INSERTED.LastUpdatedDateTime 
	,LastUpdatedByUserId  = INSERTED.LastUpdatedByUserId 
FROM SubscriberAffiliate
	INNER JOIN INSERTED
	ON INSERTED.ParentSubscriberId = SubscriberAffiliate.ParentSubscriberId
	AND INSERTED.ChildSubscriberId = SubscriberAffiliate.ChildSubscriberId
	AND INSERTED.StartDate = SubscriberAffiliate.StartDate
WHERE ISNULL(INSERTED.AffiliateReferenceId,'') = ''
AND INSERTED.ParentSubscriberId <> 30000
AND INSERTED.ParentSubscriberId NOT IN (SELECT DISTINCT GroupParentSubscriberId
										FROM Company)