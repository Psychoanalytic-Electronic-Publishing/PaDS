EXEC sp510GrantObjectRights @MakeReadOnly=0
GRANT EXECUTE ON sp510GrantObjectRights TO PaDSSQLSecurityUser