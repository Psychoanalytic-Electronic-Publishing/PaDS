IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'PaDS_Logs')
	DROP DATABASE [PaDS_Logs]
GO

CREATE DATABASE [PaDS_Logs]  ON (NAME = N'PaDS_Logs_Data'
, FILENAME = N'd:\mssql\PaDS_Logs.mdf' 
, SIZE = 40
, FILEGROWTH = 10%) LOG ON (NAME = N'PaDS_Logs_Log'
, FILENAME = N'd:\mssql\PaDS_Logs.ldf' 
, SIZE = 1, FILEGROWTH = 10%)
 COLLATE SQL_Latin1_General_CP1_CI_AS
GO

exec sp_dboption N'PaDS_Logs', N'autoclose', N'true'
GO

exec sp_dboption N'PaDS_Logs', N'bulkcopy', N'false'
GO

exec sp_dboption N'PaDS_Logs', N'trunc. log', N'true'
GO

exec sp_dboption N'PaDS_Logs', N'torn page detection', N'true'
GO

exec sp_dboption N'PaDS_Logs', N'read only', N'false'
GO

exec sp_dboption N'PaDS_Logs', N'dbo use', N'false'
GO

exec sp_dboption N'PaDS_Logs', N'single', N'false'
GO

exec sp_dboption N'PaDS_Logs', N'autoshrink', N'true'
GO

exec sp_dboption N'PaDS_Logs', N'ANSI null default', N'false'
GO

exec sp_dboption N'PaDS_Logs', N'recursive triggers', N'false'
GO

exec sp_dboption N'PaDS_Logs', N'ANSI nulls', N'false'
GO

exec sp_dboption N'PaDS_Logs', N'concat null yields null', N'false'
GO

exec sp_dboption N'PaDS_Logs', N'cursor close on commit', N'false'
GO

exec sp_dboption N'PaDS_Logs', N'default to local cursor', N'false'
GO

exec sp_dboption N'PaDS_Logs', N'quoted identifier', N'false'
GO

exec sp_dboption N'PaDS_Logs', N'ANSI warnings', N'false'
GO

exec sp_dboption N'PaDS_Logs', N'auto create statistics', N'true'
GO

exec sp_dboption N'PaDS_Logs', N'auto update statistics', N'true'
GO

use [PaDS_Logs]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[SessionLog]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[SessionLog]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[AuditLog]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[AuditLog]
GO

CREATE TABLE [dbo].[SessionLog] (
	[SessionLogId] [int] IDENTITY (1, 1) NOT NULL ,
	[Date] [datetime] NOT NULL ,
	[LogType] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[PageId] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[PageTitle] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[UserId] [int] NULL ,
	[UserName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Comment] [varchar] (5000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[SessionId] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[RemoteIPAddress] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[AuditLog] (
	[TableName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[AuditDate] [datetime] NOT NULL ,
	[UpdatedByUserId] [int] NOT NULL ,
	[UpdatedByUserName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[UpdatedRecordKey] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[ModificationType] [varchar] (20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Description] [varchar] (4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[DatabaseName] [varchar] (50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL 
) ON [PRIMARY]
GO

