if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp494GetSubscriptions]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp494GetSubscriptions]
GO


CREATE  PROCEDURE sp494GetSubscriptions (
				 @SubscriberId INT  
				,@GroupSubscriberId INT
				,@CompanyId INT 
				)
AS
--07/03/08	James Woosnam	SIR1452 - Modified to include products bought with an affiliate product rate
select	Orders.ProductName 
	,Orders.RecurringSubscriptionEndDate 
	,Orders.OrderNumber 
from dbo.fn495GetGroupProductSubscriptions(@GroupSubscriberId,@CompanyId) Orders
WHERE Orders.SubscriberId = @SubscriberId
ORDER BY Orders.RecurringSubscriptionEndDate
Go 

--EXEC sp494GetSubscriptions @GroupSubscriberId= 37418,	@SubscriberId=17886,@CompanyId = 2


