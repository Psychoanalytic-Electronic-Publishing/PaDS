IF  exists (select * from dbo.sysobjects where id = object_id(N'sp452WebProductStatisticsFromPEPWebUsageLog') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp452WebProductStatisticsFromPEPWebUsageLog
GO
CREATE  PROCEDURE sp452WebProductStatisticsFromPEPWebUsageLog (
					@FromDate DATETIME = '01-jan-14'
					,@ToDate DATETIME = '30-jun-14'
)
--19/11/19	James Woosnam	SIR4763 - Use IndividualUsers in RemoteUser table
--29/1/2020	James Woosnam	Performance tunning for new table structure
--'17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .
AS

SELECT 
	PEPWebUsageLog.LogonLocation 
	,ProductCode = CAST('' AS VARCHAR(10))
	,ProductName = CAST('' AS VARCHAR(100))
	,ParentSubscriberId = CAST(0 AS INT)
	,ParentSubscriberName = CAST('' AS VARCHAR(150))
	,PEPWebUsageLog.SubscriberId 
	,SubscriberName = CAST('' AS VARCHAR(150))
	,WebUserName = CAST('Unknown' AS VARCHAR(200))
	,[Date] = FORMAT(PEPWebUsageLog.DateTime,'dd-MMM-yyyy')
	,[MonthYear] = FORMAT(MAX(PEPWebUsageLog.DateTime),'yyyy-MM MMM')
	,[MonthNo] = FORMAT(MAX(PEPWebUsageLog.DateTime),'MM')
	,[Year] = FORMAT(MAX(PEPWebUsageLog.DateTime),'yyyy')
	,LinkStatus = PEPWebUsageLog.LogonStatus
	,LinkFailureReason = PEPWebUsageLog.AdditionalDetails
	,LinkCount = Count(*) 
	,CountryName = CAST('na' AS VARCHAR(100))
	,PEPWebUsageLog.OrderNumber 
INTO #Stata
FROM PaDS_Logs.dbo.PEPWebUsageLog PEPWebUsageLog
WHERE CAST(LEFT(CONVERT(VARCHAR,PEPWebUsageLog.DateTime,13),11) as DATETIME)  BETWEEN @FromDate 
       AND @ToDate 
GROUP BY 
PEPWebUsageLog.LogonLocation 
	,PEPWebUsageLog.SubscriberId 
	,FORMAT(PEPWebUsageLog.DateTime,'dd-MMM-yyyy')
	,PEPWebUsageLog.LogonStatus
	,PEPWebUsageLog.AdditionalDetails
	,PEPWebUsageLog.OrderNumber 

--Update sub id to correct one 
Update #Stata 
--if proposed sub leave sub ID as is, if not wrong one on log so use UpdateToSubscriberId
Set SubscriberId = CASE WHEN s.SubscriberStatus = 'Merged' THEN ISNULL( s.UpdateToSubscriberId,st.SubscriberId) ELSE st.SubscriberId END
--Join to remoteuser should always work 
,WebUserName = ISNULL(ru.userName,st.WebUserName)
FROM #Stata st
	INNER JOIN Subscriber s
	ON s.SubscriberId = st.SubscriberId 
	LEFT JOIN RemoteUserRights rur
		INNER JOIN RemoteUser ru
		ON ru.UserId = rur.UserId 
	ON rur.RightsToId = st.SubscriberId 
	AND rur.RightsType = 'Subscriber'

--Get sub name and try getting webuser again as subId might have changed
Update #Stata 
Set SubscriberName = s.SubscriberName 
	,WebUserName = ISNULL(ru.userName,st.WebUserName)
FROM #Stata st
	INNER JOIN Subscriber s
	On s.SubscriberId = st.SubscriberId 
	LEFT JOIN RemoteUserRights rur
		INNER JOIN RemoteUser ru
		ON ru.UserId = rur.UserId 
	ON rur.RightsToId = st.SubscriberId 
	AND rur.RightsType = 'Subscriber'

Update #Stata 
Set ParentSubscriberId = so.SubscriberId 
,ParentSubscriberName = CASE WHEN st.SubscriberId = so.SubscriberId THEN 'na' ELSE s.SubscriberName END
,ProductCode = so.PrimaryProductCode 
,ProductName = Product.ProductName 
FROM #Stata st
    INNER JOIN SalesOrder so
		LEFT JOIN Subscriber s
		ON s.SubscriberId = so.SubscriberId  
    ON   so.OrderNumber = st.OrderNumber
    INNER JOIN Product  
    On Product.ProductCode = so.PrimaryProductCode

--try and set country to sub promary one	
Update #Stata 
Set CountryName = primC.CountryName 
FROM #Stata st
	INNER JOIN Subscriber s
		INNER JOIN Country primC
		On primC.CountryID = s.PrimaryCountryId 
     ON s.SubscriberId = st.SubscriberId 

--if country not found get from postal
Update #Stata 
Set CountryName = c.CountryName
FROM #Stata st
     INNER JOIN SubscriberAddress sa
           INNER JOIN Country c
           On c.CountryID = sa.CountryId
     ON sa.SubscriberId = st.SubscriberId 
     AND sa.AddressType = 'Postal'
     AND sa.AddressDescription = 'Main'
WHERE st.CountryName = 'na'
--if country not found get from billing
Update #Stata 
Set CountryName = c.CountryName
FROM #Stata st
     INNER JOIN SubscriberAddress sa
           INNER JOIN Country c
           On c.CountryID = sa.CountryId
     ON sa.SubscriberId = st.SubscriberId 
     AND sa.AddressType = 'Postal'
     AND sa.AddressDescription = 'Billing'
WHERE st.CountryName = 'na'

ALTER TABLE #Stata DROP COLUMN OrderNumber

SELECT *
from #Stata 
ORDER BY ProductCode
	,[Date]


GO
GRANT  EXECUTE ON sp452WebProductStatisticsFromPEPWebUsageLog TO PaDSSQLServerUser