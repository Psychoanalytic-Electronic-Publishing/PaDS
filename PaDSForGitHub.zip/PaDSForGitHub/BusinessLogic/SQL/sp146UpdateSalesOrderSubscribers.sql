if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp146UpdateSalesOrderSubscribers') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp146UpdateSalesOrderSubscribers
Go
CREATE PROCEDURE sp146UpdateSalesOrderSubscribers(
			@OrderNumber INT
			,@SubscriberId INT
			,@Included BIT
			,@DeliveryAddressId INT=0
			,@ProductRateId INT
			,@Quantity INT
			,@UserName20 VARCHAR(20)
			,@IncludesAssociatedProduct BIT=0
			)				
AS
/**********************************************
Modifications
=============
06/05/20	Julian Gates Add  Initial Version
2/11/20		James Woosnam	SIR5145 - Populate rates correctly
***********************************************/
DECLARE @Message VARCHAR(MAX)
	--SELECT @Message = '@@Included=' + CAST(@Included AS VARCHAR)
	--	RAISERROR ('%s', 18, 1,@Message)

IF @Included = 0
BEGIN
	DELETE FROM SalesOrderLine WHERE SubscriberId = @SubscriberId AND OrderNumber = @OrderNumber 
END
ELSE
BEGIN
	DECLARE @PrimaryProductCode VARCHAR(10)
			,@ProductRate MONEY
			 ,@AssociatedProductCode VARCHAR(10)
			,@AssociatedProductRate MONEY
			,@AssociatedProductRateId INT
			,@PrimaryhasAssociated BIT
	SELECT
		@PrimaryProductCode = p.ProductCode 
		,@ProductRate  = pr.ProductRate 
		,@AssociatedProductCode = assp.ProductCode 
		,@AssociatedProductRate  = assPr.ProductRate 
		,@AssociatedProductRateId  = assPr.ProductRateId
		,@PrimaryhasAssociated = CASE WHEN assp.ProductCode IS NULL THEN 0 ELSE 1 END
	FROM Product p
		LEFT JOIN ProductRate pr
		ON pr.ProductRateId = @ProductRateId 
		AND pr.ProductCode = p.ProductCode 
		LEFT JOIN Product assP
		ON assP.ProductCode = p.AssociatedProductCode 
		LEFT JOIN ProductRate assPR
		ON assPr.ProductCode = assP.ProductCode 
		AND assPR.AccountType = pr.AccountType 
		AND assPR.DeliveryArea  = pr.DeliveryArea 
		AND assPR.RateType  = pr.RateType 
		AND assPR.SubscriberCategory  = pr.SubscriberCategory 
		AND assPR.CurrencyCode  = pr.CurrencyCode 	
	WHERE p.ProductCode = (SELECT PrimaryProductCode FROM SalesOrder WHERE OrderNumber = @OrderNumber )
	IF @PrimaryProductCode IS NULL
	BEGIN
		SELECT @Message = 'PrimaryProductCode not found. O:' + CAST(@OrderNumber as varchar)
		RAISERROR ('%s', 18, 1,@Message)
	END
	IF @ProductRate  IS NULL
	BEGIN
		SELECT @Message = 'PrimaryProductRate not found'
		RAISERROR ('%s', 18, 1,@Message)
	END
	IF @AssociatedProductCode IS NULL AND @IncludesAssociatedProduct =1 AND @PrimaryhasAssociated=1
	BEGIN
		SELECT @Message = 'Associated product code not found, when @IncludesAssociatedProduct=1'
		RAISERROR ('%s', 18, 1,@Message)
	END
	IF @AssociatedProductRate   IS NULL AND @IncludesAssociatedProduct =1 AND @PrimaryhasAssociated=1
	BEGIN
		SELECT @Message = 'AssociatedProductRate not found'
		RAISERROR ('%s', 18, 1,@Message)
	END
	--Add affiliation to company subscriber if missing
	INSERT INTO SubscriberAffiliate
	SELECT ParentSubscriberId = c.GroupParentSubscriberId 
		,ChildSubscriberId = @SubscriberId 
		,StartDate = FORMAT(GETDATE(),'dd-MMM-yy')
		,EndDate= '31-dec-4949'
		,AffiliateReferenceID=@SubscriberId 
		,SubscriberCategory = 'Ordinary'
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName20  
	FROM SalesOrder so
		INNER JOIN Company c
		ON c.CompanyId = so.CompanyId 
		LEFT JOIN SubscriberAffiliate sa
		ON sa.ParentSubscriberID = c.GroupParentSubscriberId 
		AND sa.ChildSubscriberID = @SubscriberId 
	WHERE so.OrderNumber = @OrderNumber 
	AND sa.ParentSubscriberID IS NULL

	IF EXISTS(SELECT OrderNumber FROM SalesOrderLine WHERE SubscriberId = @SubscriberId AND OrderNumber = @OrderNumber AND ProductCode = @PrimaryProductCode )
	BEGIN
		UPDATE SalesOrderLine 
		SET DeliveryAddressId = @DeliveryAddressId 
			,ProductRateId = @ProductRateId 
			,ProductRate = @ProductRate
			,Quantity = @Quantity
			,AmountProduct = @ProductRate * @Quantity
		WHERE SubscriberId = @SubscriberId AND OrderNumber = @OrderNumber
	END
	ELSE
	BEGIN
		INSERT INTO SalesOrderLine (
			OrderNumber,
			SubscriberId,
			ProductCode,
			ProductRateId,
			DeliveryAddressId,
			ProductRate,
			Quantity,
			AmountProduct,
			CreatedDateTime,
			CreatedByUserId,
			LastUpdatedDateTime,
			LastUpdatedByUserId
		)
		SELECT
			OrderNumber = @OrderNumber ,
			SubscriberId = @SubscriberId ,
			ProductCode = @PrimaryProductCode ,
			ProductRateId = @ProductRateId ,
			DeliveryAddressId = @DeliveryAddressId ,
			ProductRate = @ProductRate,
			Quantity = @Quantity,
			AmountProduct = @ProductRate * @Quantity,
			CreatedDateTime = GetDate(),
			CreatedByUserId = @UserName20,
			LastUpdatedDateTime = GETDATE(),
			LastUpdatedByUserId = @UserName20

	END
	IF @Included = 1 AND @IncludesAssociatedProduct = 1 AND @AssociatedProductCode IS NOT NULL
	BEGIN
		IF EXISTS(SELECT OrderNumber FROM SalesOrderLine WHERE SubscriberId = @SubscriberId AND OrderNumber = @OrderNumber AND ProductCode = @AssociatedProductCode  )
		BEGIN
			UPDATE SalesOrderLine 
			SET DeliveryAddressId = @DeliveryAddressId 
				,ProductRateId = @AssociatedProductRateId 
				,ProductRate = @AssociatedProductRate
				,Quantity = @Quantity
				,AmountProduct = @AssociatedProductRate * @Quantity
			WHERE SubscriberId = @SubscriberId 
			AND OrderNumber = @OrderNumber
			AND ProductCode = @AssociatedProductCode 
		END
		ELSE
		BEGIN
			INSERT INTO SalesOrderLine (
				OrderNumber,
				SubscriberId,
				ProductCode,
				ProductRateId,
				DeliveryAddressId,
				ProductRate,
				Quantity,
				AmountProduct,
				CreatedDateTime,
				CreatedByUserId,
				LastUpdatedDateTime,
				LastUpdatedByUserId
			)
			SELECT
				OrderNumber = @OrderNumber ,
				SubscriberId = @SubscriberId ,
				ProductCode = @AssociatedProductCode  ,
				ProductRateId = @AssociatedProductRateId  ,
				DeliveryAddressId = @DeliveryAddressId ,
				ProductRate = @AssociatedProductRate ,
				Quantity = @Quantity,
				AmountProduct = @AssociatedProductRate * @Quantity,
				CreatedDateTime = GetDate(),
				CreatedByUserId = @UserName20,
				LastUpdatedDateTime = GETDATE(),
				LastUpdatedByUserId = @UserName20

		END
	END
	IF @IncludesAssociatedProduct = 0 AND @AssociatedProductCode IS NOT NULL
	BEGIN
		DELETE FROM SalesOrderLine WHERE SubscriberId = @SubscriberId AND OrderNumber = @OrderNumber AND ProductCode = @AssociatedProductCode 
	END
END
GO

GRANT EXECUTE ON sp146UpdateSalesOrderSubscribers TO PaDSSQLServerUser
