if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fn017GetParameter]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[fn017GetParameter]
GO
CREATE  FUNCTION dbo.fn017GetParameter ( @ParameterName VARCHAR(50) )
RETURNS Varchar(255)
AS
BEGIN
DECLARE @ParameterValue VARCHAR(255)

SELECT	@ParameterValue = ParameterValue
FROM dbo.stblParameters
Where ParameterName = @ParameterName


RETURN ( @ParameterValue)

END
 