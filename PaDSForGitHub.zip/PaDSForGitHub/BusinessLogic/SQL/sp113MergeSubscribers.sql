if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp113MergeSubscribers]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp113MergeSubscribers]
GO
CREATE  PROCEDURE sp113MergeSubscribers (
				 @MergeIntoSubscriberId INT  
				,@MergeFromSubscriberId INT
				,@UserId INT
				,@ReturnCode INT = 0  OUTPUT
				,@ErrorMessage varchar(200) = '' OUTPUT
				)
AS
--14/5/08	James Woosnam	SIR1533 - Bugs -Overwirting Addresses with Blanks on Merge;Updating DefaultPostal Address uncorrectly; Not allowing for nulls in address notes
--27/10/08	James Woosnam	Add SubscriberId to error message
--18/11/08	James Woosnam	SIR1615 - Update SubscriberId in RenewalReminderLog
--1/3/10	James Woosnam	SIR2179 - Don't worry about Last logon when merging Userid and password.
--17/5/2010	James Woosnam	Put AuditLog Insert directly in code as call to sp was failing maybe sql 2008 issue
--8/1/10	James Woosnam	Add new fields
--30/3/11	James Woosnam	SIR2401 - Use UpdateExistingOrdersDeliveryAddress to to indicate whether to update order delivery addresses
--21/11/19	Julian Gates	SIR4942 - Remove WebUserName, WebUserLastLoggedOn, WebUserStatus and WebUserPassword fields as no longer used.
--5/12/19		James Woosnam	SIR4769 - For GDPR user name no longer recorded on audit log
--10/1/20	James Woosnam	SIR4977 - If Into sub linked to user, make user InActive and unlink
--19/6/20	James Woosnam	SIR5085 - Copy missing child affiliates into new parent
DECLARE @ErrorFound INT
DECLARE @MergeMessage varchar(4000)
DECLARE @ROWCOUNT INT
DECLARE @TranStarted BIT
DECLARE @PassedMergeMessage varchar(200)
DECLARE @LfCr VARCHAR(2)
DECLARE @UserName varchar(50)
DECLARE @DBName varchar(50)
SET @LfCr = CHAR(13) + CHAR(10)
SET @ErrorFound = 0
SET @TranStarted = 0
SET @MergeMessage = ''

IF @ErrorFound = 0
BEGIN
	SELECT @MergeMessage = 
		CASE 	WHEN RemoteUser.UserId IS NULL THEN 'UserId:' + CAST(@USerId AS Varchar) + ' does not exist' + @LfCr
				WHEN RemoteUser.AuthorityLevel <> 'SuperCompanyAdmins' THEN 'Only RemoteUser SuperCompanyAdmins merge' + @LfCr
			ELSE ''
		END
	FROM (Select 1 BaseCol ) Base 
		LEFT JOIN  RemoteUser 
		ON UserId = @USerId 
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
IF @MergeMessage <> ''
BEGIN
	SET @ReturnCode = 1
	SET @ErrorFound =1 
	SELECT @ErrorMessage = LEFT( @MergeMessage,200)
END

IF @ErrorFound = 0
BEGIN
	SELECT @UserName = LEFT((SELECT UserName FROM RemoteUser WHERE UserId = @USerId),20)
		,@DBName = (SELECT db_name(dbid) from master..sysprocesses where spid=@@SPID)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
IF @ErrorFound = 0
BEGIN
	SELECT @MergeMessage = 
		CASE 	WHEN Subscriber.SubscriberId IS NULL THEN 'MergeIntoSubscriber:' + CAST(@MergeIntoSubscriberId AS Varchar) + ' does not exist' + @LfCr
				WHEN Subscriber.SubscriberStatus NOT IN ('Current') THEN 'Can''t merge into subscriber:' + CAST(@MergeIntoSubscriberId AS Varchar) + ' with status ' + Subscriber.SubscriberStatus  + @LfCr
			ELSE ''
		END
	FROM (Select 1 BaseCol ) Base 
		LEFT JOIN Subscriber 
		ON Subscriber.SubscriberId = @MergeIntoSubscriberId 
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
IF @ErrorFound = 0
BEGIN
	SELECT @MergeMessage = @MergeMessage + 
		CASE 	WHEN Subscriber.SubscriberId IS NULL THEN 'MergeFromSubscriber:' + CAST(@MergeFromSubscriberId AS Varchar) + ' does not exist' + @LfCr
				WHEN Subscriber.SubscriberStatus NOT IN ('Current','Proposed') THEN 'Can''t merge from subscriber:' + CAST(@MergeFromSubscriberId AS Varchar) + ' with status ' + Subscriber.SubscriberStatus + @LfCr
			ELSE ''
		END
	FROM (Select 1 BaseCol ) Base 
		LEFT JOIN Subscriber 
		ON Subscriber.SubscriberId = @MergeFromSubscriberId 
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
IF @MergeMessage <> ''
BEGIN
	SET @ReturnCode = 2
	SET @ErrorFound =1 
	SELECT @ErrorMessage = LEFT( @MergeMessage,200)
END
IF @ErrorFound = 0
BEGIN
	BEGIN TRAN
	SET @TranStarted = 1
END

IF @ErrorFound = 0
BEGIN
	SET @MergeMessage = 'Subscriber:' + CAST(@MergeFromSubscriberId as varchar) 
						+ ' Merged into ' + CAST(@MergeIntoSubscriberId as varchar) 
						+ ' on ' + convert(varchar,getdate(),13) + @LfCr
END
IF @ErrorFound = 0
BEGIN
	EXEC sp114MergeSubscriberField @FieldName = 'SubscriberName',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'ReportCategory',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'LastName',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'FirstName',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'VATNumber',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'MailMethod',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'IsReceiveMail',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'Title',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'Salutation',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'Position',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'Qualifications',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'MembershipType',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'IsTrainingAnalyst',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'IsChildAnalyst',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'IsRetired',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'GeographicalStatus',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'Spare1',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'Spare2',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'Spare3',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	EXEC sp114MergeSubscriberField @FieldName = 'Notes',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
END

IF @ErrorFound = 0
BEGIN
	UPDATE Subscriber
	SET SubscriberStatus = 'Merged'	
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	WHERE SubscriberId = @MergeFromSubscriberId
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
IF @ErrorFound = 0
BEGIN
	UPDATE Subscriber
	SET LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	WHERE SubscriberId = @MergeIntoSubscriberId
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
IF @ErrorFound = 0
BEGIN
	--If the From address is not exactly the same as the To address, and address is not used or email, then just update the To address
		SELECT IntoSubscriberAddressId = IntoSubscriberAddress.SubscriberAddressId
			,FromSubscriberAddressId = FromSubscriberAddress.SubscriberAddressId
			,i=IntoSubscriberAddress.AddressText
			,f=FromSubscriberAddress.AddressText
			,AddressDifferent = CASE WHEN ((ISNULL(IntoSubscriberAddress.AddressText,'') <> ISNULL(FromSubscriberAddress.AddressText,'')
					AND IntoSubscriberAddress.AddressType <> 'Postal')
			   OR (IntoSubscriberAddress.AddressType = 'Postal'
					AND  NOT ( ISNULL(IntoSubscriberAddress.Address1,'') = ISNULL(FromSubscriberAddress.Address1,'')
							AND ISNULL(IntoSubscriberAddress.Address2,'') = ISNULL(FromSubscriberAddress.Address2,'')
							AND ISNULL(IntoSubscriberAddress.Address3,'') = ISNULL(FromSubscriberAddress.Address3,'')
							AND ISNULL(IntoSubscriberAddress.Address4,'') = ISNULL(FromSubscriberAddress.Address4,'')
							AND ISNULL(IntoSubscriberAddress.Town,'') = ISNULL(FromSubscriberAddress.Town,'')
							AND ISNULL(IntoSubscriberAddress.County,'') = ISNULL(FromSubscriberAddress.County,'')
							AND ISNULL(IntoSubscriberAddress.Postcode,'') = ISNULL(FromSubscriberAddress.Postcode,'')
							AND ISNULL(IntoSubscriberAddress.CountryId,0) = ISNULL(FromSubscriberAddress.CountryId,0))
				   )
				) THEN 1 ELSE 0 END
			, IntoAddressUsed = CASE WHEN IntoSubscriberAddress.SubscriberAddressId IS NULL THEN 0 
									ELSE CASE WHEN (IntoSubscriberAddress.AddressType = 'Postal'
--21/10/20	James Woosnam	SIR5099 - Don't count email as always IsUsed as the old emil doesn't need to be made redundant as it can be seen in audit log
												AND IntoSubscriberAddress.SubscriberAddressId IN (SELECT DeliveryAddressId
																							FROM SalesOrderLine
																								INNER JOIN SalesOrder
																								ON SalesOrder.OrderNumber = SalesOrderLine.OrderNumber
																							WHERE SalesOrder.SalesOrderStatus IN ('Confirmed','Partial','RemotePartial')
																							AND ISNULL(SalesOrderLine.IsCancel,0) = 0

																								)
											) THEN 1 ELSE 0 END
									END
		INTO #SubscriberAddress
		FROM SubscriberAddress FromSubscriberAddress 
			LEFT JOIN SubscriberAddress IntoSubscriberAddress
			ON IntoSubscriberAddress.subscriberId =@MergeIntoSubscriberId  
			AND IntoSubscriberAddress.AddressType = FromSubscriberAddress.AddressType
			AND IntoSubscriberAddress.AddressDescription = FromSubscriberAddress.AddressDescription
		WHERE FromSubscriberAddress.SubscriberId = @MergeFromSubscriberId 
		AND FromSubscriberAddress.AddressDescription <>'Deleted'
		--Only copy redudant addresses if they are Postal or Email
		AND (FromSubscriberAddress.AddressDescription <> 'Redundant'
			OR FromSubscriberAddress.AddressType IN ('Postal','Email')
			)
		AND ISNULL(FromSubscriberAddress.AddressText,'') <> ''
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' from address records found' + @LfCr END
END
IF @ErrorFound = 0
BEGIN
	--If the From address is not exactly the same as the To address, and address is not used or email, then just update the To address
	UPDATE SubscriberAddress
		SET  SubscriberAddress.AddressText =FromSubscriberAddress.AddressText
		,SubscriberAddress.Address1 =FromSubscriberAddress.Address1
		,SubscriberAddress.Address2 =FromSubscriberAddress.Address2
		,SubscriberAddress.Address3 =FromSubscriberAddress.Address3
		,SubscriberAddress.Address4 =FromSubscriberAddress.Address4
		,SubscriberAddress.Town =FromSubscriberAddress.Town
		,SubscriberAddress.County =FromSubscriberAddress.County
		,SubscriberAddress.Postcode =FromSubscriberAddress.Postcode
		,SubscriberAddress.CountryId =FromSubscriberAddress.CountryId
		,SubscriberAddress.Notes = LEFT(ISNULL(SubscriberAddress.Notes,'') + 'Updated in merge with SubscriberId:' + cast(FromSubscriberAddress.subscriberId as varchar),255)
--21/10/20	James Woosnam	SIR5099 - Set LastUpdatedDateTime & LastUpdatedByUserId to FromSubscriberAddress
		,SubscriberAddress.LastUpdatedDateTime =  FromSubscriberAddress.LastUpdatedDateTime
		,SubscriberAddress.LastUpdatedByUserId = FromSubscriberAddress.LastUpdatedByUserId
--30/3/11	James Woosnam	SIR2401 - Update UpdateExistingOrdersDeliveryAddress 
		,SubscriberAddress.UpdateExistingOrdersDeliveryAddress = FromSubscriberAddress.UpdateExistingOrdersDeliveryAddress
		FROM SubscriberAddress 
			INNER JOIN #SubscriberAddress
				INNER JOIN SubscriberAddress FromSubscriberAddress
				On FromSubscriberAddress.SubscriberAddressId = #SubscriberAddress.FromSubscriberAddressId 
			ON #SubscriberAddress.IntoSubscriberAddressId = SubscriberAddress.SubscriberAddressId
		WHERE #SubscriberAddress.AddressDifferent = 1
		AND #SubscriberAddress.IntoAddressUsed = 0
--Check we are not overwritting with blank or invalid postal address
		AND (ISNULL(FromSubscriberAddress.AddressText,'') <> ''
			OR (SubscriberAddress.AddressType = 'Postal'
					AND ISNULL(FromSubscriberAddress.Address1,'') <> ''
					AND ISNULL(FromSubscriberAddress.Town,'') <> ''
					AND ISNULL(FromSubscriberAddress.Postcode,'') <> ''
				)
			)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' address records Updated' + @LfCr END
END

IF @ErrorFound = 0
BEGIN
	--If the From address is not exactly the same as the To address then update the To address to "Redundant"
	UPDATE SubscriberAddress
		SET  SubscriberAddress.AddressDescription = 'Redundant'
		,  SubscriberAddress.Notes = LEFT(ISNULL(SubscriberAddress.Notes,'') + 'Made Redundant in merge with SubscriberId:' + cast(FromSubscriberAddress.subscriberId as varchar),255)
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	FROM SubscriberAddress 
		INNER JOIN #SubscriberAddress
			INNER JOIN SubscriberAddress FromSubscriberAddress
			On FromSubscriberAddress.SubscriberAddressId = #SubscriberAddress.FromSubscriberAddressId 
		ON #SubscriberAddress.IntoSubscriberAddressId = SubscriberAddress.SubscriberAddressId
	WHERE #SubscriberAddress.AddressDifferent = 1
	AND #SubscriberAddress.IntoAddressUsed = 1
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' address records made redundant' + @LfCr END
END
IF @ErrorFound = 0
BEGIN
--Now update the From address with Id of To Sub Only where there isn't one already and there is a change
--, if thre was already it will have been made Redundant above.
	UPDATE SubscriberAddress
		SET  SubscriberId = @MergeIntoSubscriberId 
		,  SubscriberAddress.Notes = LEFT(ISNULL(SubscriberAddress.Notes,'') + ' SubscriberId switched back in merge from:' + cast(@MergeFromSubscriberId  as varchar),255)
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	FROM SubscriberAddress 
		INNER JOIN #SubscriberAddress
		ON #SubscriberAddress.FromSubscriberAddressId = SubscriberAddress.SubscriberAddressId
	WHERE ((#SubscriberAddress.AddressDifferent = 1
			AND #SubscriberAddress.IntoAddressUsed = 1
			)
		OR #SubscriberAddress.IntoSubscriberAddressId IS NULL)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' address records merged' + @LfCr END
	UPDATE AuditTableLog
	SET UpdatedRecordFamilyKey = CAST(@MergeIntoSubscriberId AS VARCHAR)
	FROM AuditTableLog a
		INNER JOIN SubscriberAddress 
		ON SubscriberAddress.SubscriberAddressId = a.UpdatedRecordKey 
		INNER JOIN #SubscriberAddress
		ON #SubscriberAddress.FromSubscriberAddressId = SubscriberAddress.SubscriberAddressId
	WHERE ((#SubscriberAddress.AddressDifferent = 1
			AND #SubscriberAddress.IntoAddressUsed = 1
			)
		OR #SubscriberAddress.IntoSubscriberAddressId IS NULL)
	AND a.TableName = 'SubscriberAddress'
	AND a.UpdatedRecordFamilyKey = @MergeFromSubscriberId 
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' AuditTableLog records updated' + @LfCr END
END

IF @ErrorFound = 0
BEGIN
	--Set oldest redundant email address as deleted
	IF EXISTS(SELECT SubscriberId
				FROM SubscriberAddress 
				WHERE SubscriberId =@MergeIntoSubscriberId
				AND AddressType = 'Email'
				AND AddressDescription = 'Redundant'
				GROUP BY SubscriberId
				HAVING COUNT(*) > 2 )
	BEGIN
		UPDATE SubscriberAddress
		SET AddressDescription = 'Deleted'
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
		FROM SubscriberAddress
		WHERE SubscriberId =@MergeIntoSubscriberId
		AND AddressType = 'Email'
		AND AddressDescription = 'Redundant'
		AND LastUpdatedDateTime = (SELECT MIN(LastUpdatedDateTime)
								FROM SubscriberAddress sa
								WHERE sa.SubscriberId =SubscriberAddress.SubscriberId
								AND sa.AddressType = 'Email'
								AND sa.AddressDescription = 'Redundant')
		SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
		SELECT @MergeMessage = @MergeMessage
				+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' redundant email addresses deleted' + @LfCr END
	END
END
IF @ErrorFound = 0
BEGIN
	--13/9/05	James Woosnam	Set dafault address after address merge
	--Only update the default address is it has been mergered from other sub.  If not just output message
	IF EXISTS(SELECT FromSubscriberAddressId
				FROM #SubscriberAddress 
				WHERE FromSubscriberAddressId = (SELECT DefaultPostalAddressId FROM Subscriber WHERE SubscriberId = @MergeFromSubscriberId)
    			AND ((#SubscriberAddress.AddressDifferent = 1
						AND #SubscriberAddress.IntoAddressUsed = 1)
					OR (#SubscriberAddress.IntoSubscriberAddressId IS NULL
						  )
					)
			)
	BEGIN
	--If here the old default address has been merged so update default in merged into
		EXEC sp114MergeSubscriberField @FieldName = 'DefaultPostalAddressId',@MergeIntoSubscriberId = @MergeIntoSubscriberId,@MergeFromSubscriberId = @MergeFromSubscriberId,@MergeMessage = @MergeMessage OUTPUT,@ErrorFound = @ErrorFound OUTPUT,@ErrorMessage = @ErrorMessage OUTPUT
	END
	ELSE
	BEGIN
		SELECT @MergeMessage = @MergeMessage
				+ ' DefaulPostalAddress NOT updated as address not moved -  **Check**' + @LfCr 
	End
END

--30/3/11	James Woosnam	SIR2401 - If UpdateExistingOrdersDeliveryAddress set then update open sales order delivery addresses
IF @ErrorFound = 0
BEGIN
	UPDATE SalesOrderLine 
	SET DeliveryAddressId = sa.SubscriberAddressId 
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	FROM SalesOrderLine sol
		INNER JOIN SubscriberAddress sa
		ON sa.SubscriberId = sol.SubscriberId 
		INNER JOIN SalesOrder so
		ON so.OrderNumber = sol.OrderNumber 
		AND so.SalesOrderStatus IN  ('Confirmed','Partial','RemotePartial')
	WHERE sa.SubscriberId = @MergeIntoSubscriberId 
	AND sa.UpdateExistingOrdersDeliveryAddress =1
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' SalesOrderLines delivery address Updated due to UpdateExistingOrdersDeliveryAddress' + @LfCr END
END	
--30/3/11	James Woosnam	SIR2401 - If UpdateExistingOrdersDeliveryAddress set then update Subscriber Default address
IF @ErrorFound = 0
BEGIN
	UPDATE Subscriber 
	SET DefaultPostalAddressId  = sa.SubscriberAddressId 
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	FROM Subscriber s
		INNER JOIN SubscriberAddress sa
		ON sa.SubscriberId = s.SubscriberId 
	WHERE sa.SubscriberId = @MergeIntoSubscriberId 
	AND sa.UpdateExistingOrdersDeliveryAddress =1
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE ' Subscriber DefaultPostalAddressId Updated due to UpdateExistingOrdersDeliveryAddress' + @LfCr END
END	
--30/3/11	James Woosnam	SIR2401 - Set UpdateExistingOrdersDeliveryAddress=0
IF @ErrorFound = 0
BEGIN
	UPDATE SubscriberAddress  
	SET UpdateExistingOrdersDeliveryAddress  = 0
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	WHERE SubscriberId = @MergeIntoSubscriberId 
	AND UpdateExistingOrdersDeliveryAddress =1
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END	

IF @ErrorFound = 0
BEGIN
	DECLARE @ParentSubscriberId INT

	DECLARE curAffiliates CURSOR FORWARD_ONLY STATIC READ_ONLY	FOR 
	SELECT MergeIntoSubscriber.ParentSubscriberId
	FROM SubscriberAffiliate MergeIntoSubscriber 
		INNER JOIN vw111SubscriberAffiliate MergeFromSubscriber
		ON MergeFromSubscriber.ChildSubscriberId = @MergeFromSubscriberId  
		AND MergeFromSubscriber.ParentSubscriberId = MergeIntoSubscriber.ParentSubscriberId
	WHERE MergeIntoSubscriber.ChildSubscriberId = @MergeIntoSubscriberId 
	AND (MergeIntoSubscriber.StartDate <> MergeFromSubscriber.StartDate
		OR MergeIntoSubscriber.EndDate <> MergeFromSubscriber.EndDate
		OR (ISNULL(MergeFromSubscriber.SubscriberCategory,'') <> ''
						AND ISNULL(MergeIntoSubscriber.SubscriberCategory,'') <> ISNULL(MergeFromSubscriber.SubscriberCategory,'')
			)
		OR (ISNULL(MergeFromSubscriber.AffiliateReferenceID,'') <> ''
						AND ISNULL(MergeIntoSubscriber.AffiliateReferenceID,'') <> ISNULL(MergeFromSubscriber.AffiliateReferenceID,'')
			)
		)

	OPEN curAffiliates
	FETCH NEXT FROM curAffiliates INTO 
		@ParentSubscriberId

	WHILE @@FETCH_STATUS = 0 AND @ErrorFound = 0
	BEGIN
		SELECT @MergeMessage = @MergeMessage 
							+ 'Affilate Updates for Parent:' + CAST(@ParentSubscriberId as VARCHAR) + @LfCr
		UPDATE SubscriberAffiliate
		SET  StartDate = CASE WHEN MergeIntoSubscriber.StartDate < MergeFromSubscriber.StartDate 
								THEN MergeIntoSubscriber.StartDate 
							ELSE MergeFromSubscriber.StartDate END
			,EndDate = CASE WHEN MergeIntoSubscriber.EndDate > MergeFromSubscriber.EndDate 
								THEN MergeIntoSubscriber.EndDate 
							ELSE MergeFromSubscriber.EndDate END
			,SubscriberCategory = CASE WHEN ISNULL(MergeFromSubscriber.SubscriberCategory,'') <> ''
										AND MergeFromSubscriber.SubscriberCategory <> MergeIntoSubscriber.SubscriberCategory
									THEN MergeFromSubscriber.SubscriberCategory 
							ELSE MergeIntoSubscriber.SubscriberCategory END
			,AffiliateReferenceID = CASE WHEN ISNULL(MergeFromSubscriber.AffiliateReferenceID,'') <> ''
										AND MergeFromSubscriber.AffiliateReferenceID <> MergeIntoSubscriber.AffiliateReferenceID
									THEN MergeFromSubscriber.AffiliateReferenceID 
							ELSE MergeIntoSubscriber.AffiliateReferenceID END
			,@MergeMessage = @MergeMessage 
			+	CASE WHEN MergeIntoSubscriber.StartDate > MergeFromSubscriber.StartDate 
				THEN  ' - StartDate updated to:'  + CONVERT(VARCHAR,MergeFromSubscriber.StartDate,13) + @LfCr ELSE '' END
			+	CASE WHEN MergeIntoSubscriber.EndDate < MergeFromSubscriber.EndDate 
				THEN  ' - EndDate updated to:'  + CONVERT(VARCHAR,MergeFromSubscriber.StartDate,13) + @LfCr ELSE '' END
			+	CASE WHEN ISNULL(MergeFromSubscriber.SubscriberCategory,'') <> ''
						AND ISNULL(MergeIntoSubscriber.SubscriberCategory,'') <> ISNULL(MergeFromSubscriber.SubscriberCategory,'') 
				THEN  ' - SubscriberCategory updated to:'  + MergeFromSubscriber.SubscriberCategory + @LfCr ELSE '' END
			+	CASE WHEN ISNULL(MergeFromSubscriber.AffiliateReferenceID,'') <> ''
						AND ISNULL(MergeIntoSubscriber.AffiliateReferenceID,'') <> ISNULL(MergeFromSubscriber.AffiliateReferenceID,'')
				THEN  ' - AffiliateReferenceID updated to:'  + MergeFromSubscriber.AffiliateReferenceID + @LfCr ELSE '' END
			,LastUpdatedDateTime = GETDATE()
			,LastUpdatedByUserId = @UserName
		FROM SubscriberAffiliate MergeIntoSubscriber 
			INNER JOIN vw111SubscriberAffiliate MergeFromSubscriber
			ON MergeFromSubscriber.ChildSubscriberId = @MergeFromSubscriberId  
			AND MergeFromSubscriber.ParentSubscriberId = MergeIntoSubscriber.ParentSubscriberId
		WHERE MergeIntoSubscriber.ChildSubscriberId = @MergeIntoSubscriberId 
		AND MergeIntoSubscriber.ParentSubscriberId = @ParentSubscriberId 
		SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT

		FETCH NEXT FROM curAffiliates INTO 
			@ParentSubscriberId
	END
	CLOSE curAffiliates
	DEALLOCATE curAffiliates
END
	

IF @ErrorFound = 0
BEGIN
	UPDATE SubscriberAffiliate
		SET  ChildSubscriberId = @MergeIntoSubscriberId 
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	FROM SubscriberAffiliate MergeFromSubscriber 
		LEFT JOIN vw111SubscriberAffiliate MergeIntoSubscriber
		ON MergeIntoSubscriber.ChildSubscriberId = @MergeIntoSubscriberId  
		AND MergeIntoSubscriber.ParentSubscriberId = MergeFromSubscriber.ParentSubscriberId
	WHERE MergeFromSubscriber.ChildSubscriberId = @MergeFromSubscriberId 
	AND MergeFromSubscriber.ParentSubscriberId <> @MergeIntoSubscriberId 
  	AND MergeIntoSubscriber.ParentSubscriberId Is Null
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' parent Affiliations moved to ' + CAST(@MergeIntoSubscriberId AS VARCHAR) + @LfCr END
END

--19/6/20	James Woosnam	SIR5085 - Copy missing child affiliates into new parent
IF @ErrorFound = 0
BEGIN
	UPDATE SubscriberAffiliate
		SET  ParentSubscriberID = @MergeIntoSubscriberId 
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	FROM SubscriberAffiliate mfA 
		LEFT JOIN vw111SubscriberAffiliate  mtA
		ON mtA.ParentSubscriberID = @MergeIntoSubscriberId  
		AND mta.ChildSubscriberID = mfa.ChildSubscriberID
	WHERE mfA.ParentSubscriberID = @MergeFromSubscriberId 
	AND mfA.EndDate > getdate()
	AND mtA.ParentSubscriberId Is Null
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' child Affiliates moved to ' + CAST(@MergeIntoSubscriberId AS VARCHAR) + @LfCr END
END


IF @ErrorFound = 0
BEGIN
	UPDATE CompanyAccount
		SET  SubscriberId = @MergeIntoSubscriberId 
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	FROM CompanyAccount ca1
	WHERE SubscriberId = @MergeFromSubscriberId 
  	AND Not EXISTS (SELECT CompanyId 
							FROM CompanyAccount ca2 
						 WHERE ca2.CompanyId = ca1.companyId 
						 AND ca2.SubscriberId=@MergeIntoSubscriberId 
						 )
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' CompanyAccount records merged'  + @LfCr END
END
IF @ErrorFound = 0
BEGIN
	--Update the billing address id to the one on the current subscriber								
	UPDATE CompanyAccount
		SET  BillingAddressId = Subscriber.DefaultPostalAddressId  
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
 	FROM CompanyAccount ca1
		INNER JOIN Subscriber
		ON  Subscriber.SubscriberId = ca1.SubscriberId
	WHERE ca1.SubscriberId = @MergeIntoSubscriberId 
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' CompanyAccount.BillingAddressId Updated ' + @LfCr END
END
IF @ErrorFound = 0
BEGIN
	UPDATE SalesOrder
		SET  SubscriberId = @MergeIntoSubscriberId 
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	WHERE SubscriberId = @MergeFromSubscriberId 
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' SalesOrder records merged' + @LfCr END
END
IF @ErrorFound = 0
BEGIN
	UPDATE SalesOrderLine
		SET  SubscriberId = @MergeIntoSubscriberId 
--Repoint the delivery address if it has not been moved.
			,DeliveryAddressId = CASE WHEN #SubscriberAddress.IntoSubscriberAddressId IS NOT NULL 
										Then #SubscriberAddress.IntoSubscriberAddressId
								ELSE DeliveryAddressId END
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	FROM SalesOrderLine
		LEFT JOIN #SubscriberAddress
		ON #SubscriberAddress.FromSubscriberAddressId = SalesOrderLine.DeliveryAddressId
		AND #SubscriberAddress.IntoAddressUsed = 0
		AND #SubscriberAddress.IntoSubscriberAddressId Is NOT NULL
	WHERE SubscriberId = @MergeFromSubscriberId 
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' SalesOrderLine records merged' + @LfCr END
END
IF @ErrorFound = 0
BEGIN
	UPDATE Cashbook
		SET  SubscriberId = @MergeIntoSubscriberId 
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	WHERE SubscriberId = @MergeFromSubscriberId 
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' Cashbook records merged' + @LfCr END
END
--18/11/08	James Woosnam	SIR1615 - Update SubscriberId in RenewalReminderLog
IF @ErrorFound = 0
BEGIN
	UPDATE RenewalReminderLog
		SET  SubscriberId = @MergeIntoSubscriberId 
	WHERE SubscriberId = @MergeFromSubscriberId 
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE CAST(@ROWCOUNT as varchar) + ' RenewalReminderLog records merged' + @LfCr END
END
--10/1/20	James Woosnam	SIR4977 - If Into sub linked to user, make user InActive and unlink
IF @ErrorFound = 0
BEGIN
	DECLARE @ExistingRemoteUserId INT = (SELECT UserId FROM RemoteUserRights WHERE RightsToId = @MergeIntoSubscriberId )
	DELETE FROM RemoteUserRights WHERE UserId = @ExistingRemoteUserId
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	IF @ErrorFound = 0
	BEGIN
		UPDATE RemoteUser 
		SET UserName = LEFT(UserName + ' **Made InActive in merge**',200)
			, EmailAddress = LEFT(ISNULL(EmailAddress,'') + ' **Made InActive in merge**',200)
			, UserStatus = 'InActive'
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
		WHERE UserId = @ExistingRemoteUserId 
		SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
		SELECT @MergeMessage = @MergeMessage
				+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE ' UserId:' + cAST(@ExistingRemoteUserId AS VARCHAR) +  ' made redundant and unlinked from SID:' + cAST(@MergeIntoSubscriberId AS VARCHAR) + @LfCr END
	END
END
--10/1/20	James Woosnam	SIR4977 - Move RemoteUser to @MergeIntoSubscriberId
IF @ErrorFound = 0
BEGIN
	DECLARE @RemoteUserId INT = (SELECT UserId FROM RemoteUserRights WHERE RightsToId = @MergeFromSubscriberId )
	UPDATE RemoteUserRights
		SET  RightsToId = @MergeIntoSubscriberId 
		,LastUpdatedDateTime = GETDATE()
		,LastUpdatedByUserId = @UserName
	WHERE UserId = @RemoteUserId 
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	SELECT @MergeMessage = @MergeMessage
			+ CASE @ROWCOUNT WHEN 0 THEN '' ELSE ' UserId:' + cAST(@RemoteUserId AS VARCHAR) + ' linked to SID:' + cAST(@MergeIntoSubscriberId AS VARCHAR) + @LfCr END
END
IF @ErrorFound = 0
BEGIN
--17/5/2010		James Woosnam	Put AuditLog Insert directly in code as call to sp was failing maybe sql 2008 issue
--5/12/19		James Woosnam	SIR4769 - For GDPR user name no longer recorded on audit log
	INSERT INTO Pads_Logs..AuditLog
			( TableName
			, AuditDate
			, UpdatedByUserId
			, UpdatedByUserName
			, UpdatedRecordKey
			, ModificationType
			, [Description]
			, [DatabaseName]
			)
		VALUES ( 'Subscriber'
			,GetDate()
			,@UserId 
			,@UserName
			,@MergeFromSubscriberId
			,'MergeFrom'
			,@MergeMessage
			,@DBName
			)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
IF @ErrorFound = 0
BEGIN
--17/5/2010		James Woosnam	Put AuditLog Insert directly in code as call to sp was failing maybe sql 2008 issue
	INSERT INTO Pads_Logs..AuditLog
			( TableName
			, AuditDate
			, UpdatedByUserId
			, UpdatedByUserName
			, UpdatedRecordKey
			, ModificationType
			, [Description]
			, [DatabaseName]
			)
		VALUES ( 'Subscriber'
			,GetDate()
			,@UserId 
			,@UserName
			,@MergeIntoSubscriberId
			,'MergeInto'
			,@MergeMessage
			,@DBName
			)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END	


IF @TranStarted = 1
BEGIN
	IF @ErrorFound = 0
	BEGIN
		COMMIT TRAN
	END
	ELSE
	BEGIN
		ROLLBACK TRAN
	END
END
IF @ErrorFound <> 0
BEGIN
	Set @ErrorMessage = 'Error:' + Cast(@ErrorFound as varchar) 
				+ ' ReturnCode:'  + Cast(@ReturnCode as varchar) + @LfCr
				+ @MergeMessage
	PRINT @ErrorMessage
END
If @ReturnCode = 0 
	--If an error been found with no return code then set the returncode to the ErrorCode
	SET @ReturnCode = @ErrorFound

RETurn (@ReturnCode)	

GO
GRANT EXECUTE ON sp113MergeSubscribers TO PaDSSQLServerUser