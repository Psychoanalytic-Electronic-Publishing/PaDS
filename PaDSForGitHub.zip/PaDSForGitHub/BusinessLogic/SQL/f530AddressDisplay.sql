
ALTER FUNCTION f530SubscriberAddressDisplay ( @SubscriberAddressId INT , @Delimiter VARCHAR(15) )
RETURNS Varchar(2000)
AS
BEGIN
DECLARE @DisplayAddress VARCHAR(2000)
If @Delimiter = 'MultiLine' 
  SET @Delimiter = Char(13)
If @Delimiter = 'MultiLineExcel' 
  SET @Delimiter = Char(10)
If @Delimiter = 'SingleLine'
    SET @Delimiter = ','
If @Delimiter = 'HTMLLine'
  SET @Delimiter = '<BR>'

SELECT	@DisplayAddress = CASE AddressType
	 WHEN 'Postal' THEN
		CASE 	(CASE IsNull( Address1 , '' )  WHEN '' THEN '' ELSE Address1 + @Delimiter END 
			+ CASE IsNull( Address2 , '' )  WHEN '' THEN '' ELSE Address2 + @Delimiter END 
			+ CASE IsNull( Address3 , '' )  WHEN '' THEN '' ELSE Address3 + @Delimiter END 
			+ CASE IsNull( Address4 , '' )  WHEN '' THEN '' ELSE Address4 + @Delimiter END 
			+ CASE IsNull( Town , '' )  WHEN '' THEN '' ELSE Town + @Delimiter END 
			+ CASE IsNull( County , '' )  WHEN '' THEN '' ELSE County + @Delimiter END 
			+ CASE IsNull( Postcode , '' )  WHEN '' THEN '' ELSE Postcode + @Delimiter END 
			+ CASE IsNull( CountryName , '' )  WHEN '' THEN '' ELSE CountryName + @Delimiter END 
 			) WHEN '' THEN ''
		ELSE
		    (	LEFT(
				CASE IsNull( Address1 , '' )  WHEN '' THEN '' ELSE Address1 + @Delimiter END 
				+ CASE IsNull( Address2 , '' )  WHEN '' THEN '' ELSE Address2 + @Delimiter END 
				+ CASE IsNull( Address3 , '' )  WHEN '' THEN '' ELSE Address3 + @Delimiter END 
				+ CASE IsNull( Address4 , '' )  WHEN '' THEN '' ELSE Address4 + @Delimiter END 
				+ CASE IsNull( Town , '' )  WHEN '' THEN '' ELSE Town + @Delimiter END 
				+ CASE IsNull( County , '' )  WHEN '' THEN '' ELSE County + @Delimiter END 
				+ CASE IsNull( Postcode , '' )  WHEN '' THEN '' ELSE Postcode + @Delimiter END 
				+ CASE IsNull( CountryName , '' )  WHEN '' THEN '' ELSE CountryName + @Delimiter END 
			, LEN(
				CASE IsNull( Address1 , '' )  WHEN '' THEN '' ELSE Address1 + @Delimiter END 
				+ CASE IsNull( Address2 , '' )  WHEN '' THEN '' ELSE Address2 + @Delimiter END 
				+ CASE IsNull( Address3 , '' )  WHEN '' THEN '' ELSE Address3 + @Delimiter END 
				+ CASE IsNull( Address4 , '' )  WHEN '' THEN '' ELSE Address4 + @Delimiter END 
				+ CASE IsNull( Town , '' )  WHEN '' THEN '' ELSE Town + @Delimiter END 
				+ CASE IsNull( County , '' )  WHEN '' THEN '' ELSE County + @Delimiter END 
				+ CASE IsNull( Postcode , '' )  WHEN '' THEN '' ELSE Postcode + @Delimiter END 
				+ CASE IsNull( CountryName , '' )  WHEN '' THEN '' ELSE CountryName + @Delimiter END 
			      ) - 1 
			     )
		     )
		END
	Else
		AddressText
	END 
FROM SubscriberAddress
	LEFT JOIN Country
	ON Country.CountryId = SubscriberAddress.CountryId
Where SubscriberAddressId = @SubscriberAddressId

RETURN ( @DisplayAddress)

END


