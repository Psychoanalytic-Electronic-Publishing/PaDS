if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp484SubscriberImportAddressMaint') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp484SubscriberImportAddressMaint
GO
CREATE PROCEDURE sp484SubscriberImportAddressMaint(
						@SubscriberImportId INT
						,@SubscriberId INT
						,@AddressType varchar(20)
						,@AddressDescription varchar(20)
						,@AddressText varchar(255)  --Non postal only
						,@UserName varchar(50)
						,@ReturnCode INT OUTPUT
						,@ErrorMessage varchar(200) OUTPUT
				
									)
AS
--15/4/08	James Woosnam	SIR1424 - Fix town/county typo
--5/4/08	James Woosnam	SIR1517 - For non postal addresses only overwrite if the imported value is not blank.
--9/4/08	James Woosnam	SIR1517 - Make some addresses redundant
--22/04/09  Julian Gates    SIR1831 - Changed code below to only update Address details if @AddressText <> ''

DECLARE @ErrorCode INT
DECLARE @ErrorFound INT
DECLARE @ProcName varchar(50)
DECLARE @ROWCOUNT INT
DECLARE @Message VARCHAR(2000)
DECLARE @Today DATETIME
SET @ReturnCode = 0
SET @ErrorFound = 0
SET @ProcName = 'sp484SubscriberImportAddressMaint'

SET @Today = CAST(CONVERT(varchar(11),GETDATE(),13) as DATETIME)

DECLARE @CountryId INT
IF @ErrorFound = 0
BEGIN
	SELECT @AddressText = LEFT( 
			CASE @AddressType 
			WHEN 'Postal' THEN	
				CASE WHEN ISNULL(Address1,'') <> '' THEN Address1 + ', ' ELSE '' END
				+	CASE WHEN ISNULL(Address2,'') <> '' THEN Address2 + ', '  ELSE '' END
				+	CASE WHEN ISNULL(Address3,'') <> '' THEN Address3 + ', '  ELSE '' END
				+	CASE WHEN ISNULL(Address4,'') <> '' THEN Address4 + ', '  ELSE '' END
				+	CASE WHEN ISNULL(Town,'') <> '' THEN Town + ', '  ELSE '' END
				+	CASE WHEN ISNULL(County,'') <> '' THEN County + ', '  ELSE '' END
				+	CASE WHEN ISNULL(PostCode,'') <> '' THEN PostCode + ', '  ELSE '' END
				+	CASE WHEN ISNULL(Country.CountryName,'') <> '' THEN Country.CountryName   ELSE '' END 
			ELSE @AddressText END
					,255)
			,@CountryId = Country.CountryId
	FROM tmpSubscriberImport
		LEFT JOIN Country
		On Country.CountryName = tmpSubscriberImport.CountryName
	WHERE tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END

--22/04/09  Julian Gates  SIR 1831 Changed code below to only update Address details if @AddressText <> ''
IF ISNULL(@AddressText,'') <> ''
BEGIN
	--9/4/08	James Woosnam	SIR1517 - Make some addresses redundant
	--In some cases mark the current address as redundant rather than updating it
			--email address
			--Postal Address and used on an incomplete order. 
	IF @ErrorFound = 0
	BEGIN
		UPDATE SubscriberAddress
		SET AddressDescription = 'Redundant'
			,  SubscriberAddress.Notes = LEFT(ISNULL(SubscriberAddress.Notes,'') + char(10) + CHAR(13) + 'Made Redundant by Import',255)
		FROM SubscriberAddress
		WHERE SubscriberId = @SubscriberId
		AND AddressType = @AddressType
		AND AddressDescription = @AddressDescription
		AND AddressText <> @AddressText
		AND (@AddressType = 'Email'
			OR (@AddressType = 'Postal'
				AND SubscriberAddress.SubscriberAddressId IN (SELECT DeliveryAddressId
															FROM SalesOrderLine
																INNER JOIN SalesOrder
																ON SalesOrder.OrderNumber = SalesOrderLine.OrderNumber
															WHERE SalesOrder.SalesOrderStatus IN ('Confirmed','Partial','RemotePartial')
															AND ISNULL(SalesOrderLine.IsCancel,0) = 0
															AND SalesOrderLine.SubscriberId = SubscriberAddress.SubscriberId
																)
				)
			)

		SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	END


	DECLARE @SubscriberAddressId INT
	SET @SubscriberAddressId = 0
	IF @ErrorFound = 0
	BEGIN
		SELECT @SubscriberAddressId = SubscriberAddressId
		FROM SubscriberAddress
		WHERE SubscriberId = @SubscriberId
		AND AddressType = @AddressType
		AND AddressDescription = @AddressDescription
		SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	END

	IF @SubscriberAddressId = 0
	AND @ErrorFound = 0
	BEGIN
		Exec dbo.sp005GetNextTableNumber 'SubscriberAddress',@SubscriberAddressId OUTPUT
		IF @AddressType = 'Postal'
		BEGIN
			INSERT INTO SubscriberAddress
				(SubscriberAddressId
				,SubscriberId
				,AddressType
				,AddressDescription
				,AddressText
				,CountryId
				,Address1
				,Address2
				,Address3
				,Address4
				,Town
				,County
				,PostCode
				,CreatedDateTime
				,CreatedByUserId
				,LastUpdatedDateTime
				,LastUpdatedByUserId )
			SELECT @SubscriberAddressId
				,@SubscriberId
				,@AddressType
				,@AddressDescription
				,AddressText = LEFT(
					CASE WHEN ISNULL(Address1,'') <> '' THEN Address1 + ', ' ELSE '' END
					+	CASE WHEN ISNULL(Address2,'') <> '' THEN Address2 + ', '  ELSE '' END
					+	CASE WHEN ISNULL(Address3,'') <> '' THEN Address3 + ', '  ELSE '' END
					+	CASE WHEN ISNULL(Address4,'') <> '' THEN Address4 + ', '  ELSE '' END
					+	CASE WHEN ISNULL(Town,'') <> '' THEN Town + ', '  ELSE '' END
					+	CASE WHEN ISNULL(County,'') <> '' THEN County + ', '  ELSE '' END
					+	CASE WHEN ISNULL(PostCode,'') <> '' THEN PostCode + ', '  ELSE '' END
					+	CASE WHEN ISNULL(CountryName,'') <> '' THEN CountryName   ELSE '' END ,255)
				,@CountryId
				,Address1
				,Address2
				,Address3
				,Address4
				,Town
				,County
				,PostCode
				,CreatedDateTime = GETDATE()
				,CreatedByUserId = @UserName
				,LastUpdatedDateTime = GetDate()
				,LastUpdatedByUserId = @UserName
			FROM tmpSubscriberImport
			WHERE tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
			SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
		END
		ELSE --non postal
		BEGIN	
			INSERT INTO SubscriberAddress
				(SubscriberAddressId
				,SubscriberId
				,AddressType
				,AddressDescription
				,AddressText
				,CountryId
				,CreatedDateTime
				,CreatedByUserId
				,LastUpdatedDateTime
				,LastUpdatedByUserId )
			VALUES ( @SubscriberAddressId
				,@SubscriberId
				,@AddressType
				,@AddressDescription
				,@AddressText
				,@CountryId 
				,GETDATE()
				,@UserName
				,GetDate()
				,@UserName
					)
			SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
		END
	END
	ELSE
	--Address already exisits
	BEGIN
		IF @AddressType = 'Postal'
		BEGIN
			UPDATE SubscriberAddress
			SET 
				AddressText = @AddressText
				,CountryId = @CountryId
				,Address1 = ISNULL(tmpSubscriberImport.Address1,'')
				,Address2 = ISNULL(tmpSubscriberImport.Address2,'')
				,Address3 = ISNULL(tmpSubscriberImport.Address3,'')
				,Address4 = ISNULL(tmpSubscriberImport.Address4,'')
				,Town = ISNULL(tmpSubscriberImport.Town,'')
	--15/4/08	James Woosnam	SIR1424 - Fix town/county typo
				,County = ISNULL(tmpSubscriberImport.County,'')
				,PostCode = ISNULL(tmpSubscriberImport.PostCode,'')
				,LastUpdatedDateTime = GETDATE()
				,LastUpdatedByUserId = @UserName
			FROM SubscriberAddress 
				INNER JOIN tmpSubscriberImport
				ON tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
			WHERE SubscriberAddressId = @SubscriberAddressId
			SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
		END
		ELSE --non postal
		BEGIN
			UPDATE SubscriberAddress
			SET 
	--5/4/08	James Woosnam	SIR1517 - For non postal addresses only overwrite if the imported value is not blank.
				AddressText = CASE WHEN ISNULL(@AddressText,'') = '' THEN AddressText ELSE @AddressText END
				,CountryId = @CountryId
				,LastUpdatedDateTime = GETDATE()
				,LastUpdatedByUserId = @UserName
			FROM SubscriberAddress 
			WHERE SubscriberAddressId = @SubscriberAddressId
			SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
		END
	END

	--Update default postal address if it has been made redundant.
	IF @ErrorFound = 0
	AND @AddressType = 'Postal'
	BEGIN
		IF EXiSTS(SELECT SubscriberAddressId
					FROM SubscriberAddress 
					WHERE SubscriberAddressId = @SubscriberAddressId
					AND SubscriberAddressId = (SELECT DefaultPostalAddressId 
												FROM Subscriber
												WHERE Subscriber.SubscriberId = SubscriberAddress.SubscriberId)
					AND SubscriberAddress.AddressDescription = 'Redundant')
		BEGIN
			UPDATE Subscriber
			SET DefaultPostalAddressId = @SubscriberAddressId
			WHERE Subscriber.SubscriberId = @SubscriberId
			SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
		END
	END

END

If @ReturnCode = 0 
	--If an error been found with no return code then set the returncode to the ErrorCode
	SET @ReturnCode = @ErrorFound

RETURN (@ReturnCode)
