if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp235WebProducts') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp235WebProducts
Go
CREATE PROCEDURE sp235WebProducts
					@CompanyId Int = NULL
					,@SubscriberId INT = 0 
					,@ShowWhereNoRates BIT = 0
					,@NewUserRates BIT = 0
AS
--10/11/06 JGates  Add TermsAndConditionsFileName as modification
--8/11/06	James Woosnam	Need to add all possible rates before selecting the cheapest
--13/11/06 James Woosnam  Add Group By to eliminate duplicate rate IDs
--14/11/06	James Woosnam	Join to MIN rate in ProductGroupingName to allow only 1 CD product to show
--14/11/06	James Woosnam	Join to Previous orders on ProductGroupingName to allow for 
--14/11/06	James Woosnam	Use OnePerSubscriberFlag to only show some products if not ordered.
--20/11/06	James Woosnam	Use product.CheckAgainstOrderType to fitler orders
--21/11/06	James Woosnam	Allow "RemotePartial" orders that have payment
--22/11/06	James Woosnam	Change the product rate lookup to use CheckAgainstOrderType from qualifying product
--10/4/07	James Woosnam	Use RecurringSubscriptionEndDate SIRs 129, 1013
--02/8/07       Julian Gates    Add CurrentSubscriptionOrderNumber to be used to determine if SalesOrder is Individual or Block order SIR 1131
--19/11/07	James Woosnam	SIR1395 - Use OrderNumber to find last order for product rather than RecurringEndDate as this can sometimes be null.	
--07/03/08	James Woosnam	SIR1452 - Get Affiliate Rates if subscriber is affiliated with group that has been given special rates
--									  Also rework product rate code to make simplier						
--08/4/08	James Woosnam	Join on ProductRateId
--24/01/08	James Woosnam	SIR1615 - Use Parameter FirstReminderDaysBefore to dictate when to show expiring orders
--24/11/08	James Woosnam	SIR1615- Ensure the CurrentSubscriptionOrderNumber is populated where possible
--21/7/09	James Woosnam	Ignore Null RateIds in specials
--11/3/11	James Wosnam	SIR2349 - Exclude MACweb from sales order lines considered
--18/3/11	James Woosnam	Find products for base sub as well if the passed sub is the proposed one	
--21/6/11	James Woosnam	SIR2445 - If there is a current subscription to any recurring PEPWeb product then remove any other pepweb products									
--19/7/11	James Woosnam	Put output into temp table so we can filter out orphan sub products
--9/2/15	James Woosnam	SIR3724 - Constrain rates by DeliveryArea from Subscribers primary country or the ALL rate if no match
--2/4/18	James Woosnam	SIR4600 - Add a sort order to the final query
--14/12/18	James Woosnam	SIR4752 - Get the CurrentSubscriptionOrderNumber with a max grouped on ProductGroupingName
--20/11/19	James Woosnam	SIR4949 - Use companies based on subscribers associated companies
--22/11/19	James Woosnam	SIR4949 - Add AssociatedWithProductCode
--10/12/19	James Woosnam	SIR4975 - Special hard coding to delete special PEPweb qualifying rates if the sub got a JV100 product.  Only works for JV101 and Rate D.
--15/1/20	James Woosnam	SIR4970 - Output for all Active companies if SubscriberId passed
--7/2/20	James			Delete any products in list which are associated with a product that is no longer in the list
--1/9/20	James Woosnam	SIR5118 - don't delete if product has an qualifying product of its parent associated product,
--12/7/21	Julian Gates	SIR5281 - Add DisplayProductName field to Products.
SET NOCOUNT ON
SET ARITHIGNORE ON
	CREATE TABLE #Subscriber(
		SubscriberId INT NOT NULL
		,SubscriberCategory varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
		,AccountType varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
		,CountryDeliveryArea varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
		)
	--20/11/19	James Woosnam	SIR4949 - Use companies based on subscribers associated companies
	CREATE TABLE #SubsCompanies ( CompanyId INT NOT NULL)
	IF @CompanyId IS NULL
	OR (@CompanyId IS NULL AND @SubscriberId <> 0 )
--15/1/20	James Woosnam	SIR4970 - Output for all Active companies if SubscriberId passed
		INSERT INTO #SubsCompanies
		SELECT DISTINCT c.CompanyId 
		FROM Company c
		WHERE c.CompanyStatus = 'Active'
	ELSE
		INSERT INTO #SubsCompanies VALUES(@CompanyId)

	IF @SubscriberId <> 0 
	BEGIN

		INSERT INTO #Subscriber
		SELECT Subscriber.SubscriberId
			,SubscriberAffiliate = ISNULL(SubscriberAffiliate.SubscriberCategory,'Ordinary')
			,AccountType = ISNULL(CompanyAccount.AccountType,'Individual')	
			,CountryDeliveryArea = ISNULL(dda.DespatchDeliveryArea ,'All')
		FROM Subscriber
			INNER JOIN Company
			On Company.CompanyId  IN (SELECT CompanyId FROM #SubsCompanies)
			LEFT JOIN DespatchDeliveryArea dda
			ON dda.CompanyId = Company.CompanyId 
			AND dda.CountryId = Subscriber.PrimaryCountryId 
			LEFT JOIN SubscriberAffiliate
			On SubscriberAffiliate.ChildSubscriberId = Subscriber.SubscriberId
			AND SubscriberAffiliate.ParentSubscriberId = Company.GroupParentSubscriberId
			LEFT JOIN CompanyAccount
			On CompanyAccount.CompanyId = Company.CompanyId
			AND CompanyAccount.SubscriberId = Subscriber.SubscriberId
			LEFT JOIN Country 
			On Country.CountryID = Subscriber.PrimaryCountryId 
		WHERE Subscriber.Subscriberid = @SubscriberId
--18/3/11	James Woosnam	Find products for base sub as well if the passed sub is the proposed one	
		OR  Subscriber.Subscriberid = (SELECT s1.UpdateToSubscriberId FROM Subscriber s1 WHERE  s1.SubscriberId = @SubscriberId AND s1.SubscriberStatus = 'Proposed')
	END
	ELSE
	BEGIN
		INSERT INTO #Subscriber
		SELECT SubscriberId = @SubscriberId
				,SubscriberCategory
				,AccountType = 'Individual'
		FROM (SELECT SubscriberCategory = 'Ordinary'
				UNION
			  SELECT SubscriberCategory = 'Student') Subs

	END	
	
	CREATE TABLE #SalesOrderLines(
		OrderNumber INT Null
		,SubscriberId INT NULL
		,AmountGross MONEY NULL
		,SalesOrderStatus varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
		,OrderType varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
		,TotalCashbookAmount MONEY NULL
		,RecurringSubscriptionStartDate DateTime NULL
		,RecurringSubscriptionEndDate DateTime NULL
		,ProductCode varchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
		,ProductGroupingName varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
		)

	INSERT INTO #SalesOrderLines
	SELECT
		SalesOrderLine.OrderNumber
		,SalesOrderLine.SubscriberId
		,SalesOrder.AmountGross
		,SalesOrder.SalesOrderStatus
		,SalesOrder.OrderType
		,TotalCashbookAmount = (SELECT SUM(Amount) 
									FROM Cashbook 
									WHERE OrderNumber = SalesOrderLine.OrderNumber 
									AND CashbookStatus = 'Confirmed')
		,RecurringSubscriptionStartDate
		,RecurringSubscriptionEndDate
		,OrderedProduct.ProductCode
		,OrderedProduct.ProductGroupingName
	FROM  SalesOrderLine
			INNER JOIN Product OrderedProduct
			On OrderedProduct.ProductCode=  SalesOrderLine.ProductCode
			INNER JOIN SalesOrder
			On SalesOrder.OrderNumber = SalesOrderLine.OrderNumber
			AND (SalesOrder.OrderType like '%' + OrderedProduct.CheckAgainstOrderType + '%'
				OR OrderedProduct.CheckAgainstOrderType = 'All')
	WHERE SalesOrderLine.SubscriberId IN (SELECT SubscriberId FROM #Subscriber )
--11/3/11	James Wosnam	SIR2349 - Exclude MACweb from sales order lines considered
	AND OrderedProduct.ProductCode <> 'MAC WEB'

--12/7/21	Julian Gates	SIR5281 - Add DisplayProductName field to Products.
	CREATE TABLE #Products(
		PrimaryProductCode varchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
		,PrimaryProductName varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
		,PrimaryProductShortName varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
		,PrimaryProductTermsAndConditionsFileName varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
		,ProductCode varchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
		,ProductName varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
		,ProductShortName varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
		,ProductGroupingName varchar(25) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
		,TermsAndConditionsFileName varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
		,ProductRateId INT Null
		,ProductRate MONEY NULL
		,SubscriberCategory varchar(20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
		,CurrentSubscriptionEndDate DateTime NULL
		,CurrentSubscriptionOrderNumber INT NULL
		,NewRecurringSubscriptionStartDate DateTime NULL
		,NewRecurringSubscriptionEndDate DateTime NULL
		,RecurringSubscriptionFlag BIT NULL
		,CurrencyCode Varchar(3)
		,DisplayProductName NVarchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS  NOT NULL
		)
--GEt all the main products this subscriber is allowed to buy. 
	INSERT INTO #Products
		(PrimaryProductCode 
		,PrimaryProductName 
		,PrimaryProductShortName
		,PrimaryProductTermsAndConditionsFileName
		,ProductCode
		,ProductName
		,ProductShortName
		,ProductGroupingName
		,TermsAndConditionsFileName
		,CurrentSubscriptionEndDate
		,CurrentSubscriptionOrderNumber
		,RecurringSubscriptionFlag
		,DisplayProductName
		)
	SELECT DISTINCT
		Product.ProductCode
		,Product.ProductName
		,Product.ProductShortName
		,Product.TermsAndConditionsFileName
		,Product.ProductCode
		,Product.ProductName
		,Product.ProductShortName
		,ISNULL(Product.ProductGroupingName,Product.ProductShortName)
		,Product.TermsAndConditionsFileName
--10/4/07	James Woosnam	Use RecurringSubscriptionEndDate SIRs 129, 1013
		,CurrentSubscriptionEndDate = ISNULL(SalesOrderLine.RecurringSubscriptionEndDate,'01-jan-1900')
		,SalesOrderLine.OrderNumber
		,ISNULL(Product.RecurringSubscriptionFlag,0)
		,Product.DisplayProductName
	FROM Product
		--See if this product is a MustBuy Qualifying product - if it is filter out in where clause
		LEFT JOIN ProductQualifyingProduct MustBuyCheck
		On MustBuyCheck.QualifyingProductCode = Product.ProductCode
		AND MustBuyCheck.MustBuyFlag = 1
		--Check to see if they have an order for this product
--14/11/06	James Woosnam	Join to Previous orders on ProductGroupingName to allow for 
--21/11/06	James Woosnam	Allow "RemotePartial" orders that have payment
		LEFT JOIN #SalesOrderLines SalesOrderLine
		On SalesOrderLine.ProductGroupingName = Product.ProductGroupingName
		AND (SalesOrderLine.SalesOrderStatus IN ('Confirmed','Complete') 
				OR (SalesOrderLine.SalesOrderStatus = 'RemotePartial'
					AND SalesOrderLine.AmountGross <= SalesOrderLine.TotalCashbookAmount)
			)
--19/11/07	James Woosnam	SIR1395 - Use OrderNumber to find last order for product rather than RecurringEndDate as this can sometimes be null.	
		AND SalesOrderLine.OrderNumber = (SELECT MAX(SOl.OrderNumber)
									FROM #SalesOrderLines sol
									WHERE sol.SubscriberId = SalesOrderLine.SubscriberId
									AND (sol.SalesOrderStatus IN ('Confirmed','Complete') 
											OR (sol.SalesOrderStatus = 'RemotePartial'
												AND sol.AmountGross <= SalesOrderLine.TotalCashbookAmount)
										)
									AND sol.ProductCode = SalesOrderLine.ProductCode)	

	WHERE Product.CompanyId  IN (SELECT CompanyId FROM #SubsCompanies)
	AND Product.SellOnWebFlag = 1
	AND Product.IsParent = 1
--9/2/15	James Woosnam	SIR3724 - Consrrain to status and release date
	AND Product.ProductStatus = 'Current'
	AND Product.ReleaseDate <= GETDATE()
	AND MustBuyCheck.ProductCode IS NULL
--14/11/06	James Woosnam	Use OnePerSubscriberFlag to only show some products if not ordered.
	AND ((ISNULL(Product.RecurringSubscriptionFlag,0) <> 1 
			AND (SalesOrderLine.OrderNumber IS NULL
				OR Product.OnePerSubscriberFlag <> 1))
		OR  (ISNULL(Product.RecurringSubscriptionFlag,0) = 1 
			)
		)
--select * from #products
--Get any products that must be bought as part of buying the parent product
	INSERT INTO #Products
		(PrimaryProductCode 
		,PrimaryProductName 
		,PrimaryProductShortName 
		,PrimaryProductTermsAndConditionsFileName
		,ProductCode
		,ProductName
		,ProductShortName
		,ProductGroupingName
		,TermsAndConditionsFileName
		,CurrentSubscriptionEndDate
		,RecurringSubscriptionFlag
		,DisplayProductName
		)
	SELECT DISTINCT
		#Products.ProductCode
		,#Products.ProductName
		,#Products.ProductShortName
		,#Products.TermsAndConditionsFileName
		,Product.ProductCode
		,Product.ProductName
		,Product.ProductShortName
		,ISNULL(Product.ProductGroupingName,Product.ProductShortName)
		,Product.TermsAndConditionsFileName
		,CurrentSubscriptionEndDate = '01-jan-1900'
		,ISNULL(Product.RecurringSubscriptionFlag,0)
		,#Products.DisplayProductName
	FROM Product
		INNER JOIN #Subscriber 
		On #Subscriber.Subscriberid IN (SELECT SubscriberId FROM #Subscriber )
		INNER JOIN ProductQualifyingProduct MustBuyProductQualifyingProduct
			INNER JOIN #Products
			ON #Products.ProductCode = MustBuyProductQualifyingProduct.ProductCode
		On MustBuyProductQualifyingProduct.QualifyingProductCode = Product.ProductCode
		AND MustBuyProductQualifyingProduct.MustBuyFlag = 1
		
		LEFT JOIN #SalesOrderLines SalesOrderLine
		On SalesOrderLine.ProductGroupingName = Product.ProductGroupingName
		AND (SalesOrderLine.SalesOrderStatus IN ('Confirmed','Complete') 
				OR (SalesOrderLine.SalesOrderStatus = 'RemotePartial'
					AND SalesOrderLine.AmountGross <= SalesOrderLine.TotalCashbookAmount)
			)
--19/11/07	James Woosnam	SIR1395 - Use OrderNumber to find last order for product rather than RecurringEndDate as this can sometimes be null.	
		AND SalesOrderLine.OrderNumber = (SELECT MAX(SOl.OrderNumber)
									FROM #SalesOrderLines sol
									WHERE sol.SubscriberId = SalesOrderLine.SubscriberId
									AND (sol.SalesOrderStatus IN ('Confirmed','Complete') 
											OR (sol.SalesOrderStatus = 'RemotePartial'
												AND sol.AmountGross <= SalesOrderLine.TotalCashbookAmount)
										)
									AND sol.ProductCode = SalesOrderLine.ProductCode)	

	--If there isn't a TerminatedSubscriptionsGracePeriodMonths then we jsut check to see if they have bought this before or not
	--If there is a TerminatedSubscriptionsGracePeriodMonths then only show product if over grace period
	WHERE 1 = CASE WHEN ISNULL(MustBuyProductQualifyingProduct.TerminatedSubscriptionsGracePeriodMonths,0)=0
				THEN CASE WHEN SalesOrderLine.OrderNumber IS NULL THEN 1 ELSE 0 END
			ELSE  CASE WHEN GETDATE() > DATEADD(M,ISNULL(MustBuyProductQualifyingProduct.TerminatedSubscriptionsGracePeriodMonths,0),
						#Products.CurrentSubscriptionEndDate) THEN 1
					ELSE 0 END
			END
--07/03/08	James Woosnam	SIR1452 - Get Affiliate Rates if subscriber is affiliated with group that has been given special rates
--									  Also rework product rate code to make simplier						
--17/8/20	James	Special Rates are collected here so the main rate update query below does NOT use them
--21/7/09	James Woosnam	Ignore Null RateIds in specials
	SELECT ProductRateId 
	INTO #SpecialRates
	FROM  ProductQualifyingProduct 
	WHERE  ProductCode IN (SELECT ProductCode FROM #Products)
	AND ProductRateId Is Not Null
	
--21/7/09	James Woosnam	Ignore Null RateIds in specials
	INSERT INTO #SpecialRates
	SELECT ProductRateId 
	FROM  ProductAffiliateRate 
	WHERE  ProductCode IN (SELECT ProductCode FROM #Products)
	AND ProductRateId Is Not Null

--Get one rate (doesn't matter which as other added later) for all products already found from non special rates
--22/11/06	James Woosnam	Change the product rate lookup to use CheckAgainstOrderType from qualifying product
	UPDATE #Products
	SET 
		ProductRateId=ProductRate.ProductRateId
		,ProductRate = ProductRate.ProductRate
		,SubscriberCategory = #Subscriber.SubscriberCategory
		,CurrencyCode = ProductRate.CurrencyCode
	FROM #Products Product
		INNER JOIN #Subscriber 
		On #Subscriber.Subscriberid IN (SELECT SubscriberId FROM #Subscriber )
		LEFT JOIN ProductRate
		On ProductRate.ProductCode = Product.ProductCode
		AND ProductRate.AccountType = #Subscriber.AccountType
		AND ProductRate.SubscriberCategory = #Subscriber.SubscriberCategory
		AND ProductRate.ProductRateId Not IN (SELECT ProductRateId 
												FROM  #SpecialRates)
		AND ProductRate.SellOnWebFlag = 1
		AND (ProductRate.NewUserRateFlag =1 OR @NewUserRates <> 1)
--9/2/15	James Woosnam	SIR3724 - Constrain rates by DeliveryArea from Subscribers primary country or the ALL rate if no match
		AND (ProductRate.DeliveryArea = #Subscriber.CountryDeliveryArea 
			OR (ProductRate.DeliveryArea <> #Subscriber.CountryDeliveryArea AND ProductRate.DeliveryArea = 'All' )
			)

--select * from #Products
--8/11/06	James Woosnam	Need to add all possible rates before selecting the cheapest
--Get any additional NON special rates
	INSERT INTO #Products
		(PrimaryProductCode 
		,PrimaryProductName 
		,PrimaryProductShortName 
		,PrimaryProductTermsAndConditionsFileName
		,ProductCode
		,ProductName
		,ProductShortName
		,ProductGroupingName
		,TermsAndConditionsFileName
		,CurrentSubscriptionEndDate
		,RecurringSubscriptionFlag
		,ProductRateId
		,ProductRate 
		,SubscriberCategory 
		,CurrencyCode
		,DisplayProductName
		)
	SELECT DISTINCT
		Product.PrimaryProductCode
		,Product.PrimaryProductName
		,Product.PrimaryProductShortName
		,Product.PrimaryProductTermsAndConditionsFileName
		,Product.ProductCode
		,Product.ProductName
		,Product.ProductShortName
		,Product.ProductGroupingName
		,Product.TermsAndConditionsFileName
		,Product.CurrentSubscriptionEndDate
		,ISNULL(Product.RecurringSubscriptionFlag,0)
		,ProductRateId=ProductRate.ProductRateId
		,ProductRate = ProductRate.ProductRate
		,SubscriberCategory = #Subscriber.SubscriberCategory
		,CurrencyCode = ProductRate.CurrencyCode
		,Product.DisplayProductName
	FROM #Products Product
		INNER JOIN #Subscriber 
		On #Subscriber.Subscriberid IN (SELECT SubscriberId FROM #Subscriber )
		LEFT JOIN ProductRate
		On ProductRate.ProductCode = Product.ProductCode
		AND ProductRate.AccountType = #Subscriber.AccountType
		AND ProductRate.SubscriberCategory = #Subscriber.SubscriberCategory
		AND ProductRate.ProductRateId Not IN (SELECT ProductRateId 
												FROM  #SpecialRates)
		AND ProductRate.SellOnWebFlag = 1
		AND (ProductRate.NewUserRateFlag =1 OR @NewUserRates <> 1)
--9/2/15	James Woosnam	SIR3724 - Constrain rates by DeliveryArea from Subscribers primary country or the ALL rate if no match
		AND (ProductRate.DeliveryArea = #Subscriber.CountryDeliveryArea 
			OR (ProductRate.DeliveryArea <> #Subscriber.CountryDeliveryArea AND ProductRate.DeliveryArea = 'All' )
			)

--This section gets rates dictated by what they have previously bought
	INSERT INTO #Products
		(PrimaryProductCode 
		,PrimaryProductName 
		,PrimaryProductShortName 
		,PrimaryProductTermsAndConditionsFileName
		,ProductCode
		,ProductName
		,ProductShortName
		,ProductGroupingName
		,TermsAndConditionsFileName
		,CurrentSubscriptionEndDate
		,RecurringSubscriptionFlag
		,ProductRateId
		,ProductRate 
		,SubscriberCategory 
		,CurrencyCode
		,DisplayProductName
		)
	SELECT DISTINCT
		Product.PrimaryProductCode
		,Product.PrimaryProductName
		,Product.PrimaryProductShortName
		,Product.PrimaryProductTermsAndConditionsFileName
		,Product.ProductCode
		,Product.ProductName
		,Product.ProductShortName
		,Product.ProductGroupingName
		,Product.TermsAndConditionsFileName
		,Product.CurrentSubscriptionEndDate
		,ISNULL(Product.RecurringSubscriptionFlag,0)
		,ProductRateId=ProductRate.ProductRateId
		,ProductRate = ProductRate.ProductRate
		,SubscriberCategory = #Subscriber.SubscriberCategory
		,CurrencyCode = ProductRate.CurrencyCode
		,Product.DisplayProductName
	FROM #Products Product
		INNER JOIN #Subscriber 
		On #Subscriber.Subscriberid IN (SELECT SubscriberId FROM #Subscriber )
		INNER JOIN ProductRate
		On ProductRate.ProductCode = Product.ProductCode
		AND ProductRate.AccountType = #Subscriber.AccountType
		AND ProductRate.SubscriberCategory = #Subscriber.SubscriberCategory
		AND ProductRate.ProductRateId IN (SELECT pqr2.ProductRateId 
											FROM  ProductQualifyingProduct pqr2
												INNER JOIN SalesORderLine sol
												On sol.ProductCode = pqr2.QualifyingProductCode
												AND sol.SubscriberId =#Subscriber.SubscriberId
													INNER JOIN SalesOrder so
													On so.OrderNumber = sol.OrderNumber
													AND so.SalesOrderStatus IN ('Complete','Confirmed')
													AND (so.OrderType like '%' + pqr2.CheckAgainstOrderType + '%'
														OR pqr2.CheckAgainstOrderType = 'All')
											WHERE  pqr2.ProductCode = ProductRate.ProductCode)
		AND ProductRate.SellOnWebFlag = 1
		AND (ProductRate.NewUserRateFlag =1 OR @NewUserRates <> 1)
--9/2/15	James Woosnam	SIR3724 - Constrain rates by DeliveryArea from Subscribers primary country or the ALL rate if no match
		AND (ProductRate.DeliveryArea = #Subscriber.CountryDeliveryArea 
			OR (ProductRate.DeliveryArea <> #Subscriber.CountryDeliveryArea AND ProductRate.DeliveryArea = 'All' )
			)

--10/12/19	James Woosnam	SIR4975 - Special hard coding to delete special PEPweb qualifying rates if the sub got a JV100 product.  Only works for JV101 and Rate D.
	DELETE #Products 
	FROM #Products p
		INNER JOIN #Subscriber 
		On #Subscriber.Subscriberid IN (SELECT SubscriberId FROM #Subscriber )
		INNER JOIN ProductRate pr
		ON pr.ProductRateId = p.ProductRateId 
		AND pr.ProductCode = 'JV101'
		AND pr.RateType = 'rate D'
	WHERE EXISTS(SELECT sol.orderNumber
				FROM SalesORderLine sol
					INNER JOIN SalesOrder so
					On so.OrderNumber = sol.OrderNumber
					AND so.SalesOrderStatus IN ('Complete','Confirmed')
				WHERE sol.ProductCode IN ('JV100','EJV100','PV100')
				AND sol.SubscriberId =#Subscriber.SubscriberId
				)


--07/03/08	James Woosnam	SIR1452 - Get Affiliate Rates if subscriber is affiliated with group that has been given special rates
--									  Also rework product rate code to make simplier						
--This section gets rates dictated by what group they might be in
	INSERT INTO #Products
		(PrimaryProductCode 
		,PrimaryProductName 
		,PrimaryProductShortName 
		,PrimaryProductTermsAndConditionsFileName
		,ProductCode
		,ProductName
		,ProductShortName
		,ProductGroupingName
		,TermsAndConditionsFileName
		,CurrentSubscriptionEndDate
		,RecurringSubscriptionFlag
		,ProductRateId
		,ProductRate 
		,SubscriberCategory 
		,CurrencyCode
		,DisplayProductName
		)
	SELECT DISTINCT
		Product.PrimaryProductCode
		,Product.PrimaryProductName
		,Product.PrimaryProductShortName
		,Product.PrimaryProductTermsAndConditionsFileName
		,Product.ProductCode
		,Product.ProductName
		,Product.ProductShortName
		,Product.ProductGroupingName
		,Product.TermsAndConditionsFileName
		,Product.CurrentSubscriptionEndDate
		,ISNULL(Product.RecurringSubscriptionFlag,0)
		,ProductRateId=ProductRate.ProductRateId
		,ProductRate = ProductRate.ProductRate
		,SubscriberCategory = #Subscriber.SubscriberCategory
		,CurrencyCode = ProductRate.CurrencyCode
		,Product.DisplayProductName
	FROM #Products Product
		INNER JOIN #Subscriber 
		On #Subscriber.Subscriberid IN (SELECT SubscriberId FROM #Subscriber )
		INNER JOIN ProductRate
		On ProductRate.ProductCode = Product.ProductCode
		AND ProductRate.AccountType = #Subscriber.AccountType
		AND ProductRate.SubscriberCategory = #Subscriber.SubscriberCategory
		AND ProductRate.SellOnWebFlag = 1
		AND (ProductRate.NewUserRateFlag =1 OR @NewUserRates <> 1)
--9/2/15	James Woosnam	SIR3724 - Constrain rates by DeliveryArea from Subscribers primary country or the ALL rate if no match
		AND (ProductRate.DeliveryArea = #Subscriber.CountryDeliveryArea 
			OR (ProductRate.DeliveryArea <> #Subscriber.CountryDeliveryArea AND ProductRate.DeliveryArea = 'All' )
			)
		INNER JOIN ProductAffiliateRate
		ON ProductAffiliateRate.ProductCode = ProductRate.ProductCode
		AND ProductAffiliateRate.SubscriberCategory = #Subscriber.SubscriberCategory
--08/4/08	James Woosnam	Join on ProductRateId
		AND ProductAffiliateRate.ProductRateId = ProductRate.ProductRateId
		INNER JOIN SubscriberAffiliate
		ON SubscriberAffiliate.ChildSubscriberId = #Subscriber.Subscriberid 
		AND SubscriberAffiliate.ParentSubscriberId = ProductAffiliateRate.GroupSubscriberId
		AND GetDate() BETWEEN SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate



--21/6/11	James Woosnam	SIR2445 - If there is a current subscription to any recurring PEPWeb product then remove any other pepweb products									
	DELETE #Products
	FROM #Products
	WHERE PrimaryProductCode IN (SELECT PrimaryProductCode 
								FROM #Products 
								WHERE PrimaryProductCode like 'PEPWeb%'
								AND RecurringSubscriptionFlag = 1)
	AND EXISTS( SELECT PrimaryProductCode 
				FROM #Products 
				WHERE #Products.RecurringSubscriptionFlag = 1 
				AND PrimaryProductCode like 'PEPWeb%'
				AND dateadd(day, (-1 * dbo.fn017GetParameter('FirstReminderDaysBefore')),CurrentSubscriptionEndDate) > GetDate())

	--Don't output any product where the subscription is not finished
	DELETE #Products
	FROM #Products
	WHERE PrimaryProductCode IN (SELECT PrimaryProductCode 
								FROM #Products 
--24/01/08	James Woosnam	SIR1615 - Use Parameter FirstReminderDaysBefore to dictate when to show expiring orders
								WHERE #Products.RecurringSubscriptionFlag = 1 
								AND dateadd(day, (-1 * dbo.fn017GetParameter('FirstReminderDaysBefore')),CurrentSubscriptionEndDate) > GetDate())


--21/6/11	James Woosnam	SIR2445 - Don't show CPPost unless there is already a CPO product shown									
	DELETE #Products
	FROM #Products
	WHERE PrimaryProductCode IN (SELECT PrimaryProductCode 
								FROM #Products 
								WHERE PrimaryProductCode like 'CPPost'
								)
	AND NOT EXISTS( SELECT PrimaryProductCode 
				FROM #Products 
				WHERE  PrimaryProductCode = 'CPO'
				)
--7/2/20	James	Delete any products in list which are associated with a product that is no longer in the list
--1/9/20	James Woosnam	SIR5118 - don't delete if product has an qualifying product of its parent associated product,
--							as this indicates the associated product can be sold seperatly after the product it is associated with has been bought!!
--							For example JV102 was sold and then later, if sub wants pv102, they are charged $30
	DELETE #Products
	FROM #Products p
		LEFT JOIN Product asscOwner  --SIR5118
		ON asscOwner.AssociatedProductCode = p.ProductCode 
		LEFT JOIN ProductQualifyingProduct q  --SIR5118
		ON q.ProductCode=p.ProductCode 
		AND q.QualifyingProductCode = asscOwner.ProductCode 
		AND q.SubscriberCategory = p.SubscriberCategory 
	WHERE p.ProductCode IN (SELECT p2.AssociatedProductCode 
							FROM Product p2
							WHERE p2.ProductCode NOT IN (SELECT p3.productCode FROM #Products p3)
							AND p2.AssociatedProductCode IS NOT NULL
						)
	AND NOT EXISTS(SELECT q.ProductCode  --SIR5118
					FROM ProductQualifyingProduct q
					WHERE q.ProductCode=p.ProductCode 
					AND q.QualifyingProductCode = asscOwner.ProductCode 
					AND q.SubscriberCategory = p.SubscriberCategory 
					AND q.ProductRateId = p.ProductRateId 
					)

--23/4/21	James Woosnam	SIR5230 - Special code Delete PV102 zero rate when user offered $60 JV102 rate
	DELETE #Products 
	FROM #Products p
		INNER JOIN Product asscOwner  
		ON asscOwner.AssociatedProductCode = p.ProductCode 
		INNER JOIN (SELECT * FROM #Products) p2
		ON p2.ProductCode = asscOwner.ProductCode
	WHERE p.ProductCode = 'PV102'
	AND asscOwner.ProductCode = 'JV102'
	AND p2.ProductRate = 60
	AND p.ProductRate=0

	DECLARE @RecurringStartDate DATETIME
	SELECT @RecurringStartDate = GETDATE()

	UPDATE #Products
	SET NewRecurringSubscriptionStartDate = CASE #Products.RecurringSubscriptionFlag 
										WHEN 1 THEN CASE 
															WHEN #Products.CurrentSubscriptionEndDate =  '01-jan-1900' THEN @RecurringStartDate
															WHEN #Products.CurrentSubscriptionEndDate <  GetDate() THEN @RecurringStartDate
													  	ELSE DATEADD(S,1,#Products.CurrentSubscriptionEndDate) END
										ELSE '01-jan-1900' END
	FROM #Products
		INNER JOIN Product
		On Product.ProductCode = #Products.ProductCode

	UPDATE #Products
	SET NewRecurringSubscriptionEndDate = dbo.fn236GetRecurringSubscriptionEndDate(#Products.ProductCode,NewRecurringSubscriptionStartDate)
	FROM #Products
		INNER JOIN Product
		On Product.ProductCode = #Products.ProductCode

	--24/11/08	James Woosnam	SIR1615- Ensure the CurrentSubscriptionOrderNumber is populated where possible
--14/12/2018	James Woosnam	SIR4752 - Get the CurrentSubscriptionOrderNumber with a max grouped on ProductGroupingName
	UPDATE #Products
	SET CurrentSubscriptionOrderNumber = SalesOrderLine.MaxOrderNumber
	FROM #Products Product
		LEFT JOIN (SELECT SalesOrderLine.ProductGroupingName 
						,MaxOrderNumber = MAX(SalesOrderLine.OrderNumber)
				FROM #SalesOrderLines SalesOrderLine
				where  SalesOrderLine.SalesOrderStatus IN ('Confirmed','Complete') 
				OR (SalesOrderLine.SalesOrderStatus = 'RemotePartial'
					AND SalesOrderLine.AmountGross <= SalesOrderLine.TotalCashbookAmount)
				GROUP BY SalesOrderLine.ProductGroupingName 
				) SalesOrderLine
		ON SalesOrderLine.ProductGroupingName = product.ProductGroupingName 	
	WHERE CurrentSubscriptionOrderNumber IS NULL

--select * from #Products
--13/11/06 James Woosnam  Add Group By to eliminate duplicate rate IDs
--19/7/11	James Woosnam	Put output into temp table so we can filter out orphan sub products
	SELECT  SubscriberId = @SubscriberId
		,#Products.SubscriberCategory
		,#Products.PrimaryProductCode
		,#Products.PrimaryProductName
		,#Products.PrimaryProductShortName
		,#Products.TermsAndConditionsFileName
		,#Products.ProductCode
		,#Products.ProductName
		,#Products.ProductShortName
		,#Products.ProductGroupingName
		,#Products.ProductRate
		,RateStatus = CASE WHEN #Products.ProductRateId IS NULL THEN 'NoRate' ELSE 'RateFound' END
		,CurrentSubscriptionEndDate=MAX(#Products.CurrentSubscriptionEndDate)
		,CurrentSubscriptionOrderNumber = MAX(#Products.CurrentSubscriptionOrderNumber)
		,NewRecurringSubscriptionStartDate=MAX(#Products.NewRecurringSubscriptionStartDate)
		,NewRecurringSubscriptionEndDate=MAX(#Products.NewRecurringSubscriptionEndDate)
		,#Products.RecurringSubscriptionFlag
		,#Products.CurrencyCode
		,PrimaryProduct =CASE WHEN PrimaryProductCode = ProductCode THEN 1 ELSE 0 END
		,ProductRateId = MAX(#Products.ProductRateId)
		,AssociatedWithProductCode = CAST('' AS VARCHAR(10))
		,#Products.DisplayProductName
	INTO #FinalOutput
	FROM #Products
	WHERE #Products.ProductRate = (SELECT MIN(pr.ProductRate)
									FROM #Products pr
--14/11/06	James Woosnam	Join to MIN rate in ProductGroupingName to allow only 1 CD product to show
									WHERE pr.ProductGroupingName = #Products.ProductGroupingName)
	OR (#Products.ProductRateId IS NULL AND @ShowWhereNoRates = 1) 
	
	GROUP BY 
		#Products.SubscriberCategory
		,#Products.PrimaryProductCode
		,#Products.PrimaryProductName
		,#Products.PrimaryProductShortName
		,#Products.TermsAndConditionsFileName
		,#Products.ProductCode
		,#Products.ProductName
		,#Products.ProductShortName
		,#Products.ProductGroupingName
		,#Products.ProductRate
		, CASE WHEN #Products.ProductRateId IS NULL THEN 'NoRate' ELSE 'RateFound' END
		,#Products.RecurringSubscriptionFlag
		,#Products.CurrencyCode
		,#Products.DisplayProductName
		,CASE WHEN PrimaryProductCode = ProductCode THEN 1 ELSE 0 END
	ORDER BY PrimaryProductShortName
		,CASE WHEN PrimaryProductCode = ProductCode THEN 1 ELSE 0 END desc
		,ProductShortName

--4/9/20	James Woosnam	SIR
	UPDATE #FinalOutput
	SET	AssociatedWithProductCode = (SELECT MAX(p.ProductCode)
										FROM Product p
										WHERE p.AssociatedProductCode = #FinalOutput.ProductCode
										AND NOT EXISTS(SELECT q.ProductCode  --SIR5118
															FROM ProductQualifyingProduct q
															WHERE q.ProductCode=#FinalOutput.ProductCode 
															AND q.QualifyingProductCode = asscOwner.ProductCode 
															AND q.SubscriberCategory = #FinalOutput.SubscriberCategory 
															AND q.ProductRateId = #FinalOutput.ProductRateId 
															)
					)
	FROM #FinalOutput 
		LEFT JOIN Product asscOwner  --SIR5118
		ON asscOwner.AssociatedProductCode = #FinalOutput.ProductCode 
		LEFT JOIN ProductQualifyingProduct q  --SIR5118
		ON q.ProductCode=#FinalOutput.ProductCode 
		AND q.QualifyingProductCode = asscOwner.ProductCode 
		AND q.SubscriberCategory = #FinalOutput.SubscriberCategory 
--19/7/11	James Woosnam	Put output into temp table so we can filter out orphan sub products
--22/11/19	James Woosnam	SIR4949 - Add AssociatedWithProductCode
SELECT *
FROM (
	SELECT *
	FROM #FinalOutput
	WHERE PrimaryProductCode in (select PrimaryProductCode
								FROM #FinalOutput
								Where PrimaryProductCode = ProductCode)
	) p
--2/4/18	James Woosnam	SIR4600 - Add a sort order to the final query
	ORDER BY ISNULL(AssociatedWithProductCode , PrimaryProductCode)
		,PrimaryProductCode 
		,CASE WHEN PrimaryProductCode = ProductCode THEN 0 ELSE 1 END

SET NOCOUNT OFF
SET ARITHIGNORE OFF
GO
GRant EXECUTE ON sp235WebProducts to PaDSSQLServerUser


--exec sp235WebProducts @SubscriberId = 34417 --Ordinary Group
--exec sp235WebProducts @SubscriberId = 35081 --student Group
--exec sp235WebProducts @SubscriberId =23722 -- Ordinary MAC
--exec sp235WebProducts @SubscriberId =36013 -- Student MAC
--EXEC sp235WebProducts @CompanyId=2,@SubscriberId=22150,@ShowWhereNoRates=1
--exec sp235WebProducts @NewUserRates=1
--exec sp235WebProducts @SubscriberId = 23685 

--exec sp235WebProducts @SubscriberId =44864,@CompanyId =2
--exec sp235WebProducts @CompanyId =2
--exec sp235WebProducts @SubscriberId = 23988 
--exec sp235WebProducts @SubscriberId = 40681 --has a1v5a and PEP L2
--exec sp235WebProducts @SubscriberId = 35635 
--exec sp235WebProducts @SubscriberId = 23488 ,@ShowWhereNoRates=1
--exec sp235WebProducts @SubscriberId = 26077   ,@ShowWhereNoRates=1