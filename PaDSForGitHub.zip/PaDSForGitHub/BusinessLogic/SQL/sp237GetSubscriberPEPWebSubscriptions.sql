if exists (select * from dbo.sysobjects where id = object_id(N'sp237GetSubscriberPEPWebSubscriptions') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp237GetSubscriberPEPWebSubscriptions
GO
CREATE PROCEDURE sp237GetSubscriberPEPWebSubscriptions ( 
		@SubscriberId INT = NULL
		,@UserName VARCHAR(200) = NULL
		,@OnDate DATETIME =NULL
		,@ReturnType VARCHAR(20) = 'ProductCombinations' --'ContentSets'
		)

AS
--7/4/14	James Woosnam	SIR3472 - Output name First Last

SET NOCOUNT ON
SET ARITHIGNORE ON
/*
Description:	Builds a list of the PEP products this subscriber is subscribed to on the given date
				It also get the unique ProductCombinationId for the combination of products subscribed to
18/3/11	James Woosnam	Find products for base sub as well if the passed sub is the proposed one	
1/4/14	James Woosnam	SIR3472 - Add additional data field
9/12/15	SIR4019 - Add all furture subs and delete any that don't have the newest order number
--26/5/17	James Woosnam	SIR4408 - Combine products PEPWeb,PEPWEBS,PEPWeb3y into PEPWeb, so the number of combination can be reduced
--28/10/19	James Woosnam	SIR4763 - Get User logon details from RemoteUser rather than Subscriber
--27/9/20	James Woosnam	SIR5043 - Allow GroupUsers
*/
DECLARE @SQL VARCHAR(8000) 
DECLARE @ProdcutCode Varchar(10)
DECLARE @Error INT 
DECLARE @ProdCount INT 
DECLARE @TotalSubs VARCHAR(3)
DECLARE @SQLTable VARCHAR(1000)
SET @Error = 0
SET @ProdCount = 0

IF @OnDate IS NULL
BEGIN
	SET @OnDate = GETDATE()
END

	IF @SubscriberId IS NULL
	  AND @UserName IS NULL
	BEGIN
		RAISERROR ('sp237GetSubscriberPEPWebSubscriptions reqires either @SubscriberId or @UserName', 18, 1)
		SET @Error = 1
	END

IF @Error = 0 
BEGIN
	SELECT DISTINCT 
		--26/5/17	James Woosnam	SIR4408 - Combine products PEPWeb,PEPWEBS,PEPWeb3y into PEPWeb, so the number of combination can be reduced
		--****IF CHANGED, CHANGE IN FROM BELOW****
		CASE WHEN SalesOrderLine.ProductCode IN ('PEPWeb','PEPWEBS','PEPWeb3y') THEN 'PEPWeb' ELSE SalesOrderLine.ProductCode END AS ProductCode
		 ,Subscriber.SubscriberId as SubscriberId
		 ,ru.UserName as WebUserName
--7/4/14	James Woosnam	SIR3472 - Output name First Last
		 ,ISNULL(CASE WHEN Subscriber.FirstName IS NULL THEN '' ELSE Subscriber.FirstName + ' ' END
				+ CASE WHEN Subscriber.LastName IS NULL THEN '' ELSE Subscriber.LastName END
				,Subscriber.SubscriberName)
		   as SubscriberName
		 ,ru.Password as WebUserPassword
--1/4/14	James Woosnam	SIR3472 - Add additional data field
		 ,SubscriberEmailAddress = (SELECT MAX(sa.AddressText)
									FROM SubscriberAddress sa
									WHERE sa.SubscriberId = Subscriber.SubscriberId 
									AND sa.AddressType='Email' 
									AND sa.AddressDescription='Main')
		 ,SalesOrder.SubscriberId as GatewayId
		 ,SalesOrder.OrderDate as OrderDate
		 ,SalesOrder.OrderNumber as OrderNumber
		 ,SalesOrderLine.RecurringSubscriptionStartDate
		 ,SalesOrderLine.RecurringSubscriptionEndDate
		 ,Product.ProductName
		 ,OrderedViaSubscriberId = sVia.SubscriberId
		 --Jan20 - removed Self as via name as doesn't work for IPAddressIndividuals et al
		 ,OrderedViaName =  sVia.SubscriberName 
	INTO #ProductSubs
	FROM  Subscriber  
--28/10/19	James Woosnam	SIR4763 - Get User logon details from RemoteUser rather than Subscriber
		INNER JOIN RemoteUserRights rur
			INNER Join RemoteUser ru
			ON ru.UserId = rur.UserId 
		ON rur.RightsToId = subscriber.SubscriberId 
		AND rur.RightsType = 'Subscriber'
		LEFT JOIN  SalesOrderLine  
			INNER JOIN SalesOrder 
				INNER JOIN Subscriber sVia
				ON sVia.SubscriberId = SalesOrder.SubscriberId 
			ON SalesOrderLine.OrderNumber = SalesOrder.OrderNumber 
			And (SalesOrder.SalesOrderStatus IN ('Confirmed','Complete')
				   OR (SalesOrder.SalesOrderStatus = 'RemotePartial' 
						AND SalesOrder.AmountGross <= (SELECT SUM(Amount) 
									FROM Cashbook
									WHERE OrderNumber =  SalesOrderLine.OrderNumber
									AND CashbookStatus = 'Confirmed')))
			INNER JOIN Product 
			ON Product.ProductCode = SalesOrderLine.ProductCode 
		--16/6/17	James Woosnam	SIR4408 - Add PEPweb case statement into join
		--****IF CHANGED, CHANGE IN SELECT ABOVE****
		--	AND Product.ProductCode IN (SELECT ProductCode FROM PEPOnlineProductCombination)
			AND ((CASE WHEN SalesOrderLine.ProductCode IN ('PEPWeb','PEPWEBS','PEPWeb3y') THEN 'PEPWeb' ELSE SalesOrderLine.ProductCode END IN (SELECT ProductCode FROM PEPOnlineProductCombination)
				AND @ReturnType= 'ProductCombinations')
				OR
				(SalesOrderLine.ProductCode in (select productcode from ProductContentSet)
				AND @ReturnType= 'ContentSets')
				)
			AND Product.RecurringSubscriptionFlag = 1
		--30/3/21	James		The company filter was removed as it was disabling IJOD IJP Open and Zedra test scripts
		--	AND Product.CompanyId = 2 --Only look for products owned by PEP
		ON SalesOrderLine.SubscriberId = Subscriber.SubscriberId 
--9/12/15	SIR4019 - Include any future subscriptions
		AND @OnDate < SalesOrderLine.RecurringSubscriptionEndDate
			
	WHERE Subscriber.SubscriberStatus IN ( 'Current','Proposed')
	AND (ru.UserName = @UserName OR @UserName IS NULL)
--18/3/11	James Woosnam	Find products for base sub as well if the passed sub is the proposed one	
	AND (Subscriber.SubscriberId = @SubscriberId OR @SubscriberId IS NULL OR Subscriber.SubscriberId =  (SELECT s1.UpdateToSubscriberId FROM Subscriber s1 WHERE  s1.SubscriberId = @SubscriberId AND s1.SubscriberStatus = 'Proposed'))
--27/9/20	James Woosnam	SIR5043 - Allow GroupUsers
	AND ru.AuthorityLevel IN ( 'IndividualSubscriber','Groupuser')
	AND ru.UserStatus = 'Active'
	ORDER BY SalesOrderLine.RecurringSubscriptionEndDate DESC

--9/12/15	SIR4019 - If there is more than one subscription delete any that don't have the newest order number
	DELETE #ProductSubs
	FROM #ProductSubs ps
		INNER JOIN (
			SELECT
				ProductCode
				,MaxSalesOrderNumber = MAX(OrderNumber)
			FROM #ProductSubs
			GROUP BY ProductCode
			HAVING COUNT(*) > 1
		) p
		ON p.ProductCode = ps.ProductCode 
		AND p.MaxSalesOrderNumber <> ps.OrderNumber 

	--Get the number of distinct products for use in building SQL
	SELECT @TotalSubs = CAST((SELECT Count(DISTINCT ProductCode) FROM #ProductSubs WHERE ProductCode IS NOT NULL ) AS VARCHAR)

	IF @ReturnType= 'ProductCombinations'
	BEGIN
		--Table to store the ProductCombinationId
		CREATE TABLE #ProductCombination (ProductCombinationId INT)

		DECLARE curProducts CURSOR FOR
		SELECT DISTINCT
			 ProductCode
		FROM  #ProductSubs
		WHERE ProductCode IS NOT NULL

		OPEN curProducts
		FETCH NEXT FROM curProducts INTO @ProdcutCode
		WHILE @@FETCH_STATUS = 0 AND @Error = 0
		BEGIN
			SET @ProdCount = @ProdCount + 1

			SET @SQLTable = '(
					SELECT  ProductCombinationId 
					FROM PEPOnlineProductCombination pc
					WHERE productcode = ''' + @ProdcutCode + '''
					AND ' + @TotalSubs + ' = (SELECT COUNT(*)
											  FROM dbo.PEPOnlineProductCombination pc1
											  WHERE pc1.ProductCombinationId = pc.ProductCombinationId)	
						) pc' + CAST(@ProdCount as VARCHAR) + '
					'
	
			IF @ProdCount = 1
			BEGIN
				SET @SQL = '
					INSERT INTO #ProductCombination
					SELECT DISTINCT pc1.ProductCombinationId
					FROM 
						' + @SQLTable + '
				     			'
			END
			ELSE
			BEGIN
				SET @SQL = @SQL + '
					INNER JOIN 
						' + @SQLTable + '
					ON pc' + CAST(@ProdCount as VARCHAR) + '.ProductCombinationId = pc' + CAST(@ProdCount - 1 as VARCHAR) + '.ProductCombinationId 
						'
			END
		
			FETCH NEXT FROM curProducts INTO @ProdcutCode
		
		END
	
		
		CLOSE curProducts
		deallocate curProducts
	
		--run sql to get ProductCombinationId
		execute(@SQL)

		SELECT #ProductCombination.ProductCombinationId
			,#ProductSubs.*
		FROM #ProductSubs
			LEFT JOIN #ProductCombination
			ON #ProductCombination.ProductCombinationId > 0 
		WHERE #ProductSubs.ProductCode IS NOT NULL
	
		ORDER BY RecurringSubscriptionEndDate DESC
	END --ProductCombinations

	IF @ReturnType= 'ContentSets'
	BEGIN
		SELECT DISTINCT
			 pcs.ContentSetId 
			 ,p.ProductCode 
			 ,p.ProductName 
			 ,p.RecurringSubscriptionStartDate 
			 ,p.RecurringSubscriptionEndDate 
			 ,p.OrderNumber
			 ,p.OrderedViaSubscriberId 
			 ,p.OrderedViaName 
			 ,p.SubscriberId 
			 ,p.SubscriberName 
			 ,HasCurrentAccess = ISNULL(CAST(cs.GivesAccessToAllCurrentContent AS INT),0)
             ,HasArchiveAccess = ISNULL(CAST(cs.GivesAccessToAllArchiveContent AS INT),0)
		INTO #ContentOutput
		FROM  #ProductSubs p
			INNER JOIN ProductContentSet pcs
				INNER JOIN ContentSet cs
				ON cs.ContentSetId = pcs.ContentSetId 
				AND cs.ContentSetStatus = 'Active'

			ON CASE WHEN pcs.ProductCode IN ('PEPWeb','PEPWEBS','PEPWeb3y') THEN 'PEPWeb' ELSE pcs.ProductCode END = p.ProductCode 
		WHERE p.ProductCode IS NOT NULL

		DECLARE @ContentSets VARCHAR(MAX) = ''
		DECLARE @ContentSetId INT
		DECLARE curContentSets CURSOR FOR
		SELECT DISTINCT
			 ContentSetId 
		FROM  #ContentOutput

		OPEN curContentSets
		FETCH NEXT FROM curContentSets INTO @ContentSetId
		WHILE @@FETCH_STATUS = 0 AND @Error = 0
		BEGIN
			SET @ContentSets += CASE WHEN @ContentSets='' THEN '' ELSE ',' END + CAST(@ContentSetId AS VARCHAR)
			FETCH NEXT FROM curContentSets INTO @ContentSetId
		END
		CLOSE curContentSets
		deallocate curContentSets
		
		SELECT *
				,ContentSets = @ContentSets
		FROM #ContentOutput
		ORDER BY RecurringSubscriptionEndDate DESC
	END

END	
	
GO
GRant EXECUTE ON sp237GetSubscriberPEPWebSubscriptions to PaDSSQLServerUser


	/*
		exec sp237GetSubscriberPEPWebSubscriptions @UserName = 'Test1',@ReturnType ='ContentSets'
	exec sp237GetSubscriberPEPWebSubscriptions @UserName = 'Test2',@ReturnType ='ContentSets'
	exec sp237GetSubscriberPEPWebSubscriptions @UserName = 'Test3',@ReturnType ='ContentSets'
	exec sp237GetSubscriberPEPWebSubscriptions @UserName = 'Test4',@ReturnType ='ContentSets'
	exec sp237GetSubscriberPEPWebSubscriptions @UserName = 'Test5',@ReturnType ='ContentSets'
	exec sp237GetSubscriberPEPWebSubscriptions @UserName = 'Test6',@ReturnType ='ContentSets'
	exec sp237GetSubscriberPEPWebSubscriptions @UserName = 'Test7',@ReturnType ='ContentSets'

*/	
	