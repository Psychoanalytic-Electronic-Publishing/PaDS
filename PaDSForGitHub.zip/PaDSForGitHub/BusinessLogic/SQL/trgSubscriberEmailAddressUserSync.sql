if exists (select * from sysobjects where id = object_id(N'trgSubscriberEmailAddressUserSync') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER trgSubscriberEmailAddressUserSync
Go
CREATE TRIGGER trgSubscriberEmailAddressUserSync ON [SubscriberAddress]
FOR Update,Insert
AS
--10/1/20	James Woosnam	SIR4977 - Initial version
UPDATE RemoteUser
SET UserName = CASE WHEN ru.EmailAddress=ru.UserName Then inserted.AddressText ELSE ru.UserName END
	,LastUpdatedDateTime = INSERTED.LastUpdatedDateTime 
	,LastUpdatedByUserId  = INSERTED.LastUpdatedByUserId 
FROM RemoteUser ru
	INNER JOIN RemoteUserRights rur
	ON rur.UserId = ru.UserId 
	AND rur.RightsType = 'Subscriber'
	INNER JOIN INSERTED
	ON INSERTED.SubscriberId = rur.RightsToId 
	AND inserted.AddressType = 'Email'
	AND inserted.AddressDescription = 'Main'
UPDATE RemoteUser
SET EmailAddress = inserted.AddressText 
	,LastUpdatedDateTime = INSERTED.LastUpdatedDateTime 
	,LastUpdatedByUserId  = INSERTED.LastUpdatedByUserId 
FROM RemoteUser ru
	INNER JOIN RemoteUserRights rur
	ON rur.UserId = ru.UserId 
	AND rur.RightsType = 'Subscriber'
	INNER JOIN INSERTED
	ON INSERTED.SubscriberId = rur.RightsToId 
	AND inserted.AddressType = 'Email'
	AND inserted.AddressDescription = 'Main'
go
