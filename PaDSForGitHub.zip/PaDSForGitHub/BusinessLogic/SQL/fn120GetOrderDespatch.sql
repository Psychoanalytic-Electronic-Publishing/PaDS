if exists (select * from dbo.sysobjects where id = object_id(N'fn120GetOrderDespatch') and xtype in (N'FN', N'IF', N'TF'))
drop function fn120GetOrderDespatch
GO
CREATE FUNCTION fn120GetOrderDespatch( @SubscriberId INT, @OrderNumber INT,@ParentProductCode VARCHAR(10))
RETURNS Varchar(max)
AS
BEGIN
--13/3/19	James Woosnam	SIR4811 - Output fund's ratings
DECLARE @Out VARCHAR(max) = ''

DECLARE @DespatchText VARCHAR(50)

DECLARE cur CURSOR FOR 
SELECT DespatchText = solp.ProductCode + '-->' + FORMAT( solp.DateDespatched,'dd-MMM-yy')
FROM SalesOrderLinePart solp
	INNER JOIN Product pC
	ON pC.ProductCode = solp.ProductCode 
	INNER JOIN SalesOrderLine sol
	ON sol.SalesOrderLineID = solp.SalesOrderLineID 
	INNER JOIN Product pP
	ON pP.ProductCode = sol.ProductCode
WHERE solp.OrderNumber = @OrderNumber 
AND sol.SubscriberId = @SubscriberId 
AND sol.ProductCode = @ParentProductCode
AND pP.ProductCode = pC.ParentProductCode 
ORDER BY solp.DateDespatched
Open cur 
FETCH cur 
INTO @DespatchText
WHILE @@FETCH_STATUS = 0 
BEGIN
	SET @Out += CASE WHEN @Out='' THEN ''ELSE '<br/>' END + @DespatchText 
	FETCH cur 
	INTO @DespatchText
END
CLOSE cur 
DEALLOCATE cur 

RETURN ( @Out)

END

GO
GRANT  EXECUTE ON fn120GetOrderDespatch TO PaDSSQLServerUser

 