/*************************************************************************************
Script:	Creates the users and roles required for Database
Description:	

Amendments
21/3/2018	James Woosnam	SIR4590 - Reworked with replaceable ServerName
**************************************************************************************/

USE Pads_Live 
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'ServerName\PEP_FTP') DROP USER [ServerName\PEP_FTP]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'ServerName\IJP_FTP') DROP USER [ServerName\IJP_FTP]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'ServerName\ZedraAdmin') DROP USER [ServerName\ZedraAdmin]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'ZedraAdmin') DROP USER ZedraAdmin

IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'PaDSSQLServerUser') DROP USER [PaDSSQLServerUser]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'PaDSSQLSecurityUser') DROP USER [PaDSSQLSecurityUser]

USE [PADS_Logs]

IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'ServerName\IJP_FTP') DROP USER [ServerName\IJP_FTP]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'ServerName\PEP_FTP') DROP USER [ServerName\PEP_FTP]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'ServerName\ZedraAdmin') DROP USER [ServerName\ZedraAdmin]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'ZedraAdmin') DROP USER ZedraAdmin

IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'PaDSSQLServerUser') DROP USER [PaDSSQLServerUser]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'PaDSSQLSecurityUser') DROP USER [PaDSSQLSecurityUser]

USE [master]

IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ServerName\IJP_FTP') DROP LOGIN [ServerName\IJP_FTP]
IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ServerName\PEP_FTP') DROP LOGIN [ServerName\PEP_FTP]
IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ServerName\ZedraAdmin') DROP LOGIN [ServerName\ZedraAdmin]

--IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ZedraAdmin') DROP LOGIN ZedraAdmin
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'PaDSSQLServerUser') DROP USER [PaDSSQLServerUser]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'PaDSSQLSecurityUser') DROP USER [PaDSSQLSecurityUser]


--******************************************************************************
--******************************************************************************
--			END OF DROP SECTION
--******************************************************************************
--******************************************************************************

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ServerName\ZedraAdmin') CREATE LOGIN [ServerName\ZedraAdmin] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[British]
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'PaDSSQLServerUser') CREATE LOGIN [PaDSSQLServerUser] WITH PASSWORD=N'xxObscuredPasswordxx', DEFAULT_DATABASE=[PADS_Live], DEFAULT_LANGUAGE=[British], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'PaDSSQLSecurityUser') CREATE LOGIN [PaDSSQLSecurityUser] WITH PASSWORD=N'xxObscuredPasswordxx', DEFAULT_DATABASE=[PADS_Live], DEFAULT_LANGUAGE=[British], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = N'ZedraAdmin') CREATE LOGIN ZedraAdmin WITH PASSWORD=N'xxObscuredPasswordxx', DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[British], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF


EXEC sp_addsrvrolemember @loginame = N'ServerName\ZedraAdmin', @rolename = N'sysadmin'
EXEC sp_addsrvrolemember @loginame = N'ZedraAdmin', @rolename = N'sysadmin'


USE [PADS_Live]

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'PaDSSQLServerUser') CREATE USER [PaDSSQLServerUser] FOR LOGIN [PaDSSQLServerUser] WITH DEFAULT_SCHEMA=[dbo]
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'PaDSSQLSecurityUser') CREATE USER [PaDSSQLSecurityUser] FOR LOGIN [PaDSSQLSecurityUser] WITH DEFAULT_SCHEMA=[dbo]

EXEC sys.sp_addrolemember @rolename=N'db_owner', @membername=N'PaDSSQLSecurityUser'

USE [PADS_Logs]


IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'PaDSSQLServerUser') CREATE USER [PaDSSQLServerUser] FOR LOGIN [PaDSSQLServerUser] WITH DEFAULT_SCHEMA=[dbo]
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'PaDSSQLSecurityUser') CREATE USER [PaDSSQLSecurityUser] FOR LOGIN [PaDSSQLSecurityUser] WITH DEFAULT_SCHEMA=[dbo]

EXEC sys.sp_addrolemember @rolename=N'db_datareader', @membername=N'PaDSSQLServerUser'

EXEC sys.sp_addrolemember @rolename=N'db_datawriter', @membername=N'PaDSSQLServerUser'

EXEC sys.sp_addrolemember @rolename=N'db_owner', @membername=N'PaDSSQLSecurityUser'



