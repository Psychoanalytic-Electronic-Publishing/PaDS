/*
USE master
Exec sp_dropdevice 'PadsBackup'
EXEC sp_addumpdevice 'disk', 'PadsBackup','\\zedra05\d\projects\Pads\backup\Pads.bak'

-- Back up the full MyNwind database.
BACKUP DATABASE Pads_Test  to PadsBackup WITH INIT

*/

--drop database Pads_Live
go

RESTORE FILELISTONLY 

    FROM DISK = '\\zedra05\d\projects\Pads\backup\PaDS_Live_db_200303031717.BAK'

RESTORE DATABASE Pads_Test

    FROM DISK = '\\zedra05\d\projects\Pads\backup\PaDS_Live_db_200303031717.BAK'

    WITH MOVE 'PaDS_Test_dat' TO 'D:\MSSQL\Pads_Test.mdf',

    MOVE 'PaDS_Test_log' TO 'D:\MSSQL\Pads_Test.ldf'

GO