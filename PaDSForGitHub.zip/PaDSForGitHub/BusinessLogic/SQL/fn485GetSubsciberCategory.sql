if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].fn485GetSubsciberCategory') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].fn485GetSubsciberCategory
GO

CREATE FUNCTION dbo.fn485GetSubsciberCategory ( @SubscriberCategory varchar(20) 
												,@CompanyId INT )
RETURNS Varchar(20)
AS
BEGIN
DECLARE @ReturnedSubscriberCategory varchar(20)

IF EXISTS(Select LookupItemKey
		FROM Lookup
		WHERE LookupName = 'SubscriberCategory'
		AND LookupItemKey = @SubscriberCategory
		AND CompanyId = @CompanyId)
BEGIN
	SET @ReturnedSubscriberCategory = @SubscriberCategory
END
ELSE
BEGIN
	SELECT @ReturnedSubscriberCategory = 
		CASE @SubscriberCategory
			WHEN 'Practitioner' THEN 'Ordinary'
			WHEN 'Candidate' THEN 'Student'
			ELSE 'Unknown' END
END

RETURN(	@ReturnedSubscriberCategory )

END