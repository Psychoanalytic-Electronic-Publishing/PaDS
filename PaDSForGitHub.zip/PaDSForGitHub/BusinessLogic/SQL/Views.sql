if exists (select * from dbo.sysobjects where id = object_id(N'f520SecureSubscriber') and xtype in (N'FN', N'IF', N'TF'))
drop function f520SecureSubscriber
GO
CREATE  FUNCTION f520SecureSubscriber ( @UserId INT
				, @TaregtDate DATETIME )
RETURNS TABLE
AS
RETURN (SELECT DISTINCT Subscriber.* 
	FROM Subscriber
		INNER JOIN SubscriberAffiliate
			INNER JOIN RemoteUserRights
			On RemoteUserRights.RightsToid = SubscriberAffiliate.ParentSubscriberId
			AND RemoteUserRights.UserId = @UserId
			AND RemoteUserRights.RightsType = 'Subscriber'
		ON SubscriberAffiliate.ChildSubscriberId = Subscriber.SubscriberId
		AND @TaregtDate Between SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate
	UNION
	SELECT DISTINCT Subscriber.* 
	FROM Subscriber
		INNER JOIN RemoteUserRights
		On RemoteUserRights.RightsToid = Subscriber.SubscriberId
		AND RemoteUserRights.UserId = @UserId
		AND RemoteUserRights.RightsType = 'Subscriber'
	
	)
Go
if exists (select * from dbo.sysobjects where id = object_id(N'f530SecureCompany') and xtype in (N'FN', N'IF', N'TF'))
drop function f530SecureCompany
GO
CREATE  FUNCTION f530SecureCompany ( @UserId INT
				 )
RETURNS TABLE
AS
RETURN (SELECT DISTINCT Company.* 
	FROM Company
		INNER JOIN RemoteUserRights
		On RemoteUserRights.RightsToid = Company.CompanyId
		AND RemoteUserRights.UserId = @UserId
		AND RemoteUserRights.RightsType = 'Company'
	)
Go

if exists (select * from sysobjects where id = object_id(N'[dbo].[vwSecureCompany]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vwSecureCompany]
GO
CREATE VIEW vwSecureCompany 
AS
SELECT  Company.* 
FROM Company
	INNER JOIN RemoteUserRights
		INNER JOIN RemoteUser
		On RemoteUser.UserID = RemoteUserRights.UserId
		AND RemoteUser.UserName = Right(user,len(user) - patindex('%\%',user))
		AND RemoteUser.AuthorityLevel Like '%CompanyAdmin%'
	On RemoteUserRights.RightsToid = Company.CompanyId
	AND RemoteUserRights.RightsType = 'Company'
Go
if exists (select * from sysobjects where id = object_id(N'[dbo].[vwSecureSubscriber]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vwSecureSubscriber]
GO
CREATE VIEW vwSecureSubscriber 
AS
SELECT DISTINCT Subscriber.* 
	FROM Subscriber
		INNER JOIN SubscriberAffiliate
			INNER JOIN RemoteUserRights
				INNER JOIN RemoteUser
				On RemoteUser.UserID = RemoteUserRights.UserId
				AND RemoteUser.UserName = Right(user,len(user) - patindex('%\%',user))
			On RemoteUserRights.RightsToid = SubscriberAffiliate.ParentSubscriberId
			AND RemoteUserRights.RightsType = 'Subscriber'
		ON SubscriberAffiliate.ChildSubscriberId = Subscriber.SubscriberId
		AND GetDate() Between SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate
	UNION
	SELECT DISTINCT Subscriber.* 
	FROM Subscriber
		INNER JOIN RemoteUserRights
				INNER JOIN RemoteUser
				On RemoteUser.UserID = RemoteUserRights.UserId
				AND RemoteUser.UserName = Right(user,len(user) - patindex('%\%',user))
		On RemoteUserRights.RightsToid = Subscriber.SubscriberId
		AND RemoteUserRights.RightsType = 'Subscriber'
Go

if exists (select * from sysobjects where id = object_id(N'[dbo].[vw111SubscriberAffiliate]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw111SubscriberAffiliate]
GO
CREATE View vw111SubscriberAffiliate
AS
SELECT *
FROM SubscriberAffiliate
Go		
if exists (select * from sysobjects where id = object_id(N'[dbo].[vw550RemoteUser]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw550RemoteUser]
GO
CREATE View vw550RemoteUser
AS
SELECT UserId
	,UserName
	,EmailAddress
FROM RemoteUser
Go		
if  exists (select * from sysobjects where id = object_id(N'vw520ReportProduct') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP view vw520ReportProduct 
go
CREATE VIEW vw520ReportProduct
As
--Updated 11/6/02 - Use parent product name if reporting attributes are Null
SELECT Parent.ProductCode
	,ISNULL(Child.ProductReportName,Parent.ProductName) as ProductReportName
	,ISNULL(Child.ReportProportion,1) As ReportProportion
FROM Product Parent
	LEFT JOIN Product Child
	ON Child.ParentProductCOde = Parent.ProductCode
	AND Child.IsForReporting <> 0
WHERE Parent.IsParent <> 0
Go
if exists (select * from sysobjects where id = object_id(N'[dbo].[vw144OrderSummaryBySubscriberCategory]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw144OrderSummaryBySubscriberCategory]
Go
CREATE View vw144OrderSummaryBySubscriberCategory
AS
select SalesOrderLine.OrderNumber
	,SubscriberAffiliate.SubscriberCategory
	,CASE WHEN SalesOrderLine.IsCancel = 0 THEN '' ELSE 'Cancelled' END Cancelled
	,Sum(Quantity) AS Quantity
	,Sum(AmountProduct) AS Amount
FROM SalesOrderLine
	INNER JOIN SalesOrder
		INNER JOIN Company
		ON Company.CompanyId = SalesOrder.CompanyId
	On SalesOrder.OrderNumber = SalesOrderLine.OrderNumber
	INNER JOIN SubscriberAffiliate
	ON SubscriberAffiliate.ChildSubscriberID = SalesOrderLine.SubscriberId
WHERE Company.GroupParentSubscriberId = SubscriberAffiliate.ParentSubscriberID
GROUP BY SalesOrderLine.OrderNumber
	,SubscriberAffiliate.SubscriberCategory
	,CASE WHEN SalesOrderLine.IsCancel = 0 THEN '' ELSE 'Cancelled' END

GO
if exists (select * from sysobjects where id = object_id(N'PEPWebUsageLog') and OBJECTPROPERTY(id, N'IsView') = 1) drop view PEPWebUsageLog
Go
CREATE VIEW PEPWebUsageLog AS SELECT * FROM [PaDS_Try_Logs].dbo.PEPWebUsageLog
Go
if exists (select * from sysobjects where id = object_id(N'SessionLog') and OBJECTPROPERTY(id, N'IsView') = 1) drop view SessionLog
Go
CREATE VIEW SessionLog AS SELECT * FROM [PaDS_Try_Logs].dbo.SessionLog
Go
if exists (select * from sysobjects where id = object_id(N'AuditLog') and OBJECTPROPERTY(id, N'IsView') = 1) drop view AuditLog
Go
CREATE VIEW AuditLog AS SELECT * FROM [PaDS_Try_Logs].dbo.AuditLog
Go
if exists (select * from sysobjects where id = object_id(N'AuditTableLog') and OBJECTPROPERTY(id, N'IsView') = 1) drop view AuditTableLog
Go
CREATE VIEW AuditTableLog AS SELECT * FROM [PaDS_Try_Logs].dbo.AuditTableLog
Go
if exists (select * from sysobjects where id = object_id(N'UserActionLog') and OBJECTPROPERTY(id, N'IsView') = 1) drop view UserActionLog
Go
CREATE VIEW UserActionLog AS SELECT * FROM [PaDS_Try_Logs].dbo.UserActionLog
Go
if exists (select * from sysobjects where id = object_id(N'PEPWebSessionLog') and OBJECTPROPERTY(id, N'IsView') = 1) drop view PEPWebSessionLog
Go
CREATE VIEW PEPWebSessionLog AS SELECT * FROM [PaDS_Try_Logs].dbo.PEPWebSessionLog
Go
