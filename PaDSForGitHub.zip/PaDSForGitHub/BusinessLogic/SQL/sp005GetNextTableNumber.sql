if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp005GetNextTableNumber]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp005GetNextTableNumber]
GO

CREATE    PROCEDURE sp005GetNextTableNumber(
			@TableName as varchar(50)
			,@NextNumber INT OUTPUT)
							
AS
DECLARE @ErrorFound INT
-- Procedure 	: sp005GetNextTableNumber
-- Description	: Gets the next unique ID for a particular table
-- In      		: Name of table
-- Out       	: Next Number
-- Returns    	: 0 = Success, 1 = Error
-- Author       	Date		Comment           
-- ClaytonCragg	18/12/02	Initial code
--xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

SET @ErrorFound = 0

--seed
IF NOT EXISTS (SELECT LastNumber 
	FROM stblTableNumber 
	WHERE TableName = @TableName) 
BEGIN
    INSERT INTO stblTableNumber(TableName,LastNumber)
	VALUES(@TableName,0)
	SELECT @ErrorFound = @@Error
END

IF @ErrorFound = 0
BEGIN
	--Get
	SELECT TOP 1 @NextNumber = (LastNumber + 1) 
	FROM stblTableNumber
	WHERE TableName = @TableName
END

IF @ErrorFound = 0
BEGIN
	--SELECT @NextNumber as NextNumber
	--increment
	UPDATE stblTableNumber
	SET LastNumber = (LastNumber + 1)
	WHERE TableName = @TableName
	SELECT @ErrorFound = @@Error
END

--Basic error handling	       
Return(@ErrorFound)


go 