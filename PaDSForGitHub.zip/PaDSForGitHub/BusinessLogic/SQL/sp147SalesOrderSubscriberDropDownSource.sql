if exists (select * from dbo.sysobjects where id = object_id(N'sp147SalesOrderSubscriberDropDownSource') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	drop procedure sp147SalesOrderSubscriberDropDownSource
Go
CREATE PROCEDURE sp147SalesOrderSubscriberDropDownSource(
			@OrderNumber int
			,@PageMode VARCHAR(20) = 'Block' --'Indiviual'
			,@SourceType VARCHAR(20) = 'Rates'--'Rates','Addresses'
			)				
AS
/**********************************************
Modifications
=============
06/05/20	Julian Gates Add  Initial Version
***********************************************/
IF @SourceType = 'Rates' AND @PageMode = 'Block'
	 SELECT 
		so.OrderNumber 
		,SubscriberId=sf.ChildSubscriberID
		,pr.ProductRateId
		,pr.RateType
		,pr.DeliveryArea 
		,pr.ProductRate 
		,pr.SubscriberCategory 
		,ProductRateDescription = FORMAT(pr.ProductRate,'#,##0.##') + ' (' + pr.RateType + '/' + pr.SubscriberCategory + '/' + pr.DeliveryArea  + ')'
	 From ProductRate pr
		INNER JOIN SalesOrder so
			INNER JOIN CompanyAccount ca
			ON ca.SubscriberId = so.SubscriberId
			AND ca.CompanyId = so.CompanyId 
			INNER JOIN Company c
			ON c.CompanyId = so.CompanyId 
		ON so.PrimaryProductCode = pr.ProductCode 
		INNER JOIN SubscriberAffiliate sf
		ON sf.ParentSubscriberID = so.SubscriberId 
--14/1/21	James Woosnam	Add Date criteria to Affiliate join
		AND getdate() between sf.StartDate AND sf.EndDate 
		LEFT JOIN SubscriberAffiliate sa
		On sa.ParentSubscriberID=c.GroupParentSubscriberId
		AND sa.ChildSubscriberID = sf.ChildSubscriberId 
		AND getdate() between sa.StartDate AND sa.EndDate 

	 WHERE so.OrderNumber = @OrderNumber 
	 AND pr.AccountType = ca.AccountType 
	 AND pr.CurrencyCode = so.CurrencyCode 
	AND pr.SubscriberCategory = ISNULL(sa.SubscriberCategory ,'Ordinary')
	 ORDER BY sf.ChildSubscriberID
		,pr.productrate desc
IF @SourceType = 'Rates'  AND @PageMode = 'Individual'
	 SELECT 
		so.OrderNumber 
		,cs.SubscriberId
		,p.ProductCode 
		,pr.ProductRateId
		,pr.RateType
		,pr.DeliveryArea 
		,pr.ProductRate 
		,pr.SubscriberCategory 
		,ProductRateDescription = FORMAT(pr.ProductRate,'#,##0.##') + ' (' + pr.RateType + '/' + pr.SubscriberCategory + '/' + pr.DeliveryArea  + ')'
	 From ProductRate pr
		INNER JOIN Product p
		ON p.ProductCode = pr.ProductCode 
		INNER JOIN SalesOrder so
			INNER JOIN CompanyAccount ca
			ON ca.SubscriberId = so.SubscriberId 
			AND ca.CompanyId = so.CompanyId 
			INNER JOIN Company c
			ON c.CompanyId = so.CompanyId 
		ON so.OrderNumber = @OrderNumber 
		INNER JOIN Subscriber cs
		ON cs.SubscriberId = so.SubscriberId 

		LEFT JOIN SubscriberAffiliate sa  --Affliate of main sub to get subscriberCategory
		On sa.ParentSubscriberID=c.GroupParentSubscriberId
		AND sa.ChildSubscriberID = cs.SubscriberId 
		AND getdate() BETWEEN sa.StartDate AND sa.EndDate 
		LEFT JOIN Lookup
		ON Lookup.LookupItemKey = pr.DeliveryArea
		AND Lookup.LookupName = 'DeliveryArea'
		AND Lookup.CompanyId = so.CompanyId
	 WHERE 1=1
	 AND p.ProductStatus = 'Current'
	 AND p.IsParent = 1
	 AND pr.CurrencyCode = so.CurrencyCode 
	 AND pr.SubscriberCategory  = ISNULL(sa.SubscriberCategory,'Ordinary')
	 AND pr.AccountType = ca.AccountType 

	 ORDER BY pr.Productrate desc

IF @SourceType = 'Addresses'
	SELECT DeliveryAddressId = sa.SubscriberAddressId 
		,AddressText = sa.AddressDescription + '-' + dbo.f530SubscriberAddressDisplay(sa.SubscriberAddressId,'SingleLine') + '(' + CAST(sa.SubscriberAddressId AS VARCHAR) + ')'
		,sa.SubscriberId 
	FROM SubscriberAddress sa
		INNER JOIN SalesOrder so
		ON so.OrderNumber = @OrderNumber 
		INNER JOIN SubscriberAffiliate sf
		ON sf.ParentSubscriberID = so.SubscriberId 
		AND sf.ChildSubscriberID = sa.SubscriberId 
		AND getdate() between sf.StartDate AND sf.EndDate 
	WHERE sa.AddressType = 'Postal'
	AND sa.AddressDescription IN ('Main','Billing')
	ORDER By 2
GO
GRANT EXECUTE ON sp147SalesOrderSubscriberDropDownSource TO PaDSSQLServerUser
