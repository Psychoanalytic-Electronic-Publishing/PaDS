

DECLARE @NewDBVersion varchar(10)
DECLARE @OldDBVersion varchar(10)
DECLARE @CurrentDBVersion varchar(10)
DECLARE @SQL as varchar(8000)
DECLARE @ProcName Varchar(50)
DECLARE @ServerName varchar(100)
DECLARE @DBName varchar(100)= DB_Name()
DECLARE @Message VARCHAR(2000)
DECLARE @RowCount INT
DECLARE @v sql_variant 
DECLARE @IsAtClient BIT = 0
DECLARE @LookupId INT

IF PATINDEX('%zedra%',@@ServerName) = 0
	SET @IsAtClient = 1

SELECT @ServerName = CASE WHEN @IsAtClient = 1 THEN 'PaDS01' ELSE  @@ServerName END

DECLARE @RunningAtClient BIT = ( SELECT CASE WHEN PATINDEX('%zedra%',@ServerName)=0 THEN 1 ELSE 0 END )

SET @OldDBVersion = '2.8'
SET @NewDBVersion = '2.9'
 
IF NOT EXISTS(SELECT * FROM stblParameters WHERE ParameterName = 'DatabaseVersion') INSERT INTO stblParameters(ParameterName,ParameterType,UserID,ParameterValue) SELECT 'DatabaseVersion','System','All','01.00'  
SELECT @CurrentDBVersion = ParameterValue FROM dbo.stblParameters WHERE ParameterName = 'DatabaseVersion'
SELECT 'Current Version: ' + @CurrentDBVersion

IF NOT (@CurrentDBVersion = @OldDBVersion OR  @CurrentDBVersion = @NewDBVersion)
OR @CurrentDBVersion IS NULL
BEGIN
	SELECT 'Current DB Version ' + ISNULL(@CurrentDBVersion,'EMPTY') + ' does not match'
END
ELSE
BEGIN
BEGIN TRANSACTION 
BEGIN TRY
print 'xx'


	SET @SQL ='

	USE Pads_Logs
		IF  EXISTS(SELECT * FROM Sysobjects o where o.name = ''UserActionLog'' and o.type=''u'') DROP TABLE UserActionLog
		IF  NOT EXISTS(SELECT * FROM Sysobjects o where o.name = ''UserActionLog'' and o.type=''u'')
		BEGIN
			 CREATE TABLE UserActionLog (
				UserActionLogId INT IDENTITY(1,1),
				FromLogRecordWithId VARCHAR(20) ,
				UserSessionId varchar(50) NOT NULL,
				DateTime datetime NOT NULL,
				MonthStartDate datetime NOT NULL,
				ActionType varchar(37) NOT NULL,
				UserId int NULL,
				LoggedInMethod VARCHAR(50) NULL,
				UserType  VARCHAR(50)  NULL,
				SubscriberId int NULL,
				SubscriberName varchar(150) NULL,
				Institution_Id int NULL,
				Institution_Name varchar(150) NULL,
				Access_Type varchar(50) NOT NULL,
				Access_Method varchar(50) NOT NULL,
				Data_Type varchar(50) NULL,
				Publisher_ID varchar(50) NULL,
				Section_Type varchar(50) NULL,
				TitleId varchar(50) NULL,
				TitleName varchar(200) NULL,
				ItemId  VARCHAR(50)  NULL,
				ItemName  VARCHAR(200)  NULL,
				YOP  INT  NULL,
				ISSN  VARCHAR(50)  NULL,
				ISBN varchar(50) NULL,
				Language  VARCHAR(200)  NULL
				) ON [PRIMARY]
				ALTER TABLE dbo.UserActionLog ADD CONSTRAINT
					UserActionLog_PK PRIMARY KEY NONCLUSTERED 
					(
					UserActionLogId
					) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		END


		USE '  + @DBName
	EXECUTE(@SQL)

		IF  NOT EXISTS(SELECT * FROM Sysobjects o where o.name = 'CounterReport' and o.type='u')
		BEGIN
			 CREATE TABLE CounterReport (
				Report_ID VARCHAR(50) NOT NULL
				,Report_Name VARCHAR(100) NOT NULL
				,ReportStatus VARCHAR(20) NOT NULL
				,DisplayOrder INT NOT NULL
				,Details VARCHAR(2000)  NULL
				)
				ALTER TABLE dbo.CounterReport ADD CONSTRAINT
					CounterReport_PK PRIMARY KEY NONCLUSTERED 
					(
					Report_ID
					) WITH( STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

			SET @SQL = '
INSERT INTO CounterReport(Report_ID,Report_Name,Details,ReportStatus,DisplayOrder) SELECT ''TR'',''Title Master Report'',''A customizable report detailing activity at the title level (journal, book, etc.) that allows the�user�to apply�filters�and select other configuration options.'',''Active'',''20''
INSERT INTO CounterReport(Report_ID,Report_Name,Details,ReportStatus,DisplayOrder) SELECT ''TR_B1'',''Book Requests (Excluding OA_Gold)'',''Reports on full-text activity for books, excluding Gold�Open Access�content, as Total_Item_Requests and Unique_Title_Requests. The Unique_Title_Requests provides comparable usage across�book�platforms. The Total_Item_Requests shows overall activity; however, numbers between sites will vary significantly based on how the content is delivered (e.g. delivered as a complete�book�or by chapter).'',''Active'',''21''
INSERT INTO CounterReport(Report_ID,Report_Name,Details,ReportStatus,DisplayOrder) SELECT ''TR_B2'',''Book Access Denied'',''Reports on�Access Denied�activity for books where users were denied access because simultaneous-use licenses were exceeded or their�institution�did not have a�license�for the book.'',''Active'',''22''
INSERT INTO CounterReport(Report_ID,Report_Name,Details,ReportStatus,DisplayOrder) SELECT ''TR_B3'',''Book Usage by Access Type'',''Reports on�book�usage showing all applicable Metric_Types broken down by Access_Type.'',''Active'',''23''
INSERT INTO CounterReport(Report_ID,Report_Name,Details,ReportStatus,DisplayOrder) SELECT ''TR_J1'',''Journal Requests (Excluding OA_Gold)'',''Reports on usage of journal content, excluding Gold�Open Access�content, as Total_Item_Requests and Unique_Item_Requests. The Unique_Item_Requests provides comparable usage across journal platforms by reducing the inflationary effect that occurs when an�HTML�full text automatically displays and the�user�then accesses the�PDF�version. The Total_Item_Requests shows overall activity.'',''Active'',''24''
INSERT INTO CounterReport(Report_ID,Report_Name,Details,ReportStatus,DisplayOrder) SELECT ''TR_J2'',''Journal Access Denied'',''Reports on�Access Denied�activity for journal content where users were denied access because simultaneous-use licenses were exceeded or their�institution�did not have a�license�for the title.'',''Active'',''25''
INSERT INTO CounterReport(Report_ID,Report_Name,Details,ReportStatus,DisplayOrder) SELECT ''TR_J3'',''Journal Usage by Access Type'',''Reports on usage of journal content for all Metric_Types broken down by Access_Type.'',''Active'',''26''
INSERT INTO CounterReport(Report_ID,Report_Name,Details,ReportStatus,DisplayOrder) SELECT ''TR_J4'',''Journal Requests by YOP (Excluding OA_Gold)'',''Breaks down the usage of journal content, excluding Gold�Open Access�content, by year of publication (YOP), providing counts for the Metric_Types Total_Item_Requests and Unique_Item_Requests. Provides the details necessary to analyze usage of content in backfiles or covered by perpetual access agreement. Note that COUNTER reports do not provide access model or perpetual access rights details.'',''Active'',''27''
INSERT INTO CounterReport(Report_ID,Report_Name,Details,ReportStatus,DisplayOrder) SELECT ''PR'',''Platform Master Report'',''A customizable report summarizing activity across a content provider�s platforms that allows the�user�to applyfilters�and select other configuration options.'',''Active'',''10''
INSERT INTO CounterReport(Report_ID,Report_Name,Details,ReportStatus,DisplayOrder) SELECT ''PR_P1'',''Platform Usage'',''Platform-level usage summarized by Metric_Type.'',''Active'',''11''
'
			execute(@sql)
		END

		IF NOT EXISTS(SELECT * FROM Lookup WHERE LookupName = 'GeneralReports' AND LookupItemKey = 'PEPWebStatsPost2020')
			INSERT INTO Lookup (
LookupName
,LookupItemKey
,CompanyId
,Name
,MaintenanceGroup
,DisplayOrder
,LookupStatus
,LastUpdatedDateTime
,LastUpdatedByUserId
)
SELECT
LookupName = 'GeneralReports'
,LookupItemKey = 'PEPWebStatsPost2020'
,CompanyId = 2
,Name = 'PEP Web Usage Stats Post 2020'
,MaintenanceGroup ='System'
,DisplayOrder = 5
,LookupStatus = 'Active'
,LastUpdatedDateTime = GETDATE()
,LastUpdatedByUserId = 'jwoosnam'

UPDATE Lookup SET LookupStatus = 'InAcive' WHERE LookupItemKey = 'PEPWebStatsPreApr11' AND  LookupName = 'GeneralReports'

	----**************************
	--Set New DB Version
	
	Update stblParameters
	SET ParameterValue =CAST( @NewDBVersion AS VARCHAR)
	WHERE ParameterName = 'DatabaseVersion'
	
--*************   END TRANSACTION *********************
COMMIT TRAN
SELECT 'Transaction Commited'
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SELECT 'Transaction Rolled Back'
	SELECT @Message = 'DBUpgrade Failed - Line:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE()
	
	RAISERROR ('%s', 18, 1,@Message)

END CATCH

END
