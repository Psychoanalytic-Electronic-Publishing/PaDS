if  exists (select * from sysobjects where id = object_id(N'vw450WebProductStatistics') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP view vw450WebProductStatistics
go

CREATE VIEW vw450WebProductStatistics
As
--3/7/07	James Woosnam	Remove Test Date criteria from 2nd part of query
--23/8/07	James Woosnam	SIR1301 - Only look at current or inActive subs to stop duplicates
--18/5/2010	James Woosnam	Replace text string with SessionLog.Comment	
--19/11/19	James Woosnam	SIR4763 - Use IndividualUsers in RemoteUser table
--05/12/19	James Woosnam	SIR4769 - This is only use for Pre April 2011 stats
--
SELECT 
	AuditLog.UpdatedRecordKey ProductCode 
	,Product.ProductName 
	,MAX(SalesOrder.SubscriberId) ParentSubscriberId
	,SUBSTRING(AuditLog.[ModificationType],9,10) SubscriberId 
	,Subscriber.SubscriberName 
	,ru.UserName
	,CAST(LEFT(CONVERT(VARCHAR,AuditLog.AuditDate,13),11) as DATETIME) AS [Date]
	,Count(*) as LinkCount 
	,LinkStatus = 'Success'
	,LinkFailureReason = ''                 
FROM PaDS_Logs.dbo.AuditLog  AuditLog 
	LEFT JOIN Product  
	On Product.ProductCode = AuditLog.UpdatedRecordKey
	Left JOIN Subscriber 
		LEFT JOIN RemoteUserRights rur
			INNER JOIN RemoteUser ru
			ON ru.UserId = rur.UserId 
		ON rur.RightsToId = Subscriber.SubscriberId 
		AND rur.RightsType = 'Subscriber'
	ON Subscriber.SubscriberId = SUBSTRING(AuditLog.[ModificationType],9,10)
	Left JOIN SalesOrderLine 
		INNER JOIN SalesOrder
		ON SalesOrder.OrderNumber = SalesOrderLine.OrderNumber
	ON SalesOrderLine.SubscriberId = SUBSTRING(AuditLog.[ModificationType],9,10)
	AND SalesOrderLine.ProductCode = AuditLog.UpdatedRecordKey
WHERE AuditLog.TableName = 'WebProduct' 
GROUP BY 
	AuditLog.UpdatedRecordKey 
	,Product.ProductName 
    ,SUBSTRING(AuditLog.[ModificationType],9,10)
    ,ru.UserName
    ,Subscriber.SubscriberName 
    ,CAST(LEFT(CONVERT(VARCHAR,AuditLog.AuditDate,13),11) as DATETIME)
UNION ALL
SELECT 
	ProductCode = PageTitle 
	,ProductName = PageTitle
	,ParentSubscriberId = ParentSubscriber.SubscriberId 
	,Subscriber.SubscriberId 
	,Subscriber.SubscriberName 
	,WebUserName = sessionlog.UserName 
	,[Date] = CAST(LEFT(CONVERT(VARCHAR,sessionlog.Date,13),11) as DATETIME)
	,LinkCount = Count(*) 
	,LinkStatus = LEFT(Comment,PATINDEX('%:%',Comment))
	,LinkFailureReason = CASE WHEN LEN(Comment) > 30 THEN substring(Comment,18,PATINDEX('%at PEPProduct.%',Comment)-23)                
						ELSE '' END
FROM PaDS_Logs.dbo.sessionlog  sessionlog
	LEFT JOIN RemoteUser ru
		INNER JOIN RemoteUserRights rur
			INNER JOIN Subscriber
			ON  Subscriber.SubscriberId = rur.RightsToId
		ON rur.UserId = ru.UserId
		AND rur.RightsType = 'Subscriber'
	ON ru.UserName =  sessionlog.UserName
--23/8/07	James Woosnam	SIR1301 - Only look at current or inActive subs to stop duplicates
	AND Subscriber.SubscriberStatus IN ('Current','InActive')
	LEFT JOIN Subscriber ParentSubscriber
--18/5/2010	James Woosnam	Replace text string with SessionLog.Comment	
	On ParentSubscriber.SubscriberId = CASE WHEN ISNUMERIC(substring(SessionLog.Comment,20,LEN(SessionLog.Comment)-19)) = 1 
												THEN substring(SessionLog.Comment,20,LEN(SessionLog.Comment)-19)
										ELSE 0 END
WHERE PageTitle = 'PEPProduct'
GROUP BY PageTitle 
	,PageTitle
	,ParentSubscriber.SubscriberId 
	,Subscriber.SubscriberId 
	,Subscriber.SubscriberName 
	,Sessionlog.UserName 
	,CAST(LEFT(CONVERT(VARCHAR,sessionlog.Date,13),11) as DATETIME)
	,Comment 


Go
