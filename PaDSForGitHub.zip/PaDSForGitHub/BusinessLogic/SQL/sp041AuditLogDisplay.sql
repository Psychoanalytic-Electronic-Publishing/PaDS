if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp041AuditLogDisplay]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp041AuditLogDisplay]
GO

CREATE  PROCEDURE sp041AuditLogDisplay (
				@FltrFromDate Varchar(20)
				,@FltrToDate Varchar(20)
				,@FltrTableName Varchar(50)
				,@FltrUpdatedByUserId Varchar(50)
				,@FltrUpdatedRecordFamily Varchar(50)
				,@FltrUpdatedRecordFamilyKey Varchar(50)
				,@FltrUpdatedRecordKey Varchar(100)
				,@FltrModificationType Varchar(20)
				,@RecordsRequired INT   = 50 	--Number of recods to return
				,@ReturnTotalRecordCount INT = 0 --1 if we need to count all records
				)
AS
-- =============================================
-- Author:		Julian Gates
-- Create date: 19 Aug 2020
-- Description:	GetsAuditLogList
-- =============================================
set nocount on
set arithignore on
DECLARE @ReturnError INT
DECLARE @From VARCHAR(2000)
DECLARE @Where VARCHAR(2000)
DECLARE @Columns VARCHAR(2000)
DECLARE @SQL VARCHAR(4000)
DECLARE @LF Varchar(5)
DECLARE @Today Varchar(11)
DECLARE @Records INT
DECLARE @RecordCount INT

SET @Today = CONVERT(Varchar(11),GetDate(),13)
SET @LF = CHAR(13) + CHAR(10)

SET @Where = ' WHERE a.DatabaseName = db_name() '

-- Filter on paramaters, if passed in
If ISNULL(@FltrFromDate,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND a.AuditDate >= ''' + @FltrFromDate + '''' + @LF
END
If ISNULL(@FltrToDate,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND a.AuditDate <= ''' + @FltrToDate + '''' + @LF
END
If ISNULL(@FltrTableName,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND a.TableName like ''%' + @FltrTableName + '%''' + @LF
END
If ISNULL(@FltrUpdatedByUserId,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND a.UpdatedByUserId like ''%' + @FltrUpdatedByUserId + '%''' + @LF
END
If ISNULL(@FltrUpdatedRecordFamily,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND a.UpdatedRecordFamily = ''' + @FltrUpdatedRecordFamily + '''' + @LF
END
If ISNULL(@FltrUpdatedRecordFamilyKey,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND a.UpdatedRecordFamilyKey = ''' + @FltrUpdatedRecordFamilyKey + '''' + @LF
END
If ISNULL(@FltrUpdatedRecordKey,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND a.UpdatedRecordKey like ''%' + @FltrUpdatedRecordKey + '%''' + @LF
END
If ISNULL(@FltrModificationType,'') <> '' 
BEGIN
	SET @Where = @Where + ' AND a.ModificationType like ''%' + @FltrModificationType + '%''' + @LF
END

SET @From = '		
	FROM AuditTableLog a
	
			' + @Where	

IF @ReturnTotalRecordCount = 1
BEGIN
	--Count records into Temp table
	CREATE TABLE #RecordCount(RecordCount INT)

	SET @SQL = '
	INSERT INTO #RecordCount
	SELECT (SELECT Count1=COUNT(*)  

				FROM (Select 1 Num ' + @From + ') ResultSet)
	'			
	execute (@SQL)
	SELECT @RecordCount = RecordCount
	FROM #RecordCount
END
ELSE
BEGIN
	SELECT @RecordCount = -1
END
Print 100
Print @SQL
--select columns to show
SELECT @Columns = '
	SELECT  Top '  + CAST(@RecordsRequired as VARCHAR) + '
		TotalRecordCount = ' + CAST(@RecordCount as VARCHAR) 

		
SET @Columns = @Columns + '
		,a.AuditDate
		,a.TableName
		,a.UpdatedByUserId
		,a.UpdatedRecordFamily 
		,a.UpdatedRecordFamilyKey 
		,a.UpdatedRecordKey
		,a.ModificationType
		,a.BeforeDescription
		,a.AfterDescription
		,dbo.fn042GetColumnNames(a.TableName) As ColumnNames
	'

SET @From = @From + '
		ORDER BY a.AuditDate Desc'

--Now Run the query
SET @SQL =  @Columns
			+ @From
print @SQL
execute (@SQL)
SELECT @ReturnError = @@Error, @Records= @@ROWCOUNT 
IF @ReturnError <> 0
BEGIN
	SELECT ReturnError=@ReturnError
		,ReturnMessage=master..sysmessages.description 
		from master..sysmessages where error=@returnerror
	RETURN
END	
set nocount off
set arithignore off

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO