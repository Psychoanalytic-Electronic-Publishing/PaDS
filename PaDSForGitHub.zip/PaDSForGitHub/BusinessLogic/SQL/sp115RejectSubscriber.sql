if exists (select * from dbo.sysobjects where id = object_id(N'sp115RejectSubscriber') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp115RejectSubscriber
GO
CREATE  PROCEDURE sp115RejectSubscriber (
				 @SubscriberId INT  
				)
AS
--10/1/20	James Woosnam	SIR4977 - Initial version
DECLARE @Message VARCHAR(MAX)=''
DECLARE @UpdateToSubscriberId INT = (SELECT UpdateToSubscriberId FROM Subscriber WHERE SubscriberId = @SubscriberId )
BEGIN TRAN
BEGIN TRY
	UPDATE Subscriber SET SubscriberStatus='Rejected' WHERE SubscriberId = @SubscriberId
	IF @UpdateToSubscriberId IS NOT NULL
	BEGIN
		UPDATE RemoteUserRights 
		SET RightsToId = @UpdateToSubscriberId
		WHERE RightsToId = @SubscriberId
		UPDATE RemoteUser
		SET UserName = ru.UserNameBeforeProposed
		,EmailAddress = sa.AddressText 
		FROM RemoteUser ru
			INNER JOIN RemoteUserRights rur
				LEFT JOIN SubscriberAddress sa
				ON sa.SubscriberId = rur.RightsToId 
				AND sa.AddressType = 'Email'
				AND sa.AddressDescription = 'Main'
			ON rur.UserId = ru.UserId
			AND rur.RightsType = 'Subscriber'
		WHERE rur.RightsToId = @UpdateToSubscriberId
	END
	ELSE
	BEGIN
		UPDATE RemoteUser 
		SET UserStatus = 'InActive'
		FROM RemoteUser ru
			INNER JOIN RemoteUserRights rur
			ON rur.UserId = ru.UserId
			AND rur.RightsType = 'Subscriber'
		WHERE rur.RightsToId = @SubscriberId 
	END
	COMMIT TRAN
END TRY
BEGIN CATCH
	ROLLBACK TRAN		
	SELECT @Message = 'Subscriber Insert Failed - ' + ERROR_MESSAGE()
	RAISERROR (@Message, 16, 1)
END CATCH

GO
