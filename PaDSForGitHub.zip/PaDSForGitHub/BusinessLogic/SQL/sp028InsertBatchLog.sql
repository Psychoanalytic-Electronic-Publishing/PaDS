if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].sp028InsertBatchLog') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].sp028InsertBatchLog
GO

CREATE PROCEDURE sp028InsertBatchLog(
						@BatchLogType Varchar(20)
						,@Description varchar(200)
						,@BatchJobId INT
						,@SubmittedByUserSessionId uniqueIdentifier = NULL
						,@BatchLogId INT OUTPUT
										)
AS
/* 	Added the batch log with a new log messge 
Oct 2008		James Woosnam	Initial Version
*/
DECLARE @Error INT

EXEC @Error = sp005GetNextTableNumber @TableName ='BatchLod', @NextNumber = @BatchLogId OUTPUT

IF @Error = 0
BEGIN
	IF Exists(SELECT BatchLogId
				FROM BatchLog
				WHERE BatchLogId = @BatchLogId)
	BEGIN
		  RAISERROR ('Failed. sp028InsertBatchLog - Batch Log %8.0i already exists', 18, 1, @BatchLogId)
	END 
END

IF @Error = 0
BEGIN
	INSERT INTO BatchLog
			(BatchLogId
			,BatchLogType
			,Description
			,BatchLogStatus
			,SubmittedByUserSessionId
			,DateTime
			,BatchJobId )
	SELECT @BatchLogID
			,@BatchLogType
			,@Description
			,'Started'
			,@SubmittedByUserSessionId
			,GetDate()
			,@BatchJobId 
	SET @Error =@@Error
	IF @Error <> 0
	BEGIN
	  RAISERROR ('Failed. sp028InsertBatchLog - BatchLog Insert ', 16, 1)
	END
END
	
IF @Error = 0
BEGIN
	EXEC @Error = sp029UpdateBatchLog @BatchLogID = @BatchLogID,@LogMessage =  'Batch Started'
END

RETURN(@Error)
GO 