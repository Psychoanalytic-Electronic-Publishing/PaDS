if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[fn042GetColumnNames]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[fn042GetColumnNames]
GO
SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO
CREATE FUNCTION dbo.fn042GetColumnNames ( @TableName varchar(50))
RETURNS Varchar(2000)
AS
BEGIN
DECLARE @Out VARCHAR(2000)
DECLARE @ColumnName varchar(255)

SET @ColumnName = ''
SET @Out = '' 

DECLARE cur CURSOR FOR
SELECT SysColumns.Name    
	SysObjects
FROM SysColumns
	INNER JOIN SysObjects
	ON  SysObjects.id = SysColumns.id
	AND SysObjects.xType = 'U'
Where SysObjects.Name = @TableName
--20/10/20     James   ****** The Excluded Trigger Columns are also mentioned in PaDSSupportUtilities.DBColumns - KEEP IN SYNC
AND SysColumns.Name NOT IN ('LastUpdatedDateTime','LastUpdatedByUserId', 'PasswordRetryAttempts', 'LastLoggedOn','PEPWebClientSettings')
ORDER BY ColOrder
Open cur 
FETCH cur 
INTO @ColumnName
WHILE @@FETCH_STATUS = 0 
BEGIN
	SET @Out =  @Out + @ColumnName + ',' 
	FETCH cur 
	INTO @ColumnName
END
SET @Out = Left(@Out,Len(@Out)-1)
CLOSE cur 
DEALLOCATE cur 
RETURN ( @Out)

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO
 