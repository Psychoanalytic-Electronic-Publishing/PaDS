if exists (select * from dbo.sysobjects where id = object_id(N'sp006RebuildIndexes') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp006RebuildIndexes
GO
CREATE PROCEDURE sp006RebuildIndexes (@DBName VARCHAR(100)
									,@ReportOnly BIT = 0
									,@RebuildIfFragmentationGreaterThan INT = 30
									,@ReorganiseIfFragmentationGreaterThan INT = 5
									,@SkipIfPageCountLessThan INT = 50
									,@LogMessage VARCHAR(MAX) = '' OUTPUT 
										)
AS

DECLARE @Message VARCHAR(1000) = ''
DECLARE @SQL VARCHAR(8000) = ''
DECLARE @BatchLogCreatedHere BIT = 0

SET @LogMessage = ISNULL(@LogMessage ,'')

	SET @Message = LEFT(
			'Database:' + @DBName 
			+ ' Server:' + @@ServerName 
				,100)
	SET @LogMessage += CHAR(13) + CHAR(10) + FORMAT(GETDATE(),'HH:mm:ss') + '-' + @Message
	SET @Message = LEFT(
			' ReportOnly>:' + CAST(@ReportOnly AS VARCHAR)
			+ ' RebuildFrag>:' + CAST(@RebuildIfFragmentationGreaterThan AS VARCHAR)
			+ ' ReorgFrag>:' + CAST(@ReorganiseIfFragmentationGreaterThan AS VARCHAR)
			+ ' SkipPg<:' + CAST(@SkipIfPageCountLessThan AS VARCHAR)
				,100)
	SET @LogMessage +=  CHAR(13) + CHAR(10) + FORMAT(GETDATE(),'HH:mm:ss') + '-' + @Message
BEGIN TRY
	--DROP TABLE #Tables
	CREATE TABLE #Tables (
		TableName VARCHAR(200) 
		,IndexName VARCHAR(200) 
		,Fragmentation FLOAT
		,PagesCount INT
		,ActionType VARCHAR(20)
		)

	SET @SQL =	'
		INSERT INTO #Tables (
			TableName
			,IndexName
			,Fragmentation
			,PagesCount
			)
		SELECT 
			TableName = dbtables.[name]
			,IndexName = dbindexes.[name]
			,Fragmentation = indexstats.avg_fragmentation_in_percent
			,PagesCount = indexstats.page_count
		FROM ' + @DBName + '.sys.dm_db_index_physical_stats (DB_ID(N''' + @DBName + '''), NULL, NULL, NULL, NULL) AS indexstats
			INNER JOIN ' + @DBName + '.sys.tables dbtables 
			on dbtables.[object_id] = indexstats.[object_id]
			INNER JOIN ' + @DBName + '.sys.indexes AS dbindexes 
			ON dbindexes.[object_id] = indexstats.[object_id]
			AND indexstats.index_id = dbindexes.index_id
		WHERE dbindexes.type in (1,2) -- indexstats.database_id = DB_ID()
		ORDER BY indexstats.avg_fragmentation_in_percent desc
	'
	EXEC(@SQL)

	UPDATE #Tables 
	SET ActionType = CASE WHEN Fragmentation > @ReorganiseIfFragmentationGreaterThan 
				AND Fragmentation <=  @RebuildIfFragmentationGreaterThan 
				AND PagesCount >= @SkipIfPageCountLessThan
			THEN 'REORGANIZE'
		WHEN Fragmentation > @RebuildIfFragmentationGreaterThan 
				AND PagesCount >= @SkipIfPageCountLessThan
			THEN 'REBUILD'
	ELSE 'None'
	END

	SELECT @Message = CAST((SELECT COUNT(*) FROM #Tables WHERE ActionType = 'REORGANIZE') AS VARCHAR)  + ' indexes to be reorganised';	SET @LogMessage +=  CHAR(13) + CHAR(10) + FORMAT(GETDATE(),'HH:mm:ss') + '-' + @Message
	IF @ReportOnly = 1 select @Message
	SELECT @Message = CAST((SELECT COUNT(*) FROM #Tables WHERE ActionType = 'REBUILD') AS VARCHAR)  + ' indexes to be rebuilt';	SET @LogMessage +=  CHAR(13) + CHAR(10) + FORMAT(GETDATE(),'HH:mm:ss') + '-' + @Message
	IF @ReportOnly = 1 select @Message
	IF @ReportOnly = 0
	BEGIN
		DECLARE @TableName VARCHAR(200) 
		DECLARE @IndexName VARCHAR(200) 
		DECLARE @ActionType VARCHAR(200) 
		DECLARE @Fragmentation Float 
		
		DECLARE cur CURSOR FOR
		SELECT DISTINCT
			TableName
			,IndexName
			,Fragmentation
			,ActionType
		FROM #Tables
		WHERE Fragmentation > @ReorganiseIfFragmentationGreaterThan
		AND PagesCount >= @SkipIfPageCountLessThan
		Open cur 
		FETCH cur INTO @TableName,@IndexName,@Fragmentation,@ActionType
		WHILE @@FETCH_STATUS = 0 
		BEGIN
			SET @SQL =	'ALTER INDEX ' + @IndexName + ' ON ' + @DBName + '..' + @TableName + ' ' + @ActionType

			BEGIN TRY
				EXEC(@SQL)
			print @sql
				SELECT @Message = @TableName + '.' + @IndexName + ' ' + @ActionType + ' Complete. Fragmentation:' + CAST(@Fragmentation as VARCHAR)
			END TRY
			BEGIN CATCH
				SELECT @Message = @TableName + '.' + @IndexName + ' ' + @ActionType + ' FAILED:'+ ' ' + ERROR_MESSAGE()
			END CATCH
			SET @LogMessage +=  CHAR(13) + CHAR(10) + FORMAT(GETDATE(),'HH:mm:ss') + '-' + @Message
	
			FETCH cur INTO @TableName,@IndexName,@Fragmentation,@ActionType
		END
		CLOSE cur 
		DEALLOCATE cur 

		SET @SQL =	'EXEC ' + @DBName + '..sp_updatestats'
		BEGIN TRY
			EXEC(@SQL)
			SELECT @Message = 'sp_updatestats Complete'
		END TRY
		BEGIN CATCH
			SELECT @Message = 'sp_updatestats Complete FAILED:'+ ' ' + ERROR_MESSAGE()
		END CATCH
		SET @LogMessage +=  CHAR(13) + CHAR(10) + FORMAT(GETDATE(),'HH:mm:ss') + '-' + @Message
	END
	ELSE
	BEGIN
		Select * from #Tables order by 1,2,3
	END

	SELECT @Message = 'Rebuild Table Indexes Complete'
	SET @LogMessage +=  CHAR(13) + CHAR(10) + FORMAT(GETDATE(),'HH:mm:ss') + '-' + @Message
END TRY
BEGIN CATCH

	SELECT @Message = 'Rebuild Table Indexes Failed: ' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE()

	SET @LogMessage +=  CHAR(13) + CHAR(10) + FORMAT(GETDATE(),'HH:mm:ss') + '-' + @Message
	
	RAISERROR ('%s', 18, 1,@Message)
END CATCH
GO

