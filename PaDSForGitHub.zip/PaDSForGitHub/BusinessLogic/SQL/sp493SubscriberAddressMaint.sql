if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp493SubscriberAddressMaint') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp493SubscriberAddressMaint
GO
CREATE PROCEDURE sp493SubscriberAddressMaint(
						@SubscriberId INT
						,@AddressType varchar(20)
						,@AddressDescription varchar(20)
						,@AddressText varchar(255)  --Non postal only
						,@Address1 varchar(50) = NULL
						,@Address2 varchar(50) = NULL
						,@Address3 varchar(50) = NULL
						,@Address4 varchar(50) = NULL
						,@Town varchar(50) = NULL
						,@County varchar(50) = NULL
						,@PostCode varchar(16) = NULL
						,@CountryId INT = NULL
						,@UserName varchar(50)
						,@ReturnCode INT OUTPUT
						,@ErrorMessage varchar(200) OUTPUT
				
									)
AS

DECLARE @ErrorCode INT
DECLARE @ErrorFound INT
DECLARE @ProcName varchar(50)
DECLARE @ROWCOUNT INT
DECLARE @Message VARCHAR(2000)
DECLARE @Today DATETIME
SET @ReturnCode = 0
SET @ErrorFound = 0
SET @ProcName = 'sp484SubscriberImportAddressMaint'

SET @Today = CAST(CONVERT(varchar(11),GETDATE(),13) as DATETIME)
DECLARE @CountryName  varchar(50)

IF @ErrorFound = 0
BEGIN
	SELECT @CountryName = CountryName
	FROM Country
	WHERE CountryId = @CountryId
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END

IF @ErrorFound = 0
BEGIN
	SELECT @AddressText = LEFT( 
			CASE @AddressType 
			WHEN 'Postal' THEN	
				CASE WHEN ISNULL(@Address1,'') <> '' THEN @Address1 + ', ' ELSE '' END
				+	CASE WHEN ISNULL(@Address2,'') <> '' THEN @Address2 + ', '  ELSE '' END
				+	CASE WHEN ISNULL(@Address3,'') <> '' THEN @Address3 + ', '  ELSE '' END
				+	CASE WHEN ISNULL(@Address4,'') <> '' THEN @Address4 + ', '  ELSE '' END
				+	CASE WHEN ISNULL(@Town,'') <> '' THEN @Town + ', '  ELSE '' END
				+	CASE WHEN ISNULL(@County,'') <> '' THEN @County + ', '  ELSE '' END
				+	CASE WHEN ISNULL(@PostCode,'') <> '' THEN @PostCode + ', '  ELSE '' END
				+	CASE WHEN ISNULL(@CountryName,'') <> '' THEN @CountryName   ELSE '' END 
			ELSE @AddressText END
					,255)
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END

DECLARE @SubscriberAddressId INT
SET @SubscriberAddressId = 0
IF @ErrorFound = 0
BEGIN
	SELECT @SubscriberAddressId = SubscriberAddressId
	FROM SubscriberAddress
	WHERE SubscriberId = @SubscriberId
	AND AddressType = @AddressType
	AND AddressDescription = @AddressDescription
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
IF @SubscriberAddressId = 0
AND @ErrorFound = 0
BEGIN
	Exec dbo.sp005GetNextTableNumber 'SubscriberAddress',@SubscriberAddressId OUTPUT
	IF @AddressType = 'Postal'
	BEGIN
		INSERT INTO SubscriberAddress
			(SubscriberAddressId
			,SubscriberId
			,AddressType
			,AddressDescription
			,AddressText
			,CountryId
			,Address1
			,Address2
			,Address3
			,Address4
			,Town
			,County
			,PostCode
			,CreatedDateTime
			,CreatedByUserId
			,LastUpdatedDateTime
			,LastUpdatedByUserId )
		VALUES ( 
			@SubscriberAddressId
			,@SubscriberId
			,@AddressType
			,@AddressDescription
			,LEFT(
				CASE WHEN ISNULL(@Address1,'') <> '' THEN @Address1 + ', ' ELSE '' END
				+	CASE WHEN ISNULL(@Address2,'') <> '' THEN @Address2 + ', '  ELSE '' END
				+	CASE WHEN ISNULL(@Address3,'') <> '' THEN @Address3 + ', '  ELSE '' END
				+	CASE WHEN ISNULL(@Address4,'') <> '' THEN @Address4 + ', '  ELSE '' END
				+	CASE WHEN ISNULL(@Town,'') <> '' THEN @Town + ', '  ELSE '' END
				+	CASE WHEN ISNULL(@County,'') <> '' THEN @County + ', '  ELSE '' END
				+	CASE WHEN ISNULL(@PostCode,'') <> '' THEN @PostCode + ', '  ELSE '' END
				+	CASE WHEN ISNULL(@CountryName,'') <> '' THEN @CountryName   ELSE '' END ,255)
			,@CountryId
			,@Address1
			,@Address2
			,@Address3
			,@Address4
			,@Town
			,@County
			,@PostCode
			, GETDATE()
			,@UserName
			,GetDate()
			,@UserName
			)
		--FROM tmpSubscriberImport
		--WHERE tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
		SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	END
	ELSE --non postal
	BEGIN	

		INSERT INTO SubscriberAddress
			(SubscriberAddressId
			,SubscriberId
			,AddressType
			,AddressDescription
			,AddressText
			,CountryId
			,CreatedDateTime
			,CreatedByUserId
			,LastUpdatedDateTime
			,LastUpdatedByUserId )
		VALUES ( @SubscriberAddressId
			,@SubscriberId
			,@AddressType
			,@AddressDescription
			,@AddressText
			,@CountryId 
			,GETDATE()
			,@UserName
			,GetDate()
			,@UserName
				)
		SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	END
END
ELSE
--Address already exisits
BEGIN
	IF @AddressType = 'Postal'
	BEGIN
		UPDATE SubscriberAddress
		SET 
			AddressText = @AddressText
			,CountryId = @CountryId
			,Address1 = ISNULL(@Address1,'')
			,Address2 = ISNULL(@Address2,'')
			,Address3 = ISNULL(@Address3,'')
			,Address4 = ISNULL(@Address4,'')
			,Town = ISNULL(@Town,'')
			,County = ISNULL(@County,'')
			,PostCode = ISNULL(@PostCode,'')
			,LastUpdatedDateTime = GETDATE()
			,LastUpdatedByUserId = @UserName
		FROM SubscriberAddress 
		WHERE SubscriberAddressId = @SubscriberAddressId
		SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	END
	ELSE --non postal
	BEGIN
		UPDATE SubscriberAddress
		SET 
			AddressText = @AddressText
			,CountryId = @CountryId
			,LastUpdatedDateTime = GETDATE()
			,LastUpdatedByUserId = @UserName
		FROM SubscriberAddress 
		WHERE SubscriberAddressId = @SubscriberAddressId
		SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	END
END


If @ReturnCode = 0 
	--If an error been found with no return code then set the returncode to the ErrorCode
	SET @ReturnCode = @ErrorFound

RETURN (@ReturnCode)
