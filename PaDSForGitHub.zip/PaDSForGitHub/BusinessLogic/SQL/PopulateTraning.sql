--17/10/05	James Woosnam	Don't uer stbleNumber for Productrate
--7/12/05	James Woosnam delete orders belonging direct to John Smith
--16/05/19  Julian Gates    SIR4759 - Set all telephone numbers to ''

BEGIN TRANSACTION

Declare @CompanyId INT
Declare @SubscriberId Int
Declare @SubscriberAddressId Int
Declare @ProductRateid Int
Declare @FirstName varchar(50)
Declare @LastName varchar(50)
Declare @ProductCode varchar(20)
Declare @userId Int

--**********User Start ************
Set @userId = 2 --Generic Remote User
Delete from remoteuserRights where userid = @userId
Delete from remoteuser where userid = @userId
INSERT INTO Remoteuser
(	UserId		,UserName	,[Password]	,ValidUntil	,AuthorityLevel	)
 VALUES (@userId		,'Generic Remote User'	,'njsdnslkl'	,'01/01/3000'	,'User')
--*********User End *****************************

--**********User Start ************
Set @userId = 3 --PaDS Federation
Delete from remoteuserRights where userid = @userId
Delete from remoteuser where userid = @userId
INSERT INTO Remoteuser
(	UserId		,UserName	,[Password]	,ValidUntil	,AuthorityLevel	)
 VALUES (@userId		,'TRFed'	,'trfed'	,'01/01/3000'	,'CompanyAdmins')
INSERT INTO RemoteuserRights
(	UserId		,RightsType	,RightsToId)
 VALUES (@userId	,'Company'	,3)
INSERT INTO RemoteuserRights
(	UserId		,RightsType	,RightsToId)
 VALUES (@userId	,'Subscriber'	,29801)
--*********User End *****************************

--**********User Start ************
Set @userId = 4  --PaDS Journal
Delete from remoteuserRights where userid = @userId
Delete from remoteuser where userid = @userId
INSERT INTO Remoteuser
(	UserId		,UserName	,[Password]	,ValidUntil	,AuthorityLevel	)
 VALUES (@userId		,'TRJour'	,'trjour'	,'01/01/3000'	,'CompanyAdmins')
INSERT INTO RemoteuserRights
(	UserId		,RightsType	,RightsToId)
 VALUES (@userId	,'Company'	,4)
INSERT INTO RemoteuserRights
(	UserId		,RightsType	,RightsToId)
 VALUES (@userId	,'Subscriber'	,29802)
--*********User End *****************************

--**********User Start ************
Set @userId = 6 --PaDS England Group User
Delete from remoteuserRights where userid = @userId
Delete from remoteuser where userid = @userId
INSERT INTO Remoteuser
(	UserId		,UserName	,[Password]	,ValidUntil	,AuthorityLevel	)
 VALUES (@userId		,'TRWales'	,'trwales'	,'01/01/3000'	,'GroupAdmins')
INSERT INTO RemoteuserRights
(	UserId		,RightsType	,RightsToId)
 VALUES (@userId	,'Company'	,3)
INSERT INTO RemoteuserRights
(	UserId		,RightsType	,RightsToId)
 VALUES (@userId	,'Subscriber'	,29804)
--*********User End *****************************
--**********User Start ************
Set @userId = 7 --PaDS England Group User
Delete from remoteuserRights where userid = @userId
Delete from remoteuser where userid = @userId
/*
Removed in favour of new subscriber security
INSERT INTO Remoteuser
(	UserId		,UserName	,[Password]	,ValidUntil	,AuthorityLevel	)
 VALUES (@userId		,'TRSmith'	,'trsmith'	,'01/01/3000'	,'User')
INSERT INTO RemoteuserRights
(	UserId		,RightsType	,RightsToId)
 VALUES (@userId	,'Company'	,3)
INSERT INTO RemoteuserRights
(	UserId		,RightsType	,RightsToId)
 VALUES (@userId	,'Company'	,4)
INSERT INTO RemoteuserRights
(	UserId		,RightsType	,RightsToId)
 VALUES (@userId	,'Subscriber'	,29811)
*/
--*********User End *****************************

--*******  Company Start **************
SET @CompanyId = 3
Delete Cashbook where Companyid = @CompanyId
Delete BankDeposit where Companyid = @CompanyId
--Delete SalesOrderLinePart where Companyid = @CompanyId
Delete SalesOrderLine FROM SalesOrderLine 
	INNER Join SalesOrder
	On SalesOrder.OrderNumber  = SalesOrderLine.OrderNumber
  WHERE Companyid = @CompanyId
Delete SalesOrder where Companyid = @CompanyId
DELETE DespatchDeliveryArea WHERE Companyid = @CompanyId
DELETE CurrencyConversionRate WHERE Companyid = @CompanyId
DELETE Product WHERE Companyid = @CompanyId
Delete CompanyAccount where Companyid = @CompanyId
Delete CompanyBankAccount where Companyid = @CompanyId
Delete Company where Companyid = @CompanyId

INSERT INTO Company
(CompanyId,CompanyName,CompanyOfficer,CurrencyCode,BuildingStreet,Town,County,PostCode,CountryId,TelephoneNumber,FaxNumber,Email,RegisteredOfficeName,RegisteredOfficeBuildingStreet,RegisteredOfficeTown,RegisteredOfficeCounty,RegisteredOfficePostCode,RegisteredOfficeCountryId,RegisteredOfficeTelephoneNumber,RegisteredOfficeFaxNumber,RegistrationNumber,Notes,VATCode,VATNumber,LimitedCompanyNumber,RegisteredCharityNumber,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId,GroupParentSubscriberId)
 VALUES (@CompanyId,'International PaDS Federation','James Woosnam','GBP','Estate Office, Western COurt','Alresford','Hampshire','SO21 1EP',58,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,58,NULL,NULL,NULL,NULL,NULL,'','','','1/1/2002','JWOOSNAM','1/1/02','JWOOSNAM',29801)
INSERT INTO CompanyBankAccount
(CompanyId,BankSortCode,BankAccountNumber,BankAccountName,CurrencyCode,CountryID,BankName,BankBuildingStreet,BankTown,BankCounty,BankPostCode,BankTelephoneNumber,BankFaxNumber,Notes,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@CompanyId,'99-22-33','002100','International PaDS Federation GBP','GBP',58,'Flemmings','xx','London',NULL,'SW1',NULL,NULL,NULL,'1/1/2002','JWOOSNAM','1/1/02','JWOOSNAM')
INSERT INTO CompanyBankAccount
(CompanyId,BankSortCode,BankAccountNumber,BankAccountName,CurrencyCode,CountryID,BankName,BankBuildingStreet,BankTown,BankCounty,BankPostCode,BankTelephoneNumber,BankFaxNumber,Notes,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@CompanyId,'56548','92496241','International PaDS Federation USD','USD',58,'BofA','xx','New York',NULL,'SW1',NULL,NULL,NULL,'1/1/2002','JWOOSNAM','1/1/02','JWOOSNAM')
--*******  Company End **************

--************ NEW PRODCUT Start
Set @ProductCode = 'PaDS01'
INSERT INTO Product
(ProductCode	,ProductName	,ProductStatus	,CompanyID	,IsParent	,ReleaseDate	,ParentProductCode	,ProductShortName	,IsForReporting	,ReportProportion	,ProductReportName	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@ProductCode,'PaDS Federation Subscription'	,'Current'	,@CompanyId	,1		,'01/01/2002'	,'Fed Sub'			,@ProductCode		,0		,NULL			,NULL			,'06/09/1999 17:03:30'	,'jwoosnam'		,'12/01/2002 09:57:00'	,'Jwoosnam')
INSERT INTO Product
(ProductCode	,ProductName	,ProductStatus	,CompanyID	,IsParent	,ReleaseDate	,ParentProductCode	,ProductShortName	,IsForReporting	,ReportProportion	,ProductReportName	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES ('PaDS01c1','Feb Sub 1','Current'	,@CompanyId	,0	,'01/01/2002'	,@ProductCode		,'PaDS01c1'		,1		,1			,@ProductCode 		,'06/09/1999 17:03:30'	,'jwoosnam'		,'12/01/2002 09:57:00'	,'Jwoosnam')

SET @ProductRateid = (Select LastNumber + 1 FROM stblTableNumber WHere TableName = 'ProductRate') 
INSERT INTO ProductRate
(	ProductRateId	,ProductCode	,CurrencyCode	,RateType	,AccountType	,SubscriberCategory	,DeliveryArea	,ProductRate	,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@ProductRateid	,@ProductCode	,'GBP'		,'Full'		,'Society'	,'Ordinary'		,'All'		,75.00	,'20/12/2001 09:28:05','jwoosnam','20/12/2001 09:28:05','jwoosnam')
SET @ProductRateid = @ProductRateid + 1
INSERT INTO ProductRate
(	ProductRateId	,ProductCode	,CurrencyCode	,RateType	,AccountType	,SubscriberCategory	,DeliveryArea	,ProductRate	,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@ProductRateid	,@ProductCode	,'GBP'		,'Full'		,'Society'	,'Institutional'		,'All'		,120.00	,'20/12/2001 09:28:05','jwoosnam','20/12/2001 09:28:05','jwoosnam')
SET @ProductRateid = @ProductRateid + 1
INSERT INTO ProductRate
(	ProductRateId	,ProductCode	,CurrencyCode	,RateType	,AccountType	,SubscriberCategory	,DeliveryArea	,ProductRate	,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@ProductRateid	,@ProductCode	,'USD'		,'Full'		,'Society'	,'Ordinary'		,'All'		,40.00	,'20/12/2001 09:28:05','jwoosnam','20/12/2001 09:28:05','jwoosnam')
SET @ProductRateid = @ProductRateid + 1
INSERT INTO ProductRate
(	ProductRateId	,ProductCode	,CurrencyCode	,RateType	,AccountType	,SubscriberCategory	,DeliveryArea	,ProductRate	,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@ProductRateid	,@ProductCode	,'USD'		,'Full'		,'Society'	,'Institutional'		,'All'		,90.00	,'20/12/2001 09:28:05','jwoosnam','20/12/2001 09:28:05','jwoosnam')
SET @ProductRateid = @ProductRateid + 1
INSERT INTO ProductRate
(	ProductRateId	,ProductCode	,CurrencyCode	,RateType	,AccountType	,SubscriberCategory	,DeliveryArea	,ProductRate	,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@ProductRateid	,@ProductCode	,'GBP'		,'Full'		,'Individual'	,'Ordinary'		,'All'		,100.00	,'20/12/2001 09:28:05','jwoosnam','20/12/2001 09:28:05','jwoosnam')
SET @ProductRateid = @ProductRateid + 1
INSERT INTO ProductRate
(	ProductRateId	,ProductCode	,CurrencyCode	,RateType	,AccountType	,SubscriberCategory	,DeliveryArea	,ProductRate	,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@ProductRateid	,@ProductCode	,'USD'		,'Full'		,'Individual'	,'Ordinary'		,'All'		,60.00	,'20/12/2001 09:28:05','jwoosnam','20/12/2001 09:28:05','jwoosnam')

Update stblTableNumber Set LastNumber = @ProductRateid WHere TableName = 'ProductRate'
--************ NEW PRODCUT End

--*******  Company Start **************
SET @CompanyId = 4
Delete Cashbook where Companyid = @CompanyId
Delete BankDeposit where Companyid = @CompanyId
--Delete SalesOrderLinePart where Companyid = @CompanyId
--Delete SalesOrderLine where Companyid = @CompanyId
Delete SalesOrder where Companyid = @CompanyId
DELETE DespatchDeliveryArea WHERE Companyid = @CompanyId
DELETE CurrencyConversionRate WHERE Companyid = @CompanyId
DELETE Product WHERE Companyid = @CompanyId
Delete CompanyAccount where Companyid = @CompanyId
Delete CompanyBankAccount where Companyid = @CompanyId
Delete Company where Companyid = @CompanyId

INSERT INTO Company
(CompanyId,CompanyName,CompanyOfficer,CurrencyCode,BuildingStreet,Town,County,PostCode,CountryId,TelephoneNumber,FaxNumber,Email,RegisteredOfficeName,RegisteredOfficeBuildingStreet,RegisteredOfficeTown,RegisteredOfficeCounty,RegisteredOfficePostCode,RegisteredOfficeCountryId,RegisteredOfficeTelephoneNumber,RegisteredOfficeFaxNumber,RegistrationNumber,Notes,VATCode,VATNumber,LimitedCompanyNumber,RegisteredCharityNumber,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId,GroupParentSubscriberId)
 VALUES (@CompanyId,'PaDS Journal','James Woosnam','GBP','Estate Office, Western COurt','Alresford','Hampshire','SO21 1EP',58,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,58,NULL,NULL,NULL,NULL,NULL,'','','','1/1/2002','JWOOSNAM','1/1/02','JWOOSNAM',29802)
INSERT INTO CompanyBankAccount
(CompanyId,BankSortCode,BankAccountNumber,BankAccountName,CurrencyCode,CountryID,BankName,BankBuildingStreet,BankTown,BankCounty,BankPostCode,BankTelephoneNumber,BankFaxNumber,Notes,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@CompanyId,'88-99-11','992255','PaDS Journal','GBP',58,'Flemmings','xx','London',NULL,'SW1',NULL,NULL,NULL,'1/1/2002','JWOOSNAM','1/1/02','JWOOSNAM')
--*******  Company End **************
--************ NEW PRODCUT Start
Set @ProductCode = 'JR2002'
INSERT INTO Product
(ProductCode	,ProductName	,ProductStatus	,CompanyID	,IsParent	,ReleaseDate	,ParentProductCode	,ProductShortName	,IsForReporting	,ReportProportion	,ProductReportName	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@ProductCode,'PaDS Journal 2002'	,'Current'	,@CompanyId	,1		,'01/01/2002'	,'JR2002'			,@ProductCode		,0		,NULL			,NULL			,'06/09/1999 17:03:30'	,'jwoosnam'		,'12/01/2002 09:57:00'	,'Jwoosnam')
INSERT INTO Product
(ProductCode	,ProductName	,ProductStatus	,CompanyID	,IsParent	,ReleaseDate	,ParentProductCode	,ProductShortName	,IsForReporting	,ReportProportion	,ProductReportName	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES ('JR2002p1','PaDS Journal 2002','Current'	,@CompanyId	,0	,'01/01/2002'	,@ProductCode		,'JR2002p1'		,1		,1			,@ProductCode 		,'06/09/1999 17:03:30'	,'jwoosnam'		,'12/01/2002 09:57:00'	,'Jwoosnam')

SET @ProductRateid = (Select LastNumber + 1 FROM stblTableNumber WHere TableName = 'ProductRate') 
INSERT INTO ProductRate
(	ProductRateId	,ProductCode	,CurrencyCode	,RateType	,AccountType	,SubscriberCategory	,DeliveryArea	,ProductRate	,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@ProductRateid	,@ProductCode	,'GBP'		,'Full'		,'Society'	,'Ordinary'		,'All'		,50	,'20/12/2001 09:28:05','jwoosnam','20/12/2001 09:28:05','jwoosnam')
SET @ProductRateid = @ProductRateid +1
INSERT INTO ProductRate
(	ProductRateId	,ProductCode	,CurrencyCode	,RateType	,AccountType	,SubscriberCategory	,DeliveryArea	,ProductRate	,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@ProductRateid	,@ProductCode	,'GBP'		,'Full'		,'Society'	,'Institutional'		,'All'		,90	,'20/12/2001 09:28:05','jwoosnam','20/12/2001 09:28:05','jwoosnam')
SET @ProductRateid = @ProductRateid +1
INSERT INTO ProductRate
(	ProductRateId	,ProductCode	,CurrencyCode	,RateType	,AccountType	,SubscriberCategory	,DeliveryArea	,ProductRate	,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@ProductRateid	,@ProductCode	,'GBP'		,'Full'		,'Individual'	,'Ordinary'		,'All'		,65	,'20/12/2001 09:28:05','jwoosnam','20/12/2001 09:28:05','jwoosnam')

Update stblTableNumber Set LastNumber = @ProductRateid WHere TableName = 'ProductRate'
--************ NEW PRODCUT End



SET @SubscriberAddressId =  (SELECT MAX(SubscriberAddressId) + 1 FROM SubscriberAddress)
--************New Subscriber Start
SET @SubscriberId = 29801
--Delete any merged Subs
Update Subscriber Set DefaultPostalAddressId = NULL Where UpdateToSubscriberId = @SubscriberId  
DELETE FROM SubscriberAddress WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ChildSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ParentSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM Subscriber  Where UpdateToSubscriberId = @SubscriberId  
Update Subscriber Set DefaultPostalAddressId = NULL WHERE SubscriberId = @SubscriberId
Update CompanyAccount Set BillingAddressId = NULL WHERE SubscriberId = @SubscriberId
Update SalesOrderLine Set DeliveryAddressId = NULL WHERE SubscriberId = @SubscriberId
DELETE FROM SubscriberAddress Where Subscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ChildSubscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ParentSubscriberid = @SubscriberId
DELETE FROM Subscriber Where Subscriberid = @SubscriberId

INSERT INTO Subscriber
(SubscriberId		,SubscriberName				,SubscriberStatus,EntityType	,PrimaryCountryId	,SubscriberCategory	,VATNumber	,MailMethod	,DefaultPostalAddressId	,IsReceiveMail	,ContactName	,FirstName	,LastName,Title	,Notes	,CreatedDateTime	,CreatedByUserId,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberId	,'International PaDS Federation'	,'Current'	,'Organisation'	,58			,'Institutional'	,NULL		,NULL		,Null			,1		,'James Woosnam',''		,''	,NULL	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Set @SubscriberAddressId = @SubscriberAddressId + 1
INSERT INTO SubscriberAddress
(SubscriberAddressId		,SubscriberId	,AddressType	,AddressDescription	,AddressText					,CountryId	,InvalidAddress	,Address1		,Address2	,Town	,County	,PostCode	,Notes	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberAddressId	,@SubscriberId	,'Postal'	,'Main'			,cast(@SubscriberId as varchar) + ' The Road,London,SW6 2YH '	,58		,0		,cast(@SubscriberId as varchar) + ' The Road',NULL	,'London',NULL	,'SW6 6DF'	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Update Subscriber Set DefaultPostalAddressId = @SubscriberAddressId WHERE SubscriberId = @SubscriberId
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	30000			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	@SubscriberId			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
--*********************New Subscriber End

--************New Subscriber Start
SET @SubscriberId = 29802 -- PaDS Journal
--Delete any merged Subs
Update Subscriber Set DefaultPostalAddressId = NULL Where UpdateToSubscriberId = @SubscriberId  
DELETE FROM SubscriberAddress WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ChildSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ParentSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM Subscriber  Where UpdateToSubscriberId = @SubscriberId  
Update Subscriber Set DefaultPostalAddressId = NULL WHERE SubscriberId = @SubscriberId
Update CompanyAccount Set BillingAddressId = NULL WHERE SubscriberId = @SubscriberId
Update SalesOrderLine Set DeliveryAddressId = NULL WHERE SubscriberId = @SubscriberId
DELETE FROM SubscriberAddress Where Subscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ChildSubscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ParentSubscriberid = @SubscriberId
DELETE FROM Subscriber Where Subscriberid = @SubscriberId

INSERT INTO Subscriber
(SubscriberId		,SubscriberName				,SubscriberStatus,EntityType	,PrimaryCountryId	,SubscriberCategory	,VATNumber	,MailMethod	,DefaultPostalAddressId	,IsReceiveMail	,ContactName	,FirstName	,LastName,Title	,Notes	,CreatedDateTime	,CreatedByUserId,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberId	,'PaDS Journal'	,'Current'	,'Organisation'	,58			,'Institutional'	,NULL		,NULL		,Null			,1		,'James Woosnam',''		,''	,NULL	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Set @SubscriberAddressId = @SubscriberAddressId + 1
INSERT INTO SubscriberAddress
(SubscriberAddressId		,SubscriberId	,AddressType	,AddressDescription	,AddressText					,CountryId	,InvalidAddress	,Address1		,Address2	,Town	,County	,PostCode	,Notes	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberAddressId	,@SubscriberId	,'Postal'	,'Main'			,cast(@SubscriberId as varchar) + ' The Road,London,SW6 2YH '	,58		,0		,cast(@SubscriberId as varchar) + ' The Road',NULL	,'London',NULL	,'SW6 6DF'	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Update Subscriber Set DefaultPostalAddressId = @SubscriberAddressId WHERE SubscriberId = @SubscriberId
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	30000			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	@SubscriberId			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
--*********************New Subscriber End

--************New Subscriber Start
SET @SubscriberId = 29803 --PaDS England
--Delete any merged Subs
Update Subscriber Set DefaultPostalAddressId = NULL Where UpdateToSubscriberId = @SubscriberId  
DELETE FROM SubscriberAddress WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ChildSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ParentSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM Subscriber  Where UpdateToSubscriberId = @SubscriberId  
Update Subscriber Set DefaultPostalAddressId = NULL WHERE SubscriberId = @SubscriberId
Update CompanyAccount Set BillingAddressId = NULL WHERE SubscriberId = @SubscriberId
Update SalesOrderLine Set DeliveryAddressId = NULL WHERE SubscriberId = @SubscriberId
DELETE FROM SubscriberAddress Where Subscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ChildSubscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ParentSubscriberid = @SubscriberId
DELETE FROM Subscriber Where Subscriberid = @SubscriberId
INSERT INTO Subscriber
(SubscriberId		,SubscriberName	,SubscriberStatus,EntityType	,PrimaryCountryId	,SubscriberCategory	,VATNumber	,MailMethod	,DefaultPostalAddressId	,IsReceiveMail	,ContactName	,FirstName	,LastName,Title	,Notes	,CreatedDateTime	,CreatedByUserId,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberId	,'PaDS England'	,'Current'	,'Organisation'	,58			,'Institutional'	,NULL		,NULL		,Null			,1		,'James Woosnam',''		,''	,NULL	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Set @SubscriberAddressId = @SubscriberAddressId + 1
INSERT INTO SubscriberAddress
(SubscriberAddressId		,SubscriberId	,AddressType	,AddressDescription	,AddressText					,CountryId	,InvalidAddress	,Address1		,Address2	,Town	,County	,PostCode	,Notes	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberAddressId	,@SubscriberId	,'Postal'	,'Main'			,cast(@SubscriberId as varchar) + ' The Road,London,SW6 2YH '	,58		,0		,cast(@SubscriberId as varchar) + ' The Road',NULL	,'London',NULL	,'SW6 6DF'	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Update Subscriber Set DefaultPostalAddressId = @SubscriberAddressId WHERE SubscriberId = @SubscriberId
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	30000			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	@SubscriberId			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29801			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
--*********************New Subscriber End
--************New Subscriber Start
SET @SubscriberId = 29804 --PaDS Wales
--Delete any merged Subs
Update Subscriber Set DefaultPostalAddressId = NULL Where UpdateToSubscriberId = @SubscriberId  
DELETE FROM SubscriberAddress WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ChildSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ParentSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM Subscriber  Where UpdateToSubscriberId = @SubscriberId  
Update Subscriber Set DefaultPostalAddressId = NULL WHERE SubscriberId = @SubscriberId
Update CompanyAccount Set BillingAddressId = NULL WHERE SubscriberId = @SubscriberId
Update SalesOrderLine Set DeliveryAddressId = NULL WHERE SubscriberId = @SubscriberId
DELETE FROM SubscriberAddress Where Subscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ChildSubscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ParentSubscriberid = @SubscriberId
DELETE FROM Subscriber Where Subscriberid = @SubscriberId
INSERT INTO Subscriber
(SubscriberId		,SubscriberName	,SubscriberStatus,EntityType	,PrimaryCountryId	,SubscriberCategory	,VATNumber	,MailMethod	,DefaultPostalAddressId	,IsReceiveMail	,ContactName	,FirstName	,LastName,Title	,Notes	,CreatedDateTime	,CreatedByUserId,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberId	,'PaDS Wales'	,'Current'	,'Organisation'	,58			,'Institutional'	,NULL		,NULL		,Null			,1		,'James Woosnam',''		,''	,NULL	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Set @SubscriberAddressId = @SubscriberAddressId + 1
INSERT INTO SubscriberAddress
(SubscriberAddressId		,SubscriberId	,AddressType	,AddressDescription	,AddressText					,CountryId	,InvalidAddress	,Address1		,Address2	,Town	,County	,PostCode	,Notes	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberAddressId	,@SubscriberId	,'Postal'	,'Main'			,cast(@SubscriberId as varchar) + ' The Road,London,SW6 2YH '	,58		,0		,cast(@SubscriberId as varchar) + ' The Road',NULL	,'London',NULL	,'SW6 6DF'	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Update Subscriber Set DefaultPostalAddressId = @SubscriberAddressId WHERE SubscriberId = @SubscriberId
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	30000			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	@SubscriberId			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29801			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
--*********************New Subscriber End

--***********
SET @SubscriberId = 30777 --Bad record that has got into live
Update Subscriber Set DefaultPostalAddressId = NULL WHERE SubscriberId = @SubscriberId
DELETE FROM SalesOrderLine WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SalesOrder WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAddress Where Subscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ChildSubscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ParentSubscriberid = @SubscriberId
DELETE FROM Subscriber Where Subscriberid = @SubscriberId
--************New Subscriber Start
SET @SubscriberId = 29810 -- John Smith
--Delete any merged Subs
Update Subscriber Set DefaultPostalAddressId = NULL Where UpdateToSubscriberId = @SubscriberId  
--7/12/05	James Woosnam delete orders belonging direct to John Smith and elete cashbook items
DELETE FROM Cashbook WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM Cashbook WHERE SubscriberId = @SubscriberId
DELETE FROM SalesOrderLine WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SalesOrder WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SalesOrderLine WHERE SubscriberId = @SubscriberId
DELETE FROM SalesOrder WHERE SubscriberId = @SubscriberId
DELETE FROM CompanyAccount WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAddress WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ChildSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ParentSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM Subscriber  Where UpdateToSubscriberId = @SubscriberId  

Update Subscriber Set DefaultPostalAddressId = NULL WHERE SubscriberId = @SubscriberId
Update CompanyAccount Set BillingAddressId = NULL WHERE SubscriberId = @SubscriberId
Update SalesOrderLine Set DeliveryAddressId = NULL WHERE SubscriberId = @SubscriberId
Set @FirstName = 'John'
Set @LastName = 'Smith'
DELETE FROM SalesOrderLine WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SalesOrder WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAddress Where Subscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ChildSubscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ParentSubscriberid = @SubscriberId
DELETE FROM Subscriber Where Subscriberid = @SubscriberId
INSERT INTO Subscriber
(SubscriberId		,SubscriberName	,SubscriberStatus,EntityType	,PrimaryCountryId	,SubscriberCategory	,VATNumber	,MailMethod	,DefaultPostalAddressId	,IsReceiveMail	,ContactName	,FirstName	,LastName	,Title	,Notes	,CreatedDateTime	,CreatedByUserId,LastUpdatedDateTime	,LastUpdatedByUserId,WebUSerName,WebUserPassword)
 VALUES (@SubscriberId	,@LastName + ', ' + @FirstName	,'Current'	,'Person'	,58			,'Ordinary'		,NULL		,NULL		,Null			,1		,Null		,@FirstName	,@LastName	,'Mr'	,Null	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM','TRSmith','TRSmith')
Set @SubscriberAddressId = @SubscriberAddressId + 1
INSERT INTO SubscriberAddress
(SubscriberAddressId		,SubscriberId	,AddressType	,AddressDescription	,AddressText					,CountryId	,InvalidAddress	,Address1		,Address2	,Town	,County	,PostCode	,Notes	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberAddressId	,@SubscriberId	,'Postal'	,'Main'			,@LastName + ' House, ' + cast(@SubscriberId as varchar) + ' The Road,London,SW6 2YH '	,58		,0		,@LastName + ' House' ,cast(@SubscriberId as varchar) + ' The Road'	,'London',NULL	,'SW6 6DF'	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Update Subscriber Set DefaultPostalAddressId = @SubscriberAddressId WHERE SubscriberId = @SubscriberId
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	30000			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29801			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29803			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29802			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	@SubscriberId			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
--*********************New Subscriber End

--************New Subscriber Start
SET @SubscriberId = 29811
--Delete any merged Subs
Update Subscriber Set DefaultPostalAddressId = NULL Where UpdateToSubscriberId = @SubscriberId  
DELETE FROM SalesOrderLine WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SalesOrder WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAddress WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ChildSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ParentSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM Subscriber  Where UpdateToSubscriberId = @SubscriberId  

Update Subscriber Set DefaultPostalAddressId = NULL WHERE SubscriberId = @SubscriberId
Update CompanyAccount Set BillingAddressId = NULL WHERE SubscriberId = @SubscriberId
Update SalesOrderLine Set DeliveryAddressId = NULL WHERE SubscriberId = @SubscriberId
Set @FirstName = 'Jo'
Set @LastName = 'Bloggs'
DELETE FROM SalesOrderLine WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SalesOrder WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAddress Where Subscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ChildSubscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ParentSubscriberid = @SubscriberId
DELETE FROM Subscriber Where Subscriberid = @SubscriberId
INSERT INTO Subscriber
(SubscriberId		,SubscriberName	,SubscriberStatus,EntityType	,PrimaryCountryId	,SubscriberCategory	,VATNumber	,MailMethod	,DefaultPostalAddressId	,IsReceiveMail	,ContactName	,FirstName	,LastName	,Title	,Notes	,CreatedDateTime	,CreatedByUserId,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberId	,@LastName + ', ' + @FirstName	,'Current'	,'Person'	,58			,'Ordinary'		,NULL		,NULL		,Null			,1		,Null		,@FirstName	,@LastName	,'Mr'	,Null	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Set @SubscriberAddressId = @SubscriberAddressId + 1
INSERT INTO SubscriberAddress
(SubscriberAddressId		,SubscriberId	,AddressType	,AddressDescription	,AddressText					,CountryId	,InvalidAddress	,Address1		,Address2	,Town	,County	,PostCode	,Notes	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberAddressId	,@SubscriberId	,'Postal'	,'Main'			,@LastName + ' House, ' + cast(@SubscriberId as varchar) + ' The Road,London,SW6 2YH '	,58		,0		,@LastName + ' House' ,cast(@SubscriberId as varchar) + ' The Road'	,'London',NULL	,'SW6 6DF'	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Update Subscriber Set DefaultPostalAddressId = @SubscriberAddressId WHERE SubscriberId = @SubscriberId
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	30000			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29801			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29803			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29802			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
--*********************New Subscriber End

--************New Subscriber Start
SET @SubscriberId = 29815
--Delete any merged Subs
Update Subscriber Set DefaultPostalAddressId = NULL Where UpdateToSubscriberId = @SubscriberId  
DELETE FROM SalesOrderLine WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SalesOrder WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAddress WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ChildSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ParentSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM Subscriber  Where UpdateToSubscriberId = @SubscriberId  
Update Subscriber Set DefaultPostalAddressId = NULL WHERE SubscriberId = @SubscriberId
Update CompanyAccount Set BillingAddressId = NULL WHERE SubscriberId = @SubscriberId
Update SalesOrderLine Set DeliveryAddressId = NULL WHERE SubscriberId = @SubscriberId
Set @FirstName = 'Ivor'
Set @LastName = 'Williams'
DELETE FROM SalesOrderLine WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SalesOrder WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAddress Where Subscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ChildSubscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ParentSubscriberid = @SubscriberId
DELETE FROM Subscriber Where Subscriberid = @SubscriberId
INSERT INTO Subscriber
(SubscriberId		,SubscriberName	,SubscriberStatus,EntityType	,PrimaryCountryId	,SubscriberCategory	,VATNumber	,MailMethod	,DefaultPostalAddressId	,IsReceiveMail	,ContactName	,FirstName	,LastName	,Title	,Notes	,CreatedDateTime	,CreatedByUserId,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberId	,@LastName + ', ' + @FirstName	,'Current'	,'Person'	,58			,'Ordinary'		,NULL		,NULL		,Null			,1		,Null		,@FirstName	,@LastName	,'Mr'	,Null	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Set @SubscriberAddressId = @SubscriberAddressId + 1
INSERT INTO SubscriberAddress
(SubscriberAddressId		,SubscriberId	,AddressType	,AddressDescription	,AddressText					,CountryId	,InvalidAddress	,Address1		,Address2	,Town	,County	,PostCode	,Notes	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberAddressId	,@SubscriberId	,'Postal'	,'Main'			,@LastName + ' House, ' + cast(@SubscriberId as varchar) + ' The Road,London,SW6 2YH '	,58		,0		,@LastName + ' House' ,cast(@SubscriberId as varchar) + ' The Road'	,'London',NULL	,'SW6 6DF'	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Update Subscriber Set DefaultPostalAddressId = @SubscriberAddressId WHERE SubscriberId = @SubscriberId
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	30000			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29801			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29804			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
--*********************New Subscriber End
--************New Subscriber Start
SET @SubscriberId = 29816
--Delete any merged Subs
Update Subscriber Set DefaultPostalAddressId = NULL Where UpdateToSubscriberId = @SubscriberId  
DELETE FROM SalesOrderLine WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SalesOrder WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAddress WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ChildSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ParentSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM Subscriber  Where UpdateToSubscriberId = @SubscriberId  
Update Subscriber Set DefaultPostalAddressId = NULL WHERE SubscriberId = @SubscriberId
Update CompanyAccount Set BillingAddressId = NULL WHERE SubscriberId = @SubscriberId
Update SalesOrderLine Set DeliveryAddressId = NULL WHERE SubscriberId = @SubscriberId
Set @FirstName = 'Gareth'
Set @LastName = 'Jones'
DELETE FROM SalesOrderLine WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SalesOrder WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAddress Where Subscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ChildSubscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ParentSubscriberid = @SubscriberId
DELETE FROM Subscriber Where Subscriberid = @SubscriberId
INSERT INTO Subscriber
(SubscriberId		,SubscriberName	,SubscriberStatus,EntityType	,PrimaryCountryId	,SubscriberCategory	,VATNumber	,MailMethod	,DefaultPostalAddressId	,IsReceiveMail	,ContactName	,FirstName	,LastName	,Title	,Notes	,CreatedDateTime	,CreatedByUserId,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberId	,@LastName + ', ' + @FirstName	,'Current'	,'Person'	,58			,'Ordinary'		,NULL		,NULL		,Null			,1		,Null		,@FirstName	,@LastName	,'Mr'	,Null	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Set @SubscriberAddressId = @SubscriberAddressId + 1
INSERT INTO SubscriberAddress
(SubscriberAddressId		,SubscriberId	,AddressType	,AddressDescription	,AddressText					,CountryId	,InvalidAddress	,Address1		,Address2	,Town	,County	,PostCode	,Notes	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberAddressId	,@SubscriberId	,'Postal'	,'Main'			,@LastName + ' House, ' + cast(@SubscriberId as varchar) + ' The Road,London,SW6 2YH '	,58		,0		,@LastName + ' House' ,cast(@SubscriberId as varchar) + ' The Road'	,'London',NULL	,'SW6 6DF'	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Update Subscriber Set DefaultPostalAddressId = @SubscriberAddressId WHERE SubscriberId = @SubscriberId
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	30000			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29804			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29802			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
--*********************New Subscriber End

--************New Subscriber Start
SET @SubscriberId = 29820
--Delete any merged Subs
Update Subscriber Set DefaultPostalAddressId = NULL Where UpdateToSubscriberId = @SubscriberId  
DELETE FROM SalesOrderLine WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SalesOrder WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAddress WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ChildSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAffiliate WHERE ParentSubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM Subscriber  Where UpdateToSubscriberId = @SubscriberId  
Update Subscriber Set DefaultPostalAddressId = NULL WHERE SubscriberId = @SubscriberId
Update CompanyAccount Set BillingAddressId = NULL WHERE SubscriberId = @SubscriberId
Update SalesOrderLine Set DeliveryAddressId = NULL WHERE SubscriberId = @SubscriberId
Set @FirstName = 'Hamish'
Set @LastName = 'McCann'
DELETE FROM SalesOrderLine WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SalesOrder WHERE SubscriberId In (SELECT SubscriberId FROM Subscriber WHERE Subscriber.UpdateToSubscriberId = @SubscriberId) 
DELETE FROM SubscriberAddress Where Subscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ChildSubscriberid = @SubscriberId
DELETE FROM SubscriberAffiliate Where ParentSubscriberid = @SubscriberId
DELETE FROM Subscriber Where Subscriberid = @SubscriberId
INSERT INTO Subscriber
(SubscriberId		,SubscriberName	,SubscriberStatus,EntityType	,PrimaryCountryId	,SubscriberCategory	,VATNumber	,MailMethod	,DefaultPostalAddressId	,IsReceiveMail	,ContactName	,FirstName	,LastName	,Title	,Notes	,CreatedDateTime	,CreatedByUserId,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberId	,@LastName + ', ' + @FirstName	,'Current'	,'Person'	,58			,'Ordinary'		,NULL		,NULL		,Null			,1		,Null		,@FirstName	,@LastName	,'Mr'	,Null	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Set @SubscriberAddressId = @SubscriberAddressId + 1
INSERT INTO SubscriberAddress
(SubscriberAddressId		,SubscriberId	,AddressType	,AddressDescription	,AddressText					,CountryId	,InvalidAddress	,Address1		,Address2	,Town	,County	,PostCode	,Notes	,CreatedDateTime	,CreatedByUserId	,LastUpdatedDateTime	,LastUpdatedByUserId)
 VALUES (@SubscriberAddressId	,@SubscriberId	,'Postal'	,'Main'			,@LastName + ' House, ' + cast(@SubscriberId as varchar) + ' The Road,London,SW6 2YH '	,58		,0		,@LastName + ' House' ,cast(@SubscriberId as varchar) + ' The Road'	,'London',NULL	,'SW6 6DF'	,NULL	,'1/1/2002'		,'JWOOSNAM'	,'1/1/02'		,'JWOOSNAM')
Update Subscriber Set DefaultPostalAddressId = @SubscriberAddressId WHERE SubscriberId = @SubscriberId
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	30000			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
INSERT INTO SubscriberAffiliate
(		ParentSubscriberID	,ChildSubscriberID	,StartDate	,EndDate	,AffiliateReferenceID)
 VALUES (	29801			,@SubscriberId		,'01/01/2002'	,'01/01/3000'	,NULL)
--*********************New Subscriber End


Update stblTableNumber Set LastNumber = (SELECT MAX(SubscriberAddressId) FROM SubscriberAddress)
WHere TableName = 'SubscriberAddress'

INSERT INTO CompanyBankAccount
(CompanyId,BankSortCode,BankAccountNumber,BankAccountName,CurrencyCode,CountryID,BankName,BankBuildingStreet,BankTown,BankCounty,BankPostCode,BankTelephoneNumber,BankFaxNumber,Notes,CreatedDateTime,CreatedByUserId,LastUpdatedDateTime,LastUpdatedByUserId)
 VALUES (@CompanyId,'99-22-33','002100','International PaDS Federation','GBP',58,'Flemmings','xx','London',NULL,'SW1',NULL,NULL,NULL,'1/1/2002','JWOOSNAM','1/1/02','JWOOSNAM')

--***************************
--Populate the sub category on Afiliate
Update SubscriberAffiliate
	SET SubscriberCategory = Subscriber.SubscriberCategory
	FROM SubscriberAffiliate
		INNER JOIN Subscriber
		On Subscriber.Subscriberid = SubscriberAffiliate.ChildSubscriberId
	WHERE SubscriberAffiliate.ParentSubscriberId In (29801,29802)

COMMIT 