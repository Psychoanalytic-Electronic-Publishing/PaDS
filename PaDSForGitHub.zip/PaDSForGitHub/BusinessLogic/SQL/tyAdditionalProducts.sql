if exists (select * from dbo.sysobjects where id = object_id(N'sp483SubscriberImport') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp483SubscriberImport
GO
IF  EXISTS (SELECT * FROM sys.types st JOIN sys.schemas ss ON st.schema_id = ss.schema_id WHERE st.name = N'AdditionalProducts' AND ss.name = N'dbo')
DROP TYPE AdditionalProducts
GO
CREATE TYPE AdditionalProducts AS TABLE(
	[ProductCode] [varchar](20) NOT NULL,
	PRIMARY KEY CLUSTERED 
(
	[ProductCode] ASC
)WITH (IGNORE_DUP_KEY = OFF)
)
GO


