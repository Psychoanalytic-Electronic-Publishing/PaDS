/*************************************************************************************
Script:	Creates the users and roles required for Database
Description:	

Amendments
Feb 2018	Remove loacal users PEP_FTP, IJP_FTP, PaDSReporter
21/9/19		James Woosnam	N' for a string no longer works in sql 2017!!
**************************************************************************************/

USE Pads_Live 
--IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'ServerName\PADSReporter') DROP USER [ServerName\PADSReporter]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'ServerName\ZedraAdmin') DROP USER [ServerName\ZedraAdmin]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'ZedraAdmin') DROP USER ZedraAdmin

IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') DROP USER [PaDSSQLServerUser]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLSecurityUser') DROP USER [PaDSSQLSecurityUser]

USE [PADS_Logs]

--IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'ServerName\PADSReporter') DROP USER [ServerName\PADSReporter]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'ServerName\ZedraAdmin') DROP USER [ServerName\ZedraAdmin]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'ZedraAdmin') DROP USER ZedraAdmin

IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') DROP USER [PaDSSQLServerUser]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLSecurityUser') DROP USER [PaDSSQLSecurityUser]

USE [master]

--IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = 'ServerName\PADSReporter') DROP LOGIN [ServerName\PADSReporter]
--IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = 'ServerName\ZedraAdmin') DROP LOGIN [ServerName\ZedraAdmin]

--IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = 'ZedraAdmin') DROP LOGIN ZedraAdmin
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') DROP USER [PaDSSQLServerUser]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLSecurityUser') DROP USER [PaDSSQLSecurityUser]


--******************************************************************************
--******************************************************************************
--			END OF DROP SECTION
--******************************************************************************
--******************************************************************************

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = 'ServerName\ZedraAdmin') CREATE LOGIN [ServerName\ZedraAdmin] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[British]
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = 'PaDSSQLServerUser') CREATE LOGIN [PaDSSQLServerUser] WITH PASSWORD= 'xxObscuredPasswordxx', DEFAULT_DATABASE=[PADS_Live], DEFAULT_LANGUAGE=[British], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = 'PaDSSQLSecurityUser') CREATE LOGIN [PaDSSQLSecurityUser] WITH PASSWORD= 'xxObscuredPasswordxx', DEFAULT_DATABASE=[PADS_Live], DEFAULT_LANGUAGE=[British], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
--IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = 'ZedraAdmin') CREATE LOGIN ZedraAdmin WITH PASSWORD= 'xxObscuredPasswordxx', DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[British], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF


EXEC sp_addsrvrolemember @loginame = 'ServerName\ZedraAdmin', @rolename = 'sysadmin'
--EXEC sp_addsrvrolemember @loginame = 'ZedraAdmin', @rolename = 'sysadmin'


USE [PADS_Live]

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') CREATE USER [PaDSSQLServerUser] FOR LOGIN [PaDSSQLServerUser] WITH DEFAULT_SCHEMA=[dbo]
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLSecurityUser') CREATE USER [PaDSSQLSecurityUser] FOR LOGIN [PaDSSQLSecurityUser] WITH DEFAULT_SCHEMA=[dbo]

EXEC sys.sp_addrolemember @rolename= 'db_owner', @membername= 'PaDSSQLSecurityUser'

USE [PADS_Logs]

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') CREATE USER [PaDSSQLServerUser] FOR LOGIN [PaDSSQLServerUser] WITH DEFAULT_SCHEMA=[dbo]
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLSecurityUser') CREATE USER [PaDSSQLSecurityUser] FOR LOGIN [PaDSSQLSecurityUser] WITH DEFAULT_SCHEMA=[dbo]

EXEC sys.sp_addrolemember @rolename= 'db_datareader', @membername= 'PaDSSQLServerUser'

EXEC sys.sp_addrolemember @rolename= 'db_datawriter', @membername= 'PaDSSQLServerUser'

EXEC sys.sp_addrolemember @rolename= 'db_owner', @membername= 'PaDSSQLSecurityUser'



