if exists (select * from dbo.sysobjects where id = object_id(N'dbo.sp492SubscriberAddUpdate') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure dbo.sp492SubscriberAddUpdate
GO
CREATE PROCEDURE sp492SubscriberAddUpdate(
						@SubscriberId INT output
						,@SubscriberCategory varchar(20)
						,@FirstName varchar(25)
						,@LastName varchar(50)
						,@SubscriberName varchar(150)
						,@Title varchar(20)
						,@EmailAddress varchar(255) = NULL
						,@Address1 varchar(50) = NULL
						,@Address2 varchar(50) = NULL
						,@Address3 varchar(50) = NULL
						,@Address4 varchar(50) = NULL
						,@Town varchar(50) = NULL
						,@County varchar(50) = NULL
						,@PostCode varchar(16) = NULL
						,@CountryId INT = NULL
						,@AffiliateEndDate datetime = NULL
						,@UserName varchar(50)
						,@GroupSubscriberId INT
						,@CompanyId INT 
						,@ReturnCode INT OUTPUT
						,@ErrorMessage varchar(200) OUTPUT
						
									)
AS
--13/1/11		James Woosnam	HotFix - Stop Password being overwritten with blanks
--30/3/11	James Woosnam	SIR2401 - Find and use @CompanyAddressDescription
--16/05/19  Julian Gates    SIR4759 - Removed Home and work telephone number fields
--19/11/19	James Woosnam	SIR4763 - Remove WebUser Fields
--17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .

DECLARE @ErrorFound INT
DECLARE @ErrorCode INT
DECLARE @ProcName varchar(50)
DECLARE @ROWCOUNT INT
DECLARE @Message VARCHAR(2000)
DECLARE @Today DATETIME
SET @ReturnCode = 0
SET @ErrorFound = 0
SET @ProcName = 'sp492SubscriberAddUpdate'

SET @Today = CAST(CONVERT(varchar(11),GETDATE(),13) as DATETIME)

--30/3/11	James Woosnam	SIR2401 - Find @CompanyAddressDescription
DECLARE @CompanyAddressDescription VARCHAR(20)
SELECT @CompanyAddressDescription = MAX(c.DefaultAddressDescription)
FROM Company c
WHERE c.CompanyId = @CompanyId
IF ISNULL(@CompanyAddressDescription,'') = '' 
BEGIN
	SET @ReturnCode = 3
	SET @ErrorFound = 1
	SET @ErrorMessage = 'The Company must be set up with a DefaultAddressDescription'
END


DECLARE @TranBegun BIT
SET @TranBegun = 0
If @ErrorFound = 0
BEGIN
	BEGIN TRAN
	SET @TRanBegun = 1
END

If @ErrorFound = 0
AND @SubscriberId = 0
BEGIN
--New Subscriber--
	Exec dbo.sp005GetNextTableNumber 'Subscriber',@SubscriberId OUTPUT
	INSERT INTO Subscriber
		(SubscriberId
		,SubscriberName
		,SubscriberStatus
		,EntityType
		,PrimaryCountryId
		,SubscriberCategory
		,IsAccount
		,IsReceiveMail
		,FirstName
		,LastName
		,Title
		,CreatedDateTime
		,CreatedByUserId
		,LastUpdatedDateTime
		,LastUpdatedByUserId )
	VALUES (	
		@SubscriberId
		,ISNULL(@LastName,'') + CASE WHEN ISNULL(@FirstName,'') <> '' THEN + ', ' + @FirstName ELSE '' END
		,'Proposed'
		,'Person'
		,@CountryId
		,@SubscriberCategory
		, 0
		, 1
		,@FirstName 
		,@LastName
		,@Title
		,GETDATE()
		,@UserName
		, GetDate()
		, @UserName
		)
	
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	
	IF @ErrorFound = 0 
	BEGIN
	--Add Affiliate for group subscriber
		INSERT INTO SubscriberAffiliate
			(ParentSubscriberID
			,ChildSubscriberID
			,StartDate
			,EndDate
			,AffiliateReferenceID
			)
		VALUES (
			@GroupSubscriberID
			,@SubscriberId
			,@Today
			,'31-DEC-4949'
			,@SubscriberId
			)
		
		SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
	END
END
ELSE
BEGIN
--Exisiting Subscriber--
	UPDATE Subscriber
	SET SubscriberName = CASE EntityType 
							WHEN 'Organisation' THEN @SubscriberName 
							ELSE ISNULL(@LastName,'') + CASE WHEN ISNULL(@FirstName,'') <> '' THEN + ', ' + @FirstName ELSE '' END
							END
		  ,PrimaryCountryId = @CountryId
		  ,SubscriberCategory = @SubscriberCategory
		  ,FirstName = @FirstName
		  ,LastName = @LastName
		  ,LastUpdatedDateTime = GETDATE()
		  ,LastUpdatedByUserId = @UserName
		,Title = @Title
	WHERE Subscriber.SubscriberId = @SubscriberId
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END

--****Affiliates****

IF @ErrorFound = 0
AND NOT EXISTS( SELECT  ParentSubscriberID 
				FROM SubscriberAffiliate
				WHERE ParentSubscriberID = 30000
				AND ChildSubscriberID = @SubscriberId
				AND StartDate <= @Today
				AND EndDate >= @Today) 
BEGIN
--Add Affiliate for 3000
	INSERT INTO SubscriberAffiliate
		(ParentSubscriberID
		,ChildSubscriberID
		,StartDate
		,EndDate
		,AffiliateReferenceID
		)
	VALUES( 30000
		,@SubscriberId
		,@Today
		,'31-DEC-4949'
		,NULL
		)

	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END

DECLARE @CompanySubscriberId INT
SELECT @CompanySubscriberId =Company.GroupParentSubscriberId
FROM Company
WHERE CompanyId = @CompanyId

IF @ErrorFound = 0 
AND NOT EXISTS( SELECT  ParentSubscriberID 
				FROM SubscriberAffiliate
				WHERE ParentSubscriberID = @CompanySubscriberId
				AND ChildSubscriberID = @SubscriberId
				AND StartDate <= @Today
				AND EndDate >= @Today) 
BEGIN
--Add Affiliate for Company
	INSERT INTO SubscriberAffiliate
		(ParentSubscriberID
		,ChildSubscriberID
		,StartDate
		,EndDate
		,SubscriberCategory)
	VALUES (
		@CompanySubscriberId
		,@SubscriberId
		,@Today
		,'31-DEC-4949'
		,@SubscriberCategory
		)

	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END
ELSE
BEGIN
	UPDATE SubscriberAffiliate
	SET SubscriberCategory = @SubscriberCategory
	FROM SubscriberAffiliate
	WHERE ChildSubscriberID = @SubscriberId
	AND ParentSubscriberId = @CompanySubscriberId
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END

IF @ErrorFound = 0
AND @AffiliateEndDate IS NOT NULL
BEGIN
--Update the Affiliation to the primary group
	UPDATE SubscriberAffiliate
	SET EndDate = @AffiliateEndDate
	FROM SubscriberAffiliate
	WHERE ChildSubscriberID = @SubscriberId
	AND ParentSubscriberId = @GroupSubscriberID
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END

--****Addresses****
IF @ErrorFound = 0
BEGIN
	EXEC sp493SubscriberAddressMaint
					@SubscriberId = @SubscriberID 
					,@AddressType = 'Postal'
					,@AddressDescription = @CompanyAddressDescription
					,@AddressText = ''
					,@Address1 =@Address1
					,@Address2 =@Address2
					,@Address3 =@Address3
					,@Address4 =@Address4
					,@Town =@Town
					,@County =@County
					,@PostCode =@PostCode
					,@CountryId =@CountryId
					,@UserName = @UserName
					,@ReturnCode = @ErrorFound OUTPUT
					,@ErrorMessage = @ErrorMessage OUTPUT
	IF @ReturnCode <> 0 
	BEGIN 
		SET @ErrorFound = 1
	END			
END
--Set the DefaultPostalAddressId if not already set
IF @ErrorFound = 0
BEGIN
	UPDATE Subscriber
	SET DefaultPostalAddressId = SubscriberAddress.SubscriberAddressId
	FROM Subscriber
		INNER JOIN SubscriberAddress
		ON SubscriberAddress.SubscriberId = Subscriber.SubscriberId
		AND AddressType = 'Postal'
		AND AddressDescription = @CompanyAddressDescription
	WHERE Subscriber.SubscriberId = @SubscriberId
	AND Subscriber.DefaultPostalAddressId IS NULL
	SELECT @ErrorFound = @@Error,@ROWCOUNT = @@ROWCOUNT
END 
DECLARE @AddressText VARCHAR(255)
IF @ErrorFound = 0
BEGIN
	--SELECT @AddressText = EmailAddress FROM  tmpSubscriberImport WHERE tmpSubscriberImport.SubscriberImportId = @SubscriberImportId
	EXEC sp493SubscriberAddressMaint
					@SubscriberId = @SubscriberID
					,@AddressType = 'Email'
					,@AddressDescription = 'Main'
					,@AddressText = @EmailAddress
					,@UserName = @UserName
					,@ReturnCode = @ErrorFound OUTPUT
					,@ErrorMessage = @ErrorMessage OUTPUT
	IF @ReturnCode <> 0 
	BEGIN 
		SET @ErrorFound = 1
	END			
END

IF @TranBegun = 1
BEGIN
	IF @ErrorFound <> 0
	BEGIN
		ROLLBACK TRAN
		PRINT 'Tran rolled back'
	END
	ELSE
	BEGIN
		COMMIT TRAN
		PRINT 'Tran Commited'
	END
END
If @ReturnCode = 0 
	--If an error been found with no return code then set the returncode to the ErrorCode
	SET @ReturnCode = @ErrorFound

RETurn (@ReturnCode)	
--select @ErrorMessage
Go
