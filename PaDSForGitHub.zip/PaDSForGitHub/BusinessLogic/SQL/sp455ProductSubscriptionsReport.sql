if exists (select * from sysobjects where id = object_id(N'sp455ProductSubscriptionsReport') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp455ProductSubscriptionsReport
GO
CREATE  PROCEDURE sp455ProductSubscriptionsReport ( 
					@StartDate datetime
					,@EndDate datetime
					,@CompanyId Int
)
AS

SELECT
	so.OrderNumber 
	,so.OrderDate 
	,so.CompanyId  
	,so.SalesOrderStatus 
	,LineStatus = CASE WHEN ISNULL(sol.IsCancel,0)=1 THEN 'Cancelled' ELSE '' END 
	,sol.ProductCode 
	,p.ProductName  
	,AccountSubscriberId = accs.SubscriberId 
	,AccountSubscriberName = accs.SubscriberName  
	,AccountSubscriberAddress = accsa.AddressText 
	,BeneficiarySubscriberId = bens.SubscriberId 
	,BeneficiarySubscriberName = bens.SubscriberName 
	,BeneficiarySubscriberAddress = bensa.AddressText 
	,BeneficiarySubscriberCategory = bens.SubscriberCategory  
	,sol.AmountProduct  
	,so.CurrencyCode 
FROM SalesOrderLine sol
	INNER JOIN SalesOrder so
	On so.OrderNumber = sol.OrderNumber
	INNER JOIN Subscriber bens
		LEFT JOIN SubscriberAddress bensa
		ON bensa.SubscriberId = bens.SubscriberId 
		AND bensa.AddressType = 'Postal'
		AND bensa.AddressDescription = 'Main'
	ON bens.SubscriberId = sol.SubscriberId

	INNER JOIN Subscriber accs
		LEFT JOIN SubscriberAddress accsa
		ON accsa.SubscriberId = accs.SubscriberId 
		AND accsa.AddressType = 'Postal'	
		AND accsa.AddressDescription = 'Main'

	ON accs.SubscriberId = so.SubscriberId
	INNER JOIN Product p
	ON p.ProductCode = sol.ProductCode 
WHERE 1=1
AND so.OrderDate BETWEEN @StartDate AND @EndDate 
AND so.CompanyId = @CompanyId 
ORDER BY
	so.OrderNumber 
	,sol.ProductCode 
go