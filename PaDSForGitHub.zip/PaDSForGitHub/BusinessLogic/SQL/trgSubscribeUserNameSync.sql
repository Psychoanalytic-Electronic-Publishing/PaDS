if exists (select * from sysobjects where id = object_id(N'trgSubscribeUserNameSync') and OBJECTPROPERTY(id, N'IsTrigger') = 1)
DROP TRIGGER trgSubscribeUserNameSync
Go
CREATE TRIGGER trgSubscribeUserNameSync ON Subscriber
FOR Update
AS
--10/1/20	James Woosnam	SIR4977 - Initial version
--17/2/20    James Woosnam   SIR5021 -tuncate longer sub name to 50 in remote user full name .
UPDATE RemoteUser
SET UserFullName = LEFT(inserted.SubscriberName  ,50)
	,LastUpdatedDateTime = INSERTED.LastUpdatedDateTime 
	,LastUpdatedByUserId  = INSERTED.LastUpdatedByUserId 
FROM RemoteUser ru
	INNER JOIN RemoteUserRights rur
	ON rur.UserId = ru.UserId 
	AND rur.RightsType = 'Subscriber'
	INNER JOIN INSERTED
	ON INSERTED.SubscriberId = rur.RightsToId 
go

