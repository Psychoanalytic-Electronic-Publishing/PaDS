Begin tran

declare 
	@SessionId varchar(50)=''--faacb345-5782-44a5-b734-e8a765b12851  '--55f0335e-33bf-4a9a-a2d6-abc6c1457754'--3a66728b-3e86-4333-b93f-180e1d04e384'--76F7CCCF-A3D9-4136-A870-A45EC3286D0F  '--3a44454b-7dcb-46d4-85f0-eff9b47db501'--75878a0b-df33-4f75-9e9f-da6185b772ba  '--F26D29B1-33C4-4AB0-9ED1-D945586A2300  '--2887d2f2-fe18-4b5c-84ce-e8e1d201121e'--2887d2f2-fe18-4b5c-84ce-e8e1d201121e'--CA0D7622-C814-4CD1-8AAE-DF74380A6167  '--85045E2E-00FE-4DD8-8BEC-E95EF1388205  '--7EA07AE3-8BAC-4412-9798-998D29F2C15D  '--81c99041-9caa-4801-9b1c-ffbcbc10fd8d  '--02E57FFD-C29D-4AEB-B805-88E7E4FC56ED  '--78913d06-231f-448d-b897-50f5d2fc89a9'--
	,@FromDateTime as DATETIME = '1-jan-16 20:00:00'--2021-01-14 05:24:54.750
	,@ToDateTime as DATETIME =null-- '26-jan-21 22:11:00'--2021-01-14 05:24:54.750
	,@SessionLog BIT = 1
	,@HideAdHocSessionLogLines BIT =1
	,@PEPLog BIT = 1
	,@ErrorLog BIT = 0
	,@LogCount BIT =0
	,@UserSessionLog BIT =0
	,@IPAddress varchar(50)=null--'3.91.86.77'
	,@LogType VARCHAR(20) =''-- 'PEPSecurity'
--	,@LogType VARCHAR(2 =''-- 'PEPSecurity'

select * INTO #Sess
from (
	 select SessionId = '04E2716B-7097-433F-91BC-35D64C29B128' , WhatWhere= 'Auth/IP on Old MAC Chrome '
	union select 'B9647D9B-D5EB-4B7A-8E78-D2A62894703F  ' , 'Client Safari old mac'
	union select '01E14B36-D33C-42F0-A2CA-A742354806DA  ' , 'Clnt Sfri New Mac'
	union select 'xxxxxx' , 'yyyyyyy'
	) x
select * INTO #IP
from (
	 select IPAddress = '178.63.104.39' , Who= 'ZedraHetzner '
	union select '67.248.189.117' , 'Gavant'
--	union select '172.30.2.85' , 'Gavant1  ????'
	union select '81.174.164.198' , 'TheWarren Plusnet'
	union select '67.248.236.252' , 'Neil??'
	union select '3.234.215.231' , 'OPAS Stage'
	union select '3.91.86.77' , 'OPAS Prod'
	union select '185.115.60.160' , 'TheWarren  Gigabeam'
	union select 'zzzzz' , 'ZedraDEV??'
	) x

IF @PEPLog=1 ---PEPUsageLog
SELECT 
x.DateTime 
,x.ActionType 
,x.LogonLocation 
,x.LogonStatus 
,x.UserName 
,x.SubscriberName 
,x.OrderNumber 
--,SubscriptionEndDate = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='SubscriptionEndDate' AND usd.UserSessionId=x.UserSessionId )
,x.DocumentId 
,x.documentRef
,x.ReasonForCheck
,IPWho = x.RemoteIPAddress + ' (' + ISNULL((SELECT Who from #ip WHERE ipaddress= x.RemoteIPAddress ),'') + ')'
,Sess = x.UserSessionId + '  ' + ISNULL( (SELECT WhatWhere FROM #Sess WHERE SessionId = x.UserSessionId),'')

FROM (
SELECT
l.*
  ,d.title
  ,d.documentRef 
 ,d.year
 ,j.embargoYears 
 ,s.SubscriberName 
FROM PEPWebUsageLog l WITH (NOLOCK)
	LEFT JOIN Subscriber s WITH (NOLOCK)
	ON s.SubscriberId = l.SubscriberId 
	left join contentdocuments d WITH (NOLOCK)
		left join contentjournals j WITH (NOLOCK)
		on j.pepcode = d.pepcode
	on d.DocumentId = l.DocumentId collate database_default
where 1=1
and l.DateTime >='01-oct-2020'
AND (l.UserSessionId = @SessionId OR @SessionId = '')
AND (l.DateTime >= @FromDateTime OR @FromDateTime IS NULL)
AND (l.DateTime <= @ToDateTime OR @ToDateTime IS NULL)
and (l.RemoteIPAddress = @IPAddress or @IPAddress is null)
--and l.ActionType = 'Authenticate'
) x
order by x.DateTime desc

if @SessionLog = 1
SELECT 
x.Date 
,x.LogType 
,x.PageId 
,x.PageTitle 
,x.UserId 
,x.FromUserUserName 
,IPWho = x.RemoteIPAddress + ' (' + ISNULL((SELECT Who from #ip WHERE ipaddress= x.RemoteIPAddress ),'') + ')'
,Sess = x.SessionId + '  ' + ISNULL( (SELECT WhatWhere FROM #Sess WHERE SessionId = x.SessionId),'')
,Comment= REPLACE(x.Comment ,'WEB=Primary DB=Primary','')

FROM (
SELECT TOP 10000
l.*
,FromUserUserName=r.username

FROM SessionLog l WITH (NOLOCK) 
	left join RemoteUser r WITH (NOLOCK)
	on r.userid = l.userid
WHERE (l.LogType = @LogType OR @LogType='')
AND (l.SessionId = @SessionId OR @SessionId = '')
AND (l.date >= @FromDateTime OR @FromDateTime IS NULL)
and (l.RemoteIPAddress = @IPAddress or @IPAddress is null)
AND (l.date <= @ToDateTime OR @ToDateTime IS NULL)
AND (l.LogType <> 'AdHoc' OR ISNULL(@HideAdHocSessionLogLines,0) = 0)
--and l.PageTitle = 'SessionLogout'
	--and logtype <>'adhoc'

ORDER BY
l.SessionLogId  desc) x



IF @LogCount=1 ---IP count

SELECT
l.RemoteIPAddress 
,l.Who
,l.DayY 
,l.PageTitle 
,Count(*)
FROM (

	select 
	s.RemoteIPAddress
	,#IP.Who 
	,s.PageTitle 
	,DayY = FORMAT(s.Date ,'yy-MM-dd ddd')

	from SessionLog s WITH (NOLOCK)
		left join #IP 
		on #IP.IPAddress = s.RemoteIPAddress 
	where 1=1
	AND (s.Date >= @FromDateTime OR @FromDateTime IS NULL)
	AND (s.Date <= @ToDateTime OR @ToDateTime IS NULL)
	AND (s.SessionId = @SessionId OR @SessionId = '')
	AND (s.LogType = @LogType OR @LogType='')
	) l
group by
l.RemoteIPAddress 
,l.Who
,l.PageTitle 
,l.DayY  
order by 
l.DayY  desc
,Count(*) desc

IF @UserSessionLog = 1
SELECT top 200
*
,IPAddress = (SELECT MAX(l.RemoteIPAddress  ) FROM SessionLog l WHERE l.SessionId = CAST(us.UserSessionId as VARCHAR(50) ))
,SubscriptionEndDate = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='SubscriptionEndDate' AND usd.UserSessionId=us.UserSessionId )
,Subscriberid = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='Subscriberid' AND usd.UserSessionId=us.UserSessionId )
,Subscriberid = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='Subscriberid' AND usd.UserSessionId=us.UserSessionId )

FROM UserSession us with (nolock)
	--left JOIN UserSessionData usd with (nolock)
	--ON usd.UserSessionId = us.UserSessionId  
WHERE 1=1
AND (CAST(us.UserSessionId AS VARCHAR(50))  = @SessionId OR @SessionId = '')


ORDER BY 
us.LastAccessedDate  desc
--,usd.DataItemName


IF @ErrorLog=1 --Error Log
select top 1000
*
from stblErrorMessageLog WITH (NOLOCK)
order by 1 desc

rollback tran