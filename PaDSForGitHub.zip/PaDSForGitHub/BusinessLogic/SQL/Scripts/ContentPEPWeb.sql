select
	cj.PEPCode 
	,cj.displayTitle 
	,cv.vol 
	,cv.year 
	,cd.documentID 
	,cd.vol 
from (
		SELECT
			c.sourceType 
			,c.PEPCode 
			,c.embargoYears 
			,c.displayTitle 
		FROM ContentJournals c
		UNION
		SELECT
			c.sourceType 
			,c.PEPCode 
			,c.embargoYears 
			,c.displayTitle 
		FROM ContentBooks c
		UNION
		SELECT
			c.sourceType 
			,c.PEPCode 
			,c.embargoYears 
			,c.displayTitle 
		FROM ContentVideos c
		) cj
	LEFT join ContentVolumes cv
		inner join ContentDocuments cd
		on cd.PEPCode = cv.PEPCode 
		and cd.vol = cv.vol 
	on cv.PEPCode = cj.PEPCode
where cj.PEPCode in ('ijp','ADPSA','IPL002','')
and cv.year >2015