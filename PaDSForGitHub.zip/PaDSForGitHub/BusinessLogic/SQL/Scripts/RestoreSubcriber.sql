DECLARE			@CommitTran BIT = 1
				,@SubscriberId INT = 29001
				,@BackupDBName VARCHAR(100) = 'PaDS_LiveBeforeDataRationalisation20190516'
				,@RunByUserId INT
				,@AllMsg VARCHAR(MAX) = ''
	
/*

*/
--Modification History
--May 2019 - James Woosnam - Initial Version
DECLARE @Message varchar(8000) = ''
DECLARE @SQL varchar(8000) = ''
	
IF  EXISTS(select Subscriberid from subscriber where Subscriberid = @SubscriberId )
BEGIN
	SET @Message = 'SubscriberId:' + CAST(@SubscriberId AS VARCHAR) + ' still exists'
	RAISERROR (@Message, 16, 1)
	RETURN
END


BEGIN TRAN
BEGIN TRY
	
	SET @SQL = '

	DECLARE	@SubscriberId INT = ' + CAST(@SubscriberId as VARCHAR) + '
	DECLARE @Message varchar(8000) = ''''

	IF  NOT EXISTS(select Subscriberid from ' + @BackupDBName + '..subscriber where Subscriberid = @SubscriberId )
	BEGIN
		SET @Message = ''SubscriberId not in target DB''
		RAISERROR (@Message, 16, 1)
	END
	INSERT INTO Subscriber SELECT * FROM ' + @BackupDBName + '..Subscriber WHERE SubscriberId = @SubscriberId 
	SET @Message= CAST(@@RowCount AS VARCHAR) + '' Subscrbers Added'';PRINT @Message
	INSERT INTO SubscriberAddress SELECT * FROM ' + @BackupDBName + '..SubscriberAddress WHERE SubscriberId = @SubscriberId 
	SET @Message= CAST(@@RowCount AS VARCHAR) + '' SubscriberAddress Added'';PRINT @Message
	INSERT INTO SubscriberAffiliate SELECT sa.* FROM ' + @BackupDBName + '..SubscriberAffiliate sa 
									INNER JOIN Subscriber s ON s.SubscriberId = sa.ParentSubscriberId 
									WHERE sa.ChildSubscriberID = @SubscriberId 
									AND sa.ParentSubscriberID <> @SubscriberId
	SET @Message= CAST(@@RowCount AS VARCHAR) + '' SubscriberAffiliate Child Added'';PRINT @Message

--	IF EXISTS(Select * from SubscriberAffiliate where ParentSubscriberID = @SubscriberId AND ChildSubscriberId <>  @SubscriberId) DELETE FROM SubscriberAffiliate WHERE ParentSubscriberID = @SubscriberId AND ChildSubscriberId <>  @SubscriberId
	INSERT INTO SubscriberAffiliate SELECT sa.* FROM ' + @BackupDBName + '..SubscriberAffiliate sa
									INNER JOIN Subscriber s ON s.SubscriberId = sa.ChildSubscriberId 
										WHERE ParentSubscriberID = @SubscriberId
	SET @Message= CAST(@@RowCount AS VARCHAR) + '' SubscriberAffiliate Parent Added'';PRINT @Message
	INSERT INTO CompanyAccount SELECT * FROM ' + @BackupDBName + '..CompanyAccount WHERE SubscriberId = @SubscriberId 
	SET @Message= CAST(@@RowCount AS VARCHAR) + '' CompanyAccount Added'';PRINT @Message
	
	'

	--print @sql
	EXECUTE(@sql)
	IF @CommitTran = 1
		COMMIT TRAN
	ELSE
		rollback TRAN
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SET @Message = 'Restore Subscriebr Failed - ' + ERROR_MESSAGE()
	RAISERROR (@Message, 16, 1)
END CATCH







