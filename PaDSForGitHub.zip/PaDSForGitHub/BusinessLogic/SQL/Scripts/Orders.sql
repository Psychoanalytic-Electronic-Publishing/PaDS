SELECT
	so.OrderNumber 
	,s.SubscriberId 
	,s.SubscriberName 
	,SubIdAndName = s.SubscriberName + ' (' + CAST(s.SubscriberId AS VARCHAR) +')'
	,Included = CASE WHEN sol.SubscriberId IS NULL THEN 0 ELSE 1 END
	,IncludedYN = CASE WHEN sol.SubscriberId IS NULL THEN 'N' ELSE 'Y' END
	,DeliveryAddressId = ISNULL(sol.DeliveryAddressId , s.DefaultPostalAddressId  )
	,DeliveryAddress = dbo.f530SubscriberAddressDisplay( ISNULL(sol.DeliveryAddressId , s.DefaultPostalAddressId  ),'SingleLine')
	,ProductRateId = pr.ProductRateId 
	,pr.ProductRate		
	,Quantity = ISNULL(sol.Quantity ,1)
	,sol.AmountProduct 
	,AssociatedProductCode = assProd.ProductCode 
	,IncludesAssociatedProduct = CASE WHEN (SELECT MAX(sol2.OrderNumber)  
										FROM SalesOrderLine sol2 
										WHERE sol2.SubscriberId = s.SubscriberId 
										AND sol2.ProductCode = assProd.ProductCode 
										AND sol2.OrderNumber = so.OrderNumber  
										) IS NULL THEN 0 ELSE 1 END

FROM SalesOrder so
	INNER JOIN Product p
		LEFT JOIN Product assProd
		On assProd.ProductCode = p.AssociatedProductCode 
	On p.ProductCode = so.PrimaryProductCode 
	INNER JOIN Company c
	ON c.CompanyId = so.CompanyId 
	INNER JOIN CompanyAccount ca
	ON ca.SubscriberId = so.SubscriberId 
	AND ca.CompanyId = so.CompanyId 
	INNER JOIN SubscriberAffiliate sa
	ON sa.ParentSubscriberID = so.SubscriberId 
	LEFT JOIN SalesOrderLine sol
	ON so.OrderNumber = sol.OrderNumber 
	AND sol.ProductCode = so.PrimaryProductCode 
	AND (sol.SubscriberId = sa.ChildSubscriberID OR sol.SubscriberId IS NULL)
	LEFT JOIN Subscriber s
	ON s.SubscriberId = ISNULL(sa.ChildSubscriberId,sol.SubscriberId )
	LEFT JOIN SubscriberAffiliate compAffil
	ON compAffil.ChildSubscriberID = s.SubscriberId 
	AND compAffil.ParentSubscriberID = c.GroupParentSubscriberId 
	LEFT JOIN ProductRate pr
	ON pr.ProductRateId = ISNULL(sol.ProductRateId ,(SELECT MIN(pr.ProductRateId )
												FROM Productrate pr
													LEFT JOIN DespatchDeliveryArea dda
													on dda.CountryID = s.PrimaryCountryId 
													AND dda.CompanyId = so.CompanyId 
												WHERE pr.ProductCode = so.primaryProductCode 
												AND pr.CurrencyCode = so.CurrencyCode 
												AND pr.RateType = ca.RateType  
												AND pr.AccountType  = ca.AccountType 
												AND pr.SubscriberCategory   = compAffil.SubscriberCategory  
												AND pr.DeliveryArea   = ISNULL(dda.DespatchDeliveryArea    ,'All')
												)
												)
WHERE so.OrderNumber IN ( 62723 ,62673)
ORDER BY 
	so.OrderNumber 
	,CASE WHEN sol.SubscriberId IS NULL THEN 0 ELSE 1 END DESC
	,S.SubscriberName 
