begin tran

select 
sa.AddressType 
,count(*)
from SubscriberAddress sa
group by
sa.AddressType 

delete from SubscriberAddress 
where AddressType in ('Telephone','Fax')

select 
sa.AddressType 
,count(*)
from SubscriberAddress sa
group by
sa.AddressType 

DELETE FROM Lookup WHERE LookupNAme = 'AddressType' AND LookupItemKey IN ('Telephone','Fax')

commit tran