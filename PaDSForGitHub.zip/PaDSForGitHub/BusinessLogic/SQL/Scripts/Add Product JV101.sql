begin tran
declare @dt datetime = GETDATE()
--JV101
INSERT INTO Product (
ProductCode
,ProductName
,ProductStatus
,CompanyID
,IsCarriageCharge
,IsParent
,ReleaseDate
,ParentProductCode
,AssociatedProductCode
,Notes
,ProductShortName
,IsForReporting
,ReportProportion
,ProductReportName
,CreatedDateTime
,CreatedByUserId
,LastUpdatedDateTime
,LastUpdatedByUserId
,RecurringSubscriptionFlag
,RecurringSubscriptionUnits
,SellOnWebFlag
,TermsAndConditionsFileName
,ProductGroupingName
,OnePerSubscriberFlag
,CheckAgainstOrderType
,RecurringSubscriptionUnitType
,ShippedProductFlag
,SalesReportProductGrouping
)
SELECT 
ProductCode = 'JV101'
,ProductName = 'JV101 Online Journal 2020'
,ProductStatus = 'Current'
,CompanyID = 1
,IsCarriageCharge = 0
,IsParent = 1
,ReleaseDate = '01-sep-2019'
,ParentProductCode=null
,AssociatedProductCode = 'PV101'
,Notes=''
,ProductShortName='JV101'
,IsForReporting= 0
,ReportProportion =NULL
,ProductReportName =NULL
,CreatedDateTime = @dt
,CreatedByUserId = 'jwoosnam'
,LastUpdatedDateTime = @dt
,LastUpdatedByUserId = 'jwoosnam'
,RecurringSubscriptionFlag = 1
,RecurringSubscriptionUnits = 18
,SellOnWebFlag = 1
,TermsAndConditionsFileName = 'JV101.htm'
,ProductGroupingName =NULL
,OnePerSubscriberFlag=0
,CheckAgainstOrderType =NULL
,RecurringSubscriptionUnitType = 'Months'
,ShippedProductFlag = 0
,SalesReportProductGrouping = NULL

INSERT INTO Product (
ProductCode
,ProductName
,ProductStatus
,CompanyID
,IsCarriageCharge
,IsParent
,ReleaseDate
,ParentProductCode
,AssociatedProductCode
,Notes
,ProductShortName
,IsForReporting
,ReportProportion
,ProductReportName
,CreatedDateTime
,CreatedByUserId
,LastUpdatedDateTime
,LastUpdatedByUserId
,RecurringSubscriptionFlag
,RecurringSubscriptionUnits
,SellOnWebFlag
,TermsAndConditionsFileName
,ProductGroupingName
,OnePerSubscriberFlag
,CheckAgainstOrderType
,RecurringSubscriptionUnitType
,ShippedProductFlag
,SalesReportProductGrouping
)
SELECT 
ProductCode = REPLACE(p.ProductCode ,'100','101')
,ProductName = REPLACE(p.ProductCode ,'100','101')
,ProductStatus = 'Current'
,CompanyID = 1
,IsCarriageCharge = 0
,IsParent = 0
,ReleaseDate = DATEADD(YEAR,1,p.ReleaseDate)
,ParentProductCode='JV101'
,AssociatedProductCode = NULL
,Notes=''
,ProductShortName=REPLACE(p.ProductCode ,'100','101')
,IsForReporting= p.IsForReporting 
,ReportProportion =p.ReportProportion 
,ProductReportName =p.ProductReportName 
,CreatedDateTime = @dt
,CreatedByUserId = 'jwoosnam'
,LastUpdatedDateTime = @dt
,LastUpdatedByUserId = 'jwoosnam'
,RecurringSubscriptionFlag = null
,RecurringSubscriptionUnits = null
,SellOnWebFlag = null
,TermsAndConditionsFileName = null
,ProductGroupingName =NULL
,OnePerSubscriberFlag = null
,CheckAgainstOrderType =NULL
,RecurringSubscriptionUnitType = null
,ShippedProductFlag = null
,SalesReportProductGrouping = NULL
FROM Product p
where p.ProductCode  = 'jv100C1'
--*******************************************************************************************************
--*******************************************************************************************************
--*******************************************************************************************************
--PV101  
--*******************************************************************************************************
--*******************************************************************************************************
--*******************************************************************************************************

INSERT INTO Product (
ProductCode
,ProductName
,ProductStatus
,CompanyID
,IsCarriageCharge
,IsParent
,ReleaseDate
,ParentProductCode
,AssociatedProductCode
,Notes
,ProductShortName
,IsForReporting
,ReportProportion
,ProductReportName
,CreatedDateTime
,CreatedByUserId
,LastUpdatedDateTime
,LastUpdatedByUserId
,RecurringSubscriptionFlag
,RecurringSubscriptionUnits
,SellOnWebFlag
,TermsAndConditionsFileName
,ProductGroupingName
,OnePerSubscriberFlag
,CheckAgainstOrderType
,RecurringSubscriptionUnitType
,ShippedProductFlag
,SalesReportProductGrouping
)
SELECT 
ProductCode = 'PV101'
,ProductName = 'PV101 Printed Journal 2020'
,ProductStatus = 'Current'
,CompanyID = 1
,IsCarriageCharge = 0
,IsParent = 1
,ReleaseDate = '01-sep-2019'
,ParentProductCode=null
,AssociatedProductCode = NULL
,Notes=''
,ProductShortName='PV101 Printed'
,IsForReporting= 0
,ReportProportion =NULL
,ProductReportName =NULL
,CreatedDateTime = @dt
,CreatedByUserId = 'jwoosnam'
,LastUpdatedDateTime = @dt
,LastUpdatedByUserId = 'jwoosnam'
,RecurringSubscriptionFlag = 0
,RecurringSubscriptionUnits =NULL
,SellOnWebFlag = 1
,TermsAndConditionsFileName = 'PV101.htm'
,ProductGroupingName =NULL
,OnePerSubscriberFlag=0
,CheckAgainstOrderType =NULL
,RecurringSubscriptionUnitType =NULL
,ShippedProductFlag = 1
,SalesReportProductGrouping = NULL

INSERT INTO Product (
ProductCode
,ProductName
,ProductStatus
,CompanyID
,IsCarriageCharge
,IsParent
,ReleaseDate
,ParentProductCode
,AssociatedProductCode
,Notes
,ProductShortName
,IsForReporting
,ReportProportion
,ProductReportName
,CreatedDateTime
,CreatedByUserId
,LastUpdatedDateTime
,LastUpdatedByUserId
,RecurringSubscriptionFlag
,RecurringSubscriptionUnits
,SellOnWebFlag
,TermsAndConditionsFileName
,ProductGroupingName
,OnePerSubscriberFlag
,CheckAgainstOrderType
,RecurringSubscriptionUnitType
,ShippedProductFlag
,SalesReportProductGrouping
)
SELECT 
ProductCode = REPLACE(p.ProductCode ,'JV100','PV101')
,ProductName = REPLACE(p.ProductCode ,'JV100','PV101')
,ProductStatus = 'Current'
,CompanyID = 1
,IsCarriageCharge = 0
,IsParent = 0
,ReleaseDate = DATEADD(YEAR,1,p.ReleaseDate)
,ParentProductCode='PV101'
,AssociatedProductCode = NULL
,Notes=''
,ProductShortName=REPLACE(p.ProductCode ,'JV100','PV101')
,IsForReporting= p.IsForReporting 
,ReportProportion =p.ReportProportion 
,ProductReportName =p.ProductReportName 
,CreatedDateTime = @dt
,CreatedByUserId = 'jwoosnam'
,LastUpdatedDateTime = @dt
,LastUpdatedByUserId = 'jwoosnam'
,RecurringSubscriptionFlag = null
,RecurringSubscriptionUnits = null
,SellOnWebFlag = null
,TermsAndConditionsFileName = null
,ProductGroupingName =NULL
,OnePerSubscriberFlag = null
,CheckAgainstOrderType =NULL
,RecurringSubscriptionUnitType = null
,ShippedProductFlag = null
,SalesReportProductGrouping = NULL
FROM Product p
where p.ParentProductCode = 'jv100'

SELECT 
CurrencyCode
,RateType 
,AccountType
,SubscriberCategory
,NewUserRateFlag
,SellOnWebFlag 
,ProductRate
INTO #pr1
FROM ProductRate pr
WHERE pr.ProductCode = 'jv100'
delete from #pr1
INSERT INTO #pr1 SELECT 'EUR','Full','Society','Ordinary',0,0,221
INSERT INTO #pr1 SELECT 'EUR','Courtesy','Society','Fellow',0,0,0
INSERT INTO #pr1 SELECT 'EUR','Full','Society','Student',0,0,116
INSERT INTO #pr1 SELECT 'GBP','Full','Society','Fellow',0,0,0
INSERT INTO #pr1 SELECT 'GBP','Full','Agent','Student',0,0,227
INSERT INTO #pr1 SELECT 'GBP','Full','Individual','Ordinary',0,0,227
INSERT INTO #pr1 SELECT 'GBP','Full','Society','Student',0,0,83
INSERT INTO #pr1 SELECT 'GBP','Full','Society','Ordinary',0,0,156
INSERT INTO #pr1 SELECT 'GBP','Full','Society','Retired BPAS',0,0,83
INSERT INTO #pr1 SELECT 'GBP','Full','Agent','Ordinary',0,0,227
INSERT INTO #pr1 SELECT 'USD','Courtesy','Society','Fellow',0,0,0
INSERT INTO #pr1 SELECT 'USD','Full','Society','Ordinary',0,0,231
INSERT INTO #pr1 SELECT 'USD','Full','Society','Student',0,0,148
INSERT INTO #pr1 SELECT 'USD','rate A','Society','Ordinary',0,0,185
INSERT INTO #pr1 SELECT 'USD','rate A','Society','Student',0,0,98
INSERT INTO #pr1 SELECT 'USD','rate B','Society','Student',0,0,98
INSERT INTO #pr1 SELECT 'USD','rate B','Society','Ordinary',0,0,125
INSERT INTO #pr1 SELECT 'USD','rate C','Society','Ordinary',0,0,125
INSERT INTO #pr1 SELECT 'USD','rate C','Society','Student',0,0,98
INSERT INTO #pr1 SELECT 'USD','Full','Individual','Ordinary',1,1,270
INSERT INTO #pr1 SELECT 'USD','Full','Individual','Student',1,1,148
INSERT INTO #pr1 SELECT 'USD','Full','Society','Institutional',0,0,400
INSERT INTO #pr1 SELECT 'GBP','Full','Society','Institutional',0,0,400
INSERT INTO #pr1 SELECT 'EUR','Full','Society','Institutional',0,0,400

--PEPweb Qualifying rates

SELECT 
ProductRateId = 0
,ProductCode = 'JV101'
,CurrencyCode
,RateType 
,AccountType
,SubscriberCategory
,DeliveryArea ='All'
,ProductRate
,CreatedDateTime = @dt
,CreatedByUserId = 'jwoosnam'
,LastUpdatedDateTime = @dt
,LastUpdatedByUserId = 'jwoosnam'
,NewUserRateFlag
,SellOnWebFlag 
INTO #pr
FROM #pr1 pr
--and pr.CurrencyCode  'usd'

alter table #pr add ID INt identity(1,1) 


insert into ProductRate (
ProductCode
,CurrencyCode
,RateType
,AccountType
,SubscriberCategory
,DeliveryArea
,ProductRate
,CreatedDateTime
,CreatedByUserId
,LastUpdatedDateTime
,LastUpdatedByUserId
,NewUserRateFlag
,SellOnWebFlag
)
SELECT 
p2.ProductCode
,CurrencyCode
,RateType
,AccountType
,SubscriberCategory
,DeliveryArea
,ProductRate = CASE WHEN p2.ProductCode='jv101' then p.ProductRate else 0 end
,CreatedDateTime
,CreatedByUserId
,LastUpdatedDateTime
,LastUpdatedByUserId
,NewUserRateFlag
,SellOnWebFlag
FROM #pr p
	CROSS JOIN (SELECT ProductCode = 'JV101'
				UNION
				SELECT ProductCode = 'PV101') p2


update Product set
--select *, dateadd(year ,-1,CAST('01-JAN-' + FORMAT(getdate(),'yyyy') as datetime)),
 ProductStatus = 'Withdrawn'
 from product p
where CompanyID = 1
and ReleaseDate <= dateadd(year ,-1,CAST('01-JAN-' + FORMAT(getdate(),'yyyy') as datetime))
and p.ProductStatus<>'Withdrawn'

select * 
from Product p 
where  p.CompanyID = 1 
and p.ProductStatus = 'current'
and (p.IsParent = 1 or p.ParentProductCode in (select p2.productcode from product p2 where p2.CompanyID =1))
order by case when p.IsParent=1 then p.productcode else p.parentproductcode end 
		,p.ProductCode 
		,p.ParentProductCode 

select * from productrate where ProductCode in ('jv101','pv101')

select
cp.ProductCode
,cp.AssociatedProductCode 
,prm.CurrencyCode
,prm.RateType 
,prm.AccountType 
,prm.SubscriberCategory
,prm.DeliveryArea 
,MainRate = prm.ProductRate 
,AssociatedRate = pra.ProductRate 
from (
select
p.ProductCode 
,p.AssociatedProductCode 
from Product p
where p.ProductStatus = 'current'
and isnull(p.AssociatedProductCode,'') <> ''
and p.IsParent = 1
) cp
	INNER JOIN ProductRate prm
	on prm.ProductCode = cp.ProductCode 
	LEFT JOIN ProductRate pra
	ON pra.ProductCode = cp.AssociatedProductCode 
	AND pra.CurrencyCode = prm.CurrencyCode 
	AND pra.RateType = prm.RateType 
	AND pra.AccountType  = prm.AccountType 
	AND pra.SubscriberCategory = prm.SubscriberCategory 
	AND pra.DeliveryArea = prm.DeliveryArea 
ORDER BY 
cp.ProductCode
,cp.AssociatedProductCode 
,prm.CurrencyCode
,prm.RateType 
,prm.AccountType 
,prm.SubscriberCategory
,prm.DeliveryArea 
update Product 
set ProductStatus = 'Withdrawn'
where ReleaseDate < '01-jan-2019'
and companyid =1

UPDATE Product
SET CompanyID = 1
WHERE Productcode in ('IJOD','IJP-es','IJP-CHI')


select p.ProductCode 
,p.ProductName 
,p.ReleaseDate 
,c.ProductCode 
,c.ReleaseDate 
from Product p
	inner join Product c
	on c.ParentProductCode = p.ProductCode 
where p.CompanyID = 1
and p.ProductStatus = 'current'
and p.IsParent = 1
order by case when p.ParentProductCode is null then p.ProductCode else p.ParentProductCode end
,p.ProductCode 



rollback tran