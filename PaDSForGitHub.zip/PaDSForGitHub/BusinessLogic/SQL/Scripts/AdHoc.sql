exec sp601PopulateActivityLog 39733

rollback tran