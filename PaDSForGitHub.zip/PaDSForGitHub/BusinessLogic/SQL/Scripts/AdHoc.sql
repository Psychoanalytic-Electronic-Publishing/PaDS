SELECT
	u.UserId 
	,u.UserFullName 
	,s.FirstName 
	,LastName = ISNULL(s.LastName ,u.UserFullName )
	,u.EmailAddress 
	,SendJournalAlerts = ISNULL(u.SendJournalAlerts ,0)
	,SendVideoAlerts = ISNULL(u.SendVideoAlerts,0)
FROM RemoteUser u
	LEFT JOIN RemoteUserRights rur
		LEFT JOIN Subscriber s
		ON s.SubscriberId = rur.RightsToId 
	ON rur.UserId = u.UserId 
	AND rur.RightsType = 'Subscriber'
WHERE u.UserStatus = 'Active'
AND (U.SendJournalAlerts = 1 OR u.SendVideoAlerts = 1)