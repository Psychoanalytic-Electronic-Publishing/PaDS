ALTER DATABASE Pads_live SET SINGLE_USER WITH ROLLBACK IMMEDIATE

alter database pAds_Live set offline with rollback immediate


/*
alter database pAds_Live set ONLINE

ALTER DATABASE pads_live SET MULTI_USER

*/