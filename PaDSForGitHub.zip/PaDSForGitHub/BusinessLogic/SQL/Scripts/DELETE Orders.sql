Begin tran

select 
so.OrderNumber  
into #ord

from SalesOrder so
where So.SubscriberId = 9509
and so.PrimaryProductCode = 'jv96'

delete from SalesOrderLinePart where OrderNumber in (select OrderNumber from #ord)
delete from SalesOrderLine where OrderNumber in (select OrderNumber from #ord)
delete from SalesOrder where OrderNumber in (select OrderNumber from #ord)
drop table #ord
commit tran