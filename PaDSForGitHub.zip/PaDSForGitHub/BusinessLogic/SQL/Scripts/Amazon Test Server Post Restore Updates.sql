begin tran
USE Pads_Live
DECLARE @PaDS01PrivateIPAddress VARCHAR(100) = '172.30.0.153'
UPDATE stblParameters SET ParameterValue = CASE ParameterName 
 WHEN 'aaa' THEN ParameterValue
 WHEN 'ADOConnectionString' THEN ParameterValue
 WHEN 'AllContentSetIdsForAdmin' THEN ParameterValue 
 WHEN 'BlindCopyEmailAddress' THEN 'julian.gates@Zedra.co.uk'
 WHEN 'BofAAPIPassword' THEN ParameterValue
 WHEN 'BofAAPIUserName' THEN ParameterValue
 WHEN 'BofAMerchantId' THEN ParameterValue
 WHEN 'BofASettlementURL' THEN 'https://padstest.zedra.net/pages/pg228SettlementInterface2.asp'
 WHEN 'ChecksEmailLastSentDateTime' THEN ParameterValue
 WHEN 'CORSAllowedOrigins' THEN 'http://localhost:57752,http://localhost:4200,http://gavant.pep-web.rocks:4200,https://localhost:4200,https://gavant.pep-web.rocks:4200,https://stage.pep-web.rocks,https://pep-web.rocks,https://www.pep-web.rocks,https://pep-web.org,https://www.pep-web.org'
 WHEN 'CounterPlatformName' THEN ParameterValue
 WHEN 'CurrentContentYear' THEN ParameterValue
 WHEN 'CybersourceMerchantID' THEN ParameterValue
 WHEN 'CybersourceSecurityPassword' THEN 's1Z0zjC8Uxna7XmEpXawZE3Z//iBDzs/+i81RDRK7ak3GjJYQzad3IuzIvUGBdgnxk5wD1A6WzOxitEZeRj9L3pvf/D2d1DguroAb6MjsEJa3eJHANK9/wV/4apuxhXV65mqLWQlueFYo28t05dh0ulCSPOXPQRpZ1mb3FSViZyDhiWfUDok2Fgc8v2mTal4Umr73Pc56lTOD2gqbaKJJxe1CF1g//T5+VNcVU9yNkGUrZI2elFt6AXZjRihIx2nIcOmQi6agQ+xIfcKJU5uE6nZHOV+FQa2Ku5dnj0lzRKIuiviqSkZzvovkmHNu4MeLcSRhyLJwAja9N4dlNbXqw=='
 WHEN 'DatabaseVersion' THEN ParameterValue
 WHEN 'DateTimeSecondaryConenctionUnavailable' THEN ParameterValue
 WHEN 'DBCommandTimeoutForDBBackup' THEN ParameterValue
 WHEN 'DefaultVATRateId' THEN ParameterValue
 WHEN 'DropboxCheckInternalMinutes' THEN ParameterValue
 WHEN 'DropboxTestFileId' THEN ParameterValue
 WHEN 'EmailFrom' THEN 'zedrasupport@googlemail.com'
 WHEN 'EmailFromForCompanyId:1' THEN 'Support@Zedra.co.uk'
 WHEN 'EmailFromForCompanyId:2' THEN 'Support@Zedra.co.uk'
 WHEN 'EmailSupport' THEN ParameterValue
 WHEN 'FailoverIfPrimaryDownForMoreThanXMinutes' THEN ParameterValue
 WHEN 'FailoverStartedFailingAtDateTime' THEN ParameterValue
 WHEN 'FailoverThisIsMasterServer' THEN ParameterValue
 WHEN 'FailoverThisIsMasterServerDesc' THEN 'zzzzz'
 WHEN 'FirstReminderDaysBefore' THEN ParameterValue
 WHEN 'HoursToConfirmNewEmail' THEN '24'
 WHEN 'LastDatabaseBackupDateTimeFor080PaDSCheck' THEN ParameterValue
 WHEN 'LatestClientVersion' THEN ParameterValue
 WHEN 'LiveIPAddresses' THEN '184.73.194.23 184.73.194.26'
 WHEN 'MinimumDiskSpaceAllowed' THEN '5368709120'
 WHEN 'MinPasswordLength' THEN '8'
 WHEN 'OidcAuthority' THEN 'https://connect.openathens.net'
 WHEN 'OidcClientId' THEN 'scilab-inc.com.oidc-app-v1.13e6122c-62af-46bd-95ad-0ee6cb51d145'
 WHEN 'OidcClientSecret' THEN 'y5mAEanHXXQGHRYEWXzaneBs1'
 WHEN 'OidcLogonURL' THEN 'https://connect.openathens.net/scilab-inc.com/13e6122c-62af-46bd-95ad-0ee6cb51d145/login'
 WHEN 'OidcRedirectUrl' THEN 'https://stage-pads.pep-web.rocks/Federated/'
 WHEN 'PaDSClientIdForOPAS' THEN '3'
 WHEN 'PaDSFederatedPortalURL' THEN 'https://pads.pep-web.rocks/federated/'
 WHEN 'PaDSPEPSecureAPIURL' THEN 'https://pads.pep-web.rocks/PEPSecure/'
 WHEN 'PEPGDPRURL' THEN 'http://support.pep-web.org/subscribe/pads-and-its-data-protection-policy/'
 WHEN 'PEPProductCombinationSecureURL' THEN 'http://www.zedra.net:81/Pads/PEPWeb/PEPWebnnnGateway.asp'
 WHEN 'PEPSecureUserAlertSecurityKey' THEN 'bshkdx&*js:(0'
 WHEN 'PEPWeb2021URL' THEN 'https://stage.pep-web.rocks'
 WHEN 'PEPWeb2021URLzzz' THEN 'https://www.zedra.co.uk'
 WHEN 'PEPWebAPIKey' THEN 'pr2x%$ddE??233aGYKSE'
 WHEN 'PEPwebAPIRoot' THEN 'https://stage-api.pep-web.rocks/v2/'
 WHEN 'PEPwebContentMetadataRoot' THEN 'https://stage-api.pep-web.rocks/v2/Metadata/'
 WHEN 'PaDSSecondaryAuditLogDatabaseName' THEN ParameterValue
 WHEN 'PasswordRetryAttempts' THEN ParameterValue
 WHEN 'PEPGatewayTargetURL' THEN 'https://stage.pep-web.rocks/'
 WHEN 'PEPRenewalEmailBCCAddress' THEN 'Support@Zedra.co.uk'
 WHEN 'PEPRenewalEmailTestToAddress' THEN 'Support@Zedra.co.uk'
 WHEN 'PepSupportEmailAddress' THEN 'support@p-e-p.org'
 WHEN 'PrimaryDatabaseBackupDirectory' THEN ParameterValue
 WHEN 'PrimaryDatabaseBackupDirectoryUNC' THEN ParameterValue
 WHEN 'ReceiptBCCEmailAddressForCompanyId:1' THEN 'Support@Zedra.co.uk'
 WHEN 'ReceiptBCCEmailAddressForCompanyId:2' THEN 'Support@Zedra.co.uk'
 WHEN 'RemoteProductNewOrderFormTextFile' THEN ParameterValue
 WHEN 'RemoteProductRenewOrderFormTextFile' THEN ParameterValue
 WHEN 'ReportOutDirectory' THEN ParameterValue
 WHEN 'ReportsPhysicalDir' THEN ParameterValue
 WHEN 'ReportTemplateDirectory' THEN 'C:\Dropbox\PaDSTest\ReportTemplates'
 WHEN 'RunningSecondaryDBRestore' THEN ParameterValue
 WHEN 'SecondaryDatabaseBackupDirectory' THEN ParameterValue
 WHEN 'SecondaryDatabaseBackupDirectoryUNC' THEN ParameterValue
 WHEN 'SecondReminderDaysBefore' THEN ParameterValue
 WHEN 'ServerDescription' THEN 'Amazon Test Server'
 WHEN 'ServiceRegistryKey' THEN ParameterValue
 WHEN 'SessionTimeout' THEN ParameterValue
 WHEN 'SMTPEnableSsL' THEN ParameterValue
 WHEN 'SMTPPassword' THEN 'kUhduk-9muqde-rujkap'
 WHEN 'SMTPServer' THEN 'smtp.gmail.com'
 WHEN 'SMTPUser' THEN 'zedrasupport@googlemail.com'
 WHEN 'ShowFullError' THEN 'False'
 WHEN 'SQLFileDirectory' THEN '\\' + @PaDS01PrivateIPAddress + '\c$\PaDS\SQLLive'
 WHEN 'SuperGroupSubscriberId' THEN ParameterValue
 WHEN 'SystemID' THEN ParameterValue
 WHEN 'SystemName' THEN ParameterValue
 WHEN 'SpoofPassword' THEN 'bhj67GHB2#$VGbN*JkJu0'
 WHEN 'TermsConditionsDirectory' THEN ParameterValue
 WHEN 'TermsConditionsDirectoryPhysicalPath' THEN 'c:\Dropbox\PaDSTest\TermsAndConditions\'
 WHEN 'TransferBackupNo' THEN ParameterValue
 WHEN 'TransferBackupsNoOfBeforeFull' THEN ParameterValue
 WHEN 'UniversalContentRegPtrn' THEN '0000A|PEPGRANTVS.001.0002A|pepgrantvs.001.0002a'
 WHEN 'UserActionLogLastPEPWebLogId' THEN ParameterValue
 WHEN 'UserActionLogLastPEPWebSessionLogId' THEN ParameterValue
 WHEN 'WebSiteURL' THEN 'https://stage-pads.pep-web.rocks'
 WHEN 'zzzzCybersourceMerchantID_BOA' THEN ParameterValue
 WHEN 'zzzzCybersourceSecurityKeyPath' THEN ParameterValue
 WHEN 'zzzzCybersourceSecurityPassword_BOA' THEN ParameterValue
 WHEN 'zzzzCybersourceSendToProduction' THEN ParameterValue
 WHEN 'zzzzCybersourceTargetAPIVersion' THEN ParameterValue
 WHEN 'zzzzEmailPassword' THEN ParameterValue
 WHEN 'zzzzEmailSMTPServer' THEN ParameterValue

 ELSE '99999' END  

 select *
	,FixThis = CASE WHEN ParameterValue='99999' THEN '**Dont just leave as 99999' ELSE '' END --10/11/20	Added by James
 from stblParameters 
 order by CASE WHEN ParameterValue='99999' THEN 0 ELSE 1 END
	,ParameterName

 UPDATE BatchJob
 Set BatchJobStatus = 'PendingPaused'
 WHERE BatchJobStatus = 'Pending'


  commit tran
  GO
  	IF NOT EXISTS(select * from master..sysdatabases where name = 'PaDSSecondaryAuditLog')
	BEGIN

	  CREATE DATABASE [PaDSSecondaryAuditLog]
		 CONTAINMENT = NONE
		 ON  PRIMARY 
		( NAME = N'PaDSSecondaryAuditLog', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\PaDSSecondaryAuditLog.mdf' , SIZE = 116736KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
		 LOG ON 
		( NAME = N'PaDSSecondaryAuditLog_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\PaDSSecondaryAuditLog_log.ldf' , SIZE = 20480KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
		
	
	END

GO
	USE [PaDSSecondaryAuditLog]
	if not exists(select * from sysobjects where name = 'SecondaryAuditLog' and type = 'u')
	BEGIN
		CREATE USER [PaDSSQLServerUser] FOR LOGIN [PaDSSQLServerUser]
		
		CREATE TABLE [dbo].[SecondaryAuditLog](
			[AuditLogId] [int] IDENTITY(1,1) NOT NULL,
			[TableName] [varchar](50) NOT NULL,
			[AuditDate] [datetime] NOT NULL,
			[UpdatedByUserName] [varchar](50) NULL,
			[UpdatedRecordFamily] [varchar](50) NULL,
			[UpdatedRecordFamilyKey] [varchar](50) NULL,
			[UpdatedRecordKey] [varchar](100) NULL,
			[ModificationType] [varchar](20) NULL,
			[AfterDescription] [varchar](max) NULL,
		 CONSTRAINT [PK_AuditLog] PRIMARY KEY CLUSTERED 
		(
			[AuditDate] DESC,
			[AuditLogId] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
		GRANT  SELECT,INSERT,UPDATE,DELETE ON [SecondaryAuditLog] TO PaDSSQLServerUser
	END

USE PaDS_Live 
go