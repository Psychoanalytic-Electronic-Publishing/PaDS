begin tran
USE Pads_Live
DECLARE @PaDS01PrivateIPAddress VARCHAR(100) = '172.30.0.170'
UPDATE stblParameters SET ParameterValue = CASE ParameterName 
 WHEN 'aaa' THEN ParameterValue
 WHEN 'ADOConnectionString' THEN ParameterValue
 WHEN 'BlindCopyEmailAddress' THEN 'julian.gates@Zedra.co.uk'
 WHEN 'BofAAPIPassword' THEN ParameterValue
 WHEN 'BofAAPIUserName' THEN ParameterValue
 WHEN 'BofAMerchantId' THEN ParameterValue
 WHEN 'BofASettlementURL' THEN 'https://padstest.zedra.net/pages/pg228SettlementInterface2.asp'
 WHEN 'ChecksEmailLastSentDateTime' THEN ParameterValue
 WHEN 'CybersourceMerchantID' THEN ParameterValue
 WHEN 'CybersourceSecurityPassword' THEN 'Z0iuM/+4oKjYDYcrD99PCqjhVDF14JW6u3nvpSBMn1kX9jNLdHWK3qVTp4q6AG6rrh/QR4JJzEVWiEXrFcJo3dwWV55YgK3UuoGgX0e9S+mH/Hhw4mQ7TDOJ0HoY6ligA4cRm8Opo23Cg5rV91v6LoooR2ayEJjF738CydqGqnhmXD1sztoT0PRO2Y4PMSauaOp43HfSK3wPBIvi+ZJgEt+VzQWYhscHxMT/Yo5BRtnYko+IK/I5AOOtooGJ6MifccQ3UsMkp9C1UPolezcm9L1yWgpnA3+DegRz1ITPdIuGsZcGL2X657dvKNfABbW8MW9RLtQI97jYMfIeTPEXpg=='
 WHEN 'DatabaseVersion' THEN ParameterValue
 WHEN 'DateTimeSecondaryConenctionUnavailable' THEN ParameterValue
 WHEN 'DBCommandTimeoutForDBBackup' THEN ParameterValue
 WHEN 'DefaultVATRateId' THEN ParameterValue
 WHEN 'DropboxCheckInternalMinutes' THEN ParameterValue
 WHEN 'DropboxTestFileId' THEN ParameterValue
 WHEN 'EmailFrom' THEN 'zedrasupport@googlemail.com'
 WHEN 'EmailFromForCompanyId:1' THEN 'Support@Zedra.co.uk'
 WHEN 'EmailFromForCompanyId:2' THEN 'Support@Zedra.co.uk'
 WHEN 'EmailSupport' THEN ParameterValue
 WHEN 'FailoverIfPrimaryDownForMoreThanXMinutes' THEN ParameterValue
 WHEN 'FailoverStartedFailingAtDateTime' THEN ParameterValue
 WHEN 'FailoverThisIsMasterServer' THEN ParameterValue
 WHEN 'FailoverThisIsMasterServerDesc' THEN 'zzzzz'
 WHEN 'FirstReminderDaysBefore' THEN ParameterValue
 WHEN 'HoursToConfirmNewEmail' THEN '24'
 WHEN 'LastDatabaseBackupDateTimeFor080PaDSCheck' THEN ParameterValue
 WHEN 'LatestClientVersion' THEN ParameterValue
 WHEN 'LiveIPAddresses' THEN '184.73.194.23 184.73.194.26'
 WHEN 'MinimumDiskSpaceAllowed' THEN '5368709120'
 WHEN 'MinPasswordLength' THEN '8'
 WHEN 'PaDSSecondaryAuditLogDatabaseName' THEN ParameterValue
 WHEN 'PasswordRetryAttempts' THEN ParameterValue
 WHEN 'PEPGatewayTargetURL' THEN ParameterValue
 WHEN 'PEPRenewalEmailBCCAddress' THEN 'Support@Zedra.co.uk'
 WHEN 'PEPRenewalEmailTestToAddress' THEN 'Support@Zedra.co.uk'
 WHEN 'PepSupportEmailAddress' THEN 'support@p-e-p.org'
 WHEN 'PrimaryDatabaseBackupDirectory' THEN ParameterValue
 WHEN 'PrimaryDatabaseBackupDirectoryUNC' THEN ParameterValue
 WHEN 'ReceiptBCCEmailAddressForCompanyId:1' THEN 'Support@Zedra.co.uk'
 WHEN 'ReceiptBCCEmailAddressForCompanyId:2' THEN 'Support@Zedra.co.uk'
 WHEN 'RemoteProductNewOrderFormTextFile' THEN ParameterValue
 WHEN 'RemoteProductRenewOrderFormTextFile' THEN ParameterValue
 WHEN 'ReportOutDirectory' THEN ParameterValue
 WHEN 'ReportsPhysicalDir' THEN ParameterValue
 WHEN 'ReportTemplateDirectory' THEN 'C:\Dropbox\PaDSTest\ReportTemplates'
 WHEN 'RunningSecondaryDBRestore' THEN ParameterValue
 WHEN 'SecondaryDatabaseBackupDirectory' THEN ParameterValue
 WHEN 'SecondaryDatabaseBackupDirectoryUNC' THEN ParameterValue
 WHEN 'SecondReminderDaysBefore' THEN ParameterValue
 WHEN 'ServerDescription' THEN 'Amazon Test Server'
 WHEN 'ServiceRegistryKey' THEN ParameterValue
 WHEN 'SessionTimeout' THEN ParameterValue
 WHEN 'SMTPEnableSsL' THEN ParameterValue
 WHEN 'SMTPPassword' THEN 'kUhduk-9muqde-rujkap'
 WHEN 'SMTPServer' THEN 'smtp.gmail.com'
 WHEN 'SMTPUser' THEN 'zedrasupport@googlemail.com'
 WHEN 'ShowFullError' THEN 'False'
 WHEN 'SQLFileDirectory' THEN '\\' + @PaDS01PrivateIPAddress + '\c$\PaDS\SQLLive'
 WHEN 'SuperGroupSubscriberId' THEN ParameterValue
 WHEN 'SystemID' THEN ParameterValue
 WHEN 'SystemName' THEN ParameterValue
 WHEN 'SpoofPassword' THEN 'bhj67GHB2#$VGbN*JkJu0'
 WHEN 'TermsConditionsDirectory' THEN ParameterValue
 WHEN 'TermsConditionsDirectoryPhysicalPath' THEN 'c:\Dropbox\PaDSTest\TermsAndConditions\'
 WHEN 'TransferBackupNo' THEN ParameterValue
 WHEN 'TransferBackupsNoOfBeforeFull' THEN ParameterValue
 WHEN 'WebSiteURL' THEN 'https://padstest.zedra.net'
 WHEN 'zzzzCybersourceMerchantID_BOA' THEN ParameterValue
 WHEN 'zzzzCybersourceSecurityKeyPath' THEN ParameterValue
 WHEN 'zzzzCybersourceSecurityPassword_BOA' THEN ParameterValue
 WHEN 'zzzzCybersourceSendToProduction' THEN ParameterValue
 WHEN 'zzzzCybersourceTargetAPIVersion' THEN ParameterValue
 WHEN 'zzzzEmailPassword' THEN ParameterValue
 WHEN 'zzzzEmailSMTPServer' THEN ParameterValue

 ELSE '99999' END  

 select *
	,FixThis = CASE WHEN ParameterValue='99999' THEN '**Dont just leave as 99999' ELSE '' END --10/11/20	Added by James
 from stblParameters 
 order by CASE WHEN ParameterValue='99999' THEN 0 ELSE 1 END
	,ParameterName

 UPDATE BatchJob
 Set BatchJobStatus = 'PendingPaused'
 WHERE BatchJobStatus = 'Pending'


  commit tran
  GO
  	IF NOT EXISTS(select * from master..sysdatabases where name = 'PaDSSecondaryAuditLog')
	BEGIN

	  CREATE DATABASE [PaDSSecondaryAuditLog]
		 CONTAINMENT = NONE
		 ON  PRIMARY 
		( NAME = N'PaDSSecondaryAuditLog', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\PaDSSecondaryAuditLog.mdf' , SIZE = 116736KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
		 LOG ON 
		( NAME = N'PaDSSecondaryAuditLog_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQL\DATA\PaDSSecondaryAuditLog_log.ldf' , SIZE = 20480KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
		
	
	END

GO
	USE [PaDSSecondaryAuditLog]
	if not exists(select * from sysobjects where name = 'SecondaryAuditLog' and type = 'u')
	BEGIN
		CREATE USER [PaDSSQLServerUser] FOR LOGIN [PaDSSQLServerUser]
		
		CREATE TABLE [dbo].[SecondaryAuditLog](
			[AuditLogId] [int] IDENTITY(1,1) NOT NULL,
			[TableName] [varchar](50) NOT NULL,
			[AuditDate] [datetime] NOT NULL,
			[UpdatedByUserName] [varchar](50) NULL,
			[UpdatedRecordFamily] [varchar](50) NULL,
			[UpdatedRecordFamilyKey] [varchar](50) NULL,
			[UpdatedRecordKey] [varchar](100) NULL,
			[ModificationType] [varchar](20) NULL,
			[AfterDescription] [varchar](max) NULL,
		 CONSTRAINT [PK_AuditLog] PRIMARY KEY CLUSTERED 
		(
			[AuditDate] DESC,
			[AuditLogId] ASC
		)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
		) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
		GRANT  SELECT,INSERT,UPDATE,DELETE ON [SecondaryAuditLog] TO PaDSSQLServerUser
	END

USE PaDS_Live 
go