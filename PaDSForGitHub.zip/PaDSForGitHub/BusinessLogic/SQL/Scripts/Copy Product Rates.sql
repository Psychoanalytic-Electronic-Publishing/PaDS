--Copy Product rates for a product
begin tran
DECLARE @CopyFromProductCode VARCHAR(10) = 'JV95'
DECLARE @CopyToProductCode VARCHAR(10) = 'JV96'


DECLARE @ProductRateId INT
DECLARE @NewProductRateId INT

select *
from ProductRate 
where ProductCode = @CopyToProductCode

DECLARE cRates CURSOR FOR
	select pr.ProductRateId 
from ProductRate pr
where pr.ProductCode = @CopyFromProductCode

	OPEN cRates 
	FETCH cRates INTO @ProductRateId
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		exec sp005GetNextTableNumber 'ProductRate',@NewProductRateId OUTPUT
		INSERT INTO ProductRate (
			ProductRateId
			,ProductCode
			,CurrencyCode
			,RateType
			,AccountType
			,SubscriberCategory
			,DeliveryArea
			,ProductRate
			,CreatedDateTime
			,CreatedByUserId
			,LastUpdatedDateTime
			,LastUpdatedByUserId
			,NewUserRateFlag
			,SellOnWebFlag

		)
		SELECT 
			ProductRateId = @NewProductRateId 
			,ProductCode = @CopyToProductCode
			,CurrencyCode
			,RateType
			,AccountType
			,SubscriberCategory
			,DeliveryArea
			,ProductRate
			,CreatedDateTime = GETDATE()
			,CreatedByUserId = 1
			,LastUpdatedDateTime = GETDATE()
			,LastUpdatedByUserId = 1
			,NewUserRateFlag
			,SellOnWebFlag
		FROM ProductRate pr
		WHERE pr.ProductRateId = @ProductRateId 
		FETCH cRates INTO @ProductRateId
	END
	CLOSE cRates 
	DEALLOCATE cRates 

select *
from ProductRate 
where ProductCode = @CopyToProductCode

rollback tran