begin tran
declare @dt datetime = GETDATE()

SELECT 
CurrencyCode
,RateType 
,AccountType
,SubscriberCategory
,NewUserRateFlag
,SellOnWebFlag 
,ProductRate
INTO #pr1
FROM ProductRate pr
WHERE pr.ProductCode = 'jv101'
delete from #pr1


INSERT INTO #pr1 SELECT 'USD','rate D','Individual','Ordinary',0,1,135.99
INSERT INTO #pr1 SELECT 'USD','rate D','Individual','Student',0,1,74.99


--PEPweb Qualifying rates

SELECT 
ProductRateId = 0
,ProductCode = 'JV101'
,CurrencyCode
,RateType 
,AccountType
,SubscriberCategory
,DeliveryArea ='All'
,ProductRate
,CreatedDateTime = @dt
,CreatedByUserId = 'jwoosnam'
,LastUpdatedDateTime = @dt
,LastUpdatedByUserId = 'jwoosnam'
,NewUserRateFlag
,SellOnWebFlag 
INTO #pr
FROM #pr1 pr
--and pr.CurrencyCode  'usd'

alter table #pr add ID INt identity(1,1) 


insert into ProductRate (
ProductCode
,CurrencyCode
,RateType
,AccountType
,SubscriberCategory
,DeliveryArea
,ProductRate
,CreatedDateTime
,CreatedByUserId
,LastUpdatedDateTime
,LastUpdatedByUserId
,NewUserRateFlag
,SellOnWebFlag
)
SELECT 
p2.ProductCode
,CurrencyCode
,RateType
,AccountType
,SubscriberCategory
,DeliveryArea
,ProductRate = CASE WHEN p2.ProductCode='jv101' then p.ProductRate else 0 end
,CreatedDateTime
,CreatedByUserId
,LastUpdatedDateTime
,LastUpdatedByUserId
,NewUserRateFlag
,SellOnWebFlag
FROM #pr p
	CROSS JOIN (SELECT ProductCode = 'JV101'
				--UNION  don't need PV101 rates
				--SELECT ProductCode = 'PV101'
				) p2



INSERT INTO ProductQualifyingProduct (
ProductCode
,QualifyingProductCode
,SubscriberCategory
,ProductRateId
,MustBuyFlag
,TerminatedSubscriptionsGracePeriodMonths
,CheckAgainstOrderType
)
SELECT
ProductCode = 'JV101'
,QualifyingProductCode = q.QualifyingProductCode 
,SubscriberCategory = a.SubscriberCategory 
,ProductRateId = (select pr.ProductRateId  from ProductRate pr where pr.RateType = 'rate d' and pr.ProductCode = 'jv101' and SubscriberCategory=a.SubscriberCategory )
,MustBuyFlag = 0
,TerminatedSubscriptionsGracePeriodMonths = 0
,CheckAgainstOrderType = 'All'
FROM (select SubscriberCategory='Ordinary'
	  UNION 
	  select SubscriberCategory='Student'
	  ) a
	  CROSS JOIN (
	  select QualifyingProductCode = 'PEPweb' UNION
	  select QualifyingProductCode = 'Pepweb3y' UNION
	  select QualifyingProductCode = 'PEPWEBS' 
	  ) Q


select top 10 * from ProductRate order by ProductRateId desc
select  * from ProductQualifyingProduct where ProductCode = 'jv101'

select
	solp.SubscriberId 
	,solp.ProductCode
	,soli.ProductCode 
	,HasBoth = case when  soli.OrderNumber is  null then 'n' else 'y' end
from SalesOrderLine solp
	left join SalesOrderLine soli
	on soli.SubscriberId = solp.SubscriberId 
	and solp.ProductCode IN ('JV100','EJV100','PV100')
where solp.ProductCode in ( 'pepwebs','pepweb')
and solp.RecurringSubscriptionEndDate > getdate()



order by 1

commit tran