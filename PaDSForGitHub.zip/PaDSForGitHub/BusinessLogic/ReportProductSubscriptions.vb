﻿'Modification History
'Feb 2018       James Woosnam   SIR4571 - Initial Version


Public Class ReportProductSubscriptions
    Inherits ReportSSG
#Region "Class Properties"
    Dim BatchJobId As Integer = Nothing
    Dim StartDate As Date = Nothing
    Dim EndDate As Date = Nothing
    Dim CompanyId As Integer = Nothing
#End Region

    Public Sub New(ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("ProductSubscriptions", "Excel", db, SubmittedByUserSessionId)
    End Sub
    Public Sub New(ByVal StartDate As Date, ByVal EndDate As Date, CompanyId As Integer, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("ProductSubscriptions", "Excel", db, SubmittedByUserSessionId)
        Me.StartDate = StartDate
        Me.EndDate = EndDate
        Me.CompanyId = CompanyId
    End Sub
    Public Overloads Sub Submit()

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSessionId
        BatchJob.Parameters.Add("ReportName", Me.ReportName)
        BatchJob.Parameters.Add("CompanyId", CompanyId)
        BatchJob.Parameters.Add("StartDate", StartDate.ToString("dd-MMM-yyyy"))
        BatchJob.Parameters.Add("EndDate", EndDate.ToString("dd-MMM-yyyy"))
        BatchJob.CreateBatchJobEntry("RunReportSpreadsheetGearExcel", Me.db)

    End Sub

    Public Overloads Sub Execute(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.JobParameters = Parameters
        Me.StartDate = Parameters.GetValue("StartDate")
        Me.EndDate = Parameters.GetValue("EndDate")
        Me.CompanyId = Parameters.GetValue("CompanyId")
        Me.Execute()
    End Sub

    Public Overloads Sub Execute(Optional ByVal InBatchLog As BatchLog = Nothing)

        Dim batchLogCreatedHere As Boolean = False
        If InBatchLog Is Nothing Then
            Me.BatchLog = New BatchLog("Report-" & Me.ReportName _
                                          , ";StartDate=" & Me.StartDate _
                                         & ";EndDate=" & Me.EndDate _
                                         , Me.db _
                                         , BatchJobId _
                                         , Me.SubmittedByUserSessionId)
            batchLogCreatedHere = True
        Else
            Me.BatchLog = InBatchLog
        End If
        Try
            MyBase.Execute(Me.BatchLog)

            Me.ExcelWorkBook = SpreadsheetGear.Factory.GetWorkbook(Me.ExcelTemplate.FullName)

            Me.ReportSQL = "EXEC sp455ProductSubscriptionsReport 
                    @StartDate = " & db.vFQ(StartDate, "d") & "
					,@EndDate = " & db.vFQ(EndDate, "d") & "
					,@CompanyId = " & Me.CompanyId
            Dim tblRep As DataTable = db.GetDataTableFromSQL(Me.ReportSQL)

            Dim Currencies As New List(Of String)


            Dim wsData As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Data")
            Dim wsCriteria As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Criteria")
            Dim CompanyName As String = db.DLookup("CompanyName", "Company", "CompanyId=" & CompanyId)
            wsCriteria.Cells("CompanyName").Value = CompanyName
            wsCriteria.Cells("StartDate").Value = StartDate
            wsCriteria.Cells("EndDate").Value = EndDate
            wsCriteria.Cells("DateRun").Value = Now.ToString("dd-MMM-yyyy HH:mm")
            wsCriteria.Cells("UserName").Value = Me.SubmittedByUserSession.UserFullName

            Dim rgBase As SpreadsheetGear.IRange
            rgBase = wsData.Cells("DataRows")
            rgBase.CopyFromDataTable(tblRep, SpreadsheetGear.Data.SetDataFlags.InsertCells + SpreadsheetGear.Data.SetDataFlags.None) '+ SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders)

            ReportName = ReportName & " For " & CompanyName & " " & StartDate.ToString(" dd-MMM-yyyy") & " to " & EndDate.ToString("dd-MMM-yyyy")
            ExcelWorkBook.SaveAs(Me.ReportFile.FullName, SpreadsheetGear.FileFormat.OpenXMLWorkbook)
            BatchLog.Update(Me.FileLink)

            If batchLogCreatedHere Then
                BatchLog.Update("Process Complete", "Complete")
            End If
        Catch ex As Exception
            BatchLog.Update("Report Failed:" & ex.Message, "Failed")
            Throw New Exception("Report Failed:" & ex.Message, ex)

        End Try

    End Sub

End Class
