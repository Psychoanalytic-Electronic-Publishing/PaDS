﻿Imports System.Data.SqlClient
'Modification History
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields
'20/2/21 James Woosnam  SIR5190 - Open connection direct to SecondaryAuditLogDatabas as main secondary db may be locked by 1/2 hourly restore

Public Class AuditLog

#Region "Class Properties"
    Dim FieldAndColumnNameSeparator As String = "|"
    Dim RecordTable As RecordTables = Nothing
    Dim UpdatedRecordKey As String = Nothing
    Dim UserSession As UserSession
    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property
    Dim _SecondaryAuditDB As Database = Nothing
    Private ReadOnly Property SecondaryAuditDB As Database
        '20/2/21 James Woosnam  SIR5190 - Open connection direct to SecondaryAuditLogDatabas as main secondary db may be locked by 1/2 hourly restore
        Get
            If _SecondaryAuditDB Is Nothing Then
                _SecondaryAuditDB = New Database(db.SecondaryConnectionString.Replace(db.DBConnection.Database, PaDSSecondaryAuditLogDatabaseName))
            End If
            Return _SecondaryAuditDB
        End Get

    End Property
    Dim _PaDSSecondaryAuditLogDatabaseName As String = Nothing
    Private ReadOnly Property PaDSSecondaryAuditLogDatabaseName As String
        Get
            If _PaDSSecondaryAuditLogDatabaseName = Nothing Then _PaDSSecondaryAuditLogDatabaseName = db.GetParameterValue("PaDSSecondaryAuditLogDatabaseName")
            Return _PaDSSecondaryAuditLogDatabaseName
        End Get
    End Property

    Enum RecordTables
        Cashbook
        SalesOrder
        Subscriber
        RemoteUser
    End Enum
#End Region
    Sub New(ByVal db As BusinessLogic.Database)
        Me.db = db
    End Sub
    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
    End Sub
    Dim _ColumnNames As Dictionary(Of RecordTables, String) = Nothing
    Private Function GetColumeNames(RecordTableForColumnNames As RecordTables) As String
        Dim colNames As String = Nothing
        If _ColumnNames Is Nothing Then
            _ColumnNames = New Dictionary(Of RecordTables, String)
        End If
        If Not _ColumnNames.ContainsKey(RecordTableForColumnNames) Then
            Dim tbl As DataTable = db.GetDataTableFromSQL(Me.GetRecordSQL(RecordTableForColumnNames, -1))
            For Each col As DataColumn In tbl.Columns
                colNames += IIf(colNames = "", "", FieldAndColumnNameSeparator) & col.ColumnName
            Next
            _ColumnNames(RecordTableForColumnNames) = colNames
        End If

        Return _ColumnNames(RecordTableForColumnNames)
    End Function
    Private Function GetRecordSQL(SQLForRecordtable As RecordTables, RecordKeyToFind As Integer) As String
        Dim sql As String = Nothing
        Select Case SQLForRecordtable
            Case RecordTables.Cashbook
                sql = "
                SELECT
	                c.*
	                ,s.SubscriberName 
	                ,bd.DateBanked 
                FROM Cashbook c
	                LEFT JOIN Subscriber s
	                ON s.SubscriberId = c.SubscriberId 
	                LEFT JOIN BankDeposit bd
	                ON bd.BankDepositId = c.BankDepositId 
                WHERE c.CashbookId = " & RecordKeyToFind
            Case RecordTables.SalesOrder
                sql = "
               SELECT
	                AccountSubscriberId = so.SubscriberId 
	                ,AccountSubscriberName = sa.SubscriberName 
	                ,so.*
	                ,sol.*
                FROM SalesOrder so
	                INNER JOIN SalesOrderLine sol
	                ON sol.OrderNumber = so.OrderNumber 
	                INNER JOIN Subscriber sa
	                ON sa.SubscriberId = so.SubscriberId 
                WHERE so.OrderNumber = " & RecordKeyToFind
            Case RecordTables.Subscriber
                sql = "
                SELECT
	                s.*
	                ,BillingAddress = saPostBill.AddressText 
	                ,MainAddress = saPostMain.AddressText 
	                ,Email = saEmail.AddressText 
                FROM Subscriber s
	                LEFT JOIN SubscriberAddress saPostBill
	                ON saPostBill.SubscriberId = s.SubscriberId 
	                AND saPostBill.AddressType  = 'Postal'
	                AND saPostBill.AddressDescription = 'Billing'

	                LEFT JOIN SubscriberAddress saPostMain
	                ON saPostMain.SubscriberId = s.SubscriberId 
	                AND saPostMain.AddressType  = 'Postal'
	                AND saPostMain.AddressDescription = 'Main'
	
	                LEFT JOIN SubscriberAddress saEmail
	                ON saEmail.SubscriberId = s.SubscriberId 
	                AND saEmail.AddressType  = 'Email'
	                AND saEmail.AddressDescription = 'Mail'

                WHERE s.SubscriberId = " & RecordKeyToFind
            Case RecordTables.RemoteUser
                sql = "
                SELECT
	                ru.*
	                ,rur.RightsType
	                ,rur.RightsToId
                FROM RemoteUser ru
                    INNER JOIN RemoteUserRights rur
                    ON rur.UserId = ru.UserId
                WHERE ru.UserId = " & RecordKeyToFind
        End Select

        Return sql
    End Function
    Sub WriteAuditLog(RecordTable As RecordTables,
                      UpdatedRecordKey As String)
        If Me.db.DBConnection.Database.ToLower.Contains("pads_try") Then Exit Sub 'skip audit for try version
        Dim AfterDescription As String = Nothing
        Try
            Me.RecordTable = RecordTable
            Me.UpdatedRecordKey = UpdatedRecordKey
            Dim tbl As DataTable = db.GetDataTableFromSQL(GetRecordSQL(RecordTable, UpdatedRecordKey))
            Dim AuditSQL As String = Nothing

            AuditSQL = "
 IF NOT EXISTS(
    SELECT s.AuditLogId 
    FROM " & Me.PaDSSecondaryAuditLogDatabaseName & ".dbo.SecondaryAuditLog s
    WHERE s.AuditLogId = (SELECT MAX(l.AuditLogId )
					    FROM " & Me.PaDSSecondaryAuditLogDatabaseName & ".dbo.SecondaryAuditLog l
					    WHERE 1=1
					    AND l.TableName = @TableName
					    AND l.UpdatedByUserName = @UpdatedByUserName
					    AND l.UpdatedRecordFamily = @UpdatedRecordFamily
					    AND l.UpdatedRecordFamilyKey = @UpdatedRecordFamilyKey
					    AND l.UpdatedRecordKey = @UpdatedRecordKey
					    AND l.ModificationType = @ModificationType
    )
    AND s.AfterDescription = @AfterDescription
)
INSERT INTO " & Me.PaDSSecondaryAuditLogDatabaseName & ".dbo.SecondaryAuditLog(
	TableName,
	AuditDate,
	UpdatedByUserName,
	UpdatedRecordFamily,
	UpdatedRecordFamilyKey,
	UpdatedRecordKey,
	ModificationType,
	AfterDescription
    )
SELECT
    TableName = @TableName
    ,AuditDate = GETDATE()
    ,UpdatedByUserName = @UpdatedByUserName
    ,UpdatedRecordFamily = @UpdatedRecordFamily
    ,UpdatedRecordFamilyKey = @UpdatedRecordFamilyKey
    ,UpdatedRecordKey = @UpdatedRecordKey
    ,ModificationType = @ModificationType
    ,AfterDescription = @AfterDescription
            "




            For Each row As DataRow In tbl.Rows
                For Each col As DataColumn In tbl.Columns
                    AfterDescription += IIf(AfterDescription = "", "", FieldAndColumnNameSeparator) & row(col.ColumnName.ToString)
                Next
                '20/2/21 James Woosnam  Open connection direct to SecondaryAuditLogDatabas as main secondary db may be locked by 1/2 hourly restore
                Dim cmd As New SqlCommand(AuditSQL, Me.SecondaryAuditDB.DBConnection)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TableName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      RecordTable.ToString))
                If RecordTable = RecordTables.Subscriber And UserSession.UserName Is Nothing Then
                    'Changed WebUserName to SubscriberName as WebUserName no longer is used in subscriber table
                    '17/2/20    James Woosnam   SIR5021 - tuncate longer sub name to 50 in Audit log.
                    cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UpdatedByUserName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      Left(db.IsDBNull(row("SubscriberName"), "Unknown").ToString, 50)))
                ElseIf RecordTable = RecordTables.RemoteUser And UserSession.UserName Is Nothing Then
                    'If use resending password then UserSession.UserNamein nothing so use onwn UserName
                    cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UpdatedByUserName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          db.IsDBNull(row("UserName"), "Unknown")))
                Else
                    cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UpdatedByUserName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                    UserSession.UserName))
                End If

                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UpdatedRecordFamily", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      RecordTable.ToString))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UpdatedRecordFamilyKey", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                       Me.UpdatedRecordKey))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UpdatedRecordKey", System.Data.SqlDbType.VarChar, 100, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                       Me.UpdatedRecordKey))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ModificationType", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      "Update"))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AfterDescription", System.Data.SqlDbType.VarChar, -1, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                          AfterDescription))
                Try
                    cmd.ExecuteNonQuery()
                Catch ex As Exception
                    Throw ex
                End Try
            Next


        Catch ex As Exception
            '10/6/20    James Woosnam   If fails only stop process if error email also fails
            Try
                Dim em As New Email(db)
                Dim bdy As String = "Write Secondary AuditLog on failed:" & ex.Message
                bdy += Environment.NewLine & "Table:" & Me.RecordTable.ToString & " Id:" & UpdatedRecordKey
                bdy += Environment.NewLine & "AfterDesc:" & AfterDescription
                em.SendErrorEmail("Write Secondary AuditLog on failed", bdy)
            Catch ex1 As Exception
                Throw New Exception("Write Secondary AuditLog on " & Me.RecordTable.ToString & " failed:" & ex.Message & " and ErrorEmailFailed:" & ex1.Message, ex)
            End Try
        End Try
    End Sub

    Public Function GetAuditChanges() As DataTable
        Try
            Dim sql As String = "
SELECT 
	a.*
	,BeforeDescription = ISNULL(prev.AfterDescription,'')
FROM " & Me.PaDSSecondaryAuditLogDatabaseName & ".dbo.SecondaryAuditLog a
	LEFT JOIN " & Me.PaDSSecondaryAuditLogDatabaseName & ".dbo.SecondaryAuditLog prev
	ON prev.UpdatedRecordFamily = a.UpdatedRecordFamily 
	AND prev.UpdatedRecordFamilyKey = a.UpdatedRecordFamilyKey 
	AND prev.UpdatedRecordKey = a.UpdatedRecordFamilyKey 
	AND prev.TableName = a.TableName 
	AND prev.AfterDescription <> a.AfterDescription 
	and prev.AuditDate = (SELECT MAX(da.AuditDate ) 
						FROM " & Me.PaDSSecondaryAuditLogDatabaseName & ".dbo.SecondaryAuditLog da
						WHERE da.UpdatedRecordFamily = a.UpdatedRecordFamily 
						AND da.UpdatedRecordFamilyKey = a.UpdatedRecordFamilyKey 
						AND da.UpdatedRecordKey = a.UpdatedRecordFamilyKey 
						AND da.TableName = a.TableName  
						AND da.AuditDate < a.AuditDate)  
ORDER BY a.AuditDate desc

"
            Dim tbl As DataTable = Me.SecondaryAuditDB.GetDataTableFromSQL(sql)
            tbl.Columns.Add(New DataColumn("ColumnNames"))
            For Each row As DataRow In tbl.Rows
                row("ColumnNames") = Me.GetColumeNames([Enum].Parse(GetType(RecordTables), row("TableName")))
            Next

            Return tbl

        Catch ex As Exception
            Throw New Exception("GetAuditChanges failed:" & ex.Message, ex)
        End Try

    End Function
End Class
