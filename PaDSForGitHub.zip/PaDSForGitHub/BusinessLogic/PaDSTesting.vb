﻿Imports BusinessLogic
Imports System.Data.SqlClient
Imports System.Environment
Public Class PaDSTesting
#Region "Class Properties"
    Dim testProductsAdded As New ArrayList()
    Public ProgressMessage As String = ""
    Private _db As Database = Nothing

    Public Property db() As Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As Database)

            Me._db = value
        End Set
    End Property
    Public Sub New(db As Database)
        Me.db = db
    End Sub
    Dim _UsrSessGeneral As UserSession = Nothing
    Private ReadOnly Property UsrSessGeneral As UserSession
        Get
            If _UsrSessGeneral Is Nothing Then
                _UsrSessGeneral = New BusinessLogic.UserSession(db)
                _UsrSessGeneral.Restore("")
            End If
            Return _UsrSessGeneral
        End Get
    End Property
#End Region
    Public Sub DeleteAllTestData()
        db.BeginTran()
        Try
            Me.DeleteProducts()
            ProgressMessage += "Products Deleted" & NewLine
            Me.DeleteContentsets()
            ProgressMessage += "Content sets Deleted" & NewLine
            For Each r As DataRow In Me.TestSubscribers.Rows
                Me.DeleteUserAndSubscriber(db.IsDBNull(r("UserName"), "sfgddghj"), r("SubscriberId"))
                ProgressMessage += r("SubscriberName") & " Deleted" & NewLine
            Next
            Me.DeleteUserAndSubscriber("Test6", 0)

            db.CommitTran()
        Catch ex As Exception
            db.RollbackTran()
            Throw ex
        End Try
    End Sub
    Public Sub ResetTestData(TestUserPassword As String)
        Try
            db.BeginTran()
            Try
                If TestUserPassword = "" Then Throw New Exception("TestUserPassword must not be blank")
                Me.TestUserPassword = TestUserPassword
                CreateTestProducts()
                ProgressMessage += "Products Created" & NewLine
                CreateTestContent()
                ProgressMessage += "Content Created" & NewLine
                CreateTestUsersSubsAndOrders()
                ProgressMessage += "Subs, Users and orders Created" & NewLine

                db.CommitTran()
            Catch ex As Exception
                db.RollbackTran()
                Throw ex
            End Try


        Catch ex As Exception
            Throw ex
        End Try
    End Sub

#Region "Populate Data"
    Dim emailTemplate As String = "PaDSxx@zedra.net"
    Public ReadOnly Property TestSubscribers As DataTable
        Get
            Dim sql As String = "
SELECT DISTINCT	
	s.SubscriberId
	,s.SubscriberName 
	,sa.AddressText 
	,ru.UserName 
FROM Subscriber s
    INNER JOIN SubscriberAddress sa
	ON sa.SubscriberId = s.SubscriberId 
	AND sa.AddressType = 'Email'
	LEFT JOIN RemoteUserRights rur
		INNER JOIN RemoteUser ru
		ON ru.UserId = rur.UserId 
	ON rur.RightsToId = s.SubscriberId 
	AND rur.RightsType = 'Subscriber'
WHERE sa.AddressText like '" & emailTemplate.Replace("xx", "Test%") & "'
"
            Return db.GetDataTableFromSQL(sql)
        End Get
    End Property
    Sub CreateTestUsersSubsAndOrders()
        db.ExecuteSQL("
            UPDATE stblTableNumber SET LastNumber = 500000 WHERE TableName = 'SalesOrder'
            UPDATE stblTableNumber SET LastNumber = 500000 WHERE TableName = 'Subscriber'
            UPDATE stblTableNumber SET LastNumber = 500000 WHERE TableName = 'RemoteUser'
")
        Dim Subscbr As Subscriber = Nothing
        Dim SubSess As UserSession = Nothing
        Dim usrNm As String = ""
        '*************************
        usrNm = "Test1"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="Archive and JV101",
                                          EmailAddress:=emailTemplate.Replace("xx", usrNm),
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)
        Me.ProgressMessage += "Test1 Added" & NewLine
        Me.AddOrder(Subscbr, SubSess, {"T-PEPweb"}, CandidateStudent:=False)
        Me.AddOrder(Subscbr, SubSess, {"T-JV101", "T-PV101"}, CandidateStudent:=False)
        Me.ProgressMessage += "Test1 orders Added" & NewLine
        '*************************
        usrNm = "Test2"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="Video7Day",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)
        Me.ProgressMessage += "Test2 Added" & NewLine
        Me.AddOrder(Subscbr, SubSess, {"T-Vid7Dy"}, CandidateStudent:=False)
        Me.ProgressMessage += "Test2 order Added" & NewLine
        '*************************
        usrNm = "Test3"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="IJP Only",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)
        Me.ProgressMessage += "Test3 Added" & NewLine
        Me.AddOrder(Subscbr, SubSess, {"T-JV101"}, CandidateStudent:=False)
        Me.AddOrder(Subscbr, SubSess, {"T-JV102"}, CandidateStudent:=False)
        '  Me.AddOrder(Subscbr, SubSess, {"T-PV102"}, CandidateStudent:=False)
        Me.ProgressMessage += "Test3 order Added" & NewLine
        '*************************
        usrNm = "Test4"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="All PEP",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)
        Me.ProgressMessage += "Test4 Added" & NewLine
        Me.AddOrder(Subscbr, SubSess, {"T-PEPCur"}, CandidateStudent:=False, FailIfNotValidWebProduct:=False)
        Me.AddOrder(Subscbr, SubSess, {"T-PEPweb"}, CandidateStudent:=False, FailIfNotValidWebProduct:=True)
        Me.ProgressMessage += "Test4 order Added" & NewLine
        '*************************
        usrNm = "Test5"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="All PEP",
                                          EmailAddress:="PaDS" & usrNm & "@zedra.net",
                                          CandidateStudent:=False)

        SubSess = GetSubscriberSession(Subscbr)
        Me.ProgressMessage += "Test5 Added" & NewLine
        'Çonvert into org
        Subscbr.SubscriberRow("EntityType") = "Organisation"
        Subscbr.SubscriberRow("SubscriberName") = "Test5 Organisation with T-PEPweb"
        Subscbr.Save()
        Dim ru As New RemoteUser(Subscbr.RemoteUser.UserId, db, SubSess)
        ru.RemoteUserRow("Authoritylevel") = "GroupUser"
        ru.Save()
        ru = New RemoteUser(Subscbr.RemoteUser.UserId, db, SubSess)
        Dim newRow As DataRow = ru.RemoteUserAutoLogon.NewRow


        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -2
        newRow("AutoLogonStatus") = "InActive"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.IPAddress.ToString
        newRow("UserId") = ru.UserId
        newRow("Notes") = "Zedra Plusnet Broadband"
        newRow("MinIPAddress") = "81.174.164.198" 'Zedra Plusnet Broadband
        newRow("MaxIPAddress") = "81.174.164.198"
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -6
        newRow("AutoLogonStatus") = "Active"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.IPAddress.ToString
        newRow("UserId") = ru.UserId
        newRow("Notes") = "Random IP for Zedra Postman testing using X-Forwarded-For-PEP header"
        newRow("MinIPAddress") = "101.101.101.101"
        newRow("MaxIPAddress") = "101.101.101.101"
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -3
        newRow("UserId") = ru.UserId
        newRow("AutoLogonStatus") = "InActive"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.IPAddress.ToString
        newRow("Notes") = "Gavant test user"
        newRow("MinIPAddress") = "66.152.101.226" 'Gavant test user
        newRow("MaxIPAddress") = "66.152.101.226"
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -4
        newRow("UserId") = ru.UserId
        newRow("AutoLogonStatus") = "Active"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.Federated.ToString
        newRow("Notes") = "Test OpenAthens User:oasptemptest"
        newRow("FederatedEntity") = "https://sd.openathens.net/entity" '
        newRow("FederatedScope") = "" '
        newRow("IsFederatedLinkRequired") = True '
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -7
        newRow("UserId") = ru.UserId
        newRow("AutoLogonStatus") = "Active"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.Federated.ToString
        newRow("Notes") = "OpenAthens user:peptesting"
        newRow("FederatedEntity") = "https://idp.scilab-inc.com/openathens" '
        newRow("FederatedScope") = "" '
        newRow("IsFederatedLinkRequired") = True '
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        newRow = ru.RemoteUserAutoLogon.NewRow
        newRow("RemoteUserAutoLogonId") = -5
        newRow("UserId") = ru.UserId
        newRow("AutoLogonStatus") = "Active"
        newRow("AutoLogonType") = UserSession.LoggedInMethods.ReferrerURL.ToString
        newRow("Notes") = "Zedra Dev Pads Home"
        newRow("ReferrerURL") = "http://localhost:46339/Pages/pg100HomeAdmin.aspx" '
        ru.RemoteUserAutoLogon.Rows.Add(newRow)

        ru.Save()
        Me.AddOrderBlock(Subscbr, SubSess, {"T-PEPweb"}, New IO.FileInfo("D:\Projects\PaDS2\PaDS\TestData\SubscriberImportFiles\Test4 Import Subscribers01.xlsx"))

        Me.ProgressMessage += "Test5 order Added" & NewLine
        '*************************
        usrNm = "Test6" 'PEP admin user
        'Only need to delete user as no orders or subscriber
        db.ExecuteSQL("
declare @UserId int = (select userid from RemoteUser where username = '" & usrNm & "')
delete from RemoteUserRights   where UserId =@UserId
delete from RemoteUserAutoLogon   where UserId =@UserId
delete From RemoteUser   Where UserId =@UserId")
        ru = New RemoteUser(db, UsrSessGeneral)
        ru.AddNew(EmailAddress:="PaDS" & usrNm & "@zedra.net", AuthorityLevel:=UserSession.AuthorityLevels.SuperCompanyAdmins, FullUserName:=usrNm & " PEP CompanyAdmin")
        ru.UserName = usrNm
        ru.UserStatus = RemoteUser.UserStates.Active
        ru.AddRights(RemoteUser.RightsTypes.Company, 2) 'PEP
        ru.AddRights(RemoteUser.RightsTypes.Subscriber, 29002) 'PEP
        ru.SetPassword(Me.TestUserPassword)
        ru.Save()
        Me.ProgressMessage += "Test6 User Added" & NewLine
        db.GetNextNumber("Subscriber") ' increment the table no for subscriber so next will be 7
        '*************************
        usrNm = "Test7"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="Archive Renewing",
                                          EmailAddress:=emailTemplate.Replace("xx", usrNm),
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)
        Me.ProgressMessage += usrNm & " Added" & NewLine
        Me.AddOrder(Subscbr, SubSess, {"T-PEPweb"}, CandidateStudent:=True)
        Dim ord As New SalesOrder(db.DLookup("MAX(OrderNumber)", "SalesOrder", ""), db, SubSess)
        ord.SalesOrderRow("OrderDate") = CType(ord.SalesOrderRow("OrderDate"), Date).AddYears(-1).AddDays(CType(db.GetParameterValue("FirstReminderDaysBefore"), Integer) - 3)
        ord.SalesOrderRow("SubscriptionStartDateForAdd") = ord.SalesOrderRow("OrderDate")

        ord.Save()
        ord = New SalesOrder(ord.OrderNumber, db, SubSess)
        ord.Save() 'Save again to set RecurringSubscriptionStartDate
        Me.ProgressMessage += usrNm & " orders Added" & NewLine

        '*************************
        '*************************
        usrNm = "Test8"
        Subscbr = Me.AddSubscriberAndUser(LastUserName:=usrNm,
                                          FirstName:="RegisteredUser",
                                          EmailAddress:=emailTemplate.Replace("xx", usrNm),
                                          CandidateStudent:=False)
        SubSess = GetSubscriberSession(Subscbr)

        For Each r As DataRow In Subscbr.SubscriberAddress.Rows
            If r("AddressType") = "Postal" Then
                r.Delete()
            End If
        Next
        Subscbr.SubscriberRow("DefaultPostalAddressId") = DBNull.Value
        Subscbr.AddSubscriberAffiliate(500005)

        Subscbr.Save()
        Me.ProgressMessage += usrNm & " Added" & NewLine
        '*************************



        db.ExecuteSQL("
            UPDATE stblTableNumber SET LastNumber = (SELECT MAX(OrderNumber) FROM SalesOrder WHERE OrderNumber < 500000) WHERE TableName = 'SalesOrder'
            UPDATE stblTableNumber SET LastNumber = (SELECT MAX(SubscriberId) FROM Subscriber WHERE SubscriberId < 500000) WHERE TableName = 'Subscriber'
            UPDATE stblTableNumber SET LastNumber = (SELECT MAX(UserId) FROM RemoteUser WHERE UserId < 500000) WHERE TableName = 'RemoteUser'
")
    End Sub

    Sub CreateTestProducts()

        Me.DeleteProducts()
        Dim prod As Product = Nothing
        '*******************************
        prod = Me.AddProduct(ProductCode:="T-PEPweb",
                  CompanyId:=2,
                  AssociatedProductCode:="",
                  RecurringSubscriptionFlag:=True,
                    RecurringSubscriptionUnitType:="Months",
                    RecurringSubscriptionUnits:=12,
                    SellOnWebFlag:=True)
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=230,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=110,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Society",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=150,
                    NewUserRateFlag:=False,
                    SellOnWebFlag:=False
                    )
        '*******************************
        prod = Me.AddProduct(ProductCode:="T-PV101",
                  CompanyId:=1,
                 AssociatedProductCode:="")
        prod.ProductRow("ReleaseDate") = CDate("01-jan-2020")
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=0,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=0,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        '*******************************
        prod = Me.AddProduct(ProductCode:="T-JV101",
                  CompanyId:=1,
                  RecurringSubscriptionFlag:=True,
                    RecurringSubscriptionUnitType:="Months",
                    RecurringSubscriptionUnits:=12,
                    SellOnWebFlag:=True,
                    AssociatedProductCode:="T-PV101")
        prod.ProductRow("ReleaseDate") = CDate("01-jan-2020")
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=270,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=135,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        '*******************************
        prod = Me.AddProduct(ProductCode:="T-Vid7Dy",
              CompanyId:=2,
              AssociatedProductCode:="",
              RecurringSubscriptionFlag:=True,
                RecurringSubscriptionUnitType:="Hours",
                RecurringSubscriptionUnits:=(7 * 24),
                SellOnWebFlag:=True)
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=20,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=10,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )

        '*******************************
        prod = Me.AddProduct(ProductCode:="T-PEPCur",
                  CompanyId:=2,
                  AssociatedProductCode:="",
                  RecurringSubscriptionFlag:=True,
                    RecurringSubscriptionUnitType:="Months",
                    RecurringSubscriptionUnits:=1000,
                    SellOnWebFlag:=False)
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=0,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )

        '*******************************

        '***JV102*****
        '*******************************
        If 1 = 2 Then

        End If
        prod = Me.AddProduct(ProductCode:="T-PV102",
                  CompanyId:=1,
                 AssociatedProductCode:="")
        '   prod.ProductRow("ReleaseDate") = IIf(Now > CDate("01-sep-2020"), CDate("01-jan-2021"), Now.Date.AddDays(-1))
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=0,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=0,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        'Qualifying rate for subs buying paper after main journal, ProductQualifyingProduct added after JV102 created
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="rate D",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=30,
                    NewUserRateFlag:=False,
                    SellOnWebFlag:=True
                    )
        Dim PV102QualRateId As Integer = db.DLookup("MAX(ProductRateId)", "ProductRate", "")
        '*******************************
        prod = Me.AddProduct(ProductCode:="T-JV102",
                  CompanyId:=1,
                  RecurringSubscriptionFlag:=True,
                    RecurringSubscriptionUnitType:="Months",
                    RecurringSubscriptionUnits:=12,
                    SellOnWebFlag:=True,
                    AssociatedProductCode:="T-PV102")
        '   prod.ProductRow("ReleaseDate") = IIf(Now > CDate("01-jan-2020"), CDate("01-jan-2021"), Now.Date.AddDays(-1))
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=270,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=148,
                    NewUserRateFlag:=True,
                    SellOnWebFlag:=True
                    )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Ordinary",
                    DeliveryArea:="All",
                    ProductRate:=243,
                    NewUserRateFlag:=False,
                    SellOnWebFlag:=True
                    )
        prod.AddProductQualifyingProduct(QualifyingProductCode:="T-JV101",
                                          SubscriberCategory:="Ordinary",
                                           ProductRateId:=db.DLookup("MAX(ProductRateId)", "ProductRate", ""),
                                            MustBuyFlag:=False,'*** If true will be added to t-JV101 order!!
                                             CheckAgainstOrderType:="All",
                                              TerminatedSubscriptionsGracePeriodMonths:=12
                                        )
        prod.AddProductRate(CurrencyCode:="USD",
                    RateType:="Full",
                    AccountType:="Individual",
                    SubscriberCategory:="Student",
                    DeliveryArea:="All",
                    ProductRate:=133,
                    NewUserRateFlag:=False,
                    SellOnWebFlag:=True
                    )
        prod.AddProductQualifyingProduct(QualifyingProductCode:="T-JV101",
                                          SubscriberCategory:="Student",
                                           ProductRateId:=db.DLookup("MAX(ProductRateId)", "ProductRate", ""),
                                            MustBuyFlag:=False,
                                             CheckAgainstOrderType:="All",
                                              TerminatedSubscriptionsGracePeriodMonths:=12
                                        )
        '*******************************
        prod = New BusinessLogic.Product("T-PV102", db, UsrSessGeneral)
        'Add ProductQualifyingProduct for PV102 $30 after initial purchase
        prod.AddProductQualifyingProduct(QualifyingProductCode:="T-JV102",
                                  SubscriberCategory:="Ordinary",
                                   ProductRateId:=PV102QualRateId,
                                    MustBuyFlag:=False,'*** If true will be added to t-JV101 order!!
                                     CheckAgainstOrderType:="All",
                                      TerminatedSubscriptionsGracePeriodMonths:=12
                                )
    End Sub
    Sub CreateTestContent()

        Dim cs As New ContentSet(db, UsrSessGeneral)
        Me.DeleteContentsets()

        db.ExecuteSQL("
DBCC CHECKIDENT ('Contentset', RESEED, 1000)
DBCC CHECKIDENT ('ContentSetSource', RESEED, 1000)
DBCC CHECKIDENT ('ContentSetSourceItem', RESEED, 1000)
DBCC CHECKIDENT ('ProductContentSet', RESEED, 1000)
")

        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="T-All NonEmbargoed (Archive)")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.ContentSetRow("GivesAccessToAllArchiveContent") = 1
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = True
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Book)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Book)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Video)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Video)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.Save()
        Me.AddProductContentSet({"T-PEPweb"}, cs.ContentSetId)
        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="T-Video")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Video)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Video)
            .Item("IncludeAllSourceItems") = True
        End With
        cs.Save()
        Me.AddProductContentSet({"T-Vid7Dy"}, cs.ContentSetId)
        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="T-IJP Year 0 & 1")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = False
            .Item("ExcludeEmbargoedYears") = False
            .Item("EmbargoedYearsOnly") = True
            .Item("OverrideEmbargoYears") = 2
        End With
        cs.Save()
        cs = New ContentSet(cs.ContentSetId, db, UsrSessGeneral)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            Dim r As DataRow = cs.ContentSetSourceItem.NewRow
            r("ContentSetSourceItemId") = -1
            r("ContentSetSourceId") = .Item("ContentSetSourceId")
            r("ContentCode") = "IJP"
            cs.ContentSetSourceItem.Rows.Add(r)
        End With
        cs.Save()
        Me.AddProductContentSet({"T-JV101"}, cs.ContentSetId)
        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="T-All Embargoed (Current)")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.ContentSetRow("GivesAccessToAllCurrentContent") = 1
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = True
            .Item("EmbargoedYearsOnly") = True
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Book)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Book)
            .Item("IncludeAllSourceItems") = True
            .Item("EmbargoedYearsOnly") = False
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Video)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Video)
            .Item("IncludeAllSourceItems") = True
            .Item("EmbargoedYearsOnly") = False
        End With
        cs.Save()
        Me.AddProductContentSet({"T-PEPCur"}, cs.ContentSetId)
        '*******************************
    End Sub

#End Region


#Region "Actions"


    Sub AddProductContentSet(products As String(), ContentSetId As Integer, Optional checkAddedTestProduct As Boolean = True)
        For Each prd As String In products
            If checkAddedTestProduct Then
                If Not testProductsAdded.Contains(prd) Then Throw New Exception("AddProductContentSet Test ProductCode:" & prd & " hasn't been added")
            End If
            db.ExecuteSQL("INSERT INTO ProductContentSet (ProductCode,ContentSetId) SELECT '" & prd & "' ," & ContentSetId)
        Next

    End Sub
    Function AddProduct(ProductCode As String,
                   CompanyId As Integer,
                   Optional AssociatedProductCode As String = "",
                   Optional RecurringSubscriptionFlag As Boolean = False,
                   Optional RecurringSubscriptionUnitType As String = "",
                   Optional RecurringSubscriptionUnits As String = "",
                   Optional SellOnWebFlag As Boolean = True) As Product
        Try
            If ProductCode.Length > 8 Then
                Throw New Exception("PrtoductCode: " & ProductCode & " must be no more than 8 characeters (2 added for child)")
            End If
            testProductsAdded.Add(ProductCode)
            Dim prod As New Product(db, Me.UsrSessGeneral)
            prod.AddNewProduct(ProductCode:=ProductCode,
                          ProductName:=ProductCode & " Testing",
                          ProductStatus:="Current",
                          CompanyID:=CompanyId,
                          Notes:="",
                          ShippedProductFlag:=False,
                          TermsAndConditionsFileName:="",
                          ProductGroupingName:=ProductCode,
                          ProductShortName:=ProductCode,
                          ReleaseDate:=CDate("01-" & Now.ToString("MMM-yyyy")),
                          AssociatedProductCode:=AssociatedProductCode,
                          RecurringSubscriptionFlag:=RecurringSubscriptionFlag,
                          RecurringSubscriptionUnitType:=RecurringSubscriptionUnitType,
                          RecurringSubscriptionUnits:=RecurringSubscriptionUnits,
                          SellOnWebFlag:=SellOnWebFlag,
                          OnePerSubscriberFlag:=True,
                          CheckAgainstOrderType:="All"
                            )

            Return prod
        Catch ex As Exception
            Throw ex
        End Try
    End Function


    Sub AddOrder(Subscbr As Subscriber, UserSess As UserSession, products() As String, CandidateStudent As Boolean, Optional FailIfNotValidWebProduct As Boolean = True)
        Try
            For Each prd As String In products
                If Not testProductsAdded.Contains(prd) Then Throw New Exception("Test ProductCode:" & prd & " hasn'True been added")
            Next
            Dim so As New SalesOrder(db, UserSess)
            Dim companyID As Integer = db.DLookup("CompanyId", "Product", "ProductCode='" & products(0) & "'")
            If New DataView(Subscbr.CompanyAccount, "CompanyId=" & companyID, "", DataViewRowState.CurrentRows).Count = 0 Then
                Dim vw As New DataView(Subscbr.SubscriberAddress, "AddressType='Postal'", "", DataViewRowState.CurrentRows)
                Subscbr.AddCompanyAccount(CompanyId:=companyID, AccountType:="Individual", DiscountRateId:=1, RateType:="Full", BillingAddressId:=vw(0)("SubscriberAddressId"))
            End If
            Subscbr.AddSubscriberAffiliate(ParentSubscriberId:=db.DLookup("GroupParentSubscriberId", "Company", "CompanyId=" & companyID), AffiliateReferenceId:="", SubscriberCategory:=IIf(CandidateStudent, "Student", "Ordinary"))
            Dim cmd As New SqlCommand("sp235WebProducts", db.DBConnection, db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            'cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CompanyId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
            '                                                              , companyID))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , Subscbr.SubscriberId))
            Dim webProds As DataTable = db.GetDataTableFromSQL(cmd)

            Dim tProd As New DataTable
            For Each col As DataColumn In webProds.Columns
                tProd.Columns.Add(New DataColumn(col.ColumnName))
            Next
            For Each r As DataRow In webProds.Rows
                If products.Contains(r("ProductCode")) Then
                    Dim nr As DataRow = tProd.NewRow
                    For Each col As DataColumn In webProds.Columns
                        nr(col.ColumnName) = r(col.ColumnName)
                    Next
                    tProd.Rows.Add(nr)
                End If
            Next
            If tProd.Rows.Count = 0 Then
                If FailIfNotValidWebProduct Then Throw New Exception("AddOrder failed for Sub:" & Subscbr.SubscriberName & ". Ordered prods not returned by sp235WebProducts, FirstProd:" & products(0))
                so.Add(ProductCode:=products(0),
                         CurrencyCode:="USD",
                         OrderType:="Individual",
                         SalesOrderStatus:="Partial",
                         SubscriberId:=Subscbr.SubscriberId,
                         SubscriptionStartDateForAdd:=Now())
                so = New SalesOrder(so.OrderNumber, db, UserSess)
                For i As Integer = 0 To products.Length - 1
                    Dim ProductRateId As Integer = db.DLookup("MIN(productRateId)", "ProductRate", "ProductCode='" & products(i) & "'")
                    so.AddNewSalesOrderLine(Product:=New BusinessLogic.Product(products(i), db, UserSess),
                                          SubscriberId:=Subscbr.SubscriberId,
                                           ProductRateId:=ProductRateId,
                                           RecurringStartDate:=Now())

                Next
                so.Save()
                Dim cb As New Cashbook(db, UserSess)
                cb.InternalAdd(OrderNumber:=so.OrderNumber,
                      CompanyId:=companyID,
                     EntryType:="payment",
                     PaymentType:="Cash",
                     SubscriberId:=Subscbr.SubscriberId)
                cb = New BusinessLogic.Cashbook(cb.CashbookId, db, UserSess)
                cb.CashbookRow("CashbookStatus") = "Confirmed"
                cb.Save()

            Else
                'web order
                so.Add(tProd)
                so.AddSalesOrderLines(tProd)
                so = New SalesOrder(so.OrderNumber, db, UserSess)
                '  so.Save()
                Dim cb As New Cashbook(db, UserSess)
                cb.RemoteAdd(OrderNumber:=so.OrderNumber,
                            SalesOrderRow:=so.SalesOrderRow,
                            PaymentCardType:="MasterCard",
                            PaymentCardNumber:="5555555555554444",
                            PaymentCardName:=Subscbr.SubscriberName,
                            PaymentCardExpiryDate:="12-25",
                            PaymentCardCVNumber:="123"
                            )
                If Not db.IsOnLiveServer And Not db.DBConnection.Database.ToLower.Contains("pads_try") Then
                    'Hard code credit card number as cashbook save corrupt them for security.
                    cb.AuthenticateCreditCard("5555555555554444", "123")
                Else
                    cb.CashbookRow("CashbookStatus") = "Confirmed"
                End If
                cb.Save()

                Select Case cb.CashbookRow("CashbookStatus")
                    Case "Confirmed"
                    Case Else
                        cb = New Cashbook(cb.CashbookId, db, UserSess)
                        cb.CashbookRow("CashbookStatus") = "Confirmed"
                        ProgressMessage += "Cashbook for:" & Subscbr.SubscriberName & " confirmed manually as authorisation failed:" & cb.CashbookRow("PaymentCardRejectDescription") & NewLine
                        cb.Save()
                End Select
            End If

            so = New SalesOrder(so.OrderNumber, db, UserSess)
            so.SalesOrderRow("SalesOrderStatus") = "Confirmed"
            so.SalesOrderRow("OrderDate") = System.DateTime.Now.Date
            so.SalesOrderRow("AmountCarriage") = 0
            so.SalesOrderRow("PercentVAT") = 0
            so.Save()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Sub AddOrderBlock(Subscbr As Subscriber, UserSess As UserSession, products() As String, ImportFile As IO.FileInfo)
        Try
            For Each prd As String In products
                If Not testProductsAdded.Contains(prd) Then Throw New Exception("Test ProductCode:" & prd & " hasn't been added")
            Next
            Dim so As New SalesOrder(db, UserSess)
            Dim companyID As Integer = db.DLookup("CompanyId", "Product", "ProductCode='" & products(0) & "'")
            If New DataView(Subscbr.CompanyAccount, "CompanyId=" & companyID, "", DataViewRowState.CurrentRows).Count = 0 Then
                Dim vw As New DataView(Subscbr.SubscriberAddress, "AddressType='Postal'", "", DataViewRowState.CurrentRows)
                Subscbr.AddCompanyAccount(CompanyId:=companyID, AccountType:="Society", DiscountRateId:=1, RateType:="Full", BillingAddressId:=vw(0)("SubscriberAddressId"))
            End If
            Subscbr.AddSubscriberAffiliate(ParentSubscriberId:=db.DLookup("GroupParentSubscriberId", "Company", "CompanyId=" & companyID), AffiliateReferenceId:="", SubscriberCategory:="Ordinary")

            'If Not ImportFile.Exists Then
            '    Throw New Exception("File:" & ImportFile.FullName & "does not exist")
            'End If

            'Dim ib As New BusinessLogic.SubscriberImportBatch(db)
            'ib.AddNew(Subscbr.SubscriberId, companyID, Subscbr.SubscriberName & " Import01")
            'ib.AddFile(SubscriberImportBatch.SubscriberImportBatchFileTypes.BeforeImport, IO.File.ReadAllBytes(ImportFile.FullName), ImportFile.Name)

            Dim primprod As New Product(products(0), db, UserSess)
            so = New SalesOrder(db, UserSess)
            so.Add(ProductCode:=primprod.ProductCode,
                         CurrencyCode:="USD",
                         OrderType:="Block",
                         SalesOrderStatus:="Partial",
                         SubscriberId:=Subscbr.SubscriberId,
                         SubscriptionStartDateForAdd:=Now())
            so = New SalesOrder(so.OrderNumber, db, UserSess)
            Dim rateID As Integer = db.DLookup("MAX(ProductRateId)", "ProductRate", "productCode='" & primprod.ProductCode & "' AND CurrencyCode='USD' AND RateType='Full' AND AccountType='Society'")
            If rateID = Nothing Then Throw New Exception("RateId not found")
            so.AddNewSalesOrderLine(primprod, Subscbr.SubscriberId, rateID, Now())
            so.SalesOrderRow("SalesOrderStatus") = "Confirmed"
            so.SalesOrderRow("OrderDate") = System.DateTime.Now.Date
            so.SalesOrderRow("AmountCarriage") = 0
            so.SalesOrderRow("PercentVAT") = 0.2
            so.Save()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
    Dim TestUserPassword As String = ""
    Public Function AddSubscriberAndUser(LastUserName As String, FirstName As String, EmailAddress As String, Optional CandidateStudent As Boolean = False) As Subscriber
        Try

            Me.DeleteUserAndSubscriber(LastUserName, 0)
            Dim sb As New Subscriber(db, Me.UsrSessGeneral)

            sb.Add(EmailAddress:=EmailAddress,
                        Title:="Mr.",
                        FirstName:=FirstName,
                        LastName:=LastUserName,
                        BillingAddress:=LastUserName & " House, Somewhere",
                        Town:=FirstName,
                        County:="Hants",
                        CountyUS:="",
                        PostCode:="SO211DF",
                        CountryId:="58",
                        CandidateStudent:=CandidateStudent,
                        PrimaryCompanyId:=2,
                        IsReceiveMail:=True,
                        IsBillingAddressAndTitleRequired:=True
                        )
            sb.RemoteUser.UserName = LastUserName
            sb.RemoteUser.UserStatus = RemoteUser.UserStates.Active
            sb.RemoteUser.SetPassword(TestUserPassword)
            sb.RemoteUser.Save()
            sb.SubscriberStatus = Subscriber.SubscriberStates.Current
            sb.Save()
            Return sb

        Catch ex As Exception
            Throw ex
        End Try
        Return Nothing
    End Function

    Function GetSubscriberSession(Subscbr As Subscriber) As UserSession
        Dim pepS As New PEPSecurity(db, "ZedraTestHarness")
        Dim pepsAuthReq As New BusinessLogic.PEPSecurity.AuthenticationRequest
        pepsAuthReq.UserName = Subscbr.RemoteUser.UserName
        pepsAuthReq.Password = Me.TestUserPassword
        Dim authRes As New PEPSecurity.AuthenticationResponse
        authRes = pepS.AuthenticateUser(pepsAuthReq)

        Dim us As New UserSession(db)
        us.Restore(authRes.SessionId)
        Return us
    End Function
#End Region
#Region "Delete Data"


    Sub DeleteUserAndSubscriber(UserName As String, SubscriberId As Integer)

        Dim sql As String = "
declare @UserName varchar(50)='" & UserName & "' 
select SubscriberId = rur.rightstoid , ru.UserId INTO #subs FROM RemoteUserRights rur inner join RemoteUser ru on ru.UserId = rur.UserId where ru.UserName=@UserName and rur.rightstoid >= 500000
INSERT INTO #subs SELECT " & SubscriberId & ",UserId=0
INSERT INTO #subs SELECT 0,UserId FROM RemoteUser WHERE UserName =  @UserName
select ordernumber into #ords from SalesOrderLine where SubscriberId in (select SubscriberId from #subs)

delete BankDeposit from BankDeposit b where b.BankDepositId in (select SubscriberId  from cashbook where SubscriberId in (select SubscriberId from #subs))
delete cashbook from  cashbook where SubscriberId in (select SubscriberId from #subs)

delete from SalesOrderLinePart where OrderNumber in (select ordernumber from #ords )
delete from SalesOrderLine where OrderNumber in (select ordernumber from #ords )
delete from SalesOrder where OrderNumber in (select ordernumber from #ords )

delete from SubscriberAffiliate where childSubscriberId in (select SubscriberId from #subs)
delete from SubscriberAffiliate where ParentSubscriberId in (select SubscriberId from #subs)
delete from CompanyAccount  where SubscriberId in (select SubscriberId from #subs)
delete from SubscriberAddress   where SubscriberId in (select SubscriberId from #subs)
delete from Subscriber   where SubscriberId in (select SubscriberId from #subs)

delete from RemoteUserRights   where UserId in (select userid from #subs)
delete from RemoteUserAutoLogon   where UserId in (select userid from #subs)
delete from RemoteUser   where UserId in (select userid from #subs)
drop table #Subs
drop table #ords
"
        db.ExecuteSQL(sql)

    End Sub
    Sub DeleteContentsets()

        Dim sql As String = "
select ContentSetId  INTO #conts FROM ContentSet where ContentSetId >=1000
delete ContentSetSourceItem  where ContentSetSourceId in (select ContentSetSourceId from ContentSetSource where ContentSetId in (select ContentSetId from #conts ))
delete ProductContentSet   where ContentSetId in (select ContentSetId from #conts )
delete ContentSetSource  where ContentSetId in (select ContentSetId from #conts )
delete ContentSet  where ContentSetId in (select ContentSetId from #conts )

drop table #conts
DECLARE @ID INT = 0
SET @Id = ISNULL((SELECT MAX(ContentSetId) FROM ContentSet ),0) +1
DBCC CHECKIDENT ('Contentset', RESEED, @Id)
SET @Id = ISNULL((SELECT MAX(ContentSetSourceId) FROM ContentSetSource ),0) +1
DBCC CHECKIDENT ('ContentSetSource', RESEED, @id)
SET @Id = ISNULL((SELECT MAX(ContentSetSourceItemId) FROM ContentSetSourceItem ),0) +1
DBCC CHECKIDENT ('ContentSetSourceItem', RESEED, @id)
SET @Id = ISNULL((SELECT MAX(ProductContentSetId) FROM ProductContentSet ),0) +1
DBCC CHECKIDENT ('ProductContentSet', RESEED, @id)
"
        db.ExecuteSQL(sql)

    End Sub
    Sub DeleteProducts()

        Dim sql As String = "
select ProductCode   INTO #prods FROM product  where ProductCode like 'T-%' 
delete ProductAffiliateRate  where ProductCode in (select productcode from #prods )
delete ProductContentSet  where ProductCode in (select productcode from #prods )
delete ProductQualifyingProduct   where ProductCode in (select productcode from #prods )
delete ProductRate   where ProductCode in (select productcode from #prods )
delete Product   where ProductCode in (select productcode from #prods )

drop table #prods 
"
        db.ExecuteSQL(sql)

    End Sub

#End Region

#Region "PopulateBase Content"
    Public Sub DeleteBaseContentSets()

        Dim sql As String = "
select ContentSetId  INTO #conts FROM ContentSet where ContentSetId <10
delete ContentSetSourceItem  where ContentSetSourceId in (select ContentSetSourceId from ContentSetSource where ContentSetId in (select ContentSetId from #conts ))
delete ProductContentSet   where ContentSetId in (select ContentSetId from #conts )
delete ContentSetSource  where ContentSetId in (select ContentSetId from #conts )
delete ContentSet  where ContentSetId in (select ContentSetId from #conts )
drop table #conts

"
        db.ExecuteSQL(sql)
        db.ExecuteSQL(GetBaseResetIdSQL)
        ProgressMessage += "Base content deleted" & NewLine

    End Sub
    Function GetBaseResetIdSQL() As String
        Return "
DECLARE @ID INT = 0
SET @Id = ISNULL((SELECT MAX(ContentSetId) FROM ContentSet WHERE ContentSetId >1000  ),0) +1
IF @Id > 10  SET @Id=10 --Always set to at least 10
DBCC CHECKIDENT ('Contentset', RESEED, 10)
SET @Id = ISNULL((SELECT MAX(ContentSetSourceId) FROM ContentSetSource ),0) +1
DBCC CHECKIDENT ('ContentSetSource', RESEED, @id)
SET @Id = ISNULL((SELECT MAX(ContentSetSourceItemId) FROM ContentSetSourceItem ),0) +1
DBCC CHECKIDENT ('ContentSetSourceItem', RESEED, @id)
SET @Id = ISNULL((SELECT MAX(ProductContentSetId) FROM ProductContentSet ),0) +1
DBCC CHECKIDENT ('ProductContentSet', RESEED, @id)
"

    End Function
    Public Sub CreateBaseContentSets()
        Dim cs As New ContentSet(db, UsrSessGeneral)

        db.ExecuteSQL("
DBCC CHECKIDENT ('Contentset', RESEED, 0)
DBCC CHECKIDENT ('ContentSetSource', RESEED, 0)
DBCC CHECKIDENT ('ContentSetSourceItem', RESEED, 0)
DBCC CHECKIDENT ('ProductContentSet', RESEED, 0)
")

        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="All Content for Admin Users")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.ContentSetRow("GivesAccessToAllArchiveContent") = 1
        cs.ContentSetRow("GivesAccessToAllCurrentContent") = 1
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Book)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Book)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Video)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Video)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.Save()
        ProgressMessage += cs.ContentSetName & " added" & NewLine

        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="All NonEmbargoed (Archive)")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.ContentSetRow("GivesAccessToAllArchiveContent") = 1
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = True
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Book)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Book)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Video)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Video)
            .Item("IncludeAllSourceItems") = True
            .Item("ExcludeEmbargoedYears") = False
        End With
        cs.Save()
        Me.AddProductContentSet({"PEPweb", "PEPWEBS", "Pepweb3y", "PEPWEB24"}, cs.ContentSetId, False)
        ProgressMessage += cs.ContentSetName & " added" & NewLine
        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="All Videos")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Video)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Video)
            .Item("IncludeAllSourceItems") = True
        End With
        cs.Save()
        Me.AddProductContentSet({"Video24"}, cs.ContentSetId, False)
        '*******************************
        cs = New ContentSet(db, UsrSessGeneral)
        cs.AddContentSet(ContentSetName:="IJP JV101")
        cs.ContentSetStatus = ContentSet.ContentSetStates.Active
        cs.AddContentsetSource(ContentSet.ContentSetSourceTypes.Journal)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            .Item("IncludeAllSourceItems") = False
            .Item("ExcludeEmbargoedYears") = False
            .Item("EmbargoedYearsOnly") = True
        End With
        cs.Save()
        cs = New ContentSet(cs.ContentSetId, db, UsrSessGeneral)
        With cs.ContentSetSourceRow(ContentSet.ContentSetSourceTypes.Journal)
            Dim r As DataRow = cs.ContentSetSourceItem.NewRow
            r("ContentSetSourceItemId") = -1
            r("ContentSetSourceId") = .Item("ContentSetSourceId")
            r("ContentCode") = "IJP"
            cs.ContentSetSourceItem.Rows.Add(r)
        End With
        cs.Save()
        Me.AddProductContentSet({"JV101"}, cs.ContentSetId, False)
        ProgressMessage += cs.ContentSetName & " added" & NewLine
        db.ExecuteSQL(GetBaseResetIdSQL)

    End Sub

#End Region
End Class
