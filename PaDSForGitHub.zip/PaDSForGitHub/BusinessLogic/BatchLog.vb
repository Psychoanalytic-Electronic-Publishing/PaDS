﻿Imports System.Data
Imports System.Data.SqlClient
Public Class BatchLog
    '8/9/05     James Woosnam   Add BatchLogStatus as a seperate property
    '8/9/05     James Woosnam   Limit lenght of Description and Type

#Region "Class Properties"
    Dim ds As New DataSet

    Dim _BatchLogId As Long
    Public Property BatchLogId() As Long
        Get
            Return _BatchLogId
        End Get
        Set(ByVal Value As Long)
            If Not IsNumeric(Me.db.DLookup("BatchLogId", "BatchLog", "BatchLogId=" & Value)) Then
                Throw New Exception("BatchLogId:" & Value & " can not be found.")
            End If
            _BatchLogId = Value
        End Set
    End Property
    Dim _BatchLogStatus As String
    Public Property BatchLogStatus() As String
        Get
            Return _BatchLogStatus
        End Get
        Set(ByVal Value As String)
            _BatchLogStatus = Value
        End Set
    End Property
    Private _db As BusinessLogic.Database = Nothing
    Private Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)
            'For batch log try and create a new connection so the log remains even if the tans is rolled back
            'If this fails use the normal one.
            Try
                Me._db = New BusinessLogic.Database(value.DBConnection.ConnectionString)
            Catch ex As Exception
                Me._db = value
            End Try

        End Set
    End Property

#End Region
    Public Sub New(ByVal db As BusinessLogic.Database)
        Me.db = db
    End Sub
    Public Sub New(ByVal BatchLogId As Long, ByVal db As BusinessLogic.Database)
        Me.db = db
        Me.BatchLogId = BatchLogId
    End Sub
    Public Sub New(ByVal BatchLogType As String, ByVal Description As String, ByVal db As BusinessLogic.Database, Optional ByVal BatchJobId As Integer = 0, Optional ByVal SubmittedByUserSessionId As Guid = Nothing)
        Me.db = db
        Try
            Dim lBatchLogId As Integer
            Dim cmd As New SqlCommand("sp028InsertBatchLog", Me.db.DBConnection, Me.db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchLogType", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, BatchLogType))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Description", System.Data.SqlDbType.VarChar, 500, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Description))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchJobId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, BatchJobId))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchLogId", System.Data.SqlDbType.Int, 0, ParameterDirection.Output, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, lBatchLogId))
            If Not SubmittedByUserSessionId = Nothing Then
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubmittedByUserSessionId", System.Data.SqlDbType.UniqueIdentifier, 0, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, SubmittedByUserSessionId))
            End If
            cmd.ExecuteNonQuery()
            Me.BatchLogId = cmd.Parameters("@BatchLogId").Value
            cmd = Nothing
        Catch ex As Exception
            Throw New Exception("Failed to Create BatchLog", ex)
        End Try
    End Sub
    Public Overloads Sub Update(ByVal LogMessage As String, ByVal BatchLogStatus As String)
        Try
            Me.BatchLogStatus = BatchLogStatus
            Dim cmd As New SqlCommand("sp029UpdateBatchLog", Me.db.DBConnection, Me.db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchLogId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.BatchLogId))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LogMessage", System.Data.SqlDbType.VarChar, 7000, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, LogMessage))
            If Me.BatchLogStatus <> "" Then
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@BatchLogStatus", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.BatchLogStatus))
            End If
            cmd.ExecuteNonQuery()
            cmd = Nothing

        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Public Overloads Sub Update(ByVal LogMessage As String)
        Me.Update(LogMessage, "")
    End Sub

    Public Function GetBatchLogLinesHTML(ByVal BatchJobId As String) As String
        Dim SQL As String = ""
        Dim html As String = ""
        Dim BatchLogId As Integer = 0
        BatchLogId = db.IsDBNull(db.DLookup("MAX(BatchLogId)", "BatchLog", "BatchJobId=" & BatchJobId), 0)

        html = "<table border='0' width='400'>"
        html += "<tr>"
        html += "   <td><H3>Batchlog Lines</H3></td>"
        html += "</tr>"
        html += "<tr>"
        html += "   <td class='fldView'>BatchLog Refresh Time: " & System.DateTime.Now().ToLongTimeString & "</td>"
        html += "</tr>"
        If BatchLogId = 0 Then
            html += "<tr>"
            html += "   <td class=fldView>There are no lines as Batchjob hasn't started yet.</td>"
            html += "</tr>"
            html += "</table>"
        Else
            html += "</table>"

            SQL = "Select BatchLogLine.DateTime" _
                    & "     ,LastLineLogTime = IsNull(PrevBatchLogLine.DateTime,BatchLogLine.DateTime)" _
                    & "     ,BatchLogLine.BatchLogLineText" _
                    & " FROM BatchLogLine" _
                    & "	    LEFT JOIN BatchLogLine PrevBatchLogLine" _
                    & "	    ON PrevBatchLogLine.BatchLogId = BatchLogLine.BatchLogId" _
                    & "	    AND PrevBatchLogLine.BatchLogLineId = (Select Max(BatchLogLineId)" _
                    & "								                FROM BatchLogLine bll" _
                    & "                                             WHERE bll.BatchLogId = BatchLogLine.BAtchLogId" _
                    & "								                AND bll.BatchLogLineId < BatchLogLine.BatchLogLineId)" _
                    & " WHERE 1 = 1" _
                    & " AND BatchLogLine.BatchLogId=" & BatchLogId _
                    & " ORDER BY BatchLogLine.DateTime,BatchLogLine.BatchLogLineId"
            Try
                Dim tblBatchLogLines As DataTable = db.GetDataTableFromSQL(SQL)

                If tblBatchLogLines.Rows.Count > 0 Then
                    html += "<table border='0' class='selectTable' width='400' cellpadding='4'>"
                    html += "<tr>"
                    html += "<td width='80' class='fldTitle'>Time</td>"
                    html += "<td width='40' class='fldTitle'>Seconds</td>"
                    html += "<td width='280' class='fldTitle'>Text</td>"
                    html += "</tr>"
                    Dim processTime As System.TimeSpan
                    Dim logTime As DateTime
                    Dim milliSeconds As Integer = 0

                    For Each row As DataRow In tblBatchLogLines.Rows
                        logTime = row("DateTime")
                        milliSeconds = logTime.Millisecond
                        logTime = logTime.ToString("HH:mm:ss")
                        processTime = CDate(row("DateTime")).Subtract(CDate(row("LastLineLogTime")))
                        html += "<tr>"
                        html += "   <td  valign='top' class=fldView>" & logTime & ":" & milliSeconds & "</td>"
                        html += "   <td  valign='top' align='right' class=fldView>" & processTime.TotalSeconds.ToString("#0.00") & "</td>"
                        html += "   <td  valign='top' class=fldView>" & row("BatchLogLineText").Replace(vbCr, "<br/>") & "</td>"
                        html += "</tr>"
                    Next
                    html += "</table>"
                End If

            Catch ex As Exception
                Throw New Exception("An Unexpected error has occured.  Get batch log summary failed:" & ex.Message)
            End Try
        End If

        Return html

    End Function
    Public Function GetBatchLogLinesAsText() As String
        Dim sOut As String = ""
        Try
            Dim tbl As DataTable = db.GetDataTableFromSQL("Select * From BatchLogLine WHERE BatchLogId = " & Me.BatchLogId & " Order By 1")
            For Each row As DataRow In tbl.Rows
                If sOut <> "" Then
                    sOut += Environment.NewLine
                End If
                sOut += CDate(row("DateTime")).ToString("HH.mm.ss") & " - " & row("BatchLogLineText")
            Next
        Catch ex As Exception
            Throw New Exception("GetBatchLogLinesAsText failed:" & ex.Message)
        End Try
        Return sOut
    End Function
End Class
