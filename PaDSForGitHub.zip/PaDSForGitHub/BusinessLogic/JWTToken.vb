﻿Imports System.Security.Cryptography
Imports System.Text
Imports Org.BouncyCastle.Crypto
Imports Org.BouncyCastle.Crypto.Parameters
Imports Org.BouncyCastle.Security


Imports System
Imports System.Collections.Generic
Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Imports Org.BouncyCastle.Asn1
Imports Org.BouncyCastle.Asn1.Pkcs
Imports System.IO
Imports System.Security.Cryptography.X509Certificates
Imports Jose

Public Class JWTToken
    Public JWTToken As System.IdentityModel.Tokens.Jwt.JwtSecurityToken = Nothing
    Public Payload As System.IdentityModel.Tokens.Jwt.JwtPayload = Nothing
    Dim TokenString As String = Nothing
    Sub New()

    End Sub
    Sub New(Token As String)
        TokenString = Token
        JWTToken = New System.IdentityModel.Tokens.Jwt.JwtSecurityToken(Token)
    End Sub

    Public Function DecodeAndValidateToken(key As String, Optional AllowExpiredToken As Boolean = False) As Boolean
        'remove prefix, sufix and linefeed
        key = Replace(key, "-----BEGIN PUBLIC KEY-----", "").Replace("-----END PUBLIC KEY-----", "").Replace(Environment.NewLine, "")
        Dim validated As Boolean = False
        Payload = JWTToken.Payload
        Dim parts As String() = TokenString.Split("."c)
        Dim exp As Integer = Nothing
        For Each claim As System.Security.Claims.Claim In Me.Payload.Claims
            If claim.Type = "exp" Then
                If Not IsNumeric(claim.Value) Then
                    Throw New Exception("The exp claim should be numeric.")
                End If
                exp = claim.Value
            End If
        Next
        If exp = Nothing Then
            Throw New Exception("No exp claim.")
        End If
        If DateTime.UtcNow > CDate("01-jan-1970").AddSeconds(exp) Then
            If Not AllowExpiredToken Then
                Throw New ApplicationException("Token expired:" & CDate("01-jan-1970").AddSeconds(exp).ToString("dd-MMM-yyyy HH:mm:ss.ff") & "  UTC Time:" & Now.ToString("dd-MMM-yyyy HH:mm:ss.ff"))
            End If
        End If

        Try
            Dim keyBytes = Convert.FromBase64String(key)
            ' your key here
            Dim asymmetricKeyParameter As AsymmetricKeyParameter = PublicKeyFactory.CreateKey(keyBytes)
            Dim rsaKeyParameters As RsaKeyParameters = DirectCast(asymmetricKeyParameter, RsaKeyParameters)
            Dim rsaParameters As New RSAParameters()
            rsaParameters.Modulus = rsaKeyParameters.Modulus.ToByteArrayUnsigned()
            rsaParameters.Exponent = rsaKeyParameters.Exponent.ToByteArrayUnsigned()
            Dim rsa As New RSACryptoServiceProvider()
            rsa.ImportParameters(rsaParameters)

            Dim sha256__1 As SHA256 = SHA256.Create()
            Dim hash As Byte() = sha256__1.ComputeHash(Encoding.UTF8.GetBytes(parts(0) + "."c + parts(1)))

            Dim rsaDeformatter As New RSAPKCS1SignatureDeformatter(rsa)
            rsaDeformatter.SetHashAlgorithm("SHA256")
            If Not rsaDeformatter.VerifySignature(hash, FromBase64Url(parts(2))) Then
                Throw New ApplicationException("Invalid signature")
                Return False
            End If
        Catch ex As Exception
            Throw New Exception("Check Signature failed", ex)
            Return False
        End Try

        Return True

    End Function

    Private Shared Function FromBase64Url(base64Url As String) As Byte()
        Dim padded As String = If(base64Url.Length Mod 4 = 0, base64Url, base64Url & "====".Substring(base64Url.Length Mod 4))
        Dim base64 As String = padded.Replace("_", "/").Replace("-", "+")
        Return Convert.FromBase64String(base64)
    End Function

    ' from JWT spec
    Private Shared Function Base64UrlDecode(input As String) As Byte()
        Dim output = input
        output = output.Replace("-"c, "+"c)
        ' 62nd char of encoding
        output = output.Replace("_"c, "/"c)
        ' 63rd char of encoding
        Select Case output.Length Mod 4
        ' Pad with trailing '='s
            Case 0
                Exit Select
        ' No pad chars in this case
            Case 1
                output += "==="
                Exit Select
        ' Three pad chars
            Case 2
                output += "=="
                Exit Select
        ' Two pad chars
            Case 3
                output += "="
                Exit Select
            Case Else
                ' One pad char
                Throw New System.Exception("Illegal base64url string!")
        End Select
        Dim converted = Convert.FromBase64String(output)
        ' Standard base64 decoder
        Return converted
    End Function





    Public Function Sign(ByVal payload As String, ByVal privateKey As String) As String
        'remove prefix, sufix and linefeed
        privateKey = Replace(privateKey, "-----BEGIN PRIVATE KEY-----", "").Replace("-----END PRIVATE KEY-----", "").Replace(Environment.NewLine, "")

        Dim segments As New List(Of Object)
        Dim header = New With {Key .alg = "RS256", Key .typ = "JWT"}
        Dim issued As DateTime = DateTime.Now
        Dim expire As DateTime = DateTime.Now.AddHours(10)
        Dim headerBytes As Byte() = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(header, Formatting.None))
        Dim payloadBytes As Byte() = Encoding.UTF8.GetBytes(payload)
        segments.Add(Base64UrlEncode(headerBytes))
        segments.Add(Base64UrlEncode(payloadBytes))
        Dim stringToSign As String = String.Join(".", segments.ToArray())
        Dim bytesToSign As Byte() = Encoding.UTF8.GetBytes(stringToSign)
        Dim keyBytes As Byte() = Convert.FromBase64String(privateKey)
        Dim privKeyObj = Asn1Object.FromByteArray(keyBytes)
        Dim privStruct = RsaPrivateKeyStructure.GetInstance(CType(privKeyObj, Asn1Sequence))
        Dim sig As ISigner = SignerUtilities.GetSigner("SHA256withRSA")
        sig.Init(True, New RsaKeyParameters(True, privStruct.Modulus, privStruct.PrivateExponent))
        sig.BlockUpdate(bytesToSign, 0, bytesToSign.Length)
        Dim signature As Byte() = sig.GenerateSignature()
        segments.Add(Base64UrlEncode(signature))
        Return String.Join(".", segments.ToArray())


    End Function

    Public Function JoseSign(ByVal payload As String, ByVal privateKey As String) As String
        Dim jwt As String = ""
        Dim keyBytes As Byte() = Convert.FromBase64String(privateKey)
        'Prity sure X509 can be invoked with text key in Bytes as it appears to be done in this example: https://social.msdn.microsoft.com/Forums/en-US/d7e2ccea-4bea-4f22-890b-7e48c267657f/creating-a-x509-certificate-from-a-rsa-private-key-in-pem-file?forum=csharpgeneral
        '   Dim pk As New X509Certificate2(keyBytes)
        jwt = Jose.JWT.Encode(payload, privateKey, JwsAlgorithm.RS256)
        Return jwt
    End Function
    Private Shared Function Base64UrlEncode(ByVal input As Byte()) As String
        Dim output = Convert.ToBase64String(input)
        output = output.Split("="c)(0)
        output = output.Replace("+"c, "-"c)
        output = output.Replace("/"c, "_"c)
        Return output
    End Function

    Private Shared Function xxBase64UrlDecode(ByVal input As String) As Byte()
        Dim output = input
        output = output.Replace("-"c, "+"c)
        output = output.Replace("_"c, "/"c)

        Select Case output.Length Mod 4
            Case 0
            Case 1
                output += "==="
            Case 2
                output += "=="
            Case 3
                output += "="
            Case Else
                Throw New System.Exception("Illegal base64url string!")
        End Select

        Dim converted = Convert.FromBase64String(output)
        Return converted
    End Function

    Public Class Account
        Public Property exp As Integer
        Public Property Email As String
        Public Property Active As Boolean
        Public Property CreatedDate As DateTime
        Public Property Roles As IList(Of String)
    End Class
    Public Function test(publickey As String, privateKey As String) As String
        Dim sout As String = ""
        Try
            Dim IRISkey As String = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAocURgTCJo2n8gf8XpvdsBRe4qMZmqDmwBGpu2+xDcz38QL9UznCN/+tDQoXueHQVJQk43iPPQ1p7fhEGICqSIot0FT6BT0I9kKrTROuCxW3l0kJXLKAzWAeogf3ewibQeZq6eYedm15P4R4nK5kXWxOVmAbct51tcRDJQEe1Mq6r2ItCI1+D2wudwVIDlKsIUH6kfVCIhey+8bWLUVCrdCORlewRQ2Ay56hD8GOI/EpQIFcQulrSkML/0Cq09XO2GbIY8n+oxFqI84v5034tUlEq2Fst59Gy4vmZOrEIocfXennZypQsgvrJ49X98/+mHTYnd9zyXuJ3+SduJ6AX+QIDAQAB"
            Me.DecodeAndValidateToken(IRISkey, True)
            sout += "Info from test IRIS JWT" & Environment.NewLine
            For Each claim As System.Security.Claims.Claim In Me.Payload.Claims
                sout += claim.ToString & Environment.NewLine
            Next
            'Dim j As New Newtonsoft.Json.Linq.JArray()
            'Dim array As JArray = New JArray()
            'Dim text As JValue = New JValue("Manual text")
            'Dim xx As JValue = New JValue(New DateTime(2000, 5, 23))
            'array.Add(text)
            'array.Add(xx)
            '   Dim json As String = array.ToString()
            Dim account As Account = New Account With {
                .exp = DateDiff(DateInterval.Second, CDate("01-jan-1970"), Now().AddDays(1)),
        .Email = "james@example.com",
        .Active = True,
        .CreatedDate = New DateTime(2013, 1, 20, 0, 0, 0, DateTimeKind.Utc),
        .Roles = New List(Of String) From {
            "User",
            "Admin"
        }
    }
            Dim json2 As String = JsonConvert.SerializeObject(account, Formatting.Indented)
            ' sout += json & Environment.NewLine
            Dim p As String = "Part01-- Use Sign to create JWT" & Environment.NewLine
            Dim newjwt1 As String = ""

            Try
                '9/8/20 - This one works fine, remove prefix, sufix and linefeed function.  First value must be exp expiry date as an integer.
                newjwt1 = Sign(json2, privateKey)
                ' sout += Environment.NewLine & newjwt1 & Environment.NewLine

                sout += p & Environment.NewLine
            Catch ex As Exception
                sout += p & ex.Message & Environment.NewLine
                sout += p & ex.Message
            End Try
            p = "Part02-- Decode first JWT"
            Try
                Dim j2 As New JWTToken(newjwt1)
                '9/8/20 - This one works fine, remove prefix, sufix and linefeed function.  First value must be exp expiry date as an integer.
                j2.DecodeAndValidateToken(publickey)
                For Each claim As System.Security.Claims.Claim In j2.Payload.Claims
                    sout += claim.ToString & Environment.NewLine
                Next
                sout += p & Environment.NewLine
            Catch ex As Exception
                sout += p & ex.Message & Environment.NewLine
            End Try
            p = "Part03--Try JoseSign to create JWT fails"
            Dim newjwt2 As String = ""
            Try
                '9/8/20 - I thought this worked previously but failed in Aug 2020

                newjwt2 = JoseSign(json2, privateKey)
                sout += p & Environment.NewLine
            Catch ex As Exception

                sout += p & ex.Message & Environment.NewLine
            End Try
            p = "Part04--"
            Try
                Dim j2 As New JWTToken(newjwt2)
                j2.DecodeAndValidateToken(publickey)
                For Each claim As System.Security.Claims.Claim In j2.Payload.Claims
                    sout += claim.ToString & Environment.NewLine
                Next
                sout += p & Environment.NewLine

            Catch ex As Exception
                sout += p & ex.Message & Environment.NewLine
            End Try

        Catch ex As Exception
            Throw ex
        Finally
        End Try

        Return sout

    End Function
End Class
