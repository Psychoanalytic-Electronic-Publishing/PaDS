﻿Imports Microsoft.Owin
Imports Owin

<Assembly: OwinStartup(GetType(PEPFederatedInterface.Startup))>
Namespace PEPFederatedInterface
    Partial Public Class Startup
        Public Sub Configuration(ByVal app As IAppBuilder)
            ConfigureAuth(app)
        End Sub
    End Class
End Namespace