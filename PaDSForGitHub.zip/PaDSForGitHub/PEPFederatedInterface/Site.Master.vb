﻿Imports Microsoft.Owin.Security.Cookies
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports BusinessLogic

Public Class SiteMaster
    Inherits MasterPage
    Dim _Db As BusinessLogic.Database = Nothing
    Public ReadOnly Property Db As BusinessLogic.Database
        Get
            If _Db Is Nothing Then
                _Db = New PaDSDB().db
            End If
            Return _Db
        End Get
    End Property
    Dim _UserSession As UserSession = Nothing
    Public ReadOnly Property UserSession() As UserSession
        Get
            If _UserSession Is Nothing Then
                '_UserSession = New UserSession(Me.Db)
                '_UserSession.Restore("")
            End If
            Return Me._UserSession
        End Get

    End Property
    Public IPAddress As String = Nothing

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load


    End Sub
    Public Sub Initialise(ResetSessionCookie As Boolean)
        IPAddress = New StdCode().GetIPAddress(HttpContext.Current.Request)
        _UserSession = New UserSession(Db)
        Dim RedirectURL As String = Nothing

        Try
            Me.UserSession.RestoreFromCookie(Me.Request, RedirectURL, ResetSessionCookie)
        Catch ex As Exception

            If ex.Message.Contains(" has timed out") Then
                'Me.WriteSessionLog("Session Timed Out")
            End If
        End Try
    End Sub
    Protected Sub login_Click(ByVal sender As Object, ByVal e As EventArgs)
        If Not Request.IsAuthenticated Then
            HttpContext.Current.GetOwinContext().Authentication.Challenge()
        End If
    End Sub

    Public Sub Unnamed_LoggingOut(ByVal sender As Object, ByVal e As EventArgs)
        If Request.IsAuthenticated Then
            UserSession.Logout()
            Context.GetOwinContext().Authentication.SignOut(CookieAuthenticationDefaults.AuthenticationType)
        End If
    End Sub

    Private Sub SiteMaster_Unload(sender As Object, e As EventArgs) Handles Me.Unload

    End Sub

    Private Sub SiteMaster_PreRender(sender As Object, e As EventArgs) Handles Me.PreRender
        Me.UserSession.SessionCookie.Save(Me.Response)

    End Sub
    Public Sub HandlePageError(ex As Exception)
        Dim showFullError As Boolean = False
        Try
            showFullError = Db.ShowFullError Or Db.DBConnection.DataSource.ToLower.Contains("zedra")
        Catch ex1 As Exception
        End Try
        Me.PageErrorDisplay.Text = "Unexpected Error" & IIf(showFullError, ex.ToString, "")
        Me.Server.ClearError()
    End Sub
    Sub SiteMaster_Error(sender As Object, e As EventArgs) Handles Me.[Error]
        Me.HandlePageError(Me.Server.GetLastError())
    End Sub
End Class