﻿Imports BusinessLogic
Public Class PaDSDB
    Public Sub New()
        Dim x As String = db.ShowFullError
    End Sub
    Public ReadOnly Property IsWebServerPrimaryOrSecondary As String
        Get
            Return System.Configuration.ConfigurationManager.AppSettings("IsPrimaryOrSeconday")
        End Get
    End Property
    Public IsDatabaseServerPrimaryOrSecondary As String = "Unknown"
    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get

            If Me._db Is Nothing Then
                Dim FailOver As New BusinessLogic.Failover()
                Me._db = New BusinessLogic.Database(FailOver.ChooseConnectionString(
                                                System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringPrimary").ToString _
                                                , System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringSecondary").ToString _
                                                , System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringSecurityOnSecondary").ToString _
                                                , "ASP.NET - PEP Secure - " _
                                                , Me.IsWebServerPrimaryOrSecondary))
                Me._db.SecondaryConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("ConnectionStringSecondary").ToString
                Me._db.IsDatabaseServerPrimaryOrSecondary = FailOver.IsDatabaseServerPrimaryOrSecondary
                Me._db.IsWebServerPrimaryOrSecondary = Me.IsWebServerPrimaryOrSecondary
            End If
            Return (Me._db)
        End Get


        Set(ByVal value As BusinessLogic.Database)
            Me._db = value
        End Set
    End Property
End Class
