﻿Public Class Federated
    Inherits Page
    Dim _db As BusinessLogic.Database = Nothing
    Public ReadOnly Property db As BusinessLogic.Database
        Get
            If _db Is Nothing Then
                _db = New PaDSDB().db
            End If
            Return _db
        End Get
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load

        If Not Request.IsAuthenticated AndAlso Request.QueryString("iss") <> "" Then
            HttpContext.Current.GetOwinContext().Authentication.Challenge()
        End If
        If Request.QueryString("iss") <> "" Then
            Me.ReturnedISS.Text = Request.QueryString("iss")
        Else
            Me.ReturnedISS.Text = " Nothing in iss"
        End If
        If Request.QueryString("iss") <> "" And Request.IsAuthenticated Then
            'Just gettting back from logging on in OpenAthens, check
        End If

        Dim t As DataTable = db.GetDataTableFromSQL("
                SELECT 
	                al.RemoteUserAutoLogonId 
	                ,al.FederatedEntity 
	                ,ru.UserFullName 
                FROM RemoteUserAutoLogon al
	                INNER JOIN RemoteUser ru
	                ON ru.UserId = al.UserId 
                WHERE ru.UserStatus = 'Active'
                AND al.AutoLogonStatus = 'Active'
                AND al.AutoLogonType = 'Federated'
                ORDER BY
	                ru.UserFullName 
                ")
        For Each r As DataRow In t.Rows
            Dim tr As New TableRow
            Dim tc As New TableCell
            Dim lk As New HyperLink
            lk.NavigateUrl = db.GetParameterValue("OidcLogonURL") & "?entity=" & r("FederatedEntity")
            lk.Text = r("UserFullName")
            tc.Controls.Add(lk)
            tr.Cells.Add(tc)
            tc = New TableCell
            tc.Text = lk.NavigateUrl
            tr.Cells.Add(tc)


            Me.tbFederations.Rows.Add(tr)
        Next
    End Sub

    Private Sub Federated_Unload(sender As Object, e As EventArgs) Handles Me.Unload
        Try
            db.DBConnection.Close()
            db.DBConnection.Dispose()
        Catch ex As Exception
        End Try
    End Sub
End Class