﻿Imports Microsoft.IdentityModel.Protocols.OpenIdConnect
Imports Microsoft.Owin.Security
Imports Microsoft.Owin.Security.Cookies
Imports OpenAthens.Owin.Security.OpenIdConnect
Imports Owin
Imports System.Configuration

Namespace PEPFederatedInterface
    Partial Public Class Startup

        Public Sub ConfigureAuth(ByVal app As IAppBuilder)
            app.SetDefaultSignInAsAuthenticationType(CookieAuthenticationDefaults.AuthenticationType)
            app.UseCookieAuthentication(New CookieAuthenticationOptions())
            Dim PaDSDB As BusinessLogic.Database = New PaDSDB().db

            Try
                Dim oidcOptions = New OpenIdConnectAuthenticationOptions With {
                    .Authority = PaDSDB.GetParameterValue("OidcAuthority", "https://connect.openathens.net"),
                    .ClientId = PaDSDB.GetParameterValue("OidcClientId", "xxxxxx"),
                    .ClientSecret = PaDSDB.GetParameterValue("OidcClientSecret", "xxxxxx"),
                    .GetClaimsFromUserInfoEndpoint = True,
                    .PostLogoutRedirectUri = PaDSDB.GetParameterValue("OidcRedirectUrl", "https://localhost:44332/"),
                    .RedirectUri = PaDSDB.GetParameterValue("OidcRedirectUrl", "https://localhost:44332/"),
                    .ResponseType = OpenIdConnectResponseType.Code,
                    .Scope = OpenIdConnectScope.OpenId
                }
                app.UseOpenIdConnectAuthentication(oidcOptions)
            Catch ex As Exception
                Throw ex
            Finally

                Try
                    PaDSDB.DBConnection.Close()
                    PaDSDB.DBConnection.Dispose()
                Catch ex1 As Exception
                End Try
            End Try
        End Sub

    End Class
End Namespace
