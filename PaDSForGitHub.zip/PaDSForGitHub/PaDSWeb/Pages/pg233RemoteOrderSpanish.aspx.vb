﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'19/03/15  Julian Gates   Initial version
'31/07/15   Julian Gates    SIR3897 - Change Order form text to be imported from htm document
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields and associated code
'13/11/19   James Woosnam   SIR4949 - use passed in companyId

Partial Class Pages_pg233RemoteOrderSpanish
    Inherits System.Web.UI.Page
    Dim pageMode As String = ""
    Dim StdCode As New BusinessLogic.StdCode()
    Dim _tblProducts As DataTable = Nothing
    Private ReadOnly Property tblProducts As DataTable
        Get
            If Me._tblProducts Is Nothing Then
                Dim cmd As New SqlCommand("sp235WebProducts", Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
                cmd.CommandType = CommandType.StoredProcedure


                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CompanyId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , Me.Master.UserSession.Data("CompanyId")))
                '13/11/19   James Woosnam   SIR4949 - use passed in companyId
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , ViewState("CompanyId")))

                Me._tblProducts = Me.Master.db.GetDataTableFromSQL(cmd)
            End If
            Return Me._tblProducts
        End Get
    End Property
    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                Me._Subscriber = New BusinessLogic.Subscriber(Me.Master.UserSession.Data("SubscriberId"), Me.Master.db, Me.Master.UserSession)
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property

    Private _SalesOrder As BusinessLogic.SalesOrder = Nothing
    Public Property SalesOrder() As BusinessLogic.SalesOrder
        Get
            If Me._SalesOrder Is Nothing Then
                Me._SalesOrder = New BusinessLogic.SalesOrder(Me.Master.db, Me.Master.UserSession)
            End If
            Return Me._SalesOrder
        End Get
        Set(ByVal value As BusinessLogic.SalesOrder)
            Me._SalesOrder = value
        End Set
    End Property
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Master.Initilise("FORMULARIO REMOTO DE PEDIDO DE PRODUCTO", "05", "")

        If Request.QueryString("PageMode") <> "" Then
            pageMode = Request.QueryString("PageMode")
        Else
            Me.Master.WebForm.AddPageError("Esta página ha pasado al modo página no válida")
        End If

        Dim lOrderNumber As Integer = 0
        If IsNumeric(Request.QueryString("OrderNumber")) Then
            lOrderNumber = Request.QueryString("OrderNumber")
        Else
            lOrderNumber = Me.Master.WebForm.db.IsDBNull(Master.WebForm.db.DLookup("Max(OrderNumber)", "SalesOrder", "SubscriberId=" & Me.Master.UserSession.Data("SubscriberId") & "AND SalesOrderstatus = 'RemotePartial'"), 0)
            '15/02/12 Julian Gates  Hotfix - Add code below to stop user creating duplicate cashbook entries
            If Me.Master.WebForm.db.DLookup("CashbookId", "Cashbook", "OrderNumber=" & lOrderNumber & "AND CashbookStatus <> 'Partial'") <> Nothing Then
                lOrderNumber = Nothing
            End If
        End If

        If lOrderNumber = Nothing Then
            Me.SalesOrder = New BusinessLogic.SalesOrder(Master.db, Master.UserSession)
        Else
            Me.SalesOrder = New BusinessLogic.SalesOrder(lOrderNumber, Master.db, Master.UserSession)
        End If

        If Request.QueryString("ProductCode") <> "" Then
            Me.txtProductCode.Value = Request.QueryString("ProductCode")
        End If

        If Page.IsPostBack Then
            Me._tblProducts = CType(ViewState("tblProducts"), DataTable)
            Me.SalesOrder.MainDataset = CType(ViewState("MainDataSet"), DataSet)
        Else
            '13/11/19   James Woosnam   SIR4949 - use passed in companyId
            If Request.QueryString("CompanyId") <> "" Then
                ViewState("CompanyId") = Request.QueryString("CompanyId")
            ElseIf lOrderNumber <> Nothing Then
                '13/11/19   James Woosnam   SIR4949 - use  companyId from order
                ViewState("CompanyId") = Me.SalesOrder.SalesOrderRow("CompanyId")
            Else
                Me.Master.WebForm.AddPageError("This page must be passed a CompanyId")
                Exit Sub
            End If
            If Me.Master.WebForm.IsValid Then
                ReadRecord()
            End If
            Me.FirstName.Focus()
        End If
        Session("UsedOrderPageType") = "Spanish"
    End Sub

    Sub PageSetup()
        '22/6/11   Julian Gates   SIR2459 - Add new IsSubscriberValidForOrdering error message functionality
        If Me.Subscriber.IsSubscriberValidForOrdering(True) <> "" Then
            Me.IsSubscriberValidForOrderingError.Text = "<b>ADVERTENCIA: Faltan datos del suscriptor</b> <br>" & Me.Subscriber.IsSubscriberValidForOrdering()
            Me.TableRowIsSubscriberValidForOrdering.Visible = True
            Me.NextBtn.Enabled = False
        Else
            Me.TableRowIsSubscriberValidForOrdering.Visible = False
            Me.NextBtn.Enabled = True
        End If

        If pageMode = "RenewOrder" Then
            Me.UpdateDetailsBtn.Visible = False
        Else
            Me.UpdateDetailsBtn.Visible = True
        End If

        RemoteProductOrderFormTextDisplay()
        GetWebProductList()

    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else
                If Me.TermsAgreed.Checked = False Then
                    Me.Master.WebForm.AddPageError("Por favor coloque un tilde en Términos y Condiciones  del recuadro Venta.")
                End If

                If pageMode = "NewOrder" Then
                    If GetSelectedProductsTable.Rows.Count = 0 Then
                        Me.Master.WebForm.AddPageError("Seleccione un product o de la lista de productos.")
                    End If
                End If
        End Select

        Return Me.Master.WebForm.IsValid
    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        If Me.SalesOrder.OrderNumber <> Nothing Then
            Me.OrderNumber.Text = SalesOrder.OrderNumber
        End If
        Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.Subscriber.SubscriberRow)
        Me.EmailMain.Text = Me.Subscriber.GetAddressText("Email")
        Me.BillingAddress.Text = Me.Subscriber.BillingAddressRow("AddressText")
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.SalesOrder.MainDataset
        ViewState("tblProducts") = Me.tblProducts
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    Sub SaveRecord()
        '    '******************************************************
        '    'Description:	Save the record either by updating
        '    '******************************************************
        '9/11/11    James Woosnam   Hot Fix - ReInitialise SalesOrder to try and avaid conccuency and tramsation problems
        If Me.SalesOrder.OrderNumber = Nothing Then
            Me.SalesOrder = New BusinessLogic.SalesOrder(Master.db, Master.UserSession)
        Else
            Me.SalesOrder = New BusinessLogic.SalesOrder(Me.SalesOrder.OrderNumber, Master.db, Master.UserSession)
        End If
        Me.Master.db.BeginTran()
        Try
            If Me.SalesOrder.OrderNumber = Nothing Then
                Select Case pageMode
                    Case "NewOrder"
                        SalesOrder.Add(GetSelectedProductsTable())
                    Case "RenewOrder"
                        SalesOrder.Add(GetSelectedRenewProductsTable())
                End Select
            Else
                Select Case pageMode
                    Case "NewOrder"
                        Me.SalesOrder.AddSalesOrderLines(GetSelectedProductsTable())
                    Case "RenewOrder"
                        Me.SalesOrder.AddSalesOrderLines(GetSelectedRenewProductsTable())
                End Select

                Me.SalesOrder.Save()
            End If
            Me.OrderNumber.Text = SalesOrder.OrderNumber
            Me.Master.db.CommitTran()
        Catch ex As Exception
            Me.Master.db.RollbackTran()
            Throw ex
        End Try

    End Sub

    Protected Sub NextBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles NextBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                SaveRecord()
            Catch ex As Exception
                Me.Master.WebForm.AddPageError(New Exception("Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia", ex))
            End Try

            If Me.Master.WebForm.IsValid Then
                Select Case pageMode
                    Case "NewOrder"
                        Response.Redirect("../Pages/pg223Authorisation.aspx?" & Me.Master.UserSession.QueryString & "&OrderNumber=" & Me.OrderNumber.Text & "&PageType=" & pageMode)
                    Case "RenewOrder"
                        Response.Redirect("../Pages/pg223Authorisation.aspx?" & Me.Master.UserSession.QueryString & "&OrderNumber=" & Me.OrderNumber.Text & "&PageType=" & pageMode & "&ProductCode=" & Me.txtProductCode.Value)
                End Select
            End If
        End If
    End Sub

    Protected Sub HomeBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles HomeBtn.Click
        Response.Redirect("../pages/pg101Home.aspx?" & Me.Master.UserSession.QueryString)
    End Sub

    Sub GetWebProductList()
        Dim strSQL As String = ""
        Dim html As String = ""
        Dim lnglineNumber As Long
        Dim strPrefix As String = ""
        Dim strRateViewFormat As String = ""
        Dim blnQualifyingProductFound As Boolean = False
        Try


            If tblProducts.Rows.Count > 0 Then
                Select Case pageMode
                    Case "RenewOrder"
                        For Each row As DataRow In tblProducts.Rows
                            If row("ProductCode") = Me.txtProductCode.Value Then
                                html += "Ud. está renovando su suscripción para " & row("ProductName") & " at $" & Format(row("ProductRate"), "0.00")
                                html += "  <a href='../pages/pg234TermsAndConditions.aspx?" _
                                       & "PageMode=Update&TCFileName=" & row("TermsAndConditionsFileName") & "&ProductName=" & row("ProductName") & "&" & Me.Master.UserSession.QueryString _
                                       & "' Title='Ver Términos y Condiciones para " & row("ProductCode") & " producto' Target='_blank'>Términos y condiciones</a>"
                                GetSelectedRenewProductsTable()
                            End If
                        Next
                    Case "NewOrder"
                        html += "<table width='760' border='1' class='ListTable'>"
                        html += "	<tr>"
                        html += "		<th width='180' height='25' class='firstTh'>Código de Producto Primario</th>"
                        html += "		<th>Nombre</th>"
                        html += "		<th colspan=3 class='lastTh'>Tarifa</th>"
                        html += "	</tr>"

                        For Each row As DataRow In tblProducts.Rows
                            If row("ProductCode") = "IJP-es" Then
                                Dim blnNoRate As Boolean = False
                                lnglineNumber = lnglineNumber + 1
                                If lnglineNumber > 9 Then
                                    strPrefix = ""
                                Else
                                    strPrefix = "0"
                                End If
                                If Me.Master.db.IsDBNull(row("ProductRate")) Then
                                    strRateViewFormat = "No Rate"
                                    blnNoRate = True
                                Else
                                    strRateViewFormat = "$"
                                End If
                                html += "<tr>"

                                Dim ShowAsAutoSelectedChildProduct As Boolean = False
                                'CPpost is auto related to CPO
                                If row("PrimaryProductCode") <> row("ProductCode") _
                                  Or row("ProductCode") = "CPPost" Then
                                    ShowAsAutoSelectedChildProduct = True
                                End If
                                If ShowAsAutoSelectedChildProduct Then
                                    blnQualifyingProductFound = True

                                    html += "	<td><img src='../images/arrow2.gif'></td>"
                                    If row("PrimaryProductCode") = "Freud" Then
                                        html += "	<td>One-time " & row("ProductName") & " for PEP WEB users</td>"
                                    Else
                                        html += "	<td class='redText'>" & row("ProductName") & "</td>"
                                    End If
                                    html += "	<td class='redText'>" & strRateViewFormat & Format(row("ProductRate"), "0.00") & "</td>"
                                Else
                                    html += "	<td>" & row("ProductCode") & "</td>"
                                    html += "	<td>" & row("ProductName") & "</td>"
                                    html += "	<td>" & strRateViewFormat & Format(row("ProductRate"), "0.00") & "</td>"
                                    If blnNoRate = False Then
                                        html += "<td><input id=""cbxSelectedProduct" & row("ProductRateId") & """ name=""cbxSelectedProduct" & row("ProductRateId") & """ type=""checkbox"""
                                        For Each row1 As DataRow In GetSelectedProductsTable.Rows
                                            If row("ProductRateId") = row1("ProductRateId") Then
                                                html += " Checked "
                                            End If
                                        Next
                                        html += "</input></td>"
                                    Else
                                        html += "	<td>&nbsp;</td>"
                                    End If
                                End If
                                If Me.Master.db.IsDBNull(row("TermsAndConditionsFileName"), "") <> "" Then
                                    html += "          <td width=140>"
                                    html += "            <p class='lnkMaint'>"
                                    html += "              <a href='../pages/pg234TermsAndConditions.aspx?" _
                                            & "PageMode=Update&TCFileName=" & row("TermsAndConditionsFileName") & "&ProductName=" & row("ProductName") & "&" & Me.Master.UserSession.QueryString _
                                            & "' Title='Ver Términos y Condiciones para " & row("ProductCode") & " producto' Target='_blank'>Términos y condiciones</a>"
                                    html += "            </p>"
                                    html += "          </td>"
                                    html += "</tr>"
                                Else
                                    html += "	<td>&nbsp;</td>"
                                End If
                            End If
                        Next
                        html += "	</tr>"
                        html += "</table>"
                End Select
            Else
                html += "<table width='500' border='0' align='left'>"
                html += "	<tr>"
                html += "		<td class='fldprompt'><b>No hay productos encontrados</b></td>"
                html += "	</tr>"
                html += "</table>"
            End If

            Me.WebProductsList.Text = html

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia", ex))
        End Try
    End Sub

    Function GetSelectedProductsTable() As DataTable
        Dim SelectedProductsTable As New DataTable("SelectedProductsTable")
        Dim columnAdded As Boolean = False
        Try
            Dim lastParentLineSelected As Boolean = False
            For Each row As DataRow In tblProducts.Rows
                Dim alreadyOrdered As Boolean = False
                If Not Me.IsPostBack Then
                    'Only check whether already ordered first time in.
                    For Each saledRow As DataRow In Me.SalesOrder.SalesOrderLine.Rows
                        If saledRow("ProductCode") = row("ProductCode") Then
                            alreadyOrdered = True
                            Exit For
                        End If
                    Next
                End If
                Dim ParentProductOrdered As Boolean = False
                'Special code to select CPPost if CPO ordered
                '22/6/11   Julian Gates   SIR2459 - Use new Subscriber.BillingAddressRow to get Billing or Main address data
                If (row("ProductCode") <> row("PrimaryProductCode") _
                    Or (row("ProductCode") = "CPPost" _
                    And Me.Subscriber.BillingAddressRow("CountryId") <> 56 _
                      ) _
                   ) _
                    And lastParentLineSelected Then
                    ParentProductOrdered = True
                End If

                'For Each row2 As DataRow In tbl.Rows
                '    If row2("ProductCode") = row("PrimaryProductCode") Then
                '        If Request.Form.Item("cbxSelectedProduct" & row("ProductRateId")) = "on" Then
                '            ParentProductOrdered = True
                '        End If
                '    End If
                'Next
                If Request.Form.Item("cbxSelectedProduct" & row("ProductRateId")) = "on" _
                    Or alreadyOrdered _
                    Or ParentProductOrdered Then
                    If columnAdded = False Then
                        SelectedProductsTable.Columns.Add("ProductRateId")
                        SelectedProductsTable.Columns.Add("PrimaryProductCode")
                        SelectedProductsTable.Columns.Add("ProductCode")
                        SelectedProductsTable.Columns.Add("ProductRate")
                        SelectedProductsTable.Columns.Add("CurrencyCode")
                        SelectedProductsTable.Columns.Add("NewRecurringSubscriptionStartDate")
                        SelectedProductsTable.Columns.Add("NewRecurringSubscriptionEndDate")
                        columnAdded = True
                    End If
                    Dim row1 As DataRow = SelectedProductsTable.NewRow
                    row1.Item("ProductRateId") = row("ProductRateId")
                    row1.Item("PrimaryProductCode") = row("PrimaryProductCode")
                    row1.Item("ProductCode") = row("ProductCode")
                    row1.Item("ProductRate") = row("ProductRate")
                    row1.Item("CurrencyCode") = row("CurrencyCode")
                    row1.Item("NewRecurringSubscriptionStartDate") = row("NewRecurringSubscriptionStartDate")
                    row1.Item("NewRecurringSubscriptionEndDate") = row("NewRecurringSubscriptionEndDate")
                    SelectedProductsTable.Rows.Add(row1)
                    If row("ProductCode") = row("PrimaryProductCode") Then
                        lastParentLineSelected = True
                    End If
                Else
                    If row("ProductCode") = row("PrimaryProductCode") Then
                        lastParentLineSelected = False
                    End If
                End If
            Next
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia", ex))
        End Try

        Return SelectedProductsTable
    End Function

    Function GetSelectedRenewProductsTable() As DataTable
        Dim SelectedProductsTable As New DataTable("SelectedProductsTable")
        Dim columnAdded As Boolean = False
        Try
            For Each row As DataRow In tblProducts.Rows
                If row("ProductCode") = Me.txtProductCode.Value Then
                    If columnAdded = False Then
                        SelectedProductsTable.Columns.Add("ProductRateId")
                        SelectedProductsTable.Columns.Add("PrimaryProductCode")
                        SelectedProductsTable.Columns.Add("ProductCode")
                        SelectedProductsTable.Columns.Add("ProductRate")
                        SelectedProductsTable.Columns.Add("CurrencyCode")
                        SelectedProductsTable.Columns.Add("NewRecurringSubscriptionStartDate")
                        SelectedProductsTable.Columns.Add("NewRecurringSubscriptionEndDate")
                        columnAdded = True
                    End If
                    Dim row1 As DataRow = SelectedProductsTable.NewRow
                    row1.Item("ProductRateId") = row("ProductRateId")
                    row1.Item("PrimaryProductCode") = row("PrimaryProductCode")
                    row1.Item("ProductCode") = row("ProductCode")
                    row1.Item("ProductRate") = row("ProductRate")
                    row1.Item("CurrencyCode") = row("CurrencyCode")
                    row1.Item("NewRecurringSubscriptionStartDate") = row("NewRecurringSubscriptionStartDate")
                    row1.Item("NewRecurringSubscriptionEndDate") = row("NewRecurringSubscriptionEndDate")
                    SelectedProductsTable.Rows.Add(row1)
                End If
            Next
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia", ex))
        End Try

        Return SelectedProductsTable
    End Function

    Protected Sub UpdateDetailsBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateDetailsBtn.Click
        Response.Redirect("../pages/pg112SubscriberDetailsMaint.aspx?PageFrom=SalesOrder&PageMode=" & pageMode & "&" & Me.Master.UserSession.QueryString)
    End Sub

    Sub RemoteProductOrderFormTextDisplay()
        '*********************************************************
        'Desc:		Generates Remote product order form text
        '********************************************************
        Try
            '13/11/19   James Woosnam   SIR4949 - Use different test file for each company
            Me.RemoteOrderTermsText.Text = Me.Master.WebForm.GetImportFileText(IO.Path.Combine(Me.Master.db.GetParameterValue("TermsConditionsDirectoryPhysicalPath"), "RemoteNewOrderText" & ViewState("CompanyId") & ".htm"))
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured.  Please contact support", ex))
        End Try
    End Sub
End Class
