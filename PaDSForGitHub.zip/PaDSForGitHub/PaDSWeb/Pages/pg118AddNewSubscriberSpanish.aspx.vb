﻿Imports System.Data
Imports System.Data.SqlClient
Imports AjaxControlToolkit.ToolkitScriptManager

'Modification History
'18/03/15  Julian Gates   Initial version
'31/07/15   Julian Gates    SIR3898 - Remove mandatory validation from Non Us & Canada State field.
'16/10/15   Julian Gates    SIR3982 - Change www.p-e-p.org links to support.pep-web.org
'23/11/15   Julian Gates    SIR4016 - Add Triggers to Update panel on aspx page to get MaintainSchrollPosition working
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields and associated code
'29/10/19   Julian Gates    SIR4763 - Remove WebUserName, WebUserPassword and email confirmation fields.
'29/10/19   Julian Gates    SIR4763 - Remove VAT Number field.

Partial Class Pages_pg118AddNewSubscriberSpanish
    Inherits System.Web.UI.Page
    '******* This page is designed to work with one Company *****************
    Dim CompanyId As Integer = 2

    Dim pageMode As String = ""
    Dim StdCode As New BusinessLogic.StdCode()
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Master.Initilise("Registro de Nuevo Usuario", "00", "")

        If Page.IsPostBack Then
            pageMode = "Add"
        Else
            pageMode = "Add"

            If Me.Master.WebForm.IsValid Then
                ReadRecord()
            End If

            Me.EmailMain.Focus()
            ResetFormBtn.Attributes.Add("onclick", "if(confirm('Está seguro de que quiere restaurar el formulario y perder sus datos?')){}else{return false}")
        End If
        PageSetup()

        'Used to display animation when processing credit card and hide confirm button
        Me.progressImage.Style.Add("display", "none")
        SaveBtn.OnClientClick = "document.getElementById('" + progressImage.ClientID + "').style.display = ''; document.getElementById('" + SaveBtn.ClientID + "').style.display = 'none';"

    End Sub

    Sub PageSetup()

    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '    '****************************************************** 
        '    'Description: Validate page fields and show error message 
        '    '****************************************************** 
        Select Case validatorStatus
            Case Else

                Me.Master.WebForm.FieldValidateMandatoryESP(Me.EmailMain, "La dirección de correo electrónico  es obligatoria")
                CheckEmail()
                Me.Master.WebForm.DropDownValidateMandatoryESP(Me.TitleESP, "Estado civil es obligatorio")
                Me.Master.WebForm.FieldValidateMandatoryESP(Me.FirstName, "Nombre de pila es obligatorio")
                Me.Master.WebForm.FieldValidateMandatoryESP(Me.LastName, "Apellido es obligatorio")
                Me.Master.WebForm.FieldValidateMandatoryESP(Me.BillingAddress, "Dirección de facturación es obligatorio")
                Me.Master.WebForm.FieldValidateMandatoryESP(Me.Town, "Ciudad es obligatorio")
                '31/07/15   Julian Gates    SIR3898 - Remove mandatory validation from Non Us & Canada State field.
                If Me.Master.db.IsDBNull(Me.CountryId.SelectedValue, "") = "11" Or Me.Master.db.IsDBNull(Me.CountryId.SelectedValue, "") = "56" Then 'US or Canada
                    Me.Master.WebForm.DropDownValidateMandatoryESP(Me.CountyUS, "Estado (Estados Unidos o Canadá) es obligatorio")
                End If
                Me.Master.WebForm.FieldValidateMandatoryESP(Me.PostCode, "Código Postal es dato obligatorio  ")
                Me.Master.WebForm.DropDownValidateMandatoryESP(Me.CountryId, "País es obligatorio")
        End Select

        Return Me.Master.WebForm.IsValid
    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        'populate dropdowns
        Me.Master.WebForm.PopulateDropDownListFromLookup(Me.TitleESP, "TitleESP", "<--Select-->")
        Me.Master.WebForm.PopulateDropDownListFromLookup(Me.CountyUS, "US_CanadaStateCode", "<--Select-->")
        Me.Master.WebForm.PopulateDropDownListFromSQL(Me.CountryId, "SELECT Country.CountryId as Value" _
                                                                    & "     ,Country.CountryName As Text" _
                                                                    & " FROM Country" _
                                                                    & " ORDER BY Country.CountryName" _
                                                                    , "<--Select-->")
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        '  ViewState("MainDataSet") = Me.Subscriber.MainDataset
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    '03/10/14   Julian Gates    SIR3621 - Add IsReceiveMail to  Subscriber.Add
    '16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields
    '29/10/19   Julian Gates    SIR4763 - Remove VAT Number field.
    Protected Sub SaveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                Master.db.BeginTran()
                Try
                    Dim Subscriber As New BusinessLogic.Subscriber(Me.Master.db, Me.Master.UserSession)
                    Subscriber.Add(Me.EmailMain.Text _
                                      , Me.TitleESP.SelectedValue _
                                      , Me.FirstName.Text _
                                      , Me.LastName.Text _
                                      , Me.BillingAddress.Text _
                                      , Me.Town.Text _
                                      , Me.County.Text _
                                      , Me.CountyUS.SelectedValue _
                                      , Me.PostCode.Text _
                                      , Me.CountryId.SelectedValue _
                                      , False _
                                      , Me.CompanyId _
                                      , Me.IsReceiveMail.Checked _
                                      , True)
                    Subscriber.AddCompanyAccount(Me.CompanyId, "Individual", 4, "Full", Subscriber.SubscriberRow("DefaultPostalAddressId"))
                    Master.db.CommitTran()
                Catch ex As Exception
                    Master.db.RollbackTran()
                    Throw ex
                End Try

            Catch ex As Exception
                Me.Master.WebForm.AddPageError(ex)
            End Try

            ' Show message to say user set up and emails confirmation and password set up emails sent 
            If Me.Master.WebForm.IsValid Then
                Me.MainContentTable.Visible = False
                Me.EmailSentMessageTable.Visible = True
            Else
                Me.EmailSentMessageTable.Visible = False
                Me.MainContentTable.Visible = True
            End If
        End If
    End Sub

    Protected Sub ResetFormBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ResetFormBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?" & Me.Master.UserSession.QueryString)
    End Sub
    Protected Sub EmailMain_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles EmailMain.TextChanged
        CheckEmail()
    End Sub

    Protected Sub CheckEmail()
        If Me.EmailMain.Text <> "" Then
            If Not Me.StdCode.IsValidEmail(Me.EmailMain.Text) Then
                Me.Master.WebForm.AddPageError("Email Address is syntactically invalid")
            Else

                Dim sql As String = ""
                sql = "SELECT EmailAddress"
                sql += " FROM RemoteUser"
                sql += " WHERE EmailAddress=@EmailAddress"
                Dim cmd As New SqlCommand(sql, Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailAddress", System.Data.SqlDbType.VarChar, 255, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                         , Me.EmailMain.Text))
                If Me.Master.db.GetDataTableFromSQL(cmd).Rows.Count > 0 Then
                    Me.Master.WebForm.AddPageError("La dirección de correo electrónico introducida ya está en uso. Si usted ya tiene una cuenta por favor haga click en el botón Enviar para que enviemos el detalle de su cuenta")
                    Me.SaveBtn.Visible = False
                    Me.ResendLogonDetailsRow.Visible = True
                    Me.ResendLogonDetailsRow.Focus()
                Else
                    Me.SaveBtn.Visible = True
                    Me.ResendLogonDetailsRow.Visible = False
                End If
            End If
        End If
    End Sub


    Protected Sub ResendLogonDetails_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ResendLogonDetails.Click
        Try
            Dim ru As New BusinessLogic.RemoteUser(Me.EmailMain.Text, Master.db, Master.UserSession)
            ru.ResetPasswordAndEmail()
            Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=Sus datos de apertura de sesión han sido enviados. Por favor revise su correo electrónico.")
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(ex)
        End Try
    End Sub
End Class
