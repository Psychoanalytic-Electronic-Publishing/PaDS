﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.Subscriber
Imports BusinessLogic.ContentSet
'Modification History
'09/04/20  Julian Gates   Initial New version
'18/08/20   Julian Gates    SIR5099 - Pass UserSession to ContentSet class
'21/08/20   Julian Gates    SIR5099 - Add Audit link

Partial Class Pages_pg271ContentSetMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Enum PageModes
        Add
        Update
    End Enum

    Property pageMode As PageModes
        Set(value As PageModes)
            ViewState("PageMode") = value

        End Set
        Get
            If ViewState("PageMode") Is Nothing Then ViewState("PageMode") = "Add"
            Return ViewState("PageMode")
        End Get
    End Property
    Private _ContentSet As BusinessLogic.ContentSet = Nothing
    Public Property ContentSet() As BusinessLogic.ContentSet
        Get
            If Me._ContentSet Is Nothing Then
                Me._ContentSet = New BusinessLogic.ContentSet(Me.uPage.db, uPage.UserSession)
            End If
            Return Me._ContentSet
        End Get
        Set(ByVal value As BusinessLogic.ContentSet)
            Me._ContentSet = value
        End Set
    End Property
    ReadOnly Property ContentSetSourceRow As DataRow
        Get
            If Me.SelectedSourceType = Nothing Then Return Nothing
            Return Me.ContentSet.ContentSetSourceRow(Me.SelectedSourceType)
        End Get
    End Property
    Dim SelectedSourceType As ContentSetSourceTypes = Nothing
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Subscriber Maintenance ", "")
        Try
            If Page.IsPostBack Then
                Me.ContentSet.MainDataset = CType(ViewState("MainDataSet"), DataSet)
                If ViewState("SelectedSourceType") IsNot Nothing Then Me.SelectedSourceType = ViewState("SelectedSourceType")
            Else
                If Request.QueryString("ContentSetId") <> "" Then
                    Me.pageMode = PageModes.Update
                    Try
                        Me.txtContentSetId.Value = Request.QueryString("ContentSetId")
                        Me.ContentSet = New BusinessLogic.ContentSet(CInt(Request.QueryString("ContentSetId")), Me.uPage.db, Me.uPage.UserSession)
                    Catch ex As Exception
                        Me.uPage.PageError = "Invalid Parameter has been passed in"
                    End Try
                    If Request.QueryString("SelectedSourceType") <> "" Then
                        ViewState("SelectedSourceType") = Request.QueryString("SelectedSourceType")
                        Me.SelectedSourceType = ViewState("SelectedSourceType")
                    End If
                Else
                    Me.pageMode = PageModes.Add
                End If

                If Me.uPage.IsValid And Me.pageMode = PageModes.Update Then
                    ReadRecord()
                End If
                Me.ContentSetName.Focus()
                If Request.QueryString("InfoMsg") <> "" Then
                    InfoMsg.Text = Request.QueryString("InfoMsg")
                End If
            End If
        Catch ex As Exception
            uPage.PageError = "An unexpected error has occured.  Please contact support." & ex.ToString
        End Try


        If Me.pageMode = PageModes.Update Then
            BuildContentSetSourceTableHTML()
        End If
    End Sub

    Sub PageSetup()
        Me.AddModeFields.Visible = Me.pageMode = PageModes.Add
        Me.UpdateModeFields.Visible = Me.pageMode = PageModes.Update
        Select Case Me.pageMode
            Case PageModes.Add
                uPage.pageTitle = "Add New Content Set"
            Case PageModes.Update
                uPage.pageTitle = "Content Set Maint: " & ContentSet.ContentSetId & " - " & ContentSet.ContentSetName
                Select Case Me.ContentSetStatus.Text
                    Case "Active"
                        Me.ActivateBtn.Visible = False
                        Me.InactiveBtn.Visible = True
                    Case "Inactive"
                        Me.ActivateBtn.Visible = True
                        Me.InactiveBtn.Visible = False
                    Case "Initial"
                        Me.ActivateBtn.Visible = True
                        Me.InactiveBtn.Visible = False
                End Select

                '21/08/20   Julian Gates    SIR5099 - Add Audit link
                Me.AuditLink.NavigateUrl = "../pages/pg040AuditLogDisplay.aspx?FltrUpdatedRecordFamily=ContentSet&FltrUpdatedRecordFamilyKey=" & ContentSet.ContentSetId & "&" & uPage.UserSession.QueryString
                Me.AuditLink.Text = "View Audit"
                Me.AuditLink.ToolTip = "View Audit for this record"
        End Select
        Me.pageHeaderTitle.Text = uPage.pageTitle
        Me.UniversalAccessHelp.Text = "Any user, logged on or not, will have acces to document ids matching the regular expression pattern:" & uPage.db.GetParameterValue("UniversalContentRegPtrn")
        'Setup and show Content Set Source update section
        If Me.SelectedSourceType <> Nothing Then
            Me.ContentSourceUpdateTitle.Text = "Update Content Set Source for " & Me.SelectedSourceType.ToString
            Me.ContentSourceSetUpdateTable.Visible = True
            Me.ExcEmbargoedYearsRow.Visible = SelectedSourceType = ContentSetSourceTypes.Journal And Me.SingleYearOnly.Text = ""
            Me.EmbargoedYearsOnlyRow.Visible = SelectedSourceType = ContentSetSourceTypes.Journal And Me.SingleYearOnly.Text = ""
            Me.OverrideEmbargoYearsRow.Visible = (ExcludeEmbargoedYears.Checked Or EmbargoedYearsOnly.Checked) And SelectedSourceType = ContentSetSourceTypes.Journal And Me.SingleYearOnly.Text = ""
            Me.SingleYearOnlyRow.Visible = SelectedSourceType = ContentSetSourceTypes.Journal
            Select Case SelectedSourceType
                Case ContentSetSourceTypes.Journal
                    Me.IncludeAllSourceItemstext.Text = "If ticked then all " & SelectedSourceType.ToString & " will be considered. "
                    Me.IncludeAllSourceItemstext.Text += "<br>If Un-ticked then only Journals, Issues or Documents listed in 'Included Items' below will be considered."
                    Me.IncludeAllSourceItemstext.Text += "<br>The 'considered' items will then be further filtered by the including/excluding embargoes years options below."
                Case Else
                    Me.IncludeAllSourceItemstext.Text = "If ticked then all " & SelectedSourceType.ToString & " will be included."
                    Me.IncludeAllSourceItemstext.Text += "<br>If Un-ticked then only " & SelectedSourceType.ToString & " listed in 'Included Items' below will be included."
            End Select
            Me.ExcEmbargoedYearsText.Text = "If ticked, items that are still being embargoed will be excluded.  An item Is embargoed if the item year Is greater than the CurrentContentYear(" & uPage.db.GetParameterValue("CurrentContentYear") & ") - EmbargoYears."
            Me.EmbargoedYearsOnlyText.Text = "If ticked then only embargoed years will be included."
            Me.OverrideEmbargoYearsText.Text = "Override the embargoes years for all " & SelectedSourceType.ToString & ".  If, say 1, then includes the current year And the previous year."
            Me.SingleYearOnlyText.Text = "This will allow just a single year.  The years are numbered 0,1,2.. backwards from the current year. Therefore if the CurrentContentYear Is 2020 And SingleYearOnly Is 1 then only 2019 editions will be shown."

            Me.JounalDropDownsRow.Visible = Me.ContentSetSourceRow IsNot Nothing And Me.SelectedSourceType = ContentSetSourceTypes.Journal And Not IncludeAllSourceItems.Checked 'Jounals
            Me.VolumesDropDownRow.Visible = Me.ContentSetSourceRow IsNot Nothing And Me.JounalDropDownsRow.Visible And Me.JournalsDropdown.SelectedValue <> ""
            Me.ContentListsRow.Visible = Me.ContentSetSourceRow IsNot Nothing And Not IncludeAllSourceItems.Checked
            Me.SelectFromList.Visible = Me.ContentSetSourceRow IsNot Nothing And (Me.VolumesDropdown.SelectedValue <> "" Or Me.SelectedSourceType <> ContentSetSourceTypes.Journal)
            If Not Me.IncludeAllSourceItems.Checked Then
                Me.SourceHelpMsgDiv.Visible = True
                If Me.ContentSetSourceRow Is Nothing Then
                    Me.SourceHelpMsg.Text = "Click save to add the " & SelectedSourceType.ToString & " source, And then you will be able to select specidic " & SelectedSourceType.ToString
                Else
                    Select Case SelectedSourceType
                        Case ContentSetSourceTypes.Journal
                            Me.SourceHelpMsg.Text = "To add a complete journal select it from the drop down And click add."
                            Me.SourceHelpMsg.Text += "<br>To add a volume, select a journal And then the volume And then click add."
                            Me.SourceHelpMsg.Text += "<br>To add an individual documents, select a journal, a volume And then required documeents And then click add."
                        Case Else
                            Me.SourceHelpMsg.Text = "Select one Or more " & SelectedSourceType.ToString & " from the left hand list And click Add to include them"

                    End Select
                    Me.SourceHelpMsg.Text += "<br><br>Remember to save to store included items with this content set"
                    Me.SourceHelpMsg.Text += "<br><br>Items can be removed by selecting them in the right hand list And clicking remove."

                End If
            Else
                Me.SourceHelpMsgDiv.Visible = False
            End If

        End If

    End Sub



    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else
                Me.uPage.FieldValidateMandatory(Me.ContentSetName)
                If SelectedSourceType <> Nothing Then
                    uPage.FieldValidateNumber(Me.OverrideEmbargoYears, False)
                    uPage.FieldValidateNumber(Me.SingleYearOnly, False)
                End If
        End Select

        Return Me.uPage.IsValid
    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        Me.uPage.PopulatePageFieldsFromDataRow(Me.ContentSet.ContentSetRow)

        Dim sql As String = "SELECT PEPCode As Value" _
                        & "     ,PEPCode + '-' + displayTitle As Text" _
                        & " FROM ContentJournals" _
                        & " ORDER BY 2 Asc"
        Me.uPage.PopulateDropDownListFromSQL(Me.JournalsDropdown, sql, uPage.db.DBConnection, "<--Select-->")


        If Me.ContentSetSourceRow IsNot Nothing Then
            Me.uPage.PopulatePageFieldsFromDataRow(Me.ContentSetSourceRow)
            Me.uPage.PopulateListBoxFromSql(Me.IncludedList, Me.ContentSet.GetSourceItemsSQL(Me.SelectedSourceType), Nothing)

        End If
        PopulateLists()
    End Sub
    Sub PopulateLists()
        Dim sql As String = ""
        If Me.SelectedSourceType <> Nothing Then
            If Me.SelectedSourceType = ContentSetSourceTypes.Journal Then
                If Me.JournalsDropdown.SelectedValue <> "" And Me.VolumesDropdown.SelectedValue = "" Then
                    sql = "SELECT vol As Value" _
                        & "     ,year + '-' + vol As Text" _
                        & " FROM ContentVolumes " _
                        & " WHERE PEPCode = '" & Me.JournalsDropdown.SelectedValue & "'" _
                        & " ORDER BY 2 Asc"
                    Me.uPage.PopulateDropDownListFromSQL(Me.VolumesDropdown, sql, uPage.db.DBConnection, "<--Select-->")
                End If

            Else
                sql = "SELECT PEPCode As Value" _
                    & "     ,PEPCode + '-' + title As Text" _
                    & " FROM Content" & Me.SelectedSourceType.ToString & "s" _
                    & " ORDER BY 2 Asc"
                Me.uPage.PopulateListBoxFromSql(Me.SelectFromList, sql, Nothing)
            End If

        End If
    End Sub
    Sub PopulateJournalDocs()
        If Me.VolumesDropdown.SelectedValue <> "" Then
            Dim sql As String = ""
            sql = "SELECT documentId As Value" _
            & "     ,documentId + '-' + documentRef As Text" _
            & " FROM ContentDocuments" _
            & " WHERE PEPCode ='" & Me.JournalsDropdown.SelectedValue & "'" _
            & " AND vol ='" & Me.VolumesDropdown.SelectedValue & "'" _
            & " ORDER BY 2 Asc"
            Me.uPage.PopulateListBoxFromSql(Me.SelectFromList, sql, Nothing)
        End If

    End Sub
    Sub SaveRecord()
        '******************************************************
        'Description:	Save the record either by updating
        '******************************************************
        Try
            uPage.db.BeginTran()
            Try

                Me.uPage.PopulateDataRowFromPageFields(Me.ContentSet.ContentSetRow)
                If Me.SelectedSourceType <> Nothing Then
                    If Me.ContentSetSourceRow Is Nothing Then Me.ContentSet.AddContentsetSource(Me.SelectedSourceType)
                    Me.uPage.PopulateDataRowFromPageFields(Me.ContentSetSourceRow)
                    Dim vw As New DataView(Me.ContentSet.ContentSetSourceItem, "ContentSetSourceId=" & Me.ContentSetSourceRow("ContentSetSourceId"), "", DataViewRowState.CurrentRows)
                    For i As Integer = vw.Count - 1 To 0 Step -1
                        vw(i).Delete()
                    Next
                    If Me.IncludeAllSourceItems.Checked Then

                    Else
                        Dim tmpId As Integer = -1
                        For Each item As ListItem In Me.IncludedList.Items
                            Dim r As DataRow = Me.ContentSet.ContentSetSourceItem.NewRow
                            r("ContentSetSourceItemId") = tmpId
                            tmpId -= 1
                            r("ContentSetSourceId") = Me.ContentSetSourceRow("ContentSetSourceId")
                            Select Case Me.SelectedSourceType
                                Case ContentSetSourceTypes.Journal
                                    Dim idParts() As String = item.Value.Split(".")

                                    r("ContentCode") = idParts(0)
                                    If idParts.Length > 1 Then r("volume") = CInt(idParts(1))
                                    If idParts.Length > 2 Then r("DocumentId") = item.Value
                                Case Else
                                    r("ContentCode") = item.Value
                            End Select
                            Me.ContentSet.ContentSetSourceItem.Rows.Add(r)
                        Next

                    End If
                End If
                Me.ContentSet.Save()
                Me.uPage.db.CommitTran()

            Catch ex As Exception
                uPage.db.RollbackTran()
                Throw ex
            End Try

        Catch ex As Exception
            Me.uPage.PageError = "An Unexpected Error has occured.  Please contact support" & ex.ToString
        End Try

        If Me.uPage.IsValid Then
            If Me.SelectedSourceType <> Nothing Then
                Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=Content Set has been saved&SelectedSourceType=" & Me.SelectedSourceType & "&ContentSetId=" & Me.ContentSet.ContentSetId & "&" & Me.uPage.UserSession.QueryString)
            Else
                Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=Content Set has been saved&ContentSetId=" & Me.ContentSet.ContentSetId & "&" & Me.uPage.UserSession.QueryString)
            End If
        End If
    End Sub

    Protected Sub AddNewBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AddNewBtn.Click
        If Me.NewContentSetName.Text <> "" Then
            Dim NewContentSet As New BusinessLogic.ContentSet(Me.uPage.db, Me.uPage.UserSession)
            Try
                uPage.db.BeginTran()
                Try
                    NewContentSet.AddContentSet(Me.NewContentSetName.Text)

                    uPage.db.CommitTran()
                Catch ex As Exception
                    uPage.db.RollbackTran()
                    Throw ex
                End Try

            Catch ex As Exception
                Me.uPage.PageError = "An unexpected error has occured. Please contact support." & ex.ToString
            End Try

            If Me.uPage.IsValid Then
                Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=New Content Set has been saved&ContentSetId=" & NewContentSet.ContentSetId & "&" & Me.uPage.UserSession.QueryString)
            End If
        Else
            Me.uPage.PageError = "New Content Set Name is mandatory"
        End If

    End Sub

    Protected Sub SaveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If Me.IsPageValidForStatus("") Then SaveRecord()
    End Sub

    Protected Sub BackBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackBtn.Click, BackBtn1.Click
        Response.Redirect("../pages/pg270ContentSetSelect.aspx?" & Me.uPage.UserSession.QueryString)
    End Sub

    Protected Sub CancelUpdateBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelUpdateBtn.Click, ResetBtn.Click
        ViewState("SelectedSourceType") = Nothing
        Response.Redirect(Request.ServerVariables("Path_Info") & "?ContentSetId=" & Me.ContentSet.ContentSetId & "&" & Me.uPage.UserSession.QueryString())
    End Sub

    Protected Sub ActivateBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ActivateBtn.Click
        Try
            If Me.IsPageValidForStatus("") Then
                Me.ContentSetStatus.Text = "Active"
                SaveRecord()
            End If
        Catch ex As Exception
            Me.uPage.PageError = "An unexpected Error has occured. Please contact support." & ex.ToString
        End Try
    End Sub

    Protected Sub InactiveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles InactiveBtn.Click
        Try
            If Me.IsPageValidForStatus("") Then
                Me.ContentSetStatus.Text = "Inactive"
                SaveRecord()
            End If
        Catch ex As Exception
            Me.uPage.PageError = "An unexpected Error has occured. Please contact support." & ex.ToString
        End Try
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.ContentSet.MainDataset
        Me.PageSetup()
    End Sub

    Sub BuildContentSetSourceTableHTML()
        Try
            Dim tRow As New TableRow()
            Dim tCell As New TableCell()
            Dim SourceTypes As ContentSetSourceTypes() = System.Enum.GetValues(GetType(ContentSetSourceTypes))
            For Each SourceType As ContentSetSourceTypes In SourceTypes.Skip(1)
                Dim row As DataRow = Nothing
                For Each r As DataRow In Me.ContentSet.ContentSetSource.Rows
                    If r("SourceType") = SourceType.ToString Then row = r
                Next

                tRow = New TableRow()
                If Me.SelectedSourceType = SourceType Then
                    tRow.BackColor = System.Drawing.Color.LightGray
                End If
                tCell = New TableCell()
                Dim link As New WebControls.HyperLink
                link.NavigateUrl = "pg271ContentSetMaint.aspx?ContentSetId=" & Me.ContentSetId.Text & "&SelectedSourceType=" & SourceType & "&" & uPage.UserSession.QueryString
                link.Text = IIf(row Is Nothing, "Add", "Edit")
                tCell.Controls.Add(link)
                tRow.Cells.Add(tCell)
                'tCell = New TableCell()
                'tCell.CssClass = "fldView"
                'tCell.Text = row("ContentSetSourceId")
                'tRow.Cells.Add(tCell)
                tCell = New TableCell()
                tCell.CssClass = "fldView"
                tCell.Text = SourceType.ToString
                tRow.Cells.Add(tCell)
                If row Is Nothing Then
                    tCell = New TableCell()
                    tCell.CssClass = "fldView"
                    tCell.ColumnSpan = 6
                    tCell.Text = "Not Included"
                    tRow.Cells.Add(tCell)

                Else

                    tCell = New TableCell()
                    tCell.CssClass = "fldView"
                    tCell.Text = uPage.db.IsDBNull(row("IncludeAllSourceItems"), "")
                    tRow.Cells.Add(tCell)
                    tCell = New TableCell()
                    tCell.CssClass = "fldView"
                    tCell.Text = uPage.db.IsDBNull(row("ExcludeEmbargoedYears"), "")
                    tRow.Cells.Add(tCell)
                    tCell = New TableCell()
                    tCell.CssClass = "fldView"
                    tCell.Text = uPage.db.IsDBNull(row("EmbargoedYearsOnly"), "")
                    tRow.Cells.Add(tCell)
                    tCell = New TableCell()
                    tCell.CssClass = "fldView"
                    tCell.Text = uPage.db.IsDBNull(row("OverrideEmbargoYears"), "")
                    tRow.Cells.Add(tCell)
                    tCell = New TableCell()
                    tCell.CssClass = "fldView"
                    tCell.Text = uPage.db.IsDBNull(row("SingleYearOnly"), "")
                    tRow.Cells.Add(tCell)
                End If
                Me.ContentSetSourceList.Rows.Add(tRow)
            Next
        Catch ex As Exception
            uPage.PageError = "An Unexpected error has occured.  Please contact support" & ex.ToString
        End Try
    End Sub

    Private Sub IncludeAllSourceItems_CheckedChanged(sender As Object, e As EventArgs) Handles IncludeAllSourceItems.CheckedChanged
        PopulateLists()
    End Sub

    Private Sub JournalsDropdown_SelectedIndexChanged(sender As Object, e As EventArgs) Handles JournalsDropdown.SelectedIndexChanged
        PopulateLists()
    End Sub

    Private Sub AddToListBtn_Click(sender As Object, e As EventArgs) Handles AddToListBtn.Click
        Select Case SelectedSourceType
            Case ContentSetSourceTypes.Journal
                If Me.JournalsDropdown.SelectedValue <> "" And Me.VolumesDropdown.SelectedValue = "" Then
                    Dim item As New ListItem(Me.JournalsDropdown.SelectedItem.Text, Me.JournalsDropdown.SelectedValue)
                    Me.IncludedList.Items.Add(item)
                ElseIf Me.VolumesDropdown.SelectedValue <> "" And Me.SelectFromList.SelectedValue = "" Then
                    Dim item As New ListItem(Me.VolumesDropdown.SelectedItem.Text, Me.JournalsDropdown.SelectedValue & "." & CInt(Me.VolumesDropdown.SelectedValue).ToString("000"))
                    Me.IncludedList.Items.Add(item)
                End If
        End Select
        For Each fromItem As ListItem In Me.SelectFromList.Items
            If fromItem.Selected Then
                If Not Me.IncludedList.Items.Contains(fromItem) Then
                    Me.IncludedList.Items.Add(fromItem)
                End If
            End If
        Next
    End Sub

    Private Sub RemoveFromListBtn_Click(sender As Object, e As EventArgs) Handles RemoveFromListBtn.Click
        Dim i As Integer = IncludedList.Items.Count - 1
        Do While i >= 0
            Dim includedItem As ListItem = IncludedList.Items(i)
            If includedItem.Selected Then
                Me.IncludedList.Items.Remove(includedItem)
                '  i -= 1
            End If
            i -= 1
        Loop
    End Sub

    Private Sub VolumesDropdown_SelectedIndexChanged(sender As Object, e As EventArgs) Handles VolumesDropdown.SelectedIndexChanged
        PopulateJournalDocs()
    End Sub

    Private Sub ExcludeEmbargoedYears_CheckedChanged(sender As Object, e As EventArgs) Handles ExcludeEmbargoedYears.CheckedChanged
        If Me.ExcludeEmbargoedYears.Checked Then
            Me.EmbargoedYearsOnly.Checked = False
            Me.SingleYearOnly.Text = ""
        End If
    End Sub

    Private Sub EmbargoedYearsOnly_CheckedChanged(sender As Object, e As EventArgs) Handles EmbargoedYearsOnly.CheckedChanged
        If Me.EmbargoedYearsOnly.Checked Then
            Me.ExcludeEmbargoedYears.Checked = False
            Me.SingleYearOnly.Text = ""
        End If

    End Sub

    Private Sub SingleYearOnly_TextChanged(sender As Object, e As EventArgs) Handles SingleYearOnly.TextChanged
        If IsNumeric(SingleYearOnly.Text) Then
            Me.EmbargoedYearsOnly.Checked = False
            Me.ExcludeEmbargoedYears.Checked = False
            Me.OverrideEmbargoYears.Text = ""
        End If
    End Sub

    Private Sub OverrideEmbargoYears_TextChanged(sender As Object, e As EventArgs) Handles OverrideEmbargoYears.TextChanged
        If IsNumeric(OverrideEmbargoYears.Text) Then
            Me.SingleYearOnly.Text = ""
        End If
    End Sub
End Class
