﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'09/04/2020    Julian Gates   Initial Version

Partial Class Pages_pg270ContentSetSelect
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Content Set List", "")
        Me.pageHeaderTitle.Text = "Content Set List"

        If Page.IsPostBack Then

        Else

        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        GridSetup()

    End Sub

    Sub PageSetup()

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub GridSetup()
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT cs.ContentSetId" & sCR
            Sql += " ,cs.ContentSetName" & sCR
            Sql += " ,cs.ContentSetStatus" & sCR
            Sql += " ,Journals = dbo.fn275ContentSetSourceDesc(cs.ContentSetId,'Journals')" & sCR
            Sql += " ,Books = dbo.fn275ContentSetSourceDesc(cs.ContentSetId,'Books')" & sCR
            Sql += " ,Videos = dbo.fn275ContentSetSourceDesc(cs.ContentSetId,'Videos')" & sCR
            Sql += " FROM ContentSet cs" & sCR
            'Sql += "    INNER JOIN ContentSetSource css" & sCR
            'Sql += "    ON cs.ContentSetId = css.ContentSetId" & sCR
            Sql += " WHERE 1 = 1" & sCR
            Sql += " ORDER BY cs.ContentSetId" & sCR

            Me.ContentSetDatasource.SelectCommand = Sql
            Me.ContentSetDatasource.DataBind()
            Me.ContentSetGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Protected Sub AddNewBtn_Click(sender As Object, e As EventArgs) Handles AddNewBtn.Click
        Response.Redirect("../Pages/pg271ContentSetMaint.aspx?" & uPage.UserSession.QueryString)
    End Sub
End Class
