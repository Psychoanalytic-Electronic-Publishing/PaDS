﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'29/01/2021    Julian Gates   Initial Version

Partial Class Pages_pg090SessionData
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Public FltrQueryString As String = Nothing

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Session Data", "")
        Me.pageHeaderTitle.Text = "Session Data"

        If Page.IsPostBack Then

        Else
            If Request.QueryString("LastWeekOnly") <> "" Then Me.ExcludeNotLoggedIn.Checked = Request.QueryString("LastWeekOnly")
            If Request.QueryString("ExcludeNotLoggedIn") <> "" Then Me.ExcludeNotLoggedIn.Checked = Request.QueryString("ExcludeNotLoggedIn")
            If Request.QueryString("ExcludeOldPEPWeb") <> "" Then Me.ExcludeOldPEPWeb.Checked = Request.QueryString("ExcludeOldPEPWeb")
            If Request.QueryString("PEPWebOnly") <> "" Then Me.PEPWebOnly.Checked = Request.QueryString("PEPWebOnly")
            If Request.QueryString("IPAddress") <> "" Then Me.PEPWebOnly.Checked = Request.QueryString("IPAddress")

            'submit a job to get latest PEPSessionLog records,do as batch job so as not to conflict with regular job
            Dim bj As New BusinessLogic.BatchJob(uPage.db)
            bj.SubmittedByUserSessionId = uPage.UserSession.UserSessionIdGUID
            bj.CreateBatchJobEntry("GetPEPWebSessionLog", uPage.db)
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        SessionsGridSetup()

        If Request.QueryString("SelectedSessionId") <> "" Then
            Me.SessionDataGridSetup(Request.QueryString("SelectedSessionId"))
            Me.PEPWebLogGridSetup(Request.QueryString("SelectedSessionId"))
            Me.SessionLogGridSetup(Request.QueryString("SelectedSessionId"))
            Me.OPASSessionLogGridSetup(Request.QueryString("SelectedSessionId"))
            Me.pageHeaderTitle.Text = "Session Data for Session: " & Request.QueryString("SelectedSessionId")
        End If
    End Sub

    Sub PageSetup()
        FltrQueryString = ""
        If Not LastWeekOnly.Checked Then FltrQueryString += "&LastWeekOnly=False"
        If Not ExcludeNotLoggedIn.Checked Then FltrQueryString += "&ExcludeNotLoggedIn=False"
        If Not ExcludeOldPEPWeb.Checked Then FltrQueryString += "&ExcludeOldPEPWeb=False"
        If PEPWebOnly.Checked Then FltrQueryString += "&PEPWebOnly=True"
        If IPAddress.Text <> "IPAddress" Then FltrQueryString += "&IPAddress=" & IPAddress.Text
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub SessionsGridSetup()
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT us.UserSessionId" & sCR
            Sql += " ,us.StartDate" & sCR
            Sql += " ,us.LastAccessedDate" & sCR
            Sql += " ,us.UserId" & sCR
            Sql += " ,UserDesc = us.UserName + '(' + CAST(us.UserId AS VARCHAR) + ')'" & sCR
            Sql += " ,LoggedInMethod = (SELECT MAX(CAST(d.DataItemValue AS VARCHAR(100))) From UserSessionData d With (nolock) WHERE d.DataItemName = 'LoggedInMethod' AND d.UserSessionId=us.UserSessionId)" & sCR
            Sql += " FROM UserSession us With (nolock)" & sCR
            Sql += " WHERE 1=1 "
            If Me.LastWeekOnly.Checked Then Sql += " AND us.startDate > DATEADD(DAY,-7,GETDATE())" & sCR
            If Me.ExcludeNotLoggedIn.Checked Then Sql += " AND UserId <> -1" & sCR
            If Me.ExcludeOldPEPWeb.Checked Then Sql += " AND NOT EXISTS(SELECT l.SessionId FROM SessionLog l WHERE l.SessionId = us.UserSessionId AND l.LogType = 'PEPProduct' )" & sCR
            If Me.PEPWebOnly.Checked Then Sql += " AND  EXISTS(SELECT l.UserSessionId FROM PEPWebUsageLog l WHERE l.UserSessionId = us.UserSessionId)" & sCR
            If IPAddress.Text <> "IPAddress" Then Sql += " AND us.UserSessionId IN (select l2.SessionId from sessionlog l2 where  l2.Comment like '%" & IPAddress.Text & "%' or l2.RemoteIPAddress = '" & IPAddress.Text & "')"
            Sql += " ORDER BY us.LastAccessedDate desc" & sCR
            Me.SessionsDatasource.SelectCommand = Sql
            If uPage.UserSession.Data("pg090FilterExpression") IsNot Nothing Then Me.SessionsGridView.FilterExpression = uPage.UserSession.Data("pg090FilterExpression")

            Me.SessionsDatasource.DataBind()
            Me.SessionsGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Sub SessionDataGridSetup(ByVal UserSessionId As String)
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT usd.UserSessionId" & sCR
            Sql += " ,usd.DataItemName" & sCR
            Sql += " ,usd.DataItemValue" & sCR
            Sql += " FROM UserSessionData usd  with (nolock)" & sCR
            Sql += " WHERE UserSessionId = '" & UserSessionId & "'" & sCR
            Sql += " ORDER By usd.DataItemName" & sCR

            Me.SessionDataDatasource.SelectCommand = Sql
            Me.SessionDataDatasource.DataBind()
            Me.SessionDataGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Sub PEPWebLogGridSetup(ByVal UserSessionId As String)
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT pwul.PEPWebUsageLogId" & sCR
            Sql += " ,pwul.DateTime" & sCR
            Sql += " ,pwul.ActionType" & sCR
            Sql += " ,pwul.LogonLocation" & sCR
            Sql += " ,pwul.LogonStatus" & sCR
            Sql += " ,Subscriber = ISNULL(s.Subscribername,'') + '(' + CAST(pwul.SubscriberId AS VARCHAR) + ')'" & sCR
            Sql += " ,pwul.SubscriberId" & sCR
            Sql += " ,pwul.OrderNumber" & sCR
            Sql += " ,pwul.AccessibleContentSets" & sCR
            Sql += " ,pwul.ReasonForCheck" & sCR
            Sql += " ,IPAddress = pwul.RemoteIPAddress + ISNULL('(' + (SELECT MAX(Notes) FROM RemoteUserAutoLogon WHERE MinIPAddress = pwul.RemoteIPAddress) + ')','')" & sCR
            Sql += " ,pwul.DocumentId" & sCR
            Sql += " ,Info = pwul.DocumentId + ' ' + ISNULL(d.documentRef,'') + ' ' + ISNULL(pwul.AdditionalDetails,'') " & sCR
            Sql += " FROM PEPWebUsageLog pwul with (nolock)" & sCR
            Sql += "    LEFT JOIN Subscriber s with (nolock)" & sCR
            Sql += "    ON s.SubscriberId = pwul.SubscriberId" & sCR
            Sql += "    LEFT JOIN contentdocuments d WITH (NOLOCK)" & sCR
            Sql += "        LEFT JOIN contentjournals j WITH (NOLOCK)" & sCR
            Sql += "        ON j.pepcode = d.pepcode" & sCR
            Sql += "    ON d.DocumentId = pwul.DocumentId collate database_default" & sCR
            Sql += " WHERE pwul.UserSessionId = '" & UserSessionId & "'" & sCR
            Sql += " ORDER By pwul.DateTime desc" & sCR
            Sql += "    , pwul.PEPWebUsageLogId desc" & sCR

            Me.PEPWebLogDatasource.SelectCommand = Sql
            Me.PEPWebLogDatasource.DataBind()
            Me.PEPWebLogGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Sub SessionLogGridSetup(ByVal UserSessionId As String)
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT s.SessionLogId" & sCR
            Sql += " ,s.Date" & sCR
            Sql += " ,s.LogType" & sCR
            Sql += " ,Page = LEFT(LEFT(REPLACE(s.PageId,'/Pages/',''),5) + ' ' + s.PageTitle,30)" & sCR
            Sql += " ,s.PageTitle" & sCR
            Sql += " ,RemoteIPAddress = s.RemoteIPAddress  + ISNULL('(' + (SELECT MAX(Notes) FROM RemoteUserAutoLogon WHERE MinIPAddress = s.RemoteIPAddress) + ')','')" & sCR
            Sql += " ,s.Comment" & sCR
            Sql += " FROM SessionLog s with (nolock)" & sCR
            Sql += " WHERE s.SessionId = '" & UserSessionId & "'" & sCR
            Sql += " ORDER By s.Date desc" & sCR
            Sql += "    , s.SessionLogId desc" & sCR

            Me.SessionLogDatasource.SelectCommand = Sql
            Me.SessionLogDatasource.DataBind()
            Me.SessionLogGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Sub OPASSessionLogGridSetup(ByVal UserSessionId As String)
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT s.PEPWebSessionLogId" & sCR
            Sql += " ,s.UserSessionId" & sCR
            Sql += " ,s.LastUpdate" & sCR
            Sql += " ,s.ItemOfInterest" & sCR
            Sql += " ,s.Endpoint" & sCR
            Sql += " ,s.Params" & sCR
            Sql += " ,s.ReturnAddedStatusMessage" & sCR
            Sql += " FROM PEPWebSessionLog s with (nolock)" & sCR
            Sql += " WHERE s.UserSessionId = '" & UserSessionId & "'" & sCR
            Sql += " ORDER By s.LastUpdate DESC" & sCR
            Sql += "    , s.PEPWebSessionLogId DESC" & sCR

            Me.OPASSessionLogDatasource.SelectCommand = Sql
            Me.OPASSessionLogDatasource.DataBind()
            Me.OPASSessionLogGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Protected Sub SelectRowBtn_CustomButtonCallback(ByVal sender As Object, ByVal e As DevExpress.Web.ASPxGridViewCustomButtonCallbackEventArgs)
        Dim userSessionId As String = Nothing
        If e.ButtonID <> "SelectRowBtn" Then
            Return
        End If
        Try
            userSessionId = SessionsGridView.GetRowValues(e.VisibleIndex, "UserSessionId").ToString
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
        If uPage.IsValid Then
            If Page.IsCallback Then
                'Have to use code below to do redirect as response redirect cant be used in a CustomButtonCallback
                DevExpress.Web.ASPxWebControl.RedirectOnCallback(VirtualPathUtility.ToAbsolute(Request.ServerVariables("Path_Info") & "?SelectedSessionId=" & userSessionId & "&" & uPage.UserSession.QueryString))
            End If
        End If
    End Sub

    Private Sub SessionsGridView_DataBound(sender As Object, e As EventArgs) Handles SessionsGridView.DataBound
        uPage.UserSession.Data("pg090FilterExpression") = SessionDataGridView.FilterExpression
    End Sub
    Protected Sub SessionsGridView_OnHtmlRowPrepared(ByVal s As Object, ByVal e As DevExpress.Web.ASPxGridViewTableRowEventArgs)
        Dim grid = TryCast(s, DevExpress.Web.ASPxGridView)
        If e.RowType = DevExpress.Web.GridViewRowType.Data Then
            If e.GetValue("UserSessionId").ToString = Request.QueryString("SelectedSessionId") Then
                e.Row.BackColor = System.Drawing.Color.Yellow
            End If
        End If
    End Sub
    Private Sub CancelBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearBtn.Click

        Response.Redirect(Request.ServerVariables("Path_Info") & "?" & uPage.UserSession.QueryString)

    End Sub
End Class
