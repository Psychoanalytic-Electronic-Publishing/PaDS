﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'15/04/2020    Julian Gates   Initial Version

Partial Class Pages_pg170BankDepositSelect
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Bank Deposit Search and List", "")
        Me.pageHeaderTitle.Text = "Bank Deposit Search and List"

        'Only allow update by AuthorityLevel Admin users
        Select Case Me.uPage.UserSession.AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
            Case Else
                Response.Redirect("../Pages/pg100HomeAdmin.aspx?InfoMsg=Your userid does not allow you access to this page." & uPage.UserSession.QueryString)
        End Select

        If Page.IsPostBack Then

        Else

        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        GridSetup()

    End Sub

    Sub PageSetup()

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub GridSetup()
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT bd.BankDepositId" & sCR
            Sql += " ,bd.CompanyId" & sCR
            Sql += " ,Company.CompanyName" & sCR
            Sql += " ,BankDetails = cba.BankAccountName + ' - Acct:' + bd.BankAccountNumber + ' - Sort:' + bd.BankSortCode" & sCR
            Sql += " ,bd.DateBanked" & sCR
            Sql += " ,cba.CurrencyCode" & sCR
            Sql += " ,bd.AmountDeposited" & sCR
            Sql += " FROM BankDeposit bd" & sCR
            Sql += "    INNER JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId) & sCR
            Sql += "    ON Company.CompanyId = bd.CompanyId" & sCR
            Sql += "	INNER JOIN CompanyBankAccount cba" & sCR
            Sql += "	ON cba.CompanyId = bd.CompanyId " & sCR
            Sql += "	AND cba.BankSortCode = bd.BankSortCode " & sCR
            Sql += "	AND cba.BankAccountNumber = bd.BankAccountNumber " & sCR
            Sql += " WHERE 1 = 1" & sCR
            Sql += " ORDER BY bd.BankDepositId Desc" & sCR

            Me.BankDepositDatasource.SelectCommand = Sql
            Me.BankDepositDatasource.DataBind()
            Me.BankDepositGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Protected Sub AddNewBtn_Click(sender As Object, e As EventArgs) Handles AddNewBtn.Click
        Response.Redirect("../Pages/pg171BankDepositMaint.aspx?" & uPage.UserSession.QueryString)
    End Sub
End Class
