﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web
'Modification History
'21/05/2015 Julian Gates    Initial Version
'18/05/2016 Julian Gates    SIR4130 - Change Child Product add to update CompanyId with Product parent CompanyId
'24/05/16   Julian Gates    SIR4132 - Validate ProductCose ProductShortName and ProductName is unique and mandatory
'30/09/20   Julian Gates    SIR5118 - Add DisableAutoRenewalFlag and associated code.

'19/08/20   Julian Gates    SIR5099 - Add Audit link

Partial Class Pages_pg504ProductMaint
    Inherits System.Web.UI.Page
    Dim pageMode As String = ""
    Public uPage As UserPage

    Private _Product As BusinessLogic.Product = Nothing
    Public Property Product() As BusinessLogic.Product
        Get
            If Me._Product Is Nothing Then
                Me._Product = New BusinessLogic.Product(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._Product
        End Get
        Set(ByVal value As BusinessLogic.Product)
            Me._Product = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Product Maint", "")
        Me.pageHeaderTitle.Text = "Product Maint"

        If Request.QueryString("ProductCode") <> "" Then
            pageMode = "Update"
        Else
            pageMode = "Add"
        End If

        If Page.IsPostBack Then
            Me.Product.MainDataset = CType(ViewState("MainDataSet"), DataSet)
        Else
            If Request.QueryString("ProductCode") <> "" Then
                Try
                    Me.ProductCode.Text = Request.QueryString("ProductCode")
                    Me.Product = New BusinessLogic.Product(Request.QueryString("ProductCode"), Me.uPage.db, Me.uPage.UserSession)
                Catch ex As Exception
                    Me.uPage.PageError = "Invalid Parameter has been passed in"
                End Try
                pageMode = "Update"
                Me.ProductName.Focus()
            Else
                pageMode = "Add"
                Me.Product = New BusinessLogic.Product(Me.uPage.db, Me.uPage.UserSession)
                Me.ProductCode.Focus()
            End If

            If Me.uPage.IsValid Then
                ReadRecord()
            End If
        End If
        Me.TargetProductCode.Value = Me.ProductCode.Text
        '18/05/16   Julian Gates    SIR4130 - Change Child Product add to update CompanyId with Product parent CompanyId
        Me.TargetCompanyId.Value = Me.CompanyID.SelectedValue

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If
    End Sub

    Sub PageSetup()
        Select Case pageMode
            Case "Add"
                Me.pageHeaderTitle.Text = "Add Product"
                Me.ProductCode.Enabled = True
                Me.RatesLinksRow.Visible = False
                Me.ChildProductListRow.Visible = False
            Case "Update"
                Me.pageHeaderTitle.Text = "Product: " & Me.ProductCode.Text
                Me.ProductCode.Enabled = False
                Me.RatesLinksRow.Visible = True
                Me.ChildProductListRow.Visible = True

                Me.ProductSelectLink.NavigateUrl = "../pages/pg503ProductSelect.aspx?" & uPage.UserSession.QueryString
                Me.ProductRatesLink.NavigateUrl = "../pages/pg502ProductRatesMaint.aspx?" & uPage.UserSession.QueryString & "&ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.CompanyID.SelectedValue
                Me.QualifyingProductsLink.NavigateUrl = "../pages/pg505QualifyingProductMaint.aspx?" & uPage.UserSession.QueryString & "&ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.CompanyID.SelectedValue
                Me.AffiliateRatesLink.NavigateUrl = "../pages/pg506AffiliateRatesMaint.aspx?" & uPage.UserSession.QueryString & "&ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.CompanyID.SelectedValue
                Me.ProductContentSetLink.NavigateUrl = "../pages/pg507ProductContentSetMaint.aspx?" & uPage.UserSession.QueryString & "&ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.TargetCompanyId.Value

                '19/08/20   Julian Gates    SIR5099 - Add Audit link
                Me.AuditLink.NavigateUrl = "../pages/pg040AuditLogDisplay.aspx?FltrUpdatedRecordFamily=Product&FltrUpdatedRecordFamilyKey=" & Me.ProductCode.Text & "&" & uPage.UserSession.QueryString
                Me.AuditLink.Text = "View Audit"
                Me.AuditLink.ToolTip = "View Audit for this record"
        End Select
        Me.RecurringSubscriptionFieldsTable.Visible = Me.RecurringSubscriptionFlag.Checked = True
    End Sub
    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else
                Select Case pageMode
                    Case "Add"
                        If Me.ProductCode.Text = "" Then
                            uPage.FieldErrorControl(Me.ProductCode, "Product Code is mandatory")
                        End If
                        If Me.ProductCode.Text <> "" Then
                            If Me.ProductCode.Text = Me.uPage.db.DLookup("ProductCode", "Product", "ProductCode='" & Me.ProductCode.Text & "'") Then
                                uPage.FieldErrorControl(Me.ProductCode, "Entered Product Code already exists, please enter another.")
                            End If
                        End If
                        '24/05/16   Julian Gates    SIR4132 - Validate ProductName and ProductShortName is unique
                        If Me.ProductName.Text <> "" Then
                            If Me.ProductName.Text = Me.uPage.db.DLookup("ProductName", "Product", "ProductName='" & Me.ProductName.Text & "'") Then
                                uPage.FieldErrorControl(Me.ProductName, "Entered Product Name already exists, please enter another.")
                            End If
                        End If
                        If Me.ProductShortName.Text <> "" Then
                            If Me.ProductShortName.Text = Me.uPage.db.DLookup("ProductShortName", "Product", "ProductShortName='" & Me.ProductShortName.Text & "'") Then
                                uPage.FieldErrorControl(Me.ProductShortName, "Entered Product Short Name already exists, please enter another.")
                            End If
                        End If
                    Case "Update"
                        '24/05/16   Julian Gates    SIR4132 - Validate ProductName and ProductShortName is unique in update mode
                        If Me.ProductName.Text <> "" Then
                            If Me.ProductName.Text = Me.uPage.db.DLookup("ProductName", "Product", "ProductName='" & Me.ProductName.Text & "' AND ProductCode <> '" & Me.ProductCode.Text & "'") Then
                                uPage.FieldErrorControl(Me.ProductName, "Entered Product Name already exists, please enter another.")
                            End If
                        End If
                        If Me.ProductShortName.Text <> "" Then
                            If Me.ProductShortName.Text = Me.uPage.db.DLookup("ProductShortName", "Product", "ProductShortName='" & Me.ProductShortName.Text & "' AND ProductCode <> '" & Me.ProductCode.Text & "'") Then
                                uPage.FieldErrorControl(Me.ProductShortName, "Entered Product Short Name already exists, please enter another.")
                            End If
                        End If
                End Select
                If Me.ProductName.Text = "" Then
                    uPage.FieldErrorControl(Me.ProductName, "Product Name is mandatory")
                End If
                If Me.ProductStatus.SelectedValue = "" Then
                    uPage.FieldErrorControl(Me.ProductStatus, "Product Status is mandatory")
                End If
                If Me.CompanyID.SelectedValue = "" Then
                    uPage.FieldErrorControl(Me.CompanyID, "Company ID is mandatory")
                End If
                If Me.ReleaseDate.Text = "" Then
                    uPage.PageError = "Please add an Release Date"
                End If
                If Me.ReleaseDate.Text <> "" Then
                    'uPage.FieldValidateDate(Me.ReleaseDate)
                End If
                '24/05/16   Julian Gates    SIR4132 - Validate ProductShortName as mandatory
                If Me.ProductShortName.Text = "" Then
                    uPage.FieldErrorControl(Me.ProductShortName, "Product Short Name is mandatory")
                End If
                If Me.RecurringSubscriptionUnits.Text <> "" Then
                    uPage.FieldValidateNumber(Me.RecurringSubscriptionUnits)
                End If
        End Select

        Return uPage.IsValid
    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Try

            Dim sql As String = ""

            Me.uPage.PopulateDropDownListFromLookup(Me.ProductStatus, "ProductStatus", uPage.PrimaryConnection, "<--Select-->")
            uPage.PopulateDropDownListFromSQL(Me.CompanyID, "SELECT DISTINCT Company.CompanyId as Value" _
                                                                   & "    , Company.CompanyName as Text" _
                                                                   & " FROM " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                                                                   & " ORDER BY 2" _
                                                                  , uPage.PrimaryConnection, "<--Select-->"
                                                                  )
            sql = "SELECT ProductCode as Value"
            sql += "    ,ProductCode as Text"
            sql += " FROM Product "
            sql += "    INNER JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId)
            sql += "    ON Company.CompanyId = Product.CompanyId"
            sql += " WHERE ISNULL(IsParent,0) <> 0 "
            sql += " ORDER BY ProductCode , ProductName"
            Me.uPage.PopulateDropDownListFromSQL(Me.AssociatedProductCode, sql, uPage.PrimaryConnection, "<--Select-->")
            Me.uPage.PopulateDropDownListFromLookup(Me.CheckAgainstOrderType, "CheckOrderType", uPage.PrimaryConnection, "<--Select-->")
            Me.uPage.PopulateDropDownListFromLookup(Me.RecurringSubscriptionUnitType, "SubscriptionUnitType", uPage.PrimaryConnection, "<--Select-->")

            Select Case pageMode
                Case "Update"
                    Me.uPage.PopulatePageFieldsFromDataRow(Me.Product.ProductRow)
                    If Not Me.Product.ProductRow("ReleaseDate") Is System.DBNull.Value Then
                        Me.ReleaseDate.Text = CDate(Me.Product.ProductRow("ReleaseDate"))
                    End If
            End Select
        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Sub SaveRecord()
        '******************************************************
        'Description:	Save the record either by updating or adding
        '******************************************************
        Try

            Me.uPage.PopulateDataRowFromPageFields(Me.Product.ProductRow)
            If Me.RecurringSubscriptionFieldsTable.Visible = False Then
                'Clear out RecurringSubscriptionFields values if fields hidden
                Me.Product.ProductRow("RecurringSubscriptionUnitType") = System.DBNull.Value
                Me.Product.ProductRow("RecurringSubscriptionUnits") = System.DBNull.Value
                Me.Product.ProductRow("DisableAutoRenewalFlag") = System.DBNull.Value
            End If
            Me.Product.ProductRow("LastUpdatedDateTime") = Now()
            Me.Product.ProductRow("LastUpdatedByUserId") = uPage.UserSession.UserName20
            Me.Product.ProductRow("ReleaseDate") = Me.ReleaseDate.Text
            Me.Product.Save()

        Catch e As Exception
            uPage.PageError = e.ToString
        End Try
        If Me.uPage.IsValid Then
            Me.uPage.InfoMessage = "This record has been saved"
            Response.Redirect(Request.ServerVariables("Path_Info") & "?ProductCode=" & Me.ProductCode.Text & "&InfoMsg=This record has been saved&" & uPage.UserSession.QueryString)
        End If
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.Product.MainDataset
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                Select Case pageMode
                    Case "Update"
                        SaveRecord()
                    Case "Add"
                        Me.Product.AddNewProduct(Me.ProductCode.Text,
                                                 Me.ProductName.Text,
                                                 Me.ProductStatus.SelectedValue,
                                                 Me.CompanyID.SelectedValue,
                                                 Me.Notes.Text,
                                                 Me.ShippedProductFlag.Checked,
                                                 Me.TermsAndConditionsFileName.Text,
                                                 Me.ProductGroupingName.Text,
                                                 Me.ProductShortName.Text,
                                                 CDate(Me.ReleaseDate.Text),
                                                 Me.AssociatedProductCode.SelectedValue,
                                                 Me.RecurringSubscriptionFlag.Checked,
                                                 Me.RecurringSubscriptionUnitType.SelectedValue,
                                                 Me.RecurringSubscriptionUnits.Text,
                                                 Me.SellOnWebFlag.Checked,
                                                 Me.OnePerSubscriberFlag.Checked,
                                                 Me.CheckAgainstOrderType.SelectedValue
                                                   )
                End Select

            Catch ex As Exception
                uPage.PageError = ex.ToString
            End Try

            Select Case pageMode
                Case "Add"
                    If Me.uPage.IsValid Then
                        Response.Redirect(Request.ServerVariables("Path_Info") & "?ProductCode=" & Me.Product.ProductCode & "&InfoMsg=New Product has been saved&" & uPage.UserSession.QueryString)
                    End If
            End Select
        End If
    End Sub

    Private Sub BackBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        Response.Redirect("../Pages/pg503ProductSelect.aspx?" & uPage.UserSession.QueryString)
    End Sub


    Sub ChildProductsGridView_ParseValue(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxParseValueEventArgs) Handles ChildProductsGridView.ParseValue
        Select Case e.FieldName
            Case "ReportProportion"
                If e.Value <> Nothing Then
                    If Not IsNumeric(e.Value) Then
                    Else
                        e.Value = Convert.ToDecimal(e.Value)
                    End If
                End If
        End Select
    End Sub

    Protected Sub ChildProductsGridView__ItemUpdating(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataUpdatingEventArgs) Handles ChildProductsGridView.RowUpdating
        '18/05/16   Julian Gates    SIR4130 - Change Child Product add to update CompanyId with Product parent CompanyId
        e.NewValues("CompanyID") = Me.CompanyID.SelectedValue
        e.NewValues("IsCarriageCharge") = False
        e.NewValues("IsParent") = False
        e.NewValues("LastUpdatedDateTime") = DateTime.Now()
        e.NewValues("LastUpdatedByUserId") = uPage.UserSession.UserName20
        If e.NewValues("IsForReporting") Is Nothing Then
            e.NewValues("IsForReporting") = False
        End If
    End Sub

    Protected Sub ChildProductsGridView__ItemInserting(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInsertingEventArgs) Handles ChildProductsGridView.RowInserting
        e.NewValues("IsCarriageCharge") = False
        e.NewValues("IsParent") = False
        e.NewValues("CreatedDateTime") = DateTime.Now()
        e.NewValues("CreatedByUserId") = uPage.UserSession.UserName20
        e.NewValues("IsCarriageCharge") = False
        If e.NewValues("IsForReporting") Is Nothing Then
            e.NewValues("IsForReporting") = False
        End If
    End Sub

    Protected Sub ChildProductsGridView_RowValidating(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataValidationEventArgs)
        If e.NewValues("ProductCode") Is Nothing Then
            AddError(e.Errors, ChildProductsGridView.Columns("ProductCode"), "Please enter a Product Code.")
        End If
        If (ChildProductsGridView.IsNewRowEditing) Then
            If e.NewValues("ProductCode") <> Nothing Then
                If e.NewValues("ProductCode") = Me.uPage.db.DLookup("ProductCode", "Product", "ProductCode = '" & e.NewValues("ProductCode") & "'") Then
                    AddError(e.Errors, ChildProductsGridView.Columns("ProductCode"), "Entered Product Code already exists, please enter another.")
                End If
            End If
        End If
        If e.NewValues("ProductShortName") Is Nothing Then
            AddError(e.Errors, ChildProductsGridView.Columns("ProductShortName"), "Please enter a Product Short Name value.")
        End If
        If (Not ChildProductsGridView.IsNewRowEditing) Then
            If e.NewValues("ProductShortName") <> Nothing Then
                If e.NewValues("ProductShortName") = Me.uPage.db.DLookup("ProductShortName", "Product", "ProductShortName = '" & e.NewValues("ProductShortName") & "'  AND ProductCode <> '" & e.NewValues("ProductCode") & "'") Then
                    AddError(e.Errors, ChildProductsGridView.Columns("ProductShortName"), "Entered Product Short Name already exists, please enter another.")
                End If
            End If
        End If
        If (ChildProductsGridView.IsNewRowEditing) Then
            If e.NewValues("ProductShortName") <> Nothing Then
                If e.NewValues("ProductShortName") = Me.uPage.db.DLookup("ProductShortName", "Product", "ProductShortName = '" & e.NewValues("ProductShortName") & "'") Then
                    AddError(e.Errors, ChildProductsGridView.Columns("ProductShortName"), "Entered Product Short Name already exists, please enter another.")
                End If
            End If
        End If

        If e.NewValues("ProductName") Is Nothing Then
            AddError(e.Errors, ChildProductsGridView.Columns("ProductName"), "Please enter a Product Name value.")
        End If
        If (Not ChildProductsGridView.IsNewRowEditing) Then
            If e.NewValues("ProductName") <> Nothing Then
                If e.NewValues("ProductName") = Me.uPage.db.DLookup("ProductName", "Product", "ProductName = '" & e.NewValues("ProductName") & "'  AND ProductCode <> '" & e.NewValues("ProductCode") & "'") Then
                    AddError(e.Errors, ChildProductsGridView.Columns("ProductName"), "Entered Product Name already exists, please enter another.")
                End If
            End If
        End If
        If (ChildProductsGridView.IsNewRowEditing) Then
            If e.NewValues("ProductName") <> Nothing Then
                If e.NewValues("ProductName") = Me.uPage.db.DLookup("ProductName", "Product", "ProductName = '" & e.NewValues("ProductName") & "'") Then
                    AddError(e.Errors, ChildProductsGridView.Columns("ProductName"), "Entered Product Name already exists, please enter another.")
                End If
            End If
        End If

        If e.NewValues("ReleaseDate") Is Nothing Then
            AddError(e.Errors, ChildProductsGridView.Columns("ReleaseDate"), "Please select a Release Date value.")
        End If

        If e.NewValues("ReportProportion") <> Nothing Then
            If Not IsNumeric(e.NewValues("ReportProportion")) Then
                AddError(e.Errors, ChildProductsGridView.Columns("ReportProportion"), "Report Proportion must be a numerical value.")
            End If
        End If

        uPage.PageError = e.RowError
    End Sub

    Protected Sub ChildProductsGridView_StartRowEditing(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxStartRowEditingEventArgs) Handles ChildProductsGridView.StartRowEditing
        Dim text As GridViewDataTextColumn = TryCast(ChildProductsGridView.Columns("ProductCode"), GridViewDataTextColumn)
        text.ReadOnly = True
    End Sub

    Private Sub AddError(ByVal errors As Dictionary(Of GridViewColumn, String), ByVal column As GridViewColumn, ByVal errorText As String)
        If errors.ContainsKey(column) Then
            Return
        End If
        errors(column) = errorText
    End Sub
End Class
