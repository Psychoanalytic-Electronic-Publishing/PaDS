﻿Imports System.Data
Imports System.Data.SqlClient
Imports AjaxControlToolkit.ToolkitScriptManager

'Modification History
'19/01/11  Julian Gates   Initial version
'21/6/11   Julian Gates   Modification: Save entered passwords in viewstate to repopulate field if error.
'21/6/11   Julian Gates   Modification: Add animation and hide save button to stop duplicate subscribers being added.
'05/3/12   Julian Gates   Removed Ajax roundpanels
'03/10/14   Julian Gates    SIR3621 - Add IsReceiveMail to  Subscriber.Add
'31/07/15   Julian Gates    SIR3898 - Remove mandatory validation from Non Us & Canada State field.
'16/10/15   Julian Gates    SIR3982 - Change www.p-e-p.org links to support.pep-web.org
'23/11/15   Julian Gates    SIR4016 - Add Triggers to Update panel on aspx page to get MaintainSchrollPosition working
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields
'29/10/19   Julian Gates    SIR4763 - Remove WebUserName, WebUserPassword and email confirmation fields.
'29/10/19   Julian Gates    SIR4763 - Remove VAT Number field.
'10/1/20    James Woosnam   SIR4984 - If passed in AffiliateToSubscriberId then affiliate to sub
'13/1/20    James Woosnam   SIR4977 - Update duplicate checking
'17/02/20   Julian Gates    SIR5020 - Change Duplicate Email Info Message text and move below Email Address field and move page error message into page.
'03/03/20   Julian Gates    Convert page to be English and Spanish
'7/1/21     Julian Gates    SIR5143 - Rework page to allow Basic User entry.
'12/02/21   Julian Gates    SIR5193 - Set field focus to correct field after Email check

Partial Class Pages_pg117AddNewSubscriber
    Inherits System.Web.UI.Page
    '******* This page is designed to work with one Company *****************
    Dim CompanyId As Integer = 2
    Public ErrorMessage As String = ""

    Dim StdCode As New BusinessLogic.StdCode()
    '10/1/20    James Woosnam   SIR4984 - If passed in AffiliateToSubscriberId then affiliate to sub
    Dim _AffiliateToSubscriber As BusinessLogic.Subscriber = Nothing
    ReadOnly Property AffiliateToSubscriber As BusinessLogic.Subscriber
        Get
            If _AffiliateToSubscriber Is Nothing Then
                If ViewState("AffiliateToSubscriberId") IsNot Nothing Then
                    _AffiliateToSubscriber = New BusinessLogic.Subscriber(ViewState("AffiliateToSubscriberId"), Master.db, Master.UserSession)
                End If
            End If
            Return _AffiliateToSubscriber
        End Get
    End Property

    Public Property DisplayLanguage As BusinessLogic.UserSession.DisplayLanguages
        Get
            Return Me.Master.UserSession.DisplayLanguage
        End Get
        Set(value As BusinessLogic.UserSession.DisplayLanguages)
            Me.Master.UserSession.DisplayLanguage = value
        End Set
    End Property
    Enum PageModes
        FullDetails
        BasicDetails
    End Enum
    ReadOnly Property PageMode As PageModes
        Get
            Return ViewState("PageMode")
        End Get
    End Property
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim langDis As BusinessLogic.UserSession.DisplayLanguages = Me.Master.DisplayLanguageRBLSelectedValue
        If Not IsPostBack And IsNumeric(Request.QueryString("DisplayLanguage")) Then
            langDis = Request.QueryString("DisplayLanguage")
        End If
        'Must reset cookie when opening 
        Dim ResetSessionCookieIfNotPostback As Boolean = Not Me.IsPostBack Or Request.QueryString("UserSessionId") = "" 'if a sess is passed then needed 
        Master.Initilise("New User Registration", "00", "", "", "", ResetSessionCookieIfNotPostback)
        Master.UserSession.DisplayLanguage = langDis
        Master.ShowLanguageRBL = True

        If Request.QueryString("PageMode") <> "" Then
            ViewState("PageMode") = [Enum].Parse(GetType(PageModes), Request.QueryString("PageMode"))
        Else
            ViewState("PageMode") = PageModes.FullDetails
        End If
        If Page.IsPostBack Then
            'Me.Subscriber.MainDataset = CType(ViewState("MainDataSet"), DataSet)
        Else
            If Me.Master.WebForm.IsValid Then
                ReadRecord()
            End If
            Select Case Me.PageMode
                Case PageModes.BasicDetails
                    'For now basic details is always when called from PEP so add setting to session to use after password set up
                    Master.UserSession.Data("AfterPasswordSetupReturnToPep") = True

            End Select
            '10/1/20    James Woosnam   SIR4984 - If passed in AffiliateToSubscriberId then affiliate to sub
            If IsNumeric(Request.QueryString("AffiliateToSubscriberId")) Then
                ViewState("AffiliateToSubscriberId") = Request.QueryString("AffiliateToSubscriberId")
                Try
                    If Me.AffiliateToSubscriber.SubscriberRow("EntityType") <> "Organisation" Then
                        Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "AffiliateToSubscriberId error. New subscribers can only be added to Organisations" _
                               , "AffiliateToSubscriberId error. Los nuevos suscriptores solo se pueden agregar a organizaciones"))
                    End If
                Catch ex As Exception
                    Me.Master.WebForm.AddPageError("AffiliateToSubscriberId error. " & ex.Message)
                    _AffiliateToSubscriber = Nothing
                End Try

            Else

            End If
            Me.EmailMain.Focus()
        End If

        'Used to display animation when processing credit card and hide confirm button
        Me.progressImage.Style.Add("display", "none")
        SaveBtn.OnClientClick = "document.getElementById('" + progressImage.ClientID + "').style.display = ''; document.getElementById('" + SaveBtn.ClientID + "').style.display = 'none';"

    End Sub

    Sub PageSetup()
        'Hide show page elements based on PageMode of BasicDetails or FullDetails
        Select Case Me.PageMode
            Case PageModes.BasicDetails
                Me.Master.PageTitle = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "New Basic User Registration" _
                               , "Registro básico de nuevo usuarios")

                Me.BasicEnglishHeaderText.Visible = Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English
                Me.BasicSpanishHeaderText.Visible = Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.Spanish

            Case PageModes.FullDetails
                Me.Master.PageTitle = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "New User Registration" _
                               , "Registro de nuevo usuario")

                Me.EnglishHeaderText.Visible = Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English
                Me.SpanishHeaderText.Visible = Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.Spanish
        End Select

        'Hide show page elements based if FullDetails
        Me.TitleRow.Visible = Me.PageMode = PageModes.FullDetails
        Me.AddressFields.Visible = Me.PageMode = PageModes.FullDetails
        Me.CandidateRow.Visible = Me.PageMode = PageModes.FullDetails
        Me.CandidateCheckBoxRow.Visible = Me.PageMode = PageModes.FullDetails

        Me.SaveBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Save", "Guarda")
        Me.SaveBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Save your details", "Guarda")



        If Me.AffiliateToSubscriber IsNot Nothing Then
            Me.AffiliateToSubscriberLbl.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                   , "As part of this registration you will be automatically affiliated to " _
                                                   , "Como parte de su registración usted será automáticamente asociado a ") & "'" & Me.AffiliateToSubscriber.SubscriberName & "'."
            IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                   , " This will allow you To receive any discounted rates allocated To this group." _
                                                   , " Esto le permitirá recibir cualquier descuento otorgado a esta asociación.")
            Me.AffiliateToSubscriberLbl.Visible = True
        End If

        Me.ResendLogonDetails.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Send", "Enviar")

        '17/02/20   Julian Gates    SIR5020 -  Show ErrorMessage in the page and not in header
        Me.ErrorMessage = Master.OutputErrorMessage()
        Me.pnlError.Visible = True
        Me.pnlError.Update()
    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else

                Me.Master.WebForm.FieldValidateMandatory(Me.EmailMain, "Email Address", "Es obligación escribir un correo electrónico")
                If Me.EmailMain.Text <> "" Then
                    CheckEmail()
                End If
                Select Case Me.PageMode
                    Case PageModes.FullDetails
                        Me.Master.WebForm.DropDownValidateMandatory(Me.Title, "", "Es obligación escribir un título")
                End Select
                Me.Master.WebForm.FieldValidateMandatory(Me.FirstName, "First Name", "Es obligación escribir su Nombre")
                Me.Master.WebForm.FieldValidateMandatory(Me.LastName, "Last Name", "Es obligación escribir su Apellido")
                Select Case Me.PageMode
                    Case PageModes.FullDetails
                        Me.Master.WebForm.FieldValidateMandatory(Me.BillingAddress, "Billing Address", "Es obligación escribir una Dirección de Facturación")
                        Me.Master.WebForm.FieldValidateMandatory(Me.Town, "City", "Es obligación escribir su Ciudad")
                        '31/07/15   Julian Gates    SIR3898 - Remove mandatory validation from Non Us & Canada State field.
                        If Me.Master.db.IsDBNull(Me.CountryId.SelectedValue, "") = "11" Or Me.Master.db.IsDBNull(Me.CountryId.SelectedValue, "") = "56" Then 'US or Canada
                            Me.Master.WebForm.DropDownValidateMandatory(Me.CountyUS, "State (US Or Canada)", "Estado (US Or Canada)")
                        End If
                        Me.Master.WebForm.FieldValidateMandatory(Me.PostCode, "Zip Or Postal Code", "Es obligación escribir su Código Postal o Zip")
                End Select
                Me.Master.WebForm.DropDownValidateMandatory(Me.CountryId, "Country", "Es obligación escribir su País")
                If Not Me.GDPRAgreement.Checked Then
                    Master.WebForm.FieldErrorControl(Me.GDPRAgreement, "Please tick to confirm you agree with PEP retaining your details")
                End If
        End Select

        Return Me.Master.WebForm.IsValid
    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        'populate dropdowns
        Select Case Me.PageMode
            Case PageModes.FullDetails
                Me.Master.WebForm.PopulateDropDownListFromLookup(Me.Title, "Title", "<--Select-->")
                Me.Master.WebForm.PopulateDropDownListFromLookup(Me.CountyUS, "US_CanadaStateCode", "<--Select-->")
        End Select
        Me.Master.WebForm.PopulateDropDownListFromSQL(Me.CountryId, "Select Country.CountryId As Value" _
                                                                            & "     , Country.CountryName As Text" _
                                                                            & " FROM Country" _
                                                                            & " ORDER BY Country.CountryName" _
                                                                         , "<--Select-->")

    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        '  ViewState("MainDataSet") = Me.Subscriber.MainDataset
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    '03/10/14   Julian Gates    SIR3621 - Add IsReceiveMail to  Subscriber.Add
    '16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields
    '29/10/19   Julian Gates    SIR4768 - Remove VAT Number field.
    '07.01/21   Julian Gates    SIR5143 - Only pass Title if PageModes.FullDetails

    Protected Sub SaveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                Master.db.BeginTran()
                Try
                    Me.Master.UserSession.Data("UserName") = Me.EmailMain.Text 'set here so can be used in audit log
                    Dim Subscriber As New BusinessLogic.Subscriber(Me.Master.db, Me.Master.UserSession)
                    Subscriber.Add(Me.EmailMain.Text _
                                      , IIf(Me.PageMode = PageModes.FullDetails, Me.Title.SelectedValue, "") _
                                      , Me.FirstName.Text _
                                      , Me.LastName.Text _
                                      , Me.BillingAddress.Text _
                                      , Me.Town.Text _
                                      , Me.County.Text _
                                      , Me.CountyUS.SelectedValue _
                                      , Me.PostCode.Text _
                                      , Me.CountryId.SelectedValue _
                                      , Me.CandidateStudent.Checked _
                                      , Me.CompanyId _
                                      , True _
                                      , IIf(Me.PageMode = PageModes.FullDetails, True, False))
                    Select Case Me.PageMode
                        Case PageModes.FullDetails
                            Subscriber.AddCompanyAccount(Me.CompanyId, "Individual", 4, "Full", Subscriber.SubscriberRow("DefaultPostalAddressId"))
                            '10/1/20    James Woosnam   SIR4984 - If passed in AffiliateToSubscriberId then affiliate to sub
                            If Me.AffiliateToSubscriber IsNot Nothing Then
                                Subscriber.AddSubscriberAffiliate(Me.AffiliateToSubscriber.SubscriberId)
                            End If
                        Case PageModes.BasicDetails

                            If Master.UserSession.LoggedIn Then
                                Select Case Master.UserSession.AuthorityLevel
                                    Case BusinessLogic.UserSession.AuthorityLevels.GroupUser
                                        Select Case Master.UserSession.LoggedInMethod
                                            Case BusinessLogic.UserSession.LoggedInMethods.IPAddress, BusinessLogic.UserSession.LoggedInMethods.ReferrerURL
                                                Subscriber.AddSubscriberAffiliate(Master.UserSession.Data("SubscriberId"))
                                            Case BusinessLogic.UserSession.LoggedInMethods.Federated
                                                Subscriber.AddSubscriberAffiliate(Master.UserSession.Data("SubscriberId"))
                                                'Before updating the loggedInMethod Call UpdateFederatedPersonIdFromSession which will update when available and required
                                                Subscriber.RemoteUser.UpdateFederatedPersonIdFromSession()
                                        End Select

                                End Select

                            End If
                    End Select
                    Master.db.CommitTran()
                Catch ex As Exception
                    Master.db.RollbackTran()
                    Throw ex
                End Try

            Catch ex As Exception
                Me.Master.WebForm.AddPageError(ex)
            End Try

            ' Show message to say user set up and emails confirmation and password set up emails sent 
            If Me.Master.WebForm.IsValid Then
                Me.MainContentTable.Visible = False
                Me.EmailSentMessageTable.Visible = True
            Else
                Me.EmailSentMessageTable.Visible = False
                Me.MainContentTable.Visible = True
            End If
        End If
    End Sub



    Protected Sub EmailMain_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles EmailMain.TextChanged
        CheckEmail()
    End Sub
    ReadOnly Property tUser As DataTable
        Get
            '13/1/20    James Woosnam   SIR4977 - Update duplicate checking

            Dim sql As String = ""
            sql = "Select ru.EmailAddress"
            sql += " , SubscriberId = rur.RightsToId"
            sql += " , ru.UserStatus"
            sql += " FROM RemoteUser ru"
            sql += "    LEFT JOIN RemoteUserRights rur"
            sql += "    On rur.userid = ru.UserId"
            sql += " WHERE EmailAddress=@EmailAddress"
            sql += " And ru.UserStatus <> 'InActive'"
            Dim cmd As New SqlCommand(sql, Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailAddress", System.Data.SqlDbType.VarChar, 255, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                     , Me.EmailMain.Text))
            Return Me.Master.db.GetDataTableFromSQL(cmd)
        End Get
    End Property
    Protected Sub CheckEmail()
        If Me.EmailMain.Text <> "" Then
            If Not Me.StdCode.IsValidEmail(Me.EmailMain.Text) Then
                Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Email Address is syntactically invalid", "Esta dirección de correo electrónico parece estar mal escrita"))
                Me.EmailMain.Focus()
                Me.EmailMain.CssClass = "fldEntryError"
            Else
                Me.EmailMain.CssClass = "fldEntry"
                '12/02/21   Julian Gates    SIR5193 - Set field focus to correct field after Email check
                Select Case Me.tUser.Rows.Count
                    Case 0
                        Me.SaveBtn.Visible = True
                        Me.ResendLogonDetailsRow.Visible = False
                        Me.DuplicateEmailInfoMessageRow.Visible = False
                        Select Case Me.PageMode
                            Case PageModes.FullDetails
                                Me.Title.Focus()
                            Case PageModes.BasicDetails
                                Me.FirstName.Focus()
                        End Select
                    Case 1
                        If tUser.Rows(0)("UserStatus") = "Pending" Then
                            Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Email address: ", "Correo electrónico: ") & Me.EmailMain.Text &
                                                           IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, " is already used on a Pending user. Please contact PaDS support ", " ya está en uso en un Usuario pendiente. Por favor contacte al soporte de PaDS ") & Me.Master.db.SupportEmailLink)
                            Me.SaveBtn.Visible = False
                            Me.ResendLogonDetailsRow.Visible = False
                            Me.DuplicateEmailInfoMessageRow.Visible = False
                            Select Case Me.PageMode
                                Case PageModes.FullDetails
                                    Me.Title.Focus()
                                Case PageModes.BasicDetails
                                    Me.FirstName.Focus()
                            End Select
                        Else
                            '17/02/20   Julian Gates    SIR5020 - Change Duplicate Email Info Message text and move below Email Address field
                            Me.DuplicateEmailAddressText.Text = Me.EmailMain.Text
                            Me.SaveBtn.Visible = False
                            Me.ResendLogonDetailsRow.Visible = True
                            Me.DuplicateEmailInfoMessageRow.Visible = True
                            Me.ResendLogonDetailsRow.Focus()
                        End If

                    Case 2
                        Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Email address: ", "Correo electrónico: ") & Me.EmailMain.Text &
                                                           IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, " is already in use multiple times on PaDS. Please contact PaDS support ", " ya está en uso en muchas ocasiones en PaDS. Por favor contacte al soporte de PaDS ") & Me.Master.db.SupportEmailLink)
                        Me.SaveBtn.Visible = False
                        Me.ResendLogonDetailsRow.Visible = False
                        Me.DuplicateEmailInfoMessageRow.Visible = False
                        Select Case Me.PageMode
                            Case PageModes.FullDetails
                                Me.Title.Focus()
                            Case PageModes.BasicDetails
                                Me.FirstName.Focus()
                        End Select
                End Select
            End If
        End If
    End Sub


    Protected Sub ResendLogonDetails_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ResendLogonDetails.Click
        Try
            Dim UserName As String = Master.db.DLookup("UserName", "RemoteUser", "UserStatus IN ('Active','Emailed') AND EmailAddress='" & Me.EmailMain.Text & "'", True)
            If UserName = Nothing Then
                Throw New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Email address not linked to a User record.", "Este correo electrónico no está vinculado a nuestros registros de usuarios."))
            End If
            Dim ru As New BusinessLogic.RemoteUser(UserName, Master.db, Master.UserSession)
            ru.ResetPasswordAndEmail()
            If Me.AffiliateToSubscriber IsNot Nothing Then
                Select Case tUser.Rows.Count
                    Case 1
                        Dim subscriber As New BusinessLogic.Subscriber(tUser.Rows(0)("SubscriberId"), Master.db, Master.UserSession)
                        subscriber.AddSubscriberAffiliate(Me.AffiliateToSubscriber.SubscriberId)
                End Select
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(ex)
        End Try

        If Master.WebForm.IsValid Then
            Me.MainContentTable.Visible = False
            Me.ResendEmailSentMessageTable.Visible = True
        Else
            Me.MainContentTable.Visible = True
            Me.ResendEmailSentMessageTable.Visible = False
            'Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=" & IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "A password reset email has been sent. Please check your email.", "Un correo electrónico de reseteo de su contraseña ha sido enviado. Por favor revise su correo."))
        End If
    End Sub

    '17/02/20   Julian Gates    SIR5020 - Click Here link to run code below if AffiliateToSubscriber
    Private Sub ClickHereLinkBtn_Click(sender As Object, e As EventArgs) Handles ClickHereLinkBtn.Click
        Try
            If Me.AffiliateToSubscriber IsNot Nothing Then
                Select Case tUser.Rows.Count
                    Case 1
                        Dim subscriber As New BusinessLogic.Subscriber(tUser.Rows(0)("SubscriberId"), Master.db, Master.UserSession)
                        subscriber.AddSubscriberAffiliate(Me.AffiliateToSubscriber.SubscriberId)
                End Select
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(ex)
        End Try
        If Master.WebForm.IsValid Then
            Response.Redirect("../pages/pg070Logon.aspx?" & Me.Master.UserSession.QueryString)
        End If
    End Sub
End Class
