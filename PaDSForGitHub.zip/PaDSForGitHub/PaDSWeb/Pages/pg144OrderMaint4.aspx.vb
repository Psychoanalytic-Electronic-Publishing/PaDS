﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'18/09/19  Julian Gates   Initial New version
'25/11/19   James Woosnam   Set OrderDate and CancelledDate to whole dates rather than date time
'12/11/20   Julian Gates    SIR5148 - Make Primary Product and Subscriber Id links to Maint Pages.

Partial Class Pages_pg144OrderMaint4
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim pageMode As String = ""

    Private _SalesOrder As BusinessLogic.SalesOrder = Nothing
    Public Property SalesOrder() As BusinessLogic.SalesOrder
        Get
            If Me._SalesOrder Is Nothing Then
                Me._SalesOrder = New BusinessLogic.SalesOrder(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._SalesOrder
        End Get
        Set(ByVal value As BusinessLogic.SalesOrder)
            Me._SalesOrder = value
        End Set
    End Property

    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                Me._Subscriber = New BusinessLogic.Subscriber(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Order Summary", "")
        Me.pageHeaderTitle.Text = "Order Summary"

        If Request.QueryString("OrderNumber") <> "" Then
            pageMode = "Update"
        End If

        If Request.QueryString("OrderNumber") <> "" Then
            Try
                Me.txtOrderNumber.Value = Request.QueryString("OrderNumber")
                Me.SalesOrder = New BusinessLogic.SalesOrder(CInt(Request.QueryString("OrderNumber")), Me.uPage.db, Me.uPage.UserSession)
                Me.Subscriber = New BusinessLogic.Subscriber(CInt(Me.SalesOrder.SalesOrderRow.Item("SubscriberId")), Me.uPage.db, Me.uPage.UserSession)
            Catch ex As Exception
                Me.uPage.PageError = "Invalid Parameter has been passed in"
            End Try
            pageMode = "Update"

        End If
        If Page.IsPostBack Then

        Else
            If Me.uPage.IsValid Then
                ReadRecord()
            End If

            If Me.AmountCarriage.Visible Then
                Me.AmountCarriage.Focus()
            End If
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        Me.RejectBtn.Attributes.Add("onclick", "if(confirm('Are you sure you want to reject this order?')){}else{return false}")
        Me.ConfirmBtn.Attributes.Add("onclick", "if(confirm('Are you sure you want to confirm this order?')){}else{return false}")
        Me.CancelBtn.Attributes.Add("onclick", "if(confirm('Are you sure you want to cancel this order?')){}else{return false}")

    End Sub

    Sub PageSetup()
        Select Case pageMode
            Case "Add"
            Case "Update"
                '05/02/2020 Julian Gates    SIR5007 - Change Subscriber, Order and Cashbook select page links.
                Me.CashbookLink.NavigateUrl = "../pages/pg150CashbookSelect.aspx?" _
                                           & "FilterSubscriberId=" & Me.Subscriber.SubscriberRow("SubscriberId") _
                                           & "&CompanyId=" & Me.SalesOrder.SalesOrderRow.Item("CompanyId") _
                                           & "&" & uPage.UserSession.QueryString
                '12/11/20   Julian Gates    SIR5148 - Make Subscriber Id a link to Subscriber Display
                Me.SubscriberId.NavigateUrl = "../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & Me.Subscriber.SubscriberId & "&" & uPage.UserSession.QueryString
                '12/11/20   Julian Gates    SIR5148 - Make Primary Product a link to Product Maint
                Me.PrimaryProductCode.NavigateUrl = "../pages/pg504ProductMaint.aspx?PageMode=Update&ProductCode=" & Me.SalesOrder.SalesOrderRow("PrimaryProductCode") & "&" & uPage.UserSession.QueryString


                Select Case Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")
                    Case "Complete", "Confirmed"
                        If uPage.db.IsDBNull(uPage.StdCode.DLookup("RequireInvoice", "CompanyAccount", "CompanyAccount.CompanyId=" & Me.SalesOrder.SalesOrderRow.Item("CompanyId") & " AND CompanyAccount.SubscriberId =" & Me.SalesOrder.SalesOrderRow.Item("SubscriberId"), uPage.PrimaryConnection), False) = True Then
                            Me.RequestInvoiceTextTR.Visible = True
                        Else
                            Me.RequestInvoiceTextTR.Visible = False
                        End If
                        Me.SummaryInvoiceLink.Visible = True
                        Me.SummaryInvoiceLink.Target = "_blank"
                        Me.SummaryInvoiceLink.NavigateUrl = "../Pages/pg450Reports.aspx?" _
                                                             & "RunSpecificReportName=Invoice" _
                                                             & "&ReportCriteria=OrderNumber=" & Me.SalesOrder.SalesOrderRow.Item("OrderNumber") _
                                                             & "&" & uPage.UserSession.QueryString

                        Me.DetailedInvoiceLink.Visible = True
                        Me.DetailedInvoiceLink.Target = "_blank"
                        Me.DetailedInvoiceLink.NavigateUrl = "../Pages/pg450Reports.aspx?" _
                                                            & "RunSpecificReportName=InvoiceDetail" _
                                                            & "&ReportCriteria=OrderNumber=" & Me.SalesOrder.SalesOrderRow.Item("OrderNumber") _
                                                            & "&" & uPage.UserSession.QueryString
                        Me.AmountCarriagePrompt.Visible = False
                        Me.AmountCarriage.Visible = False
                        Me.PercentVAT.Visible = False
                        Me.EnterVATLabel.Visible = False
                End Select

                Select Case Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")
                    Case "Partial", "Pending", "RemotePartial"
                        Me.SaveBtn.Visible = True
                        Select Case Me.uPage.UserSession.AuthorityLevel
                            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                                Me.RejectBtn.Visible = True
                                Me.ConfirmBtn.Visible = True
                            Case Else
                                Me.RejectBtn.Visible = False
                                Me.ConfirmBtn.Visible = False
                        End Select
                        Me.AmountCarriagePrompt.Visible = True
                        Me.AmountCarriage.Visible = True
                        Me.AmountCarriageRO.Visible = False
                        Me.PercentVAT.Visible = True
                        Me.EnterVATLabel.Visible = True
                        Me.PercentVATRO.Visible = False
                        Me.RequestInvoiceTextTR.Visible = False
                    Case "Confirmed"
                        Select Case Me.uPage.UserSession.AuthorityLevel
                            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                                Me.CancelBtn.Visible = True
                                If uPage.db.IsDBNull(uPage.StdCode.DLookup("CashbookId", "Cashbook", "OrderNumber=" & Me.SalesOrder.SalesOrderRow.Item("OrderNumber"), uPage.PrimaryConnection), Nothing) = Nothing Then
                                    Me.PaymentBtn.Visible = True
                                Else
                                    '05/02/2020 Julian Gates    SIR5007 - Change Subscriber, Order and Cashbook select page links.
                                    Me.CashbookListLink.Visible = True
                                    Me.CashbookListLink.NavigateUrl = "../Pages/pg150CashbookSelect.aspx?" _
                                                            & "FilterSubscriberId=" & Me.SalesOrder.SalesOrderRow.Item("SubscriberId") _
                                                            & "&CompanyId=" & Me.SalesOrder.SalesOrderRow.Item("CompanyId") _
                                                            & "&" & uPage.UserSession.QueryString
                                End If
                                '10/10/2019 Julian Gates    Change from ZeroVAt to AmountGross as hotfix
                                If uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("AmountGross"), 0) = 0 Then
                                    Me.SendEmailReceiptBtn.Visible = True
                                Else
                                    Me.SendEmailReceiptBtn.Visible = False
                                End If
                            Case Else
                                Me.CancelBtn.Visible = False
                        End Select
                    Case "Complete"
                        Select Case Me.uPage.UserSession.AuthorityLevel
                            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                                Me.CancelBtn.Visible = True
                            Case Else
                                Me.CancelBtn.Visible = False
                        End Select
                    Case "Cancelled", "Rejected"
                        Me.AmountCarriagePrompt.Visible = False
                        Me.AmountCarriage.Visible = False
                        Me.AmountCarriageRO.Visible = True
                        Me.PercentVAT.Visible = False
                        Me.EnterVATLabel.Visible = False
                        Me.PercentVATRO.Visible = True
                        Me.RequestInvoiceTextTR.Visible = False
                End Select

                Me.PrevPageLink.NavigateUrl = "../pages/pg143OrderMaint3.aspx?OrderNumber=" & Me.SalesOrder.OrderNumber & "&" & uPage.UserSession.QueryString

                GetOrderSummaryHTML()
        End Select
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Try
            Select Case pageMode
                Case "Add"

                Case "Update"
                    'Read in subscriber details
                    Me.uPage.PopulatePageFieldsFromDataRow(Me.Subscriber.SubscriberRow)
                    'Read in Sales Order details
                    Me.uPage.PopulatePageFieldsFromDataRow(Me.SalesOrder.SalesOrderRow)
                    Me.AmountNet.Text = Format(uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("AmountNet"), 0), "0.00")
                    Me.AmountDiscount.Text = Format(uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("AmountDiscount"), 0), "0.00")
                    Me.AmountVAT.Text = Format(uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("AmountVAT"), 0), "0.00")
                    Me.AmountCarriageRO.Text = Format(uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("AmountCarriage"), 0), "0.00")
                    Me.AmountCarriage.Text = Format(uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("AmountCarriage"), 0), "0.00")
                    Me.PercentDiscount.Text = Format(uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("PercentDiscount"), 0), "P")
                    Me.PercentVATRO.Text = uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("PercentVAT"), 0)
                    Me.AmountGross.Text = Format(uPage.db.IsDBNull(Me.SalesOrder.SalesOrderRow.Item("AmountGross"), 0), "0.00")
                    Me.CompanyName.Text = uPage.db.IsDBNull(uPage.StdCode.DLookup("CompanyName", "Company", "CompanyId=" & Me.SalesOrder.SalesOrderRow.Item("CompanyId"), uPage.PrimaryConnection), "")
            End Select

        Catch ex As Exception
            Dim email As New BusinessLogic.Email(Me.uPage.db)
            email.SendErrorEmail("pg144OrderMaint4 Read Error", ex.ToString)
            Me.uPage.PageError = "Read Error.  Please contact Support:" & ex.Message
        End Try

    End Sub

    Sub SaveRecord(ByVal SaveType As String)
        '******************************************************
        'Description:	Save the record either by updating
        '******************************************************
        Try
            '25/11/19   James Woosnam   Set OrderDate and CancelledDate to whole dates rather than date time
            Select Case SaveType
                Case "Confirm"
                    Me.SalesOrder.SalesOrderRow("SalesOrderStatus") = "Confirmed"
                    Me.SalesOrder.SalesOrderRow("OrderDate") = System.DateTime.Now.Date
                    Me.SalesOrder.SalesOrderRow("AmountCarriage") = Me.AmountCarriage.Text
                    Me.SalesOrder.SalesOrderRow("PercentVAT") = Me.PercentVAT.Text
                Case "Cancel"
                    Me.SalesOrder.SalesOrderRow("SalesOrderStatus") = "Cancelled"
                    Me.SalesOrder.SalesOrderRow("CancelledDate") = System.DateTime.Now.Date
                Case "Complete"
                    Me.SalesOrder.SalesOrderRow("SalesOrderStatus") = "Complete"
                Case "Reject"
                    Me.SalesOrder.SalesOrderRow("SalesOrderStatus") = "Rejected"
                Case "Save"
                    'and only recalculate VAT rate when combo is showning.
                    Me.SalesOrder.SalesOrderRow("AmountCarriage") = Me.AmountCarriage.Text
                    Me.SalesOrder.SalesOrderRow("PercentVAT") = Me.PercentVAT.Text
            End Select

            Me.SalesOrder.Save()
        Catch ex As Exception
            Me.uPage.PageError = "Save Record failed " & ex.ToString
        End Try

        If Me.uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=This record has been saved&OrderNumber=" & Me.txtOrderNumber.Value & "&PageMode=Update&" & uPage.UserSession.QueryString)
        End If

    End Sub

    Protected Sub SaveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                SaveRecord("Save")
            Catch ex As Exception
                uPage.PageError = ex.ToString
            End Try
        End If
    End Sub

    Protected Sub RejectBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RejectBtn.Click
        If Me.IsPageValidForStatus("Reject") Then
            Try
                SaveRecord("Reject")
            Catch ex As Exception
                uPage.PageError = ex.ToString
            End Try
        End If
    End Sub

    Protected Sub ConfirmBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ConfirmBtn.Click
        If Me.IsPageValidForStatus("Confirm") Then
            Try
                SaveRecord("Confirm")
            Catch ex As Exception
                uPage.PageError = ex.ToString
            End Try
        End If
    End Sub

    Protected Sub CancelBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelBtn.Click
        If Me.IsPageValidForStatus("Cancel") Then
            Try
                SaveRecord("Cancel")
            Catch ex As Exception
                uPage.PageError = ex.ToString
            End Try
        End If
    End Sub

    Protected Sub PaymentBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles PaymentBtn.Click
        Response.Redirect("../Pages/pg151CashbookMaint.aspx?PageMode=Add" _
                            & "&OrderNumber=" & Me.SalesOrder.SalesOrderRow.Item("OrderNumber") _
                            & "&SubscriberId=" & Me.SalesOrder.SalesOrderRow.Item("SubscriberId") _
                            & "&CompanyId=" & Me.SalesOrder.SalesOrderRow.Item("CompanyId") _
                            & "&" & uPage.UserSession.QueryString)
    End Sub

    Protected Sub SendEmailReceiptBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SendEmailReceiptBtn.Click
        Try
            SalesOrder.SendEmailReceipt()
            InfoMsg.Text = "Email Receipt has been sucessfully sent for this order."
        Catch ex As Exception
            Me.uPage.PageError = "Email Receipt failed " & ex.ToString
        End Try
    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case "Confirm"
                Dim subCount As String = Nothing
                subCount = uPage.db.IsDBNull(uPage.StdCode.DLookup("Count(*)", "SalesOrderline", "OrderNumber=" & Me.SalesOrder.SalesOrderRow.Item("OrderNumber"), uPage.PrimaryConnection), 0)
                If subCount = 0 Then
                    uPage.PageError = "There are no subscribers selected to receive this order"
                End If
            Case "Cancel"
                If Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus") <> "Confirmed" _
                 And Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus") <> "Complete" Then
                    uPage.PageError = "Only confirmed or complete orders can be cancelled"
                End If
            Case "Complete"
                If Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus") <> "Confirmed" Then
                    uPage.PageError = "Only confirmed order can be completed"
                End If
            Case "Reject"
                Select Case Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")
                    Case "RemotePartial", "Pending", "Partial"
                    Case Else
                        uPage.PageError = "Only pending or partial orders can be rejected"
                End Select
            Case Else
                Select Case Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus")
                    Case "RemotePartial", "Pending", "Partial"
                        uPage.FieldValidateNumber(Me.AmountCarriage, True)
                        uPage.FieldValidateNumber(Me.PercentVAT, True)
                End Select

        End Select
        Return uPage.IsValid
    End Function

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub GetOrderSummaryHTML()

        Dim strSQL As String = ""
        Dim html As String = ""
        Dim quantityTotal As Integer = 0
        Dim amountTotal As Double = 0

        strSQL = "Select SalesOrderLine.IsCancel" _
             & "	,SubscriberAffiliate.SubscriberCategory" _
             & "	,Sum(Quantity) AS Quantity" _
             & "	,Sum(AmountProduct) AS Amount" _
             & " FROM SalesOrderLine" _
             & "	INNER JOIN SalesOrder" _
             & "		INNER JOIN Company" _
             & "		ON Company.CompanyId = SalesOrder.CompanyId" _
             & "	On SalesOrder.OrderNumber = SalesOrderLine.OrderNumber" _
             & "	INNER JOIN SubscriberAffiliate" _
             & "	ON SubscriberAffiliate.ChildSubscriberID = SalesOrderLine.SubscriberId" _
             & " WHERE Company.GroupParentSubscriberId = SubscriberAffiliate.ParentSubscriberID" _
             & " AND SalesOrderLine.OrderNumber=" & Me.txtOrderNumber.Value _
             & " GROUP BY SalesOrderLine.IsCancel" _
             & "        ,SubscriberAffiliate.SubscriberCategory"
        Try
            Dim tblOrderSummary As DataTable = uPage.db.GetDataTableFromSQL(strSQL)
            If tblOrderSummary.Rows.Count <> 0 Then
                html += "<table width='300' border='0' cellpadding='5' class='selectTable'>"
                html += "  <tr>"
                html += "    <td class='fldTitle'>Category</td>"
                html += "    <td class='fldTitle'>Cancelled</td>"
                html += "    <td class='fldTitle'>Quantity</td>"
                html += "    <td class='fldTitle'>Amount</td>"
                html += "  </tr>"

                For Each row As DataRow In tblOrderSummary.Rows
                    html += "  <tr>"
                    html += "	    <td class='fldView'>" & row("SubscriberCategory") & "</td>"
                    If uPage.db.IsDBNull(row("IsCancel"), False) = True Then
                        html += "	    <td class='fldView'>Yes</td>"
                    Else
                        html += "	    <td class='fldView'>&nbsp;</td>"
                    End If
                    html += "	    <td class='fldView'>" & row("Quantity") & "</td>"
                    html += "	    <td class='fldView'>" & Format(uPage.db.IsDBNull(row("Amount"), 0), "0.00") & "</td>"
                    html += "  </tr>"
                Next
                html += "</table>"
            Else
                html += "<table width='300' border='0' cellpadding='5' class='selectTable'>"
                html += "  <tr>"
                html += "    <td class='fldView'>No Order data available</td>"
                html += "  </tr>"
                html += "</table>"
            End If

            Me.OrderSummaryList.Text = html

        Catch ex As Exception
            uPage.PageError = "An Unexpected error has occured.  Get Order summary failed" & ex.ToString
        End Try
    End Sub
End Class
