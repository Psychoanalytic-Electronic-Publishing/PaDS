Imports System.Data.SqlClient
Imports System.Data
Imports System.IO

'Modification History
'27/01/2010     Julian Gates   Initial Version
'20/5/16    James Wosonam   SIR4133 Correct issue in sql below uPage.UserSession.UserId was Session("UserID") which returned 0
'17/02/21   Julian Gates  SIR5166 - Remove Sub CreateGatewayPage()

Partial Class pg501ProductCombinationMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim pageMode As String
    Dim selectCommand As String
    Dim ds As New DataSet
    Dim dRow As DataRow
    Dim dTble As DataTable
    Dim cPageNumber As Long

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "PEP Product Combination Maint", "")
        Me.pageHeaderTitle.Text = "PEP Product Combination Maint"

        pageMode = Request.QueryString("PageMode")
        Me.ProductCombinationId.Text = Request.QueryString("ProductCombinationId")

        If Request.QueryString("PageNumber") <> "" Then
            Me.cPageNumber = Request.QueryString("PageNumber")
        End If
        'uPage.FocusControl = Me.AffiliateReferenceId
        selectCommand = "Select *" _
           & " From PEPOnlineProductCombination" _
           & " Where ProductCombinationId = '" & Me.ProductCombinationId.Text & "'"

        If Page.IsPostBack Then
            ds = CType(ViewState("MainDataSet"), DataSet)
            If Left(Me.txtCommandData.Value, 6) = "Delete" Then
                DeleteProductCombinationLineRecord(Mid(Me.txtCommandData.Value, 7))
            End If
            BuildProductCombinationGridHTML()
        Else
            ReadRecord()
            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
        End If
        PageSetup()
    End Sub

    Sub PageSetup()
        Select Case pageMode
            Case "Add"
                Me.ProductCombinationIdPrompt.Visible = False
                Me.SecureCentreURLPrompt.Visible = False
                Me.pageHeaderTitle.Text = "Add New PEP Product Combination"
            Case "Update"
                Me.ProductCombinationIdPrompt.Visible = True
                Me.SecureCentreURLPrompt.Visible = True
                Me.SecureCentreURL.Text = "" '26/1/21 No longer required  New BusinessLogic.Database(uPage.PrimaryConnection).GetParameterValue("PEPProductCombinationSecureURL").Replace("nnn", Me.ProductCombinationId.Text)
        End Select
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Dim commandText As String
        Dim dr As SqlDataReader
        Dim field As DataSet
        Dim da As New SqlDataAdapter(selectCommand, uPage.PrimaryConnection)
        'Populate Dataset
        da.Fill(ds, "ProductCombination")

        'Populate all dropdown fields
        Dim dropDownIntialValue As String = "<---------Select--------->"
        '20/5/16    James Wosonam   SIR4133 Correct issue in sql below uPage.UserSession.UserId was Session("UserID") which returned 0
        uPage.PopulateDropDownListFromSQL(Me.NewProductCodeDropDown,
                                        "SELECT Product.ProductCode as Value" _
                                        & "     ,Product.ProductCode as Text" _
                                        & "	FROM Product" _
                                        & "		INNER JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                                        & "		ON Company.CompanyId = Product.CompanyId" _
                                        & " WHERE Product.ProductStatus = 'Current'" _
                                        & " AND Product.IsParent = 1" _
                                        & " ORDER By Product.ProductCode" _
                                        , uPage.PrimaryConnection, dropDownIntialValue)

        'Read all data from dataset into page fields
        If pageMode = "Update" Then
            uPage.PopulatePageFieldsFromDataRow(ds.Tables("ProductCombination").Rows(0))
            BuildProductCombinationGridHTML()
        End If
    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else
                If Me.NewProductCodeDropDown.SelectedValue = "" Then
                    uPage.FieldErrorControl(Me.NewProductCodeDropDown, "New Product Code DropDown is mandatory")
                End If

                If Me.NewProductCodeDropDown.SelectedValue <> "" Then
                    If uPage.StdCode.DLookup("ProductCode", "PEPOnlineProductCombination", "ProductCode='" & Me.NewProductCodeDropDown.SelectedValue & "' AND ProductCombinationId='" & Me.ProductCombinationId.Text & "'", uPage.PrimaryConnection).ToString() <> "" Then
                        uPage.PageError = "Selected Product Code " & Me.NewProductCodeDropDown.SelectedValue & " already exists for this Product Combination, Please choose another."
                    End If
                End If
        End Select

        Return uPage.IsValid
    End Function

    Sub SaveRecord()
        '******************************************************
        'Description:	Save the record either by updating or adding
        '******************************************************
        Dim intRowsAffected As Integer
        Dim cmdBld As System.Data.SqlClient.SqlCommandBuilder
        Dim da As New SqlDataAdapter(selectCommand, uPage.PrimaryConnection)

        dTble = ds.Tables("ProductCombination")
        If dTble.Rows.Count = 0 Then
            dRow = dTble.NewRow()
            Me.ProductCombinationId.Text = uPage.db.GetNextNumber("PEPOnlineProductCombinationId")
        Else
            dRow = dTble.Rows(0)
        End If
        'Read Values from page fields into dataset table
        uPage.PopulateDataRowFromPageFields(dRow)
        'Assign any default values or foreign key values if required

        If dTble.Rows.Count = 0 Then
            dTble.Rows.Add(dRow)
        End If
        'Add or Update data using command builder and transaction
        cmdBld = New System.Data.SqlClient.SqlCommandBuilder(da)
        da.InsertCommand = cmdBld.GetInsertCommand()
        da.UpdateCommand = cmdBld.GetUpdateCommand()
        da.DeleteCommand = cmdBld.GetDeleteCommand()
        If pageMode = "Add" Then
            ' must update the DestinationBandNumber after it has been allocated
            For Each row As Data.DataRow In ds.Tables("ProductCombination").Rows
                row("ProductCombinationId") = CInt(Me.ProductCombinationId.Text)
            Next
        End If
        Dim transaction As SqlTransaction
        transaction = uPage.PrimaryConnection.BeginTransaction
        Try
            da.InsertCommand.Transaction = transaction
            da.UpdateCommand.Transaction = transaction
            da.DeleteCommand.Transaction = transaction
            intRowsAffected = da.Update(ds, "ProductCombination")

            transaction.Commit()

            InfoMsg.Text = "Record Saved"
            If pageMode = "Add" Then
                Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&" & uPage.UserSession.QueryString & "&ProductCombinationId=" & Me.ProductCombinationId.Text)
            End If
        Catch e As Exception
            uPage.PageError = e.ToString
            transaction.Rollback()
        End Try
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = ds
        uPage.PagePreRender()
    End Sub

    Private Sub BackBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        Response.Redirect("../pages/pg500ProductCombinationList.aspx?" & uPage.UserSession.QueryString)
    End Sub


    Sub BuildProductCombinationGridHTML()
        '******************************************************
        'Description:	Builds and Displays Product Combination Grid
        '******************************************************
        Dim strHtml As String = Nothing
        Dim strQuery As String = Nothing
        For i As Integer = 0 To ds.Tables("ProductCombination").Rows.Count - 1
            Dim row As DataRow = ds.Tables("ProductCombination").Rows(i)
            If Not row.RowState = DataRowState.Deleted Then
                strHtml = strHtml & "<tr>"
                strHtml = strHtml & "<td>" _
                     & "<P class=fldView>" & row.Item("ProductCode") & "</P>" _
                     & "</td>"
                strHtml = strHtml & "<td align='center'>" _
                    & "<span class='lnkMaintNew'><a href='javascript:ConfirmSubmitCommandData(""Are you sure you want to delete this record?"",""Delete" & row.Item("ProductCode") _
                    & """)' Title='Delete Product Code: " & row.Item("ProductCode") & " record '><span class=hyperLinkButtonText>Delete</Span></a></span>" _
                    & "</td>"
                strHtml = strHtml & "</tr>"
            End If
        Next
        'Assign grid to Label
        ProductCombinationGridView.Text = strHtml
    End Sub

    Private Sub AddNewProductCodeBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddNewProductCodeBtn.Click
        'Add New Line to Grid
        If IsPageValidForStatus() Then
            Dim dRow As DataRow
            Dim dTble As DataTable
            dTble = ds.Tables("ProductCombination")
            dRow = dTble.NewRow()
            'Populate drow values from new row fields
            Select Case Me.pageMode
                Case "Add"
                    Me.ProductCombinationId.Text = uPage.db.GetNextNumber("PEPOnlineProductCombinationId")
                Case "Update"
                    dRow.Item("ProductCombinationId") = Me.ProductCombinationId.Text
            End Select
            dRow.Item("ProductCode") = NewProductCodeDropDown.SelectedValue
            dTble.Rows.Add(dRow)

            'Rebuild Grid
            BuildProductCombinationGridHTML()
            NewProductCodeDropDown.ClearSelection()
            SaveRecord()
        End If
    End Sub
    Sub DeleteProductCombinationLineRecord(ByVal locProductCode As String)
        If ds.Tables("ProductCombination").Rows.Count < 2 Then
            uPage.PageError = "Product Code Cannot be deleted, You must have at least one Product Code."
        Else
            For Each row As DataRow In ds.Tables("ProductCombination").Rows
                If row.Item("ProductCode") = locProductCode Then
                    row.Delete()
                    Exit For
                End If
            Next
        End If
        Me.txtCommandData.Value = ""
        SaveRecord()
    End Sub
End Class
