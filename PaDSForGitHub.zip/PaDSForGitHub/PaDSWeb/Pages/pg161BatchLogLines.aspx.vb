﻿Imports System.Data
Imports System.Data.SqlClient
'Modification History
'13/10/08  Julian Gates   Initial version
'18/10/10   Mike Sheard     SIR2250 - Read data from database in registry
'30/09/20   Julian Gates    Add paging to GetBatchLinesTable and filter button.

Partial Class pages_pg161BatchLogLines
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim pageMode As String
    Dim ds As New DataSet
    Dim dRow As DataRow
    Dim tbl As DataTable
    Public BatchLinesTableHtml As String = ""
    Public PageHtml As String = ""
    Private WebForm As WebForm

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Batch Log Lines", "")
        Me.pageHeaderTitle.Text = "Batch Log Lines"

        pageMode = Request.QueryString("PageMode")

        If Request.QueryString("BatchlogId") = "" Then
            Me.uPage.PageError = "This page must be passed a valid batchlog id"
        Else
            Me.BatchlogId.Text = Request.QueryString("BatchlogId")
            Me.PageNumber.Value = Request.QueryString("PageNumber")

            If Page.IsPostBack Then

            Else
                If Request.QueryString("InfoMsg") <> "" Then
                    Me.uPage.InfoMessage = Request.QueryString("InfoMsg")
                End If
                Me.RecordsToShow.Text = "50"
            End If

            ReadRecord()
            If Me.IsPageValidForStatus("") Then
                BatchLinesTableHtml = GetBatchLinesTable()
            End If
        End If
    End Sub
    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else

        End Select
        Me.uPage.FieldValidateNumber(Me.RecordsToShow)
        Return Me.uPage.IsValid
    End Function

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            uPage.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Dim selectCommand As String
        Try
            selectCommand = "Select * From BatchLog Where BatchLogId = " & Me.BatchlogId.Text
            Dim da As New SqlDataAdapter(selectCommand, uPage.db.DBConnection)
            'Populate Dataset
            da.Fill(ds, "BatchLog")

            'Read all data from dataset into page fields
            If pageMode = "Update" Then
                Me.uPage.PopulatePageFieldsFromDataRow(ds.Tables("BatchLog").Rows(0))
                Me.Description.Text.Replace(vbCrLf, "<br>")
                Me.ProcessDuration.Text = uPage.GetProcessTime(uPage.db.IsDBNull(ds.Tables("BatchLog").Rows(0)("DateTime"), ""), uPage.db.IsDBNull(ds.Tables("BatchLog").Rows(0)("EndDateTime"), ""))
            End If
        Catch e As Exception
            Me.uPage.PageError = "No available data for batch log id " & Me.BatchlogId.Text
        End Try
    End Sub

    Function GetBatchLinesTable() As String

        Dim commandTimedOut As Boolean = False
        If Me.ViewState("PageNumber") = Nothing Then
            Me.ViewState("PageNumber") = 1
        End If

        If Me.txtGotoPageNum.Value <> "" Then
            Me.ViewState("PageNumber") = Me.txtGotoPageNum.Value
        End If
        Try
            Dim sql As String = ""
            sql += "sp160BatchLogLines @batchLogId=" & Me.BatchlogId.Text & ", @RecordsRequired=" & CInt(Me.RecordsToShow.Text) * 5
            tbl = uPage.GetListDatatable(ViewState("PageNumber"), Me.RecordsToShow.Text, PageHtml _
                                                            , sql _
                                                            , uPage.db.DBConnection, True)

        Catch ex As Exception
            ' Throw ex
            commandTimedOut = True
        End Try

        Dim html As String = ""
        If commandTimedOut = True Then
            Me.BatchLineLbl.Visible = False
            html = "<span class=subHeader>Batch lines are unavailable until current process has completed.</span>"
        Else
            Me.BatchLineLbl.Visible = True
            html = "<table border='0' class='selectTable' width='100%' cellpadding='4'>"
            html += "<tr>"
            html += "<td width='150' class='fldTitle'>Date/Time</td>"
            html += "<td width='80' class='fldTitle'>Seconds</td>"
            html += "<td width='150' class='fldTitle'>Text</td>"
            html += "</tr>"
            Dim processTime As System.TimeSpan
            Dim logTime As DateTime
            Dim milliSeconds As Integer = 0

            For Each row As DataRow In tbl.Rows
                logTime = row("DateTime")
                milliSeconds = logTime.Millisecond
                logTime = logTime.ToString("dd/MM/yyyy HH:mm:ss")
                processTime = CDate(row("DateTime")).Subtract(CDate(row("LastLineLogTime")))
                html += "<tr>"
                html += "   <td  valign='top' class=fldView>" & logTime & ":" & milliSeconds & "</td>"
                html += "   <td  valign='top' align='right' class=fldView>" & processTime.TotalSeconds.ToString("#0.00") & "</td>"
                html += "   <td  valign='top' class=fldView>" & row("BatchLogLineText").Replace(vbCr, "<br/>") & "</td>"
                html += "</tr>"
            Next
            html += "</table>"
        End If
        Return html
    End Function

    Protected Sub BackBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        Response.Redirect("../pages/pg160BatchLogList.aspx?" & uPage.UserSession.QueryString)
    End Sub

    Protected Sub ClearBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ClearBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?BatchLogId=" & Me.BatchlogId.Text & "&PageMode=Update&" & uPage.UserSession.QueryString)
    End Sub

    Private Sub FilterBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilterBtn.Click
        Me.txtGotoPageNum.Value = 1
    End Sub
End Class
