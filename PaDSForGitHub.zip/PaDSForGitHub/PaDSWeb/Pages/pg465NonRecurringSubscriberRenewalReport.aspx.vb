﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports BusinessLogic
'Modification History
'30/10/19   Julian Gates    Initial Version
'20/11/19   Julian Gates    SIR4952 - Add CreateSubscriberImportBatches checkbox
'27/9/20     James Woosnam  SIR5118 - Show JV101 as a potentíal product

Partial Class Pages_pg465NonRecurringSubscriberRenewalReport
    Inherits System.Web.UI.Page
    Dim Product As Product = Nothing
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Non Recurring Subscriber Renewal Report", "")
        Me.pageHeaderTitle.Text = "Non Recurring Subscriber Renewal Report"

        If Page.IsPostBack Then

        Else
            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            uPage.PopulateDropDownListFromSQL(Me.CompanyId, "SELECT Company.CompanyId as Value" _
                                                            & "    ,Company.CompanyName as Text" _
                                                            & " FROM " & uPage.CompanyTable("Company", 31) _
                                                            & " ORDER BY CASE WHEN CompanyId=1 THEN 0 ELSE 1 END" _
                                                            & " ,CompanyName" _
                                                            , uPage.PrimaryConnection
                                                            )
            Me.PopulateLists()
            Me.CreateSubscriberImportBatches.Checked = True
        End If
    End Sub

    Sub PopulateLists()
        '27/9/20     James Woosnam  SIR5118 - Show JV101 as a potentíal product
        Dim SubscribedToProductCodes As String = GetSubscribedToProductCodes()

        Me.uPage.PopulateListBoxFromSql(Me.ProductsList, "Select DISTINCT p.ProductCode As VALUE" _
                                                                      & " ,p.ProductName  As TEXT" _
                                                                      & " FROM SalesOrder so" _
                                                                      & "  INNER JOIN Subscriber s" _
                                                                      & "  ON s.SubscriberId = so.SubscriberId" _
                                                                      & "  INNER Join Product p" _
                                                                      & "  ON p.ProductCode = so.PrimaryProductCode" _
                                                                      & " WHERE so.OrderDate > DateAdd(Month, -18, GETDATE())" _
                                                                      & " And (ISNULL(p.RecurringSubscriptionFlag,0) =0 OR p.ProductCode = 'JV101') " _
                                                                      & " And so.CompanyId = " & Me.CompanyId.SelectedValue _
                                                                      & " ORDER BY p.ProductName", Nothing)

        Me.ProductsList.Height = GetListHeightForRows(Me.ProductsList.Items.Count)
        ''  Me.ProductsList.Focus()
        For Each item As ListItem In Me.ProductsList.Items
            If SubscribedToProductCodes.Contains(item.Value) Then
                item.Selected = True
            End If
        Next

        Dim sql As String = "Select DISTINCT s.SubscriberId As VALUE" _
                            & " ,s.SubscriberName As TEXT" _
                            & " FROM SalesOrder so" _
                            & "  INNER JOIN Subscriber s" _
                            & "  ON s.SubscriberId = so.SubscriberId" _
                            & "  INNER Join Product p" _
                            & "  ON p.ProductCode = so.PrimaryProductCode" _
                            & " WHERE so.OrderDate > DateAdd(Month, -18, GETDATE())" _
                            & " And (ISNULL(p.RecurringSubscriptionFlag,0) =0 OR p.ProductCode = 'JV101') " _
                            & " And so.CompanyId = " & Me.CompanyId.SelectedValue
        If Me.OrderType.SelectedValue <> "All" Then
            sql += " AND so.orderType LIKE '" & Me.OrderType.SelectedValue & "%'"
        End If

        If SubscribedToProductCodes <> "" Then
            sql += " AND so.PrimaryProductCode IN (" & SubscribedToProductCodes & ")"

        End If
        sql += " ORDER BY s.SubscriberName"

        Me.uPage.PopulateListBoxFromSql(Me.SubscribersList, sql, Nothing)
        Me.SubscribersList.Height = GetListHeightForRows(Me.SubscribersList.Items.Count)
    End Sub
    Sub PageSetup()
        Me.TimedPanel.Visible = IsNumeric(ViewState("BatchJobId"))
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub
    Function GetSubscribedToProductCodes() As String
        Dim SubscribedToProductCodes As String = ""
        For Each itm As ListItem In Me.ProductsList.Items
            If itm.Selected Then
                SubscribedToProductCodes += IIf(SubscribedToProductCodes = "", "", ",") & "'" & itm.Value & "'"
            End If
        Next
        Return SubscribedToProductCodes
    End Function
    Private Sub SubmitReportBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubmitReportBtn.Click
        Try
            Dim SubscribedToProductCodes As String = GetSubscribedToProductCodes()
            Dim SpreadsheetsForSubscriberIds As String = ""
            For Each itm As ListItem In Me.ProductsList.Items
                If itm.Selected Then
                    SubscribedToProductCodes += IIf(SubscribedToProductCodes = "", "", ",") & "'" & itm.Value & "'"
                End If
            Next
            For Each itm As ListItem In Me.SubscribersList.Items
                If itm.Selected Then
                    SpreadsheetsForSubscriberIds += IIf(SpreadsheetsForSubscriberIds = "", "", ",") & itm.Value
                End If
            Next
            If SubscribedToProductCodes = "" Then uPage.FieldErrorControl(Me.ProductsList, "Please select at least one product")
            If SpreadsheetsForSubscriberIds = "" Then uPage.FieldErrorControl(Me.SubscribersList, "Please select at least one subscriber")
            If Not uPage.IsValid Then Exit Sub
            Dim report As BusinessLogic.ReportSubscriberRenewal = Nothing

            report = New BusinessLogic.ReportSubscriberRenewal(Me.CompanyId.SelectedValue, uPage.db, Me.uPage.UserSession.UserSessionIdGUID)
            report.SubmitNonRecurring(SubscribedToProductCodes, SpreadsheetsForSubscriberIds, CreateSubscriberImportBatches.Checked)

            ViewState("BatchJobId") = report.BatchJob.BatchJobId

            Me.InfoMsg.Text = "Report has been submitted as batchjob, if you wish to view the batchlog please use the Batchlog link in main menu."
            Me.UpdateTimer.Enabled = True

        Catch ex As Exception
            uPage.PageError = "There was an unexpected problem generating this report.  Please contact support." & ex.ToString
        End Try
    End Sub
    Private Function GetListHeightForRows(ByVal NoOfRows As Integer) As Integer
        Dim extraLines As Integer = 0
        Select Case NoOfRows
            Case 1, 2, 3
                extraLines = (100 / 6)
        End Select
        Return (100 / 6 * NoOfRows) + extraLines
    End Function

    Private Sub CompanyId_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CompanyId.SelectedIndexChanged
        PopulateLists()
    End Sub

    Protected Sub UpdateTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateTimer.Tick
        Try
            If IsNumeric(ViewState("BatchJobId")) Then
                Dim BatchLog As New BusinessLogic.BatchLog(uPage.db)
                Me.BatchLogLines.Text = BatchLog.GetBatchLogLinesHTML(ViewState("BatchJobId"))
                Select Case uPage.db.IsDBNull(uPage.db.DLookup("MAX(BatchLogStatus)", "BatchLog", "BatchJobId=" & ViewState("BatchJobId")), "")
                    Case "Complete", "Failed"
                        Me.UpdateTimer.Enabled = False
                    Case Else
                        Me.UpdateTimer.Enabled = True
                End Select
            Else
                Me.UpdateTimer.Enabled = False
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub

    Private Sub OrderType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles OrderType.SelectedIndexChanged
        PopulateLists()
    End Sub

    Private Sub ProductsList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ProductsList.SelectedIndexChanged
        PopulateLists()

    End Sub
End Class
