﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'05/02/2020    Julian Gates   Initial Version

Partial Class Pages_pg150CashbookSelect
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Cashbook Search and List", "")
        Me.pageHeaderTitle.Text = "Cashbook Search and List"

        If Page.IsPostBack Then

        Else
            If Request.QueryString("FilterSubscriberId") <> "" Then
                Me.CashBookGridView.FilterExpression = "SubscriberId='" & Request.QueryString("FilterSubscriberId") & "'"
            End If
            If Request.QueryString("FilterSubscriberName") <> "" Then
                Me.CashBookGridView.FilterExpression = "Contains(SubscriberName, '" & Request.QueryString("FilterSubscriberName") & "')"
            End If

            If Request.QueryString("FilterSubscriberId") <> "" And Request.QueryString("CompanyId") <> "" Then
                Me.CashBookGridView.FilterExpression = "SubscriberId='" & Request.QueryString("FilterSubscriberId") & "' AND CompanyId='" & Request.QueryString("CompanyId") & "'"
            End If
            If Me.CashBookGridView.FilterExpression = "" Then
                Me.CashBookGridView.FilterExpression = "CashbookStatus='Confirmed'"
            End If
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        GridSetup()

    End Sub

    Sub PageSetup()

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub GridSetup()
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT cb.CashbookId" & sCR
            Sql += " ,cb.CompanyId" & sCR
            Sql += " ,cb.OrderNumber" & sCR
            Sql += " ,cb.CashbookStatus" & sCR
            Sql += " ,cb.EntryDate" & sCR
            Sql += " ,cb.SubscriberId" & sCR
            Sql += " ,s.SubscriberName" & sCR
            Sql += " ,cb.CurrencyCode" & sCR
            Sql += " ,cb.EntryType" & sCR
            Sql += " ,cb.PaymentType" & sCR
            Sql += " ,cb.Amount" & sCR
            Sql += " ,cb.Amount" & sCR
            Sql += " ,cb.BankDepositId" & sCR
            Sql += " ,BankedDate = CASE WHEN cb.BankDepositId IS NOT NULL THEN FORMAT(bd.DateBanked,'d-MMM-yy') ELSE '' END" & sCR
            Sql += " ,IsBanked = CASE WHEN cb.BankDepositId IS  NULL THEN 'N' ELSE 'Y' END" & sCR
            Sql += " ,c.CompanyShortName" & sCR
            Sql += " FROM Cashbook cb" & sCR
            Sql += "    INNER JOIN  " & uPage.SubscriberTable("s") & sCR
            Sql += "    ON s.SubscriberId = cb.SubscriberId" & sCR
            Sql += "    INNER JOIN " & uPage.CompanyTable("c", uPage.UserSession.UserId) & sCR
            Sql += "    ON c.CompanyId = cb.CompanyId"
            Sql += "    LEFT JOIN BankDeposit bd" & sCR
            Sql += "    ON bd.BankDepositID = cb.BankDepositId"
            Sql += " WHERE 1=1" & sCR
            If Me.AccentSubscriberNameSearch.Text <> "" Then
                Sql += " AND CAST(s.SubscriberName AS NVARCHAR(50)) Like N'%" & Me.AccentSubscriberNameSearch.Text & "%'  COLLATE SQL_Latin1_General_CP1_CI_AI" & sCR
            End If
            Sql += " ORDER BY cb.CashBookId Desc" & sCR

            Me.CashBookDatasource.SelectCommand = Sql
            Me.CashBookDatasource.DataBind()
            Me.CashBookGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
    Protected Sub AccentSubscriberNameSearchBtn_Click(sender As Object, e As EventArgs) Handles AccentSubscriberNameSearchBtn.Click
        Me.GridSetup()
    End Sub
    Protected Sub ClearSearchBtn_Click(sender As Object, e As EventArgs) Handles ClearSearchBtn.Click
        Response.Redirect("pg150CashbookSelect.aspx?" & uPage.UserSession.QueryString)
    End Sub
End Class
