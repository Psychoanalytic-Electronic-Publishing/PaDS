﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'04/05/2020    Julian Gates   Initial Version

Partial Class Pages_pg081ErrorMessageLogList
    Inherits System.Web.UI.Page
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Error Message Log List", "")
        Me.pageHeaderTitle.Text = "Error Message Log List"

        If Page.IsPostBack Then

        Else

        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        GridSetup()

    End Sub

    Sub PageSetup()

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub GridSetup()
        Try
            Dim sCR As String = System.Environment.NewLine
            Dim Sql As String = ""
            Sql = "SELECT eml.ErrorMessageLogId" & sCR
            Sql += " ,eml.DateTime" & sCR
            Sql += " ,eml.UserId" & sCR
            Sql += " ,eml.UserName" & sCR
            Sql += " ,eml.Page" & sCR
            Sql += " ,eml.ErrorMessage" & sCR
            Sql += " ,eml.Source" & sCR
            Sql += " ,eml.StackTrace" & sCR
            Sql += " FROM stblErrorMessageLog eml" & sCR
            Sql += " ORDER BY eml.DateTime desc" & sCR

            Me.ErrorMessageLogDatasource.SelectCommand = Sql
            Me.ErrorMessageLogDatasource.DataBind()
            Me.ErrorMessageLogGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub
End Class
