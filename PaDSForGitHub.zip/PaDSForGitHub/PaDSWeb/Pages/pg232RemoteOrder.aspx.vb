﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'20/01/11  Julian Gates   Initial version
'12/05/11  Julian Gates   SIR2428 - Dont show PEPWEB24 in GetWebProductList() if has existing subscription
'20/6/11   Julian Gates   Modification - Add Me.Subscriber.GetAddressRow("Postal", "Main")("CountryId") <> 56 to only add CSPost to Non USA subscribers in GetSelectedProductsTable function.
'21/6/11    James Woosnam   SIR2445 - The above change is now reversed as this is now hanlded in sp236WebProducts
'22/6/11   Julian Gates   SIR2459 - Add new IsSubscriberValidForOrdering error message functionality.
'22/6/11   Julian Gates   SIR2459 - Use new Subscriber.BillingAddressRow to get Billing or Main address data
'9/11/11    James Woosnam   Hot Fix - ReInitialise SalesOrder to try and avaid conccuency and tramsation problems
'14/11/11   James Woosnam   HotFix - Add session to the terms and conditions link
'15/02/12   Julian Gates    Hotfix - Add code pageload to stop user creating duplicate cashbook entries.
'05/3/12    Julian Gates    Removed Ajax roundpanels
'08/3/12    Julian Gates    SIR2631 - Hide update details button if product renewal.
'28/01/14   Julian Gates    SIR3398 - Test to see if zero and non zero products have been selected in sub IsPageValidForStatus.
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields and associated code
'29/10/19   Julian Gates    SIR4768 - Removed VATNumber
'13/11/19   James Woosnam   SIR4949 - use passed in companyId
'25/11/19   Julian Gates    SIR4957 - Show ErrorMessage in the page and not in header
'9/12/19    Julian Gates    SIR4972 - Add mailing address as read only line.
'18/1/20    James Woosnam   SIR4999 - Significantly reworked to allow much more control of the product gird and how associated products are shown and handled
'03/03/20   Julian Gates    Convert page to be English and Spanish
'12/07/21   Julian Gates    SIR5281 - Add DisplayProductName to page to be shown to User.

Partial Class Pages_pg232RemoteOrder
    Inherits System.Web.UI.Page
    Dim pageMode As String = ""
    Dim StdCode As New BusinessLogic.StdCode()
    Public ErrorMessage As String = ""
    Dim _tblProducts As DataTable = Nothing
    Private ReadOnly Property tblProducts As DataTable
        Get
            If Me._tblProducts Is Nothing Then
                Dim cmd As New SqlCommand("sp235WebProducts", Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
                cmd.CommandType = CommandType.StoredProcedure


                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CompanyId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , ViewState("CompanyId")))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                          , Me.Master.UserSession.Data("SubscriberId")))

                Me._tblProducts = Me.Master.db.GetDataTableFromSQL(cmd)
            End If
            Return Me._tblProducts
        End Get
    End Property
    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                Me._Subscriber = New BusinessLogic.Subscriber(Me.Master.UserSession.Data("SubscriberId"), Me.Master.db, Me.Master.UserSession)
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property

    Private _SalesOrder As BusinessLogic.SalesOrder = Nothing
    Public Property SalesOrder() As BusinessLogic.SalesOrder
        Get
            If Me._SalesOrder Is Nothing Then
                Me._SalesOrder = New BusinessLogic.SalesOrder(Me.Master.db, Me.Master.UserSession)
            End If
            Return Me._SalesOrder
        End Get
        Set(ByVal value As BusinessLogic.SalesOrder)
            Me._SalesOrder = value
        End Set
    End Property
    Public ReadOnly Property DisplayLanguage As BusinessLogic.UserSession.DisplayLanguages
        Get
            If Me.IsPostBack Then
                Return Me.Master.DisplayLanguageRBLSelectedValue
            Else
                Return Me.Master.UserSession.DisplayLanguage
            End If
        End Get

    End Property
    Protected Sub Page_Init(sender As Object, e As System.EventArgs) Handles Me.Init
        '18/1/20    James Woosnam   SIR4999 - Controls that need dynamic event handlers must be declared in Page.Init
        '                           and then attached to the correct position later
        Me.PageInit()

        For Each row In tblProducts.Rows
            '   Dim 
            Dim cb As New CheckBox
            cb.ID = "cbxSelectedProduct" & row("ProductRateId")
            cb.AutoPostBack = True
            cb.EnableViewState = True
            AddHandler cb.CheckedChanged, AddressOf cbxSelectedProductChanged
            cb.Visible = False
            Page.Controls.Add(cb)
        Next
    End Sub
    Sub PageInit()
        Try
            'Put user code to initialize the page here
            Master.Initilise("Remote Product Order Form", "05", "")
            Master.ShowLanguageRBL = True

            If Request.QueryString("PageMode") <> "" Then
                pageMode = Request.QueryString("PageMode")
            Else
                Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "This page has been passed an invalide page mode." _
                               , "Esta página ha pasado al modo página no válida."))
            End If

            '13/11/19   James Woosnam   SIR4949 - use passed in companyId

            If Request.QueryString("ProductCode") <> "" Then
                Me.txtProductCode.Value = Request.QueryString("ProductCode")
            End If
            If Request.QueryString("CompanyId") <> "" Then
                ViewState("CompanyId") = Request.QueryString("CompanyId")
            ElseIf Me.txtProductCode.Value <> Nothing Then
                '5/12/19   James Woosnam   SIR4949 - use  companyId from product
                ViewState("CompanyId") = Master.db.DLookup("CompanyId", "Product", "ProductCode='" & Me.txtProductCode.Value & "'")
            Else
                Throw New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "This page must be passed a CompanyId." _
                               , "Esta página debe pasar un ID de empresa."))
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try
    End Sub
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            '18/1/20    James Woosnam   SIR4999 - Normal initial page set up is now called from me.Init

            If Page.IsPostBack Then
                If ViewState("OrderNumber") = 0 Then
                    Me.SalesOrder = New BusinessLogic.SalesOrder(Master.db, Master.UserSession)
                Else
                    Me.SalesOrder = New BusinessLogic.SalesOrder(ViewState("OrderNumber"), Master.db, Master.UserSession)
                    Me.SalesOrder.MainDataset = CType(ViewState("MainDataSet"), DataSet)
                End If
            Else
                '
                ViewState("OrderNumber") = Me.Master.WebForm.db.IsDBNull(Master.WebForm.db.DLookup("Max(OrderNumber)", "SalesOrder", "CompanyId=" & ViewState("CompanyId") & " AND SubscriberId = " & Me.Master.UserSession.Data("SubscriberId") & "And SalesOrderstatus = 'RemotePartial'"), 0)
                '15/02/12 Julian Gates  Hotfix - Add code below to stop user creating duplicate cashbook entries
                If Me.Master.WebForm.db.DLookup("CashbookId", "Cashbook", "OrderNumber=" & ViewState("OrderNumber") & "AND CashbookStatus <> 'Partial'") <> Nothing Then
                    ViewState("OrderNumber") = Nothing
                End If
                If ViewState("OrderNumber") = 0 Then
                    Me.SalesOrder = New BusinessLogic.SalesOrder(Master.db, Master.UserSession)
                Else
                    Me.SalesOrder = New BusinessLogic.SalesOrder(ViewState("OrderNumber"), Master.db, Master.UserSession)
                End If

                If Me.Master.WebForm.IsValid Then
                    ReadRecord()
                End If
            End If

            GetWebProductList()

            Session("UsedOrderPageType") = "English"
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try
    End Sub

    Sub PageSetup()

        Me.Master.PageTitle = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Remote Product Order Form" _
                               , "Formulario de Compra de Producto Remoto")

        '22/6/11   Julian Gates   SIR2459 - Add new IsSubscriberValidForOrdering error message functionality
        If Me.Subscriber.IsSubscriberValidForOrdering() <> "" Then

            Me.IsSubscriberValidForOrderingError.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "<b>WARNING: Subscriber Details Missing</b> <br>" & Me.Subscriber.IsSubscriberValidForOrdering() _
                               , "<b>ADVERTENCIA: Faltan datos del suscriptor</b> <br>" & Me.Subscriber.IsSubscriberValidForOrdering())
            Me.TableRowIsSubscriberValidForOrdering.Visible = True
            Me.NextBtn.Enabled = False
        Else
            Me.TableRowIsSubscriberValidForOrdering.Visible = False
            Me.NextBtn.Enabled = True
        End If

        If pageMode = "RenewOrder" Then
            Me.UpdateDetailsBtn.Visible = False
        Else
            Me.UpdateDetailsBtn.Visible = True
        End If

        RemoteProductOrderFormTextDisplay()
        '25/11/19   Julian Gates    SIR4957 -  Show ErrorMessage in the page and not in header
        Me.ErrorMessage = Master.OutputErrorMessage()
        Me.pnlError.Visible = True
        Me.pnlError.Update()

        Me.Master.PageTitle = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Remote Product Order Form" _
                               , "Formulario de Compra de Producto Remoto")

        Me.UpdateDetailsBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Update" _
                               , "Actualizar")
        Me.UpdateDetailsBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                , "Update your details." _
                                , "Actualizar sus datos")
        Me.NextBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                              , "Next" _
                              , "Siguiente")
        Me.NextBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                , "Next page." _
                                , "Página siguiente.")
        Me.HomeBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                             , "Home" _
                             , "Inicio")
        Me.HomeBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                , "Return to home." _
                                , "Regreso a casa.")
    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else
                If Me.TermsAgreed.Checked = False Then
                    Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                             , "Please tick Terms and Conditions of Sale box." _
                             , "Por favor coloque un tilde en Términos y Condiciones  del recuadro Venta."))
                End If

                If pageMode = "NewOrder" Then
                    Dim tSelected As DataTable = GetSelectedProductsTable()
                    If tSelected.Rows.Count = 0 Then
                        Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                             , "You must select a product from product list." _
                             , "Seleccione un product o de la lista de productos."))
                    Else
                        For Each rSelected As DataRow In tSelected.Rows
                            If Not Master.db.IsDBNull(rSelected("AssociatedWithProductCode")) Then
                                Dim vw As New DataView(tSelected, "PrimaryProductCode='" & rSelected("AssociatedWithProductCode") & "'", "", DataViewRowState.CurrentRows)
                                If vw.Count = 0 Then
                                    Me.Master.WebForm.AddPageError(rSelected("PrimaryProductCode") & IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , " can only be ordered with " _
                                                                     , " solo se puede pedir con ") & rSelected("AssociatedWithProductCode"))
                                End If
                            End If
                        Next
                    End If
                End If
        End Select

        Return Me.Master.WebForm.IsValid
    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        If Me.SalesOrder.OrderNumber <> Nothing Then
            Me.OrderNumber.Text = SalesOrder.OrderNumber
        End If
        Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.Subscriber.SubscriberRow)
        Me.EmailMain.Text = Me.Subscriber.GetAddressText("Email")
        Me.BillingAddress.Text = Me.Subscriber.BillingAddressRow("AddressText")
        '9/12/19    Julian Gates    SIR4972 - Add mailing address as read only line.
        Me.PostalAddress.Text = Me.Subscriber.GetAddressText("Postal")
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.SalesOrder.MainDataset
        ViewState("tblProducts") = Me.tblProducts
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    Sub SaveRecord()
        '    '******************************************************
        '    'Description:	Save the record either by updating
        '    '******************************************************
        '9/11/11    James Woosnam   Hot Fix - ReInitialise SalesOrder to try and avaid conccuency and tramsation problems
        If Me.SalesOrder.OrderNumber = Nothing Then
            Me.SalesOrder = New BusinessLogic.SalesOrder(Master.db, Master.UserSession)
        Else
            Me.SalesOrder = New BusinessLogic.SalesOrder(Me.SalesOrder.OrderNumber, Master.db, Master.UserSession)
        End If
        Me.Master.db.BeginTran()
        Try
            If Me.SalesOrder.OrderNumber = Nothing Then
                Select Case pageMode
                    Case "NewOrder"
                        SalesOrder.Add(GetSelectedProductsTable())
                    Case "RenewOrder"
                        SalesOrder.Add(GetSelectedRenewProductsTable())
                End Select
            Else
                Select Case pageMode
                    Case "NewOrder"
                        Me.SalesOrder.AddSalesOrderLines(GetSelectedProductsTable())
                    Case "RenewOrder"
                        Me.SalesOrder.AddSalesOrderLines(GetSelectedRenewProductsTable())
                End Select

                Me.SalesOrder.Save()
            End If
            Me.OrderNumber.Text = SalesOrder.OrderNumber
            Me.Master.db.CommitTran()
        Catch ex As Exception
            Me.Master.db.RollbackTran()
            Throw ex
        End Try

    End Sub

    Protected Sub NextBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles NextBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                SaveRecord()
            Catch ex As Exception
                Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
            End Try

            If Me.Master.WebForm.IsValid Then
                Select Case pageMode
                    Case "NewOrder"
                        Response.Redirect("../Pages/pg223Authorisation.aspx?" & Me.Master.UserSession.QueryString & "&OrderNumber=" & Me.OrderNumber.Text & "&PageType=" & pageMode)
                    Case "RenewOrder"
                        Response.Redirect("../Pages/pg223Authorisation.aspx?" & Me.Master.UserSession.QueryString & "&OrderNumber=" & Me.OrderNumber.Text & "&PageType=" & pageMode & "&ProductCode=" & Me.txtProductCode.Value)
                End Select
            End If
        End If
    End Sub

    Protected Sub HomeBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles HomeBtn.Click
        Response.Redirect("../pages/pg101Home.aspx?" & Me.Master.UserSession.QueryString)
    End Sub

    Sub RemoteProductOrderFormTextDisplay()
        '*********************************************************
        'Desc:		Generates Remote product order form text
        '********************************************************
        Try
            '13/11/19   James Woosnam   SIR4949 - Use different test file for each company
            Select Case pageMode
                Case "NewOrder"
                    Select Case Me.DisplayLanguage.ToString
                        Case "Spanish"
                            Me.RemoteOrderTermsText.Text = Me.Master.WebForm.GetImportFileText(IO.Path.Combine(Me.Master.db.GetParameterValue("TermsConditionsDirectoryPhysicalPath"), "RemoteNewOrderText" & Me.DisplayLanguage.ToString & ViewState("CompanyId") & ".htm"))
                        Case "English"
                            Me.RemoteOrderTermsText.Text = Me.Master.WebForm.GetImportFileText(IO.Path.Combine(Me.Master.db.GetParameterValue("TermsConditionsDirectoryPhysicalPath"), "RemoteNewOrderText" & ViewState("CompanyId") & ".htm"))
                    End Select
                Case "RenewOrder"
                    Select Case Me.DisplayLanguage.ToString
                        Case "Spanish"
                            Me.RemoteOrderTermsText.Text = Me.Master.WebForm.GetImportFileText(IO.Path.Combine(Me.Master.db.GetParameterValue("TermsConditionsDirectoryPhysicalPath"), "RemoteRenewalOrderText" & Me.DisplayLanguage.ToString & ViewState("CompanyId") & ".htm"))
                        Case "English"
                            Me.RemoteOrderTermsText.Text = Me.Master.WebForm.GetImportFileText(IO.Path.Combine(Me.Master.db.GetParameterValue("TermsConditionsDirectoryPhysicalPath"), "RemoteRenewalOrderText" & ViewState("CompanyId") & ".htm"))
                    End Select
            End Select
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try
    End Sub

    Sub GetWebProductList()
        '18/1/20    James Woosnam   SIR4999 - Reworked to use ASP controls and add event to tick box
        Dim strSQL As String = ""
        Dim html As String = ""
        Dim lnglineNumber As Long
        Dim strPrefix As String = ""
        Dim blnQualifyingProductFound As Boolean = False
        Try
            If tblProducts.Rows.Count > 0 Then
                Dim t As Table = Me.ProductListTable
                t.Width = 750
                Select Case pageMode
                    Case "RenewOrder"
                        For Each row As DataRow In tblProducts.Rows
                            If row("ProductCode") = Me.txtProductCode.Value Then
                                Dim tr As New TableRow
                                Dim tc As New TableCell
                                tc.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                        , "You are renewing your subscription for " _
                                                        , "Ud. está renovando su suscripción para ") & row("DisplayProductName") & " at $" & Format(row("ProductRate"), "0.00")
                                tc.Text += IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                        , " <a href='../pages/pg234TermsAndConditions.aspx?" _
                                                                & "PageMode=Update&TCFileName=" & row("TermsAndConditionsFileName") & "&ProductName=" & row("DisplayProductName") & "&" & Me.Master.UserSession.QueryString _
                                                                & "' Title='View Terms & Conditions for " & row("ProductCode") & " product' Target='_blank'>Terms and Conditions</a>" _
                                                        , " <a href='../pages/pg234TermsAndConditions.aspx?" _
                                                                & "PageMode=Update&TCFileName=" & row("TermsAndConditionsFileName") & "&ProductName=" & row("DisplayProductName") & "&" & Me.Master.UserSession.QueryString _
                                                                & "' Title='Ver Términos y Condiciones para " & row("ProductCode") & " producto' Target='_blank'>Términos y Condiciones</a>")
                                tr.Controls.Add(tc)
                                t.Rows.Add(tr)
                                Dim vwAss As New DataView(Me.tblProducts, "AssociatedWithProductCode='" & row("PrimaryProductCode") & "'", "", DataViewRowState.CurrentRows)
                                If vwAss.Count <> 0 Then
                                    tr = New TableRow
                                    tc = New TableCell
                                    Dim lb As New Label
                                    lb.CssClass = "redText"
                                    lb.Text = vwAss(0)("DisplayProductName")
                                    tc.Controls.Add(lb)
                                    lb = New Label
                                    lb.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "<br>If you wish to receive printed copies, make sure the box is ticked. Please untick the box if you do not wish to receive the print edition of the IJP." _
                                                                     , "<br>Si desea recibir copias impresas, asegúrese de marcar la opción correspondiente. Por favor desmarque la opción si no desea recibir la edición impresa de la IJP.")
                                    tc.Controls.Add(lb)
                                    tr.Controls.Add(tc)
                                    t.Rows.Add(tr)
                                End If
                            End If
                        Next
                    Case "NewOrder"
                        '   t.BorderStyle = BorderStyle.Solid
                        t.CssClass = "ListTable"
                        Dim thr As New TableHeaderRow
                        Dim thc As New TableHeaderCell
                        thc.CssClass = ""
                        thc.CssClass = "firstTh"
                        thc.Width = 180
                        thc.Height = 25
                        thc.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "Primary Product Code" _
                                                                     , "Código Primaro de Producto")
                        thr.Controls.Add(thc)
                        thc = New TableHeaderCell
                        thc.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "Name" _
                                                                     , "Nombre")
                        thr.Controls.Add(thc)
                        thc = New TableHeaderCell
                        thc.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "Rate" _
                                                                     , "Precio")
                        thc.CssClass = "lastTh"
                        thc.ColumnSpan = 3
                        thr.Controls.Add(thc)
                        t.Controls.Add(thr)

                        For Each row As DataRow In tblProducts.Rows
                            Dim blnNoRate As Boolean = False
                            lnglineNumber = lnglineNumber + 1
                            If lnglineNumber > 9 Then
                                strPrefix = ""
                            Else
                                strPrefix = "0"
                            End If
                            Dim sRate As String = ""
                            If Me.Master.db.IsDBNull(row("ProductRate")) Then
                                sRate = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "No Rate" _
                                                                     , "No Precio")
                                blnNoRate = True
                            Else
                                sRate = "$" & Format(row("ProductRate"), "0.00")
                            End If
                            ' html += "<tr>"
                            Dim tr As New TableRow
                            Dim ShowAsAutoSelectedChildProduct As Boolean = False
                            If row("PrimaryProductCode") <> row("ProductCode") Or Not Master.db.IsDBNull(row("AssociatedWithProductCode")) Then
                                ShowAsAutoSelectedChildProduct = True
                            End If
                            Dim IsAssociatedProduct As Boolean = Not Master.db.IsDBNull(row("AssociatedWithProductCode"))
                            Dim IsQualifyingProduct As Boolean = Not Master.db.IsDBNull(row("CurrentSubscriptionOrderNumber"))
                            Dim tc As New TableCell
                            If ShowAsAutoSelectedChildProduct Then
                                blnQualifyingProductFound = True
                                ' Arrow
                                tc = New TableCell
                                Dim i As New Image
                                i.ImageUrl = "../images/arrow2.gif"
                                tc.Controls.Add(i)
                                tr.Controls.Add(tc)
                                ' Product Name
                                tc = New TableCell
                                Dim lb As New Label
                                lb.CssClass = "redText"
                                lb.Text = row("DisplayProductName")
                                tc.Controls.Add(lb)
                                If IsAssociatedProduct Then
                                    lb = New Label
                                    lb.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "<br>If you wish to receive printed copies, make sure the box is ticked. Please untick the box if you do not wish to receive the print edition of the IJP." _
                                                                     , "<br>Si desea recibir copias impresas, asegúrese de marcar la opción correspondiente. Por favor desmarque la opción si no desea recibir la edición impresa de la IJP.")
                                    tc.Controls.Add(lb)
                                ElseIf IsQualifyingProduct Then
                                    lb = New Label
                                    lb.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "<br>(Qualifying product giving preferential rate)" _
                                                                     , "<br>(Qualifying product giving preferential rate)")
                                    tc.Controls.Add(lb)

                                End If
                                tr.Controls.Add(tc)
                                ' Product Rate
                                tc = New TableCell
                                tc.CssClass = "redText"
                                tc.Text = sRate
                                tr.Controls.Add(tc)

                            Else
                                'Product Code
                                tc = New TableCell
                                tc.Text = row("ProductCode")
                                tr.Controls.Add(tc)
                                'Product Name
                                tc = New TableCell
                                tc.Text = row("DisplayProductName")
                                tr.Controls.Add(tc)
                                ' Product Rate
                                tc = New TableCell
                                tc.Text = sRate
                                tr.Controls.Add(tc)
                            End If

                            tc = New TableCell
                            If blnNoRate Then
                            Else
                                'Check box
                                Dim cb As CheckBox = Me.Page.FindControl("cbxSelectedProduct" & row("ProductRateId"))
                                If Not IsPostBack Then
                                    'Set up state of checkbox, which was default initialised in Page_Init above
                                    cb.Visible = Not ShowAsAutoSelectedChildProduct Or IsAssociatedProduct
                                    cb.Enabled = Not ShowAsAutoSelectedChildProduct
                                    For Each saledRow As DataRow In Me.SalesOrder.SalesOrderLine.Rows
                                        If saledRow("ProductCode") = row("ProductCode") Then
                                            cb.Checked = True
                                            cb.Enabled = Not ShowAsAutoSelectedChildProduct Or IsAssociatedProduct
                                            Exit For
                                        End If
                                    Next
                                End If
                                tc.Controls.Add(cb)
                            End If
                            tr.Controls.Add(tc)
                            'Terms and conditions
                            tc = New TableCell
                            tc.Width = 140
                            tc.CssClass = "lnkMaint"
                            If Me.Master.db.IsDBNull(row("TermsAndConditionsFileName"), "") <> "" Then
                                Dim lk As New HyperLink
                                lk.NavigateUrl = "../pages/pg234TermsAndConditions.aspx?"
                                lk.NavigateUrl += "PageMode=Update&TCFileName=" & row("TermsAndConditionsFileName")
                                lk.NavigateUrl += "&ProductName=" & row("DisplayProductName") & "&" & Me.Master.UserSession.QueryString
                                lk.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "Terms and Conditions" _
                                                                     , "Términos y Condiciones")
                                lk.Target = "_blank"
                                tc.Controls.Add(lk)
                            End If
                            tr.Controls.Add(tc)
                            t.Controls.Add(tr)
                        Next
                        Me.WebProductsListTD.Controls.Add(t)
                End Select
            Else
                Me.WebProductsListTD.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "No products found" _
                                                                     , "No hay productos encontrados")
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try
    End Sub
    Dim SelectedProductsTable As DataTable = Nothing
    Function GetSelectedProductsTable() As DataTable
        If Me.SelectedProductsTable IsNot Nothing Then
            Return Me.SelectedProductsTable
        End If
        SelectedProductsTable = New DataTable("SelectedProductsTable")
        Dim columnAdded As Boolean = False
        Try
            Dim prodTable As Table = Me.WebProductsListTD.FindControl("ProductListTable")
            Dim lastParentLineSelected As Boolean = False
            For Each row As DataRow In tblProducts.Rows
                Dim ParentProductOrdered As Boolean = False
                '22/6/11   Julian Gates   SIR2459 - Use new Subscriber.BillingAddressRow to get Billing or Main address data
                If row("ProductCode") <> row("PrimaryProductCode") And lastParentLineSelected Then
                    ParentProductOrdered = True
                End If
                Dim cb As CheckBox = CType(prodTable.FindControl("cbxSelectedProduct" & row("ProductRateId")), CheckBox)


                If cb.Checked Or ParentProductOrdered Then
                    If columnAdded = False Then
                        SelectedProductsTable.Columns.Add("ProductRateId")
                        SelectedProductsTable.Columns.Add("PrimaryProductCode")
                        SelectedProductsTable.Columns.Add("ProductCode")
                        SelectedProductsTable.Columns.Add("ProductRate")
                        SelectedProductsTable.Columns.Add("CurrencyCode")
                        SelectedProductsTable.Columns.Add("NewRecurringSubscriptionStartDate")
                        SelectedProductsTable.Columns.Add("NewRecurringSubscriptionEndDate")
                        SelectedProductsTable.Columns.Add("AssociatedWithProductCode")

                        columnAdded = True
                    End If
                    Dim row1 As DataRow = SelectedProductsTable.NewRow
                    row1.Item("ProductRateId") = row("ProductRateId")
                    row1.Item("PrimaryProductCode") = row("PrimaryProductCode")
                    row1.Item("ProductCode") = row("ProductCode")
                    row1.Item("ProductRate") = row("ProductRate")
                    row1.Item("CurrencyCode") = row("CurrencyCode")
                    row1.Item("NewRecurringSubscriptionStartDate") = row("NewRecurringSubscriptionStartDate")
                    row1.Item("NewRecurringSubscriptionEndDate") = row("NewRecurringSubscriptionEndDate")
                    row1.Item("AssociatedWithProductCode") = row("AssociatedWithProductCode")
                    SelectedProductsTable.Rows.Add(row1)
                    If row("ProductCode") = row("PrimaryProductCode") Then
                        lastParentLineSelected = True
                    End If
                Else
                    If row("ProductCode") = row("PrimaryProductCode") Then
                        lastParentLineSelected = False
                    End If
                End If
            Next
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try

        Return SelectedProductsTable
    End Function

    Function GetSelectedRenewProductsTable() As DataTable
        Dim SelectedProductsTable As New DataTable("SelectedProductsTable")
        Dim columnAdded As Boolean = False
        Try
            For Each row As DataRow In tblProducts.Rows
                If row("ProductCode") = Me.txtProductCode.Value Then
                    If columnAdded = False Then
                        SelectedProductsTable.Columns.Add("ProductRateId")
                        SelectedProductsTable.Columns.Add("PrimaryProductCode")
                        SelectedProductsTable.Columns.Add("ProductCode")
                        SelectedProductsTable.Columns.Add("ProductRate")
                        SelectedProductsTable.Columns.Add("CurrencyCode")
                        SelectedProductsTable.Columns.Add("NewRecurringSubscriptionStartDate")
                        SelectedProductsTable.Columns.Add("NewRecurringSubscriptionEndDate")
                        columnAdded = True
                    End If
                    Dim row1 As DataRow = SelectedProductsTable.NewRow
                    row1.Item("ProductRateId") = row("ProductRateId")
                    row1.Item("PrimaryProductCode") = row("PrimaryProductCode")
                    row1.Item("ProductCode") = row("ProductCode")
                    row1.Item("ProductRate") = row("ProductRate")
                    row1.Item("CurrencyCode") = row("CurrencyCode")
                    row1.Item("NewRecurringSubscriptionStartDate") = row("NewRecurringSubscriptionStartDate")
                    row1.Item("NewRecurringSubscriptionEndDate") = row("NewRecurringSubscriptionEndDate")
                    SelectedProductsTable.Rows.Add(row1)
                End If
            Next
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try

        Return SelectedProductsTable
    End Function

    Protected Sub UpdateDetailsBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateDetailsBtn.Click
        Response.Redirect("../pages/pg112SubscriberDetailsMaint.aspx?PageFrom=SalesOrder&PageMode=" & pageMode & "&CompanyId=" & ViewState("CompanyId") & "&" & Me.Master.UserSession.QueryString)
    End Sub
    Protected Sub cbxSelectedProductChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        '18/1/20    James Woosnam   SIR4999 - Tixk box event, if parent product selected, then associate prop checked and enabled so it can be unchecked if required
        Try
            Dim prodTable As Table = Me.WebProductsListTD.FindControl("ProductListTable")
            Dim chk As CheckBox = CType(sender, CheckBox)
            Dim rateID As Integer = chk.ID.Replace("cbxSelectedProduct", "")
            Dim vw As New DataView(Me.tblProducts, "ProductRateId=" & rateID, "", DataViewRowState.CurrentRows)
            If Master.db.IsDBNull(vw(0)("AssociatedWithProductCode")) Then
                'see if there is an associated prod and if there is tick it or untick it
                Dim vwAss As New DataView(Me.tblProducts, "AssociatedWithProductCode='" & vw(0)("PrimaryProductCode") & "'", "", DataViewRowState.CurrentRows)
                If vwAss.Count <> 0 Then
                    Dim cbAss As CheckBox = CType(prodTable.FindControl("cbxSelectedProduct" & vwAss(0)("ProductRateId")), CheckBox)
                    cbAss.Checked = chk.Checked
                    cbAss.Enabled = chk.Checked
                End If
            Else
                'This is an assoicated product, make sure parent ticked
                Dim vwParent As New DataView(Me.tblProducts, "PrimaryProductCode='" & vw(0)("AssociatedWithProductCode") & "'", "", DataViewRowState.CurrentRows)
                Dim cbParent As CheckBox = CType(prodTable.FindControl("cbxSelectedProduct" & vwParent(0)("ProductRateId")), CheckBox)
                If chk.Checked Then
                    cbParent.Checked = True
                End If
            End If

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try
    End Sub

End Class
