﻿Imports System.Data.SqlClient
Imports System.Data

'Modification History
'31/01/11  Julian Gates   Initial version
'23/3/11   Julian Gates   SIR2395 - Add new CustomerStatement report
'25/3/11   Julian Gates   Fix date validation
'30/1/12    James Woosnam	SIR2588 - Add handling for AuditDebtorCreditors report
'16/02/18   Julian Gates    SIR4571 - Add New PEP Sales Report and Grouping update functionality
'30/10/19   Julian Gates    SIR4852 - Add ChangeAudit page link
'30/10/19   Julian Gates    SIR4944 - Add NonRecurringSubscriberRenewalReport page Link 
'3/4/20     James Woosnam   SIR5058 - Set defaults for the dates and stop start date beginning before 1/1/2020 for IJP Aged Debt
'17/02/21   Julian Gates    SIR5166 - Removed old asp page links

Partial Class Pages_pg450Reports
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim BatchLogViewOnly As Boolean = False

    Dim _tblProductGroupingTable As DataTable = Nothing
    Public ReadOnly Property tblProductGroupingTable As DataTable
        Get
            If Me._tblProductGroupingTable Is Nothing Then
                Dim rep As New BusinessLogic.ReportGroupedSales(Me.StartDate.Text, Me.EndDate.Text, Me.CompanyId.SelectedValue, uPage.db, Me.uPage.UserSession.UserSessionIdGUID)
                _tblProductGroupingTable = rep.ProductGroupingTable
            End If
            Return _tblProductGroupingTable
        End Get

    End Property


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Reports", "")
        Me.pageHeaderTitle.Text = "Reports"

        If Page.IsPostBack Then
            If Me.ProductGroupingTableRow.Visible Then
                BuildProductGroupingTable(Me.tblProductGroupingTable)
            End If
        Else
            If Me.Request.QueryString("RunSpecificReportName") <> "" Then
                BatchLogViewOnly = True
                RunSpecificReport(Me.Request.QueryString("RunSpecificReportName"))
            ElseIf Me.Request.QueryString("DoOrderDespatch") = "Yes" Then
                Me.pageHeaderTitle.Text = "Create Despatch Report"
                BatchLogViewOnly = True
                Dim SalesOrder As New BusinessLogic.SalesOrder(uPage.db, uPage.UserSession)
                ViewState("BatchJobId") = SalesOrder.SubmitDespatchSalesOrder(uPage.UserSession.Data("SubscribersToDespatchSQLColumns") _
                                                    , uPage.UserSession.Data("SubscribersToDespatchSQLFrom") _
                                                    , CStr(Me.Request.QueryString("DespatchDeliveryArea")) _
                                                    , CBool(Me.Request.QueryString("ReportOnly")) _
                                                    , CStr(Me.Request.QueryString("ProductCode"))
                                                    )

                Me.InfoMsg.Text = "Report has been submitted, See <a href=""../Pages/pg160BatchLogList.aspx?" & uPage.UserSession.QueryString & """ title=""Go To Batch Log List"">log</a> for details"
            ElseIf Me.Request.QueryString("DoAddBankDeposit") = "Yes" Then
                Me.pageHeaderTitle.Text = "Add Bank Deposit Processing"
                BatchLogViewOnly = True
                Dim BankDeposit As New BusinessLogic.BankDeposit(uPage.db, uPage.UserSession)
                ViewState("BatchJobId") = BankDeposit.SubmitAddFromCashbookIds(uPage.UserSession.Data("BankDepositCashbookIds") _
                                                    , CInt(Me.Request.QueryString("CompanyId")) _
                                                    , CStr(Me.Request.QueryString("BankAccountNumber")) _
                                                    , CStr(Me.Request.QueryString("BankSortCode")) _
                                                    , uPage.UserSession.Data("BankDepositNotes") _
                                                    , CBool(Me.Request.QueryString("SendReceipt")) _
                                                    , CDate(Me.Request.QueryString("DateBanked")) _
                                                    , CBool(Me.Request.QueryString("SettleWithCyberSource"))
                                                    )

                Me.InfoMsg.Text = "Add Deposit has been submitted, see progress below or in  <a href=""../Pages/pg160BatchLogList.aspx?" & uPage.UserSession.QueryString & """ title=""Batch Log "">log</a>"
            Else
                ReadRecord()
            End If
            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If

        End If

        Me.SubscriberMailingreportLink.NavigateUrl = "../Pages/pg460SubscriberMailingreport.aspx?" & uPage.UserSession.QueryString
        Me.SubscriberRenewalReportLink.NavigateUrl = "../Pages/pg461SubscriberRenewalReport.aspx?PageMode=SelectMode&" & uPage.UserSession.QueryString

        '30/10/19   Julian Gates    SIR4852 - Add ChangeAudit page link
        Me.ChangeAuditLink.NavigateUrl = "../Pages/pg463ChangeAudit.aspx?" & uPage.UserSession.QueryString
        '30/10/19   Julian Gates    SIR4944 - Add NonRecurringSubscriberRenewalReport page Link 
        Me.NonRecurringSubscriberRenewalReportLink.NavigateUrl = "../Pages/pg465NonRecurringSubscriberRenewalReport.aspx?" & uPage.UserSession.QueryString
    End Sub

    Sub PageSetup()
        If BatchLogViewOnly Then
            Me.ReportCriteriaPanel.Visible = False
        Else
            Me.ReportCriteriaPanel.Visible = True
        End If
        Me.TimedPanel.Visible = IsNumeric(ViewState("BatchJobId"))
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        'Populate all dropdown fields
        Me.uPage.PopulateDropDownListFromLookup(Me.ReportName, "GeneralReports", uPage.PrimaryConnection, "<--Select Report-->")

        Dim dropDownIntialValue As String = "<---------Select--------->"
        uPage.PopulateDropDownListFromSQL(Me.CompanyId, "SELECT Company.CompanyId as Value" _
                                                            & "    ,Company.CompanyName as Text" _
                                                            & " FROM " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                                                            & " ORDER BY 2" _
                                                            , uPage.PrimaryConnection, dropDownIntialValue
                                                            )
        'Default company if only one 
        If Me.CompanyId.Items.Count = 2 Then
            Me.CompanyId.SelectedValue = Me.CompanyId.Items(1).Value
            Me.CompanyId.Items.Remove(CompanyId.Items.FindByText(dropDownIntialValue))
        End If

    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else
                If Me.ReportName.SelectedValue = "" Then
                    uPage.FieldErrorControl(Me.ReportName, "Report Name is mandatory")
                End If

                If Me.CompanyId.SelectedValue = "" Then
                    uPage.FieldErrorControl(Me.CompanyId, "Company is mandatory")
                End If

                If Me.StartDate.Text.Trim = "" Then
                    uPage.FieldErrorControl(Me.StartDate, "Start Date is mandatory")
                End If

                If Me.EndDate.Text.Trim = "" Then
                    uPage.FieldErrorControl(Me.StartDate, "End Date is mandatory")
                End If

                If Me.StartDate.Text.Trim <> "" Then
                    If Not uPage.StdCode.IsValidDate(Me.StartDate.Text) Then
                        uPage.FieldErrorControl(Me.StartDate, "Start Date is an invalid date")
                    End If
                End If

                If Me.EndDate.Text.Trim <> "" Then
                    If Not uPage.StdCode.IsValidDate(Me.EndDate.Text) Then
                        uPage.FieldErrorControl(Me.StartDate, "End Date is an invalid date")
                    End If
                End If

                If Me.StartDate.Text.Trim <> "" _
                    And Me.EndDate.Text.Trim <> "" Then
                    If uPage.StdCode.IsValidDate(Me.StartDate.Text) _
                        And uPage.StdCode.IsValidDate(Me.EndDate.Text) Then
                        If CDate(Me.StartDate.Text) > CDate(Me.EndDate.Text) Then
                            uPage.FieldErrorControl(Me.StartDate, "Start Date must be before End Date")
                        End If
                    End If
                End If

                If Me.SubscriberIdPanel.Visible = True Then
                    If Me.SubscriberId.Text.Trim = "" Then
                        uPage.FieldErrorControl(Me.SubscriberId, "Subscriber Id is mandatory")
                    End If

                    If Me.SubscriberId.Text <> "" Then
                        If IsNumeric(Me.SubscriberId.Text.Trim) Then
                            Dim subcriberName As String = ""
                            subcriberName = uPage.db.IsDBNull(uPage.StdCode.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & Me.SubscriberId.Text.Trim & " AND SubscriberStatus = 'Current'", uPage.PrimaryConnection), "")
                            If subcriberName <> "" Then
                                Me.SubscriberName.Text = subcriberName
                            Else
                                uPage.PageError = "No Subscriber found for Subscriber Id " & Me.SubscriberId.Text
                                Me.SubscriberName.Text = ""
                            End If
                        Else
                            Me.SubscriberName.Text = ""
                            uPage.PageError = "Subscriber Id must be a numerical value"
                        End If
                    End If
                End If
        End Select

        Return uPage.IsValid
    End Function

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try

            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        PageSetup()
        uPage.PagePreRender()
    End Sub

    Private Sub SubmitReportBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubmitReportBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                Select Case ReportName.SelectedValue
                    Case "GroupedSales", "AgedDebtor", "FixedCashbook", "ProductSubscriptions"
                        Select Case ReportName.SelectedValue
                            Case "GroupedSales"
                                If Not Me.ProductGroupingTableRow.Visible Then
                                    'This builds the grid the first time submit is clicked only if ProductGroupingTable has 1 row
                                    If Me.ProductGroupingTable.Rows.Count = 1 Then
                                        BuildProductGroupingTable(Me.tblProductGroupingTable)
                                    End If
                                    Me.ProductGroupingTableRow.Visible = True
                                Else
                                    'Save any changes to SalesReportProductGrouping
                                    For Each rowtblPage As WebControls.TableRow In Me.ProductGroupingTable.Rows
                                        For Each cell As WebControls.TableCell In rowtblPage.Cells
                                            For Each cntl As Control In cell.Controls
                                                If Not cntl.ID Is Nothing Then
                                                    If cntl.ID.Contains("ProductCode") Then
                                                        Dim tb As WebControls.TextBox = cntl
                                                        Dim sql As String = ""
                                                        sql = "UPDATE Product SET SalesReportProductGrouping = '" & tb.Text & "' WHERE ProductCode = '" & Replace(cntl.ID, "ProductCode", "") & "'"
                                                        Me.uPage.db.ExecuteSQL(sql)
                                                    End If
                                                End If
                                            Next
                                        Next
                                    Next
                                    If uPage.IsValid Then
                                        '29/1/18    James       SIR4571 - new reports just need to submit - rest done in class so exit sub
                                        Dim rep As New BusinessLogic.ReportGroupedSales(Me.StartDate.Text, Me.EndDate.Text, Me.CompanyId.SelectedValue, uPage.db, Me.uPage.UserSession.UserSessionIdGUID)
                                        rep.Submit()
                                        ViewState("BatchJobId") = rep.BatchJob.BatchJobId
                                        Me.InfoMsg.Text = "Report has been submitted as batchjob, if you wish to view the batchlog please use the Batchlog link in main menu."
                                        Me.UpdateTimer.Enabled = True
                                    End If
                                End If
                            Case "AgedDebtor"
                                Me.ProductGroupingTableRow.Visible = False
                                If Me.CompanyId.SelectedValue = 1 Then
                                    If CDate(Me.StartDate.Text) < CDate("01-jan-2020") Then
                                        uPage.PageError = "For IJP start date must be 1/1/2020 or after"
                                        Exit Sub
                                    End If
                                End If
                                '29/1/18    James       SIR4571 - new reports just need to submit - rest done in class so exit sub
                                Dim rep As New BusinessLogic.ReportAgedDebtor(Me.StartDate.Text, Me.EndDate.Text, Me.CompanyId.SelectedValue, uPage.db, Me.uPage.UserSession.UserSessionIdGUID)
                                rep.Submit()
                                ViewState("BatchJobId") = rep.BatchJob.BatchJobId
                                Me.InfoMsg.Text = "Report has been submitted as batchjob, if you wish to view the batchlog please use the Batchlog link in main menu."
                                Me.UpdateTimer.Enabled = True
                            Case "FixedCashbook"
                                Me.ProductGroupingTableRow.Visible = False
                                '29/1/18    James       SIR4571 - new reports just need to submit - rest done in class so exit sub
                                Dim rep As New BusinessLogic.ReportFixedCashbook(Me.StartDate.Text, Me.EndDate.Text, Me.CompanyId.SelectedValue, uPage.db, Me.uPage.UserSession.UserSessionIdGUID)
                                rep.Submit()
                                ViewState("BatchJobId") = rep.BatchJob.BatchJobId
                                Me.InfoMsg.Text = "Report has been submitted as batchjob, if you wish to view the batchlog please use the Batchlog link in main menu."
                                Me.UpdateTimer.Enabled = True
                            Case "ProductSubscriptions"
                                Me.ProductGroupingTableRow.Visible = False
                                '29/1/18    James       SIR4571 - new reports just need to submit - rest done in class so exit sub
                                Dim rep As New BusinessLogic.ReportProductSubscriptions(Me.StartDate.Text, Me.EndDate.Text, Me.CompanyId.SelectedValue, uPage.db, Me.uPage.UserSession.UserSessionIdGUID)
                                rep.Submit()
                                ViewState("BatchJobId") = rep.BatchJob.BatchJobId
                                Me.InfoMsg.Text = "Report has been submitted as batchjob, if you wish to view the batchlog please use the Batchlog link in main menu."
                                Me.UpdateTimer.Enabled = True
                        End Select

                    Case Else
                        Me.ProductGroupingTableRow.Visible = False
                        Dim ReportType As String = Nothing
                        Dim TemplateName As String = Nothing
                        Select Case ReportName.SelectedValue
                            Case "Cashbook", "Sales", "Creditors", "AuditDebtorCreditors"
                                ReportType = "GenericPivot"
                                TemplateName = ReportName.SelectedValue & ".xltm"
                            Case "VAT"
                                ReportType = "GenericWord"
                                TemplateName = ReportName.SelectedValue & ".dotx"
                            Case "ChangedOrderAddress", "PEPWebStatsPreApr11", "PEPWebStatsPostApr11", "CustomerStatement"
                                ReportType = "GenericExcel"
                                TemplateName = "GenericExcel.xlsx"

                        End Select
                        Dim report As BusinessLogic.ReportGeneric = Nothing
                        report = New BusinessLogic.ReportGeneric(Me.ReportName.SelectedValue, ReportType, uPage.db, Me.uPage.UserSession.UserSessionIdGUID)
                        report.FileName = report.ReportName & " " & CDate(Me.StartDate.Text).ToString("dd-MMM-yy") & " to " & CDate(Me.EndDate.Text).ToString("dd-MMM-yy")

                        Select Case ReportName.SelectedValue
                            Case "CustomerStatement"
                                report.Submit(TemplateName, Me.GetSQL(report.ReportName, "Header", Me.CompanyId.SelectedValue, Me.StartDate.Text, Me.EndDate.Text, Me.SubscriberId.Text) _
                                                 , Me.GetSQL(report.ReportName, "Data", Me.CompanyId.SelectedValue, Me.StartDate.Text, Me.EndDate.Text, Me.SubscriberId.Text)
                                                 )
                            Case Else
                                report.Submit(TemplateName, Me.GetSQL(report.ReportName, "Header", Me.CompanyId.SelectedValue, Me.StartDate.Text, Me.EndDate.Text) _
                                                 , Me.GetSQL(report.ReportName, "Data", Me.CompanyId.SelectedValue, Me.StartDate.Text, Me.EndDate.Text)
                                                 )
                        End Select

                        ViewState("BatchJobId") = report.BatchJob.BatchJobId
                        Me.InfoMsg.Text = "Report has been submitted as batchjob, if you wish to view the batchlog please use the Batchlog link in main menu."
                        Me.UpdateTimer.Enabled = True
                End Select



            Catch ex As Exception
                uPage.PageError = "There was an unexpected problem genererating this report.  Please contact support." & ex.ToString
            End Try
        End If
    End Sub
    Private Function GetSQL(ByVal ReportName As String, ByVal SQLType As String, ByVal CompanyId As Integer, ByVal StartDate As Date, ByVal EndDate As Date, Optional ByVal SubscriberId As Integer = Nothing) As String
        Dim sqlColumns As String = ""
        Dim sqlFrom As String = ""
        Dim sqlWhere As String = ""
        Dim sqlGroup As String = ""
        Dim sqlOrderBy As String = ""
        Dim sqlData As String = ""
        Dim sqlHeader As String = ""
        Select Case ReportName
            Case "VAT"
                sqlColumns = "SELECT " _
                    & "		SUBSTRING(VATNumber,3,7999) AS VATNumber" _
                    & "		,Left(VATNumber,2) AS Code" _
                    & "		,cast(SUM( AmountInBase ) AS INT) as Amount"
                sqlFrom = " FROM vw420SubscriberTransactionsDetails SO"

                sqlWhere = " WHERE SO.CompanyId = " & CompanyId _
                   & " AND SO.[Date] BETWEEN " & uPage.db.vFQ(StartDate, "D") _
                   & "							 AND " & uPage.db.vFQ(EndDate, "D") _
                   & " AND SO.TransactionType in ('Order','OrderCancelled')" _
                   & " AND SO.CountryGroup =  'European Community'" _
                   & " AND ISNULL(SO.VATNumber,'') <> ''"
                sqlGroup = " GROUP BY " _
                   & "		SO.VATNumber"
                sqlOrderBy = " Order By 1"
                sqlData = sqlColumns _
                  & sqlFrom _
                  & sqlWhere _
                  & sqlGroup _
                  & sqlOrderBy

                sqlHeader = "SELECT '" & FormatDateTime(StartDate, vbShortDate) & "' As StartDate" _
                    & "		,'" & FormatDateTime(EndDate, vbShortDate) & "' As EndDate" _
                    & "		,CompanyName" _
                    & "		,VATNumber as CompanyVATNumber" _
                    & "		,CompanyName" _
                    & "		 ,BuildingStreet" _
                    & "		 ,Town" _
                    & "		 ,County" _
                    & "		 ,Postcode" _
                    & "		 ,CountryName As Country" _
                   & " FROM Company" _
                   & "		INNER JOIN Country" _
                   & "		ON Country.CountryID = Company.CountryId" _
                    & " WHERE CompanyId = " & CompanyId

            Case "Cashbook"
                sqlColumns = "SELECT *"
                sqlFrom = " FROM vw440Cashbook"
                sqlWhere = " WHERE vw440Cashbook.CompanyId = " & CompanyId _
                   & " AND vw440Cashbook.[BankedDate] BETWEEN " & uPage.db.vFQ(StartDate, "D") _
                   & "							 AND " & uPage.db.vFQ(EndDate, "D")
                sqlData = sqlColumns _
                  & sqlFrom _
                  & sqlWhere _
                  & sqlGroup _
                  & sqlOrderBy
                sqlHeader = "SELECT CompanyName" _
                   & "			,Convert(varchar,cast(" & uPage.db.vFQ(StartDate, "D") & " as DateTime),106) As StartDate" _
                   & "			,Convert(varchar,cast(" & uPage.db.vFQ(EndDate, "D") & " as DateTime),106) As EndDate" _
                   & " FROM Company" _
                   & " WHERE Company.CompanyId = " & CompanyId
            Case "Sales"
                sqlColumns = "SELECT *"
                sqlFrom = " FROM vw430SalesDetails"
                sqlWhere = " WHERE vw430SalesDetails.CompanyId = " & CompanyId _
                   & " AND vw430SalesDetails.[Date] BETWEEN " & uPage.db.vFQ(StartDate, "D") _
                   & "							 AND " & uPage.db.vFQ(EndDate, "D")
                sqlData = sqlColumns _
                  & sqlFrom _
                  & sqlWhere _
                  & sqlGroup _
                  & sqlOrderBy
                sqlHeader = "SELECT CompanyName" _
                   & "			,Convert(varchar,cast(" & uPage.db.vFQ(StartDate, "D") & " as DateTime),106) As StartDate" _
                   & "			,Convert(varchar,cast(" & uPage.db.vFQ(EndDate, "D") & " as DateTime),106) As EndDate" _
                   & " FROM Company" _
                   & " WHERE Company.CompanyId = " & CompanyId

            Case "Creditors", "AuditDebtorCreditors"
                '******************************************
                'JRW SQL Removed and replaced by Stored Procedure 6/11/02		
                '30/1/12    James Woosnam	SIR2588 - Add handling for AuditDebtorCreditors report

                sqlData = "EXEC sp451DebtorsReport @StartDate=" & uPage.db.vFQ(StartDate, "D") _
                         & ",@EndDate = " & uPage.db.vFQ(EndDate, "D") _
                         & ",@CompanyId = " & CompanyId
                If ReportName = "AuditDebtorCreditors" Then
                    sqlData += ",@ForAuditDebtorCreditorsReport = 1"
                End If
                '******************************************
                sqlHeader = "SELECT CompanyName" _
                   & "			,Convert(varchar,cast(" & uPage.db.vFQ(StartDate, "D") & " as DateTime),106) As StartDate" _
                   & "			,Convert(varchar,cast(" & uPage.db.vFQ(EndDate, "D") & " as DateTime),106) As EndDate" _
                   & " FROM Company" _
                   & " WHERE Company.CompanyId = " & CompanyId
            Case "ChangedOrderAddress"
                sqlColumns = "SELECT DISTINCT" _
                    & "	Company.CompanyId" _
                    & "	,subscriber.subscribername " _
                    & "	,subscriber.subscriberId " _
                    & "	,CompanyName" _
                    & "	,dbo.f530SubscriberAddressDisplay(subscriber.DefaultPostalAddressId,'SingleLine') DefaultAddress" _
                    & "	,dbo.f530SubscriberAddressDisplay(salesorderline.deliveryAddressId,'SingleLine') OrderAddress"

                sqlFrom = " FROM subscriber" _
                   & "	LEFT JOIN SubscriberAddress DefaultAddress" _
                   & "	On DefaultAddress.SubscriberAddressId = subscriber.DefaultPostalAddressId" _
                   & "	inner join salesorderline" _
                   & "		LEFT JOIN SubscriberAddress OrderAddress" _
                   & "		On OrderAddress.SubscriberAddressId = salesorderline.deliveryAddressId" _
                   & "		INNER JOIN SalesOrder" _
                   & "			INNER JOIN Company" _
                   & "			On Company.Companyid = SalesOrder.CompanyId" _
                   & "		On SalesOrder.OrderNumber = SalesOrderLine.OrderNumber" _
                   & "		AND SalesOrder.SalesOrderStatus not in ('Completed','Rejected','Cancelled')" _
                   & "	on subscriber.subscriberId = salesorderline.SubscriberId"

                sqlWhere = " WHERE Subscriber.DefaultPostalAddressId <> salesorderline.deliveryAddressId" _
                    & " AND (DefaultAddress.Address1 <> OrderAddress.Address1" _
                    & " 	OR DefaultAddress.Address2 <> OrderAddress.Address2" _
                    & " 	OR DefaultAddress.Address3 <> OrderAddress.Address3" _
                    & " 	OR DefaultAddress.Address4 <> OrderAddress.Address4" _
                    & " 	OR DefaultAddress.Town <> OrderAddress.Town" _
                    & " 	OR DefaultAddress.County <> OrderAddress.County" _
                    & " 	OR DefaultAddress.PostCode <> OrderAddress.PostCode)" _
                    & " AND ((SalesOrder.CompanyId = 1 AND SalesOrder.PrimaryProductCode >= 'JV 84') or SalesOrder.CompanyId = 2)" _
                    & " AND SalesOrder.CompanyId =" & CompanyId _
                    & " AND SalesOrder.[OrderDate] BETWEEN " & uPage.db.vFQ(StartDate, "D") _
                    & "							 AND " & uPage.db.vFQ(EndDate, "D")
                sqlOrderBy = " Order By SubscriberName"


                sqlHeader = sqlColumns & sqlFrom & sqlWhere & sqlOrderBy
                sqlData = sqlHeader
            Case "PEPWebStatsPreApr11"
                '5/3/07		James Woosnam	Move PEPWebStatsPreApr11 SQL to a view
                sqlColumns = "SELECT vw450WebProductStatistics.*"

                sqlFrom = " FROM vw450WebProductStatistics "

                sqlWhere = " WHERE vw450WebProductStatistics.[Date] BETWEEN " & uPage.db.vFQ(StartDate, "D") _
                    & "							 AND " & uPage.db.vFQ(EndDate, "D")

                sqlOrderBy = " Order by 1 desc "

                sqlHeader = sqlColumns & sqlFrom & sqlWhere & sqlOrderBy
                sqlData = sqlHeader
            Case "PEPWebStatsPostApr11"
                '5/3/07		James Woosnam	Move PEPWebStatsPreApr11 SQL to a view
                '27/7/14    James Woosnam   SIR3577 - Change to sp as adding country upset performance
                sqlWhere = " EXEC sp452WebProductStatisticsFromPEPWebUsageLog " & uPage.db.vFQ(StartDate, "D") _
                    & "							 , " & uPage.db.vFQ(EndDate, "D")

                sqlHeader = sqlWhere
                sqlData = sqlWhere
            Case "CustomerStatement"
                '23/3/11		Julian Gates SIR2395 - Add vw420SubscriberTransactionsDetails
                sqlColumns = "SELECT vw420SubscriberTransactionsDetails.*"

                sqlFrom = " FROM vw420SubscriberTransactionsDetails "

                sqlWhere = " WHERE vw420SubscriberTransactionsDetails.[Date] BETWEEN " & uPage.db.vFQ(StartDate, "D") _
                    & "							 AND " & uPage.db.vFQ(EndDate, "D") _
                    & " AND CompanyId = " & CompanyId _
                    & " AND SubscriberId = " & SubscriberId

                sqlOrderBy = " Order by 1 desc "

                sqlHeader = sqlColumns & sqlFrom & sqlWhere & sqlOrderBy
                sqlData = sqlHeader

        End Select
        Select Case SQLType
            Case "Header"
                Return sqlHeader
            Case "Data"
                Return sqlData
            Case Else
                Return ""
        End Select
    End Function

    Private Sub RunSpecificReport(ByVal ReportName As String)
        Dim sql As String = ""
        Dim TemplateName As String = ""
        Dim ReportCriteria As String = Request.QueryString("ReportCriteria")
        Dim ReportType As String = ""
        Dim FileName As String = ""
        Try
            Select Case ReportName
                Case "Invoice"
                    If ReportCriteria = "" Then
                        Throw New Exception("ReportName:" & ReportName & " must pass ReportCriteria")
                    End If
                    sql = "SELECT *" _
                        & " FROM vw400InvoiceSummaryAll " _
                        & " WHERE 1=1 " _
                        & " AND " & ReportCriteria

                    Dim row As DataRow = uPage.db.GetDataTableFromSQL("SELECT CompanyId,OrderNumber FROM SalesOrder WHERE " & ReportCriteria).Rows(0)
                    TemplateName = "Invoice" & row("CompanyId") & "Summary.dot"
                    FileName = ReportName & " for OrderNumber" & row("OrderNumber")
                    ReportType = "GenericWord"

                Case "InvoiceDetail"
                    If ReportCriteria = "" Then
                        Throw New Exception("ReportName:" & ReportName & " must pass ReportCriteria")
                    End If
                    sql = "SELECT *" _
                        & " FROM vw405InvoiceDetailAll " _
                        & " WHERE 1=1 " _
                        & " AND " & ReportCriteria
                    Dim row As DataRow = uPage.db.GetDataTableFromSQL("SELECT CompanyId,OrderNumber FROM SalesOrder WHERE " & ReportCriteria).Rows(0)
                    TemplateName = "Invoice" & row("CompanyId") & "Detail.dot"
                    FileName = ReportName & " for OrderNumber" & row("OrderNumber")
                    ReportType = "GenericWord"

                Case "Receipt"
                    If ReportCriteria = "" Then
                        Throw New Exception("ReportName:" & ReportName & " must pass ReportCriteria")
                    End If
                    sql = "SELECT vw410ReceiptHead.*" _
                        & " FROM vw410ReceiptHead " _
                        & " WHERE 1=1 " _
                        & " AND " & ReportCriteria
                    Dim row As DataRow = uPage.db.GetDataTableFromSQL("SELECT CompanyId,CashbookId FROM Cashbook WHERE " & ReportCriteria).Rows(0)
                    TemplateName = "Receipt" & row("CompanyId") & ".dot"
                    FileName = ReportName & " for ReceiptNo" & row("CashbookId")
                    ReportType = "GenericWord"
                Case Else
                    Throw New Exception("Specific Report:'" & ReportName & " is not handled")
            End Select


            Dim report As BusinessLogic.ReportGeneric = Nothing
            report = New BusinessLogic.ReportGeneric(ReportName, ReportType, uPage.db, Me.uPage.UserSession.UserSessionIdGUID)
            report.FileName = FileName
            report.Submit(TemplateName, sql, sql)

            ViewState("BatchJobId") = report.BatchJob.BatchJobId
            Me.UpdateTimer.Enabled = True

            Me.InfoMsg.Text = "Report has been submitted, See <a href=""../Pages/pg160BatchLogList.aspx?" & uPage.UserSession.QueryString & """ title=""Go To Batch Log List"">log</a> for details"

        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub

    Protected Sub UpdateTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateTimer.Tick
        Try
            If IsNumeric(ViewState("BatchJobId")) Then
                Dim BatchLog As New BusinessLogic.BatchLog(uPage.db)
                Me.BatchLogLines.Text = BatchLog.GetBatchLogLinesHTML(ViewState("BatchJobId"))
                Select Case uPage.db.IsDBNull(uPage.db.DLookup("MAX(BatchLogStatus)", "BatchLog", "BatchJobId=" & ViewState("BatchJobId")), "")
                    Case "Failed"
                        Me.UpdateTimer.Enabled = False
                    Case "Complete"
                        Me.UpdateTimer.Enabled = False
                        If Me.Request.QueryString("DoAddBankDeposit") = "Yes" Then
                            Response.Redirect("pg171BankDepositMaint.aspx?PageMode=Update" _
                                              & "&BankDepositId=" & uPage.db.DLookup("MAX(BankDepositId)", "BankDeposit", "") _
                                              & "&" & uPage.UserSession.QueryString)
                        End If
                    Case Else
                        Me.UpdateTimer.Enabled = True
                End Select
            Else
                Me.UpdateTimer.Enabled = False
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub

    Protected Sub ReportName_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ReportName.SelectedIndexChanged
        '3/4/20     James Woosnam   SIR5058 - Set defaults for the dates and stop start date beginning before 1/1/2020 for IJP Aged Debt
        Me.SubscriberId.Text = ""
        Me.SubscriberName.Text = ""
        Me.ProductGroupingTableRow.Visible = False
        Me.SubscriberIdPanel.Visible = False
        Select Case Me.ReportName.SelectedValue.ToUpper
            Case "CUSTOMERSTATEMENT".ToUpper
                Me.SubscriberIdPanel.Visible = True
                Me.SubscriberId.Focus()
            Case "GroupedSales".ToUpper
                Me.ProductGroupingTableRow.Visible = True
            Case Else

        End Select

        If Me.StartDate.Text = "" Then Me.StartDate.Text = "01-Jan-" & Now.ToString("yyyy")
        If Me.EndDate.Text = "" Then Me.EndDate.Text = Now.AddDays(1).ToString("dd-MMM-yyyy")

        ViewState("BatchJobId") = Nothing
        Me.InfoMsg.Text = Nothing
    End Sub

    Protected Sub SubscriberId_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles SubscriberId.TextChanged
        If IsPageValidForStatus("") Then
            Me.CompanyId.Focus()
        End If
    End Sub

    Sub BuildProductGroupingTable(ByRef ProductGroupingDataTable As DataTable)
        Try
            If Me.ProductGroupingTable.Rows.Count = 1 Then
                For Each row As DataRow In ProductGroupingDataTable.Rows
                    Dim tRow As New WebControls.TableRow
                    Dim cell As New WebControls.TableCell
                    tRow.ID = row("ProductCode")
                    cell = New WebControls.TableCell
                    cell.Text = row("ProductCode")
                    tRow.Cells.Add(cell)
                    cell = New WebControls.TableCell
                    cell.Text = row("ProductName")
                    tRow.Cells.Add(cell)
                    cell = New WebControls.TableCell
                    Dim tb As New WebControls.TextBox
                    tb.Width = "300"
                    tb.CssClass = "pageField"
                    tb.ID = row("ProductCode") & "ProductCode"
                    If Not row("SalesReportProductGrouping") Is System.DBNull.Value Then
                        '  If ProductGroupingTableRow.Visible = False Then
                        tb.Text = row("SalesReportProductGrouping")
                        '  End If
                        tb.EnableViewState = True
                    End If
                    cell.Controls.Add(tb)
                    tRow.Cells.Add(cell)

                    Me.ProductGroupingTable.Rows.Add(tRow)
                Next
            End If


        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

End Class
