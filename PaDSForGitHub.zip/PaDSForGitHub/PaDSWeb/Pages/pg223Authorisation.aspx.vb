﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'20/01/11  Julian Gates   Initial version
'28/01/14   Julian Gates    SIR3398 - Add functionality to order zero value products.
'19/03/15   Julian Gates    SIR3785 - Rework Prev button link to go to Spanish order page if IsSpanishIJPESSubscriber
'14/05/15   Julian Gates    SIR3838 - Call new Salesorder.SendEmailReceipt in ProcessZeroValueOrders for zero orders
'03/07/15   Julian Gates    SIR3895 - Call SendEmailReceipt for non zero value orders and update cashbook EmailReceiptDateTime field
'23/10/15   Julian Gates    SIR3895 - Change ProductLinkText message after credit card authorisation
'26/2/18    Julian Gates    SIR4588 - Add Payment card fields to AuthenticateCreditCard
'16/1/20    James Woosnam   SIR4995 -  Detect error correctly

Partial Class Pages_pg223Authorisation
    Inherits System.Web.UI.Page
    Dim pageMode As String = ""
    Dim StdCode As New BusinessLogic.StdCode()
    Public End5AccessText As String = ""

    Private _SalesOrder As BusinessLogic.SalesOrder = Nothing
    Public Property SalesOrder() As BusinessLogic.SalesOrder
        Get
            If Me._SalesOrder Is Nothing Then
                Me._SalesOrder = New BusinessLogic.SalesOrder(Me.txtOrderNumber.Value, Me.Master.db, Me.Master.UserSession)
            End If
            Return Me._SalesOrder
        End Get
        Set(ByVal value As BusinessLogic.SalesOrder)
            Me._SalesOrder = value
        End Set
    End Property

    Private _Cashbook As BusinessLogic.Cashbook = Nothing
    Public Property Cashbook() As BusinessLogic.Cashbook
        Get
            If Me._Cashbook Is Nothing Then
                Me._Cashbook = New BusinessLogic.Cashbook(Me.Master.db, Me.Master.UserSession)
            End If
            Return Me._Cashbook
        End Get
        Set(ByVal value As BusinessLogic.Cashbook)
            Me._Cashbook = value
        End Set
    End Property

    Public Property DisplayLanguage As BusinessLogic.UserSession.DisplayLanguages
        Get
            Return Me.Master.UserSession.DisplayLanguage
        End Get
        Set(value As BusinessLogic.UserSession.DisplayLanguages)
            Me.Master.UserSession.DisplayLanguage = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Master.Initilise("Order Confirmation", "06", "")
        Master.ShowLanguageRBL = True

        If Request.QueryString("PageType") <> "" Then
            Me.txtPageType.Value = Request.QueryString("PageType")
        End If

        If Request.QueryString("OrderNumber") <> "" Then
            Me.txtOrderNumber.Value = Request.QueryString("OrderNumber")
        End If

        If Request.QueryString("ProductCode") <> "" Then
            Me.txtProductCode.Value = Request.QueryString("ProductCode")
        End If

        If Request.QueryString("CashbookId") <> "" Then
            Me.Cashbook = New BusinessLogic.Cashbook(CInt(Request.QueryString("CashbookId")), Master.db, Master.UserSession)
            pageMode = "Update"
        ElseIf Me.Master.WebForm.db.DLookup("CashbookId", "Cashbook", "SubscriberId=" & Me.Master.UserSession.Data("SubscriberId") & "AND CashbookStatus = 'Partial'") <> Nothing Then
            Me.Cashbook = New BusinessLogic.Cashbook(CInt(Me.Master.WebForm.db.DLookup("CashbookId", "Cashbook", "SubscriberId=" & Me.Master.UserSession.Data("SubscriberId") & "AND CashbookStatus = 'Partial'")), Master.db, Master.UserSession)
            pageMode = "Update"
        Else
            Me.Cashbook = New BusinessLogic.Cashbook(Master.db, Master.UserSession)
            pageMode = "Add"
        End If

        If Page.IsPostBack Then
            Me.SalesOrder.MainDataset = CType(ViewState("MainDataSet"), DataSet)
        Else
            If Me.Master.WebForm.IsValid Then
                ReadRecord()
            End If
            Me.PaymentCardType.Focus()
        End If
        PageSetup()

        'Used to display animation when processing credit card and hide confirm button
        Me.progressImage.Style.Add("display", "none")
        ConfirmBtn.OnClientClick = "document.getElementById('" + progressImage.ClientID + "').style.display = ''; document.getElementById('" + ConfirmBtn.ClientID + "').style.display = 'none';"

    End Sub

    Sub PageSetup()

        Me.Master.PageTitle = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Order Confirmation" _
                               , "Confirmación De Su Compra")
        Me.CVNumberHelpLink.NavigateUrl = "javascript:CVNumberHelpPopupWindow(""../HelpFiles/CVNumberHelp.htm"")"

        '28/01/14   Julian Gates    SIR3398 - If Zero value order then hide credit card fields
        If Me.AmountGross.Text = "0.00" And Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus") <> "Confirmed" Then
            Me.InsertCreditCardDetailsPanel.Visible = False
            Me.ConfirmZeroOrderBtn.Visible = True
        Else
            Me.ConfirmZeroOrderBtn.Visible = False
        End If
        Me.ConfirmBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Confirm" _
                               , "Confirmar")

        Me.ConfirmZeroOrderBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Confirm" _
                               , "Confirmar")

        Me.PrevBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Prev" _
                               , "Atrás")

        Me.HomeBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                              , "Home" _
                              , "Inicio")

        Me.CVNumberHelpLink.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                              , "What is the security code?" _
                              , "¿Qué es el Código de Seguridad?")
    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else

                Me.Master.WebForm.DropDownValidateMandatory(Me.PaymentCardType, "Card Type", "Es obligación escribir un Tipo de Tarjeta")
                Me.Master.WebForm.FieldValidateMandatory(Me.PaymentCardNumber, "Card Number", "Es obligación escribir su Número de tarjeta")
                Me.Master.WebForm.FieldValidateMandatory(Me.PaymentCardExpiryDate, "Expiry Date", "Es obligación escribir su Fecha de Expiración")
                Me.Master.WebForm.FieldValidateMandatory(Me.PaymentCardName, "Name on Card", "Es obligación escribir su Nombre del Titular de su Tarjeta")

                If Me.PaymentCardExpiryDate.Text <> "" Then
                    If Len(Me.PaymentCardExpiryDate.Text) <> 5 Then
                        Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                              , "Expiry must be MM-YY" _
                              , "La fecha de expiración debe ser en el formato MM-AA"))
                    Else
                        If Not IsNumeric(Left(Me.PaymentCardExpiryDate.Text, 2)) Then
                            Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                              , "Expiry Month invalid" _
                              , "Mes de Expiración Inválido"))
                        Else
                            If CLng(Left(Me.PaymentCardExpiryDate.Text, 2)) < 1 _
                              Or CLng(Left(Me.PaymentCardExpiryDate.Text, 2)) > 12 Then
                                Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                              , "Expiry Month invalid" _
                              , "Mes de Expiración Inválido"))
                            End If
                        End If
                        If Not IsNumeric(Mid(Me.PaymentCardExpiryDate.Text, 4)) Then
                            Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                             , "Expiry Year invalid" _
                             , "Año de Expiración Inválido"))
                        End If
                    End If
                End If
                If Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English Then
                    Me.Master.WebForm.FieldValidateNumber(Me.PaymentCardCVNumber, True, "Security Code")
                End If
                If Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.Spanish Then
                    If Me.PaymentCardCVNumber.Text = "" Then
                        Me.Master.WebForm.AddPageError("Es obligación escribir su Código de Seguridad")
                        Me.PaymentCardCVNumber.CssClass = "fldEntryError"
                    Else
                        If Not IsNumeric(Me.PaymentCardCVNumber.Text) Then
                            Me.Master.WebForm.AddPageError("El código de seguridad debe ser un valor numérico")
                            Me.PaymentCardCVNumber.CssClass = "fldEntryError"
                        Else
                            Me.PaymentCardCVNumber.CssClass = "pageField"
                        End If
                    End If
                End If

                If Me.PaymentCardCVNumber.Text <> "" _
                    And Me.PaymentCardType.SelectedValue <> "" Then
                    Select Case Me.PaymentCardType.SelectedValue
                        Case "American Express"
                            If Len(Me.PaymentCardCVNumber.Text) < 4 Then
                                Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                    , "Security Code for American Express must be 4 numbers form the front of your card" _
                                    , "El Código de Seguridad para American Express son los 4 números que aparecen en la cara frontal de su tarjeta."))
                            End If
                        Case Else
                            If Len(Me.PaymentCardCVNumber.Text) < 3 Then
                                If Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English Then
                                    Me.Master.WebForm.AddPageError("Security Code for " & Me.PaymentCardType.SelectedValue & " must be the last 3 numbers from the back of your card")
                                End If
                                If Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.Spanish Then
                                    Me.Master.WebForm.AddPageError("El Código de Seguridad para " & Me.PaymentCardType.SelectedValue & " son los tres últimos número en el reverso de su tarjeta")
                                End If
                            End If
                    End Select
                End If

        End Select

        Return Me.Master.WebForm.IsValid

    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        If pageMode = "Update" Then
            Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.Cashbook.CashbookRow)
        End If

        'Read in Order Summary
        Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.SalesOrder.SalesOrderRow)
        Me.AmountGross.Text = Format(Me.SalesOrder.SalesOrderRow("AmountGross"), "0.00")

        'populate dropdowns
        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria and Order by
        '15/11/19   James Woosnam   SIR4949 - Hard code to PEP company (2) for CC transactions
        Me.Master.WebForm.PopulateDropDownListFromSQL(Me.PaymentCardType, "SELECT LookupItemKey as Value" _
                                                                    & "     , Name As Text" _
                                                                    & " FROM Lookup" _
                                                                    & " WHERE LookupName = 'RemoteCreditCardType'" _
                                                                    & " AND LookupStatus = 'Active'" _
                                                                    & " AND CompanyId = 2" _
                                                                    & " ORDER BY DisplayOrder,Name,LookupItemKey" _
                                                                    , "<--Select-->")

    End Sub

    Protected Sub ConfirmBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ConfirmBtn.Click
        'Calls ProcessCreditCard using javascript
    End Sub

    Protected Sub ConfirmZeroOrderBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ConfirmZeroOrderBtn.Click
        '28/01/14   Julian Gates    SIR3398 - Process zedro value orders
        ProcessZeroValueOrders()
    End Sub


    Protected Sub ProcessCreditCard(ByVal sender As Object, ByVal e As EventArgs)
        If Me.IsPageValidForStatus("") Then
            Try
                If Me.Cashbook.CashbookId = Nothing Then
                    Me.Cashbook.RemoteAdd(Me.txtOrderNumber.Value,
                                       Me.SalesOrder.SalesOrderRow,
                                       Me.PaymentCardType.Text,
                                       Me.PaymentCardNumber.Text,
                                       Me.PaymentCardName.Text,
                                       Me.PaymentCardExpiryDate.Text,
                                       Me.PaymentCardCVNumber.Text
                                       )
                Else
                    Me.Master.WebForm.PopulateDataRowFromPageFields(Me.Cashbook.CashbookRow)
                    '19/5/11    James Woosnam   Update Cashbook currency and amaount as they are not on the page
                    Me.Cashbook.CashbookRow("CurrencyCode") = Me.SalesOrder.SalesOrderRow.Item("CurrencyCode")
                    Me.Cashbook.CashbookRow("Amount") = Me.SalesOrder.SalesOrderRow.Item("AmountGross")
                    Me.Cashbook.Save()
                End If

                'Call Cybersource from here
                Try
                    '26/2/18    Julian Gates    SIR4588 - Add Payment card fields to AuthenticateCreditCard
                    Me.Cashbook.AuthenticateCreditCard(Me.PaymentCardNumber.Text,
                                                        Me.PaymentCardCVNumber.Text)

                    Select Case Me.Cashbook.CashbookRow("CashbookStatus")
                        Case "Confirmed"
                            'The request succeeded
                            Me.AuthorisationText.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                              , "Your credit card has been authorised and your order has been placed.<br /> Please make a note of your order number. A confirmation email has been sent to your registered email address." _
                              , "Su tarjeta de crédito ha sido autorizada y su compra está siendo procesada. Por favor guarde su número de compra. Un correo electrónico de confirmación ha sido enviado a su dirección de correo electrónico.")
                            Me.InsertCreditCardDetailsPanel.Visible = False
                            Me.WarningTable.Visible = False
                            Me.HomeBtn.Visible = True
                            Me.PrevBtn.Visible = False
                            Me.ConfirmBtn.Visible = False
                            '03/07/15   Julian Gates    SIR3895 - Call SendEmailReceipt for non zero value orders and update cashbook EmailReceiptDateTime
                            'Call new SendEmailReceipt 
                            Me.SalesOrder.SendEmailReceipt()
                            Cashbook.CashbookRow("EmailReceiptDateTime") = Now()
                            Me.Cashbook.Save()
                        Case "Partial"
                            Me.Master.WebForm.AddPageError(Me.Cashbook.AuthorisationRejectMsg)

                        Case Else
                            Throw New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                    , "Unexpected cashbook status: " _
                                                    , "Estado inesperado del libro de caja: ") & Me.Cashbook.CashbookRow("CashbookStatus"))
                    End Select
                Catch ex As Exception
                    Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                    , "Credit Card authorisation has caused a system error, please wait 1 minute and try again." _
                    & " If authorisation is still failing Email PEP Sales on <a href='mailto:sales@p-e-p.org'>sales@p-e-p.org</a>" _
                    & " who will be able to see what has happened online and advise what is necessary" _
                    & " to complete your order." _
                    , "La autorización de su tarjeta de crédito ha producido un error en nuestro sistema. Por favor espere 1 minuto y vuelva a intentarlo." _
                    & " Si la autorización sigue fallando, escriba a Ventas PEP al correo electrónico <a href='mailto:sales@p-e-p.org'>sales@p-e-p.org</a>," _
                    & " quienes podrán en línea ver qué ocurrió con su pedido y guiarle sobre los pasos necesarios para completar su compra."), ex))
                End Try

                Select Case Me.Cashbook.CashbookRow("CashbookStatus")
                    Case "Confirmed"
                        For Each row In Me.SalesOrder.SalesOrderLine.Rows
                            Select Case row("ProductCode")
                                Case Else
                                    Me.WebProductLinkText.Text = ProductLinkText
                            End Select
                        Next
                        Me.WebProductLinkRow.Visible = True
                End Select

            Catch ex As Exception
                Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                    , "Credit authorisation failed: " _
                                                    , "La autorización de su tarjeta de crédito ha fallado: "), ex))
            End Try
        End If
    End Sub

    Sub ProcessZeroValueOrders()
        Try
            Me.SalesOrder.SalesOrderRow.Item("IsPaid") = 1
            Me.SalesOrder.SalesOrderRow.Item("SalesOrderStatus") = "Confirmed"
            Me.SalesOrder.Save()
            'Call new SendEmailReceipt in ProcessZeroValueOrders for zero orders
            Me.SalesOrder.SendEmailReceipt()
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                    , "Zero value order confirmation failed: " _
                                                    , "La confirmación de compra de valor cero ha fallado: "), ex))
        End Try
        '16/1/20    James Woosnam   SIR4995 -  Detect error correctly
        If Me.Master.WebForm.IsValid Then
            For Each row In Me.SalesOrder.SalesOrderLine.Rows
                Select Case row("ProductCode")
                    Case Else
                        Me.WebProductLinkText.Text = ProductLinkText()
                End Select
            Next
            Me.ConfirmZeroOrderBtn.Visible = False
            Me.WebProductLinkRow.Visible = True
            Me.HomeBtn.Visible = True
            Me.PrevBtn.Visible = False
            Me.AuthorisationText.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                    , "A confirmation email has been sent to your registered email address." _
                                                    , "Un correo electrónico de confirmación ha sido enviado a su dirección de correo electrónico.")
        End If
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.SalesOrder.MainDataset
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    Protected Sub PrevBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles PrevBtn.Click
        Dim sQry As String = ""
        sQry = Me.Master.UserSession.QueryString
        sQry += "&pageMode=" & Me.txtPageType.Value
        sQry += "&CompanyId=" & Me.SalesOrder.SalesOrderRow("CompanyId")
        Select Case Me.txtPageType.Value
            Case "NewOrder"
                If Session("UsedOrderPageType") = "Spanish" Then
                    Response.Redirect("../pages/pg233RemoteOrderSpanish.aspx?" & sQry)
                Else
                    Response.Redirect("../pages/pg232RemoteOrder.aspx?" & sQry)
                End If
            Case "RenewOrder"
                sQry += "&ProductCode=" & Me.txtProductCode.Value
                If Session("UsedOrderPageType") = "Spanish" Then
                    Response.Redirect("../pages/pg233RemoteOrderSpanish.aspx?" & sQry)
                Else
                    Response.Redirect("../pages/pg232RemoteOrder.aspx?" & sQry)
                End If
        End Select

    End Sub

    Protected Sub HomeBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles HomeBtn.Click
        Response.Redirect("../pages/pg101Home.aspx?" & Me.Master.UserSession.QueryString)
    End Sub


    Protected Function ProductLinkText() As String
        '23/10/15   Julian Gates    SIR3895 - Change ProductLinkText message after credit card authorisation
        ProductLinkText = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                    , "If you have ordered a web product, please use this link <a href='http://www.pep-web.org/login.php' target=_blank>http://www.pep-web.org/login.php</a> to access it." _
                                                       & " You will have to enter your PaDS username and password into the appropriate boxes and you will then have immediate access." _
                                                    , "Si usted ha comprado un producto web, por favor use el siguiente link para acceder a él: <a href='http://www.pep-web.org/login.php' target=_blank>http://www.pep-web.org/login.php</a>. Usted tendrá que ingresar su usuario y contraseña PaDS en los cuadros correspondientes y así tendrá acceso inmediato")
        Return ProductLinkText
    End Function
End Class
