﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'11/02/11  Julian Gates   Initial New version
'20/5/11   Julian Gates   Add functinality to cancel confirmed cashbook
'23/5/11   Julian Gates   SIR2436 - Add section to show CC Authorise status and reject message
'31/5/11    James Woosnam   Show bank fields for bank draft
'26/2/18    Julian Gates    SIR4588 - Add Payment card fields to AuthenticateCreditCard
'22/5/20    James Woosnam   SIR5068 - various changes to Add to support the changes in the SIR
'19/08/20   Julian Gates    SIR5099 - Add Audit link
'28/01/21   Julian Gates    SIR5180 - Show cancel button for 30 days from entry date
'05/02/21   Julian Gates    SIR5180 - Changed logic to hide Cancel button if Cashbook has been banked and show Cashbook Cancel Info Text

Partial Class Pages_pg151CashbookMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim pageMode As String = ""
    Public subscriberROFields As String = ""
    Public orderNumberROField As String = ""
    Public paymentTypeROField As String = ""

    Private _Cashbook As BusinessLogic.Cashbook = Nothing
    Public Property Cashbook() As BusinessLogic.Cashbook
        Get
            If Me._Cashbook Is Nothing Then
                Me._Cashbook = New BusinessLogic.Cashbook(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._Cashbook
        End Get
        Set(ByVal value As BusinessLogic.Cashbook)
            Me._Cashbook = value
        End Set
    End Property

    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                Me._Subscriber = New BusinessLogic.Subscriber(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property

    Private _BankDeposit As BusinessLogic.BankDeposit = Nothing
    Public Property BankDeposit() As BusinessLogic.BankDeposit
        Get
            If Me._BankDeposit Is Nothing Then
                Me._BankDeposit = New BusinessLogic.BankDeposit(Me.uPage.db, Me.uPage.UserSession)
            End If
            Return Me._BankDeposit
        End Get
        Set(ByVal value As BusinessLogic.BankDeposit)
            Me._BankDeposit = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Cashbook Maintenance ", "")
        Me.pageHeaderTitle.Text = "Cashbook Maintenance "

        If Request.QueryString("CashbookId") <> "" Then
            pageMode = "Update"
        Else
            pageMode = "Add"
        End If

        If Request.QueryString("CompanyId") <> "" Then
            Me.txtCompanyId.Value = Request.QueryString("CompanyId")
        End If

        If Request.QueryString("SubscriberId") <> "" Then
            Me.txtSubscriberId.Value = Request.QueryString("SubscriberId")
        End If

        If Request.QueryString("OrderNumber") <> "" Then
            Me.txtOrderNumber.Value = Request.QueryString("OrderNumber")
        End If

        If Page.IsPostBack Then
            Me.Cashbook.MainDataset = CType(ViewState("MainDataSet"), DataSet)
            'Me.txtPaymentType.Value = Me.Cashbook.MainDataset.Tables("CashBook").Rows(0).Item("PaymentType").ToString
        Else
            If Request.QueryString("CashbookId") <> "" Then
                Try
                    Me.txtCashbookId.Value = Request.QueryString("CashbookId")
                    Me.Cashbook = New BusinessLogic.Cashbook(CInt(Request.QueryString("CashbookId")), Me.uPage.db, Me.uPage.UserSession)
                Catch ex As Exception
                    Me.uPage.PageError = "Invalid Parameter has been passed in"
                End Try
                pageMode = "Update"
                Me.EntryDate.Focus()
            Else
                pageMode = "Add"
                Me.CompanyId.Focus()
            End If

            If Me.uPage.IsValid Then
                ReadRecord()
            End If
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

    End Sub

    Sub PageSetup()
        Select Case pageMode
            Case "Add"
                Me.CashbookAddPanel.Visible = True
                Me.CashbookUpdatePanel.Visible = False
                Me.CashbookUpdateFieldsPanel.Visible = False
                Me.BankDetailsUpdateFieldsPanel.Visible = False
                Me.CashbookROFieldsPanel.Visible = False
                Me.BankDetailsROFieldsPanel.Visible = False
                Me.AuditPanel.Visible = False
                Me.NotesFieldPanel.Visible = False
                Me.ButtonsPanel.Visible = False
                Me.PaymentTypeRow.Visible = Me.EntryType.SelectedValue = "Payment"
                Me.BankDepositPanel.Visible = False
            Case ("Update")
                Me.GetPaymentTypeROFieldHTML(uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("PaymentType"), ""))
                Me.CashbookAddPanel.Visible = False
                Me.CashbookUpdatePanel.Visible = True

                Select Case Me.Cashbook.CashbookRow.Item("CashbookStatus")
                    Case "Partial"
                        Me.CashbookUpdateFieldsPanel.Visible = True
                        Me.CashbookROFieldsPanel.Visible = False
                        Me.ButtonsPanel.Visible = True
                        CancelBtn.Attributes.Add("onclick", "if(confirm('Are you sure you want to cancel this Cashbook record?')){}else{return false}")

                        Select Case Me.Cashbook.CashbookRow.Item("EntryType").ToString.ToUpper
                            Case "PAYMENT"
                                Select Case Me.txtPaymentType.Value
                                    Case "Credit Card"
                                        Me.PaymentDetailsUpdateFieldsPanel.Visible = True
                                        Me.PaymentDetailsROFieldsPanel.Visible = False
                                        Me.BankDetailsUpdateFieldsPanel.Visible = False
                                        Me.BankDetailsROFieldsPanel.Visible = False
                                        If Me.PaymentCardMerchant.SelectedValue.ToUpper = "CYBERSOURCE" Then
                                            Me.AutoAuthorisePanel.Visible = True
                                        Else
                                            Me.AutoAuthorisePanel.Visible = False
                                        End If
                                        Me.PaymentROFieldPanel.Visible = False
                                        Me.PaymentROFieldPanel1.Visible = False
                                    Case "Cheque", "Bank Draft"
                                        Me.BankDetailsUpdateFieldsPanel.Visible = True
                                        Me.BankDetailsROFieldsPanel.Visible = False
                                        Me.PaymentDetailsUpdateFieldsPanel.Visible = False
                                        Me.PaymentDetailsROFieldsPanel.Visible = False
                                        Me.PaymentROFieldPanel.Visible = False
                                        Me.PaymentROFieldPanel1.Visible = False
                                    Case Else
                                        Me.PaymentDetailsROFieldsPanel.Visible = False
                                        Me.PaymentDetailsUpdateFieldsPanel.Visible = False
                                        Me.BankDetailsUpdateFieldsPanel.Visible = False
                                        Me.BankDetailsROFieldsPanel.Visible = False
                                        Me.PaymentROFieldPanel.Visible = False
                                        Me.PaymentROFieldPanel1.Visible = True
                                End Select
                            Case Else
                                Me.PaymentDetailsROFieldsPanel.Visible = False
                                Me.BankDetailsUpdateFieldsPanel.Visible = False
                                Me.BankDetailsROFieldsPanel.Visible = False
                                Me.PaymentDetailsUpdateFieldsPanel.Visible = False
                        End Select

                    Case Else
                        Me.CashbookUpdateFieldsPanel.Visible = False
                        Me.CashbookROFieldsPanel.Visible = True
                        Me.ButtonsPanel.Visible = False

                        Select Case Me.Cashbook.CashbookRow.Item("EntryType").ToString.ToUpper
                            Case "PAYMENT"
                                Select Case Me.txtPaymentType.Value
                                    Case "Credit Card"
                                        Me.PaymentDetailsUpdateFieldsPanel.Visible = False
                                        Me.BankDetailsUpdateFieldsPanel.Visible = False
                                        Me.PaymentDetailsROFieldsPanel.Visible = True
                                        Me.BankDetailsROFieldsPanel.Visible = False
                                        Me.PaymentROFieldPanel.Visible = False
                                        Me.PaymentROFieldPanel1.Visible = False
                                    Case "Cheque", "Bank Draft"
                                        Me.BankDetailsUpdateFieldsPanel.Visible = False
                                        Me.PaymentDetailsUpdateFieldsPanel.Visible = False
                                        Me.PaymentDetailsROFieldsPanel.Visible = False
                                        Me.BankDetailsROFieldsPanel.Visible = True
                                        Me.PaymentROFieldPanel.Visible = False
                                        Me.PaymentROFieldPanel1.Visible = False
                                    Case Else
                                        Me.AutoAuthorisePanel.Visible = False
                                        Me.PaymentDetailsROFieldsPanel.Visible = False
                                        Me.PaymentDetailsUpdateFieldsPanel.Visible = False
                                        Me.BankDetailsUpdateFieldsPanel.Visible = False
                                        Me.BankDetailsROFieldsPanel.Visible = False
                                        Me.PaymentROFieldPanel1.Visible = True
                                End Select
                            Case Else
                                Me.PaymentDetailsROFieldsPanel.Visible = False
                                Me.BankDetailsUpdateFieldsPanel.Visible = False
                                Me.BankDetailsROFieldsPanel.Visible = False
                                Me.PaymentROFieldPanel.Visible = False
                                Me.PaymentROFieldPanel1.Visible = True
                        End Select
                End Select

                Select Case Me.Cashbook.CashbookRow.Item("CashbookStatus")
                    Case "Confirmed"
                        Me.ReceiptPromptPanel.Visible = True
                        Me.ReceiptLink.Visible = True
                        Me.ReceiptLink.Target = "blank"
                        Me.ReceiptLink.NavigateUrl = "../Pages/pg450Reports.aspx" _
                                                    & "?RunSpecificReportName=Receipt" _
                                                    & "&ReportCriteria=CashbookId=" & Me.txtCashbookId.Value & "&" & uPage.UserSession.QueryString

                        '20/5/11 Julian Gates Add functinality to cancel confirmed cashbook
                        '05/02/21   Julian Gates    SIR5180 - Changed logic to hide Cancel button if Cashbook has been banked and show Cashbook Cancel Info Text
                        If uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("BankDepositId"), Nothing) = Nothing Then
                            Me.ButtonsPanel.Visible = True
                            Me.ConfirmBtn.Visible = False
                            Me.SaveBtn.Visible = False
                            CancelBtn.Attributes.Add("onclick", "if(confirm('Are you sure you want to cancel this Cashbook record?')){}else{return false}")
                            Me.CashbookCancelInfoText.Visible = True
                        End If
                    Case Else
                        Me.ReceiptPromptPanel.Visible = False
                        Me.ReceiptLink.Visible = False
                End Select

                '23/5/11  Julian Gates SIR2436 - Add section to show CC Authorise status and reject message
                If uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("PaymentCardAuthorisationStatus"), "") <> "" Then
                    Me.AutorisationStatusPanel.Visible = True
                    If Me.Cashbook.CashbookRow.Item("PaymentCardAuthorisationStatus") = "Rejected" Then
                        Me.PaymentCardRejectDescriptionPrompt.Visible = True
                        Me.PaymentCardRejectDescription.Visible = True
                    Else
                        Me.PaymentCardRejectDescriptionPrompt.Visible = False
                        Me.PaymentCardRejectDescription.Visible = False
                    End If
                Else
                    Me.AutorisationStatusPanel.Visible = False
                End If

                '26/10/20   Julian Gates   Add BankDeposit data
                If uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("BankDepositId"), Nothing) <> Nothing Then
                    Me.BankDepositId.NavigateUrl = "../pages/pg171BankDepositMaint.aspx?BankDepositId=" & Me.Cashbook.CashbookRow.Item("BankDepositId") & "&" & uPage.UserSession.QueryString
                    Me.BankDepositId.ToolTip = "View Bank Deposit"
                    Me.BankDepositPanel.Visible = True
                End If

                '19/08/20   Julian Gates    SIR5099 - Add Audit link
                Me.AuditLink.NavigateUrl = "../pages/pg040AuditLogDisplay.aspx?FltrUpdatedRecordFamily=Cashbook&FltrUpdatedRecordFamilyKey=" & Me.Cashbook.CashbookId & "&" & uPage.UserSession.QueryString
                Me.AuditLink.Text = "View Audit"
                Me.AuditLink.ToolTip = "View Audit for this record"
        End Select

    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case "Cancel"
                If Me.EntryDate.Text = "" Then
                    uPage.PageError = "Please add an Entry Date"
                End If

                If Me.EntryDate.Text <> "" Then
                    uPage.FieldValidateDate(Me.EntryDate)
                End If

                If Me.CurrencyCode.SelectedValue = "" Then
                    uPage.FieldErrorControl(Me.CurrencyCode, "Currency is mandatory")
                End If

            Case Else
                Select Case pageMode
                    Case "Add"
                        If Me.CompanyId.SelectedValue = "" Then
                            uPage.FieldErrorControl(Me.CompanyId, "Company is mandatory")
                        End If

                        If Me.EntryType.SelectedValue = "" Then
                            uPage.FieldErrorControl(Me.EntryType, "Entry Type is mandatory")
                        End If

                        If Me.PaymentType.SelectedValue = "" And Me.PaymentType.Visible Then
                            uPage.FieldErrorControl(Me.PaymentType, "Payment Type is mandatory")
                        End If

                    Case "Update"
                        If Me.Cashbook.CashbookRow.Item("CashbookStatus") = "Partial" Then
                            If Me.EntryDate.Text = "" Then
                                uPage.PageError = "Please add an Entry Date"
                            End If

                            If Me.EntryDate.Text <> "" Then
                                uPage.FieldValidateDate(Me.EntryDate)
                            End If

                            If Me.CurrencyCode.SelectedValue = "" Then
                                uPage.FieldErrorControl(Me.CurrencyCode, "Currency is mandatory")
                            End If

                            If Me.Amount.Text = "" Then
                                uPage.FieldErrorControl(Me.Amount, "Amount is mandatory")
                            End If
                            Select Case Me.Cashbook.CashbookRow.Item("EntryType").ToString.ToUpper
                                Case "PAYMENT"
                                    If Me.txtPaymentType.Value = "Credit Card" Then
                                        If Me.PaymentCardMerchant.SelectedValue = "" Then
                                            uPage.FieldErrorControl(Me.PaymentCardMerchant, "Merchant is mandatory")
                                        End If
                                    End If
                                    If Me.AutoAuthorisePanel.Visible = True _
                                    And Me.txtPaymentType.Value = "Credit Card" _
                                    And Me.PaymentCardMerchant.SelectedValue.ToUpper = "CYBERSOURCE" Then
                                        If Me.AutoAuthorise.SelectedValue = "" Then
                                            uPage.FieldErrorControl(Me.AutoAuthorise, "Authorise with Cybersource is mandatory")
                                        End If
                                    End If

                                    If Me.txtPaymentType.Value <> "" Then
                                        If Me.txtPaymentType.Value = "Credit Card" _
                                         And Me.PaymentCardMerchant.SelectedValue.ToUpper = "CYBERSOURCE" _
                                         And Me.AutoAuthorise.SelectedValue = "Yes" Then

                                            If Me.PaymentCardType.SelectedValue = "" Then
                                                uPage.FieldErrorControl(Me.PaymentCardType, "Card Type is mandatory")
                                            End If
                                            If Me.PaymentCardNumber.Text = "" Then
                                                uPage.FieldErrorControl(Me.PaymentCardNumber, "Number is mandatory")
                                            End If
                                            If Me.PaymentCardName.Text = "" Then
                                                uPage.FieldErrorControl(Me.PaymentCardName, "Name is mandatory")
                                            End If

                                            If Me.PaymentCardExpiryDate.Text = "" Then
                                                uPage.FieldErrorControl(Me.PaymentCardExpiryDate, "Expiry Date is mandatory")
                                            End If

                                            If Me.PaymentCardExpiryDate.Text <> "" Then
                                                If Len(Me.PaymentCardExpiryDate.Text) <> 5 Then
                                                    uPage.PageError = "Expiry must be MM-YY"
                                                Else
                                                    If Not IsNumeric(Left(Me.PaymentCardExpiryDate.Text, 2)) Then
                                                        uPage.PageError = "Expiry Month invalid"
                                                    Else
                                                        If CLng(Left(Me.PaymentCardExpiryDate.Text, 2)) < 1 _
                                                          Or CLng(Left(Me.PaymentCardExpiryDate.Text, 2)) > 12 Then
                                                            uPage.PageError = "Expiry Month invalid"
                                                        End If
                                                    End If
                                                    If Not IsNumeric(Mid(Me.PaymentCardExpiryDate.Text, 4)) Then
                                                        uPage.PageError = "Expiry Year invalid"
                                                    End If
                                                End If
                                            End If

                                            If Me.PaymentCardCVNumber.Text <> "" _
                                             And Me.PaymentCardType.SelectedValue <> "" Then
                                                Select Case Me.PaymentCardType.SelectedValue
                                                    Case "American Express"
                                                        If Len(Me.PaymentCardCVNumber.Text) < 4 Then
                                                            uPage.PageError = "Security Code for American Express must be 4 numbers form the front of credit card"
                                                        End If
                                                    Case Else
                                                        If Len(Me.PaymentCardCVNumber.Text) < 3 Then
                                                            uPage.PageError = "Security Code for " & Me.PaymentCardType.SelectedValue & " must be the last 3 numbers from the back of credit card"
                                                        End If
                                                End Select
                                            End If
                                        End If
                                    End If

                            End Select
                        End If
                End Select
        End Select
        Return uPage.IsValid
    End Function

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        'Populate dropdown fields

        Select Case pageMode
            Case "Add"
                'Populate dropdown fields

                uPage.PopulateDropDownListFromSQL(Me.CompanyId, "SELECT DISTINCT Company.CompanyId as Value" _
                                                                   & "    , Company.CompanyName as Text" _
                                                                   & " FROM " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                                                                   & " ORDER BY 2" _
                                                                  , uPage.PrimaryConnection, "<--Select-->"
                                                                  )
                Me.CompanyId.SelectedValue = Me.txtCompanyId.Value

                Me.GetSubscriberFieldsHTML(Me.txtSubscriberId.Value, uPage.db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & Me.txtSubscriberId.Value))

                Me.uPage.PopulateDropDownListFromLookup(Me.PaymentType, "PaymentType", uPage.PrimaryConnection, "<--Select-->")

            Case "Update"
                'Populate dropdown fields
                uPage.PopulateDropDownListFromSQL(Me.CurrencyCode, "SELECT DISTINCT Currency.CurrencyCode as Value" _
                                                                   & "    , Currency.Description as Text" _
                                                                   & " FROM Currency" _
                                                                   & " ORDER BY 2" _
                                                                  , uPage.PrimaryConnection, "<--Select-->" _
                                                                )
                '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria and order by
                uPage.PopulateDropDownListFromSQL(Me.PaymentCardType, "SELECT Lookup.LookupItemKey as Value" _
                                                                    & "    , Lookup.Name as Text" _
                                                                    & " FROM Lookup" _
                                                                    & " WHERE LookupName = 'PaymentCardType'" _
                                                                    & " AND CompanyId = " & Me.Cashbook.CashbookRow.Item("CompanyId") _
                                                                    & " AND LookupStatus = 'Active'" _
                                                                    & " ORDER BY DisplayOrder,Name,LookupItemKey" _
                                                                  , uPage.PrimaryConnection, "<--Select-->"
                                                                )
                '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria  and order by
                uPage.PopulateDropDownListFromSQL(Me.PaymentCardMerchant, "SELECT Lookup.LookupItemKey as Value" _
                                                                   & "    , Lookup.Name as Text" _
                                                                   & " FROM Lookup" _
                                                                   & " WHERE LookupName = 'PaymentCardMerchant'" _
                                                                   & " AND CompanyId = " & Me.Cashbook.CashbookRow.Item("CompanyId") _
                                                                   & " AND LookupStatus = 'Active'" _
                                                                   & " ORDER BY DisplayOrder,Name,LookupItemKey" _
                                                                 , uPage.PrimaryConnection, "<--Select-->"
                                                               )

                'Read in subscriber details
                Me.Subscriber = New BusinessLogic.Subscriber(CInt(Me.Cashbook.CashbookRow.Item("SubscriberId")), Me.uPage.db, Me.uPage.UserSession)
                Me.GetSubscriberFieldsHTML(Me.Subscriber.SubscriberRow.Item("SubscriberId"), Me.Subscriber.SubscriberName)
                Me.GetOrderNumberFieldHTML(uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("OrderNumber"), ""))
                'add PaymentType to hidden field
                Me.txtPaymentType.Value = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("PaymentType"), "")

                Me.uPage.PopulatePageFieldsFromDataRow(Me.Cashbook.CashbookRow)

                Me.txtCompanyId.Value = Me.Cashbook.CashbookRow("CompanyId")
                Me.CompanyRO.Text = uPage.db.IsDBNull(Me.uPage.db.DLookup("CompanyName", "Company", "CompanyId=" & Me.Cashbook.CashbookRow("CompanyId")), "")

                Me.EntryTypeRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("EntryType"), "")

                Select Case Me.Cashbook.CashbookRow.Item("CashbookStatus")
                    Case "Partial"
                        Me.uPage.PopulateDropDownListFromLookup(Me.AutoAuthorise, "YesNo", uPage.PrimaryConnection, "<--Select-->")
                    Case Else
                        'populate RO cashbook fields
                        Me.EntryDateRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("EntryDate"), "")
                        Me.CurrencyCodeRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("CurrencyCode"), "")
                        Me.AmountRO.Text = Format(uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("Amount"), 0), "0.00")
                        Me.PaymentCardTypeRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("PaymentCardType"), "")
                        Me.PaymentCardMerchantRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("PaymentCardMerchant"), "")
                        Me.PaymentCardNumberRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("PaymentCardNumber"), "")
                        Me.PaymentCardNameRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("PaymentCardName"), "")
                        Me.PaymentCardExpiryDateRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("PaymentCardExpiryDate"), "")
                        Me.PaymentCardAuthorisationCodeRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("PaymentCardAuthorisationCode"), "")
                        Me.PaymentCardCVNumberRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("PaymentCardCVNumber"), "")
                        'Populate RO Bank detail fields
                        Me.ChequeNumberRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("ChequeNumber"), "")

                        Me.BankAccountNumberRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("BankAccountNumber"), "")
                        Me.BankAccountNameRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("BankAccountName"), "")
                        Me.BankSortCodeRO.Text = uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("BankSortCode"), "")
                End Select

                '26/10/20   Julian Gates   Add BankDeposit data
                If uPage.db.IsDBNull(Me.Cashbook.CashbookRow.Item("BankDepositId"), Nothing) <> Nothing Then
                    Me.BankDeposit = New BusinessLogic.BankDeposit(CInt(Me.Cashbook.CashbookRow.Item("BankDepositId")), Me.uPage.db, Me.uPage.UserSession)
                    Me.BankDepositId.Text = Me.BankDeposit.BankDepositRow.Item("BankDepositId")
                    Me.DateBanked.Text = Me.BankDeposit.BankDepositRow.Item("DateBanked")
                End If
        End Select
    End Sub

    Sub SaveRecord(Optional ByVal SaveType As String = Nothing)
        '******************************************************
        'Description:	Save the record either by updating
        '******************************************************
        Dim saveMessage As String = ""
        Try
            Select Case pageMode
                Case "Add"
                    'Cashbook


                    Me.Cashbook.InternalAdd(Me.txtOrderNumber.Value,
                                            Me.CompanyId.SelectedValue,
                                            Me.txtSubscriberId.Value,
                                            Me.EntryType.SelectedValue,
                                           IIf(Me.EntryType.SelectedValue = "Contra", "Contra", Me.PaymentType.SelectedValue)
                                           )
                    Me.txtCashbookId.Value = Me.Cashbook.CashbookId

                Case "Update"
                    Me.uPage.PopulateDataRowFromPageFields(Me.Cashbook.CashbookRow)
                    Me.Cashbook.CashbookRow("CompanyId") = Me.txtCompanyId.Value
                    Me.Cashbook.CashbookRow("PaymentType") = Me.txtPaymentType.Value
                    Me.Cashbook.CashbookRow("LastUpdatedDateTime") = Now()
                    Me.Cashbook.CashbookRow("LastUpdatedByUserId") = uPage.UserSession.UserName20
                    Select Case SaveType
                        Case "Cancel"
                            Me.Cashbook.CashbookRow("CashbookStatus") = "Cancelled"
                            Me.Cashbook.CashbookRow("Amount") = 0
                        Case "Confirm"
                            If Me.AutoAuthorise.SelectedValue = "Yes" Then
                                Me.Cashbook.CashbookRow("PaymentCardAuthorisationStatus") = "Pending"
                            Else
                                Me.Cashbook.CashbookRow("CashbookStatus") = "Confirmed"
                            End If
                    End Select

                    Me.Cashbook.Save()

                    If SaveType = "Confirm" _
                     And Me.AutoAuthorise.SelectedValue = "Yes" Then
                        Try
                            '26/2/18    Julian Gates    SIR4588 - Add Payment card fields to AuthenticateCreditCard
                            Me.Cashbook.AuthenticateCreditCard(Me.PaymentCardNumber.Text,
                                                               Me.PaymentCardCVNumber.Text)

                            Select Case Me.Cashbook.CashbookRow("CashbookStatus")
                                Case "Confirmed"
                                    'The request succeeded
                                    saveMessage = "Credit card has been authorised, this record has been saved"

                                Case "Partial"
                                    'The request rejected
                                    uPage.PageError = "This record has been Saved, but authorisation failed " & Me.Cashbook.AuthorisationRejectMsg

                                Case Else
                                    Throw New Exception("Unexpacted cashbook status:" & Me.Cashbook.CashbookRow("CashbookStatus"))
                            End Select
                        Catch ex As Exception
                            Me.uPage.PageError = "Credit Card authorisation has caused a system error, please wait 1 minute and try again."
                           
                        End Try

                        'Select Case Me.Cashbook.CyberSourceDecision
                        '    Case "ACCEPT"
                        '        Me.Cashbook.CashbookRow("PaymentCardAuthorisationReturnText") = Me.Cashbook.CyberSourceReasonCode
                        '        Me.Cashbook.CashbookRow("PaymentCardAuthorisationStatus") = "Accepted"
                        '        Me.Cashbook.CashbookRow("PaymentCardAuthorisationCode") = "" 'varReply("requestID")
                        '        Me.Cashbook.CashbookRow("CashbookStatus") = "Confirmed"
                        '        saveMessage = "This record has been Saved"
                        '    Case "ERROR"
                        '        saveMessage = "This record has been Saved, but authorisation failed"
                        'End Select

                        'Me.Cashbook.Save()

                    End If
            End Select

        Catch ex As Exception
            Me.uPage.PageError = "Save Record failed " & ex.ToString
        End Try

        If Me.uPage.IsValid Then
            Select Case SaveType
                Case "Confirm"
                    Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=" & saveMessage & "&CashbookId=" & Me.txtCashbookId.Value & "&PageMode=Update&" & uPage.UserSession.QueryString)
                Case Else
                    Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=This record has been saved&CashbookId=" & Me.txtCashbookId.Value & "&PageMode=Update&" & uPage.UserSession.QueryString)
            End Select

        End If

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        ViewState("MainDataSet") = Me.Cashbook.MainDataset
        PageSetup()
        uPage.PagePreRender()
    End Sub

    Protected Sub SaveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                SaveRecord()
            Catch ex As Exception
                uPage.PageError = ex.ToString
            End Try
        End If
    End Sub

    Protected Sub AddBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AddBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                SaveRecord()
            Catch ex As Exception
                uPage.PageError = ex.ToString
            End Try
        End If
    End Sub

    Protected Sub CancelBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelBtn.Click
        If Me.IsPageValidForStatus("Cancel") Then
            Try
                SaveRecord("Cancel")
            Catch ex As Exception
                uPage.PageError = ex.ToString
            End Try
        End If
    End Sub

    Protected Sub ConfirmBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ConfirmBtn.Click
        If Me.IsPageValidForStatus("") Then
            Try
                SaveRecord("Confirm")
            Catch ex As Exception
                uPage.PageError = ex.ToString
            End Try
        End If
    End Sub

    Protected Sub PaymentCardMerchant_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles PaymentCardMerchant.SelectedIndexChanged
        PageSetup()
    End Sub

    Protected Sub PaymentType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles PaymentType.SelectedIndexChanged
        Select Case Me.PaymentType.SelectedValue
            Case "Credit Card"
                Me.PaymentCardMerchant.Focus()
            Case "Cheque", "Bank Draft"
                Me.ChequeNumber.Focus()
        End Select
        PageSetup()
    End Sub

    Sub GetSubscriberFieldsHTML(ByVal subscriberId As String, ByVal subscriberName As String)

        Dim html As String = ""

        html += "<tr> "
        html += "   <td valign='top' class='fldPrompt'>Subscriber:</td>"
        html += "   </td>"
        html += "   <td class='fldView'>"
        html += "       <a href='../Pages/pg111SubscriberDisplay.aspx?SubscriberId=" & subscriberId & "&" & uPage.UserSession.QueryString & "'>" & subscriberId & "</a>"
        html += "       &nbsp;" & subscriberName
        html += "   </td>"
        html += "</tr>"

        subscriberROFields = html
    End Sub

    Sub GetOrderNumberFieldHTML(ByVal orderNumber As String)

        Dim html As String = ""

        html += "<tr> "
        html += "   <td valign='top' class='fldPrompt'>Order Number:</td>"
        html += "   </td>"
        html += "   <td class='fldView'>"
        html += orderNumber
        html += "   </td>"
        html += "</tr>"

        orderNumberROField = html
    End Sub

    Sub GetPaymentTypeROFieldHTML(ByVal paymentType As String)

        Dim html As String = ""
        html += "<tr>"
        html += "   <td colspan='2'>"
        html += "       <H3>Payment Details</H3>"
        html += "   </td>"
        html += "</tr>"
        html += "<tr>"
        html += "   <td valign='top' class='fldPrompt'>Payment Type:</td>"
        html += "   </td>"
        html += "   <td class='fldView'>"
        html += paymentType
        html += "   </td>"
        html += "</tr>"

        paymentTypeROField = html
    End Sub
End Class
