﻿Imports System.Data
Imports System.Data.SqlClient
'Modification History
'13/10/08  Julian Gates   Initial version
'14/09/09  Julian Gates   SIR2017 - Add Begins With filter for search string
'18/10/10   Mike Sheard     SIR2250 - Read data from database in registry

Partial Class pages_pg160BatchLogList
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Public ListTableHtml As String = ""
    Public PageHtml As String = ""
    Dim ds As New DataSet
    Dim tbl As DataTable

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Batch Log List", "")
        Me.pageHeaderTitle.Text = "Batch Log List"

        If Page.IsPostBack Then

        Else
            Me.uPage.PopulateDropDownListFromLookup(Me.FltrStatus, "BatchLogStatus", uPage.PrimaryConnection, "--All--")
            Me.uPage.PopulateDropDownListFromSQL(Me.FltrBatchLogType, "SELECT Distinct BatchLogType Value, BatchLogType Text From BatchLog ORDER BY BatchLogType", uPage.PrimaryConnection, "--All--")
            Me.FltrBatchLogType.Focus()
            Me.RecordsToShow.Text = "20"
        End If
        If Me.IsPageValidForStatus("") Then
            ListTableHtml = GetListTable()
        End If
    End Sub
    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            uPage.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else
                
        End Select
        Me.uPage.FieldValidateNumber(Me.RecordsToShow)
        Return Me.uPage.IsValid
    End Function

    Function GetListTable() As String
        Dim listSQL As String = ""

        Dim stdCode As New BusinessLogic.StdCode

        If Me.ViewState("PageNumber") = Nothing Then
            Me.ViewState("PageNumber") = 1
        End If

        If Me.txtGotoPageNum.Value <> "" Then
            Me.ViewState("PageNumber") = Me.txtGotoPageNum.Value
        End If

        listSQL = "EXEC sp160BatchLogList"
        listSQL += "      @FltrBatchLogType='" & Me.FltrBatchLogType.SelectedValue & "'"
        listSQL += "      ,@FltrDescription='" & uPage.GetBeginsWithSearch(Me.FltrDescription.Text, Me.FltrBeginsWith.Checked) & "'"
        listSQL += "      ,@FltrBatchLogStatus='" & Me.FltrStatus.SelectedValue & "'"

        tbl = uPage.GetListDatatable(ViewState("PageNumber"), Me.RecordsToShow.Text, PageHtml _
                                                        , listSQL _
                                                        , uPage.PrimaryConnection, True)
        Dim html As String = ""
        Dim dateTime As String = ""

        If tbl.Rows.Count > 0 Then
            For Each row As DataRow In tbl.Rows
                Select Case Me.uPage.UserSession.AuthorityLevel
                    Case BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                        html += "<tr>"
                        html += "<td><a href='../pages/pg161BatchLogLines.aspx" & "?BatchLogId=" & uPage.db.IsDBNull(row("BatchLogId"), "") & "&PageMode=Update"
                        html += "&" & uPage.UserSession.QueryString
                        html += "' title='View Batch Log Lines'>" & uPage.db.IsDBNull(row("BatchLogId"), "") & "</a>"
                        html += "</td>"
                    Case Else
                        If uPage.UserSession.Data("UserSessionId") = row("SubmittedByUserSessionId").ToString.ToUpper Then
                            html += "<tr class='highlightLine'>"
                            html += "<td><a href='../pages/pg161BatchLogLines.aspx" & "?BatchLogId=" & uPage.db.IsDBNull(row("BatchLogId"), "") & "&PageMode=Update"
                            html += "&" & uPage.UserSession.QueryString
                            html += "' title='View Batch Log Lines'>" & uPage.db.IsDBNull(row("BatchLogId"), "") & "</a>"
                            html += "</td>"
                        Else
                            html += "<td>&nbsp;</td>"
                        End If
                End Select
                html += "<td class='fldView'>" & row("BatchLogType") & "</td>"
                Dim sDescription As String = row("Description")
                If sDescription.IndexOf(vbCrLf) = -1 And sDescription.Length > 55 Then
                    Dim iLineCount As Int16 = 1
                    Do While sDescription.Length > iLineCount * 55
                        sDescription = sDescription.Insert(iLineCount * 55, "<br>")
                        iLineCount += 1
                    Loop

                Else
                    sDescription = sDescription.Replace(vbCrLf, "<br>")
                End If
                html += "<td width='410' class='fldView'>" & sDescription & "</td>"
                html += "<td class='fldView'>" & row("BatchLogStatus") & "</td>"
                html += "<td class='fldView'>" & row("DateTime") & "</td>"
                html += "<td class='fldView'>" & uPage.GetProcessTime(row("DateTime"), uPage.db.IsDBNull(row("EndDateTime"), "")) & "</td>"
                html += "</tr>"
            Next
        Else
            Me.uPage.PageError = "No records found for selected criteria"
        End If

        Return html

    End Function

    Protected Sub ClearBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ClearBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?" & uPage.UserSession.QueryString)
    End Sub

    Private Sub ProcessBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProcessBtn.Click
        Me.txtGotoPageNum.Value = 1
        'GetListTable()
    End Sub

    Protected Sub FltrBatchLogType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles FltrBatchLogType.SelectedIndexChanged
        Me.txtGotoPageNum.Value = 1
        GetListTable()
        Me.FltrBatchLogType.Focus()
    End Sub

    Protected Sub FltrBeginsWith_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles FltrBeginsWith.CheckedChanged
        Me.txtGotoPageNum.Value = 1
    End Sub

End Class
