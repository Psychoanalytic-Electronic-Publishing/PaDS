﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'21/01/11  Julian Gates   Initial version
'19/03/15   Julian Gates    SIR3785 - Modify page to show spanish errors if IsSpanishIJPESSubscriber

Partial Class Pages_pg234TermsAndConditions
    Inherits System.Web.UI.Page
    Dim pageMode As String = ""
    Dim StdCode As New BusinessLogic.StdCode()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Me.Master.Initilise("Terms and Conditions", "00", "")

        If Me.Master.UserSession.Data("IsSpanishIJPESSubscriber") Then
            Me.Master.PageTitle = "Términos y condiciones"
            Me.RemoteOrderTermsTitle.Text = "Términos y condiciones para " & Request.QueryString("ProductName") & " producto"
        Else
            Me.Master.PageTitle = "Terms and Conditions"
            Me.RemoteOrderTermsTitle.Text = "Terms and Conditions for " & Request.QueryString("ProductName") & " Product"
        End If

        RemoteProductTermsTextDisplay()
    End Sub

    Sub PageSetup()
        If Me.Master.UserSession.Data("IsSpanishIJPESSubscriber") Then
            Me.Close.Value = "Cerca"
        End If
    End Sub

    Sub RemoteProductTermsTextDisplay()
        Try
            Me.RemoteOrderTermsText.Text = Me.Master.WebForm.GetImportFileText(Me.Master.db.GetParameterValue("TermsConditionsDirectoryPhysicalPath") & Request.QueryString("TCFileName"))

        Catch ex As Exception
            If Me.Master.UserSession.Data("IsSpanishIJPESSubscriber") Then
                Me.Master.WebForm.AddPageError(New Exception("Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia", ex))
            Else
                Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured.  Please contact support", ex))
            End If
        End Try
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub
End Class
