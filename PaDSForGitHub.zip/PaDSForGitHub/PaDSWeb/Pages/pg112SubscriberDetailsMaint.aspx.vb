﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.RemoteUser

'Modification History
'18/01/11  Julian Gates   Initial version
'30/3/11   Julian Gates   SIR2401 - Add new functionality to Separate PEP and IJP Addresses
'10/5/11   Julian Gates   SIR2421 - Add code to Save to handle Null Firstname and Lastname
'21/6/11   Julian Gates   Modification: Save entered passwords in viewstate to repopulate field if error.
'22/6/11   Julian Gates   SIR2459 - Add additional mandatory validation and CountyUSA field.
'23/6/11   Julian Gates - Show 4 lines error message in SaveRecord to user.
'18/7/11   Julian Gates - Bug fix handle Null values in read record
'20/7/11   Julian Gates - Bug fix handle US county code being mixed case for some users.
'02/11/11  Julian Gates - Update error handling
'28/11/11  Julian Gates - Show Building Street Address individual lines must be less than 50 characters message to user in sub save record
'24/09/12  Julian Gates   SIR2865 - Check if subscriber DefaultPostalAddressId is populated if not populate in save
'26/2/13    Julian Gates    SIR3024 - Remove mandatory phone number validation
'03/10/14   Julian Gates    SIR3621 - Add IsReceiveEmail field.
'19/03/15   Julian Gates    SIR3785 - Add Me.Master.UserSession.Data("IsSpanishIJPESSubscriber")to change back link to new spanish order page
'31/07/15   Julian Gates    SIR3898 - Disable Non US & Canada mandatory validation and rename Town and County prompts to City and State.
'17/08/17   Julian Gates    SIR4478 - Handle Username Or Password update changes and notify user to wait 24-48 hours.
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields and associated code
'29/10/19   Julian Gates    SIR4768 - Removed VATNumber, MailMethod, Operating system.
'29/10/19   Julian Gates    SIR4763 - Remove WebUserName and WebUserPassword fields and add Email Change confirmation.
'05/12/19   James Woosnam   SIR4949 - use passed in companyId when going back to remote Order screen
'13/1/20    James Woosnam   SIR4977 - Show UserName And allow updates If different To email
'17/1/20    Julian Gates    SIR4998 - Add Send Password Reset Email" button and associated code
'28/4/20    Julian Gates    SIR5032 - Add spanish translation
'24/8/20    Julian Gates    SIR5119 - Remove Postal from address field prompts.
'27/12/20   James Woosnam   SIR5171 - Check subscriber status as well as HasOrIsAProposedSubscriber
'8/1/21     James Woosnam   SIR5143 - Make address optional and add AreAdressesSame functionality

Partial Class Pages_pg112SubscriberDetailsMaint
    Inherits System.Web.UI.Page
    Dim pageMode As String = ""
    Dim StdCode As New BusinessLogic.StdCode()

    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                If Me.IsPostBack Then
                    Me._Subscriber = New BusinessLogic.Subscriber(Me.Master.db, Me.Master.UserSession)
                Else
                    Me._Subscriber = New BusinessLogic.Subscriber(Me.Master.UserSession.Data("SubscriberId"), Me.Master.db, Me.Master.UserSession)
                End If
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property

    Public Property DisplayLanguage As BusinessLogic.UserSession.DisplayLanguages
        Get
            Return Me.Master.UserSession.DisplayLanguage
        End Get
        Set(value As BusinessLogic.UserSession.DisplayLanguages)
            Me.Master.UserSession.DisplayLanguage = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            'Put user code to initialize the page here
            Master.Initilise("Update Subscriber Details", "02", "")
            Master.ShowLanguageRBL = True

            If Request.QueryString("PageFrom") <> "" Then
                Me.txtPageFrom.Value = Request.QueryString("PageFrom")
            End If
            If Request.QueryString("PageMode") <> "" Then
                Me.txtPageMode.Value = Request.QueryString("PageMode")
            End If

            If Request.QueryString("CompanyId") <> "" Then
                ViewState("CompanyId") = Request.QueryString("CompanyId")
            End If

            If Page.IsPostBack Then
                Me.Subscriber.MainDataset = CType(ViewState("MainDataSet"), DataSet)

                pageMode = "Update"
            Else
                pageMode = "Update"

                If Me.Master.WebForm.IsValid Then
                    ReadRecord()
                End If
                Me.FirstName.Focus()
            End If
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try
        If Me.Subscriber.RemoteUser Is Nothing And IsPostBack Then
            'it is likely that the subscriber has been merged and user now points at original sub so switch to correct sub based on userid
            Me.Master.UserSession.Data("SubscriberId") = Master.db.DLookup("RightsToId", "RemoteUserRights", "RightsType ='Subscriber' AND UserId=" & Master.UserSession.UserId)
            Me.Master.UserSession.Data("HasOrIsAProposedSubscriber") = False
            Response.Redirect(Request.ServerVariables("Path_Info") & "?" & Me.Master.UserSession.QueryString)
        End If
    End Sub

    Sub PageSetup()

        Me.Master.PageTitle = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Update Subscriber Details" _
                               , "Información de Suscriptor")

        Me.SendPasswordResetEmailBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Send Password Reset Email", "Enviar Correo para Resetear su Contraseña")
        Me.SendPasswordResetEmailBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Send Password Reset Email", "Enviar Correo para Resetear su Contraseña")

        Me.SaveBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Save", "Guarda")
        Me.SaveBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Save your details", "Guarda")

        Me.CancelBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Cancel", "Cancelar")
        Me.CancelBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Cancel changes", "Cancelar")

        Me.BackBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Back", "Volver")
        Me.BackBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Back to Home", "Volver")

        Me.UserConfirmEmailChange.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Confirm", "Confirmar")
        Me.BillingAddressPanel.Visible = Not Me.AreAddressesTheSame.Checked
        '30/03/20   Julian Gates    SIR5053 - Handle pg112SubscriberDetailsMaint.aspx causing Object reference not set to an instance of an object.error and send email to support.
        Try
            If Me.Subscriber.RemoteUser.UserName = Me.EmailMain.Text Then
                Me.UserName.Visible = False
                Me.UserNameTD.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Use Email Address as User Name", "Use su correo electrónico como Nombre de Usuario")
            Else
                Me.UserName.Visible = True

            End If

            'Hide show password reset button and text.
            Me.SendPasswordResetEmailBtnRow.Visible = Me.Subscriber.RemoteUser.UserStatus = UserStates.Active
            Me.PasswordResetEmailStatus.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Password has been reset and email sent to " _
                                                   , "Su contraseña ha sido reseteada y un correo electrónico ha sido enviado a ") _
                                                    & Me.Subscriber.RemoteUser.EmailAddress &
                                               IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, ", Please check your email to reset your password" _
                                                   , ", Por favor revise su correo electrónico para resetear su contraseña")
            Me.PasswordResetEmailStatusRow.Visible = Me.Subscriber.RemoteUser.UserStatus = UserStates.Emailed
        Catch ex As Exception
            'This error can occur when the sub has been merged when the user is still on it. It doesn't cause a problem and the user is re-linked to the mergered sub
        End Try
    End Sub

    Private Function IsPageValidForStatus() As Boolean
        Return IsPageValidForStatus(String.Empty)
    End Function

    Private Function IsPageValidForStatus(ByVal validatorStatus As String) As Boolean
        '****************************************************** 
        'Description: Validate page fields and show error message 
        '****************************************************** 
        Select Case validatorStatus
            Case Else

                Me.Master.WebForm.FieldValidateMandatory(Me.FirstName, "First Name", "Es obligación escribir su Nombre")
                Me.Master.WebForm.FieldValidateMandatory(Me.LastName, "Last Name", "Es obligación escribir su Apellido")
                'Me.Master.WebForm.DropDownValidateMandatory(Me.Title, "Title")
                Me.Master.WebForm.FieldValidateMandatory(Me.EmailMain, "Email Address", "Es obligación escribir un Correo Electrónico")
                If Me.UserName.Visible Then Me.Master.WebForm.FieldValidateMandatory(Me.UserName, "Username", "Es obligación escribir su Nombre de usuario")
                If Me.EmailMain.Text <> "" Then
                    If Not Me.StdCode.IsValidEmail(Me.EmailMain.Text) And Not Me.UserConfirmEmailChange.Checked Then
                        Master.WebForm.FieldErrorControl(Me.EmailMain, IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Email address looks syntatically incorrect. Please confirm.", "Esta dirección de correo electrónico parece estar mal escrita. Por favor confirmar."))
                        Me.EmailAddressChangeConfirmationRow.Visible = True
                    End If
                    If Master.WebForm.IsValid Then

                        Dim sql As String = ""
                        sql = "Select sa.SubscriberId"
                        sql += " FROM SubscriberAddress sa"
                        sql += "    INNER JOIN Subscriber s"
                        sql += "    On s.SubscriberId = sa.SubscriberId"
                        sql += "    And s.SubscriberStatus In ('Proposed','Current')"
                        sql += " WHERE AddressType='Email'"
                        sql += " AND AddressDescription='Mail'"
                        sql += " AND AddressText =@EmailAddress"
                        sql += " AND sa.SubscriberId<>" & Me.Subscriber.SubscriberId
                        If Not Master.db.IsDBNull(Me.Subscriber.SubscriberRow("UpdateToSubscriberId")) Then
                            sql += " AND sa.SubscriberId<>" & Me.Subscriber.SubscriberRow("UpdateToSubscriberId")
                        End If

                        Dim cmd As New SqlCommand(sql, Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
                        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailAddress", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                         , Me.EmailMain.Text))
                        If Me.Master.db.GetDataTableFromSQL(cmd).Rows.Count > 0 Then
                            Master.WebForm.FieldErrorControl(Me.EmailMain, IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                               , "This Subscriber email is already in use on PaDS. Please choose an alternative." _
                                                                               , "Este correo electrónico de suscriptor ya está en uso en PaDS. Por favor elija otro."))
                        End If
                    End If
                    If Master.WebForm.IsValid Then
                        Dim sql As String = ""
                        sql = "SELECT ru.UserId"
                        sql += " FROM RemoteUser ru"
                        sql += "    LEFT JOIN RemoteUserRights rur"
                        sql += "    ON rur.userid = ru.UserId"
                        sql += "    AND rur.RightsToId = " & Me.Subscriber.SubscriberId 'don't check against self
                        sql += " WHERE EmailAddress=@EmailAddress"
                        sql += " AND rur.UserId IS NULL"
                        sql += " AND ru.UserStatus<>'InActive'"
                        Dim cmd As New SqlCommand(sql, Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
                        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailAddress", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                         , Me.EmailMain.Text))
                        If Me.Master.db.GetDataTableFromSQL(cmd).Rows.Count > 0 Then
                            Master.WebForm.FieldErrorControl(Me.EmailMain, IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                               , "This User email is already in use on PaDS. Please choose an alternative." _
                                                                               , "Este correo electrónico de suscriptor ya está en uso en PaDS. Por favor elija otro."))
                        End If
                    End If
                End If
                If Me.UserName.Text <> "" And Me.UserName.Visible Then
                    Dim sql As String = ""
                    sql = "SELECT ru.UserId"
                    sql += " FROM RemoteUser ru"
                    sql += "    LEFT JOIN RemoteUserRights rur"
                    sql += "    ON rur.userid = ru.UserId"
                    sql += "    AND rur.RightsToId = " & Me.Subscriber.SubscriberId 'don't check against self
                    sql += " WHERE UserName=@UserName"
                    sql += " AND rur.UserId IS NULL"
                    sql += " AND ru.UserStatus<>'InActive'"
                    Dim cmd As New SqlCommand(sql, Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
                    cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                     , Me.UserName.Text))
                    If Me.Master.db.GetDataTableFromSQL(cmd).Rows.Count > 0 Then
                        Master.WebForm.FieldErrorControl(Me.UserName, IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                               , "This user name is already in use on PaDS. Please choose an alternative." _
                                                                               , "Este nombre de usuario ya está en uso en PaDS. Por favor elija otro."))

                    End If
                End If
                'Mailing Address validation
                'jan2020    James Woosnam   If building and town are blank then assume address isn't required
                If Me.BuildingStreet.Text <> "" And Me.Town.Text <> "" Then
                    Me.Master.WebForm.FieldValidateMandatory(Me.BuildingStreet, "Mailing Address Building Street", "Es obligación escribir su dirección de envío de correspondencia")
                    Me.Master.WebForm.FieldValidateMandatory(Me.Town, "Mailing City", "Es obligación escribir la ciudad de su dirección de envío de correspondencia")
                    If Me.Master.db.IsDBNull(Me.CountryId.SelectedValue, "") = "11" Or Me.Master.db.IsDBNull(Me.CountryId.SelectedValue, "") = "56" Then 'US or Canada
                        Me.Master.WebForm.DropDownValidateMandatory(Me.CountyUS, "Mailing State (US or Canada)")
                    End If
                    Me.Master.WebForm.FieldValidateMandatory(Me.PostCode, "Mailing Postcode", "Es obligación escribir el código de su dirección de envío de correspondencia")
                    If String.IsNullOrEmpty(Me.CountryId.SelectedValue) _
                        Or Me.CountryId.SelectedValue = "0" Then
                        Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                                   , "Mailing Country is mandatory" _
                                                                                   , "Es obligación escribir el país de su dirección de envío de correspondencia"))
                        Me.CountryId.CssClass = "fldEntryError"
                    Else
                        Me.CountryId.CssClass = "DropDownList"
                    End If
                    If Not Me.AreAddressesTheSame.Checked Then
                        'Billing Address validation
                        Me.Master.WebForm.FieldValidateMandatory(Me.BillBuildingStreet, "Billing Address Building Street", "Es obligación escribir su dirección de facturación")
                        Me.Master.WebForm.FieldValidateMandatory(Me.BillTown, "Billing City", "Es obligación escribir la ciudad de su dirección de facturación")
                        If Me.Master.db.IsDBNull(Me.BillCountryId.SelectedValue, "") = "11" Or Me.Master.db.IsDBNull(Me.BillCountryId.SelectedValue, "") = "56" Then 'US or Canada
                            Me.Master.WebForm.DropDownValidateMandatory(Me.BillCountyUS, "Billing State (US or Canada)")
                        End If
                        Me.Master.WebForm.FieldValidateMandatory(Me.BillPostCode, "Billing Postcode", "Es obligación escribir el código de su dirección de facturación")

                        If String.IsNullOrEmpty(Me.BillCountryId.SelectedValue) _
                            Or Me.BillCountryId.SelectedValue = "0" Then
                            Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                                       , "Billing Country is mandatory" _
                                                                                       , "Es obligación escribir el país de su dirección de facturación"))
                            Me.BillCountryId.CssClass = "fldEntryError"
                        Else
                            Me.BillCountryId.CssClass = "DropDownList"
                        End If
                    End If
                End If

        End Select

        Return Me.Master.WebForm.IsValid
    End Function

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.Subscriber.MainDataset
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Dim hasPostalAddress As Boolean = False
        Dim hasBillingAddress As Boolean = False

        'Read all data from dataset into page fields
        If pageMode = "Update" Then

            If Not Me.Subscriber.GetAddressRow("Postal", "Main") Is Nothing Then
                hasPostalAddress = True
            End If
            If Not Me.Subscriber.GetAddressRow("Postal", "Billing") Is Nothing Then
                hasBillingAddress = True
            End If

            Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.Subscriber.SubscriberRow)

            If hasPostalAddress _
             And hasBillingAddress = False Then

                Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.Subscriber.GetAddressRow("Postal"))
                If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("CountryId"), 0) <> 0 Then
                    If CInt(Me.Subscriber.GetAddressRow("Postal").Item("CountryId")) = 11 Or CInt(Me.Subscriber.GetAddressRow("Postal").Item("CountryId")) = 56 Then 'US or Canada
                        If Me.Subscriber.GetAddressRow("Postal").Item("County").ToString.Length > 2 Then
                            Me.CountyUS.SelectedValue = ""
                        Else
                            Me.CountyUS.SelectedValue = Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("County").ToString.ToUpper, "")
                        End If
                        Me.County.Text = ""
                    Else
                        Me.County.Text = Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("County"), "")
                    End If
                End If
                Me.BuildingStreet.Text = SetMultiLineAddress("Main")
                PopulateBillingAddressFields("Main")

            ElseIf hasPostalAddress = False And hasBillingAddress Then
                Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.Subscriber.GetAddressRow("Postal", "Billing"))
                Me.BuildingStreet.Text = SetMultiLineAddress("Billing")
                PopulateBillingAddressFields("Billing")

            ElseIf hasPostalAddress And hasBillingAddress Then
                Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.Subscriber.GetAddressRow("Postal"))
                If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("CountryId"), 0) <> 0 Then
                    If CInt(Me.Subscriber.GetAddressRow("Postal").Item("CountryId")) = 11 Or CInt(Me.Subscriber.GetAddressRow("Postal").Item("CountryId")) = 56 Then 'US or Canada
                        If Me.Subscriber.GetAddressRow("Postal").Item("County").ToString.Length > 2 Then
                            Me.CountyUS.SelectedValue = ""
                        Else
                            Me.CountyUS.SelectedValue = Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("County").ToString.ToUpper, "")
                        End If
                        Me.County.Text = ""
                    Else
                        Me.County.Text = Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal").Item("County"), "")
                    End If
                End If
                Me.BuildingStreet.Text = SetMultiLineAddress("Main")
                PopulateBillingAddressFields("Billing")
            End If

            Me.EmailMain.Text = Me.Subscriber.GetAddressText("Email")
            If Me.Subscriber.RemoteUser IsNot Nothing Then
                If Me.Subscriber.RemoteUser.UserName <> Me.EmailMain.Text Then
                    Me.UserName.Text = Me.Subscriber.RemoteUser.UserName
                End If
            End If
        End If
        If Me.BuildingStreet.Text = Me.BillBuildingStreet.Text _
            And Me.Town.Text = Me.BillTown.Text _
            And Me.County.Text = Me.BillCounty.Text _
            And Me.CountyUS.Text = Me.BillCountyUS.Text _
            And Me.PostCode.Text = Me.BillPostCode.Text _
            And Me.CountryId.Text = Me.BillCountryId.Text _
            Then
            Me.AreAddressesTheSame.Checked = True
        End If
        'populate dropdowns
        Me.Master.WebForm.PopulateDropDownListFromLookup(Me.Title, "Title", "<--Select-->")
        Me.Master.WebForm.PopulateDropDownListFromLookup(Me.CountyUS, "US_CanadaStateCode", "<--Select-->")
        Me.Master.WebForm.PopulateDropDownListFromLookup(Me.BillCountyUS, "US_CanadaStateCode", "<--Select-->")

        Dim sql As String = "SELECT Country.CountryId as Value" _
                            & "     ,Country.CountryName As Text" _
                            & " FROM Country" _
                            & " ORDER BY Country.CountryName"

        Me.Master.WebForm.PopulateDropDownListFromSQL(Me.CountryId, sql, "<--Select-->")
        Me.Master.WebForm.PopulateDropDownListFromSQL(Me.BillCountryId, sql, "<--Select-->")
        Me.IsReceiveMail.Checked = Not Me.IsReceiveMail.Checked
    End Sub

    Private Sub PopulateBillingAddressFields(ByVal AddressDescription As String)

        Me.BillBuildingStreet.Text = SetMultiLineAddress(AddressDescription)

        If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("County"), "") <> "" Then
            Me.BillCounty.Text = Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("County")
        End If
        If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Town"), "") <> "" Then
            Me.BillTown.Text = Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Town")
        End If
        If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("PostCode"), "") <> "" Then
            Me.BillPostCode.Text = Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("PostCode")
        End If
        If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("CountryId"), 0) <> 0 Then
            Me.BillCountryId.SelectedValue = CInt(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("CountryId"))

            If CInt(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("CountryId")) = 11 Or CInt(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("CountryId")) = 56 Then 'US or Canada
                If Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("County").ToString.Length > 2 Then
                    Me.BillCountyUS.SelectedValue = ""
                Else
                    Me.BillCountyUS.SelectedValue = Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("County").ToString.ToUpper, "")
                End If
                Me.BillCounty.Text = ""
            Else
                Me.BillCounty.Text = Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("County"), "")
            End If
        End If

    End Sub

    Private Function SetMultiLineAddress(ByVal AddressDescription As String) As String
        Dim postalAddress As String = ""

        postalAddress += Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address1") & System.Environment.NewLine

        If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address2"), "") <> "" Then
            postalAddress += Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address2") & System.Environment.NewLine
        End If
        If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address3"), "") <> "" Then
            postalAddress += Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address3") & System.Environment.NewLine
        End If
        If Me.Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address4"), "") <> "" Then
            postalAddress += Me.Subscriber.GetAddressRow("Postal", AddressDescription).Item("Address4")
        End If

        Return postalAddress

    End Function

    Sub SaveRecord()
        '******************************************************
        'Description:	Save the record either by updating
        '******************************************************
        Dim UserOrPasswordCHanged As Boolean = False
        Try
            '7/11/11    James Woosnam   Re-initalise subscriber to avoid concurrency error
            Me.Subscriber = New BusinessLogic.Subscriber(Me.Master.UserSession.Data("SubscriberId"), Master.db, Master.UserSession)
            Master.db.BeginTran()
            Try
                'Check that this is a proposed subscriber if not make one
                '27/12/20   James Woosnam   SIR5171 - Check subscriber status as well as HasOrIsAProposedSubscriber
                If Not CBool(Me.Master.UserSession.Data("HasOrIsAProposedSubscriber")) And Me.Subscriber.SubscriberStatus = BusinessLogic.Subscriber.SubscriberStates.Current Then
                    Me.Subscriber.CreateProposedSubscriber()
                End If
                Me.Subscriber.SetAddressText("Email", Me.EmailMain.Text)

                Me.Master.WebForm.PopulateDataRowFromPageFields(Me.Subscriber.SubscriberRow)
                Me.Subscriber.SubscriberRow("IsReceiveMail") = Not Me.IsReceiveMail.Checked

                'Change SubscriberName if FirstName or Lastname has been changed
                '10/5/11 Julian Gates SIR2421 - Add code to handle Null Firstname and Lastname
                If Master.db.IsDBNull(Subscriber.SubscriberRow("FirstName", DataRowVersion.Current), "") <> Master.db.IsDBNull(Subscriber.SubscriberRow("FirstName", DataRowVersion.Original), "") _
                     Or Master.db.IsDBNull(Subscriber.SubscriberRow("LastName", DataRowVersion.Current), "") <> Master.db.IsDBNull(Subscriber.SubscriberRow("LastName", DataRowVersion.Original), "") Then
                    '17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .
                    Me.Subscriber.SubscriberRow("SubscriberName") = Left(Me.LastName.Text & ", " & Me.FirstName.Text, 150)
                End If

                '21/6/11 Julian Gates - Use CountyUS value if USA or Canada
                If Me.CountryId.SelectedValue <> "" AndAlso (Me.CountryId.SelectedValue = 11 Or Me.CountryId.SelectedValue = 56) Then 'US or Canada
                    Me.County.Text = Me.CountyUS.SelectedValue
                End If
                '30/3/11   Julian Gates   SIR2401 - Add UpdateExistingOrdersDeliveryAddress to Sub SavePostalSubscriberAddress
                Dim addrNotes As String = ""
                If Me.Subscriber.GetAddressRow("Postal", "Main") IsNot Nothing Then
                    addrNotes = Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", "Main")("Notes"), "")
                End If
                If Me.BuildingStreet.Text <> "" And Me.Town.Text <> "" Then Me.Subscriber.SavePostalSubscriberAddress("Main", Me.BuildingStreet.Text.TrimEnd, Me.Town.Text, Me.County.Text, Me.PostCode.Text, Me.CountryId.SelectedValue, addrNotes, True)

                If AreAddressesTheSame.Checked Then
                    Me.BillBuildingStreet.Text = Me.BuildingStreet.Text
                    Me.BillTown.Text = Me.Town.Text
                    Me.BillCounty.Text = Me.County.Text
                    Me.BillCountyUS.Text = Me.CountyUS.Text
                    Me.BillPostCode.Text = Me.PostCode.Text
                    Me.BillCountryId.Text = Me.CountryId.Text
                End If


                'Save Billing Address
                '21/6/11 Julian Gates - Use CountyUS value if USA or Canada
                If Me.BillCountryId.SelectedValue <> "" AndAlso (Me.BillCountryId.SelectedValue = 11 Or Me.BillCountryId.SelectedValue = 56) Then 'US or Canada
                    Me.BillCounty.Text = Me.BillCountyUS.SelectedValue
                End If
                addrNotes = ""
                If Me.Subscriber.GetAddressRow("Postal", "Billing") IsNot Nothing Then
                    addrNotes = Master.db.IsDBNull(Me.Subscriber.GetAddressRow("Postal", "Billing")("Notes"), "")
                End If
                If Me.BillBuildingStreet.Text <> "" And Me.BillTown.Text <> "" Then Me.Subscriber.SavePostalSubscriberAddress("Billing", Me.BillBuildingStreet.Text.TrimEnd, Me.BillTown.Text, Me.BillCounty.Text, Me.BillPostCode.Text, Me.BillCountryId.SelectedValue, addrNotes)

                '24/09/12 Julian Gates SIR2865 - Check if subscriber DefaultPostalAddressId is populated if not populate
                If Master.db.IsDBNull(Me.Subscriber.SubscriberRow("DefaultPostalAddressId")) And (Me.Subscriber.GetAddressRow("Postal") IsNot Nothing) Then
                    Me.Subscriber.SubscriberRow("DefaultPostalAddressId") = Me.Subscriber.GetAddressRow("Postal")("SubscriberAddressId")
                End If
                If Me.UserName.Visible Then
                    Me.Subscriber.RemoteUser.UserName = Me.UserName.Text
                    Me.Subscriber.RemoteUser.Save()
                End If

                Me.Subscriber.Save()
                Master.db.CommitTran()

            Catch ex As Exception
                Master.db.RollbackTran()
                Throw ex
            End Try

        Catch ex As Exception
            '23/6/11 Julian Gates - Show 4 lines error message to user
            '28/11/11 Julian Gates - Show Building Street Address individual lines must be less than 50 characters message to user
            If ex.ToString.Contains(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                               , "Building Street can only be 4 lines" _
                                                                               , "Su dirección sólo puede tener un máximo de 4 líneas")) Then
                Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                               , "Building Street can only be 4 lines" _
                                                                               , "Su dirección sólo puede tener un máximo de 4 líneas"))
            ElseIf ex.ToString.Contains(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                               , "Building Street Address individual lines must be less than 50 characters" _
                                                                               , "Cada línea de su dirección debe tener menos de 50 caracteres")) Then
                Me.Master.WebForm.AddPageError(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                               , "Building Street Address individual lines must be less than 50 characters" _
                                                                               , "Cada línea de su dirección debe tener menos de 50 caracteres"))
            Else
                Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
            End If
        End Try

        If Me.Master.WebForm.IsValid Then
            Dim URL As String = ""
            If Me.txtPageFrom.Value = "SalesOrder" Then
                URL = "&PageFrom= " & Me.txtPageFrom.Value & " & pageMode = " & Me.txtPageMode.Value
            Else
                URL = ""
            End If
            If UserOrPasswordCHanged Then
                ' Me.Master.WebForm.AddInfoMessage("Updates to your details has been saved, Please note webuser name and web user password modifications can take up to 24 hours to take effect")
                '17/08/17   Julian Gates    SIR4478 - Change Username Password update message
                Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=" & IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                               , "Updates saved. Username And/Or Password changes take 24 - 48 hours to take effect" _
                                                                               , "Actualización guardada. Los cambios en su Nombre de Usuario y/o Contraseña pueden tomar 24 a 48 horas para que tengan efecto") & URL & "&CompanyId=" & ViewState("CompanyId") & "&" & Me.Master.UserSession.QueryString)
            Else
                'Me.Master.WebForm.AddInfoMessage("Updates to your details has been saved")
                Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=" & IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                               , "Updates to your details has been saved" _
                                                                               , "La actualización de sus detalles ha sido guardada") & URL & "&CompanyId=" & ViewState("CompanyId") & "&" & Me.Master.UserSession.QueryString)
            End If
            '  ReadRecord()
        End If

    End Sub

    Protected Sub SaveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        If Me.IsPageValidForStatus("") Then SaveRecord() '4/11/20 - taken out of try/catch as thread was aborting from redirect in save record
    End Sub

    Protected Sub BackBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        '05/12/19   James Woosnam   SIR4949 - use passed in companyId when going back to remote Order screen
        If Me.txtPageFrom.Value = "SalesOrder" Then
            If Session("UsedOrderPageType") = "Spanish" Then
                Response.Redirect("../pages/pg233RemoteOrderSpanish.aspx?PageMode=" & Me.txtPageMode.Value & "&CompanyId=" & ViewState("CompanyId") & "&" & Me.Master.UserSession.QueryString)
            Else
                Response.Redirect("../pages/pg232RemoteOrder.aspx?PageMode=" & Me.txtPageMode.Value & "&CompanyId=" & ViewState("CompanyId") & "&" & Me.Master.UserSession.QueryString)
            End If
        Else
            Response.Redirect("../pages/pg101Home.aspx?" & Me.Master.UserSession.QueryString)
        End If

    End Sub

    Protected Sub CancelBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CancelBtn.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?" & Me.Master.UserSession.QueryString)
    End Sub

    '17/1/20    Julian Gates    SIR4998 - Add Send Password Reset Email" button And associated code
    Protected Sub SendPasswordResetEmailBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SendPasswordResetEmailBtn.Click
        Try
            'Send password reset email
            Me.Subscriber.RemoteUser.ResetPasswordAndEmail()
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                                                                     , "An Unexpected error has occured.  Please contact support" _
                                                                     , "Ha ocurrido un Error Inesperado. Por favor contáctese con Asistencia"), ex))
        End Try
    End Sub
End Class
