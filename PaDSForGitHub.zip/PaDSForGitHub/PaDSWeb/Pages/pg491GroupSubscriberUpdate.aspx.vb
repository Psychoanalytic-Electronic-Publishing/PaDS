Imports System.Data.SqlClient
Imports System.Data
Imports BusinessLogic.UserSession
Imports BusinessLogic.RemoteUser

Partial Class pg491GroupSubscriberUpdate
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim ds As New DataSet
    Public pageContent As String
    Dim pageMode As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    'Modification History
    '22/02/2008 Julian Gates    Initial version
    '09/02/16   Julian Gates    SIR4045 - Change Town/County Prompts to City/State
    '16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields
    '18/11/19   Julian Gates    SIR4768 - Removed Salutation, Operating System, VAT Code, Mail method and passwords fields and associated code.
    '31/1/20    James Woosnam   SIR5004 - Read RemoteUser when required to stop concurrency error
    '17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .
    '16/03/20   Julian Gates    Add uPage.currentUser
    '17/03/20   Julian Gates    SIR5037 - Add menu functionality for GroupAdmin users
    '14/07/20   Julian Gates    SIR5101 - Remove Web User name field and associated code

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        pageMode = Request.QueryString("PageMode")
        uPage = New UserPage(Me, "Subscriber Maint", "01a")
        uPage.menuId = "01a"
        If pageMode = "Add" Then
            uPage.pageTitle = "Add New Subscriber To " & Me.uPage.UserSession.Data("GroupSubscriberName") & " Group"
        Else
            uPage.pageTitle = "Update Subscriber Affiliated To " & Me.uPage.UserSession.Data("GroupSubscriberName")
        End If
        uPage.metaDescription = "Cont"
        uPage.currentUser = Me.uPage.UserSession.UserName

        If Request.QueryString("SubscriberId") <> "" Then
            Me.SubscriberId.Value = Request.QueryString("SubscriberId")
        Else
            Me.SubscriberId.Value = 0
        End If

        If pageMode = "Update" Then
            'Get UserId for this subscriber
            ViewState("UserId") = uPage.db.IsDBNull(uPage.db.DLookup("ru.UserId", "RemoteUser ru INNER JOIN RemoteUserRights rur ON rur.UserId = ru.UserId", "rur.rightsToId=" & Me.SubscriberId.Value), "")
        End If

        If Page.IsPostBack Then
            'Load Dataset from Viewstate
            ds = CType(ViewState("MainDataSet"), DataSet)
        Else
            ReadRecord()
            If Request.QueryString("InfoMsg") <> "" Then
                Me.InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            uPage.FocusControl = Me.SubscriberCategory
            BuildSubscriptionsList()
        End If

        PageSetup()
    End Sub

    Sub PageSetup()
        Select Case pageMode
            Case "Add"
                Me.EmailAddressConfirmFieldPanel.Visible = True
                Me.EmailAddressConfirmPromptPanel.Visible = True
                Me.EmailAddress.AutoPostBack = False
                Me.AffiliatedDatesPanel.Visible = False
                Me.SubscriptionsListPanel.Visible = False
                Me.ResetPasswordBtn.Visible = False
                Me.FirstNamePrompt.Visible = True
                Me.FirstName.Visible = True
                Me.LastNamePrompt.Visible = True
                Me.LastName.Visible = True
                Me.TitlePrompt.Visible = True
                Me.Title.Visible = True
                Me.SubscriberNamePrompt.Visible = False
                Me.SubscriberName.Visible = False
                uPage.FocusControl = Me.FirstName
            Case "Update"
                Select Case ds.Tables("Subscriber").Rows(0)("EntityType")
                    Case "Organisation"
                        Me.SubscriberNamePrompt.Visible = True
                        Me.SubscriberName.Visible = True
                        Me.FirstNamePrompt.Visible = False
                        Me.FirstName.Visible = False
                        Me.LastNamePrompt.Visible = False
                        Me.LastName.Visible = False
                        Me.TitlePrompt.Visible = False
                        Me.Title.Visible = False
                    Case Else
                        Me.SubscriberNamePrompt.Visible = False
                        Me.SubscriberName.Visible = False
                        Me.FirstNamePrompt.Visible = True
                        Me.FirstName.Visible = True
                        Me.LastName.Visible = True
                        Me.LastName.Visible = True
                        Me.TitlePrompt.Visible = True
                        Me.Title.Visible = True
                End Select
                If Me.EmailAddressConfirmFieldPanel.Visible Then
                    Me.EmailAddress.AutoPostBack = False
                Else
                    Me.EmailAddress.AutoPostBack = True
                End If

                Me.AffiliatedDatesPanel.Visible = True
                Me.SubscriptionsListPanel.Visible = True
        End Select
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Dim selectCommand As String
        If pageMode = "Update" Then
            selectCommand = "sp491GetSubscriberDetails " _
                         & Me.SubscriberId.Value _
                         & " , " & Me.uPage.UserSession.Data("PrimaryGroupSubscriberId") _
                         & " ," & Me.uPage.UserSession.Data("CompanyId")

            Dim da As New SqlDataAdapter(selectCommand, uPage.PrimaryConnection)
            'Populate Dataset
            da.Fill(ds, "Subscriber")
            'Read all data from dataset into page fields
            uPage.PopulatePageFieldsFromDataRow(ds.Tables("Subscriber").Rows(0))
            Me.GroupName.Text = Me.uPage.UserSession.Data("GroupSubscriberName")
            Me.BeforeEmailAddress.Value = ds.Tables("Subscriber").Rows(0)("EmailAddress")

            If Not ds.Tables("Subscriber").Rows(0)("StartDate") Is System.DBNull.Value Then
                Me.StartDate.Text = uPage.FormatDate(ds.Tables("Subscriber").Rows(0)("StartDate"))
            End If
            If Not ds.Tables("Subscriber").Rows(0)("EndDate") Is System.DBNull.Value Then
                Me.EndDate.Text = uPage.FormatDate(ds.Tables("Subscriber").Rows(0)("EndDate"))
            End If
        Else
            Me.SubscriberCategory.SelectedValue = "Ordinary"
        End If

        'Populate all dropdown fields
        Dim dropDownIntialValue As String = "<---------Select--------->"
        uPage.PopulateDropDownListFromLookup(Me.Title, "Title", uPage.PrimaryConnection, dropDownIntialValue)
        uPage.PopulateDropDownListFromSQL(Me.Country, "SELECT CountryId as Value" _
                                                            & "    , CountryName As Text" _
                                                            & " FROM Country " _
                                                            & " ORDER BY CountryName" _
                                                            , uPage.PrimaryConnection, dropDownIntialValue)

        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria and order by
        uPage.PopulateDropDownListFromSQL(Me.SubscriberCategory, "Select  LookupItemKey As Value" _
                                                        & "    , Name as Text" _
                                                        & " FROM Lookup " _
                                                        & " Where LookupName = 'SubscriberCategory'" _
                                                        & " AND Lookup.CompanyId =" & Me.uPage.UserSession.Data("CompanyId") _
                                                        & " AND Lookup.LookupItemKey <> 'Institutional'" _
                                                        & " AND Lookup.LookupStatus = 'Active'" _
                                                        & " ORDER BY DisplayOrder,Name,LookupItemKey" _
                                                       , uPage.PrimaryConnection, dropDownIntialValue)


    End Sub

    Sub SaveRecord()
        '******************************************************
        'Description:	Save the record either by updating or adding
        '******************************************************
        '16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields
        Dim cmd As SqlCommand
        uPage.db.BeginTran()
        Try
            Dim AddressLines() As String = uPage.GetMultiLineBuildingAddress(Me.BuildingStreet.Text)
            cmd = Nothing
            cmd = New SqlCommand("sp492SubscriberAddUpdate", uPage.db.DBConnection, uPage.db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.Int, 0, ParameterDirection.InputOutput, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.SubscriberId.Value))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberCategory", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.SubscriberCategory.SelectedValue))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@FirstName", System.Data.SqlDbType.VarChar, 25, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.FirstName.Text))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LastName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.LastName.Text))
            '17/2/20    James Woosnam   SIR5021 - Allow 150 characters for subscriber name .
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberName", System.Data.SqlDbType.VarChar, 150, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.SubscriberName.Text))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Title", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.Title.SelectedValue))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailAddress", System.Data.SqlDbType.VarChar, 255, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.EmailAddress.Text))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Address1", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, AddressLines(0)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Address2", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, AddressLines(1)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Address3", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, AddressLines(2)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Address4", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, AddressLines(3)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Town", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.Town.Text))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@County", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.County.Text))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PostCode", System.Data.SqlDbType.VarChar, 16, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.PostCode.Text))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CountryId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.Country.SelectedValue))
            If Me.EndDate.Text <> "" Then
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AffiliateEndDate", System.Data.SqlDbType.DateTime, 0, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.EndDate.Text))
            End If
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.uPage.UserSession.UserName))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@GroupSubscriberId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.uPage.UserSession.Data("PrimaryGroupSubscriberId")))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@CompanyId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.uPage.UserSession.Data("CompanyId")))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReturnCode", System.Data.SqlDbType.Int, 0, ParameterDirection.Output, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, 0))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ErrorMessage", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Output, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, ""))
            Try
                cmd.ExecuteNonQuery()

            Catch ex As Exception
                Throw New Exception("Error saving file:" & vbCrLf & ex.ToString)
            End Try
            If cmd.Parameters("@ReturnCode").Value <> 0 Then
                Throw New Exception("sp492SubscriberAddUpdate failed:" & vbCrLf _
                                    & "ErrorCode:" & cmd.Parameters("@ReturnCode").Value & vbCrLf _
                                    & cmd.Parameters("@ErrorMessage").Value)

            Else
            End If
            Dim RemoteUser As BusinessLogic.RemoteUser = Nothing
            Select Case Me.pageMode
                Case "Add"
                    RemoteUser = New BusinessLogic.RemoteUser(Me.uPage.db, Me.uPage.UserSession)
                    RemoteUser.AddNewSubscriberUser(Me.EmailAddress.Text, cmd.Parameters("@SubscriberId").Value, BusinessLogic.UserSession.AuthorityLevels.IndividualSubscriber)
                Case "Update"
                    RemoteUser = New BusinessLogic.RemoteUser(CInt(ViewState("UserId")), Me.uPage.db, Me.uPage.UserSession)
            End Select
            RemoteUser.Save()

            uPage.db.CommitTran()
            If pageMode = "Add" Then
                Me.SubscriberId.Value = cmd.Parameters("@SubscriberId").Value
            End If

        Catch ex As Exception
            uPage.db.RollbackTran()
            uPage.PageError = "Save failed:" & ex.Message
        End Try
        '13/1/11    James Woosnam   Move redirct out of try catch as this causes the "This SqlTransaction has completed; it is no longer usable." Error 
        Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&" & uPage.UserSession.QueryString & "&InfoMsg=This record has been successfully Updated&SubscriberId=" & Me.SubscriberId.Value)
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************

        Select Case validatorStatus
            Case Else
                uPage.DropDownValidateMandatory(Me.SubscriberCategory)
                If pageMode = "Update" Then
                    Select Case ds.Tables("Subscriber").Rows(0)("EntityType")
                        Case "Organisation"
                            uPage.FieldValidateMandatory(Me.SubscriberName)
                        Case Else
                            uPage.FieldValidateMandatory(Me.FirstName)
                            uPage.FieldValidateMandatory(Me.LastName)
                    End Select
                Else
                    uPage.FieldValidateMandatory(Me.FirstName)
                    uPage.FieldValidateMandatory(Me.LastName)
                End If
                uPage.FieldValidateEmail(Me.EmailAddress, True)

                uPage.FieldValidateMandatory(Me.BuildingStreet)
                uPage.DropDownValidateMandatory(Me.Country)

                If Me.EmailAddressConfirmFieldPanel.Visible = True Then
                    If Me.EmailAddress.Text <> Me.ConfirmEmailAddress.Text Then
                        uPage.FieldErrorControl(Me.ConfirmEmailAddress, "Confirm email address must match email address.")
                    Else
                        If Me.EmailAddress.Text <> "" Then
                            If CheckForDuplicateEmailAddress(Me.EmailAddress.Text) Then
                                uPage.FieldErrorControl(Me.EmailAddress, "Sorry your chosen Email Address is already being used, please choose another.")
                            End If
                        End If
                    End If
                End If
                Try
                    Dim AddressLines() As String = uPage.GetMultiLineBuildingAddress(Me.BuildingStreet.Text)
                Catch ex As Exception
                    uPage.PageError = ex.Message
                End Try

        End Select
        Return uPage.IsValid
    End Function

    Private Sub BuildSubscriptionsList()
        '******************************************************
        'Description:	Builds and Displays a subscriptions list
        '******************************************************
        Dim strHtml As String = Nothing
        Dim selectCommand As String = Nothing

        selectCommand = "sp494GetSubscriptions @SubscriberId = " & Me.SubscriberId.Value _
                                            & ", @GroupSubscriberId = " & Me.uPage.UserSession.Data("PrimaryGroupSubscriberId") _
                                            & ", @CompanyId= " & Me.uPage.UserSession.Data("CompanyId")

        Dim da As New SqlDataAdapter(selectCommand, uPage.PrimaryConnection)
        'Populate Dataset
        da.Fill(ds, "Subscriptions")
        Try
            For Each row As DataRow In ds.Tables("Subscriptions").Rows
                strHtml = strHtml & "<TR>"
                strHtml += "<TD>" _
                        & "<P class=fldView>" & row.Item("ProductName") & "</P>" _
                        & "</TD>"
                strHtml += "<TD>" _
                        & "<P class=fldView>" & IIf(uPage.FormatDate(row.Item("RecurringSubscriptionEndDate")) = "31-Dec-4949", "Indefinite", uPage.FormatDate(row.Item("RecurringSubscriptionEndDate"))) & "</P>" _
                        & "</TD>"
            Next
        Catch e As Exception
            uPage.PageError = e.ToString
        End Try
        'Assign grid to Label
        Me.lblSubscriptionsList.Text = strHtml
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        Try
            If Me.IsPageValidForStatus("") Then
                SaveRecord()
            End If
        Catch ex As Exception
            uPage.PageError = "Save failed:" & ex.Message
        End Try

    End Sub
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = ds
        uPage.PagePreRender()
    End Sub

    Private Sub BackBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackBtn.Click
        Response.Redirect("../pages/pg490GroupSubscriberSelect.aspx" & "?" & uPage.UserSession.QueryString)
    End Sub

    Private Sub SubscriberCategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubscriberCategory.SelectedIndexChanged
        PageSetup()
    End Sub

    Private Sub CancelBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelBtn.Click
        If pageMode = "Add" Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Add&" & uPage.UserSession.QueryString & "")
        Else
            Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&" & uPage.UserSession.QueryString & "&SubscriberId=" & Me.SubscriberId.Value)
        End If
    End Sub

    Private Sub DeAffiliateBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeAffiliateBtn.Click
        Me.EndDate.Text = uPage.FormatDate(System.DateTime.Today)
        Me.DeaffiliateWarningMsg.Text = "You have changed the affiliated end date, when you save this record this will cancel this subscribers affiliation with this group."
    End Sub

    Private Sub DeAffiliateCancelBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeAffiliateCancelBtn.Click
        Me.DeaffiliateWarningMsg.Text = ""
        Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&" & uPage.UserSession.QueryString & "&SubscriberId=" & Me.SubscriberId.Value)
    End Sub

    Private Sub EmailAddress_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EmailAddress.TextChanged
        Select Case pageMode
            Case "Update"
                Me.EmailAddressConfirmFieldPanel.Visible = True
                Me.EmailAddressConfirmPromptPanel.Visible = True
                uPage.FieldErrorControl(Me.ConfirmEmailAddress, "Please confirm email address.")
                uPage.FocusControl = Me.ConfirmEmailAddress
                Me.PageSetup()
        End Select
    End Sub

    Function CheckForDuplicateWebUser(ByVal webUserName As String) As Boolean
        '*********************************************************
        'Desc:		Uses Web User name to find any potentially duplicate
        '********************************************************
        Dim sql As String
        sql = "SELECT UserId"
        sql += " FROM RemoteUser"
        If pageMode = "Update" Then
            sql += " WHERE UserId <> " & ViewState("UserId")
        Else
            sql += " WHERE 1=1"
        End If

        Dim cmd As New SqlCommand(sql & " AND UserName=@UserName", uPage.db.DBConnection, uPage.db.DBTransaction)
        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      webUserName))
        Dim tbl As DataTable = uPage.db.GetDataTableFromSQL(cmd)
        If tbl.Rows.Count = 0 Then
            CheckForDuplicateWebUser = False
        Else
            CheckForDuplicateWebUser = True
        End If
    End Function
    Function CheckForDuplicateEmailAddress(ByVal EmailAddress As String) As Boolean
        '*********************************************************
        'Desc:		Uses Web User name to find any potentially duplicate
        '********************************************************
        Dim sql As String
        sql = "SELECT UserId"
        sql += " FROM RemoteUser"
        If pageMode = "Update" Then
            sql += " WHERE UserId <> " & ViewState("UserId")
        Else
            sql += " WHERE 1=1"
        End If

        Dim cmd As New SqlCommand(sql & " AND EmailAddress=@EmailAddress", uPage.db.DBConnection, uPage.db.DBTransaction)
        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmailAddress", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      EmailAddress))
        Dim tbl As DataTable = uPage.db.GetDataTableFromSQL(cmd)
        If tbl.Rows.Count = 0 Then
            CheckForDuplicateEmailAddress = False
        Else
            CheckForDuplicateEmailAddress = True
        End If
    End Function

    Private Sub ResetPasswordBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResetPasswordBtn.Click
        Try
            'Send Activation email
            Dim RemoteUser As New BusinessLogic.RemoteUser(CInt(ViewState("UserId")), Me.uPage.db, Me.uPage.UserSession)
            RemoteUser.ResetPasswordAndEmail()
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try

        If uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?PageMode=Update&InfoMsg=Password has been reset and email has been sent to user&" & uPage.UserSession.QueryString & "&SubscriberId=" & Me.SubscriberId.Value)
        End If
    End Sub

End Class
