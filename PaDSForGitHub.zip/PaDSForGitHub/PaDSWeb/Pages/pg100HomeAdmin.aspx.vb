﻿Imports System.Data
'Modification History
'22/05/2015     Julian Gates    Initial Version
'15/01/2016     Julian Gates    SIR4070 - Add BuildUserPasswordValidationWarning

Partial Class Pages_pg100HomeAdmin
    Inherits System.Web.UI.Page
    Public uPage As UserPage
   
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "PaDS - Home", "")
        Me.pageHeaderTitle.Text = "Home"

        If Page.IsPostBack Then

        Else
            If IsNumeric(Request.QueryString("FileStoreId")) Then
                Dim webform As New WebForm(Me)
                Dim fs As New BusinessLogic.FileStore(Request.QueryString("FileStoreId"), uPage.db)
                webform.PopOpenFileBytes(fs.OriginalFileName, fs.FileBytes)
            End If
        End If

        If Request.QueryString("InfoMsg") <> "" And Not IsPostBack Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If
    End Sub

    Sub PageSetup()
        BuildMenuLinks()
        If uPage.UserSession.IsAtZedraOrZedraUser Then
            Try

                Dim lb As New Label
                TestTools.Visible = True
                Dim lk As New HyperLink
                lk.NavigateUrl = uPage.db.GetParameterValue("PaDSFederatedPortalURL")
                lk.Text = "Federated Stnd"
                lk.Target = "_blank"
                Me.TestTools.Controls.Add(lk)
                lb = New Label
                lb.Text = "<br>"
                Me.TestTools.Controls.Add(lb)

                Dim tbFederations As New Table
                Dim t As DataTable = uPage.db.GetDataTableFromSQL("SELECT al.RemoteUserAutoLogonId ,al.FederatedEntity ,ru.UserFullName ,al.IsFederatedLinkRequired FROM RemoteUserAutoLogon al INNER JOIN RemoteUser ru ON ru.UserId = al.UserId WHERE ru.UserStatus = 'Active' AND al.AutoLogonStatus = 'Active' AND al.AutoLogonType = 'Federated' ORDER BY ISNULL(al.IsFederatedLinkRequired,0) DESC ,ru.UserFullName ")
                For Each r As DataRow In t.Rows
                    Dim tr As New TableRow
                    Dim tc As New TableCell
                    lk = New HyperLink
                    lk.NavigateUrl = Request.ServerVariables("Path_Info") & "?FederatedEntity=" & r("FederatedEntity") & "&" & uPage.UserSession.QueryString
                    lk.Text = r("UserFullName")
                    tc.Controls.Add(lk)
                    tr.Cells.Add(tc)

                    tc = New TableCell
                    tc.Text = r("FederatedEntity")
                    tr.Cells.Add(tc)

                    tc = New TableCell
                    Dim ck As New CheckBox
                    ck.Checked = uPage.db.IsDBNull(r("IsFederatedLinkRequired"), False)
                    tc.Controls.Add(ck)
                    tr.Cells.Add(tc)

                    tbFederations.Rows.Add(tr)
                Next
                Me.TestTools.Controls.Add(tbFederations)

            Catch ex As Exception
            End Try
        End If

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Function BuildMenuLinks() As String
        Dim sOut As String = Nothing
        Dim strLine As String = Chr(13)
        sOut = "    <table border=""0"">"
        sOut += "        <tr>" & strLine
        sOut += "           <td class=""menuHeader"">" & strLine
        sOut += "               Additional Tasks" & strLine
        sOut += "           </td>" & strLine
        sOut += "       </tr>" & strLine
        sOut += "        <tr>" & strLine
        sOut += "        <td>" & strLine
        sOut += "           <ul>" & strLine
        '28/1/16    James Woosnam   SIR4072 - Correctly apply security to menu
        If Me.uPage.UserSession.AuthorityLevel = BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins Then
            sOut += "           <li class='bltln1'>" & strLine
            sOut += "               View and Update <a href='../Pages/pg500ProductCombinationList.aspx?" & uPage.UserSession.QueryString & "' title=""Maintain Product Combinations"">Product Combination</a>" & strLine
            sOut += "           <li class='bltln1'>" & strLine
            sOut += "               View and Update <a href='../Pages/pg503ProductSelect.aspx?" & uPage.UserSession.QueryString & "' title=""Maintain Products and Rates"">Products And Rates</a>" & strLine
        End If
        sOut += "           <li class='bltln1'>" & strLine
        sOut += "               View and Update <a href='../Pages/pg270ContentSetSelect.aspx?" & uPage.UserSession.QueryString & "' title=""View and Update Content Set's"">Content Set's</a>" & strLine
        sOut += "           </ul>" & strLine
        sOut += "       </td>" & strLine
        sOut += "   </tr>" & strLine
        sOut += " </table>" & strLine
        Return sOut
    End Function

    Function BuildAdminMenuLinks() As String
        Dim sOut As String = Nothing
        Dim strLine As String = Chr(13)
        sOut = "    <table border=""0"">"
        sOut += "        <tr>" & strLine
        sOut += "           <td class=""menuHeader"">" & strLine
        sOut += "               Admin Tasks" & strLine
        sOut += "           </td>" & strLine
        sOut += "       </tr>" & strLine
        sOut += "        <tr>" & strLine
        sOut += "        <td>" & strLine
        sOut += "           <ul>" & strLine
        Select Case uPage.UserSession.AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
                sOut += "           <li class='bltln1'>" & strLine
                sOut += "               View and Update <a href='../Pages/pg260LookupList.aspx?" & uPage.UserSession.QueryString & "' title=""View and Update Lookups"">Lookups</a>" & strLine
                sOut += "           <li class='bltln1'>" & strLine
                sOut += "               View <a href='../Pages/pg160BatchLogList.aspx?" & uPage.UserSession.QueryString & "' title=""View Batchlog List"">Batchlog</a>" & strLine
                sOut += "           <li class='bltln1'>" & strLine
                sOut += "               View <a href='../Pages/pg081ErrorMessageLogList.aspx?" & uPage.UserSession.QueryString & "' title=""View Error Message Log List"">Error Message Log</a>" & strLine
                sOut += "           <li class='bltln1'>" & strLine
                sOut += "               View <a href='../Pages/pg040AuditLogDisplay.aspx?" & uPage.UserSession.QueryString & "' title=""View Audit Log"">AuditLog</a>" & strLine
                sOut += "           <li class='bltln1'>" & strLine
                sOut += "               View <a href='../Pages/pg090SessionData.aspx?" & uPage.UserSession.QueryString & "' title=""View Session Data"">Sessions</a>" & strLine
        End Select
        sOut += "           </ul>" & strLine
        sOut += "       </td>" & strLine
        sOut += "   </tr>" & strLine
        sOut += " </table>" & strLine
        Return sOut
    End Function

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else
                Dim strQLFirst As String = Nothing
                Dim strQLREst As String = Nothing

                If Me.Quicklink.Text <> "" Then
                    If IsNumeric(Me.Quicklink.Text) Then
                        uPage.PageError = "Please specify the type of number S,O,A,V"
                    Else
                        strQLFirst = UCase(Left(Me.Quicklink.Text, 1))
                        If Len(Me.Quicklink.Text) > 1 Then
                            strQLREst = Mid(Me.Quicklink.Text, 2)
                        Else
                            strQLREst = ""
                        End If
                        If IsNumeric(strQLREst) Then
                            If InStr("SOAV", strQLFirst) = 0 Then
                                uPage.PageError = "Please specify the type of number S,O,A,V"
                            End If
                        End If
                    End If
                End If
        End Select

        Return uPage.IsValid
    End Function

    Sub QuickLinks(ByVal PressedButton As String)
        '05/02/2020 Julian Gates    SIR5007 - Change Subscriber, Order and Cashbook select page links.
        Dim strQLREst As String = Nothing
        Dim strQLFirst As String = Nothing
        Dim strQuickLink As String = Nothing
        Dim strURL As String = Nothing

        strQuickLink = Me.Quicklink.Text

        If strQuickLink <> "" Then
            If IsNumeric(strQuickLink) Then
                uPage.PageError = "Please specify the type of number S,O,A,V"
            Else
                strQLFirst = UCase(Left(strQuickLink, 1))
                If Len(strQuickLink) > 1 Then
                    strQLREst = Mid(strQuickLink, 2)
                Else
                    strQLREst = ""
                End If
                If IsNumeric(strQLREst) Then
                    If InStr("SOAV", strQLFirst) = 0 Then
                        uPage.PageError = "Please specify the type of number S,O,A,V"
                    Else
                        'Numbers
                        Select Case PressedButton
                            Case "Subscribers"
                                If strQLFirst = "S" Then
                                    strURL = "../Pages/pg111SubscriberDisplay.aspx" _
                                            & "?PageMode=Update"
                                Else
                                    strURL = "../Pages/pg110SubscriberSelect.aspx" _
                                                    & "?ww=ww"
                                End If
                            Case "Orders"
                                If strQLFirst = "O" Then
                                    strURL = "../Pages/pg142OrderMaint2.aspx" _
                                            & "?PageMode=Update"
                                Else
                                    strURL = "../Pages/pg140OrderSelect.aspx" _
                                                    & "?ww=ww"
                                End If
                            Case "Cashbook"
                                If strQLFirst = "C" Then
                                    strURL = "../Pages/pg151CashbookMaint.aspx" _
                                            & "?PageMode=Update"
                                Else
                                    strURL = "../Pages/pg150CashbookSelect.aspx" _
                                                    & "?ww=ww"
                                End If
                        End Select
                        Select Case strQLFirst
                            Case "S"
                                If PressedButton = "Cashbook" Then
                                    strURL = strURL + "&FilterSubscriberId=" & CLng(strQLREst)
                                Else
                                    strURL = strURL + "&SubscriberId=" & CLng(strQLREst)
                                End If
                            Case "O"
                                strURL = strURL + "&OrderNumber=" & CLng(strQLREst)
                            Case "A"
                                strURL = strURL + "&AccountNumber=" & CLng(strQLREst)
                            Case "V"
                                strURL = strURL + "&VATNumber=" & strQLREst
                        End Select
                    End If 'First letter check
                Else 'numeric rest check
                    'Characters
                    Select Case PressedButton
                        Case "Subscribers"
                            strURL = "../Pages/pg110SubscriberSelect.aspx" _
                                    & "?SubscriberName=" & strQuickLink
                        Case "Orders"
                            strURL = "../Pages/pg140OrderSelect.aspx" _
                                    & "?SubscriberName=" & strQuickLink
                        Case "Cashbook"
                            strURL = "../Pages/pg150CashbookSelect.aspx" _
                                    & "?FilterSubscriberName=" & strQuickLink
                        Case "Subs by Address"
                            strURL = "../Pages/pg110SubscriberSelect.aspx" _
                                    & "?AddressText=" & strQuickLink
                    End Select

                End If  'numeric rest check
            End If
        Else
            uPage.PageError = "Enter something to link to"
        End If

        If uPage.IsValid Then
            Response.Redirect(strURL & "&" & uPage.UserSession.QueryString)
        End If
    End Sub

    Protected Sub SubscribersBtn_Click(sender As Object, e As EventArgs) Handles SubscribersBtn.Click
        QuickLinks("Subscribers")
    End Sub
    Protected Sub OrdersBtn_Click(sender As Object, e As EventArgs) Handles OrdersBtn.Click
        QuickLinks("Orders")
    End Sub
    Protected Sub CashbookBtn_Click(sender As Object, e As EventArgs) Handles CashbookBtn.Click
        QuickLinks("Cashbook")
    End Sub
    Protected Sub SubsByAddressBtn_Click(sender As Object, e As EventArgs) Handles SubsByAddressBtn.Click
        QuickLinks("Subs by Address")
    End Sub

    '15/01/2016     Julian Gates    SIR4070 - Add BuildUserPasswordValidationWarning
    Function BuildUserPasswordValidationWarning() As String
        Dim sOut As String = Nothing
        Dim strLine As String = Chr(13)
        'Session("UserPassord") contains current password entered by user in logon page
        If Session("UserPassord") <> Nothing Then
            Dim ru As New BusinessLogic.RemoteUser(uPage.db)
            If ru.IsValidPassword(Session("UserPassord")) Then
                'Show Nothing
                Me.passwordValidationWarningRow.Visible = False
            Else
                sOut = "    <table border=""0"" cellpadding=""5px"" cellspacing=""0"" class=""PasswordValidationTable"">"
                sOut += "       <tr>" & strLine
                sOut += "           <td>" & strLine
                sOut += "               Your current password doesn't match the current PaDS password rules, please <a href='../Pages/pg061UserMaint.aspx?PageMode=Update&UserId=" & uPage.UserSession.UserId & "&" & uPage.UserSession.QueryString & "' title=""Update your password"">Click Here</a> to update your password." & strLine
                sOut += "       </td>" & strLine
                sOut += "   </tr>" & strLine
                sOut += " </table>" & strLine
                Me.passwordValidationWarningRow.Visible = True
            End If
        End If
        Return sOut
    End Function

End Class
