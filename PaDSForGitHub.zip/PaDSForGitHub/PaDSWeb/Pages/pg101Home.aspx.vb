﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'17/01/11  Julian Gates   Initial version
'12/05/11  Julian Gates   SIR2428 - Set UserSession.Data("HasCurrentSubscription") in GetWebProductList() to be used in pg232RemoteOrder to hide PEPWEB24
'21/6/11   James Woosnam  SIR2445 - The above change is now reversed as this is now hanlded in sp236WebProducts
'22/6/11   Julian Gates   SIR2459 - Add new IsSubscriberValidForOrdering error message functionality.
'05/3/12   Julian Gates   Removed Ajax roundpanels
'08/3/12   Julian Gates   SIR2631 - Add code to hide product renewal link until user has updated subscriber details
'03/10/14   Julian Gates    SIR3621 - Add IsReceiveEmail as read only yes no value.
'30/03/15   Julian Gates    SIR3785 - Show spanish order button and subscribed to product in spanish.
'04/07/17   Julian Gates    Remove IJP-es spanish product text and orden button
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number fields
'29/10/19   Julian Gates    SIR4768 - Removed VATNumber, MailMethod, Operating system.
'29/10/19   Julian Gates    SIR4763 - Remove WebUserName
'30/10/19   Julian Gates    SIR4768 - Add Subscriptions list
'31/10/19   Julian Gates    SIR4949 - Change Order buttons to be PEP and IJP versions.
'25/11/19   Julian Gates    SIR4957 - Remove Subscription list
'15/1/20    James Woosnam   SIR4970 - show renewal link for any product recurring by month.
'10/2/20    James Woosnam   SIR4937 - Show Subscriber Category in affiliate list
'28/4/20    Julian Gates    SIR5032 - Add spanish translation
'3/2/20     James Woosnam   SIR5094 - Only show 'Current' subscriber affiliate parents
'8/7/20     Julian Gates    SIR5097 - Remove Subscriber Category from BuildAffiliations grid and Subscriber details section.
'12/11/20   Julian Gates    SIR5148 - Make Subscribed to product code read only and not a link in GetWebProductList
'02/02/21   Julian Gates    SIR5186 - Add SubscriberId in small font to top right of Subscriber deatails panel.

Partial Class Pages_pg101Home
    Inherits System.Web.UI.Page
    Dim pageMode As String = ""
    Dim StdCode As New BusinessLogic.StdCode()

    Private _Subscriber As BusinessLogic.Subscriber = Nothing
    Public Property Subscriber() As BusinessLogic.Subscriber
        Get
            If Me._Subscriber Is Nothing Then
                Me._Subscriber = New BusinessLogic.Subscriber(Me.Master.UserSession.Data("SubscriberId"), Me.Master.db, Me.Master.UserSession)
                '9/2/21     James Woosnam   SIR5186 - Logout if tryinh to open a mergered sub, due to auto open from cookie
                If Not {BusinessLogic.Subscriber.SubscriberStates.Current, BusinessLogic.Subscriber.SubscriberStates.Proposed}.Contains(_Subscriber.SubscriberStatus) Then
                    Me.Master.SessionLogout()
                End If
            End If
            Return Me._Subscriber
        End Get
        Set(ByVal value As BusinessLogic.Subscriber)
            Me._Subscriber = value
        End Set
    End Property
    Public Property DisplayLanguage As BusinessLogic.UserSession.DisplayLanguages
        Get
            Return Me.Master.UserSession.DisplayLanguage
        End Get
        Set(value As BusinessLogic.UserSession.DisplayLanguages)
            Me.Master.UserSession.DisplayLanguage = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Master.Initilise("Home", "01", "")
        Master.ShowLanguageRBL = True

        If Page.IsPostBack Then
            pageMode = "Update"
        Else
            pageMode = "Update"
            If Me.Master.WebForm.IsValid Then
                ReadRecord()
            End If
            ' Me.UserAccountName.Focus()
        End If
    End Sub

    Sub PageSetup()

        Me.Master.PageTitle = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Home" _
                               , "Inicio")

        Me.UpdateDetailsBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Change Your Details", "Cambiar su información")
        Me.UpdateDetailsBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Change Your Details", "Cambiar su información")

        Me.NewIJPOrderBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "New IJP Order", "Nueva compra en IJP")
        Me.NewIJPOrderBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Create new IJP order", "Crear nuevo pedido de IJP")

        Me.NewPEPOrderBtn.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "New PEP Order", "Nueva compra en PEP")
        Me.NewPEPOrderBtn.ToolTip = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "Create new PEP order", "Crear nuevo pedido de PEP")

        '22/6/11   Julian Gates   SIR2459 - Add new IsSubscriberValidForOrdering error message functionality.
        If Me.Subscriber.IsSubscriberValidForOrdering() <> "" Then
            Me.IsSubscriberValidForOrderingError.Text = "<b>" & IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English, "WARNING: Subscriber Details Missing", "PRECAUCIÓN: Los detalles del suscriptor no se han encontrado") & "</b> <br>" & Me.Subscriber.IsSubscriberValidForOrdering()
            Me.TableRowIsSubscriberValidForOrdering.Visible = True
            Me.NewPEPOrderBtn.Enabled = False
            Me.NewIJPOrderBtn.Enabled = False
        Else
            Me.TableRowIsSubscriberValidForOrdering.Visible = False
            Me.NewPEPOrderBtn.Enabled = True
            Me.NewIJPOrderBtn.Enabled = True
        End If

        BuildAffiliations()
        GetPEPWebProductRenewalNotification()
        GetWebProductList()
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        '    ViewState("MainDataSet") = Me.Subscriber.MainDataset
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************

        'Read all data from dataset into page fields
        If pageMode = "Update" Then
            Me.Master.WebForm.PopulatePageFieldsFromDataRow(Me.Subscriber.SubscriberRow)
            Me.EmailMain.Text = Me.Subscriber.GetAddressText("Email")

            'Show Billing address
            If Me.Subscriber.GetAddressText("Postal", "Billing") Is Nothing Then
                Me.BillingMain.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "#### Currently No Billing Address ####" _
                               , "#### Actualmente no tiene dirección de facturación ####")
            Else
                Me.BillingMain.Text = Me.Subscriber.GetAddressText("Postal", "Billing").Replace(",", ", ")
            End If

            'Show mailing address
            If Me.Subscriber.GetAddressText("Postal", "Main") Is Nothing Then
                Me.PostalMain.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "#### Currently No Postal Address ####" _
                               , "#### Actualmente no tiene dirección de envío ####")
            Else
                Me.PostalMain.Text = Me.Subscriber.GetAddressText("Postal", "Main").Replace(",", ", ")
            End If

            'Show IsReceiveMail as yes or no
            Select Case Me.Master.db.IsDBNull(Me.Subscriber.SubscriberRow("IsReceiveMail"), False)
                Case True
                    Me.IsReceiveMailYesNo.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "No" _
                               , "No")
                Case False
                    Me.IsReceiveMailYesNo.Text = IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "Yes" _
                               , "Si")
            End Select

        End If
    End Sub

    Protected Sub UpdateDetailsBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateDetailsBtn.Click
        Response.Redirect("../pages/pg112SubscriberDetailsMaint.aspx?" & Me.Master.UserSession.QueryString)
    End Sub


    Public Sub BuildAffiliations()
        '******************************************************
        'Description:	Builds and Displays Affiliations
        '******************************************************
        Dim sql As String = ""
        '10/2/20    James Woosnam   SIR4937 - Show Subscriber Category in affiliate list
        '13/2/20    James Woosnam   SIR5019 - Output subscriber category as Not Applicable if null or spaces
        '3/2/20     James Woosnam   SIR5094 - Only show 'Current' subscriber affiliate parents 
        '8/7/20     Julian Gates    SIR5097 - Remove Subscriber Category from BuildAffiliations grid

        sql = "SELECT DISTINCT Subscriber.SubscriberId as SubscriberId " _
          & "		, Subscriber.SubscriberName " _
          & "		, SubscriberAffiliate.AffiliateReferenceId " _
          & "		, SecureSubscriber.SubscriberId SecureSubscriberId " _
          & " FROM Subscriber" _
          & "		INNER JOIN SubscriberAffiliate " _
          & "		On SubscriberAffiliate.ParentSubscriberId = Subscriber.SubscriberId " _
          & "		AND GetDate() Between SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate" _
          & "		LEFT JOIN " & Me.SubscriberTable("SecureSubscriber") _
          & "		ON SecureSubscriber.SubscriberId = SubscriberAffiliate.ParentSubscriberId " _
          & "	WHERE SubscriberAffiliate.ChildSubscriberId = " & Me.Master.UserSession.Data("SubscriberId") _
          & " AND SubscriberAffiliate.ParentSubscriberId Not In (30000," & Me.Master.UserSession.Data("SubscriberId") & ")" _
          & " AND Subscriber.SubscriberStatus = 'Current'" _
          & " Order By Subscriber.SubscriberName "

        Dim tbl As DataTable = Me.Master.db.GetDataTableFromSQL(sql)

        If tbl.Rows.Count > 0 Then
            For Each row As DataRow In tbl.Rows
                Dim tRow As New TableRow()
                Dim tCell As New TableCell()
                tCell = New TableCell()
                tCell.Text = row("SubscriberName").ToString()
                tCell.VerticalAlign = VerticalAlign.Top
                tRow.Cells.Add(tCell)
                Me.AffiliatedToList.Rows.Add(tRow)
            Next
            Me.AffiliatedToListDataPanel.Visible = True
        Else
            Me.AffiliatedToListDataPanel.Visible = False
        End If

    End Sub

    Sub GetPEPWebProductRenewalNotification()
        '************************************************************************
        ' Shows a renewal notification if web product subscriptions have or are going to expire soon.
        '************************************************************************

        Dim strSQL As String = ""
        Try

            Dim cmd As New SqlCommand("sp235WebProducts", Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                      , Me.Master.UserSession.Data("SubscriberId")))

            Dim tbl As DataTable = Me.Master.db.GetDataTableFromSQL(cmd)

            If tbl.Rows.Count = 0 Then
                Exit Sub
            End If
            For Each row As DataRow In tbl.Rows
                Dim tRow As New TableRow()
                Dim tCell As New TableCell()

                If row("CurrentSubscriptionEndDate") > CDate("1/1/1990") Then
                    Dim strOrderType As String = ""
                    strOrderType = Me.Master.db.DLookup("OrderType", "SalesOrder", "OrderNumber=" & row("CurrentSubscriptionOrderNumber"))
                    Select Case strOrderType
                        Case "Individual", "IndividualRemote"
                            '15/1/20    James Woosnam   SIR4970 - show renewal link for any product recurring by month.
                            '01/10/20	Jmes Woosnam	SIR5118 - Exclude products with DisableAutoRenewalFlag set to true
                            Dim prd As New BusinessLogic.Product(row("PrimaryProductCode"), Master.db, Master.UserSession)
                            If Master.db.IsDBNull(prd.ProductRow("RecurringSubscriptionUnitType"), "").ToString.ToLower = "months" _
                                And Not Master.db.IsDBNull(prd.ProductRow("DisableAutoRenewalFlag"), False) _
                                Then
                                Dim sCellText() As String = {"", "", ""}
                                If row("PrimaryProductCode").ToString.ToLower.Contains("-es") Then
                                    sCellText(0) = "Observe por favor: Su suscripción al " & row("DisplayProductName") & " está por expirar/o ha expirado el: " & FormatDateTime(row("CurrentSubscriptionEndDate"), 1) & " a :" & FormatDateTime(row("CurrentSubscriptionEndDate"), 4) & "."
                                    sCellText(1) = "<br>Seleccione el enlaceabajo para renovar ahora."
                                    sCellText(2) = "El enlace de renovación del producto será mostrado aquí luego de actualizar sus datos de suscriptor."
                                Else
                                    sCellText(0) = "Please Note: Your subscription to the " & row("DisplayProductName") & " is due to expire/or has expired on: " & FormatDateTime(row("CurrentSubscriptionEndDate"), 1) & " at:" & FormatDateTime(row("CurrentSubscriptionEndDate"), 4) & "."
                                    sCellText(1) = "<br>Select the link below to renew now."
                                    sCellText(2) = "Product renewal link will be shown here after updating your subscriber details."
                                End If

                                tRow = New TableRow()
                                tCell = New TableCell()
                                tCell.CssClass = "fldView"
                                tCell.Text = sCellText(0)
                                If Me.Subscriber.IsSubscriberValidForOrdering() <> "" Then
                                Else
                                    tCell.Text += sCellText(1)
                                End If
                                tCell.VerticalAlign = VerticalAlign.Top
                                tRow.Cells.Add(tCell)
                                Me.ProductRenewalNotification.Rows.Add(tRow)
                                tRow = New TableRow()
                                tCell = New TableCell()
                                If Me.Subscriber.IsSubscriberValidForOrdering() <> "" Then
                                    tCell.CssClass = "fldView"
                                    tCell.Text = sCellText(2)
                                Else
                                    tCell.CssClass = "productLink"
                                    tCell.Text = "<a href='../Pages/pg232RemoteOrder.aspx?&PageMode=RenewOrder&ProductCode=" & row("ProductCode") & "&" & Me.Master.UserSession.QueryString & "'>" & row("DisplayProductName") & "</a>"
                                End If
                                tCell.VerticalAlign = VerticalAlign.Top
                                tRow.Cells.Add(tCell)
                                Me.ProductRenewalNotification.Rows.Add(tRow)
                                Me.TableRowProductRenewalNotification.Visible = True
                            End If

                    End Select
                End If

            Next

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "An Unexpected error has occured.  Please contact support." _
                               , "Un error inesperado ha ocurrido. Por favor contacte a soporte."), ex))

        End Try

    End Sub


    Sub GetWebProductList()
        Dim strSQL As String = ""
        Dim productCombinationMissing As Boolean = False
        Dim productCodes As String = ""
        Dim orderNumbers As String = ""
        Dim emailText As String = ""

        Try
            Dim cmd As New SqlCommand("sp237GetSubscriberPEPWebSubscriptions", Me.Master.db.DBConnection, Me.Master.db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                      , Me.Master.UserSession.Data("SubscriberId")))

            Dim tbl As DataTable = Me.Master.db.GetDataTableFromSQL(cmd)

            If tbl.Rows.Count > 0 Then
                For Each row As DataRow In tbl.Rows
                    If row("ProductName") <> "" _
                      And Not row("ProductCombinationId") Is System.DBNull.Value Then
                        Dim tRow As New TableRow()
                        Dim tCell As New TableCell()
                        tCell.Text = row("DisplayProductName")
                        tRow.Cells.Add(tCell)
                        '12/11/20   Julian Gates    SIR5148 - Make Subscribed to product code read only and not a link.
                        tCell = New TableCell()
                        tCell.Text = row("ProductCode")
                        tRow.Cells.Add(tCell)
                        tCell = New TableCell()
                        tCell.Text = FormatDateTime(row("RecurringSubscriptionEndDate"), 1) & " " & FormatDateTime(row("RecurringSubscriptionEndDate"), 4)
                        tRow.Cells.Add(tCell)
                        Me.WebProductList.Rows.Add(tRow)
                        Me.WebProductListRow.Visible = True
                        If row("ProductCode") = "IJP-es" Then
                        End If
                    Else
                        productCombinationMissing = True
                        productCodes += " (" & row("ProductCode") & ") "
                        orderNumbers += " (" & row("OrderNumber") & ") "
                    End If
                Next
            End If

            If productCombinationMissing Then
                Me.WebProductListRow.Visible = False

                emailText = "Subscriber " & Me.FirstName.Text & " " & Me.LastName.Text & " Id: " & Me.Master.UserSession.Data("SubscriberId") & " ordered the following products " & productCodes & " which there is no valid product combination."
                emailText += " Please add a product combination for these products as soon as possible. Order numbers are " & orderNumbers & "."

                'Send product combination error email if combination is missing.
                Dim email As New BusinessLogic.Email(Me.Master.db)
                email.SendErrorEmail("PaDS Product Combination Error", emailText)
            End If

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                          , "An Unexpected error has occured.  Please contact support." _
                          , "Un error inesperado ha ocurrido. Por favor contacte a soporte."), ex))
        End Try
    End Sub

    '31/10/19   Julian Gates    SIR4949 - Change Order buttons to be PEP and IJP versions.
    Protected Sub NewPEPOrderBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles NewPEPOrderBtn.Click
        Try
            Dim vw As New DataView(Me.Subscriber.CompanyAccount, "CompanyId=2", "", DataViewRowState.CurrentRows)
            If vw.Count = 0 Then Subscriber.AddCompanyAccount(2, "Individual", 4, "Full", Subscriber.SubscriberRow("DefaultPostalAddressId"))
            vw = New DataView(Me.Subscriber.SubscriberAffiliate, "ParentSubscriberId=29002", "", DataViewRowState.CurrentRows)
            Dim vwForCat As New DataView(Me.Subscriber.SubscriberAffiliate, "ParentSubscriberId=29001", "", DataViewRowState.CurrentRows)
            Dim SubscriberCategory As String = Nothing
            If vwForCat.Count > 0 Then SubscriberCategory = Master.db.IsDBNull(vwForCat(0)("SubscriberCategory"), "Ordinary")
            If vw.Count = 0 Then Subscriber.AddSubscriberAffiliate(29002, "", SubscriberCategory)
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "An Unexpected error has occured.  Please contact support." _
                               , "Un error inesperado ha ocurrido. Por favor contacte a soporte."), ex))
        End Try

        If Master.WebForm.IsValid Then Response.Redirect("../Pages/pg232RemoteOrder.aspx?PageMode=NewOrder&CompanyId=2&" & Me.Master.UserSession.QueryString)
    End Sub

    Protected Sub NewIJPOrderBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles NewIJPOrderBtn.Click
        Try
            Dim vw As New DataView(Me.Subscriber.CompanyAccount, "CompanyId=1", "", DataViewRowState.CurrentRows)
            If vw.Count = 0 Then Subscriber.AddCompanyAccount(1, "Individual", 4, "Full", Subscriber.SubscriberRow("DefaultPostalAddressId"))
            vw = New DataView(Me.Subscriber.SubscriberAffiliate, "ParentSubscriberId=29001", "", DataViewRowState.CurrentRows)
            Dim vwForCat As New DataView(Me.Subscriber.SubscriberAffiliate, "ParentSubscriberId=29002", "", DataViewRowState.CurrentRows)
            Dim SubscriberCategory As String = Nothing
            If vwForCat.Count > 0 Then SubscriberCategory = Master.db.IsDBNull(vwForCat(0)("SubscriberCategory"), "Ordinary")
            If vw.Count = 0 Then Subscriber.AddSubscriberAffiliate(29001, "", SubscriberCategory)
        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception(IIf(Me.DisplayLanguage = BusinessLogic.UserSession.DisplayLanguages.English _
                               , "An Unexpected error has occured.  Please contact support." _
                               , "Un error inesperado ha ocurrido. Por favor contacte a soporte."), ex))
        End Try

        If Master.WebForm.IsValid Then Response.Redirect("../Pages/pg232RemoteOrder.aspx?PageMode=NewOrder&CompanyId=1&" & Me.Master.UserSession.QueryString)
    End Sub

    Function SubscriberTable(ByVal strAliasName As String) As String

        SubscriberTable = " Subscriber " & strAliasName _
            & " INNER JOIN SubscriberAffiliate SAJoin" _
            & " ON SAJoin.ChildSubscriberId = " & strAliasName & ".SubscriberId" _
            & " AND SAJoin.ParentSubscriberId IN (0" & Me.Master.UserSession.Data("AuthorisedSubscribers") & ")" _
            & " AND " & StdCode.vFQ(Now(), "D") & " Between SAJoin.StartDate AND SAJoin.EndDate"
    End Function
End Class
