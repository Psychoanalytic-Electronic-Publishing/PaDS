﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'17/09/19  Julian Gates   Initial New version

Partial Class Pages_pg113SubscriberIsolatedAction
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim ErrorMessage As String = Nothing
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Subscriber Merge ", "")
        If Me.IsPostBack Then
        Else
            If Request.QueryString("Action") = "" Then
                uPage.PageError = "Action not passed in"
                Exit Sub
            Else
                ViewState("Action") = Request.QueryString("Action")
            End If
            Select Case ViewState("Action")
                Case "Merge"
                    If Request.QueryString("MergeIntoSubscriberId") <> "" And Request.QueryString("MergeFromSubscriberId") <> "" Then
                        ViewState("MergeIntoSubscriberId") = Request.QueryString("MergeIntoSubscriberId")
                        ViewState("MergeFromSubscriberId") = Request.QueryString("MergeFromSubscriberId")
                    Else
                        uPage.PageError = "Invalid Parameters has been passed in"
                        Exit Sub
                    End If
                Case "Reject"
                    If Request.QueryString("SubscriberId") <> "" Then
                        ViewState("SubscriberId") = Request.QueryString("SubscriberId")
                        RejectSubscriber()
                    Else
                        uPage.PageError = "Invalid Parameters has been passed in"
                        Exit Sub
                    End If
            End Select

        End If
    End Sub

    Sub PageSetup()
        Try
            Me.pageHeaderTitle.Text = "Subscriber Merge"

            Me.MergeFromSubscriberLink.NavigateUrl = "../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & ViewState("MergeFromSubscriberId") & "&" & uPage.UserSession.QueryString
            Me.MergeFromSubscriberLink.Text = ViewState("MergeFromSubscriberId") & " " & Me.uPage.db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & ViewState("MergeFromSubscriberId"))

            Me.MergeToSubscriberLink.NavigateUrl = "../pages/pg111SubscriberDisplay.aspx?SubscriberId=" & ViewState("MergeIntoSubscriberId") & "&" & uPage.UserSession.QueryString
            Me.MergeToSubscriberLink.Text = ViewState("MergeIntoSubscriberId") & " " & Me.uPage.db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & ViewState("MergeIntoSubscriberId"))
            Dim entityType As String = Me.uPage.db.DLookup("EntityType", "Subscriber", "SubscriberId=" & ViewState("MergeIntoSubscriberId"))
            Me.SendConfirmationRow.Visible = entityType = "Person"
            Me.SendConfirmationEmail.Checked = entityType = "Person" And Not IsPostBack
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        uPage.PagePreRender()
        Me.PageSetup()
    End Sub
    Sub RejectSubscriber()

        Dim msg As String = Nothing
        Try
            Dim Subscriber As New BusinessLogic.Subscriber(ViewState("SubscriberId"), uPage.db, uPage.UserSession)
            Subscriber.RejectSubscriber()
            msg = "Subscriber Rejected"
        Catch ex As Exception
            msg = "Reject Subscriber failed:" & ex.Message
            Me.uPage.PageError = msg
        End Try
        If uPage.IsValid Then Response.Redirect("../pages/pg111SubscriberDisplay.aspx?IsolatedActionMessage=" & msg & "&SubscriberId=" & ViewState("SubscriberId") & "&" & uPage.UserSession.QueryString)

    End Sub

    Protected Sub MergeSubscribersBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MergeSubscribersBtn.Click
        Dim msg As String = Nothing
        Try
            Dim Subscriber As New BusinessLogic.Subscriber(ViewState("MergeIntoSubscriberId"), uPage.db, uPage.UserSession)
            Subscriber.MergeSubscriber(ViewState("MergeIntoSubscriberId"), ViewState("MergeFromSubscriberId"), Me.SendConfirmationEmail.Checked)
            msg = "This record has been successfully Merged"
            If Me.SendConfirmationEmail.Checked Then
                msg += " and WebUser/Password confirmation email sent"
            End If
        Catch ex As Exception
            msg = "Merge failed:" & ex.Message
            Me.uPage.PageError = msg
        End Try
        If uPage.IsValid Then Response.Redirect("../pages/pg111SubscriberDisplay.aspx?PageMode=Update&IsolatedActionMessage=" & msg & "&SubscriberId=" & ViewState("MergeIntoSubscriberId") & "&" & uPage.UserSession.QueryString)
    End Sub

End Class
