﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web
Imports BusinessLogic
'Modification History
'20/05/2015    Julian Gates   Initial Version

Partial Class Pages_pg503ProductSelect
    Inherits System.Web.UI.Page
    Dim Product As Product = Nothing
    Public uPage As UserPage

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Product List", "")
        Me.pageHeaderTitle.Text = "Product List"

        If Page.IsPostBack Then
          
        Else
            Me.ProductGridView.FilterExpression = "ProductStatus = 'Current'"
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        GridSetup()

    End Sub

    Sub PageSetup()
        CType(Me.ProductGridView.Columns("CompanyName"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL("SELECT CompanyName FROM " & uPage.CompanyTable("Company", uPage.UserSession.UserId))
        Dim prod As New BusinessLogic.Product(uPage.db)
        Dim vw As New DataView(prod.AllAssociatedProductRates, " IsMissing <> ''", "", DataViewRowState.CurrentRows)

        If vw.Count <> 0 Then
            Me.AssociatedProductWarningTr.Visible = True
            Me.AssociatedproductWarningLbl.Text = "There are missing rates against the following associated products:"
            For Each row As DataRowView In vw
                Me.AssociatedproductWarningLbl.Text += "<br>" & row("AssociatedProductCode") & "  (" & row("CurrencyCode") & " " & row("RateType") & " " & row("AccountType") & " " & row("SubscriberCategory") & " " & ")"
            Next
        End If
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub GridSetup()
        Try
            Dim Sql As String = ""
            Sql = "SELECT Product.ProductCode"
            Sql += " ,Product.ProductName"
            Sql += " ,Product.ProductStatus"
            Sql += " ,Company.CompanyName"
            Sql += " ,Product.CompanyId"
            Sql += " FROM Product"
            Sql += "    INNER JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId)
            Sql += "    ON Company.CompanyId = Product.CompanyId"
            Sql += " WHERE ISNULL(IsParent,0) <> 0 "
            Sql += " ORDER BY ProductName, ProductStatus"
            Me.ProductDatasource.SelectCommand = Sql

            'Populate dropdown fields
            '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria and order by
            CType(Me.ProductGridView.Columns("ProductStatus"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL("SELECT Lookup.LookupItemKey" _
                                                                                                                                                            & "    , Lookup.Name" _
                                                                                                                                                            & " FROM Lookup" _
                                                                                                                                                            & " WHERE LookupName = 'ProductStatus'" _
                                                                                                                                                            & " AND LookupStatus = 'Active'" _
                                                                                                                                                            & " ORDER BY DisplayOrder,Name,LookupItemKey"
                                                                                                                                                            )
            'show filter row menu
            Me.ProductGridView.Settings.ShowFilterRowMenu = True

        Catch ex As Exception
            uPage.PageError = ex.ToString
        End Try
    End Sub

    Protected Sub AddNewBtn_Click(sender As Object, e As EventArgs) Handles AddNewBtn.Click
        Response.Redirect("../Pages/pg504ProductMaint.aspx?" & uPage.UserSession.QueryString & "&PageMode=Add")
    End Sub
End Class
