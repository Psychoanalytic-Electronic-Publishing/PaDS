﻿Imports System.Data
Imports System.Data.SqlClient
Imports BusinessLogic.Subscriber
'Modification History
'15/04/20  Julian Gates   Initial New version
'19/08/20   Julian Gates    SIR5099 - Add Audit link
'17/02/21   Julian Gates    SIR5166 - Removed old asp page links
'03/03/21   Julian Gates    SIR5208 - Add ASPxSummaryItem row to Cashbook table.

Partial Class Pages_pg171BankDepositMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Enum PageModes
        Add
        Update
    End Enum

    Property pageMode As PageModes
        Set(value As PageModes)
            ViewState("PageMode") = value

        End Set
        Get
            If ViewState("PageMode") Is Nothing Then ViewState("PageMode") = "Add"
            Return ViewState("PageMode")
        End Get
    End Property
    Private _BankDeposit As BusinessLogic.BankDeposit = Nothing
    Public Property BankDeposit() As BusinessLogic.BankDeposit
        Get
            If Me._BankDeposit Is Nothing Then
                Me._BankDeposit = New BusinessLogic.BankDeposit(Me.uPage.db, uPage.UserSession)
            End If
            Return Me._BankDeposit
        End Get
        Set(ByVal value As BusinessLogic.BankDeposit)
            Me._BankDeposit = value
        End Set
    End Property

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Bank Deposit Maintenance ", "")

        'Only allow update by AuthorityLevel Admin users
        Select Case Me.uPage.UserSession.AuthorityLevel
            Case BusinessLogic.UserSession.AuthorityLevels.CompanyAdmins, BusinessLogic.UserSession.AuthorityLevels.SuperCompanyAdmins
            Case Else
                Response.Redirect("../Pages/pg100HomeAdmin.aspx?InfoMsg=Your userid does not allow you access to this page." & uPage.UserSession.QueryString)
        End Select

        Try
            If Page.IsPostBack Then
                Me.BankDeposit.MainDataset = CType(ViewState("MainDataSet"), DataSet)
            Else
                If Request.QueryString("BankDepositId") <> "" Then
                    Me.pageMode = PageModes.Update
                    Try
                        Me.txtBankDepositId.Value = Request.QueryString("BankDepositId")
                        Me.BankDeposit = New BusinessLogic.BankDeposit(CInt(Request.QueryString("BankDepositId")), Me.uPage.db, Me.uPage.UserSession)
                    Catch ex As Exception
                        Me.uPage.PageError = "Invalid Parameter has been passed in"
                    End Try
                Else
                    Me.pageMode = PageModes.Add
                    Me.PaymentCardMerchantRow.Focus()
                    Me.AddDateBanked.Text = System.DateTime.Today
                End If

                If Me.uPage.IsValid Then
                    ReadRecord()
                End If
            End If
        Catch ex As Exception
            uPage.PageError = "An unexpected Error has occured.  Please contact support." & ex.ToString
        End Try

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If

        CashbookGridSetup()
    End Sub

    Sub PageSetup()
        Me.AddModeFields.Visible = Me.pageMode = PageModes.Add
        Me.UpdateModeFields.Visible = Me.pageMode = PageModes.Update
        Select Case Me.pageMode
            Case PageModes.Add
                uPage.pageTitle = "Add New Bank Deposit"
                Me.PaymentCardMerchantRow.Visible = Me.CompanyBankAccount.SelectedValue <> Nothing And PaymentType.SelectedValue = "Credit Card"
                Me.AutoSettleRow.Visible = Me.CompanyBankAccount.SelectedValue <> Nothing And PaymentCardMerchant.SelectedValue.ToUpper = "CYBERSOURCE" And PaymentType.SelectedValue = "Credit Card"
                Me.IsEmailReceiptRow.Visible = Me.CompanyBankAccount.SelectedValue <> Nothing And PaymentCardMerchant.SelectedValue.ToUpper = "CYBERSOURCE" And PaymentType.SelectedValue = "Credit Card"

                If Me.CompanyBankAccount.SelectedValue <> Nothing And PaymentType.SelectedValue <> Nothing Then
                    Me.CashbookListTable.Visible = True
                End If
                'default all lines to true
                Me.CashbookGridView.Selection.SelectAll()
            Case PageModes.Update
                uPage.pageTitle = "Bank Deposit Maint For: " & BankDeposit.BankDepositId & " - " & Me.BankDeposit.CompanyName
                Me.CashbookListTable.Visible = True
        End Select
        Me.TimedPanel.Visible = IsNumeric(ViewState("BatchJobId"))
        Me.CashbookListTable.Visible = Not Me.TimedPanel.Visible

        Me.pageHeaderTitle.Text = uPage.pageTitle

        '19/08/20   Julian Gates    SIR5099 - Add Audit link
        Me.AuditLink.NavigateUrl = "../pages/pg040AuditLogDisplay.aspx?FltrUpdatedRecordFamily=BankDeposit&FltrUpdatedRecordFamilyKey=" & Me.BankDeposit.BankDepositId & "&" & uPage.UserSession.QueryString
        Me.AuditLink.Text = "View Audit"
        Me.AuditLink.ToolTip = "View Audit for this record"
    End Sub

    Protected Sub CashbookGridView_DataBound(ByVal sender As Object, ByVal e As System.EventArgs) Handles CashbookGridView.DataBound
        Select Case Me.pageMode
            Case PageModes.Update
                Me.CashbookGridView.Columns("#").Visible = False
        End Select
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Select Case Me.pageMode
            Case PageModes.Add
                'populate dropdowns
                Dim sql As String = "SELECT CAST(cba.CompanyId AS VARCHAR) + '^' + cba.BankSortCode + '^' + cba.BankAccountNumber + '^' + cba.CurrencyCode As Value" _
                         & "     ,Company.CompanyShortName + ' ' + cba.BankAccountName + ' ' + cba.CurrencyCode As Text" _
                         & " FROM CompanyBankAccount cba" _
                         & "	INNER JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                         & "	ON Company.CompanyId= cba.CompanyId" _
                         & " ORDER BY 2"
                Me.uPage.PopulateDropDownListFromSQL(Me.CompanyBankAccount, sql, uPage.db.DBConnection, "<--Select-->")
                Me.uPage.PopulateRadioButtonListFromLookup(Me.AutoSettle, "YesNo")
                Me.uPage.PopulateDropDownListFromLookup(Me.PaymentType, "PaymentType", uPage.db.DBConnection, "<--Select-->")
                Me.PaymentType.SelectedValue = "Credit Card"

            Case PageModes.Update
                Me.uPage.PopulatePageFieldsFromDataRow(Me.BankDeposit.BankDepositRow)
                Me.AmountDepositedText.Text = Me.BankDeposit.BankDepositRow("AmountDeposited")
                Me.BankAccountName.Text = Me.BankDeposit.BankAccountName
                Me.CurrencyCode.Text = Me.BankDeposit.CurrencyCode
        End Select
    End Sub

    Sub SaveRecord()
        '******************************************************
        'Description:	Save the record either by updating
        '******************************************************
        Try
            uPage.db.BeginTran()
            Try

                Me.uPage.PopulateDataRowFromPageFields(Me.BankDeposit.BankDepositRow)
                Me.BankDeposit.Save()
                Me.uPage.db.CommitTran()

            Catch ex As Exception
                uPage.db.RollbackTran()
                Throw ex
            End Try

        Catch ex As Exception
            Me.uPage.PageError = "An Unexpected Error has occured.  Please contact support" & ex.ToString
        End Try

        If Me.uPage.IsValid Then
            Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=Bank Deposit has been saved&BankDepositId=" & Me.BankDeposit.BankDepositId & "&" & Me.uPage.UserSession.QueryString)
        End If
    End Sub

    Protected Sub SaveBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        Try
            'Do DateBanked field validation
            If Me.DateBanked.Text = "" Then
                Me.uPage.PageError = "Date Banked is mandatory"
                Me.DateBanked.CssClass = "fldEntryError"
            Else
                Me.DateBanked.CssClass = "fldEntry"
                If Not uPage.StdCode.IsValidDate(Me.DateBanked.Text) Then
                    Me.uPage.PageError = "Date Banked is an invalid date"
                    Me.DateBanked.CssClass = "fldEntryError"
                Else
                    Me.DateBanked.CssClass = "fldEntry"
                End If
            End If
            If Not uPage.IsValid Then Exit Sub

            SaveRecord()
        Catch ex As Exception
            Me.uPage.PageError = "An unexpected Error has occured. Please contact support." & ex.ToString
        End Try
    End Sub

    Protected Sub ConfirmBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ConfirmBtn.Click
        Try
            Me.uPage.DropDownValidateMandatory(Me.CompanyBankAccount, "Target Bank Account")
            Me.uPage.DropDownValidateMandatory(Me.PaymentType, "Payment Type")
            If Me.AutoSettle.SelectedValue = Nothing And PaymentCardMerchant.SelectedValue.ToUpper = "CYBERSOURCE" And PaymentType.SelectedValue = "Credit Card" Then
                uPage.FieldErrorControl(Me.AutoSettle, "Select Yes or No for Automatic settlement with Cybersource.")
            End If

            'Check to see if Cashbook line selected
            If Me.CashbookGridView.GetSelectedFieldValues({"CashbookId"}).Count = 0 Then
                Me.uPage.PageError = "Please select at least one Cashbook line"
            End If

            'Do DateBanked field validation
            If Me.AddDateBanked.Text = "" Then
                Me.uPage.PageError = "Date Banked is mandatory"
                Me.AddDateBanked.CssClass = "fldEntryError"
            Else
                Me.AddDateBanked.CssClass = "fldEntry"
                If Not uPage.StdCode.IsValidDate(Me.AddDateBanked.Text) Then
                    Me.uPage.PageError = "Date Banked is an invalid date"
                    Me.AddDateBanked.CssClass = "fldEntryError"
                Else
                    Me.AddDateBanked.CssClass = "fldEntry"
                End If
            End If

            If Not uPage.IsValid Then Exit Sub

            Dim cashbookIds As String = ""
            Dim data As List(Of Object) = Me.CashbookGridView.GetSelectedFieldValues({"CashbookId"})
            For i As Integer = 0 To data.Count - 1
                cashbookIds += IIf(cashbookIds = "", "", ",") & data(i)
            Next

            Dim keys As String() = Me.CompanyBankAccount.SelectedValue.ToString.Split("^")
            'This code taken from 450reports page and UpdateTimer below
            Dim BankDeposit As New BusinessLogic.BankDeposit(uPage.db, uPage.UserSession)
            ViewState("BatchJobId") = BankDeposit.SubmitAddFromCashbookIds(cashbookIds _
                                                        , CInt(keys(0)) _
                                                        , CStr(keys(1)) _
                                                        , CStr(keys(2)) _
                                                        , Me.Notes.Text _
                                                        , Me.IsEmailReceipt.Checked _
                                                        , CDate(Me.AddDateBanked.Text) _
                                                        , Me.AutoSettle.SelectedValue = "Yes"
                                                        )
            Me.UpdateTimer.Enabled = True
        Catch ex As Exception
            Me.uPage.PageError = "An unexpected Error has occured. Please contact support." & ex.ToString
        End Try

    End Sub

    Protected Sub UpdateTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateTimer.Tick
        Try
            If IsNumeric(ViewState("BatchJobId")) Then
                Dim BatchLog As New BusinessLogic.BatchLog(uPage.db)
                Me.BatchLogLines.Text = BatchLog.GetBatchLogLinesHTML(ViewState("BatchJobId"))
                Select Case uPage.db.IsDBNull(uPage.db.DLookup("MAX(BatchLogStatus)", "BatchLog", "BatchJobId=" & ViewState("BatchJobId")), "")
                    Case "Failed"
                        Me.UpdateTimer.Enabled = False
                    Case "Complete"
                        Me.UpdateTimer.Enabled = False
                        Response.Redirect("pg171BankDepositMaint.aspx?PageMode=Update" _
                                          & "&BankDepositId=" & uPage.db.DLookup("MAX(BankDepositId)", "BankDeposit", "") _
                                          & "&" & uPage.UserSession.QueryString)
                    Case Else
                        Me.UpdateTimer.Enabled = True
                End Select
            Else
                Me.UpdateTimer.Enabled = False
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub

    Protected Sub BackBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BackBtn.Click, BackBtn1.Click
        Response.Redirect("../pages/pg170BankDepositSelect.aspx?" & Me.uPage.UserSession.QueryString)
    End Sub

    Protected Sub AddNewBtn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles AddNewBtn.Click
        Response.Redirect("../pages/pg171BankDepositMaint.aspx?" & Me.uPage.UserSession.QueryString)
    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        ViewState("MainDataSet") = Me.BankDeposit.MainDataset
        Me.PageSetup()
    End Sub

    Protected Sub CompanyBankAccount_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CompanyBankAccount.SelectedIndexChanged
        If Me.CompanyBankAccount.SelectedValue <> Nothing Then
            Dim keys As String() = Me.CompanyBankAccount.SelectedValue.ToString.Split("^")
            Dim Sql As String = "Select LookupItemKey As Value, Name As Text" _
                       & " FROM Lookup" _
                       & " WHERE LookupName = 'PaymentCardMerchant'" _
                       & " AND CompanyId = " & keys(0) _
                       & " AND LookupStatus = 'Active'" _
                       & " AND LookupItemKey <> 'blank'" _
                       & " ORDER BY DisplayOrder,Name,LookupItemKey"
            Me.uPage.PopulateRadioButtonListFromSql(Me.PaymentCardMerchant, Sql)

            Me.PaymentCardMerchant.SelectedIndex = 0
            CashbookGridSetup()
        End If
    End Sub

    Sub CashbookGridSetup()
        Dim sCR As String = System.Environment.NewLine
        Dim Sql As String = ""
        Try
            If Me.CompanyBankAccount.SelectedValue = "" And pageMode <> PageModes.Update Then
                Exit Sub
            End If
            Dim keys As String() = Me.CompanyBankAccount.SelectedValue.ToString.Split("^")

            Sql = "Select Cashbook.CashbookId " & sCR
            Sql += "		,Cashbook.CompanyId " & sCR
            Sql += "		,Cashbook.OrderNumber " & sCR
            Sql += "		,Cashbook.EntryDate " & sCR
            Sql += "		,SubscriberDetails = CAST(Cashbook.SubscriberId AS VARCHAR) + ' ' + Subscriber.SubscriberName" & sCR
            Sql += "		,Cashbook.Amount" & sCR
            Sql += "		,OrderNumberProduct = CAST(Cashbook.OrderNumber AS VARCHAR) + CASE WHEN SalesOrder.PrimaryProductCode IS NULL THEN '' ELSE ' (' + SalesOrder.PrimaryProductCode + ')' END" & sCR
            Sql += " FROM Cashbook" & sCR
            Sql += "		LEFT JOIN SalesOrder  " & sCR
            Sql += "		ON SalesOrder.OrderNumber = Cashbook.OrderNumber " & sCR
            Sql += "		INNER JOIN Subscriber  " & sCR
            Sql += "		ON Subscriber.SubscriberId = Cashbook.SubscriberId " & sCR
            If Me.pageMode = PageModes.Add Then
                Sql += " WHERE Cashbook.CompanyId = " & keys(0) & sCR
                Sql += " AND Cashbook.CurrencyCode = '" & keys(3) & "'" & sCR
                Sql += " AND Cashbook.PaymentType = '" & Me.PaymentType.SelectedValue & "'" & sCR
                Sql += " AND Cashbook.BankDepositId  Is Null " & sCR
                Sql += " AND Cashbook.CashbookStatus = 'Confirmed' " & sCR
                If Me.PaymentType.SelectedValue = "Credit Card" Then
                    Sql += " AND Cashbook.PaymentCardMerchant = '" & PaymentCardMerchant.SelectedValue & "'" & sCR
                End If
            Else
                Sql += " WHERE Cashbook.BankDepositId =" & BankDeposit.BankDepositId & sCR
            End If
            Sql += " ORDER BY Cashbook.EntryDate Asc " & sCR

            Me.CashbookDatasource.SelectCommand = Sql
            Me.CashbookDatasource.DataBind()
            Me.CashbookGridView.DataBind()

        Catch ex As Exception
            uPage.PageError = ex.ToString & Sql
        End Try
    End Sub
End Class
