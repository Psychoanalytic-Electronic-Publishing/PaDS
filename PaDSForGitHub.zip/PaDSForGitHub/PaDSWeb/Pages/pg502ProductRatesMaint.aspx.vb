﻿Imports System.Data.SqlClient
Imports System.Data
Imports System.IO
Imports DevExpress.Web

'Modification History
'21/05/2015    Julian Gates   Initial Version

Partial Class Pages_pg502ProductRatesMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Private copiedValues As Hashtable = Nothing
    Private copiedFields() As String = {"ProductCode", "CurrencyCode", "RateType", "AccountType", "SubscriberCategory", "DeliveryArea", "ProductRate", "SellOnWebFlag", "NewUserRateFlag", "CreatedDateTime", "CreatedByUserId"}

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Product Rate Add/Update", "")
        Me.pageHeaderTitle.Text = "Product Rate Add/Update"

        If Page.IsPostBack Then

        Else

        End If
        If Request.QueryString("ProductCode") <> "" And Request.QueryString("CompanyId") <> "" Then
            Me.ProductCode.Text = Request.QueryString("ProductCode")
            Me.TargetProductCode.Value = Me.ProductCode.Text
            Me.TargetCompanyId.Value = Request.QueryString("CompanyId")
        Else
            uPage.PageError = "Invalid Parameter has been passed in."
        End If

        If Request.QueryString("InfoMsg") <> "" Then
            InfoMsg.Text = Request.QueryString("InfoMsg")
        End If
    End Sub

    Sub PageSetup()
        Me.pageHeaderTitle.Text = "Rates for: " & Me.ProductCode.Text
        Me.ProductName.Text = uPage.db.DLookup("ProductName", "Product", "ProductCode='" & Me.ProductCode.Text & "'")
        'Populate dropdown fields
        Try
            CType(Me.ProductRatesGridView.Columns("CurrencyCode"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL(Me.CurrencyCodeDropdownSQL())
            CType(Me.ProductRatesGridView.Columns("RateType"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL(Me.LookupDropdownSQL("RateType"))
            CType(Me.ProductRatesGridView.Columns("AccountType"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL(Me.LookupDropdownSQL("AccountType"))
            CType(Me.ProductRatesGridView.Columns("SubscriberCategory"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL(Me.LookupDropdownSQL("SubscriberCategory"))
            CType(Me.ProductRatesGridView.Columns("DeliveryArea"), GridViewDataComboBoxColumn).PropertiesComboBox.DataSource = Me.uPage.db.GetDataTableFromSQL(Me.LookupDropdownSQL("DeliveryArea"))
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try

        'show filter row menu
        Me.ProductRatesGridView.Settings.ShowFilterRowMenu = True
        Me.ProductRatesGridView.SettingsEditing.Mode = GridViewEditingMode.Inline

        Me.ProductSelectLink.NavigateUrl = "../pages/pg503ProductSelect.aspx?" & uPage.UserSession.QueryString
        Me.ProductMaintLink.NavigateUrl = "../pages/pg504ProductMaint.aspx?" & uPage.UserSession.QueryString & "&PageMode=Update&ProductCode=" & Me.ProductCode.Text
        Me.QualifyingProductsLink.NavigateUrl = "../pages/pg505QualifyingProductMaint.aspx?" & uPage.UserSession.QueryString & "&ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.TargetCompanyId.Value
        Me.AffiliateRatesLink.NavigateUrl = "../pages/pg506AffiliateRatesMaint.aspx?" & uPage.UserSession.QueryString & "&ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.TargetCompanyId.Value
        Me.ProductContentSetLink.NavigateUrl = "../pages/pg507ProductContentSetMaint.aspx?" & uPage.UserSession.QueryString & "&ProductCode=" & Me.ProductCode.Text & "&CompanyId=" & Me.TargetCompanyId.Value

    End Sub

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        'Assign Dataset to Viewstate to be re-used in save function
        Me.PageSetup()
        uPage.PagePreRender()
    End Sub

    Sub PolicyPremiumPartGrid_ParseValue(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxParseValueEventArgs) Handles ProductRatesGridView.ParseValue
        Select Case e.FieldName
            Case "ProductRate"
                e.Value = Convert.ToDecimal(e.Value)
        End Select
    End Sub

    Protected Sub ProductRatesGridView_ItemUpdating(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataUpdatingEventArgs) Handles ProductRatesGridView.RowUpdating
        e.NewValues("LastUpdatedDateTime") = DateTime.Now()
        e.NewValues("LastUpdatedByUserId") = uPage.UserSession.UserName
        If e.NewValues("NewUserRateFlag") Is Nothing Then
            e.NewValues("NewUserRateFlag") = False
        End If
        If e.NewValues("SellOnWebFlag") Is Nothing Then
            e.NewValues("SellOnWebFlag") = False
        End If
    End Sub

    Protected Sub ProductRatesGridView_ItemInserting(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInsertingEventArgs) Handles ProductRatesGridView.RowInserting
        e.NewValues("CreatedDateTime") = DateTime.Now()
        e.NewValues("CreatedByUserId") = uPage.UserSession.UserName
        If e.NewValues("NewUserRateFlag") Is Nothing Then
            e.NewValues("NewUserRateFlag") = False
        End If
        If e.NewValues("SellOnWebFlag") Is Nothing Then
            e.NewValues("SellOnWebFlag") = False
        End If
    End Sub

    Protected Sub ProductRatesGridView_RowValidating(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataValidationEventArgs)
        If e.NewValues("CurrencyCode") Is Nothing Then
            AddError(e.Errors, ProductRatesGridView.Columns("CurrencyCode"), "Please select a Currency Code.")
        End If

        If e.NewValues("RateType") Is Nothing Then
            AddError(e.Errors, ProductRatesGridView.Columns("RateType"), "Please select a Rate Type value.")
        End If

        If e.NewValues("AccountType") Is Nothing Then
            AddError(e.Errors, ProductRatesGridView.Columns("AccountType"), "Please select a Account Type value.")
        End If

        If e.NewValues("SubscriberCategory") Is Nothing Then
            AddError(e.Errors, ProductRatesGridView.Columns("SubscriberCategory"), "Please select a Subscriber Category value.")
        End If

        If e.NewValues("DeliveryArea") Is Nothing Then
            AddError(e.Errors, ProductRatesGridView.Columns("DeliveryArea"), "Please select a Delivery Area value.")
        End If

        If e.NewValues("ProductRate") Is Nothing Then
            AddError(e.Errors, ProductRatesGridView.Columns("ProductRate"), "Please enter a Product Rate value.")
        End If

        If String.IsNullOrEmpty(e.RowError) AndAlso e.Errors.Count > 0 Then
            e.RowError = "Please, correct all errors."
        End If

        uPage.PageError = e.RowError

        BuildDropdownsForPostback()
    End Sub

    Private Sub AddError(ByVal errors As Dictionary(Of GridViewColumn, String), ByVal column As GridViewColumn, ByVal errorText As String)
        If errors.ContainsKey(column) Then
            Return
        End If
        errors(column) = errorText
    End Sub

    Protected Sub grid_CustomButtonCallback(ByVal sender As Object, ByVal e As ASPxGridViewCustomButtonCallbackEventArgs)
        If e.ButtonID <> "Copy" Then
            Return
        End If
        copiedValues = New Hashtable()
        For Each fieldName As String In copiedFields
            copiedValues(fieldName) = ProductRatesGridView.GetRowValues(e.VisibleIndex, fieldName)
        Next fieldName
        ProductRatesGridView.AddNewRow()
    End Sub

    Protected Sub grid_InitNewRow(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInitNewRowEventArgs)
        If copiedValues Is Nothing Then
            Return
        End If
        For Each fieldName As String In copiedFields
            e.NewValues(fieldName) = copiedValues(fieldName)
        Next fieldName
        e.NewValues("CreatedDateTime") = DateTime.Now()
        e.NewValues("CreatedByUserId") = uPage.UserSession.UserName
        If e.NewValues("NewUserRateFlag") Is Nothing Then
            e.NewValues("NewUserRateFlag") = False
        End If
        If e.NewValues("SellOnWebFlag") Is Nothing Then
            e.NewValues("SellOnWebFlag") = False
        End If
    End Sub

    Protected Sub ProductRatesGridView_InitNewRow(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInitNewRowEventArgs) Handles ProductRatesGridView.InitNewRow
        BuildDropdownsForPostback()
    End Sub

    Protected Sub ProductRatesGridView_StartRowEditing(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxStartRowEditingEventArgs) Handles ProductRatesGridView.StartRowEditing
        BuildDropdownsForPostback()
    End Sub

    Protected Sub ProductRatesGridView_RowInserted(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInsertedEventArgs) Handles ProductRatesGridView.RowInserted
        BuildDropdownsForPostback()
    End Sub

    Protected Sub ProductRatesGridView_RowUpdated(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataUpdatedEventArgs) Handles ProductRatesGridView.RowUpdated
        BuildDropdownsForPostback()
    End Sub

    Sub BuildDropdownsForPostback()
        Try
            Dim combo As GridViewDataComboBoxColumn = TryCast(ProductRatesGridView.Columns("CurrencyCode"), GridViewDataComboBoxColumn)
            combo.PropertiesComboBox.ValueType = GetType(String)

            If combo.PropertiesComboBox.Items.Count = 0 Then
                For Each row As DataRow In Me.uPage.db.GetDataTableFromSQL(Me.CurrencyCodeDropdownSQL()).Rows
                    combo.PropertiesComboBox.Items.Add(row("CurrencyCode"), row("CurrencyCode"))
                Next
            End If

            combo = TryCast(ProductRatesGridView.Columns("RateType"), GridViewDataComboBoxColumn)
            combo.PropertiesComboBox.ValueType = GetType(String)

            If combo.PropertiesComboBox.Items.Count = 0 Then
                For Each row As DataRow In Me.uPage.db.GetDataTableFromSQL(Me.LookupDropdownSQL("RateType")).Rows
                    combo.PropertiesComboBox.Items.Add(row("Name"), row("LookupItemKey"))
                Next
            End If

            combo = TryCast(ProductRatesGridView.Columns("AccountType"), GridViewDataComboBoxColumn)
            combo.PropertiesComboBox.ValueType = GetType(String)

            If combo.PropertiesComboBox.Items.Count = 0 Then
                For Each row As DataRow In Me.uPage.db.GetDataTableFromSQL(Me.LookupDropdownSQL("AccountType")).Rows
                    combo.PropertiesComboBox.Items.Add(row("Name"), row("LookupItemKey"))
                Next
            End If

            combo = TryCast(ProductRatesGridView.Columns("SubscriberCategory"), GridViewDataComboBoxColumn)
            combo.PropertiesComboBox.ValueType = GetType(String)

            If combo.PropertiesComboBox.Items.Count = 0 Then
                For Each row As DataRow In Me.uPage.db.GetDataTableFromSQL(Me.LookupDropdownSQL("SubscriberCategory")).Rows
                    combo.PropertiesComboBox.Items.Add(row("Name"), row("LookupItemKey"))
                Next
            End If

            combo = TryCast(ProductRatesGridView.Columns("DeliveryArea"), GridViewDataComboBoxColumn)
            combo.PropertiesComboBox.ValueType = GetType(String)

            If combo.PropertiesComboBox.Items.Count = 0 Then
                For Each row As DataRow In Me.uPage.db.GetDataTableFromSQL(Me.LookupDropdownSQL("DeliveryArea")).Rows
                    combo.PropertiesComboBox.Items.Add(row("Name"), row("LookupItemKey"))
                Next
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub

    '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active
    Function LookupDropdownSQL(ByVal LookupName As String) As String
        Dim sql As String = "SELECT Lookup.LookupItemKey"
        sql += "   ,Lookup.Name"
        sql += "   FROM Lookup"
        sql += " WHERE LookupName = '" & LookupName & "'"
        sql += " AND CompanyId = " & Me.TargetCompanyId.Value
        sql += " AND LookupStatus = 'Active'"
        sql += " ORDER BY Lookup.DisplayOrder,Lookup.Name,Lookup.LookupItemKey"
        Return sql
    End Function

    Function CurrencyCodeDropdownSQL() As String
        Dim sql As String = "SELECT Currency.CurrencyCode FROM Currency ORDER BY Currency.CurrencyCode"
       
        Return sql
    End Function
End Class
