<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--
function HrefConfirm(strMessage,strConfirmedHref)
{

	if (confirm(strMessage) )
	{
		//window.navigate(strConfirmedHref);
        window.location.href = (strConfirmedHref);
		true
	}
	else
	{
	false
	}
}
function ConfirmSubmitCommandData(strMessage,strCommandData)
{

var ofrm = 	document.forms['Form1']
	if (confirm(strMessage) )
	{
	ofrm['txtCommandData'].value = strCommandData
	ofrm.submit()		
	true
	}
	else
	{
	false
	}
}	

function SubmitCommandData(strCommandData)
{
var ofrm = 	document.forms['Form1']
	{
	ofrm['txtCommandData'].value = strCommandData
	ofrm.submit()		
	}
}	
//-->
</SCRIPT>