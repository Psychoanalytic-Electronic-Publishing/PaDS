﻿
function CVNumberHelpPopupWindow(url) {
    newwindow = window.open(url, 'name', 'height=450,width=375,left=500,top=500,scrollbars=0');
}

function CloseWindow() {
    self.close();
}	