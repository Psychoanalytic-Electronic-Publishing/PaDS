<SCRIPT ID=clientEventHandlersJS LANGUAGE=javascript>
<!--

	var win= null;
	function OpenSearch(KeyFieldId, DataFieldId, DataFieldHiddenId,FKId, PageTitle){
		var w = '450';
		var h = '535';
		var winl = (screen.width-w)/2;
		var wint = (screen.height-h)/2;
		var settings  ='height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars=no,menubar=no,toolbar=no,resizable=no';
		
		win=window.open('pg070SingleItemListSelector.aspx'
						+ '?KeyFieldId=' + KeyFieldId
						+ '&DataFieldId=' + DataFieldId 
						+ '&DataFieldHiddenId=' + DataFieldHiddenId 
						+ '&FKId=' + FKId 
						+ '&PageTitle=' + PageTitle
						+ '&ReturnFormName=' + document.forms[0].name
						,'popUp',settings);
		
		if(parseInt(navigator.appVersion) >= 4){win.window.focus();}
	}

function SetReturnValue(KeyFieldId,KeyFieldValue, DataFieldId , DataFieldValue ,DataFieldHiddenId , ReturnFormName)
{
	eval('var theform = document.' + ReturnFormName + ';');
	win.close();
	theform.elements[KeyFieldId].value = KeyFieldValue;	
	theform.parentNode.parentElement.document.all(DataFieldId).innerHTML = DataFieldValue;		
	theform.elements[DataFieldHiddenId].value = DataFieldValue;	
	
}	
	function CloseWindow()
	{
		self.close();
	}	
//-->
</SCRIPT>