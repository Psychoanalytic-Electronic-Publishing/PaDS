Imports System.Data
Imports System.Data.SqlClient

Public Class DatabaseUtilities
    Private stdCode As New ZedraCode.StdCode
#Region "Class Properties"

    Dim _DBConnection As SqlClient.SqlConnection
    Public Property DBConnection() As SqlClient.SqlConnection
        Get
            Return _DBConnection
        End Get
        Set(ByVal Value As SqlClient.SqlConnection)
            _DBConnection = Value
        End Set
    End Property
    Private _DBTransaction As SqlTransaction
    Public Property DBTransaction() As SqlTransaction
        Get
            Return _DBTransaction
        End Get
        Set(ByVal Value As SqlTransaction)
            _DBTransaction = Value
        End Set
    End Property
    Dim _CommandTimeout As Integer
    Public Property CommandTimeout() As Integer
        Get
            Return Me._CommandTimeout
        End Get
        Set(ByVal Value As Integer)
            Me._CommandTimeout = Value
        End Set
    End Property
    Dim _SQL As String
    Public Property SQL() As String
        Get
            Return Me._SQL
        End Get
        Set(ByVal Value As String)
            Me._SQL = Value
        End Set
    End Property

#End Region
    Public Sub New()
    End Sub

    Public Sub New(ByVal DBConnection As SqlClient.SqlConnection)
        Me.DBConnection = DBConnection
    End Sub

    Public Sub New(ByRef DBConnection As SqlClient.SqlConnection, ByRef DBTransaction As SqlClient.SqlTransaction)
        Me.New(DBConnection)
        Me.DBTransaction = DBTransaction
    End Sub
    Public Function GetDataTableFromSQL() As DataTable
        Return GetDataTableFromSQL(Me.SQL, Me.DBConnection, Me.DBTransaction)
    End Function
    Public Function GetDataTableFromSQL(ByVal SQL As String) As DataTable
        Return GetDataTableFromSQL(SQL, Me.DBConnection, Me.DBTransaction)
    End Function
    Public Function GetDataTableFromSQL(ByVal SQL As String, ByRef DBConnection As SqlClient.SqlConnection, ByRef DBTransaction As SqlClient.SqlTransaction)
        Me.DBConnection = DBConnection
        Me.DBTransaction = DBTransaction
        If Me.DBConnection Is Nothing Then
            Throw New Exception("Connection not initialised in DatabaseUtilities")
        End If
        If Me.DBConnection.State <> ConnectionState.Open Then
            Throw New Exception("Connection not open in DatabaseUtilities")
        End If
        Me.SQL = SQL
        If Me.SQL = Nothing Then
            Throw New Exception("SQL not found for GetDataTableFromSQL")
        End If
        Try

            Dim cmd As New SqlCommand(SQL, Me.DBConnection, Me.DBTransaction)
            If Me.CommandTimeout <> Nothing Then
                cmd.CommandTimeout = Me.CommandTimeout
            End If
            Me.CommandTimeout = cmd.CommandTimeout
            Dim da As New SqlDataAdapter(cmd)
            Dim tbl As New DataTable
            da.Fill(tbl)
            Return tbl
        Catch ex As Exception
            Throw New Exception("Failed to build table." & ControlChars.NewLine & ex.ToString & ControlChars.NewLine & SQL)
        End Try
    End Function

End Class
