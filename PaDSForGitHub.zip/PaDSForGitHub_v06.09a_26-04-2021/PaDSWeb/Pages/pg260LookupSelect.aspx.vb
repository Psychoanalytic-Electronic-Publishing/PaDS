﻿Imports System.Data.SqlClient
Imports System.Data
Partial Class Pages_pg260LookupSelect
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    'Modification History
    '03/12/2010 Julian Gates  Initial version

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Lookup List", "")
        Me.pageHeaderTitle.Text = "Lookup List"

        If Not Page.IsPostBack Then
            If Request.QueryString("InfoMsg") <> "" Then
                Me.InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            txtRecordsToShow.Text = 20
            Me.txtPageNumber.Text = 1
            Dim dropDownIntialValue As String = "<--All-->"
            Dim sql As String = "SELECT CompanyId as Value" _
                                    & "     ,CompanyName as Text" _
                                    & "	FROM " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                                    & " ORDER By CompanyName"
            uPage.PopulateDropDownListFromSQL(Me.FltrCompanyId, sql, uPage.PrimaryConnection, dropDownIntialValue)

            uPage.PopulateDropDownListFromSQL(Me.FltrLookupName,
                                            "SELECT DISTINCT(LookupName) as Value" _
                                            & "     ,LookupName as Text" _
                                            & "	FROM Lookup" _
                                            , uPage.PrimaryConnection, dropDownIntialValue)

            uPage.PopulateDropDownListFromLookup(Me.FltrLookupStatus, "LookupStatus", uPage.PrimaryConnection, dropDownIntialValue)
            Me.FltrLookupStatus.SelectedValue = "Active"

            BuildGrid()
        Else
            If Me.txtPrevRecordsToShow.Value <> Me.txtRecordsToShow.Text Then
                Me.txtPageNumber.Text = 1
                Me.txtPrevRecordsToShow.Value = Me.txtRecordsToShow.Text
            End If
            If Me.txtGotoPageNum.Value <> "" Then
                Me.txtPageNumber.Text = Me.txtGotoPageNum.Value
                Me.txtGotoPageNum.Value = ""
            End If
        End If
        BuildGrid()
    End Sub

    Private Sub BuildGrid()
        If Me.IsPageValidForStatus() Then
            Dim listSQL As String = Nothing
            Dim html As String = Nothing
            Dim PrevProductCombinationId As String = Nothing
            Try
                listSQL = "SELECT Lookup.*" _
                        & "     ,CompanyName" _
                        & " FROM Lookup" _
                        & "     LEFT JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                        & "      ON Company.CompanyId = Lookup.CompanyId " _
                        & " WHERE 1=1"

                Dim ds As New DataSet
                Dim da As New SqlDataAdapter(listSQL, uPage.PrimaryConnection)
                'Populate Dataset
                da.Fill(ds, "Lookup")

                If Me.FltrCompanyId.SelectedValue <> "" Then
                    listSQL += " AND Lookup.CompanyId = '" & Me.FltrCompanyId.SelectedValue & "'"
                Else
                    listSQL += " AND Lookup.CompanyId = 0"
                End If

                If Me.FltrLookupName.SelectedValue <> "" Then
                    listSQL += " And Lookup.LookupName = '" & Me.FltrLookupName.SelectedValue & "'"
                End If

                If Me.FltrLookupStatus.SelectedValue <> "" Then
                    listSQL += " AND Lookup.LookupStatus = '" & Me.FltrLookupStatus.SelectedValue & "'"
                End If

                listSQL += "ORDER BY LookupName "

                Dim listTable As DataTable = uPage.GetListDatatable(Me.txtPageNumber.Text, Me.txtRecordsToShow.Text, Me.lblPaging.Text, listSQL, uPage.PrimaryConnection)

                If listTable.Rows.Count <> 0 Then
                    For Each row As DataRow In listTable.Rows
                        html = html & "<tr>"
                        If Me.FltrCompanyId.SelectedValue <> "" Then
                            html = html & "<td><p class=fldView>" & row.Item("CompanyName") & "</p></td>"
                        Else
                            html = html & "<td>&nbsp</td>"
                        End If
                        html = html & "<td><p class=fldView>" & row.Item("LookupName") & "</p></td>"
                        html = html & "<td>" _
                            & "<a href='../pages/pg261LookupMaint.asp?PageMode=Update&LookupName=" & row.Item("LookupName") & "&LookupItemKey=" & row.Item("LookupItemKey") & "&CompanyId=" & row.Item("CompanyId") _
                                                        & "&" & uPage.UserSession.QueryString _
                            & "' Title='Update Lookup'>" & row.Item("LookupItemKey") & "</a>" _
                            & "</td>"
                        html = html & "<td><p class=fldView>" & row.Item("Name") & "</p></td>"
                        html = html & "<td><p class=fldView>" & row.Item("MaintenanceGroup") & "</p></td>"
                        html = html & "<td><p class=fldView>" & row.Item("DisplayOrder") & "</p></td>"
                        html = html & "<td><p class=fldView>" & row.Item("LookupStatus") & "</p></td>"
                        html = html & "</tr>"
                        Me.txtMaintenanceGroup.Value = row.Item("MaintenanceGroup")
                    Next
                Else
                    uPage.PageError = "No records match your selection criteria"
                End If
            Catch e As Exception
                uPage.PageError = e.ToString
            End Try
            'Assign grid to Label
            lblGridView.Text = html
        End If
    End Sub

    Private Sub btnFilter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFilter.Click
        Me.txtPageNumber.Text = 1
        BuildGrid()
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Response.Redirect(Request.ServerVariables("Path_Info") & "?" & uPage.UserSession.QueryString)
    End Sub
    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        uPage.PagePreRender()
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        Select Case validatorStatus
            Case Else
                If txtRecordsToShow.Text = "" Then
                    uPage.FieldErrorControl(Me.txtRecordsToShow, "Max Records To Show is mandatory")
                End If
                If txtRecordsToShow.Text <> "" Then
                    If Not IsNumeric(Me.txtRecordsToShow.Text) Then
                        uPage.FieldErrorControl(Me.txtRecordsToShow, "Max Records To Show must be a numerical value")
                    End If
                End If
        End Select
        Return uPage.IsValid
    End Function
    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub AddNewBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddNewBtn.Click
        If Me.FltrLookupName.SelectedValue <> "" Then
            Response.Redirect("../pages/pg261LookupMaint.asp?PageMode=Add&" _
                            & "LookupName=" & Me.FltrLookupName.SelectedValue _
                            & "&" & uPage.UserSession.QueryString _
                            & "&MaintenanceGroup=" & Me.txtMaintenanceGroup.Value)
        Else
            uPage.FieldErrorControl(Me.FltrLookupName, "You must first filter on the lookup before using the Add button")
        End If
    End Sub

End Class
