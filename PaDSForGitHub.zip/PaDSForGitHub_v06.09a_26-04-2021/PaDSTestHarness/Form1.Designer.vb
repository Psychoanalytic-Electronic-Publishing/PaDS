﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.DeleteAddTestData = New System.Windows.Forms.Button()
        Me.PrimaryConnection = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ErrorMessage = New System.Windows.Forms.TextBox()
        Me.RunNextbatchJob = New System.Windows.Forms.Button()
        Me.EncryptPasswordBtn = New System.Windows.Forms.Button()
        Me.RunReport = New System.Windows.Forms.Button()
        Me.CopyDBToSecondary = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SecondaryConnection = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SecurityConnection = New System.Windows.Forms.TextBox()
        Me.Complie1stSQL = New System.Windows.Forms.Button()
        Me.ProgressLog = New System.Windows.Forms.TextBox()
        Me.Complie2ndSQL = New System.Windows.Forms.Button()
        Me.SendEmailToSupport = New System.Windows.Forms.Button()
        Me.RunIsOnLiveServer = New System.Windows.Forms.Button()
        Me.RunLogonTests = New System.Windows.Forms.Button()
        Me.DoJSON = New System.Windows.Forms.Button()
        Me.SubmitBatchJob = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.BuildTriggers = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TestDataDirectory = New System.Windows.Forms.TextBox()
        Me.DeleteAddBaseContentData = New System.Windows.Forms.Button()
        Me.DeleteTestData = New System.Windows.Forms.Button()
        Me.ReportAPI = New System.Windows.Forms.Button()
        Me.TableToJSONandBack = New System.Windows.Forms.Button()
        Me.BatchJobName = New System.Windows.Forms.TextBox()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DeleteAddTestData
        '
        Me.DeleteAddTestData.Location = New System.Drawing.Point(14, 26)
        Me.DeleteAddTestData.Name = "DeleteAddTestData"
        Me.DeleteAddTestData.Size = New System.Drawing.Size(167, 23)
        Me.DeleteAddTestData.TabIndex = 0
        Me.DeleteAddTestData.Text = "Delete/Add Test Data"
        Me.DeleteAddTestData.UseVisualStyleBackColor = True
        '
        'PrimaryConnection
        '
        Me.PrimaryConnection.Location = New System.Drawing.Point(133, 12)
        Me.PrimaryConnection.Name = "PrimaryConnection"
        Me.PrimaryConnection.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
        Me.PrimaryConnection.Size = New System.Drawing.Size(569, 20)
        Me.PrimaryConnection.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(29, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(98, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Primary Connection"
        '
        'ErrorMessage
        '
        Me.ErrorMessage.ForeColor = System.Drawing.Color.Red
        Me.ErrorMessage.Location = New System.Drawing.Point(512, 227)
        Me.ErrorMessage.Multiline = True
        Me.ErrorMessage.Name = "ErrorMessage"
        Me.ErrorMessage.Size = New System.Drawing.Size(524, 352)
        Me.ErrorMessage.TabIndex = 3
        '
        'RunNextbatchJob
        '
        Me.RunNextbatchJob.Location = New System.Drawing.Point(708, 67)
        Me.RunNextbatchJob.Name = "RunNextbatchJob"
        Me.RunNextbatchJob.Size = New System.Drawing.Size(141, 23)
        Me.RunNextbatchJob.TabIndex = 4
        Me.RunNextbatchJob.Text = "Next Batch Job"
        Me.RunNextbatchJob.UseVisualStyleBackColor = True
        '
        'EncryptPasswordBtn
        '
        Me.EncryptPasswordBtn.Location = New System.Drawing.Point(895, 133)
        Me.EncryptPasswordBtn.Name = "EncryptPasswordBtn"
        Me.EncryptPasswordBtn.Size = New System.Drawing.Size(141, 23)
        Me.EncryptPasswordBtn.TabIndex = 5
        Me.EncryptPasswordBtn.Text = "Encypt Passwords"
        Me.EncryptPasswordBtn.UseVisualStyleBackColor = True
        '
        'RunReport
        '
        Me.RunReport.Location = New System.Drawing.Point(12, 130)
        Me.RunReport.Name = "RunReport"
        Me.RunReport.Size = New System.Drawing.Size(75, 23)
        Me.RunReport.TabIndex = 6
        Me.RunReport.Text = "RunReport"
        Me.RunReport.UseVisualStyleBackColor = True
        '
        'CopyDBToSecondary
        '
        Me.CopyDBToSecondary.Location = New System.Drawing.Point(11, 174)
        Me.CopyDBToSecondary.Name = "CopyDBToSecondary"
        Me.CopyDBToSecondary.Size = New System.Drawing.Size(133, 23)
        Me.CopyDBToSecondary.TabIndex = 7
        Me.CopyDBToSecondary.Text = "CopyDBToSecondary"
        Me.CopyDBToSecondary.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(29, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(115, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Secondary Connection"
        '
        'SecondaryConnection
        '
        Me.SecondaryConnection.Location = New System.Drawing.Point(133, 38)
        Me.SecondaryConnection.Name = "SecondaryConnection"
        Me.SecondaryConnection.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
        Me.SecondaryConnection.Size = New System.Drawing.Size(569, 20)
        Me.SecondaryConnection.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(29, 67)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(102, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "Security Connection"
        '
        'SecurityConnection
        '
        Me.SecurityConnection.Location = New System.Drawing.Point(133, 64)
        Me.SecurityConnection.Name = "SecurityConnection"
        Me.SecurityConnection.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal
        Me.SecurityConnection.Size = New System.Drawing.Size(569, 20)
        Me.SecurityConnection.TabIndex = 10
        '
        'Complie1stSQL
        '
        Me.Complie1stSQL.Location = New System.Drawing.Point(708, 9)
        Me.Complie1stSQL.Name = "Complie1stSQL"
        Me.Complie1stSQL.Size = New System.Drawing.Size(101, 23)
        Me.Complie1stSQL.TabIndex = 12
        Me.Complie1stSQL.Text = "Compile 1st SQL"
        Me.Complie1stSQL.UseVisualStyleBackColor = True
        '
        'ProgressLog
        '
        Me.ProgressLog.ForeColor = System.Drawing.Color.Green
        Me.ProgressLog.Location = New System.Drawing.Point(12, 227)
        Me.ProgressLog.Multiline = True
        Me.ProgressLog.Name = "ProgressLog"
        Me.ProgressLog.Size = New System.Drawing.Size(467, 352)
        Me.ProgressLog.TabIndex = 13
        '
        'Complie2ndSQL
        '
        Me.Complie2ndSQL.Location = New System.Drawing.Point(708, 38)
        Me.Complie2ndSQL.Name = "Complie2ndSQL"
        Me.Complie2ndSQL.Size = New System.Drawing.Size(101, 23)
        Me.Complie2ndSQL.TabIndex = 14
        Me.Complie2ndSQL.Text = "Complie 2nd SQL"
        Me.Complie2ndSQL.UseVisualStyleBackColor = True
        '
        'SendEmailToSupport
        '
        Me.SendEmailToSupport.Location = New System.Drawing.Point(579, 198)
        Me.SendEmailToSupport.Name = "SendEmailToSupport"
        Me.SendEmailToSupport.Size = New System.Drawing.Size(133, 23)
        Me.SendEmailToSupport.TabIndex = 15
        Me.SendEmailToSupport.Text = "SendEmailToSupport"
        Me.SendEmailToSupport.UseVisualStyleBackColor = True
        '
        'RunIsOnLiveServer
        '
        Me.RunIsOnLiveServer.Location = New System.Drawing.Point(12, 101)
        Me.RunIsOnLiveServer.Name = "RunIsOnLiveServer"
        Me.RunIsOnLiveServer.Size = New System.Drawing.Size(155, 23)
        Me.RunIsOnLiveServer.TabIndex = 16
        Me.RunIsOnLiveServer.Text = "RunIsOnLiveServer"
        Me.RunIsOnLiveServer.UseVisualStyleBackColor = True
        '
        'RunLogonTests
        '
        Me.RunLogonTests.Location = New System.Drawing.Point(895, 162)
        Me.RunLogonTests.Name = "RunLogonTests"
        Me.RunLogonTests.Size = New System.Drawing.Size(141, 23)
        Me.RunLogonTests.TabIndex = 17
        Me.RunLogonTests.Text = "RunLogonTests"
        Me.RunLogonTests.UseVisualStyleBackColor = True
        '
        'DoJSON
        '
        Me.DoJSON.Location = New System.Drawing.Point(454, 198)
        Me.DoJSON.Name = "DoJSON"
        Me.DoJSON.Size = New System.Drawing.Size(108, 23)
        Me.DoJSON.TabIndex = 18
        Me.DoJSON.Text = "DoJSON"
        Me.DoJSON.UseVisualStyleBackColor = True
        '
        'SubmitBatchJob
        '
        Me.SubmitBatchJob.Location = New System.Drawing.Point(542, 69)
        Me.SubmitBatchJob.Name = "SubmitBatchJob"
        Me.SubmitBatchJob.Size = New System.Drawing.Size(133, 23)
        Me.SubmitBatchJob.TabIndex = 19
        Me.SubmitBatchJob.Text = "SubmitBatchJob"
        Me.SubmitBatchJob.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Coral
        Me.Panel1.Controls.Add(Me.BatchJobName)
        Me.Panel1.Controls.Add(Me.BuildTriggers)
        Me.Panel1.Controls.Add(Me.SubmitBatchJob)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.TestDataDirectory)
        Me.Panel1.Controls.Add(Me.DeleteAddBaseContentData)
        Me.Panel1.Controls.Add(Me.DeleteTestData)
        Me.Panel1.Controls.Add(Me.DeleteAddTestData)
        Me.Panel1.Location = New System.Drawing.Point(195, 92)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(694, 100)
        Me.Panel1.TabIndex = 20
        '
        'BuildTriggers
        '
        Me.BuildTriggers.Location = New System.Drawing.Point(323, 37)
        Me.BuildTriggers.Name = "BuildTriggers"
        Me.BuildTriggers.Size = New System.Drawing.Size(101, 23)
        Me.BuildTriggers.TabIndex = 67
        Me.BuildTriggers.Text = "BuildTriggers"
        Me.BuildTriggers.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(190, 11)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(127, 20)
        Me.Label4.TabIndex = 66
        Me.Label4.Text = "Test Data Directory"
        '
        'TestDataDirectory
        '
        Me.TestDataDirectory.Location = New System.Drawing.Point(323, 11)
        Me.TestDataDirectory.Name = "TestDataDirectory"
        Me.TestDataDirectory.Size = New System.Drawing.Size(342, 20)
        Me.TestDataDirectory.TabIndex = 65
        Me.TestDataDirectory.Text = "D:\Projects\PaDS2\PaDS\TestData\"
        '
        'DeleteAddBaseContentData
        '
        Me.DeleteAddBaseContentData.Location = New System.Drawing.Point(14, 72)
        Me.DeleteAddBaseContentData.Name = "DeleteAddBaseContentData"
        Me.DeleteAddBaseContentData.Size = New System.Drawing.Size(167, 23)
        Me.DeleteAddBaseContentData.TabIndex = 2
        Me.DeleteAddBaseContentData.Text = "Delete/Add BASE Content  Data"
        Me.DeleteAddBaseContentData.UseVisualStyleBackColor = True
        '
        'DeleteTestData
        '
        Me.DeleteTestData.Location = New System.Drawing.Point(14, 3)
        Me.DeleteTestData.Name = "DeleteTestData"
        Me.DeleteTestData.Size = New System.Drawing.Size(167, 23)
        Me.DeleteTestData.TabIndex = 1
        Me.DeleteTestData.Text = "Delete Test Data"
        Me.DeleteTestData.UseVisualStyleBackColor = True
        '
        'ReportAPI
        '
        Me.ReportAPI.Location = New System.Drawing.Point(305, 193)
        Me.ReportAPI.Name = "ReportAPI"
        Me.ReportAPI.Size = New System.Drawing.Size(133, 23)
        Me.ReportAPI.TabIndex = 21
        Me.ReportAPI.Text = "ReportAPI"
        Me.ReportAPI.UseVisualStyleBackColor = True
        '
        'TableToJSONandBack
        '
        Me.TableToJSONandBack.Location = New System.Drawing.Point(166, 198)
        Me.TableToJSONandBack.Name = "TableToJSONandBack"
        Me.TableToJSONandBack.Size = New System.Drawing.Size(133, 23)
        Me.TableToJSONandBack.TabIndex = 22
        Me.TableToJSONandBack.Text = "TableToJSONandBack"
        Me.TableToJSONandBack.UseVisualStyleBackColor = True
        '
        'BatchJobName
        '
        Me.BatchJobName.AllowDrop = True
        Me.BatchJobName.Location = New System.Drawing.Point(367, 71)
        Me.BatchJobName.Name = "BatchJobName"
        Me.BatchJobName.Size = New System.Drawing.Size(169, 20)
        Me.BatchJobName.TabIndex = 68
        Me.BatchJobName.Text = "BatchJobToSubmit"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1048, 591)
        Me.Controls.Add(Me.TableToJSONandBack)
        Me.Controls.Add(Me.ReportAPI)
        Me.Controls.Add(Me.DoJSON)
        Me.Controls.Add(Me.RunLogonTests)
        Me.Controls.Add(Me.RunIsOnLiveServer)
        Me.Controls.Add(Me.SendEmailToSupport)
        Me.Controls.Add(Me.Complie2ndSQL)
        Me.Controls.Add(Me.ProgressLog)
        Me.Controls.Add(Me.Complie1stSQL)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.SecurityConnection)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.SecondaryConnection)
        Me.Controls.Add(Me.CopyDBToSecondary)
        Me.Controls.Add(Me.RunReport)
        Me.Controls.Add(Me.EncryptPasswordBtn)
        Me.Controls.Add(Me.RunNextbatchJob)
        Me.Controls.Add(Me.ErrorMessage)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PrimaryConnection)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DeleteAddTestData As System.Windows.Forms.Button
    Friend WithEvents PrimaryConnection As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ErrorMessage As System.Windows.Forms.TextBox
    Friend WithEvents RunNextbatchJob As System.Windows.Forms.Button
    Friend WithEvents EncryptPasswordBtn As Button
    Friend WithEvents RunReport As Button
    Friend WithEvents CopyDBToSecondary As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents SecondaryConnection As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents SecurityConnection As TextBox
    Friend WithEvents Complie1stSQL As Button
    Friend WithEvents ProgressLog As TextBox
    Friend WithEvents Complie2ndSQL As Button
    Friend WithEvents SendEmailToSupport As Button
    Friend WithEvents RunIsOnLiveServer As Button
    Friend WithEvents RunLogonTests As Button
    Friend WithEvents DoJSON As Button
    Friend WithEvents SubmitBatchJob As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents DeleteTestData As Button
    Friend WithEvents DeleteAddBaseContentData As Button
    Friend WithEvents BuildTriggers As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents TestDataDirectory As TextBox
    Friend WithEvents ReportAPI As Button
    Friend WithEvents TableToJSONandBack As Button
    Friend WithEvents BatchJobName As TextBox
End Class
