if  exists (select * from sysobjects where id = object_id(N'SessionLog') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP view SessionLog --AS Select * from Company
go
CREATE VIEW SessionLog
As
SELECT     *
FROM PaDS_Logs.dbo.SessionLog 
Go
if  exists (select * from sysobjects where id = object_id(N'AuditLog') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP view AuditLog --AS Select * from Company
go
CREATE VIEW AuditLog
As
SELECT     *
FROM PaDS_Logs.dbo.AuditLog 
Go
if  exists (select * from sysobjects where id = object_id(N'PEPWebUsageLog') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP view PEPWebUsageLog --AS Select * from Company
go
CREATE VIEW PEPWebUsageLog
As
SELECT     *
FROM PaDS_Logs.dbo.PEPWebUsageLog 
Go
if  exists (select * from sysobjects where id = object_id(N'PEPWebSessionLog') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP view PEPWebSessionLog --AS Select * from Company
go
CREATE VIEW PEPWebSessionLog
As
SELECT     *
FROM PaDS_Logs.dbo.PEPWebSessionLog 
Go
if  exists (select * from sysobjects where id = object_id(N'UserActionLog') and OBJECTPROPERTY(id, N'IsView') = 1)
	DROP view UserActionLog --AS Select * from Company
go
CREATE VIEW UserActionLog
As
SELECT     *
FROM PaDS_Logs.dbo.UserActionLog 
Go
