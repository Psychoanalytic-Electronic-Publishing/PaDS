

DECLARE @NewDBVersion varchar(10)
DECLARE @OldDBVersion varchar(10)
DECLARE @CurrentDBVersion varchar(10)
DECLARE @SQL as varchar(8000)
DECLARE @ProcName Varchar(50)
DECLARE @ServerName varchar(100)
DECLARE @DBName varchar(100)= DB_Name()
DECLARE @Message VARCHAR(2000)
DECLARE @RowCount INT
DECLARE @v sql_variant 
DECLARE @IsAtClient BIT = 0
DECLARE @LookupId INT

IF PATINDEX('%zedra%',@@ServerName) = 0
	SET @IsAtClient = 1

SELECT @ServerName = CASE WHEN @IsAtClient = 1 THEN 'PaDS01' ELSE  @@ServerName END

DECLARE @RunningAtClient BIT = ( SELECT CASE WHEN PATINDEX('%zedra%',@ServerName)=0 THEN 1 ELSE 0 END )

SET @OldDBVersion = '2.8'
SET @NewDBVersion = '2.9'
 
IF NOT EXISTS(SELECT * FROM stblParameters WHERE ParameterName = 'DatabaseVersion') INSERT INTO stblParameters(ParameterName,ParameterType,UserID,ParameterValue) SELECT 'DatabaseVersion','System','All','01.00'  
SELECT @CurrentDBVersion = ParameterValue FROM dbo.stblParameters WHERE ParameterName = 'DatabaseVersion'
SELECT 'Current Version: ' + @CurrentDBVersion

IF NOT (@CurrentDBVersion = @OldDBVersion OR  @CurrentDBVersion = @NewDBVersion)
OR @CurrentDBVersion IS NULL
BEGIN
	SELECT 'Current DB Version ' + ISNULL(@CurrentDBVersion,'EMPTY') + ' does not match'
END
ELSE
BEGIN
BEGIN TRANSACTION 
BEGIN TRY
print 'xx'

IF NOT EXISTS(SELECT * FROM sysobjects o inner join syscolumns c on c.id = o.id where o.name = 'ContentDocuments' and c.name ='documentInfoXML')
begin
	ALTER TABLE ContentDocuments Add
		documentInfoXML VARCHAR(MAX) NULL

end

--SIR5213 - Add ShowCounterReports to RemoteUser
--SIR5217 - Add LastLoggedInMethod and LastAutoLoginGroupUserId
	IF NOT exists (select * from syscolumns WHERE 
					Id = (Select Id from sysobjects where id = object_id(N'RemoteUser') and xtype in (N'U'))
					AND Name = 'ShowCounterReports')
	BEGIN
		ALTER TABLE RemoteUser ADD
			ShowCounterReports BIT
			,LastLoggedInMethod VARCHAR(50) NULL
			,LastAutoLoginGroupUserId INT NULL
	END
--SIR5224
	IF NOT exists (select * from syscolumns WHERE 
					Id = (Select Id from sysobjects where id = object_id(N'RemoteUser') and xtype in (N'U'))
					AND Name = 'LastAutoLoginRefreshDateTime')
	BEGIN
		ALTER TABLE RemoteUser ADD
			LastAutoLoginRefreshDateTime DATETIME
	END	
--SIR5226
	IF NOT exists (select * from syscolumns WHERE 
					Id = (Select Id from sysobjects where id = object_id(N'RemoteUser') and xtype in (N'U'))
					AND Name = 'ExcludeUsageStatsFromReports')
	BEGIN
		ALTER TABLE RemoteUser ADD
			ExcludeUsageStatsFromReports BIT
	END	


	----**************************
	--Set New DB Version
	
	Update stblParameters
	SET ParameterValue =CAST( @NewDBVersion AS VARCHAR)
	WHERE ParameterName = 'DatabaseVersion'
	
--*************   END TRANSACTION *********************
COMMIT TRAN
SELECT 'Transaction Commited'
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SELECT 'Transaction Rolled Back'
	SELECT @Message = 'DBUpgrade Failed - Line:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE()
	
	RAISERROR ('%s', 18, 1,@Message)

END CATCH

END
