﻿Imports System.Net
Imports System.Net.Http
Imports System.Web.Http
Imports BusinessLogic

Namespace Controllers
    'May 2020   James Woosnam   SIR5039 - Initial Version
    Public Class PermitsController
        Inherits ApiController
        Public Class PermitRequest
            Public SessionId As String
            Public DocId As String
            Public DocYear As String
            Public ReasonForCheck As String
        End Class
        Public Class PermitResponse
            Public SessionId As String
            Public DocId As String
            Public Permit As Boolean = False
            Public HasCurrentAccess As Boolean = False
            Public HasArchiveAccess As Boolean = False
            Public ReasonId As HttpStatusCode = HttpStatusCode.OK
            Public ReasonStr As String
        End Class

        <HttpGet>
        Public Function DefaultAction(ByVal SessionId As String, DocId As String, DocYear As String, ReasonForCheck As String) As HttpResponseMessage
            Dim req As New PermitRequest
            req.SessionId = SessionId
            req.DocId = DocId
            req.DocYear = DocYear
            req.ReasonForCheck = ReasonForCheck
            Return DefaultAction(req)
        End Function

        <HttpPost>
        Public Function DefaultAction(ByVal req As PermitRequest) As HttpResponseMessage
            Dim resp As New PermitResponse
            Try
                If req.SessionId = "" Then resp.ReasonStr += IIf(resp.ReasonStr = "", "", Environment.NewLine) + "SessionId must be populated"
                If req.DocId = "" Then resp.ReasonStr += IIf(resp.ReasonStr = "", "", Environment.NewLine) + "DocId must be populated"
                If Not IsNumeric(req.DocYear) Then resp.ReasonStr += IIf(resp.ReasonStr = "", "", Environment.NewLine) + "DocYear must be a number"
                If resp.ReasonStr <> "" Then
                    resp.ReasonId = HttpStatusCode.BadRequest
                    Exit Try
                End If

                Dim authReq As New PEPSecurity.AuthoriseRequest
                authReq.SessionId = req.SessionId
                authReq.DocumentId = req.DocId
                authReq.Year = req.DocYear
                authReq.ReasonForCheck = req.ReasonForCheck
                authReq.ReasonForCheck = req.ReasonForCheck
                Dim PaDSDB As BusinessLogic.Database = New PaDSDB().db

                Try
                    Dim IPAddress As String = New StdCode().GetIPAddress(HttpContext.Current.Request)
                    Dim pepS As New PEPSecurity(PaDSDB, IPAddress)
                    If HttpContext.Current.Request.Headers.AllKeys.Contains("X-Forwarded-For") AndAlso HttpContext.Current.Request.Headers("X-Forwarded-For") IsNot Nothing Then pepS.SessionLogExtraComment += "X-Forwarded-For:" & HttpContext.Current.Request.Headers("X-Forwarded-For")
                    With pepS.AuthoriseDocument(authReq)
                        resp.SessionId = .SessionId
                        resp.DocId = .DocumentId
                        resp.Permit = .Permit
                        resp.HasArchiveAccess = .HasArchiveAccess
                        resp.HasCurrentAccess = .HasCurrentAccess
                        resp.ReasonStr = .ReasonDescription
                        If resp.ReasonStr <> "" And Not resp.Permit Then '16/12/20 not resp.Permit added as for .0000A docs the reson string may be populated
                            resp.ReasonId = HttpStatusCode.Unauthorized
                        End If
                    End With

                Catch ex As Exception
                    Throw ex
                Finally
                    Try
                        PaDSDB.DBConnection.Close()
                        PaDSDB.DBConnection.Dispose()
                    Catch ex As Exception
                    End Try
                End Try
            Catch ex As Exception
                '****LOG ERROR****
                resp.ReasonStr = "Unexpected error encountered."
                resp.ReasonId = HttpStatusCode.InternalServerError
                Try
                    If New PaDSDB().db.ShowFullError Then
                        resp.ReasonStr += " ShowFullError:" & ex.Message
                    Else
                        resp.ReasonStr += " Set ShowFullError for more."
                    End If
                Catch ex1 As Exception
                End Try
                Return Request.CreateResponse(Of String)(resp.ReasonId, resp.ReasonStr)
            End Try
            Return Request.CreateResponse(Of PermitResponse)(resp.ReasonId, resp)
        End Function

    End Class

End Namespace