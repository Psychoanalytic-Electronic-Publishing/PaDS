﻿Imports System.Net
Imports System.Net.Http
Imports System.Web.Http
Imports BusinessLogic

Namespace Controllers
    'May 2020   James Woosnam   SIR5039 - Initial Version
    '24/11/20   James Woosnam   http://localhost:4200 add to cors for Neil
    Public Class UsersController
        Inherits ApiController

        Public Class ErrorResponse
            Public ReasonId As HttpStatusCode = HttpStatusCode.OK
            Public ReasonDescription As String = Nothing
        End Class
        Public Class Sessionclass
            Public SessionId As String
        End Class

        <HttpGet>
        Public Function GetUser(SessionId As String) As HttpResponseMessage
            '  Public Function GetUser(ByVal [me] As Boolean) As HttpResponseMessage
            Dim UserRes As New PEPSecurity.PaDSUser
            Dim errRes As New ErrorResponse
            Try
                If SessionId = Nothing Then
                    errRes.ReasonDescription = "SessionId not found"
                    Exit Try
                End If
                Dim tryGUID As Guid = Nothing
                If Not Guid.TryParse(SessionId, tryGUID) Then
                    errRes.ReasonId = HttpStatusCode.NotAcceptable
                    errRes.ReasonDescription = "SessionId is not a valid GUID"
                    Exit Try
                End If
                Dim PaDSDB As BusinessLogic.Database = New PaDSDB().db
                Try
                    Dim pepS As New PEPSecurity(PaDSDB, New StdCode().GetIPAddress(HttpContext.Current.Request))
                    If HttpContext.Current.Request.Headers.AllKeys.Contains("X-Forwarded-For") AndAlso HttpContext.Current.Request.Headers("X-Forwarded-For") IsNot Nothing Then pepS.SessionLogExtraComment += "X-Forwarded-For:" & HttpContext.Current.Request.Headers("X-Forwarded-For")
                    UserRes = pepS.GetUser(SessionId)
                    errRes.ReasonDescription = UserRes.ReasonDescription
                Catch ex As Exception
                    '19/1/21    James Woosnam   Only do a error return for InternalServerError
                    '  errRes.ReasonId = HttpStatusCode.Unauthorized
                    errRes.ReasonDescription = ex.Message
                Finally
                    Try
                        PaDSDB.DBConnection.Close()
                        PaDSDB.DBConnection.Dispose()
                    Catch ex As Exception
                    End Try
                End Try
            Catch ex As Exception
                '****LOG ERROR****
                errRes.ReasonDescription = "Unexpected error encountered."
                errRes.ReasonId = HttpStatusCode.InternalServerError
                Try
                    If New PaDSDB().db.ShowFullError Then
                        errRes.ReasonDescription += " ShowFullError:" & ex.Message
                    Else
                        errRes.ReasonDescription += " Set ShowFullError for more."
                    End If
                Catch ex1 As Exception
                End Try
            End Try
            '19/1/21    James Woosnam   Only do a error return for InternalServerError
            If errRes.ReasonId = HttpStatusCode.InternalServerError Then Return Request.CreateResponse(Of String)(errRes.ReasonId, errRes.ReasonDescription)
            Return Request.CreateResponse(errRes.ReasonId, UserRes)
        End Function

        Public Class UserSettings
            '  Dim UserId As Integer
            Public SessionId As String
            Public ClientSettings As Object
            Public SendJournalAlerts As Boolean = False
            Public SendVideoAlerts As Boolean = False
        End Class


        <HttpPut>
        Public Function PutUserSettings(UserId As Integer, UsrSett As UserSettings) As HttpResponseMessage
            '9/2/21     James Woosnam   SIR5176 - Add SendJournalAlerts & SendVideoAlerts
            Dim UserRes As New PEPSecurity.PaDSUser
            Dim errRes As New ErrorResponse
            Try
                If UsrSett.SessionId = Nothing Then
                    errRes.ReasonDescription = "SessionId not found"
                    Exit Try
                End If
                Dim tryGUID As Guid = Nothing
                If Not Guid.TryParse(UsrSett.SessionId, tryGUID) Then
                    errRes.ReasonId = HttpStatusCode.NotAcceptable
                    errRes.ReasonDescription = "SessionId is not a valid GUID"
                    Exit Try
                End If
                Dim PaDSDB As BusinessLogic.Database = New PaDSDB().db
                Try
                    Dim pepS As New PEPSecurity(PaDSDB, New StdCode().GetIPAddress(HttpContext.Current.Request))
                    If HttpContext.Current.Request.Headers.AllKeys.Contains("X-Forwarded-For") AndAlso HttpContext.Current.Request.Headers("X-Forwarded-For") IsNot Nothing Then pepS.SessionLogExtraComment += "X-Forwarded-For:" & HttpContext.Current.Request.Headers("X-Forwarded-For")
                    pepS.AddUpdateUserClientSettings(UserId, UsrSett.ClientSettings, UsrSett.SendJournalAlerts, UsrSett.SendVideoAlerts, UsrSett.SessionId)
                    UserRes = pepS.GetUser(UsrSett.SessionId)
                    errRes.ReasonDescription = UserRes.ReasonDescription
                Catch ex As Exception
                    '19/1/21    James Woosnam   Only do a error return for InternalServerError
                    '   errRes.ReasonId = HttpStatusCode.InternalServerError
                    UserRes.ReasonDescription = ex.Message
                Finally
                    Try
                        PaDSDB.DBConnection.Close()
                        PaDSDB.DBConnection.Dispose()
                    Catch ex As Exception
                    End Try
                End Try
            Catch ex As Exception
                '****LOG ERROR****
                errRes.ReasonDescription = "Unexpected error encountered."
                If errRes.ReasonId = HttpStatusCode.OK Then errRes.ReasonId = HttpStatusCode.InternalServerError
                Try
                    If New PaDSDB().db.ShowFullError Then
                        errRes.ReasonDescription += " ShowFullError:" & ex.Message
                    Else
                        errRes.ReasonDescription += " Set ShowFullError for more."
                    End If
                Catch ex1 As Exception
                End Try
            End Try
            '19/1/21    James Woosnam   Only do a error return for InternalServerError
            If errRes.ReasonId = HttpStatusCode.InternalServerError Then Return Request.CreateResponse(Of String)(errRes.ReasonId, errRes.ReasonDescription)
            Return Request.CreateResponse(errRes.ReasonId, UserRes)

        End Function

        <Route("api/v1/Users/Logout")>
        <Route("api/Users/Logout")>
        <HttpPost>
        Public Function Logout(SessionId As String) As HttpResponseMessage
            Dim errRes As New ErrorResponse
            Dim SessLogoutResp As New PEPSecurity.SessionLogoutResponse
            Try
                Dim tryGUID As Guid = Nothing
                If Not Guid.TryParse(SessionId, tryGUID) Then
                    errRes.ReasonId = HttpStatusCode.NotAcceptable
                    errRes.ReasonDescription = "SessionId is not a valid GUID"
                    Exit Try
                End If
                Dim PaDSDB As BusinessLogic.Database = New PaDSDB().db
                Try
                    Dim pepS As New PEPSecurity(PaDSDB, New StdCode().GetIPAddress(HttpContext.Current.Request))
                    If HttpContext.Current.Request.Headers.AllKeys.Contains("X-Forwarded-For") AndAlso HttpContext.Current.Request.Headers("X-Forwarded-For") IsNot Nothing Then pepS.SessionLogExtraComment += "X-Forwarded-For:" & HttpContext.Current.Request.Headers("X-Forwarded-For")
                    SessLogoutResp = pepS.SessionLogout(SessionId.ToString)
                    errRes.ReasonDescription = SessLogoutResp.ReasonDescription
                Catch ex As Exception
                    errRes.ReasonId = HttpStatusCode.Unauthorized
                    errRes.ReasonDescription = ex.Message
                Finally
                    Try
                        PaDSDB.DBConnection.Close()
                        PaDSDB.DBConnection.Dispose()
                    Catch ex As Exception
                    End Try
                End Try

            Catch ex As Exception
                '****LOG ERROR****
                errRes.ReasonDescription = ex.Message
                Dim errMsg As String = "Unexpected error encountered."
                errRes.ReasonId = HttpStatusCode.InternalServerError
                Try
                    If New PaDSDB().db.ShowFullError Then
                        errMsg += " ShowFullError:" & ex.Message
                    Else
                        errMsg += " Set ShowFullError for more."
                    End If
                Catch ex1 As Exception
                End Try
                Return Request.CreateResponse(errRes.ReasonId, errMsg)

            End Try
            If errRes.ReasonDescription <> "" Then errRes.ReasonId = HttpStatusCode.Unauthorized
            Return Request.CreateResponse(errRes.ReasonId, SessLogoutResp)
        End Function
    End Class

End Namespace