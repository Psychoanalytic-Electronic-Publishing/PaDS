﻿'Modification History
'Mar 2021   James Woosnam   SIR5046 - Initial version
'19/8/21    James Woosnam   SIR5300 - Minor updates to correct period formating
'01/9/21    James Woosnam   SIR5314 - Rework SQL and total col source to make it unique over all period
'4/3/22 James Woosnam   SIR5373 - No_License requires a ItemId join in GetInvestigationRequestSQL
'15/11/23	James Woosnam	SIR5710 - Only allow one calendar year at a time

Public Class CounterReport
    ' Inherits ReportSSG
#Region "Class Properties"
    Private db As BusinessLogic.Database = Nothing
    Private UserSess As BusinessLogic.UserSession = Nothing
    Public ReportSQL As String = Nothing
    Dim sLn As String = Environment.NewLine
    Public Report_ID As String = Nothing
    Public Report_Name As String = Nothing
    Public InstitutionSubscriberId As Integer = Nothing
    Public ExcelWorkBook As SpreadsheetGear.IWorkbook
    Public IsMetricTypeChanged As Boolean = Nothing
    Public ReadOnly Property Platform As String
        Get
            Return db.GetParameterValue("CounterPlatformName", "PEPWeb")
        End Get
    End Property
    'Dim SourceTypes As ContentSetSourceTypes() = System.Enum.GetValues(GetType(ContentSetSourceTypes))
    'For Each SourceType As ContentSetSourceTypes In SourceTypes.Skip(1)
    Enum ReportMetricTypes
        Total_Item_Investigations
        Total_Item_Requests
        Unique_Item_Investigations
        Unique_Item_Requests
        Unique_Title_Investigations
        Unique_Title_Requests
        Searches_Platform
        Limit_Exceeded
        No_License
    End Enum
    Enum ReportAttributeTypes
        Data_Type
        YOP
        Access_Type
        Access_Method
    End Enum
    Public Attributes As New List(Of ReportAttributeTypes)
    Public Metrics As New List(Of ReportMetricTypes)

    Public FilterDataTypes As New List(Of String)
    Public FilterAccessMethods As New List(Of String)
    Public FilterAccessTypes As New List(Of String)
    Public FilterYOP As String = ""
    Dim _Periods As List(Of DateTime) = Nothing
    Public ReadOnly Property Periods As List(Of DateTime)
        Get
            If _Periods Is Nothing Then
                _Periods = New List(Of DateTime)
                Dim startMonth As DateTime = "01-Sep-2021" '& Now.Year 'db.IsDBNull(db.DLookup("MIN(MonthStartDate)", "UserActionLog", ""), Nothing)
                If Me.StartMonth <> Nothing Then startMonth = Me.StartMonth

                Dim endMonth As DateTime = "01-" & Now.ToString("MMM-yyyy") 'db.IsDBNull(db.DLookup("Max(MonthStartDate)", "UserActionLog", ""), Nothing)
                If Me.EndMonth <> Nothing Then endMonth = Me.EndMonth 'SIR5300 - Correct end period

                Select Case UserSess.AuthorityLevel
                    Case UserSession.AuthorityLevels.SuperCompanyAdmins, UserSession.AuthorityLevels.CompanyAdmins
                        'Company admin users can see all periods
                    Case Else
                        'other users only see completed months, so can't see current month
                        If endMonth.ToString("yyyy-MM") = Now.ToString("yyyy-MM") Then
                            endMonth = endMonth.AddMonths(-1)
                        End If
                End Select
                If startMonth <> Nothing Then
                    Dim addMonth As DateTime = startMonth
                    Do
                        _Periods.Add(addMonth)
                        addMonth = addMonth.AddMonths(1)
                    Loop Until addMonth > endMonth
                End If
            End If
            Return _Periods
        End Get
    End Property
    Public StartMonth As Date = Nothing
    Public EndMonth As Date = Nothing
    Public ExcludeMonthlyDetails As Boolean = False
    Public ReadOnly Property ReportByteArray As Byte()
        Get
            If Me.ExcelWorkBook Is Nothing Then
                Throw New Exception("Need ExcelWorkBook to return ByteArray ")
            End If
            Dim memoryStream As New System.IO.MemoryStream()
            Me.ExcelWorkBook.SaveToStream(memoryStream, SpreadsheetGear.FileFormat.OpenXMLWorkbook)
            Return memoryStream.ToArray
        End Get
    End Property
#End Region

    Public Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSess = UserSession
    End Sub
    Public Sub New(Report_ID As String, InstitutionSubscriberId As Integer, StartMonth As Date, EndMonth As Date, ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession, ByVal IsMetricTypeChanged As Boolean)
        Me.db = db
        Me.UserSess = UserSession
        Me.Report_ID = Report_ID
        Me.Report_Name = db.DLookup("Report_name", "CounterReport", "Report_ID='" & Me.Report_ID & "'")
        Me.StartMonth = StartMonth
        Me.EndMonth = EndMonth
        Me.InstitutionSubscriberId = InstitutionSubscriberId
        Me.IsMetricTypeChanged = IsMetricTypeChanged
    End Sub

    Public Sub BuildReport()
        Try
            '15/11/23	James Woosnam	SIR5710 - Only allow one calendar year at a time
            If StartMonth.Year <> EndMonth.Year Then Throw New Exception("SIR5710 - The counter report cn only be for 1 calendar year ")
            Me.ExcelWorkBook = SpreadsheetGear.Factory.GetWorkbook(IO.Path.Combine(Me.db.GetParameterValue("ReportTemplateDirectory"), "CounterReportTemplate.xlsx"))
            'Populate Header
            Dim ws As SpreadsheetGear.IWorksheet = Me.ExcelWorkBook.Sheets(0)
            ws.Cells(0, 1).Value = Me.Report_Name
            ws.Cells(1, 1).Value = Me.Report_ID
            ws.Cells(2, 1).Value = 5  'Release
            If Me.InstitutionSubscriberId = 0 Then
                ws.Cells(3, 1).Value = "All" 'Institution_Name
                ws.Cells(4, 1).Value = "All:" & Me.InstitutionSubscriberId 'Institution_ID
            Else
                ws.Cells(3, 1).Value = db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & Me.InstitutionSubscriberId) 'Institution_Name
                ws.Cells(4, 1).Value = Left(ws.Cells(3, 1).Value, IIf(Len(ws.Cells(3, 1).Value) >= 10, 10, Len(ws.Cells(3, 1).Value))).Replace(" ", "") & ":" & Me.InstitutionSubscriberId 'Institution_ID
            End If

            For Each metric In Me.Metrics
                Select Case Me.Report_ID
                    Case "PR", "TR"
                        If IsMetricTypeChanged Then
                            ws.Cells(5, 1).Value += metric.ToString & IIf(metric = Me.Metrics(Me.Metrics.Count - 1), "", "; ") 'Metric_Type
                        Else
                            'dont output metrics for PR and TR reports
                        End If
                    Case Else
                        ws.Cells(5, 1).Value += metric.ToString & IIf(metric = Me.Metrics(Me.Metrics.Count - 1), "", "; ") 'Metric_Type
                End Select

            Next

            Dim sFlt As String = ""
            If Not Report_ID.ToUpper.Contains("PR_P1") Then
                sFlt += GetFiterText("Data_Type", FilterDataTypes)
            End If
            sFlt += GetFiterText("Access_Method", FilterAccessMethods)
            Select Case Me.Report_ID
                Case "PR", "PR_P1", "TR", "TR_B2", "TR_B3", "TR_J2", "TR_J3"
                    'Don't add Access_Type filter
                Case Else
                    sFlt += GetFiterText("Access_Type", FilterAccessTypes)
            End Select
            If FilterYOP <> "" Then sFlt += "YOP=" & FilterYOP & "; "
            If sFlt <> "" Then sFlt = sFlt.ToString.Substring(0, sFlt.Length - 2)
            ws.Cells(6, 1).Value = sFlt
            Dim attributes As String = ""
            If Me.Report_ID.Contains("_") Then
                'If report ID contains _ then it is a standard report so don't show report attributes
            Else
                For Each attr In Me.Attributes
                    If attributes = "" Then attributes = "Attributes_To_Show="
                    attributes += attr.ToString & IIf(attr = Me.Attributes(Me.Attributes.Count - 1), "", "|")
                Next
            End If

            ws.Cells(7, 1).Value = attributes
            ws.Cells(8, 1).Value = "" 'Exceptions?
            ws.Cells(9, 1).Value = "Begin_Date=" & Me.StartMonth.ToString("yyyy-MM-dd") & "; End_Date=" & Me.EndMonth.AddMonths(1).AddDays(-1).ToString("yyyy-MM-dd")  'Reporting_Period
            ws.Cells(10, 1).Value = Now.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'") 'created date in RFC3339 date format
            ws.Cells(11, 1).Value = UserSess.UserFullName ' created by


            'Populate table header
            colNo = 0
            rowNo = 13
            Dim tb As DataTable = db.GetDataTableFromSQL(Me.ReportSQL)

            Dim infoColCount As Integer = tb.Columns.Count - 3
            Dim countColCount As Integer = 1 + IIf(Me.ExcludeMonthlyDetails, 0, Me.Periods.Count)
            'Copy Columns
            ws.Cells(rowNo, 1).Copy(ws.Cells(rowNo, infoColCount, rowNo, infoColCount + countColCount - 1))
            ws.Cells(rowNo, 0).Copy(ws.Cells(rowNo, 1, rowNo, infoColCount - 1))
            For Each col As DataColumn In tb.Columns
                Select Case col.ColumnName
                    Case "MonthStartDate", "PeriodCount", "AllPeriodCount"
                    Case Else
                        AddTableCell(col.ColumnName, ws)
                End Select
            Next

            AddTableCell("Reporting_Period_Total", ws)
            If Not ExcludeMonthlyDetails Then
                For Each mth As Date In Me.Periods
                    AddTableCell(mth.ToString("MMM-yyyy"), ws)   'Month title
                Next
            End If

            'Populte Table rows
            Dim lastMonthDatePopulated As Date = "31-dec-4949"
            Dim LastItemPopulated As String = ""
            Dim countTotal As Integer = 0
            Dim TotalCoNo As Integer = 0
            Dim colNoStartOfPeriodLoop As Integer = 0
            For Each r As DataRow In tb.Rows
                Dim thisMonthDate As Date = r("MonthStartDate")
                Dim thisItemId As String = ""
                If tb.Columns.Contains("Proprietary_ID") Then
                    thisItemId = r("Proprietary_ID")
                End If

                If thisMonthDate <= lastMonthDatePopulated Or LastItemPopulated <> thisItemId Then
                    If lastMonthDatePopulated <> CDate("31-dec-4949") Then
                        colNo = TotalCoNo
                        AddTableCell(countTotal, ws) 'populate total cell
                        countTotal = 0
                    End If

                    'Must be the start of a new data row
                    colNo = 0
                    rowNo += 1
                    'Copy Rows
                    ws.Cells(rowNo, 1).Copy(ws.Cells(rowNo + 1, 1, rowNo + 1, 1))
                    ws.Cells(rowNo, 0).Copy(ws.Cells(rowNo + 1, 0, rowNo + 1, 0))
                    'Copy Columns
                    ws.Cells(rowNo, 1).Copy(ws.Cells(rowNo, infoColCount, rowNo, infoColCount + countColCount - 1))
                    ws.Cells(rowNo, 0).Copy(ws.Cells(rowNo, 1, rowNo, infoColCount - 1))
                    For Each col As DataColumn In tb.Columns
                        Select Case col.ColumnName
                            Case "MonthStartDate", "PeriodCount", "AllPeriodCount"
                            Case Else
                                AddTableCell(r(col.ColumnName), ws)
                        End Select
                    Next
                    lastMonthDatePopulated = "31-Dec-4949"
                    TotalCoNo = colNo
                    colNo += 1 'leave space for total
                    colNoStartOfPeriodLoop = colNo
                End If

                Dim loopLastMonth As Date = "01-jan-1900"
                If Not ExcludeMonthlyDetails Then
                    '19/8/21    James Woosnam   SIR5300 - Minor updates to correct period formating
                    colNo = colNoStartOfPeriodLoop 'SIR5300 - set col to first period col
                    For Each mth As Date In Me.Periods
                        If mth = thisMonthDate Then
                            AddTableCell(r("PeriodCount"), ws)

                        Else
                            If ws.Cells(rowNo, colNo).Value Is Nothing Then
                                AddTableCell(0, ws)
                            Else
                                colNo += 1 'SIR5300 - always increment colNo
                            End If
                        End If
                    Next
                End If

                countTotal = r("AllPeriodCount") 'this will be the same foe all periods on one line
                lastMonthDatePopulated = thisMonthDate
                LastItemPopulated = thisItemId
            Next
            If lastMonthDatePopulated <> CDate("31-dec-4949") Then
                colNo = TotalCoNo
                AddTableCell(countTotal, ws) 'populate total cell
            End If
        Catch ex As Exception
            Throw New Exception("Build Counter Report Failed:" & ex.Message, ex)
        End Try
    End Sub
    Dim colNo As Integer = 0
    Dim rowNo As Integer = 13
    Sub AddTableCell(CellText As Object, ws As SpreadsheetGear.IWorksheet)
        ws.Cells(rowNo, colNo).Value = db.IsDBNull(CellText, "")
        colNo += 1
    End Sub
    Function GetFiterText(FilterName As String, Filters As List(Of String)) As String
        Dim sFlt As String = Nothing
        If Filters.Count > 0 Then
            sFlt += FilterName & "="
            For Each Fltr In Filters
                sFlt += Fltr.ToString & IIf(Fltr = Filters(Filters.Count - 1), "", "|")
            Next
            sFlt += "; "
        End If
        Return sFlt
    End Function


    Public Sub BuildSQL()
        '01/9/21    James Woosnam   SIR5314 - Rework SQL and total col source to make it unique over all period

        Me.ReportSQL = "
SELECT unionOfAllTypes.*
FROM ("
        For Each MetricType As ReportMetricTypes In Me.Metrics
            Me.ReportSQL += "--*****************************"
            Me.ReportSQL += "-- Start Of " & MetricType.ToString
            Me.ReportSQL += "--*****************************"
            Select Case MetricType
                Case ReportMetricTypes.Searches_Platform
                    Me.ReportSQL += GetSearchSQL(True) + IIf(MetricType = Me.Metrics(Me.Metrics.Count - 1), "", "UNION" & sLn)
                Case Else
                    Me.ReportSQL += GetInvestigationRequestSQL(MetricType, True) + IIf(MetricType = Me.Metrics(Me.Metrics.Count - 1), "", "UNION" & sLn)
            End Select
            Me.ReportSQL += "--============END of " & MetricType.ToString & "====================" & sLn
        Next
        Me.ReportSQL += "
    ) unionOfAllTypes
ORDER BY" & sLn
        Dim firstComma As String = ""
        If Report_ID.ToUpper.Contains("TR") Then
            Me.ReportSQL += "  Title" & sLn
            firstComma = ","
        End If
        For Each attr As ReportAttributeTypes In Me.Attributes


            Me.ReportSQL += IIf(attr = Me.Attributes(0), firstComma, ",") & attr.ToString & sLn
        Next
        Me.ReportSQL += IIf(Me.Attributes.Count = 0, firstComma, ",") & "Metric_Type" & sLn
        Me.ReportSQL += ",MonthStartDate" & sLn
    End Sub
    Function GetInvestigationRequestSQL(MetricType As ReportMetricTypes, ShowAllPeriodTotal As Boolean) As String
        '01/9/21    James Woosnam   SIR5314 - Rework SQL and total col source to make it unique over all period
        Dim sql As String = ""

        sql += "
SELECT" & sLn
        If Report_ID.ToUpper.Contains("PR") Then
            sql += "  
                Platform = '" & Me.Platform & "'" & sLn
        Else
            '25/10/23   James Woosnam   SIR5706 - As temp fix use PEP as Publisher, should be changed below wehn real publisher available
            sql += "
                Title = TitleName
                ,Publisher = ISNULL(Publisher,'PEP')
                ,Publisher_ID = '" & Platform & ":' + ISNULL(Publisher_ID,'PEP')
                ,Platform='" & Platform & "'
                ,DOI=''
                ,Proprietary_ID = '" & Me.Platform & ":PEP' --PEP Should be publisher when available
                ,ISBN
                ,Print_ISSN = ''
                ,Online_ISSN = ''
                ,URI = ''
                "
        End If
        For Each attr As ReportAttributeTypes In Me.Attributes
            sql += "  ," & attr.ToString & sLn
        Next

        If ShowAllPeriodTotal Then sql += "  ,MonthStartDate = u.MonthStartDate" & sLn
        sql += "  ,Metric_Type" & sLn
        sql += "  ,PeriodCount" & sLn
        If ShowAllPeriodTotal Then
            sql += "  ,AllPeriodCount" & sLn
        Else
            If Not Report_ID.ToUpper.Contains("PR") Then
                sql += ",TitleId" & sLn 'required for where on AllperiodCount sub query
                '  sql += ",ItemId" & sLn
            End If
        End If

        sql += "FROM (" & sLn
        sql += "SELECT" & sLn
        If Report_ID.ToUpper.Contains("PR") Then
            sql += "  Platform = '" & Me.Platform & "'" & sLn
        Else
            sql += "
TitleName
,TitleId
,publisher
,Publisher_ID
,ISBN
"
        End If
        For Each attr As ReportAttributeTypes In Me.Attributes
            sql += "  ,u." & attr.ToString & sLn
        Next

        If ShowAllPeriodTotal Then sql += "  ,MonthStartDate = u.MonthStartDate" & sLn
        sql += "  ,Metric_Type = '" & MetricType.ToString & "'" & sLn
        Select Case MetricType
            Case ReportMetricTypes.Unique_Title_Investigations, ReportMetricTypes.Unique_Title_Requests
                '3/9/21 James   I think we need to include UserId in the distinct, but below code doesn't work
                'also the total needs to be the following distinct over the whole period so will require a separte column derived from same sql function but without the period group by
                sql += "  ,PeriodCount =COUNT(DISTINCT TitleId + CAST(userid AS VARCHAR)) " & sLn
            Case ReportMetricTypes.Unique_Item_Investigations, ReportMetricTypes.Unique_Item_Requests
                sql += "  ,PeriodCount =COUNT(DISTINCT TitleId + CAST(userid AS VARCHAR)) " & sLn
            Case Else
                sql += "  ,PeriodCount =COUNT(*) " & sLn
        End Select
        If ShowAllPeriodTotal Then
            sql += "--*****Start AllPeriodCount" & sLn
            sql += "    ,AllPeriodCount= (SELECT SUM(PeriodCount) FROM (" & GetInvestigationRequestSQL(MetricType, False) & ") t WHERE 1=1 "
            For Each attr As ReportAttributeTypes In Me.Attributes
                sql += " AND t." & attr.ToString & " = u." & attr.ToString & sLn
            Next
            If Not Report_ID.ToUpper.Contains("PR") Then
                Select Case MetricType
                    Case ReportMetricTypes.Unique_Title_Investigations, ReportMetricTypes.Unique_Title_Requests
                        sql += " AND  t.TitleId = u.TitleId" & sLn
                    Case ReportMetricTypes.Unique_Item_Investigations, ReportMetricTypes.Unique_Item_Requests, ReportMetricTypes.Total_Item_Investigations, ReportMetricTypes.Total_Item_Requests, ReportMetricTypes.No_License
                        '4/3/22 James Woosnam   SIR5373 - No_License requires a ItemId join in GetInvestigationRequestSQL
                        sql += " AND  t.TitleId = u.TitleId" & sLn
                End Select
            End If
            sql += " )" & sLn
            sql += "--=====End AllPeriodCount" & sLn
        End If

        sql += "FROM UserActionLog" & Me.StartMonth.Year & " u
 WHERE 1=1" & sLn
        If Me.InstitutionSubscriberId <> 0 Then
            sql += "AND Institution_Id=" & Me.InstitutionSubscriberId & sLn
        End If
        If MetricType.ToString.Contains("Investigations") Then
            sql += "AND ActionType='Investigation'" & sLn
        End If
        If MetricType.ToString.Contains("Requests") Then
            sql += "AND ActionType='Request'" & sLn
        End If
        If MetricType = ReportMetricTypes.Limit_Exceeded Then
            sql += "AND ActionType='Limit_Exceeded'" & sLn
        End If
        If MetricType = ReportMetricTypes.No_License Then
            sql += "AND ActionType='No_License'" & sLn
        End If
        sql += "AND MonthStartDate BETWEEN " & New StdCode().vFQ(StartMonth, "D") & " AND " & New StdCode().vFQ(EndMonth, "D") & sLn
        If Not Report_ID.ToUpper.Contains("PR_P1") Then
            If Me.FilterDataTypes IsNot Nothing Then
                Dim tps As String = ""
                For Each filter As String In Me.FilterDataTypes
                    tps += IIf(tps = "", "", ",") & "'" & filter & "'"
                Next

                sql += "AND Data_Type IN (" + tps + ")" & sLn
            End If
        End If
        If Me.FilterAccessMethods IsNot Nothing Then
            Dim tps As String = ""
            For Each filter As String In Me.FilterAccessMethods
                tps += IIf(tps = "", "", ",") & "'" & filter & "'"
            Next
            sql += "AND Access_Method IN (" + tps + ")" & sLn
        End If
        If Me.FilterAccessTypes IsNot Nothing Then
            Dim tps As String = ""
            For Each filter As String In Me.FilterAccessTypes
                tps += IIf(tps = "", "", ",") & "'" & filter & "'"
            Next
            sql += "AND Access_Type IN (" + tps + ")" & sLn
        End If
        Dim fYears As String = ""
        If Me.FilterYOP <> "" And Me.FilterYOP <> "0001" Then
            'All years (default), a specific year in the format yyyy, or a range of years in the format yyyy-yyyy. Use 0001 for unknown or 9999 for articles in press.
            'Note that the COUNTER_SUSHI API allows the specification of multiple years And ranges separated by the vertical pipe (“|”) character.
            Dim sParts() As String = Me.FilterYOP.Split("|")  'Check for | 
            For Each sPart As String In sParts
                'each part will eiher be a single year or  range 
                If IsNumeric(sPart) Then
                    fYears += sPart & "," 'single year
                Else
                    Dim sYears() As String = sPart.Split("-") 'check for range of years
                    If sYears.Count <> 2 Or Not IsNumeric(sYears(0)) Or Not IsNumeric(sYears(1)) Then Throw New Exception("YOP Filter part:" & sPart & " must be a year single year yyyy or range in the from yyyy-yyyy")
                    If sYears.Count = 1 Then
                        fYears += sYears(0) & ","
                    Else
                        For y As Integer = CInt(sYears(0)) To CInt(sYears(1))
                            fYears += y & ","
                        Next
                    End If
                End If
            Next
        End If
        If fYears <> "" Then
            fYears = Left(fYears, Len(fYears) - 1)
            sql += "AND YOP IN (" + fYears + ")" & sLn

        End If
        Dim addGroupComma As Boolean = False
        If ShowAllPeriodTotal Or Not Report_ID.ToUpper.Contains("PR") Or Me.Attributes.Count <> 0 Then
            sql += "GROUP BY" & sLn
        End If
        If Report_ID.ToUpper.Contains("PR") Then

        Else
            sql += IIf(addGroupComma, ",", "") & "
               TitleName
                ,TitleId
                ,publisher
                ,Publisher_ID
                ,ISBN
            "
            addGroupComma = True
        End If
        For Each attr As ReportAttributeTypes In Me.Attributes
            sql += IIf(addGroupComma, ",", "") & "  u." & attr.ToString & sLn
            addGroupComma = True
        Next
        If ShowAllPeriodTotal Then
            sql += IIf(addGroupComma, ",", "") & "    u.MonthStartDate" & sLn
            addGroupComma = True
        End If
        sql += ") u" & sLn

        Return sql
    End Function
    Function GetSearchSQL(ShowAllPeriodTotal As Boolean) As String
        Dim MetricType As ReportMetricTypes = ReportMetricTypes.Searches_Platform
        Dim sql As String = ""
        sql = "
SELECT 
    Platform = '" & Me.Platform & "'" & sLn
        For Each attr As ReportAttributeTypes In Me.Attributes
            sql += "  ,u." & attr.ToString & sLn
        Next

        If ShowAllPeriodTotal Then sql += "  ,MonthStartDate = u.MonthStartDate" & sLn
        sql += "  ,Metric_Type = '" & MetricType.ToString & "'" & sLn

        sql += "  ,PeriodCount =COUNT(*) " & sLn
        If ShowAllPeriodTotal Then
            sql += "--*****Start AllPeriodCount" & sLn
            sql += "  ,AllPeriodCount = (SELECT sum(PeriodCount) FROM (" & GetSearchSQL(False) & ") t WHERE 1=1 " & sLn
            For Each attr As ReportAttributeTypes In Me.Attributes
                sql += " AND t." & attr.ToString & " = u." & attr.ToString & sLn
            Next
            sql += ")" & sLn
            sql += "--=====End AllPeriodCount" & sLn
        End If
        sql += "FROM UserActionLog" & Me.StartMonth.Year & " u
 WHERE 1=1" & sLn
        sql += "AND ActionType='Search'" & sLn
        If Me.InstitutionSubscriberId <> 0 Then
            sql += "AND Institution_Id=" & Me.InstitutionSubscriberId & sLn
        End If
        sql += "AND MonthStartDate BETWEEN " & New StdCode().vFQ(StartMonth, "D") & " AND " & New StdCode().vFQ(EndMonth, "D") & sLn
        If Not Report_ID.ToUpper.Contains("PR_P1") Then
            If Me.FilterDataTypes IsNot Nothing Then
                Dim tps As String = ""
                For Each filterDataType As String In Me.FilterDataTypes
                    tps += IIf(tps = "", "", ",") & "'" & filterDataType & "'"
                Next
                sql += "AND Data_Type IN (" + tps + ")" & sLn
            End If
        End If
        If ShowAllPeriodTotal Or Me.Attributes.Count <> 0 Then sql += "GROUP BY" & sLn
        If ShowAllPeriodTotal Then sql += "    u.MonthStartDate" & sLn
        For Each attr As ReportAttributeTypes In Me.Attributes
            sql += IIf(ShowAllPeriodTotal Or attr <> Me.Attributes(0), ",", "") & "u." & attr.ToString & sLn
        Next

        Return sql
    End Function
End Class
