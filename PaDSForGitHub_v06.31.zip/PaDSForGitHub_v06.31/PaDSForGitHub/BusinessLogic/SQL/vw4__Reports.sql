--8/3/11	James Woosnam	Use Money instead of small money
--31/5/11	James Woosnam	For Invoice REports any number that should be shown as strings should be cast to varchars	

if exists (select * from sysobjects where id = object_id(N'[dbo].[vw400CustomerStatement]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw400CustomerStatement]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[vw403InvoiceDetailLines]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw403InvoiceDetailLines]
GO
if exists (select * from sysobjects where id = object_id(N'[dbo].[vw402InvoiceSummaryLines]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw402InvoiceSummaryLines]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[vw401InvoiceHead]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw401InvoiceHead]
GO
if exists (select * from sysobjects where id = object_id(N'[dbo].[vw400InvoiceSummaryAll]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw400InvoiceSummaryAll]
GO
if exists (select * from sysobjects where id = object_id(N'[dbo].[vw405InvoiceDetailAll]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw405InvoiceDetailAll]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[vw410ReceiptHead]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw410ReceiptHead]
GO
--dfd
CREATE VIEW vw400CustomerStatement 
AS
SELECT     Subscriber.SubscriberName
	, Cashbook.SubscriberID
	, Cashbook.CompanyID
	, Cashbook.EntryDate
	, Cashbook.EntryType + ' ' + Cashbook.PaymentType AS Description
	, Cashbook.Amount AS PaymentAmount
	, NULL AS OrderAmount
	, Cashbook.CurrencyCode
FROM  Cashbook 
	INNER JOIN Subscriber 
	ON Cashbook.SubscriberID = Subscriber.SubscriberId
WHERE CashbookStatus = 'Confirmed'
UNION
SELECT     Subscriber.SubscriberName
	, SalesOrder.SubscriberId
	, SalesOrder.CompanyId
	, SalesOrder.OrderDate AS EntryDate
	, 'Order:' + CAST(OrderNumber AS VARCHAR) + ' for ' + SalesOrder.PrimaryProductCode AS Description
	, NULL AS PaymentAmount
	, SalesOrder.AmountGross AS OrderAmount
	, SalesOrder.CurrencyCode
FROM SalesOrder 
	INNER JOIN Subscriber 
	ON SalesOrder.SubscriberId = Subscriber.SubscriberId
WHERE SalesOrderStatus IN ('Confirmed','Complete')

GO
CREATE VIEW vw402InvoiceSummaryLines
AS
--31/5/11	James Woosnam	For Invoice REports any number that should be shown as strings should be cast to varchars	
SELECT      CAST(SalesOrderLine.OrderNumber AS VARCHAR) OrderNumber
	, SalesOrderLine.ProductCode
	, SalesOrderLine.ProductRateId
	, Min(ProductShortName ) AS ProductName
	, Min( SubscriberCategory + ' ' + DeliveryArea) AS RateTypeDescription
	,  SalesOrderLine.ProductRate
	, SUM(SalesOrderLine.Quantity) AS LineQuantity
	, SUM(SalesOrderLine.AmountProduct) AS LineAmount
	, ProductRate.RateType
	, ProductRate.AccountType
FROM         SalesOrderLine 
	LEFT JOIN ProductRate 
	ON SalesOrderLine.ProductRateId = ProductRate.ProductRateId
	LEFT JOIN Product 
	ON SalesOrderLine.ProductCode = Product.ProductCode
WHERE SalesOrderLine.IsCancel = 0
GROUP BY  CAST(SalesOrderLine.OrderNumber AS VARCHAR)
	, SalesOrderLine.ProductCode
	, SalesOrderLine.ProductRateId
	, SalesOrderLine.ProductRate
	, ProductRate.RateType
	, ProductRate.AccountType

GO
CREATE VIEW vw403InvoiceDetailLines
AS
--31/5/11	James Woosnam	For Invoice REports any number that should be shown as strings should be cast to varchars	
SELECT      CAST(SalesOrderLine.OrderNumber AS VARCHAR) OrderNumber
	,CAST(Subscriber.SubscriberId AS VARCHAR) AS LineSubscriberId
	,Subscriber.SubscriberName AS LineSubscriberName
	,SubscriberAffiliate.AffiliateReferenceID
	, SalesOrderLine.ProductCode
	, SalesOrderLine.ProductRateId
	, Min(ProductShortName ) AS ProductName
	, Min( Subscriber.SubscriberCategory + ' ' + DeliveryArea) AS RateTypeDescription
	,  SalesOrderLine.ProductRate
	, SUM(SalesOrderLine.Quantity) AS LineQuantity
	, SUM(SalesOrderLine.AmountProduct) AS LineAmount
	, ProductRate.RateType
	, ProductRate.AccountType
FROM         SalesOrderLine 
	LEFT JOIN ProductRate 
	ON SalesOrderLine.ProductRateId = ProductRate.ProductRateId
	INNER JOIN Subscriber
	On Subscriber.SubscriberId = SalesOrderLine.SubscriberId
	INNER JOIN SalesOrder
	ON SalesOrder.OrderNumber = SalesOrderLine.OrderNumber
	Left Join SubscriberAffiliate
	On ChildSubscriberId = Subscriber.SubscriberId
	AND ParentSubscriberId = Salesorder.SubscriberId
	LEFT JOIN Product 
	ON SalesOrderLine.ProductCode = Product.ProductCode
WHERE SalesOrderLine.IsCancel = 0
GROUP BY  CAST(SalesOrderLine.OrderNumber AS VARCHAR) 
	,Subscriber.SubscriberId
	,Subscriber.SubscriberName
	,SubscriberAffiliate.AffiliateReferenceID
	, SalesOrderLine.ProductCode
	, SalesOrderLine.ProductRateId
	, SalesOrderLine.ProductRate
	, ProductRate.RateType
	, ProductRate.AccountType
GO

CREATE VIEW vw401InvoiceHead
AS
--31/5/11	James Woosnam	For Invoice REports any number that should be shown as strings should be cast to varchars	
SELECT     CompanyAccount.AccountNumber
	,  CAST(SalesOrder.OrderNumber AS VARCHAR) OrderNumber
	, SalesOrder.OrderType
	,CAST( SalesOrder.SubscriberId as varchar) SubscriberId 
	,SalesOrder.CompanyId
	, SalesOrder.OrderedByName
	, SalesOrder.SalesOrderStatus
	, SalesOrder.AccountOrderNumber
	, SalesOrder.CurrencyCode
	, SalesOrder.PrimaryProductCode
	,TotalQuantity
	, SalesOrder.AmountNet
	, SalesOrder.PercentDiscount
	, AmountCarriage
	,SalesOrder.PercentVAT
	, AmountGross
	, CONVERT(SMALLMONEY, SalesOrder.AmountNet + AmountCarriage - AmountDiscount) AS AmountNetBeforeVAT
	, AmountDiscount
	, AmountVAT
	, SalesOrder.CancelledDate
	, Subscriber.SubscriberName
	,Subscriber.VATNumber
	, (SELECT dbo.f530SubscriberAddressDisplay(CompanyAccount.BillingAddressId,'MultiLine')) AS AddressDisplay
FROM SalesOrder 
	INNER JOIN Subscriber 
	ON Subscriber.SubscriberId = SalesOrder.SubscriberId 
	INNER JOIN CompanyAccount 
	ON  CompanyAccount.SubscriberId = SalesOrder.SubscriberId 
	AND CompanyAccount.CompanyId = SalesOrder.CompanyId 
	INNER JOIN Company 
	ON SalesOrder.CompanyId = Company.CompanyId 
	AND CompanyAccount.CompanyId = Company.CompanyId 
GO
CREATE VIEW vw400InvoiceSummaryAll
AS
SELECT vw401InvoiceHead.*
	, ProductCode
	, ProductRateId
	, ProductName
	, RateTypeDescription
	,  ProductRate
	,  LineQuantity
	,  LineAmount
	, RateType
	, AccountType
FROM vw402InvoiceSummaryLines 
                 INNER JOIN vw401InvoiceHead 
                 ON vw402InvoiceSummaryLines.OrderNumber = vw401InvoiceHead.OrderNumber 


GO
CREATE VIEW vw405InvoiceDetailAll
AS
SELECT vw401InvoiceHead.*
	,LineSubscriberid
	,LineSubscriberName
	,AffiliateReferenceID
	, ProductCode
	, ProductRateId
	, ProductName
	, RateTypeDescription
	,  ProductRate
	,  LineQuantity
	,  LineAmount
	, RateType
	, AccountType
FROM vw403InvoiceDetailLines 
                 INNER JOIN vw401InvoiceHead 
                 ON vw403InvoiceDetailLines.OrderNumber = vw401InvoiceHead.OrderNumber 


GO
CREATE VIEW vw410ReceiptHead
AS
--8/3/11	James Woosnam	Use Money instead of small money	
--31/5/11	James Woosnam	For Invoice REports any number that should be shown as strings should be cast to varchars	
SELECT     CompanyAccount.AccountNumber
	, CAST(Cashbook.OrderNumber as VARCHAR) OrderNumber
	, Cashbook.CashbookId
	, Cashbook.SubscriberID
	, Cashbook.CompanyID
	,SalesOrder.AccountOrderNumber
	, Cashbook.CurrencyCode
	, SalesOrder.PrimaryProductCode
	, Product.ProductName
	,Subscriber.SubscriberName
	, SubscriberAddress.Address1
	, SubscriberAddress.Address2
	, SubscriberAddress.Address3
	,SubscriberAddress.Address4
	, SubscriberAddress.Town
	, SubscriberAddress.County
	, SubscriberAddress.PostCode
	,Country.CountryName
	, Subscriber.VATNumber AS SubscriberVATNumber
--8/3/11	James Woosnam	Use Money instead of small money	
	,CONVERT(MONEY, Cashbook.Amount) AS Amount
	, (SELECT dbo.f530SubscriberAddressDisplay(CompanyAccount.BillingAddressId,'MultiLine')) AS AddressDisplay
FROM Subscriber 
	INNER JOIN Cashbook 
		Left JOIN SalesOrder 
			Left JOIN Product 
			ON SalesOrder.PrimaryProductCode = Product.ProductCode 
		ON SalesOrder.OrderNumber = Cashbook.OrderNumber 
	ON Subscriber.SubscriberId = Cashbook.SubscriberID 
	INNER JOIN CompanyAccount 
		INNER JOIN SubscriberAddress 
			INNER JOIN Country 
			ON Country.CountryID = SubscriberAddress.CountryId 
			ON SubscriberAddress.SubscriberAddressId = CompanyAccount.BillingAddressId 
		INNER JOIN Company 
		ON CompanyAccount.CompanyId = Company.CompanyId 
	ON Cashbook.CompanyID = CompanyAccount.CompanyId 
	AND Cashbook.SubscriberID = CompanyAccount.SubscriberId 
	AND Cashbook.CompanyID = Company.CompanyId

GO
