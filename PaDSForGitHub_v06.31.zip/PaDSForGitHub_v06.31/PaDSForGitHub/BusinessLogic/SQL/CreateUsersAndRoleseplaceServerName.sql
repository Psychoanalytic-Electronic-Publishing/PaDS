/*************************************************************************************
Script:	Creates the users and roles required for Database
Description:	

Amendments
Feb 2018	Remove loacal users PEP_FTP, IJP_FTP, PaDSReporter
21/9/19		James Woosnam	N' for a string no longer works in sql 2017!!
**************************************************************************************/

USE PaDS_Try 

IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') DROP USER [PaDSSQLServerUser]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLSecurityUser') DROP USER [PaDSSQLSecurityUser]

USE [PaDS_Try_Logs]


IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') DROP USER [PaDSSQLServerUser]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLSecurityUser') DROP USER [PaDSSQLSecurityUser]

USE [PADS_PEP_Usage]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') DROP USER [PaDSSQLServerUser]

USE [master]


IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') DROP USER [PaDSSQLServerUser]
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLSecurityUser') DROP USER [PaDSSQLSecurityUser]


--******************************************************************************
--******************************************************************************
--			END OF DROP SECTION
--******************************************************************************
--******************************************************************************

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = 'PaDSSQLServerUser') CREATE LOGIN [PaDSSQLServerUser] WITH PASSWORD= 'xxObscuredPasswordxx', DEFAULT_DATABASE=[PaDS_Try], DEFAULT_LANGUAGE=[British], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = 'PaDSSQLSecurityUser') CREATE LOGIN [PaDSSQLSecurityUser] WITH PASSWORD= 'xxObscuredPasswordxx', DEFAULT_DATABASE=[PaDS_Try], DEFAULT_LANGUAGE=[British], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF




USE [PADS_Try]

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') CREATE USER [PaDSSQLServerUser] FOR LOGIN [PaDSSQLServerUser] WITH DEFAULT_SCHEMA=[dbo]
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLSecurityUser') CREATE USER [PaDSSQLSecurityUser] FOR LOGIN [PaDSSQLSecurityUser] WITH DEFAULT_SCHEMA=[dbo]

EXEC sys.sp_addrolemember @rolename= 'db_owner', @membername= 'PaDSSQLSecurityUser'

USE [PaDS_Try_Logs]

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') CREATE USER [PaDSSQLServerUser] FOR LOGIN [PaDSSQLServerUser] WITH DEFAULT_SCHEMA=[dbo]
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLSecurityUser') CREATE USER [PaDSSQLSecurityUser] FOR LOGIN [PaDSSQLSecurityUser] WITH DEFAULT_SCHEMA=[dbo]

EXEC sys.sp_addrolemember @rolename= 'db_datareader', @membername= 'PaDSSQLServerUser'

EXEC sys.sp_addrolemember @rolename= 'db_datawriter', @membername= 'PaDSSQLServerUser'

EXEC sys.sp_addrolemember @rolename= 'db_owner', @membername= 'PaDSSQLSecurityUser'

USE [PADS_PEP_Usage]
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') CREATE USER [PaDSSQLServerUser] FOR LOGIN [PaDSSQLServerUser] WITH DEFAULT_SCHEMA=[dbo]
EXEC sys.sp_addrolemember @rolename= 'db_datareader', @membername= 'PaDSSQLServerUser'
EXEC sys.sp_addrolemember @rolename= 'db_datawriter', @membername= 'PaDSSQLServerUser'

USE [master]
--This User is needed to beable to get the database file size details from Pads02 for the CheckFreeDiskSpace batch job.
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = 'PaDSSQLServerUser') CREATE USER [PaDSSQLServerUser] FOR LOGIN [PaDSSQLServerUser] WITH DEFAULT_SCHEMA=[dbo]
EXEC sys.sp_addrolemember @rolename= 'db_owner', @membername= 'PaDSSQLServerUser'
