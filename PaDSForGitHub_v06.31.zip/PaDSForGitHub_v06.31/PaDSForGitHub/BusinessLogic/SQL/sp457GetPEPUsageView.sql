IF  exists (select * from dbo.sysobjects where id = object_id(N'sp457GetPEPUsageView') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp457GetPEPUsageView 
GO
CREATE  PROCEDURE sp457GetPEPUsageView (
					@StartMonth VARCHAR(20) = '2021-09 Sep'
					,@EndMonth VARCHAR(20) = '4949-12 Dec'
					,@ViewType VARCHAR(50) = 'SummaryByReportingParent'
					,@ReportingParentSubscriberId INT = NULL --American Psychological Association - Division 39
)
AS
--16/3/22	James Woosnam	SIR5457 - Add ArchiveOrCurrent
--21/3/22	James Woosnam	SIR5463 - Remove By Day grouping
--21/3/22	James Woosnam	SIR5463 - Change AffiliateRateSubscriber to ReportingParentSubscriber
--26/6/22    James Woosnam   SIR5487 - PEPUsageReadsFromJan2020ByReportingParent added
--15/8/22    James Woosnam   SIR5532 - Add AuthorStats
DECLARE @Message VARCHAR(MAX) = ''

IF @ViewType = 'SummaryByReportingParent'
BEGIN
	SELECT
		u.ReportingParentSubscriberId 
		,u.ReportingParentSubscriberName
		,UserActivitySessionCount = ISNULL(sum(u.UserActivitySessionCount ),0)
		,AbstractCount = ISNULL(SUM(u.AbstractCount),0)
		,ReadCount = ISNULL(SUM(u.ReadCount),0)
		,SearchCount = ISNULL(SUM(u.SearchCount),0)
		,TurnAwayCount = ISNULL(SUM(u.TurnAwayCount),0) --27/11/21	James	SIR5374 - Add TurnAwayCount
		,RecordCount = COUNT(*)
	FROM PEPUsageSummary u
	WHERE u.Month BETWEEN @StartMonth AND @EndMonth 
	GROUP BY
		u.ReportingParentSubscriberId
		,u.ReportingParentSubscriberName 
	ORDER BY 
		ISNULL(SUM(u.ReadCount),0) desc
		,u.ReportingParentSubscriberName 
END

IF @ViewType = 'DetailByReportingParent'
BEGIN
	SELECT
		ReportingParentSubscriberName
		,ReportingParentSubscriberId
		,ReportingParentType
		,LoggedInMethod
--		,DateDay
		,Year
		,Quarter
		,Month
		,UserCountry
		,PEPCode
		,DocumentVolume
		,DocumentYear
		,ArchiveOrCurrent--16/3/22	James Woosnam	SIR5457 - Add ArchiveOrCurrent
		--,authorMast
		--,DocumentId
		--,documentRef		
		,UserActivitySessionCount = ISNULL(sum(u.UserActivitySessionCount ),0)
		,AbstractCount = ISNULL(SUM(u.AbstractCount),0)
		,ReadCount = ISNULL(SUM(u.ReadCount),0)
		,SearchCount = ISNULL(SUM(u.SearchCount),0)
		,TurnAwayCount = ISNULL(SUM(u.TurnAwayCount),0) --27/11/21	James	SIR5374 - Add TurnAwayCount
	FROM PEPUsageSummary u
	WHERE u.Month BETWEEN @StartMonth AND @EndMonth 
	GROUP BY
		ReportingParentSubscriberName
		,ReportingParentSubscriberId
		,ReportingParentType
		,LoggedInMethod
--		,DateDay
		,Year
		,Quarter
		,Month
		,UserCountry
		,PEPCode
		,DocumentVolume
		,DocumentYear
		,ArchiveOrCurrent--16/3/22	James Woosnam	SIR5457 - Add ArchiveOrCurrent
		--,authorMast
		--,DocumentId
		--,documentRef	
	ORDER BY 
		ReportingParentSubscriberName 
		--,DateDay
		,PEPCode
END
IF @ViewType = 'SingleReportingParentDetail'
BEGIN
	IF @ReportingParentSubscriberId IS NULL 
	BEGIN
		SELECT @Message ='ViewType:' + @ViewType + ' requires @ReportingParentSubscriberId'
		RAISERROR ('%s', 18, 1,@Message)
	END
	SELECT
		ReportingParentSubscriberName
		,ReportingParentSubscriberId
		,ReportingParentType
		,UserName
		,UserFullName
--		,DateDay
		,Year
		,Quarter
		,Month
		,OrderNumber
		,UserCountry
		,LoggedInMethod
		,DocumentId
		,documentRef
		,PEPCode
		,DocumentVolume
		,DocumentYear
		,authorMast
		,ArchiveOrCurrent--16/3/22	James Woosnam	SIR5457 - Add ArchiveOrCurrent
		,UserActivitySessionCount = ISNULL(sum(u.UserActivitySessionCount ),0)
		,AbstractCount = ISNULL(SUM(u.AbstractCount),0)
		,ReadCount = ISNULL(SUM(u.ReadCount),0)
		,SearchCount = ISNULL(SUM(u.SearchCount),0)
		,TurnAwayCount = ISNULL(SUM(u.TurnAwayCount),0) --27/11/21	James	SIR5374 - Add TurnAwayCount
	FROM PEPUsageSummary u
	WHERE u.Month BETWEEN @StartMonth AND @EndMonth 
	AND u.ReportingParentSubscriberId = @ReportingParentSubscriberId
	GROUP BY
		ReportingParentSubscriberName
		,ReportingParentSubscriberId
		,ReportingParentType
		,UserName
		,UserFullName
--		,DateDay
		,Year
		,Quarter
		,Month
		,OrderNumber
		,UserCountry
		,LoggedInMethod
		,DocumentId
		,documentRef
		,PEPCode
		,DocumentVolume
		,DocumentYear
		,authorMast
		,ArchiveOrCurrent--16/3/22	James Woosnam	SIR5457 - Add ArchiveOrCurrent
	ORDER BY 
		ReportingParentSubscriberName 
		,UserFullName 
END
--26/6/22    James Woosnam   SIR5487 - PEPUsageReadsFromJan2020ByReportingParent added
IF @ViewType = 'ReadsFromJan2020ByReportingParent'
BEGIN
	IF @ReportingParentSubscriberId IS NULL 
	BEGIN
		SELECT @Message ='ViewType:' + @ViewType + ' requires @ReportingParentSubscriberId'
		RAISERROR ('%s', 18, 1,@Message)
	END
	SELECT
		Year = LEFT(u.MonthStart ,4)
		,Month = u.MonthStart
		,MonthStartDate = CAST('01-' + RIGHT(u.MonthStart,3) + LEFT(u.MonthStart,4) as DATETIME)
		,u.ReportingParentSubscriberName 
		,u.ReportingParentSubscriberId
		,u.Source 
		,u.DataType 
		,u.ArchiveOrCurrent 
		,u.Journal 
		,u.Title 
		,u.document_id 

		,TotalHits = SUM(u.TotalHits  )
	FROM UsageByMonthDocument u
	WHERE u.ReportingParentSubscriberId = @ReportingParentSubscriberId
	AND u.MonthStart BETWEEN @StartMonth AND @EndMonth 
	GROUP BY
		u.Source 
		,u.ReportingParentSubscriberName 
		,u.ReportingParentSubscriberId
		,u.MonthStart 
		,u.DataType 
		,u.ArchiveOrCurrent 
		,u.Journal 
		,u.Title 
		,u.document_id 
END
IF @ViewType = 'AuthorStats'
BEGIN
--15/8/22    James Woosnam   SIR5532 - Add AuthorStats
	SELECT
		Year = LEFT(u.MonthStart ,4)
		,Month = u.MonthStart
		,MonthStartDate = CAST('01-' + RIGHT(u.MonthStart,3) + LEFT(u.MonthStart,4) as DATETIME)
		,u.Source 
		,u.DataType 
		,Author = ISNULL(a.Authorname  ,d.authorMast )
		,IsLiving = CASE WHEN a.IsLiving= 1 THEN 'Y' ELSE 'N' END
		,AuthorFirstPublishedYear = (SELECT MIN(d2.year ) FROM DocumentAuthor da2 INNER JOIN ContentDocuments d2 ON d2.documentId = da2.DocumentId WHERE da2.AuthorId = min(a.AuthorId) )
		,u.Source 
		,da.NoOfAuthors 
		,PrimaryAuthorReads = SUM(case when da.IsPrimaryAuthor=1 then u.TotalHits else 0 end )
		,ProportionedReads = SUM(u.TotalHits  )/CAST(da.NoOfAuthors  as MONEY)
	FROM UsageByMonthDocument u
		LEFT JOIN ContentDocuments d
		ON d.documentID = u.document_id 
		INNER JOIN DocumentAuthor da
			INNER JOIN Author a
			ON a.Authorid = da.AuthorId 
		ON da.DocumentId = u.document_id 
	WHERE u.ReportingParentSubscriberId <>0
	AND u.TotalHits <>0
	AND u.MonthStart BETWEEN @StartMonth AND @EndMonth 
	GROUP BY
		ISNULL(a.Authorname  ,d.authorMast )
		,a.IsLiving
		,u.MonthStart 
		,u.DataType 
		,u.Source 
		,da.NoOfAuthors 
END
GO
GRANT  EXECUTE ON sp457GetPEPUsageView TO PaDSSQLServerUser

--EXEC sp457GetPEPUsageView @ViewType = 'SummaryByReportingParent'
--EXEC sp457GetPEPUsageView @ViewType = 'DetailByReportingParent'
--EXEC sp457GetPEPUsageView @ViewType = 'SingleReportingParentDetail'	,@ReportingParentSubscriberId=49337