/*
31/10/23	SIR5706
DataUpdate: once these changes have been released, and RepopulateAllPEPWebContent has been successfully run, check publisher has been populated against most records in 3 content tables above. If all ok run D:\Projects\PaDS2\PaDS\BusinessLogic\SQL\Scripts\SIR5706 - Update UserActionLog with publisher.sql
This could take a while
*/
UPDATE UserActionLog 
SET publisher = ISNULL(c.publisher ,b.publisher)
	,Publisher_ID = LEFT(dbo.fn021RemoveNonAlphanumericCharacters(ISNULL(c.publisher ,b.publisher)),50)
FROM useractionlog l
		LEFT JOIN ContentDocuments d
			LEFT JOIN (
				SELECT j.PEPCode 
					,j.publisher
				FROM ContentJournals j
				UNION
				SELECT v.PEPCode 
					,v.publisher 
				FROM ContentVideos v
				) c
			ON c.PEPCode = d.PEPCode 
		ON d.documentID = l.ItemId  
		LEFT JOIN (
			SELECT b.PEPCode 
				,b.publisher 
				,b.Title 
				,b.documentID
			FROM ContentBooks b
			) b
	on b.documentID = l.ItemId   
	or replace(l.ItemId ,'.','') like b.PEPCode + '%'



