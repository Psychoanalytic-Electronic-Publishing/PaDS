begin tran
DECLARE @ObfuscateNotDelete BIT = NULL 
				,@ReturnMessage VARCHAR(MAX) = '' 
				,@subId int =0
SET @subId= 500022;select * from Subscriber where SubscriberId = @subId;exec sp119DeleteOrObfuscateSubscriber @SubscriberId=@subId,@RunMode='test',@RunByUserId=1,@ObfuscateNotDelete =@ObfuscateNotDelete OUTPUT,@ReturnMessage=@ReturnMessage OUTPUT ; select @ObfuscateNotDelete, @ReturnMessage exec sp119DeleteOrObfuscateSubscriber @SubscriberId=@subId,@RunMode='delete',@RunByUserId=1,@ObfuscateNotDelete =@ObfuscateNotDelete OUTPUT,@ReturnMessage=@ReturnMessage OUTPUT ; select @ObfuscateNotDelete, @ReturnMessage ;select * from Subscriber where SubscriberId = @subId
rollback tran