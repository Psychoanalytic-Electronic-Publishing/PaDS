IF  exists (select * from dbo.sysobjects where id = object_id(N'sp602CorrectStoredUsageAndUserActivityData') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp602CorrectStoredUsageAndUserActivityData
GO
CREATE  PROCEDURE sp602CorrectStoredUsageAndUserActivityData (
		@BatchLogId INT = NULL
)
AS
--5/6/24	James Woosnam	SIR5746 - Rework to remove subquery and split into smaller updates
DECLARE @Msg VARCHAR(MAX) =''
DECLARE @SQL VARCHAR(MAX) = ''
DECLARE @DBName varchar(100)=''
--Initilly we did need to update using last record to fix any historical problems when an artical is no longer on PEP but is in the usage logs.  
--Going forward this should not be needed.
DECLARE @UpdateUsingLastRecord BIT = 0 
DECLARE @RowCount INT =0
BEGIN TRY
----3/6/24		James Woosnam	SP Skipped
--	EXEC sp029UpdateBatchLog @BatchLogId, '*****sp602CorrectStoredUsageAndUserActivityData SKIPPED until "The transaction log for database ''tempdb'' is full due to ''ACTIVE_TRANSACTION''" error resolved.'
--	RETURN
	EXEC sp029UpdateBatchLog @BatchLogId, ' CorrectStoredUsageAndUserActivityData SQL Started'

	IF @UpdateUsingLastRecord=1
	BEGIN
		IF EXISTS(SELECT * FROM [PaDSTempAndArchive].dbo.sysobjects WHERE Type='U' and NAME = 'AllItemsForsp602') 
		BEGIN
			DROP TABLE [PaDSTempAndArchive].dbo.AllItemsForsp602
			SET @RowCount=@@ROWCOUNT;SET @Msg = '[PaDSTempAndArchive].dbo.AllItemsForsp602 table dropped';EXEC sp029UpdateBatchLog @BatchLogId, @Msg
		END
		SELECT DISTINCT
			l.ItemId 
			,l.ItemName
			,l.TitleId 
			,l.TitleName 
		INTO [PaDSTempAndArchive].dbo.AllItemsForsp602
		FROM UserActionLog  l
		WHERE l.DateTime = (SELECT MAX(l2.DateTime) FROM UserActionLog l2 WHERE l2.ItemId = l.ItemId AND l2.TitleId = l.TitleId)
		SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' rows inserted into [PaDSTempAndArchive].dbo.AllItemsForsp602';EXEC sp029UpdateBatchLog @BatchLogId, @Msg
	END

	DECLARE cur CURSOR FOR
	SELECT name
	FROM master.dbo.sysdatabases
	Where Name like 'PaDS_Logs_UserAction%'
	ORDER BY 1
	Open cur 
	FETCH cur INTO @DBName
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		DECLARE @MonthNo INT = 1
		WHILE @MonthNo <=12
		BEGIN
			SET @SQL = '
			UPDATE [' + @DBName +'].dbo.UserActionLog 
			SET ItemName = d.documentRef 
			FROM [' + @DBName +'].dbo.UserActionLog l
				inner join ContentDocuments d
				ON d.documentID = l.ItemId 
			where l.ItemName <> d.documentRef 
			AND MONTH(l.MonthStartDate) = ' + CAST(@MonthNo AS VARCHAR)
			EXECUTE(@SQL)
			SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' UserActionLog rows from ContentDocuments in ' + @DBName+ ' Month:' + FORMAT(@MonthNo,'00');EXEC sp029UpdateBatchLog @BatchLogId, @Msg
		
			IF @UpdateUsingLastRecord=1
			BEGIN
				SET @SQL = '
					UPDATE [' + @DBName +'].dbo.UserActionLog 
					SET ItemName = lm.ItemName 
					from [' + @DBName +'].dbo.UserActionLog  l
						INNER JOIN [PaDSTempAndArchive].dbo.AllItemsForsp602 lm
						ON lm.ItemId = l.ItemId 
						AND lm.TitleId = l.TitleId 
					WHERE l.ItemName <> lm.ItemName 
					AND MONTH(l.MonthStartDate) = ' + CAST(@MonthNo AS VARCHAR) 
					EXECUTE(@SQL)
					SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' UserActionLog rows from Last Record in ' + @DBName+ ' Month:' + FORMAT(@MonthNo,'00');EXEC sp029UpdateBatchLog @BatchLogId, @Msg
			END
			SET @MonthNo += 1		
		END
		FETCH cur INTO @DBName
	END
	CLOSE cur 
	DEALLOCATE cur 

	UPDATE PEPUsage
	SET documentRef = d.documentRef 
	FROM PEPUsage l
		inner join ContentDocuments d
		ON d.documentID = l.DocumentId 
	where l.documentRef  <> d.documentRef
	SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' PEPUsage rows from ContentDocuments';EXEC sp029UpdateBatchLog @BatchLogId, @Msg
	IF @UpdateUsingLastRecord=1
	BEGIN
		UPDATE PEPUsage 
		SET documentRef  = lm.documentRef  
		from pepusage  l
			INNER JOIN (
				select
				l.DocumentId 
				,l.documentRef
				from pepusage  l
				WHERE l.DateTime = (SELECT MAX(l2.DateTime) FROM PEPUsage l2 WHERE l2.DocumentId = l.DocumentId  )
				) lm
			ON lm.documentID = l.DocumentId 
		where l.documentRef  <> lm.documentRef
		SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' PEPUsage rows from Last Record';EXEC sp029UpdateBatchLog @BatchLogId, @Msg
	END

	UPDATE PEPUsageSummary  
	SET documentRef = d.documentRef 
	FROM PEPUsageSummary l
		inner join ContentDocuments d
		ON d.documentID = l.DocumentId 
	where l.documentRef  <> d.documentRef
	SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' PEPUsageSummary rows from ContentDocuments';EXEC sp029UpdateBatchLog @BatchLogId, @Msg
	IF @UpdateUsingLastRecord=1
	BEGIN
		UPDATE PEPUsageSummary 
		SET documentRef  = lm.documentRef  
		from PEPUsageSummary  l
			INNER JOIN (
				select
				l.DocumentId 
				,l.documentRef
				from PEPUsageSummary  l
				WHERE l.MonthStartDate  = (SELECT MAX(l2.MonthStartDate) FROM PEPUsageSummary l2 WHERE l2.DocumentId = l.DocumentId  )
				) lm
			ON lm.documentID = l.DocumentId 
		where l.documentRef  <> lm.documentRef
		SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' PEPUsageSummary rows from Last Record';EXEC sp029UpdateBatchLog @BatchLogId, @Msg
	END

	UPDATE UsageByMonthDocument   
	SET Title  = d.documentRef 
	FROM UsageByMonthDocument l
		inner join ContentDocuments d
		ON d.documentID = l.document_id 
	where l.Title  <> d.documentRef
	SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' UsageByMonthDocument rows from ContentDocuments';EXEC sp029UpdateBatchLog @BatchLogId, @Msg

	IF @UpdateUsingLastRecord=1
	BEGIN
		UPDATE UsageByMonthDocument 
		SET Title  = lm.Title  
		from UsageByMonthDocument  l
			INNER JOIN (
				select
				l.document_id 
				,l.Title
				from UsageByMonthDocument  l
				WHERE l.MonthStart   = (SELECT MAX(l2.MonthStart) FROM UsageByMonthDocument l2 WHERE l2.document_id = l.document_id  )
				) lm
			ON lm.document_id = l.document_id 
		where l.Title  <> lm.Title
		SET @RowCount=@@ROWCOUNT;SET @Msg = CONVERT(VARCHAR,@RowCount) + ' UsageByMonthDocument rows from Last Record';EXEC sp029UpdateBatchLog @BatchLogId, @Msg
	END
END TRY
BEGIN CATCH
	SELECT @Msg ='sp602CorrectStoredUsageAndUserActivityData Failed:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE() ;EXEC sp029UpdateBatchLog @BatchLogId, @Msg
	RAISERROR ('%s', 18, 1,@Msg)
END CATCH	
GO
GRANT EXECUTE ON sp602CorrectStoredUsageAndUserActivityData to PaDSSQLServerUser
