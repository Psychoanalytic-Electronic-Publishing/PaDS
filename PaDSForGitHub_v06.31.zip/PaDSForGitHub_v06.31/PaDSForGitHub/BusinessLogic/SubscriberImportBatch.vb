﻿'Updates
'======
'Oct 2019       James Woosnam   SIR4571 - Initial Version
'17/12/12   JamesWoosnam    SIR4979/2 - Warning if user but no password
'18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
'4/1/21 James Woosnam   SIR5095 - Check for duplicate username and email in file
'4/1/21 Julian Gates    SIR5157 - Add extra validation to warn user if any columns exist but are not populated
'5/1/21     James Woosnam   SIR5133 - If there are some tmp rows for this import enurse the order number is updated
'10/02/21   Julian Gates    SIR5157 - Add try catch to stop process failing when more than 178 columns.
'14/10/21   James Woosnam   SIR5342 - Move subscriber import code to SubscriberImportBatch so import can be submitted and run as a batch job
'13/1/22    james Woosnam   SIR5388 - EmailOpt Out column no longer handled soo remove validation
'18/5/23    Julian Gates    SIR5641 - Add PhoneNumberForCourier to import.
'26/10/23   James Woosnam   SIR5707 - Remove Status='Error' for update below

Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class SubscriberImportBatch
#Region "Class Properties"

    Public MainDataset As New DataSet
    Dim _SubscriberImportBatchId As Integer = Nothing
    Dim UserSession As UserSession
    Public AuthorisationRejectMsg As String = ""

    Public Property SubscriberImportBatchId() As Integer
        Get
            If Me._SubscriberImportBatchId = Nothing Then
                If Me.MainDataset.Tables.Count <> 0 Then
                    Me._SubscriberImportBatchId = Me.SubscriberImportBatchRow("SubscriberImportBatchId")
                End If
            End If
            Return Me._SubscriberImportBatchId
        End Get
        Set(ByVal Value As Integer)
            _SubscriberImportBatchId = Value
            'initilise dataset
            'Me.Initilise()
        End Set
    End Property
    Public Enum SubscriberImportBatchStates
        Initial
        Available 'the renewal file has been created
        Downloaded 'block user has downloaded the file
        Uploading 'The block user is in the proces of uploading and validating the file
        Uploaded 'The block user has successfully uploaded their file
        Importing 'The file has been imported and is being reviewed
        Imported 'the file has been successfully imported into PaDS to create an order.
        Rejected
    End Enum
    Enum SubscriberImportBatchFileTypes
        Renewal = 1
        Uploaded = 2
        BeforeImport = 3
        AfterImport = 4
        Confirmation = 5
    End Enum

    Public Property SubscriberImportBatchStatus() As SubscriberImportBatchStates
        Get
            Return [Enum].Parse(GetType(SubscriberImportBatchStates), Me.SubscriberImportBatchRow("SubscriberImportBatchStatus"))
        End Get
        Set(ByVal value As SubscriberImportBatchStates)
            Me.SubscriberImportBatchRow("SubscriberImportBatchStatus") = value.ToString
        End Set
    End Property


    Public ReadOnly Property SubscriberImportBatch() As DataTable
        Get
            If Me.MainDataset.Tables("SubscriberImportBatch") Is Nothing Then
                Me.daSubscriberImportBatch.Fill(Me.MainDataset, "SubscriberImportBatch")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("SubscriberImportBatch").Columns("SubscriberImportBatchId")}
            Me.MainDataset.Tables("SubscriberImportBatch").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("SubscriberImportBatch")
        End Get
    End Property
    Private _daSubscriberImportBatch As SqlDataAdapter
    Private ReadOnly Property daSubscriberImportBatch() As SqlDataAdapter
        Get
            If Me._daSubscriberImportBatch Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM SubscriberImportBatch"
                sql += " WHERE SubscriberImportBatchId=" & Me.SubscriberImportBatchId
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daSubscriberImportBatch = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daSubscriberImportBatch)
                _daSubscriberImportBatch.UpdateCommand = cmdBld.GetUpdateCommand()
                _daSubscriberImportBatch.InsertCommand = cmdBld.GetInsertCommand()
                _daSubscriberImportBatch.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daSubscriberImportBatch.InsertCommand.Transaction = Me.db.DBTransaction
                _daSubscriberImportBatch.UpdateCommand.Transaction = Me.db.DBTransaction
                _daSubscriberImportBatch.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daSubscriberImportBatch
        End Get
    End Property
    Public ReadOnly Property SubscriberImportBatchRow() As DataRow
        Get
            If Me.SubscriberImportBatch.Rows.Count = 0 Then
                Me.daSubscriberImportBatch.Fill(Me.MainDataset.Tables("SubscriberImportBatch"))
                If Me.SubscriberImportBatch.Rows.Count = 0 Then
                    Throw New Exception("UserError: SubscriberImportBatchId:" & Me.SubscriberImportBatchId & " can't be found")
                End If
            End If
            Return Me.SubscriberImportBatch.Rows(0)
        End Get
    End Property
    Public ReadOnly Property SubscriberImportBatchLog() As DataTable
        Get
            If Me.MainDataset.Tables("SubscriberImportBatchLog") Is Nothing Then
                Me.daSubscriberImportBatchLog.Fill(Me.MainDataset, "SubscriberImportBatchLog")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("SubscriberImportBatchLog").Columns("SubscriberImportBatchLogId")}
            Me.MainDataset.Tables("SubscriberImportBatchLog").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("SubscriberImportBatchLog")
        End Get
    End Property
    Private _daSubscriberImportBatchLog As SqlDataAdapter
    Private ReadOnly Property daSubscriberImportBatchLog() As SqlDataAdapter
        Get
            If Me._daSubscriberImportBatchLog Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM SubscriberImportBatchLog"
                sql += " WHERE SubscriberImportBatchId=" & Me.SubscriberImportBatchId
                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                _daSubscriberImportBatchLog = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daSubscriberImportBatchLog)
                _daSubscriberImportBatchLog.UpdateCommand = cmdBld.GetUpdateCommand()
                _daSubscriberImportBatchLog.InsertCommand = cmdBld.GetInsertCommand()
                _daSubscriberImportBatchLog.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daSubscriberImportBatchLog.InsertCommand.Transaction = Me.db.DBTransaction
                _daSubscriberImportBatchLog.UpdateCommand.Transaction = Me.db.DBTransaction
                _daSubscriberImportBatchLog.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daSubscriberImportBatchLog
        End Get
    End Property

    Private Sub Initilise()
        Dim xx As Integer = 0
        Me.MainDataset = New DataSet
        Me._daSubscriberImportBatch = Nothing
        Me._daSubscriberImportBatchLog = Nothing
        xx = Me.SubscriberImportBatch.Rows.Count
        xx = Me.SubscriberImportBatchLog.Rows.Count

    End Sub
    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)

            Me._db = value
        End Set
    End Property
    Public Property ErrorMessages() As String
        Get
            If Me.SubscriberImportBatchRow IsNot Nothing Then
                Return Me.db.IsDBNull(Me.SubscriberImportBatchRow("ErrorMessages"), "")
            Else
                Return ""
            End If
        End Get
        Set(ByVal value As String)
            Me.SubscriberImportBatchRow("ErrorMessages") = value
        End Set
    End Property
    Public Property WarningMessages() As String
        Get
            If Me.SubscriberImportBatchRow IsNot Nothing Then
                Return db.IsDBNull(Me.SubscriberImportBatchRow("WarningMessages"), "")
            Else
                Return ""
            End If
        End Get
        Set(ByVal value As String)
            Me.SubscriberImportBatchRow("WarningMessages") = value
        End Set
    End Property
#End Region
    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.SubscriberImportBatchId = 0
        Me.UserSession = UserSession
        'Me._CalledBySubscriberImportBatchId = _CalledBySubscriberImportBatchId
    End Sub
    Sub New(ByVal SubscriberImportBatchId As Integer, ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.SubscriberImportBatchId = SubscriberImportBatchId
        Me.UserSession = UserSession
        Me.Initilise()
    End Sub
    Sub New(ByVal db As BusinessLogic.Database)
        Me.db = db
    End Sub
    Public Sub Save()
        Dim sql As String = ""
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            If Me.MainDataset.Tables("SubscriberImportBatchLog") IsNot Nothing Then Me.daSubscriberImportBatchLog.Update(Me.MainDataset, "SubscriberImportBatchLog")
            '18/08/20   Julian Gates    SIR5099 - Only update last Updated fields if record modified
            Select Case Me.SubscriberImportBatchRow.RowState
                Case DataRowState.Added, DataRowState.Modified
                    SubscriberImportBatchRow("LastUpdatedDateTime") = Now()
                    SubscriberImportBatchRow("LastUpdatedByUserId") = UserSession.UserName20
            End Select
            '5/1/21     James Woosnam   SIR5133 - If there are some tmp rows for this import enurse the order number is updated
            If db.IsDBNull(db.DLookup("MAX(OrderNumber)", "tmpSubscriberImport", "SubscriberImportBatchId=" & Me.SubscriberImportBatchId), 0) <> db.IsDBNull(Me.SubscriberImportBatchRow("OrderNumber"), 0) Then
                db.ExecuteSQL("UPDATE tmpSubscriberImport SET OrderNumber=" & db.IsDBNull(Me.SubscriberImportBatchRow("OrderNumber"), "NULL") & " WHERE SubscriberImportBatchId=" & Me.SubscriberImportBatchId)
            End If
            Me.daSubscriberImportBatch.Update(Me.MainDataset, "SubscriberImportBatch")

            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try

    End Sub

    Public Sub AddNew(ByVal BlockSubscriberId As Integer,
                                  ByVal CompanyId As Integer,
                               ByVal SubscriberImportBatchName As String
                               )

        db.BeginTran()
        Try
            Dim row As DataRow = Me.SubscriberImportBatch.NewRow
            row("SubscriberImportBatchId") = db.GetNextNumber("SubscriberImportBatch")
            If db.DLookup("SubscriberImportBatchName", "SubscriberImportBatch", "BlockSubscriberId=" & BlockSubscriberId & " AND SubscriberImportBatchStatus<>'Rejected' AND SubscriberImportBatchName='" & SubscriberImportBatchName.Replace("'", "''") & "'") IsNot Nothing Then
                Throw New Exception("Import Batch Name:" & SubscriberImportBatchName & " already exists for this group subscriber.")
            End If
            row("SubscriberImportBatchName") = Left(SubscriberImportBatchName, 50)
            row("SubscriberImportBatchStatus") = SubscriberImportBatchStates.Initial.ToString
            row("BlockSubscriberId") = BlockSubscriberId
            row("CompanyId") = CompanyId
            Me.SubscriberImportBatch.Rows.Add(row)
            Me.WriteLog("Import Batch Created")
            Me.Save()
            Me.SubscriberImportBatchId = row("SubscriberImportBatchId")
            Me.Initilise()
            db.CommitTran()
        Catch ex As Exception
            db.RollbackTran()
            Throw New Exception("UserError: Add SubscriberImportBatch failed:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub AddFile(FileType As SubscriberImportBatchFileTypes, FileByteArray As Byte(), FileName As String)
        db.BeginTran()
        Try
            If FileByteArray IsNot Nothing Then
                Dim FileStore As New FileStore(db)
                FileStore.AddNewFile(FileByteArray, FileName & ".xlsx", "SubscriberImportBatch.UpdateStatus")
                Me.SubscriberImportBatchRow(FileType.ToString & "FileStoreId") = FileStore.FileStoreId
                Me.WriteLog("New " & FileType.ToString & " added", FileStore.FileStoreId)
            End If

            Me.Save()
            db.CommitTran()
        Catch ex As Exception
            db.RollbackTran()
            Throw New Exception("UserError: Add SubscriberImportBatch failed", ex)
        End Try
    End Sub


    Public Sub UpdateStatus(NewStatus As SubscriberImportBatchStates, FileByteArray As Byte(), FileName As String)
        Dim tranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            db.BeginTran()
            tranStartedHere = True
        End If
        Try

            Me.SubscriberImportBatchRow("SubscriberImportBatchStatus") = NewStatus.ToString
            If FileByteArray IsNot Nothing Then
                Dim FileStore As New FileStore(db)

                FileStore.AddNewFile(FileByteArray, FileName & ".xlsx", "SubscriberImportBatch.UpdateStatus")
                Select Case NewStatus
                    Case SubscriberImportBatchStates.Available
                        Me.SubscriberImportBatchRow("RenewalFileStoreId") = FileStore.FileStoreId
                    Case SubscriberImportBatchStates.Uploading
                        Me.SubscriberImportBatchRow("UploadedFileStoreId") = FileStore.FileStoreId
                        Me.ErrorMessages = Nothing
                        Me.WarningMessages = Nothing
                    Case SubscriberImportBatchStates.Importing
                        Me.SubscriberImportBatchRow("BeforeImportFileStoreId") = FileStore.FileStoreId
                    Case SubscriberImportBatchStates.Imported
                        Me.SubscriberImportBatchRow("AfterImportFileStoreId") = FileStore.FileStoreId
                End Select
                Me.WriteLog("Status set to:" & NewStatus.ToString & " File:" & FileName & " added.", FileStore.FileStoreId)
            Else
                Me.WriteLog("Status set to:" & NewStatus.ToString)
            End If
            Select Case NewStatus
                Case SubscriberImportBatchStates.Uploading
                    'set to uploading when 
                    Me.ErrorMessages = Nothing
                    Me.WarningMessages = Nothing
            End Select
            Me.Save()
            If tranStartedHere Then db.CommitTran()
        Catch ex As Exception
            If tranStartedHere Then db.RollbackTran()
            Throw New Exception("UserError: Add SubscriberImportBatch failed", ex)
        End Try
    End Sub
    Public Sub WriteLog(Description As String, Optional FileStoreId As Integer = 0)
        Dim tranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            db.BeginTran()
            tranStartedHere = True
        End If
        Try
            Dim row As DataRow = Me.SubscriberImportBatchLog.NewRow
            row("SubscriberImportBatchLogId") = db.GetNextNumber("SubscriberImportBatchLog")
            row("SubscriberImportBatchId") = Me.SubscriberImportBatchId
            row("SubscriberImportBatchStatusAtLog") = SubscriberImportBatchStatus.ToString
            row("UserId") = Me.UserSession.UserId
            row("UserName") = Me.UserSession.UserName
            row("Description") = Left(Description, 200)
            row("LogDateTime") = Now
            If FileStoreId <> 0 Then row("FileStoreId") = FileStoreId
            Me.SubscriberImportBatchLog.Rows.Add(row)

            Me.Save()
            If tranStartedHere Then db.CommitTran()
        Catch ex As Exception
            If tranStartedHere Then db.RollbackTran()
            Throw New Exception("UserError: Add SubscriberImportBatch failed", ex)
        End Try
    End Sub
    Dim _FileColsDict As Dictionary(Of String, Integer) = Nothing
    Private ReadOnly Property FileColsDic As Dictionary(Of String, Integer)
        Get
            If _FileColsDict Is Nothing Then
                '2/3/23   JamesWoosnam    SIR5561 - remove webuserpassword
                '18/5/23  Julian Gates    SIR5641 - Add phonenumberforcourier
                Dim filecolsarray() As String = {"affiliatereferenceid", "parentsubscribername", "subscribercategory", "firstname", "lastname", "address1", "address2", "address3", "address4", "city", "state", "postcode", "countryname", "emailaddress", "emailoptout", "webusername", "printedcopy", "notes", "phonenumberforcourier"}
                _FileColsDict = New Dictionary(Of String, Integer)
                For Each col As String In filecolsarray
                    _FileColsDict.Add(col, 0)
                Next
            End If
            Return _FileColsDict
        End Get
    End Property
    Dim tImportSubs As DataTable = Nothing
    Dim EmailsAddresses As New ArrayList()
    Dim UserNames As New ArrayList()
    Public Sub ValidateFile(FileStore As FileStore)

        Try
            Me.ErrorMessages = Nothing
            Me.WarningMessages = Nothing


            Dim fi As New IO.FileInfo(FileStore.OriginalFileName)
            If fi.Extension.ToLower <> ".xlsx" Then
                AddGeneralMessage(MessageTypes.ErrorMessage, "Only files with a .xlsx extension can be loaded")
            End If
            Dim workbookSet As SpreadsheetGear.IWorkbookSet = SpreadsheetGear.Factory.GetWorkbookSet()
            Dim wb As SpreadsheetGear.IWorkbook = Nothing
            Try
                wb = workbookSet.Workbooks.OpenFromMemory(FileStore.FileBytes)

            Catch ex1 As Exception
                AddGeneralMessage(MessageTypes.ErrorMessage, "Opening file as a spreadsheet failed:" & ex1.Message)
                Exit Sub
            End Try
            Dim ws As SpreadsheetGear.IWorksheet = Nothing
            Select Case wb.Worksheets.Count
                Case 0
                Case 1
                    ws = wb.Worksheets(0)
                Case Else
                    For Each wsTest As SpreadsheetGear.IWorksheet In wb.Worksheets
                        If wsTest.Name.ToLower = "data" Then
                            ws = wsTest
                        End If
                    Next
            End Select
            If ws Is Nothing Then
                AddGeneralMessage(MessageTypes.ErrorMessage, "There are " & wb.Worksheets.Count & " worksheets in this file.  There needs to be 1 worksheet.")
                Exit Sub
            End If
            If ws.UsedRange.RowCount < 2 Then
                AddGeneralMessage(MessageTypes.ErrorMessage, "The worksheet must have more than 1 row")
                Exit Sub
            End If

            Dim rng As SpreadsheetGear.IRange = wb.Worksheets(0).Cells(0, 0, ws.UsedRange.RowCount - 1, ws.UsedRange.ColumnCount - 1)
            tImportSubs = rng.GetDataTable(SpreadsheetGear.Data.GetDataFlags.NoColumnTypes)

            For Each col As DataColumn In tImportSubs.Columns
                Dim colName As String = col.ColumnName.Trim
                If FileColsDic.ContainsKey(colName.ToLower) Then
                    FileColsDic(colName.ToLower) = 1
                Else
                    '10/02/21   Julian Gates    SIR5157 - Add try catch to stop process failing when more than 178 columns.
                    Try
                        '4/1/21 Julian Gates    SIR5157 - Add extra validation to warn user if any columns exist but are not populated
                        If Left(colName, 6) = "Column" Then
                            AddGeneralMessage(MessageTypes.WarningMessage, "Column:" & Chr(col.Ordinal + 65) & " exists but is not populated and will be ignored")
                        Else
                            AddGeneralMessage(MessageTypes.ErrorMessage, "Column:" & Chr(col.Ordinal + 65) & " Heading:'" & colName & "'  is not expected")
                        End If
                    Catch ex As Exception
                        'After 178 empty columns it causes a error and this catch stops the process failing
                    End Try
                End If
            Next
            Dim missingCols As String = ""
            For Each kvp As KeyValuePair(Of String, Integer) In FileColsDic
                If kvp.Value = 0 Then
                    '2/3/23   JamesWoosnam    SIR5561 - If WebUserName col found add warning
                    '18/5/23  Julian Gates    SIR5641 - Add PhoneNumberForCourier as optional column
                    Select Case kvp.Key
                        Case "ParentSubscriberName".ToLower, "EmailOptOut".ToLower, "printedcopy", "notes", "WebUserName".ToLower, "PhoneNumberForCourier".ToLower  'Optional Columns
                        Case Else
                            missingCols += IIf(missingCols = "", "", ",") & "'" & kvp.Key & "'"
                    End Select
                Else
                    Select Case kvp.Key
                        Case "WebUserName".ToLower
                            AddGeneralMessage(MessageTypes.WarningMessage, "Column WebUserName is present but is no longer used and will be ignored. Email now used for UserName.")
                    End Select
                End If
            Next
            If missingCols <> "" Then
                AddGeneralMessage(MessageTypes.ErrorMessage, "Columns:" & missingCols & " were not found")
            End If
            If ErrorMessages <> "" Then
                AddGeneralMessage(MessageTypes.ErrorMessage, "Deleting or moving columns in PaDS Excel file is not permitted.  Please Download PaDS Excel file again, enter changes, and resubmit.")
                Exit Sub
            End If
            '13/1/22    james Woosnam   SIR5388 - EmailOpt Out column no longer handled so give warnig
            If tImportSubs.Columns.Contains("EmailOptOut") Then
                AddGeneralMessage(MessageTypes.WarningMessage, "The column EmailOptOut is included in the file but is now no longer used as emails are only sent for essential operational purposes.")

            End If
            FileRowNo = 2
            For Each row As DataRow In tImportSubs.Rows
                If db.IsDBNull(row("FirstName"), "").ToString.Trim = "" And db.IsDBNull(row("LastName"), "").ToString.Trim = "" Then
                    If FileRowNo = 2 Then
                        Me.AddRowMessage(MessageTypes.ErrorMessage, "First and Last name are blank.  It looks like the file is empty.")
                    Else
                        Me.AddRowMessage(MessageTypes.WarningMessage, "First and Last name are blank. Row ignored.")
                    End If
                Else
                    For Each col As DataColumn In tImportSubs.Columns

                        Select Case col.ColumnName.Trim.ToLower

                            Case "AffiliateReferenceID".ToLower
                                CheckCellLength(col, 50)
                            Case "SubscriberCategory".ToLower
                                CheckCellManadatory(col)
                                Dim subCat As String = db.IsDBNull(row(col.ColumnName), "")

                                If subCat <> "" Then
                                    Dim sql As String = ""
                                    sql = "SELECT LookupItemKey"
                                    sql += " , Name"
                                    sql += " FROM Lookup "
                                    sql += " WHERE LookupName='SubscriberCategory'"
                                    sql += " AND CompanyId = " & Me.SubscriberImportBatchRow("CompanyId")
                                    sql += " AND LookupStatus = 'Active'"
                                    sql += " ORDER BY Name"
                                    Dim tbl As DataTable = db.GetDataTableFromSQL(sql)
                                    Dim IsMacthed As Boolean = False
                                    Dim allCats As String = ""
                                    For Each rowLk As DataRow In tbl.Rows
                                        If rowLk("Name") = subCat Then
                                            IsMacthed = True
                                            Exit For
                                        End If
                                        allCats += IIf(allCats = "", "", ", ") & rowLk("Name")
                                    Next
                                    If Not IsMacthed Then Me.AddCellMessage(MessageTypes.ErrorMessage, col.Ordinal, col.ColumnName & ":'" & subCat & "' is invalid.  It must be one of:" & allCats)
                                End If
                            Case "FirstName".ToLower
                                CheckCellManadatory(col)
                                CheckCellLength(col, 25)
                            Case "LastName".ToLower
                                CheckCellManadatory(col)
                                CheckCellLength(col, 50)
                            Case "Address1".ToLower
                                CheckCellManadatory(col)
                                CheckCellLength(col, 50)
                            Case "Address2".ToLower
                                CheckCellLength(col, 50)
                            Case "Address3".ToLower
                                CheckCellLength(col, 50)
                            Case "Address4".ToLower
                                CheckCellLength(col, 50)
                            Case "City".ToLower
                                CheckCellManadatory(col)
                                CheckCellLength(col, 50)
                            Case "State".ToLower
                                CheckCellLength(col, 50)
                            Case "PostCode".ToLower
                                CheckCellManadatory(col)
                                CheckCellLength(col, 15)
                            Case "CountryName".ToLower
                                CheckCellManadatory(col)
                                CheckCellLength(col, 50)
                            Case "EmailAddress".ToLower
                                CheckCellManadatory(col)
                                CheckCellLength(col, 200)
                                Dim email As String = db.IsDBNull(row(col.ColumnName), "")
                                If email <> "" Then
                                    If Not New StdCode().IsValidEmail(email) Then
                                        Me.AddCellMessage(MessageTypes.WarningMessage, col.Ordinal, col.ColumnName & ":" & email & " does not look like a valid email address.  Please double check.")
                                    End If
                                    '4/1/20 James Woosnam   SOR5095 - Check for duplicate username and email in file
                                    If EmailsAddresses.Contains(email.ToLower) Then
                                        Me.AddCellMessage(MessageTypes.ErrorMessage, col.Ordinal, "Email Address:" & email & " is used more than once in the file.")
                                    Else
                                        EmailsAddresses.Add(email.ToLower)
                                    End If
                                End If

                            Case "EmailOptOut".ToLower
                                '13/1/22    james Woosnam   SIR5388 - EmailOpt Out column no longer handled soo remove validation

                            Case "PrintedCopy".ToLower
                                '26/11/19   James Woosnam   SIR4960 validate PrintedCopy, if blank defaulted to Y in sp483SubscriberImport
                                Select Case db.IsDBNull(row(col.ColumnName), "").ToString.ToLower
                                    Case "y", "n", ""
                                    Case Else
                                        Me.AddCellMessage(MessageTypes.ErrorMessage, col.Ordinal, col.ColumnName & " must be Y or N")
                                End Select
                        End Select
                    Next

                End If

                FileRowNo += 1
            Next
        Catch ex As Exception
            Throw New Exception("UploadRenewalFile failed:" & ex.Message)
        Finally
            Me.Save()
            Me.WriteLog("File validation run.", FileStore.FileStoreId)
        End Try
    End Sub
    Sub CheckCellManadatory(col As DataColumn)
        If db.IsDBNull(tImportSubs.Rows(FileRowNo - 2)(col.ColumnName), "") = "" Then Me.AddCellMessage(MessageTypes.ErrorMessage, col.Ordinal, col.ColumnName & " is blank.")

    End Sub
    Sub CheckCellLength(col As DataColumn, MaxLength As Integer)
        Dim valLen As Integer = CStr(db.IsDBNull(tImportSubs.Rows(FileRowNo - 2)(col.ColumnName), "")).Length
        If valLen > MaxLength Then Me.AddCellMessage(MessageTypes.ErrorMessage, col.Ordinal, col.ColumnName & " must be " & MaxLength & " characters or less. Currently:" & valLen)

    End Sub
    Enum MessageTypes
        ErrorMessage = 1
        WarningMessage = 2
    End Enum
    Dim FileRowNo As Integer = 1
    Friend Sub AddGeneralMessage(ByVal MessageType As MessageTypes, ByVal ErrorMessage As String)
        Select Case MessageType
            Case MessageTypes.ErrorMessage
                Me.ErrorMessages += ErrorMessage & vbCrLf

            Case MessageTypes.WarningMessage
                Me.WarningMessages += ErrorMessage & vbCrLf

            Case Else
                Throw New Exception("MassageType:" & MessageType & " not recognised in AddGeneralMessage")
        End Select
    End Sub
    Friend Sub AddRowMessage(ByVal MessageType As MessageTypes, ByVal ErrorMessage As String)
        Me.AddGeneralMessage(MessageType, "Row:" & FileRowNo & "-" & ErrorMessage)

    End Sub
    Friend Sub AddCellMessage(ByVal MessageType As MessageTypes, ColumnOrdinal As Integer, ByVal ErrorMessage As String)
        Me.AddGeneralMessage(MessageType, "Cell:" & Chr(ColumnOrdinal + 65) & FileRowNo & "-" & ErrorMessage)

    End Sub

    Public Sub ImportFiletoDB(AdditionalProductsCode As String, AdditionalProductsName As String)
        Dim workbookSet As SpreadsheetGear.IWorkbookSet = SpreadsheetGear.Factory.GetWorkbookSet()
        Dim fileST As New BusinessLogic.FileStore(Me.SubscriberImportBatchRow("BeforeImportFileStoreId"), db)
        Dim workbook As SpreadsheetGear.IWorkbook = workbookSet.Workbooks.OpenFromMemory(fileST.FileBytes)
        Dim worksheet As SpreadsheetGear.IWorksheet = workbook.Worksheets(0)
        Dim rowNo As Integer = Nothing
        Dim exitLoop As Boolean = False

        Do
            If worksheet.Cells(rowNo, 1).Value Is Nothing _
                    And worksheet.Cells(rowNo, 4).Value Is Nothing Then
                exitLoop = True
            End If
            If Not exitLoop Then
                If CStr(worksheet.Cells(rowNo, 1).Value) = "" _
                        And CStr(worksheet.Cells(rowNo, 4).Value) = "" Then
                    exitLoop = True
                End If
            End If
            If Not exitLoop Then
                rowNo += 1
            End If

        Loop Until exitLoop
        If rowNo < 2 Then
            Throw New Exception("This file has no data")
        End If
        Dim tbl As DataTable = worksheet.Cells(0, 0, rowNo - 1, 20).GetDataTable(SpreadsheetGear.Data.GetDataFlags.FormattedText)

        Dim SQLInsert As String = Nothing
        Dim SQLValues As String = Nothing
        Dim SQLAll As String = Nothing
        Dim cmdDelete As New SqlCommand

        db.BeginTran()
        Try
            '8/3/10     James Woosnam   SIR2179 - Allow files to be re-imported into the same batch
            '31/07/15   Julian Gates    SIR3900 - Change import code below to use City and State column names from Import template

            Dim cmd As New SqlCommand("", db.DBConnection, db.DBTransaction)


            cmd.CommandText = "DELETE FROM tmpSubscriberImport"
            cmd.CommandText += " WHERE SubscriberImportBatchId=" & Me.SubscriberImportBatchId
            cmd.ExecuteNonQuery()

            For Each row As DataRow In tbl.Rows
                If db.IsDBNull(row("FirstName"), "") = "" And db.IsDBNull(row("LastName"), "") = "" Then
                    '16/12/19   James Woosnam   SIR4760 - If fiest and last name blank then skip row.
                Else
                    SQLInsert = "INSERT INTO tmpSubscriberImport (" _
                            & "  SubscriberImportBatchId" _
                            & " , AffiliateReferenceId" _
                            & " , SubscriberCategory" _
                            & " , FirstName" _
                            & " , LastName" _
                            & " , Address1" _
                            & " , Address2" _
                            & " , Address3" _
                            & " , Address4" _
                            & " , Town" _
                            & " , County" _
                            & " , PostCode" _
                            & " , CountryName" _
                            & " , Status" _
                            & " , GroupSubscriberId" _
                            & " , CompanyId"
                    SQLValues = "VALUES(" _
                            & " " & Me.SubscriberImportBatchId _
                            & " ,'" & CStr(row("AffiliateReferenceId")).Trim & "'" _
                            & " ,'" & CStr(row("SubscriberCategory")).Trim & "'" _
                            & " ,'" & CStr(row("FirstName")).Trim.Replace("'", "''") & "'" _
                            & " ,'" & CStr(row("LastName")).Trim.Replace("'", "''") & "'" _
                            & " ,'" & CStr(row("Address1")).Trim.Replace("'", "''") & "'" _
                            & " ,'" & CStr(row("Address2")).Trim.Replace("'", "''") & "'" _
                            & " ,'" & CStr(row("Address3")).Trim.Replace("'", "''") & "'" _
                            & " ,'" & CStr(row("Address4")).Trim.Replace("'", "''") & "'" _
                            & " ,'" & CStr(row("City")).Trim.Replace("'", "''") & "'" _
                            & " ,'" & CStr(row("State")).Trim.Replace("'", "''") & "'" _
                            & " ,'" & CStr(row("PostCode")).Trim.Replace("'", "''") & "'" _
                            & " ,'" & CStr(row("CountryName")).Trim.Replace("'", "''") & "'" _
                            & " ,'Initial'" _
                            & " ," & Me.SubscriberImportBatchRow("BlockSubscriberId") _
                            & " ," & Me.SubscriberImportBatchRow("CompanyId")
                    If Not db.IsDBNull(Me.SubscriberImportBatchRow("OrderNumber")) Then
                        SQLInsert += " , OrderNumber"
                        SQLValues += " ," & Me.SubscriberImportBatchRow("OrderNumber")
                    End If

                    If tbl.Columns.Contains("ParentSubscriberName") Then
                        SQLInsert += " , ParentSubscriberName"
                        SQLValues += " ,'" & CStr(row("ParentSubscriberName")).Trim.Replace("'", "''") & "'"
                    End If
                    If tbl.Columns.Contains("EmailAddress") Then
                        SQLInsert += " , EmailAddress"
                        SQLValues += " ,'" & CStr(row("EmailAddress")).Trim.Replace("'", "''") & "'"
                    End If


                    '27/9/12    Julian Gates    SIR2874 - Save AdditionalProductsCode for Import Dup Check fuctionality.
                    If AdditionalProductsCode <> "" Then
                        SQLInsert += " , AdditionalProductsCode"
                        SQLValues += " ,'" & AdditionalProductsCode.Replace("'", "''") & "'"
                    End If
                    '27/9/12    Julian Gates    SIR2874 - Save AdditionalProductsName for Import Dup Check fuctionality.
                    If AdditionalProductsName <> "" Then
                        SQLInsert += " , AdditionalProductsName"
                        SQLValues += " ,'" & AdditionalProductsName.Replace("'", "''") & "'"
                    End If

                    '26/11/19   James Woosnam   SIR4960 Import PrintedCopy
                    If tbl.Columns.Contains("PrintedCopy") Then
                        SQLInsert += " , PrintedCopy"
                        SQLValues += " ,'" & CStr(row("PrintedCopy")).Trim.Replace("'", "''") & "'"
                    End If

                    '18/5/23    Julian Gates    SIR5641 - Add PhoneNumberForCourier to import if it exists.
                    If tbl.Columns.Contains("PhoneNumberForCourier") Then
                        SQLInsert += " , PhoneNumberForCourier"
                        SQLValues += " ,'" & CStr(row("PhoneNumberForCourier")).Trim.Replace("'", "''") & "'"
                    End If

                    '18/12/19   James Woosnam   SIR4979 Import EmailOptOut
                    '13/1/22    james Woosnam   SIR5388 - EmailOpt Out column
                    SQLInsert += ")"
                    SQLValues += ")"
                    SQLAll = SQLInsert + " " + SQLValues
                    cmd.CommandText = SQLAll
                    cmd.ExecuteNonQuery()
                End If

            Next
            Me.WriteLog("File Loaded")
            db.CommitTran()
        Catch e As Exception
            db.RollbackTran()
            Throw New Exception(e.ToString & vbCrLf & SQLAll)
        End Try
    End Sub
    Public Function GetSubscriberImportBatchNameForAdd(CompanyId As Integer, SubscriberId As Integer, DefaultName As String) As String
        '2/3/20     James Woosnam   SIR5030 - Make import batch name unique
        Dim SubscriberImportBatchNameForAdd As String = ""
        '7/2/20     James Woosnam   SIR4996 - Get unique batch name
        '      Dim baseName As String = db.DLookup("CompanyShortName", "Company", "CompanyId=" & CompanyId) & " " & TextForName & " " & Now.ToString("MMM yyyy")
        SubscriberImportBatchNameForAdd = DefaultName
        Dim tBatches As DataTable = db.GetDataTableFromSQL("SELECT * FROM SubscriberImportBatch WHERE CompanyId=" & CompanyId & " AND BlockSubscriberId=" & SubscriberId & " ORDER BY SubscriberImportBatchName DESC")

        While New DataView(tBatches, "SubscriberImportBatchName='" & SubscriberImportBatchNameForAdd & "'", "", DataViewRowState.CurrentRows).Count > 0
            Dim maxName As String = DefaultName
            For Each row As DataRow In tBatches.Rows
                If Left(row("SubscriberImportBatchName"), DefaultName.Length) = DefaultName Then
                    maxName = row("SubscriberImportBatchName")
                    Exit For
                End If
            Next
            Dim suffix As String = maxName.Replace(DefaultName, "").Replace(" (", "").Replace(")", "")
            If IsNumeric(suffix) Then
                suffix = " (" & (suffix + 1).ToString & ")"
            Else
                suffix = " (1)"
            End If
            SubscriberImportBatchNameForAdd = DefaultName & suffix

        End While
        Return SubscriberImportBatchNameForAdd
    End Function
    Public BatchJob As BusinessLogic.BatchJob = Nothing

    Public Sub SubmitActionSubscriberImportBatch(AdditionalProductsCode As String)
        Try
            BatchJob = New BusinessLogic.BatchJob(db)
            BatchJob.SubmittedByUserSessionId = Me.UserSession.UserSessionIdGUID
            BatchJob.Parameters.Add("SubscriberImportBatchId", SubscriberImportBatchId)
            BatchJob.Parameters.Add("AdditionalProductsCode", AdditionalProductsCode)
            BatchJob.CreateBatchJobEntry("ActionSubscriberImportBatch", db)
        Catch ex As Exception
            Throw New Exception("SubmitActionSubscriberImportBatch failed:" & ex.Message)
        End Try
    End Sub
    Public BatchLog As BatchLog = Nothing
    Public Sub ExecuteActionSubscriberImportBatch(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)

        ExecuteActionSubscriberImportBatch(BatchJobId, Parameters.GetValue("AdditionalProductsCode"))
    End Sub

    Public Sub ExecuteActionSubscriberImportBatch(ByVal BatchJobId As Integer, AdditionalProductsCode As String)
        '14/10/21   James Woosnam   SIR5342 - Move subscriber import code to SubscriberImportBatch so import can be submitted and run as a batch job
        Dim dbForLog As New Database(db.DBConnectionString)
        BatchLog = New BatchLog("ActionSubscriberImportBatch", "SubscriberImportBatchId=" & SubscriberImportBatchId & ";AdditionalProductsCode=" & AdditionalProductsCode, dbForLog, BatchJobId)
        Me.BatchLog.Update("SubscriberImportBatch: <a href='pg483SubscriberImportFileLoad.aspx?SubscriberImportBatchId=" & Me.SubscriberImportBatchId & "'>" & Me.SubscriberImportBatchRow("SubscriberImportBatchName") & "</a>")
        Me.BatchLog.Update("Subscriber: <a href='pg111SubscriberDisplay.aspx?SubscriberId=" & Me.SubscriberImportBatchRow("BlockSubscriberId") & "'>" & Me.SubscriberImportBatchRow("BlockSubscriberId") & "</a>")
        Me.BatchLog.Update("Order Number: <a href='pg142OrderMaint2.aspx?OrderNumber=" & Me.SubscriberImportBatchRow("OrderNumber") & "'>" & Me.SubscriberImportBatchRow("OrderNumber") & "</a>")

        Try

            '29/11/18	James Woosnam	SIR4760 - Create/Update Remote Users
            Dim sql As String = ""
            sql = "SELECT s.*"
            sql += " FROM tmpSubscriberImport s  "
            sql += " WHERE s.SubscriberImportBatchId=  " & Me.SubscriberImportBatchId
            sql += " ORDER BY SubscriberImportId  "
            Dim tbl As DataTable = db.GetDataTableFromSQL(sql)
            BatchLog.Update(tbl.Rows.Count & " Users to setup")
            Dim FileRowowNo As Integer = 2
            Dim rowDesc As String = ""
            For Each row As DataRow In tbl.Rows
                rowDesc = "FileRow:" & FileRowowNo & " " & " " & row("Lastname") & ", " & row("FirstName") & " SubscriberImportId:" & row("SubscriberImportId")
                db.BeginTran()
                Try
                    '10/1/22    James Woosnam   SIR5403 - Set ImportedStartedDateTime so it can be used in the username trigger
                    db.ExecuteSQL("UPDATE SubscriberImportBatch SET ImportedStartedDateTime= GETDATE() WHERE SubscriberImportBatchId=" & Me.SubscriberImportBatchId)
                    Dim lineMsg As String = ""
                    If Callsp483SubscriberImportStoredProcedure("Import", AdditionalProductsCode, "", row("SubscriberImportId")) Then
                        lineMsg = "Subscriber imported"
                        row("SubscriberId") = db.DLookup("SubscriberId", "tmpSubscriberImport", "SubscriberImportId=" & row("SubscriberImportId")) 'Set SubId as it may have been created in sp483
                        Dim UserId As Integer = db.IsDBNull(db.DLookup("UserId", "RemoteUserRights", "RightsToId=" & row("SubscriberId")), 0) 'Get userId 
                        '    If db.IsDBNull(row("WebUserName"), "") <> "" Then sir5561 - WebUserName no longer used, user always added if neccessary
                        Dim ru As BusinessLogic.RemoteUser = Nothing
                        Try
                            If UserId = 0 Then
                                ru = New BusinessLogic.RemoteUser(db, Me.UserSession)
                                ru.AddNewSubscriberUser(row("EmailAddress"), row("SubscriberId"), BusinessLogic.UserSession.AuthorityLevels.IndividualSubscriber)
                                lineMsg += ", new user added"
                                '24/1/20    James Woosnam   SIR5001 - Set new user to Active
                                ru.UserStatus = BusinessLogic.RemoteUser.UserStates.Active
                                row("OverwriteWebUserName") = "Yes" 'just in case not already y
                                'if new user then set it to random to ensure secuirty
                                ru.SetPassword(New BusinessLogic.StdCode().GetRandomName(30) & "Ab1")
                            Else
                                If CStr(row("OverwriteWebUserName")).ToUpper = "YES" Then
                                    ru = New BusinessLogic.RemoteUser(UserId, db, Me.UserSession)
                                End If
                            End If
                            If CStr(row("OverwriteWebUserName")).ToUpper = "YES" Then
                                ru.RemoteUserRow("UserName") = row("EmailAddress")
                                ru.Save()
                                lineMsg += ", user updated"
                            End If
                        Catch ex As Exception
                            Dim msg As String = ex.Message
                            If ex.InnerException IsNot Nothing AndAlso ex.InnerException.InnerException IsNot Nothing Then msg += " " & ex.InnerException.InnerException.Message
                            Throw New Exception("Add/Update user failed:" & msg)
                        End Try
                    End If
                    db.ExecuteSQL("UPDATE SubscriberImportBatch SET ImportedStartedDateTime= NULL WHERE SubscriberImportBatchId=" & Me.SubscriberImportBatchId) 'Set ImportedStartedDateTime to NULL when finished
                    db.CommitTran()
                    Me.WriteLog("File Imported")
                    BatchLog.Update(rowDesc & " - " & lineMsg)
                Catch ex As Exception
                    db.RollbackTran()
                    Dim ErrMsg As String = rowDesc & " Failed & Rolled back: " & ex.Message & Environment.NewLine & "This row and all remaining rows in the file have NOT been loaded."
                    Throw New Exception(ErrMsg)
                End Try

                FileRowowNo += 1
            Next
            BatchLog.Update("All rows setup and committed")
            ExportLoadedDataTableAsXLS()
            BatchLog.Update("Completed", BatchLog.BatchLogStates.Complete)

        Catch ex As Exception
            BatchLog.Update("Failed:" & ex.Message, BatchLog.BatchLogStates.Failed)
            Throw New Exception("ActionImportBatch Failed:" & ex.Message)
        End Try
        Try
            dbForLog.DBConnection.Close()
        Catch ex As Exception
        End Try
    End Sub
    Public Function Callsp483SubscriberImportStoredProcedure(ByVal RunMode As String, AdditionalProductsCode As String, ByRef ReturnMessage As String, Optional IndividualSubscriberImportId As Integer = 0) As Boolean
        Try
            Dim cmd As New SqlCommand("sp483SubscriberImport", db.DBConnection, db.DBTransaction)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandTimeout = 1200
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberImportBatchId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.SubscriberImportBatchId))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@IndividualSubscriberImportId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, IndividualSubscriberImportId))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 100, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, Me.UserSession.UserName))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RunMode", System.Data.SqlDbType.VarChar, 100, ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, RunMode))
            '2/10/12    James Woosnam   SIR2874 - Pass additional products to sp for duplicate subscription check
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AdditionalProducts", System.Data.SqlDbType.Structured, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                      , New Product(db, Me.UserSession).GetAdditionalProductsTable(AdditionalProductsCode)))

            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReturnCode", System.Data.SqlDbType.Int, 0, ParameterDirection.Output, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, 0))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ErrorMessage", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Output, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default, ""))
            cmd.ExecuteNonQuery()
            If IndividualSubscriberImportId = 0 Then Me.WriteLog("File " & RunMode & "ed")
            Try
                For Each impRow As DataRow In db.GetDataTableFromSQL("
SELECT s.* 
    ,FullAddress = ISNULL(Address1,'') + ',' + ISNULL(Address2,'') + ',' + ISNULL(Address3,'') + ',' + ISNULL(Address4,'') + ',' + ISNULL(Town,'') + ',' + ISNULL(County,'') + ',' + ISNULL(PostCode,'') + ',' + ISNULL(CountryName,'')
FROM tmpSubscriberImport s  
WHERE s.SubscriberImportBatchId=  " & Me.SubscriberImportBatchId).Rows
                    Dim prflChgs As String = ""
                    If IndividualSubscriberImportId = 0 Or IndividualSubscriberImportId = impRow("SubscriberImportId") Then
                        Dim nowRow As DataRow = Me.GetCurrentDetailsRow(impRow("SubscriberImportId"))

                        If nowRow Is Nothing Then
                            prflChgs += IIf(prflChgs = "", "", "||") & "New Subscriber and PEPWeb User"
                        Else
                            If db.IsDBNull(nowRow("UserName")) Then
                                prflChgs += IIf(prflChgs = "", "", "||") & "New PEPWeb User"
                            End If
                            For Each col As DataColumn In nowRow.Table.Columns
                                Select Case col.DataType.ToString
                                    Case "System.String"
                                        Select Case col.ColumnName
                                            Case "UserName"
                                                If db.IsDBNull(impRow("OverwriteWebUserName"), "") = "Yes" And db.IsDBNull(impRow("EmailAddress"), "") <> db.IsDBNull(nowRow("UserName"), "") Then
                                                    prflChgs += IIf(prflChgs = "", "", "||") & col.ColumnName & ":" & db.IsDBNull(nowRow(col.ColumnName), "") & "-->" & db.IsDBNull(impRow("EmailAddress"), "")
                                                End If
                                            Case "Address1", "Address2", "Address3", "Address4", "Town", "County", "PostCode", "CountryName"
                                                'Skip as part of FullAddress
                                            Case "FullAddress"
                                                If db.IsDBNull(impRow(col.ColumnName), "") <> db.IsDBNull(nowRow(col.ColumnName), "") Then
                                                    prflChgs += IIf(prflChgs = "", "", "||") & IIf(impRow("CompanyId") = 1, "PostalAddress", "BillingAddress") & ":" & db.IsDBNull(nowRow(col.ColumnName), "") & "-->" & db.IsDBNull(impRow(col.ColumnName), "")
                                                End If
                                            Case Else
                                                If db.IsDBNull(impRow(col.ColumnName), "") <> db.IsDBNull(nowRow(col.ColumnName), "") Then
                                                    prflChgs += IIf(prflChgs = "", "", "||") & col.ColumnName & ":" & db.IsDBNull(nowRow(col.ColumnName), "") & "-->" & db.IsDBNull(impRow(col.ColumnName), "")
                                                End If

                                        End Select
                                End Select
                            Next
                            If db.IsDBNull(impRow("ExistingSubscriptionFound"), False) AndAlso db.IsDBNull(impRow("ExistingSubscriptionAction"), "") = "GroupOnly" Then
                                prflChgs += IIf(prflChgs = "", "", "||") & "Subscriber: Added to Group Only due to existing subscription"
                            End If

                        End If
                        If prflChgs <> "" Then
                            '26/10/23   James Woosnam   SIR5707 - Remove Status='Error' for update below
                            db.ExecuteSQL("UPDATE tmpSubscriberImport SET ProfileChanges ='" & prflChgs.Replace("'", "''") & "' WHERE SubscriberImportId=" & impRow("SubscriberImportId"))
                        End If
                        If IndividualSubscriberImportId = impRow("SubscriberImportId") Then Exit For
                    End If
                Next

            Catch ex As Exception
                Throw New Exception("Get profile changes failed:" & ex.Message)
            End Try
            If cmd.Parameters("@ReturnCode").Value <> 0 Then
                Throw New Exception("@ErrorCode:" & cmd.Parameters("@ReturnCode").Value & " @ErrorMessage: " & cmd.Parameters("@ErrorMessage").Value)
            End If

            cmd = Nothing

            Return True
        Catch ex As Exception
            Me.WriteLog("File " & RunMode & " Failed")
            Throw New Exception("Callsp483SubscriberImportStoredProcedure Failed:" & ex.Message)
            Return False
        End Try
    End Function
    Public Function GetLastLogFrom(LogDescs() As String) As String
        Dim DescsCSV As String = ""
        For Each desc In LogDescs
            DescsCSV += IIf(DescsCSV = "", "", ",") & "'" & desc.Replace("'", "''") & "'"
        Next
        Dim sql As String = "
            SELECT
	            l.Description
            FROM SubscriberImportBatchLog l
            WHERE l.SubscriberImportBatchId = " & Me.SubscriberImportBatchId & "
            AND l.Description in (" & DescsCSV & ")
            ORDER BY
	            l.LogDateTime DESC
            "
        Dim tbl As DataTable = db.GetDataTableFromSQL(sql)
        If tbl.Rows.Count = 0 Then Return Nothing
        Return tbl.Rows(0)(0)
    End Function
    Public Sub ExportLoadedDataTableAsXLS()
        '******************************************************
        'Description:	Exports data into a XLS file
        '******************************************************
        '8/3/10     James Woosnam   SIR2179 - Include RetainedUserName in loaded file
        Dim SQL As String = Nothing
        Dim fileName As String = Nothing
        fileName = "\Batch" & Me.SubscriberImportBatchId & " - " & db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & Me.SubscriberImportBatchRow("BlockSubscriberId")) & ".xlsx"
        Dim fileNameXLSTemplate As String = db.GetParameterValue("ReportTemplateDirectory") & "\SubscriberImportBatchTemplate.xlsx"

        SQL = "Select tmpSubscriberImport.*"
        SQL += "  ,RetainedUserName = CASE WHEN tmpSubscriberImport.OverwriteWebUserName = 'No' THEN ru.UserName ElSE '' END"
        SQL += " FROM tmpSubscriberImport"
        SQL += "		LEFT JOIN Subscriber s"
        SQL += "		    INNER JOIN RemoteUserRights rur"
        SQL += "		        INNER JOIN RemoteUser ru"
        SQL += "		        ON ru.UserId = rur.UserId"
        SQL += "		    ON rur.RightsToId = s.SubscriberId"
        SQL += "		    AND rur.RightsType = 'Subscriber'"
        SQL += "		ON ( s.SubscriberId = tmpSubscriberImport.MatchedSubscriberId "
        SQL += "		OR s.SubscriberId = tmpSubscriberImport.DuplicateSubscriberIdToUse )"
        SQL += " WHERE tmpSubscriberImport.SubscriberImportBatchId =" & Me.SubscriberImportBatchId

        Dim tbl As DataTable = db.GetDataTableFromSQL(SQL)
        BatchLog.Update(tbl.Rows.Count & " rows to add to output file")

        'remove unwanted columns from dataset
        tbl.Columns.Remove("SubscriberImportId")
        tbl.Columns.Remove("SubscriberImportBatchId")
        tbl.Columns.Remove("ErrorMessage")
        tbl.Columns.Remove("Status")
        tbl.Columns.Remove("CompanyId")
        tbl.Columns.Remove("GroupSubscriberId")
        tbl.Columns.Remove("OrderNumber")
        tbl.Columns.Remove("DuplicateSubscriberIdToUse")
        tbl.Columns.Remove("MatchedSubscriberId")
        tbl.Columns.Remove("WebUserPassword")
        tbl.Columns.Remove("LastLoggedOnDateTime")
        tbl.Columns.Remove("WebUserOverwriteActionReviewed")
        Try
            If tbl.Rows.Count = 0 Then
                Throw New Exception("Subscriber Batch Id " & Me.SubscriberImportBatchId & " not found")
            Else
                Dim i As Integer
                Dim workbook As SpreadsheetGear.IWorkbook = SpreadsheetGear.Factory.GetWorkbook(fileNameXLSTemplate)
                Try
                    Dim worksheet As SpreadsheetGear.IWorksheet = workbook.Worksheets("Sheet1")

                    worksheet.Name = "Subscriber Loaded Data"

                    For col As Integer = 0 To tbl.Columns.Count - 1
                        worksheet.Cells(0, col).Value = tbl.Columns(col).ColumnName
                    Next
                    i = 0
                    For row As Integer = 0 To tbl.Rows.Count - 1
                        If Not tbl.Rows(row).RowState = DataRowState.Deleted Then
                            For col As Integer = 0 To tbl.Columns.Count - 1
                                worksheet.Cells(i + 1, col).Value = CStr(db.IsDBNull(tbl.Rows(row)(col), ""))
                            Next
                            i = i + 1
                        End If
                    Next
                    Dim memoryStream As New System.IO.MemoryStream()

                    workbook.SaveToStream(memoryStream, SpreadsheetGear.FileFormat.OpenXMLWorkbook)

                    Me.UpdateStatus(BusinessLogic.SubscriberImportBatch.SubscriberImportBatchStates.Imported, memoryStream.ToArray, fileName)
                    Me.BatchLog.Update("Output File: <a href='pg100HomeAdmin.aspx?FileStoreId=" & Me.SubscriberImportBatchRow("AfterImportFileStoreId") & "'>Download</a>")
                Catch ex As Exception
                    Throw ex
                Finally
                    workbook.Close()
                End Try

            End If
        Catch e As Exception
            Throw New Exception("ExportLoadedDataTableAsXLS Failed:" & e.Message)
        End Try

    End Sub
    Public Function GetCurrentDetailsRow(SubscriberImportId As Integer) As DataRow
        Dim sql As String = "
SELECT
	i.SubscriberImportId 
	,afPrt.AffiliateReferenceID
	,afComp.SubscriberCategory  
	,s.FirstName 
	,s.LastName 
	,a.Address1 
	,a.Address2
	,a.Address3 
	,a.Address4 
	,a.Town  
	,a.County 
	,a.PostCode  
	,a.CountryId 
	,cy.CountryName 
    ,FullAddress = ISNULL(a.Address1,'') + ',' + ISNULL(a.Address2,'') + ',' + ISNULL(a.Address3,'') + ',' + ISNULL(a.Address4,'') + ',' + ISNULL(a.Town,'') + ',' + ISNULL(a.County,'') + ',' + ISNULL(a.PostCode,'') + ',' + ISNULL(cy.CountryName,'')
	,EmailAddress = em.AddressText 
	,ru.LastLoggedOn 
    ,ru.UserName
FROM Subscriber s
	INNER JOIN tmpSubscriberImport i
	ON ( s.SubscriberId  = i.MatchedSubscriberId 
		OR s.SubscriberId = i.DuplicateSubscriberIdToUse )
	INNER JOIN Company c
	ON c.CompanyId = i.CompanyId 
	LEFT JOIN SubscriberAffiliate afComp
	ON afComp.ChildSubscriberID = s.SubscriberId 
	AND afComp.ParentSubscriberID = c.GroupParentSubscriberId 
	and afComp.EndDate > GETDATE()
	LEFT JOIN SubscriberAffiliate afPrt
	ON afPrt.ChildSubscriberID = s.SubscriberId 
	AND afPrt.ParentSubscriberID = i.GroupSubscriberId 
	and afPrt.EndDate > GETDATE()
	LEFT JOIN SubscriberAddress a
		INNER JOIN Country cy
		On cy.CountryID = a.CountryId 
	On a.SubscriberId = s.SubscriberId 
	AND a.AddressType = 'Postal'
	AND a.AddressDescription = c.DefaultAddressDescription
	LEFT JOIN SubscriberAddress em
	On em.SubscriberId = s.SubscriberId 
	AND em.AddressType = 'Email'
	AND em.AddressDescription = 'Main'
	LEFT JOIN RemoteUserRights ror
		INNER JOIN RemoteUser ru
		ON ru.UserId = ror.UserId 
		AND ru.UserStatus IN ('Active','Emailed')
	ON ror.RightsToId = s.SubscriberId 
	AND ror.RightsType = 'Subscriber'
WHERE i.SubscriberImportId = " & SubscriberImportId
        Dim t As DataTable = db.GetDataTableFromSQL(sql)
        If t.Rows.Count = 0 Then Return Nothing
        Return t.Rows(0)
    End Function
End Class
