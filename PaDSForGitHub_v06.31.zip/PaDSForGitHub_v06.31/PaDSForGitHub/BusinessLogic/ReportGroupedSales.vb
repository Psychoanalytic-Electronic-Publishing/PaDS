﻿'Modification History
'Feb 2018       James Woosnam   SIR4571 - Initial Version


Public Class ReportGroupedSales
    Inherits ReportSSG
#Region "Class Properties"
    Dim BatchJobId As Integer = Nothing
    Dim StartDate As Date = Nothing
    Dim EndDate As Date = Nothing
    Dim CompanyId As Integer = Nothing
#End Region

    Public Sub New(ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("GroupedSales", "Excel", db, SubmittedByUserSessionId)
    End Sub
    Public Sub New(ByVal StartDate As Date, ByVal EndDate As Date, CompanyId As Integer, ByVal db As BusinessLogic.Database, ByVal SubmittedByUserSessionId As Guid)
        MyBase.New("GroupedSales", "Excel", db, SubmittedByUserSessionId)
        Me.StartDate = StartDate
        Me.EndDate = EndDate
        Me.CompanyId = CompanyId
    End Sub
    Public Overloads Sub Submit()

        Me.BatchJob = New BusinessLogic.BatchJob(Me.db)
        BatchJob.SubmittedByUserSessionId = Me.SubmittedByUserSessionId
        BatchJob.Parameters.Add("ReportName", Me.ReportName)
        BatchJob.Parameters.Add("CompanyId", CompanyId)
        BatchJob.Parameters.Add("StartDate", StartDate.ToString("dd-MMM-yyyy"))
        BatchJob.Parameters.Add("EndDate", EndDate.ToString("dd-MMM-yyyy"))
        BatchJob.CreateBatchJobEntry("RunReportSpreadsheetGearExcel", Me.db)

    End Sub

    Public Overloads Sub Execute(ByVal BatchJobId As Integer, ByVal Parameters As BusinessLogic.BatchJobParameters)
        Me.BatchJobId = BatchJobId
        Me.JobParameters = Parameters
        Me.StartDate = Parameters.GetValue("StartDate")
        Me.EndDate = Parameters.GetValue("EndDate")
        Me.CompanyId = Parameters.GetValue("CompanyId")
        Me.Execute()
    End Sub

    Public Overloads Sub Execute(Optional ByVal InBatchLog As BatchLog = Nothing)

        Dim batchLogCreatedHere As Boolean = False
        If InBatchLog Is Nothing Then
            Me.BatchLog = New BatchLog("Report-" & Me.ReportName _
                                          , ";StartDate=" & Me.StartDate _
                                         & ";EndDate=" & Me.EndDate _
                                         , Me.db _
                                         , BatchJobId _
                                         , Me.SubmittedByUserSessionId)
            batchLogCreatedHere = True
        Else
            Me.BatchLog = InBatchLog
        End If
        Try
            MyBase.Execute(Me.BatchLog)

            Me.ExcelWorkBook = SpreadsheetGear.Factory.GetWorkbook(Me.ExcelTemplate.FullName)



            Dim sql As String = "
                SELECT DISTINCT
	                s.Currency  
                FROM vw430SalesDetails s
                WHERE s.Date  BETWEEN " & db.vFQ(StartDate, "d") & " AND " & db.vFQ(EndDate, "d") & "
                AND s.CompanyId = " & Me.CompanyId & "
                    "
            Dim tblCurrencies As DataTable = db.GetDataTableFromSQL(sql)
            Me.ReportSQL = "SELECT [Product Group] = SalesReportProductGrouping"
            For Each row In tblCurrencies.Rows
                Me.ReportSQL += "
                                ," & row("Currency") & " = ISNULL([" & row("Currency") & "],0)"
            Next
            Me.ReportSQL += "
                FROM 
                (
                SELECT
	                p.SalesReportProductGrouping
	                ,s.Currency  
                    ,s.AnountInNative 
                FROM vw430SalesDetails s
		                INNER JOIN Product p
		                ON p.ProductCode = s.ProductCode 
                WHERE s.Date  BETWEEN " & db.vFQ(StartDate, "d") & " AND " & db.vFQ(EndDate, "d") & "
                AND s.CompanyId = " & Me.CompanyId & "
                AND ISNULL(p.SalesReportProductGrouping,'') <> ''
                ) ps
                PIVOT
                (
                SUM (AnountInNative)
                FOR Currency IN
                ( "
            Dim sCurrencies As String = ""
            For Each row In tblCurrencies.Rows
                sCurrencies += IIf(sCurrencies = "", "", ",") & "[" & row("Currency") & "]"
            Next
            Me.ReportSQL += sCurrencies & ")
                ) AS pvt               "

            Dim wsData As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Data")
            Dim wsCriteria As SpreadsheetGear.IWorksheet = ExcelWorkBook.Worksheets("Criteria")

            wsCriteria.Cells("CompanyName").Value = db.DLookup("CompanyName", "Company", "CompanyId=" & CompanyId)
            wsCriteria.Cells("StartDate").Value = StartDate
            wsCriteria.Cells("EndDate").Value = EndDate
            wsCriteria.Cells("DateRun").Value = Now.ToString("dd-MMM-yyyy HH:mm")
            wsCriteria.Cells("UserName").Value = Me.SubmittedByUserSession.UserFullName

            Dim rg As SpreadsheetGear.IRange
            rg = wsData.Cells("SalesData")
            rg.CopyFromDataTable(db.GetDataTableFromSQL(Me.ReportSQL), SpreadsheetGear.Data.SetDataFlags.InsertCells) '+ SpreadsheetGear.Data.SetDataFlags.NoColumnHeaders)

            ReportName = ReportName & StartDate.ToString(" dd-MMM-yyyy") & " to " & EndDate.ToString("dd-MMM-yyyy")
            ExcelWorkBook.SaveAs(Me.ReportFile.FullName, SpreadsheetGear.FileFormat.OpenXMLWorkbook)
            BatchLog.Update(Me.FileLink)

            If batchLogCreatedHere Then
                BatchLog.Update("Process Complete", "Complete")
            End If
        Catch ex As Exception
            BatchLog.Update("Report Failed:" & ex.Message, "Failed")
            Throw New Exception("Report Failed:" & ex.Message, ex)

        End Try

    End Sub
    Dim _ProductGroupingTable As DataTable = Nothing
    Public Function ProductGroupingTable() As DataTable
        Try

            Dim sql As String = Nothing
            If Me._ProductGroupingTable Is Nothing Then
                sql = "
                        SELECT DISTINCT
	                        p.ProductCode 
	                        ,p.ProductName 
                            ,p.SalesReportProductGrouping
                        FROM vw430SalesDetails so
		                    INNER JOIN Product p
		                    ON p.ProductCode = so.ProductCode 
                        WHERE so.Date BETWEEN " & db.vFQ(Me.StartDate, "d") & " AND " & db.vFQ(Me.EndDate, "d") & "
                        AND so.CompanyId = " & Me.CompanyId & "
                        
                        ORDER BY 
	                        p.ProductCode 
	                        ,p.SalesReportProductGrouping
                        "
                Me._ProductGroupingTable = db.GetDataTableFromSQL(sql)
            End If
            Return Me._ProductGroupingTable
        Catch ex As Exception
            Throw New Exception("PopulateGroupingTable failed:" & ex.Message)
        End Try
    End Function
End Class
