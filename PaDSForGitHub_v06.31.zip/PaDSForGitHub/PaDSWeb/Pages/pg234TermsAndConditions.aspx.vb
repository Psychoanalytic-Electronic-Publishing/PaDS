﻿Imports System.Data
Imports System.Data.SqlClient

'Modification History
'21/01/11  Julian Gates   Initial version
'19/03/15   Julian Gates    SIR3785 - Modify page to show spanish errors if IsSpanishIJPESSubscriber
'06/02/23   Julian Gates	SIR5562 - Use TermsAndConditionsHTML field value to populate T&C HTML

Partial Class Pages_pg234TermsAndConditions
    Inherits System.Web.UI.Page
    Dim pageMode As String = ""
    Dim StdCode As New BusinessLogic.StdCode()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Me.Master.Initilise("Terms and Conditions", "00", "")
        Master.ShowLanguageRBL = True
        Me.Master.PageTitle = Master.WebForm.GetTranslatedText(218, 0, "Terms and Conditions") & ": " & Request.QueryString("ProductName")
        Me.RemoteOrderTermsTitle.Text = Master.WebForm.GetTranslatedText(218, 0, "Terms and Conditions") & ": " & Request.QueryString("ProductName")

        RemoteProductTermsTextDisplay()
    End Sub

    Sub PageSetup()
        Me.Close.Value = Master.WebForm.GetTranslatedText(63, 0, "Back")
    End Sub

    Sub RemoteProductTermsTextDisplay()
        Try
            '06/02/23  Julian Gates	SIR5562 - Use TermsAndConditionsHTML field value to populate T&C HTML
            If Request.QueryString("ProductCode") <> "" Then
                Me.RemoteOrderTermsText.Text = Master.db.IsDBNull(Master.db.DLookup("TermsAndConditionsHTML", "Product", "ProductCode='" & Request.QueryString("ProductCode") & "'"), Nothing)
                If Me.RemoteOrderTermsText.Text = Nothing Then
                    Dim em As New BusinessLogic.Email(Me.Master.db)
                    em.SendErrorEmail("Terms and conditions HTML not found", "T&C HTML not found in Pads Product database table for Product Code:" & Request.QueryString("ProductCode"))
                    Me.Master.WebForm.AddPageError("Terms and conditions for this product not found")
                End If
            Else
                Me.Master.WebForm.AddPageError("This page must be passed a valid Product Code.")
            End If

        Catch ex As Exception
            Me.Master.WebForm.AddPageError(New Exception("An Unexpected error has occured.  Please contact support", ex))
        End Try
    End Sub

    Protected Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Unload
        Try
            Me.Master.Unload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        Try
            Me.Master.HandlePageError()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        Me.PageSetup()
        Master.WebForm.Page_PreRender(sender, e)

    End Sub
End Class
