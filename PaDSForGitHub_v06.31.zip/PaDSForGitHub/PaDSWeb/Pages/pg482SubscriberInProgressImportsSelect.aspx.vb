Imports System.Data.SqlClient
Imports System.Data

Partial Class pg482SubscriberInProgressImportsSelect
    'Modificaitons
    '============
    '18/05/07    Julian Gates    Initial Version
    '17/02/11    Julian Gates    Add filter to BuildGrid to only show imports for users company authorisation
    '09/02/16    Julian Gates    SIR4046 - Change Add Import to go to new pg483SubscriberImportFileLoad.aspx page
    '23/10/19    Julian Gates    SIR4760 - Change list SQL to point to SubscriberImportBatch data table and add filters.
    Inherits System.Web.UI.Page
    Public uPage As UserPage

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub


    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Subscriber Import Batches", "")
        Me.pageHeaderTitle.Text = "Subscriber Import Batches"

        If Not Page.IsPostBack Then

            If Request.QueryString("InfoMsg") <> "" Then
                Me.InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            If Request.QueryString("BlockSubscriberId") <> "" Then
                Me.FtrSubscriberName.Text = uPage.db.DLookup("SubscriberName", "Subscriber", "SubscriberId=" & Request.QueryString("BlockSubscriberId"))
            End If
            '19/1/20    James Woosnam   Default to inprogress
            Dim sql As String
            sql = "SELECT Distinct '=''' + SubscriberImportBatchStatus + '''' Value, SubscriberImportBatchStatus Text ,2 From SubscriberImportBatch "
            sql += "UNION SELECT Value= 'NOT IN (''Rejected'',''Imported'',''Available'')', Text = '**In Progress**', 1"
            sql += " ORDER BY 3,2"
            Me.uPage.PopulateDropDownListFromSQL(Me.FltrRenewalBatchStatus, sql, uPage.PrimaryConnection, "--All--")
            Me.FltrRenewalBatchStatus.Items.FindByText("**In Progress**").Selected = True
            txtRecordsToShow.Text = 20
            Me.txtPageNumber.Text = 1
            BuildGrid()
        Else
            'If Left(Me.txtCommandData.Value, 6) = "Delete" Then
            '    DeleteImortBatchLineRecord(Mid(Me.txtCommandData.Value, 7))
            'End If
            If Me.txtPrevRecordsToShow.Value <> Me.txtRecordsToShow.Text Then
                Me.txtPageNumber.Text = 1
                Me.txtPrevRecordsToShow.Value = Me.txtRecordsToShow.Text
            End If
            If Me.txtGotoPageNum.Value <> "" Then
                Me.txtPageNumber.Text = Me.txtGotoPageNum.Value
                Me.txtGotoPageNum.Value = ""
            End If
            BuildGrid()
        End If

    End Sub

    '23/10/19    Julian Gates    SIR4760 - Change list SQL to point to SubscriberImportBatch data table and add filters.
    Private Sub BuildGrid()
        If Me.IsPageValidForStatus() Then
            Dim listSQL As String = Nothing
            Dim html As String = Nothing
            Dim lineNumber As Long = Nothing
            Try
                listSQL = "Select rb.SubscriberImportBatchId" _
                        & "         ,rb.SubscriberImportBatchName" _
                        & "         ,rb.SubscriberImportBatchStatus" _
                        & "         ,BlockSubscriberName = s.SubscriberName" _
                        & "         ,c.CompanyName " _
                        & "         ,LastAction = rbl.UserName + ' ' + FORMAT(rbl.LogDateTime ,'dd-MMM-yy HH:mm') + ' ' + rbl.Description" _
                        & " From SubscriberImportBatch rb " _
                        & "     LEFT JOIN Subscriber s" _
                        & "     ON s.SubscriberId = rb.BlockSubscriberId" _
                        & "     LEFT JOIN Company c" _
                        & "     ON c.CompanyId = rb.CompanyId" _
                        & "     LEFT JOIN SubscriberImportBatchLog rbl" _
                        & "     ON rbl.SubscriberImportBatchId = rb.SubscriberImportBatchId" _
                        & "     AND rbl.SubscriberImportBatchLogId = (SELECT MAX(rbl2.SubscriberImportBatchLogId) FROM SubscriberImportBatchLog rbl2 WHERE rbl2.SubscriberImportBatchId = rbl.SubscriberImportBatchId)" _
                        & " WHERE 1=1"

                If Me.FltrRenewalBatchName.Text <> "" Then
                    listSQL += " AND rb.SubscriberImportBatchName LIKE '%" & Me.FltrRenewalBatchName.Text.Replace("'", "''") & "%'"
                End If
                If Me.FltrRenewalBatchStatus.SelectedValue <> "" Then
                    listSQL += " AND rb.SubscriberImportBatchStatus " & Me.FltrRenewalBatchStatus.SelectedValue & ""
                End If
                If Me.FltrCompanyName.Text <> "" Then
                    listSQL += " AND c.CompanyName LIKE '%" & Me.FltrCompanyName.Text.Replace("'", "''") & "%'"
                End If
                If Me.FtrSubscriberName.Text <> "" Then
                    listSQL += " AND s.SubscriberName LIKE '%" & Me.FtrSubscriberName.Text.Replace("'", "''") & "%'"
                End If
                listSQL += "Order By rb.SubscriberImportBatchId Desc"

                Dim listTable As DataTable = uPage.GetListDatatable(Me.txtPageNumber.Text, Me.txtRecordsToShow.Text, Me.lblPaging.Text, listSQL, uPage.PrimaryConnection)

                If listTable.Rows.Count <> 0 Then
                    For Each row As DataRow In listTable.Rows
                        lineNumber = lineNumber + 1
                        html += "<tr>"
                        html += "<td align=""center"">" _
                               & "<a href='../pages/pg483SubscriberImportFileLoad.aspx?SubscriberImportBatchId=" & row.Item("SubscriberImportBatchId") _
                               & "' Title='Subscriber Renewel Control'>" & row.Item("SubscriberImportBatchId") & "</a></td>"
                        html += "<td><p class=""fldView"">" & row.Item("SubscriberImportBatchName") & "</p></td>"
                        html += "<td><p class=""fldView"">" & row.Item("SubscriberImportBatchStatus") & "</p></td>"
                        html += "<td><p class=""fldView"">" & row.Item("BlockSubscriberName") & "</p></td>"
                        html += "<td><p class=""fldView"">" & row.Item("CompanyName") & "</p></td>"
                        html += "<td><p class=""fldView"">" & row.Item("LastAction") & "</p></td>"
                        html += "</tr>"
                    Next
                Else
                    uPage.PageError = "No records match your selection criteria"
                End If
            Catch e As Exception
                uPage.PageError = e.ToString
            End Try
            'Assign grid to Label
            lblGridView.Text = html
        End If
    End Sub

    Private Sub btnFilter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFilter.Click
        Me.txtPageNumber.Text = 1
        BuildGrid()
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub
    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try

    End Sub
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        uPage.PagePreRender()
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        Select Case validatorStatus
            Case Else
                If txtRecordsToShow.Text = "" Then
                    uPage.FieldErrorControl(Me.txtRecordsToShow, "Max Records To Show must be numerical")
                End If
                If txtRecordsToShow.Text <> "" Then
                    If Not IsNumeric(Me.txtRecordsToShow.Text) Then
                        uPage.FieldErrorControl(Me.txtRecordsToShow, "Max Records To Show must be numerical")
                    End If
                End If
        End Select
        Return uPage.IsValid
    End Function
    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub NewImportBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewImportBtn.Click
        '09/02/16    Julian Gates    SIR4046 - Change Add Import to go to new pg483SubscriberImportFileLoad.aspx page
        Response.Redirect("../pages/pg483SubscriberImportFileLoad.aspx")
    End Sub

    'Sub DeleteImortBatchLineRecord(ByVal locId As String)
    '    Try
    '        Dim cmdDelete As New SqlCommand("DELETE FROM tmpSubscriberImport WHERE SubscriberImportBatchId =" & locId, uPage.PrimaryConnection)
    '        cmdDelete.ExecuteNonQuery()
    '    Catch e As Exception
    '        uPage.PageError = e.ToString
    '    End Try
    '    Me.txtCommandData.Value = ""
    '    Response.Redirect(Request.ServerVariables("Path_Info") & "?InfoMsg=Subscriber Batch Id " & locId & " Record Deleted")
    'End Sub
End Class
