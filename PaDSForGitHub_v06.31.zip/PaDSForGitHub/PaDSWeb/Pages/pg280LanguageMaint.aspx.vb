Imports System.Data.SqlClient
Imports System.Data
Partial Class pg280LanguageMaint
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    'Modification History
    '20/06/2022 Julian Gates  Initial version
    Public Property LanguageTranslationId As Integer
        Get
            Return ViewState("LanguageTranslationId")
        End Get
        Set(value As Integer)
            ViewState("LanguageTranslationId") = value
        End Set
    End Property
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Language Maintenance", "")
        Me.pageHeaderTitle.Text = "Language Maintenance"

        'Dim emailAddress As String = uPage.db.IsDBNull(uPage.db.DLookup("EmailAddress", "RemoteUser", "UserId=" & Me.uPage.UserSession.UserId), "")
        'If emailAddress.ToUpper.Contains("ZEDRA") Then
        '    'all fine
        'Else
        '    Response.Redirect("pg100HomeAdmin.aspx?InfoMsg=You are not authourised to update Parameters")
        'End If
        If Me.txtCommandData.Value <> "" Then
            Select Case Me.txtCommandData.Value.Split("_")(0)
                Case "Update"
                    Me.UpdateLanguageTextRow.Visible = True
                    ViewState("LanguageTranslationId") = Me.txtCommandData.Value.Split("_")(1)
                    ' BuildGrid(sLanguageTranslationId)
                    Dim row As DataRow = uPage.db.GetDataTableFromSQL("SELECT * FROM LanguageTranslation WHERE LanguageTranslationId=" & Me.LanguageTranslationId).Rows(0)
                    Me.UpdateLanguagePrompt.Text = "Update Language Text for TranslationNo:" & row("TranslationNo") & ", PageNumbe:" & row("PageNumber") & ", Language:" & row("LanguageName")
                    Me.LanguageTextUpdate.Text = row("LanguageText")
                    Me.txtCommandData.Value = ""
                    Me.LanguageTextUpdate.CssClass = "fldEntry"
            End Select
        End If
        If Not Page.IsPostBack Then
            If Request.QueryString("InfoMsg") <> "" Then
                Me.InfoMsg.Text = Request.QueryString("InfoMsg")
            End If
            If Request.QueryString("FltrTranslationNo") <> "" Then
                Me.FltrTranslationNo.Text = Request.QueryString("FltrTranslationNo")
            End If
            If Request.QueryString("FltrPageNumber") <> "" Then
                Me.FltrPageNumber.Text = Request.QueryString("FltrPageNumber")
            End If
            If Request.QueryString("FltrEnglishText") <> "" Then
                Me.FltrEnglishText.Text = Request.QueryString("FltrEnglishText")
            End If
            If Request.QueryString("FltrLanguageName") <> "" Then
                Me.FltrLanguageName.Text = Request.QueryString("FltrLanguageName")
            End If
            If Request.QueryString("FltrLanguageText") <> "" Then
                Me.FltrLanguageText.Text = Request.QueryString("FltrLanguageText")
            End If
            txtRecordsToShow.Text = 200
            Me.txtPageNumber.Text = 1
            '  BuildGrid()
        Else

            If Me.txtPrevRecordsToShow.Value <> Me.txtRecordsToShow.Text Then
                Me.txtPageNumber.Text = 1
                Me.txtPrevRecordsToShow.Value = Me.txtRecordsToShow.Text
            End If
            If Me.txtGotoPageNum.Value <> "" Then
                Me.txtPageNumber.Text = Me.txtGotoPageNum.Value
                Me.txtGotoPageNum.Value = ""
                '    BuildGrid()
            End If
        End If

    End Sub

    Private Sub BuildGrid(Optional languageTranslationId As String = Nothing)
        uPage.FieldValidateNumber(Me.txtRecordsToShow, True)

        If IsNumeric(Me.txtRecordsToShow.Text) Then
            Dim listSQL As String = Nothing
            Dim html As String = Nothing
            Try
                listSQL = "SELECT l.LanguageTranslationId" _
                        & "     ,l.TranslationNo " _
                        & "     ,l.PageNumber " _
                        & "     ,EnglishText = (SELECT LanguageText FROM LanguageTranslation l2 WHERE l2.TranslationNo = l.TranslationNo AND l2.LanguageName='English') " _
                        & "     ,l.LanguageName " _
                        & "     ,l.LanguageText " _
                        & "     ,PageName = ISNULL(pg.PageName,'') " _
                        & " FROM LanguageTranslation l "
                listSQL += " LEFT JOIN ("
                listSQL += " SELECT PageNumber=70,NoLinkWhy='PaDSLogon',PageName='pg070Logon'"
                listSQL += " UNION SELECT PageNumber=0,NoLinkWhy='',PageName='0-Generic'"
                listSQL += " UNION SELECT PageNumber=71,NoLinkWhy='FromEmail',PageName='pg071UserAuthorisation'"
                listSQL += " UNION SELECT PageNumber=101,NoLinkWhy='',PageName='pg101Home'"
                listSQL += " UNION SELECT PageNumber=105,NoLinkWhy='',PageName='pg105IJPDespatchFeedbackForm'"
                listSQL += " UNION SELECT PageNumber=112,NoLinkWhy='',PageName='pg112SubscriberDetailsMaint'"
                listSQL += " UNION SELECT PageNumber=117,NoLinkWhy='',PageName='pg117AddNewSubscriber'"
                listSQL += " UNION SELECT PageNumber=223,NoLinkWhy='',PageName='pg223Authorisation.aspx'"
                listSQL += " UNION SELECT PageNumber=232,NoLinkWhy='',PageName='pg232RemoteOrder'"
                listSQL += " ) pg"
                listSQL += " ON pg.PageNumber = l.PageNumber"

                listSQL += " WHERE 1=1"


                If Me.FltrTranslationNo.Text <> "" Then
                    listSQL += " AND l.TranslationNo  = " & Me.FltrTranslationNo.Text
                End If
                If Me.FltrPageNumber.Text <> "" Then
                    listSQL += " AND l.PageNumber =" & Me.FltrPageNumber.Text
                End If
                If Me.FltrEnglishText.Text <> "" Then
                    listSQL += " AND (SELECT LanguageText FROM LanguageTranslation l2 WHERE l2.TranslationNo = l.TranslationNo AND l2.LanguageName='English') like '%" & Me.FltrEnglishText.Text & "%'"
                End If
                If Me.FltrLanguageName.Text <> "" Then
                    listSQL += " AND l.LanguageName like '%" & Me.FltrLanguageName.Text & "%'"
                End If
                If Me.FltrLanguageText.Text <> "" Then
                    listSQL += " AND l.TranslationNo  IN  (SELECT TranslationNo FROM LanguageTranslation WHERE LanguageText like '%" & Me.FltrLanguageText.Text & "%')"
                End If
                If Me.UntranslatedOnly.Checked Then
                    listSQL += " AND l.TranslationNo  IN   (SELECT l3.TranslationNo FROM LanguageTranslation l3 WHERE l3.LanguageText =(SELECT l2.LanguageText FROM LanguageTranslation l2 WHERE l2.TranslationNo = l3.TranslationNo AND l2.LanguageName='English')  AND l3.LanguageName<>'English'"
                    If Me.FrenchAndEnglish.Checked Then listSQL += " And l3.LanguageName IN ('French')"
                    If Me.SpanishAndEnglish.Checked Then listSQL += " AND l3.LanguageName IN ('Spanish')"
                    listSQL += ") "
                End If
                If Me.FrenchAndEnglish.Checked Then listSQL += " And l.LanguageName IN ('French','English')"
                If Me.SpanishAndEnglish.Checked Then listSQL += " AND l.LanguageName IN ('Spanish','English')"
                listSQL += " ORDER BY CASE WHEN l.PageNumber=0 then 0 ELSE 1 END "
                listSQL += " ,pagenumber "
                listSQL += " ,(SELECT LanguageText FROM LanguageTranslation l2 WHERE l2.TranslationNo = l.TranslationNo AND l2.LanguageName='English')"
                listSQL += " ,TranslationNo "
                listSQL += " ,LanguageName "

                Dim TestSessionId As String = ""
                TestSessionId = uPage.db.DLookup("UserSessionId", "UserSession", "UserId>500000 AND StartDate = (SELECT MAX(StartDate) FROM UserSession WHERE UserId>500000)").ToString

                Dim listTable As DataTable = uPage.GetListDatatable(Me.txtPageNumber.Text, Me.txtRecordsToShow.Text, Me.lblPaging.Text, listSQL, uPage.PrimaryConnection)

                If listTable.Rows.Count <> 0 Then
                    'Populate Update field here as we alresdy have data.
                    Dim lastTranslationNo As Integer = 0
                    For Each row As DataRow In listTable.Rows
                        Dim translationRequired As Boolean = row("EnglishText") = row("LanguageText") And row("LanguageName") <> "English"
                        If lastTranslationNo <> row("TranslationNo") Then
                            html += "<td>" & row("TranslationNo")
                            If Not uPage.db.IsOnLiveServer Then html += " <a href=""../pages/pg040AuditLogDisplay.aspx?FltrUpdatedRecordFamily=ContentSet&FltrUpdatedRecordFamilyKey=" & row("TranslationNo") & """>Audit</a>"
                            html +="</td>"
                            If row("PageName") <> "" Then
                                '  html += "<td><a href=""" & row("PageName") & ".aspx" & IIf({70, 71, 117}.Contains(row("PageNumber")), "", "?UserSessionId=" & TestSessionId) & """ target=""_blank"">" & row("PageNumber") & "</a></td>"
                                html += "<td>" & row("PageName") & "</td>"
                            Else
                                html += "<td>" & row("PageNumber") & "</td>"

                            End If
                            html += "<td>" & Left(row("EnglishText"), 20) & "</td>"
                        Else
                            html += "<td>&nbsp;</td>"
                            html += "<td>&nbsp;</td>"
                            html += "<td>&nbsp;</td>"
                        End If


                        html += "<td" & IIf(translationRequired, " class=""sessionListHighlightRow""", "") & ">" & row("LanguageName") & "</td>"
                        html += "<td" & IIf(translationRequired, " class=""sessionListHighlightRow""", "") & ">" & row("LanguageText") & "</td>"
                        html += "<td><a href='javascript:SubmitCommandData(""Update_" & row("LanguageTranslationId").ToString & """)'>Update</a>"

                        html += "</tr>"
                        lastTranslationNo = row("TranslationNo")
                    Next
                Else
                    uPage.PageError = "No records match your selection criteria"
                End If
            Catch e As Exception
                uPage.PageError = e.ToString
            End Try
            'Assign grid to Label
            lblGridView.Text = html
        End If
    End Sub
    Private Sub btnFilter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFilter.Click
        Me.txtPageNumber.Text = 1
    End Sub
    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Response.Redirect(Request.ServerVariables("Path_Info"))
    End Sub
    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub
    Sub PageSetup()
        Me.SaveBtn.Enabled = Not uPage.db.IsOnLiveServer
        Me.SaveBtnExplanation.Text = "Language translations can only be updated on Test PaDD so they can be reviewed by Zedra before releasing to Live"
        Me.SaveBtnExplanation.Visible = uPage.db.IsOnLiveServer
        Dim emailAddress As String = uPage.db.IsDBNull(uPage.db.DLookup("EmailAddress", "RemoteUser", "UserId=" & Me.uPage.UserSession.UserId), "")
        Me.GetTranslationFileBtn.Visible = emailAddress.ToUpper.Contains("ZEDRA")
        Me.AuditLink.NavigateUrl = "../pages/pg040AuditLogDisplay.aspx?FltrUpdatedRecordFamily=LanguageTranslation&FltrUpdatedRecordFamilyKey=" & uPage.db.DLookup("TranslationNo", "LanguageTranslation", "LanguageTranslationId=" & Me.LanguageTranslationId)
        Me.AuditLink.Text = "View Audit"
        Me.ShowTranslationNoChk.Checked = uPage.db.GetParameterValue("ShowTranslationNo")
        BuildGrid()

        Me.UpdateLanguageTextRow.Visible = Me.LanguageTranslationId <> Nothing
    End Sub
    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        PageSetup()
        uPage.PagePreRender()
    End Sub


    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        Try
            If Me.LanguageTextUpdate.Text = "" Then
                uPage.FieldErrorControl(Me.LanguageTextUpdate, "Language Text is Mandatory")
            End If
            If uPage.IsValid Then
                Dim Sql As String = ""
                Sql += "UPDATE LanguageTranslation "
                Sql += " SET LanguageText = @LanguageText "
                Sql += "    , LastUpdatedDateTime = GetDate() "
                Sql += "    , LastUpdatedByUserId = @UserName20 "
                Sql += " WHERE LanguageTranslationId = " & Me.LanguageTranslationId

                Dim cmd As New SqlClient.SqlCommand(Sql, uPage.db.DBConnection, uPage.db.DBTransaction)
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LanguageText", System.Data.SqlDbType.VarChar, -1, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                             , Me.LanguageTextUpdate.Text))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName20", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default _
                                                                             , uPage.UserSession.UserName20))

                cmd.ExecuteNonQuery()
            End If
        Catch ex As Exception
            Me.uPage.PageError = "An unexpected error has occured. Please contact support." & ex.ToString
        End Try
        If Me.uPage.IsValid Then
            Me.LanguageTranslationId = Nothing
            Dim FilterUrl As String = Nothing
            If Me.FltrTranslationNo.Text <> "" Then
                FilterUrl += "&FltrTranslationNo=" & Me.FltrTranslationNo.Text
            End If
            If Me.FltrPageNumber.Text <> "" Then
                FilterUrl += "&FltrPageNumber=" & Me.FltrPageNumber.Text
            End If
            If Me.FltrEnglishText.Text <> "" Then
                FilterUrl += "&FltrEnglishText=" & Me.FltrEnglishText.Text
            End If
            If Me.FltrLanguageName.Text <> "" Then
                FilterUrl += "&FltrLanguageName=" & Me.FltrLanguageName.Text
            End If
            If Me.FltrLanguageText.Text <> "" Then
                FilterUrl += "&FltrLanguageText=" & Me.FltrLanguageText.Text
            End If

        End If

    End Sub
    Private Sub CancelBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelBtn.Click
        Me.LanguageTranslationId = Nothing
    End Sub

    Private Sub GetTranslationFileBtn_Click(sender As Object, e As EventArgs) Handles GetTranslationFileBtn.Click
        Try
            Dim su As New BusinessLogic.PaDSSupportUtilities(uPage.db)
            su.GetTranslationFile()
        Catch ex As Exception
            uPage.PageError = "GetTranslationFileBtn_Click Failed:" & ex.Message
        End Try
    End Sub

    Private Sub ShowTranslationNoChk_CheckedChanged(sender As Object, e As EventArgs) Handles ShowTranslationNoChk.CheckedChanged
        Try
            uPage.db.SetParameterValue("ShowTranslationNo", ShowTranslationNoChk.Checked)
        Catch ex As Exception
            uPage.PageError = "ShowTranslationNoChk_CheckedChanged Failed:" & ex.Message
        End Try
    End Sub
End Class
