﻿Imports System.Data.SqlClient
Imports System.Data

'Modification History
'31/01/11  Julian Gates   Initial version
'31/3/11    James Woosnam   SIR2401 - Use the company specific address if available else use latest address
'03/10/14   Julian Gates    SIR3621 - Add IsReceive Mail field to Function GetSQL
'16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number and Fax fields and associated code
'21/2/21		James Woosnam	SIR5205 - Add AffiliateRateSubscriberName & AffiliateRateSubscriberType
'13/1/22    james Woosnam   SIR5388 - Remove IsReceive Mail/EmailOpt Out column
'6/7/22     James Woosnam   SIR5526 - Add fields to indicate status of subscriptions to PEPWEBS, PEPWeb or Pepweb3y
'9/8/22 James Woosnam   SIR5546 - Show line for Any pep subscription and filter out non-current products
'18/5/23    Julian Gates    SIR5652 - Change Country selection to be dev express multiple selection list.
'24/5/23    James Woosnam   SIR5642 - Create Pending Bulk Email For Report Subscribers

Partial Class Pages_pg460SubscriberMailingreport
    Inherits System.Web.UI.Page
    Public uPage As UserPage
    Dim _tblProducts As DataTable = Nothing

    Public ReadOnly Property tblProducts As DataTable
        Get
            If Me._tblProducts Is Nothing Then
                '9/8/22 James Woosnam   SIR5546 - Show line for Any pep subscription and filter out non-current products
                Dim SQL As String = "SELECT * FROM " _
                  & "(SELECT ProductDescription = 'Any PEP Archive Product (PEPWeb,PEPWebs or PEPwbb3y)'" _
                  & "  ,productCode  = 'AnyPEPArchiveProducts' " _
                  & "  ,OrderBy  = 0) a" _
                  & " UNION " _
                  & "(SELECT ProductDescription = ISNULL(Company.RegisteredOfficeName,Company.CompanyName) + ' - '  + Parent.productCode + ' - ' + Parent.productName" _
                  & "	    ,Parent.productCode" _
                  & "       ,OrderBy  = 1" _
                  & "	FROM Product" _
                  & "		INNER JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                  & "		ON Company.CompanyId = Product.CompanyId" _
                  & "		INNER JOIN Product Parent" _
                  & "		On Parent.ProductCode = Product.ParentProductCode" _
                  & " WHERE Product.IsForReporting <> 0" _
                  & IIf(Me.ShowCurrentProductsOnly.Checked, " AND Product.ProductStatus='Current'", "") _
                  & "	GROUP BY ISNULL(Company.RegisteredOfficeName,Company.CompanyName) + ' - '  + Parent.productCode + ' - ' + Parent.productName" _
                  & "	    ,Parent.productCode) " _
                  & " ORDER By OrderBy,1"
                Me._tblProducts = uPage.db.GetDataTableFromSQL(SQL)
            End If
            Return Me._tblProducts
        End Get
    End Property
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        uPage = New UserPage(Me, "Subscriber Mailing Report", "")
        Me.pageHeaderTitle.Text = "Subscriber Mailing Report"

        _tblProducts = Nothing 'rest evry time incase flg chnges
        If Page.IsPostBack Then

        Else
            ReadRecord()
            If Request.QueryString("InfoMsg") <> "" Then
                InfoMsg.Text = Request.QueryString("InfoMsg")
            End If

            Me.UpdateTimer.Enabled = False

        End If

    End Sub

    Sub PageSetup()
        GetProductListHTML()
    End Sub

    Sub ReadRecord()
        '******************************************************
        'Description:	Read the record
        '******************************************************
        Dim sql As String = ""
        'Populate all dropdown fields
        Dim dropDownIntialValue As String = "<---------Select--------->"
        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria
        '18/5/23    Julian Gates    SIR5652 - Change Country selection to be dev express multiple selection list.
        sql = "SELECT Country.CountryId as Value, Country.CountryName as Text From Country ORDER BY 2"
        uPage.PopulateDevExpressListBoxSQL(Me.CountryId, sql, Nothing)

        '03/12/15   Julian Gates    SIR3972 - Add LookupStatus = Active criteria
        uPage.PopulateDropDownListFromSQL(Me.AccountType, "SELECT Lookup.LookupItemKey as Value" _
                                                           & "    ,Name + ' (' + Company.CompanyName + ')' as Text" _
                                                           & " FROM Lookup" _
                                                           & "		INNER JOIN " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                                                           & "		ON Company.CompanyId = Lookup.CompanyId" _
                                                           & " WHERE LookupName = 'AccountType'" _
                                                           & " AND LookupStatus = 'Active'" _
                                                           & " ORDER BY  CompanyName,Lookup.DisplayOrder" _
                                                           , uPage.PrimaryConnection, dropDownIntialValue
                                                           )

        uPage.PopulateDropDownListFromSQL(Me.CurrencyCode, "SELECT Currency.CurrencyCode as Value" _
                                                           & "    ,Currency.Description as Text" _
                                                           & " FROM Currency" _
                                                           & " ORDER BY 2" _
                                                           , uPage.PrimaryConnection, dropDownIntialValue
                                                           )
        '17/4/17    James Woosnam   Remove hard coded userId=34 from SQL below
        uPage.PopulateDropDownListFromSQL(Me.CompanyId, "SELECT Company.CompanyId as Value" _
                                                            & "    ,Company.CompanyName as Text" _
                                                            & " FROM " & uPage.CompanyTable("Company", uPage.UserSession.UserId) _
                                                            & " ORDER BY 2" _
                                                            , uPage.PrimaryConnection, dropDownIntialValue
                                                            )
        ' Default company If only one 
        If Me.CompanyId.Items.Count = 2 Then
            Me.CompanyId.SelectedValue = Me.CompanyId.Items(1).Value
            Me.CompanyId.Items.Remove(CompanyId.Items.FindByText(dropDownIntialValue))
        End If

    End Sub

    Private Sub PageSetupValidators(ByVal validatorStatus As String, Optional ByVal enableClientSideValidation As Boolean = True)
        '******************************************************
        'Description:	Setup and enable any page validators
        '******************************************************
        If enableClientSideValidation Then
        Else
        End If
    End Sub

    Private Function IsPageValidForStatus(Optional ByVal validatorStatus As String = "") As Boolean
        '******************************************************
        'Description:	Validate page fields and show error message
        '******************************************************
        Select Case validatorStatus
            Case Else
                If Me.ShowAccounts.Checked Then
                    If Me.CompanyId.SelectedValue = "" Then
                        uPage.FieldErrorControl(Me.CompanyId, "Company is mandatory")
                    End If
                End If

                If Me.DateInDebt.Text.Trim <> "" Then
                    If Not uPage.StdCode.IsValidDate(Me.DateInDebt.Text) Then
                        uPage.FieldErrorControl(Me.DateInDebt, "Date In Debt is an invalid date")
                    End If
                End If
                If GetSelectedNotSubscribedProducts.Rows.Count = 0 And GetSelectedSubscribedProducts.Rows.Count = 0 Then
                    uPage.PageError = "You must select at least one product."
                End If
                If GetSelectedSubscribedProducts.Rows.Count <> 1 And Me.IncludeReportingParentFields.Checked Then
                    uPage.FieldErrorControl(Me.IncludeReportingParentFields, "Include ReportingParent Fields only works if only one 'Subecribered to Product' selected")
                End If
                If Me.CreatePendingBulkEmailForReportSubscribers.Checked AndAlso Me.CompanyId.SelectedValue = "" Then
                    uPage.FieldErrorControl(Me.CompanyId, "You must select a company to use the create bulk email facility.")
                    uPage.FieldErrorControl(Me.CreatePendingBulkEmailForReportSubscribers, "")

                End If

        End Select
        Return uPage.IsValid
    End Function

    Private Sub Page_Unload(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Unload
        'Closes any connections if open
        Try
            uPage.PageUnload()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Page_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Error
        uPage.HandlePageError()
    End Sub

    Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
        PageSetup()
        uPage.PagePreRender()
    End Sub

    Private Sub SubmitReportBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubmitReportBtn.Click
        Me.InfoMsg.Text = ""
        If Me.IsPageValidForStatus("") Then
            Try
                Dim SingleBlockSubscriberId As Integer = IIf(Me.SingleBlockSubscriberId.Text = "", Nothing, Me.SingleBlockSubscriberId.Text)
                '18/5/23    Julian Gates    SIR5652 - Convert CountryId to string populated from GetCountrySelectedItems
                Dim CountryId As String = GetCountrySelectedItems(Me.CountryId)
                Dim DateInDebt As Date = IIf(Me.DateInDebt.Text = "", Nothing, Me.DateInDebt.Text)

                Dim sql As String = ""
                sql = GetSQL("Run" _
                             , IIf(Me.CompanyId.SelectedValue = "", 0, Me.CompanyId.SelectedValue) _
                             , SingleBlockSubscriberId _
                             , Me.AllBlockSubscribers.Checked _
                             , CountryId _
                             , Me.City.Text _
                             , DateInDebt _
                             , Me.CurrencyCode.SelectedValue _
                             , Me.ShowAccounts.Checked _
                             , Me.AccountType.SelectedValue
                            )
                Dim tSubs As DataTable = uPage.db.GetDataTableFromSQL(sql)
                If tSubs.Rows.Count = 0 Then
                    uPage.PageError = "Your selections will not return any subscribers."
                    Exit Sub
                End If
                Dim report As BusinessLogic.ReportGeneric = Nothing
                report = New BusinessLogic.ReportGeneric("Subscriber Mailing " & Now().Date.ToString("yyyy-MM-dd"), "GenericExcel", uPage.db, Me.uPage.UserSession.UserSessionIdGUID)
                report.FileName = report.ReportName
                report.Submit("GenericExcel.xlsx", sql, sql)

                '24/5/23    James Woosnam   SIR5642 - Create Pending Bulk Email For Report Subscribers
                If Me.CreatePendingBulkEmailForReportSubscribers.Checked Then
                    Dim em As New BusinessLogic.EmailDistribution(uPage.db, uPage.UserSession)
                    em.AddNewEmailDistribution("Subscriber Mailing Report " & Now.ToString("yyyy-MM-dd"), BusinessLogic.EmailDistribution.SubscriberSourceTypes.EnteredEmailAddressList, "", Me.CompanyId.SelectedValue)
                    For Each rSub As DataRow In tSubs.Rows
                        em.EmailDistributionRow("SubscriberIdList") += IIf(uPage.db.IsDBNull(em.EmailDistributionRow("SubscriberIdList"), "") = "", "", ",") & uPage.db.DLookup("SubscriberId", "SubscriberAddress", "AddressType = 'Email' AND AddressDescription = 'Main' AND AddressText='" & rSub("EmailAddress") & "'")
                        em.EmailDistributionRow("EnteredSubscriberListText") += IIf(uPage.db.IsDBNull(em.EmailDistributionRow("EnteredSubscriberListText"), "") = "", "", Environment.NewLine) & rSub("EmailAddress")
                    Next
                    em.Save()

                    Me.InfoMsg.Text += "New  EmailDistribution created.  <a href=""pg291EmailDistributionMaint.aspx?EmailDistributionId=" & em.EmailDistributionId & """ >Click Here</a> to open.<br>"
                End If
                ViewState("BatchJobId") = report.BatchJob.BatchJobId

                Me.InfoMsg.Text += "Report has been submitted as batchjob, if you wish to view the batchlog please use the Batchlog link in main menu."
                Me.UpdateTimer.Enabled = True
            Catch ex As Exception
                uPage.PageError = "There was an unexpected problem generating this report.  Please contact support." & ex.ToString
                Me.UpdateTimer.Enabled = False
            End Try
        End If
    End Sub
    '18/5/23    Julian Gates    SIR5652 - Adde GetCountrySelectedItems
    Function GetCountrySelectedItems(ByRef Field As DevExpress.Web.ASPxListBox) As String
        Dim items As String = Nothing
        Dim i As Long = 0
        Dim comma As String = ""
        Try
            Do While i < Field.Items.Count
                If Field.Items(i).Selected Then
                    items += comma + Field.Items(i).Value.ToString
                    comma = ","
                End If
                i = i + 1
            Loop
        Catch ex As Exception
            uPage.PageError = "An Unexpected error has occured.  Please contact support" & ex.ToString
        End Try
        Return items
    End Function

    Sub GetProductListHTML()
        'Builds two lists of products depending on the users company access
        Dim strSQL As String = ""
        Dim html As String = ""


        Try
            html += "<table  border='1' cellpadding='5' class='selectTable'>"
            html += "  <tr>"
            html += "    <td colspan='2' class='fldTitle'>Subscribed to Products</td>"
            html += "    <td colspan='2' class='fldTitle'>Not Subscribed Products</td>"
            html += "  </tr>"

            For Each row As DataRow In tblProducts.Rows
                html += "  <tr>"
                html += "	    <td class='fldView'>" & uPage.StdCode.IsNull(row("ProductDescription"), "&nbsp;") & "</td>"
                html += "       <td><input id=""cbxSubscribed" & row("ProductCode") & """ name=""cbxSubscribed" & row("ProductCode") & """ type=""checkbox"""
                For Each row1 As DataRow In GetSelectedSubscribedProducts.Rows
                    If uPage.StdCode.IsNull(row("ProductCode"), "") = row1("ProductCode") Then
                        html += " Checked "
                    End If
                Next
                html += "</input></td>"
                html += "	<td class='fldView'>" & uPage.StdCode.IsNull(row("ProductDescription"), "&nbsp;") & "</td>"
                html += "       <td><input id=""cbxNotSubscribed" & row("ProductCode") & """ name=""cbxNotSubscribed" & row("ProductCode") & """ type=""checkbox"""
                For Each row2 As DataRow In GetSelectedNotSubscribedProducts.Rows
                    If uPage.StdCode.IsNull(row("ProductCode"), "") = row2("ProductCode") Then
                        html += " Checked "
                    End If
                Next
                html += "</input></td>"
                html += "  </tr>"
            Next
            html += "</table>"

            Me.ProductsList.Text = html

        Catch ex As Exception
            uPage.PageError = "An Unexpected error has occured.  Please contact support" & ex.ToString
        End Try

    End Sub

    Function GetSelectedSubscribedProducts() As DataTable
        Dim SelectedSubscribedProductsTable As New DataTable("SelectedSubscribedProductsTable")
        Dim columnAdded As Boolean = False
        Try
            For Each row As DataRow In tblProducts.Rows
                If Request.Form.Item("cbxSubscribed" & row("ProductCode")) = "on" Then
                    If columnAdded = False Then
                        SelectedSubscribedProductsTable.Columns.Add("ProductCode")
                        columnAdded = True
                    End If
                    Dim row1 As DataRow = SelectedSubscribedProductsTable.NewRow
                    row1.Item("ProductCode") = row("ProductCode")
                    SelectedSubscribedProductsTable.Rows.Add(row1)
                End If
            Next
        Catch ex As Exception
            uPage.PageError = "An Unexpected error has occured.  Please contact support" & ex.ToString
        End Try

        Return SelectedSubscribedProductsTable
    End Function

    Function GetSelectedNotSubscribedProducts() As DataTable
        Dim SelectedNotSubscribedProductsTable As New DataTable("SelectedNotSubscribedProductsTable")
        Dim columnAdded As Boolean = False
        Try
            For Each row As DataRow In tblProducts.Rows
                If Request.Form.Item("cbxNotSubscribed" & row("ProductCode")) = "on" Then
                    If columnAdded = False Then
                        SelectedNotSubscribedProductsTable.Columns.Add("ProductCode")
                        columnAdded = True
                    End If
                    Dim row2 As DataRow = SelectedNotSubscribedProductsTable.NewRow
                    row2.Item("ProductCode") = row("ProductCode")
                    SelectedNotSubscribedProductsTable.Rows.Add(row2)
                End If
            Next
        Catch ex As Exception
            uPage.PageError = "An Unexpected error has occured.  Please contact support" & ex.ToString
        End Try

        Return SelectedNotSubscribedProductsTable
    End Function

    '03/10/14   Julian Gates    SIR3621 - Add IsReceive Mail field to report
    '18/5/23    Julian Gates    SIR5652 - Change CountryId to string and change SQL to IN statement for country
    Private Function GetSQL(ByVal SQLType As String _
               , ByVal CompanyId As Integer _
               , ByVal SingleBlockSubscriberId As Integer _
               , ByVal AllBlockSubscribers As Boolean _
               , ByVal CountryId As String _
               , ByVal City As String _
               , ByVal DateInDebt As Date _
               , ByVal CurrencyCode As String _
               , ByVal ShowAccounts As Boolean _
               , ByVal AccountType As String
                  ) As String
        Dim sqlColumns As String = ""
        Dim sqlFrom As String = ""
        Dim sqlWhere As String = ""
        Dim sqlGroup As String = ""
        Dim sqlOrderBy As String = ""
        Dim line As String = System.Environment.NewLine

        Dim companiesCSV As String = Nothing

        For Each row As DataRow In uPage.db.GetDataTableFromSQL("SELECT Company.CompanyId FROM dbo.f530SecureCompany(" & uPage.UserSession.UserId & ") Company").Rows
            companiesCSV += IIf(companiesCSV <> Nothing, ",", "") & row("CompanyId")
        Next

        sqlFrom = " FROM " & uPage.SubscriberTable("Subscriber") & line

        sqlWhere = " WHERE Subscriber.SubscriberStatus='Current'" & line
        sqlFrom = sqlFrom + "	INNER JOIN SubscriberAffiliate" & line _
             & "			INNER JOIN Company" & line _
             & "			ON Company.CompanyId IN (" & companiesCSV & ")" & line _
             & "			AND Company.GroupParentSubscriberId = SubscriberAffiliate.ParentSubscriberId" & line _
             & "		ON SubscriberAffiliate.ChildSubscriberId = Subscriber.SubscriberId" & line _
             & "		AND GetDate() BETWEEN SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate" & line
        '''''''''''''''''''''''''''''''''''''''''''
        If Not SingleBlockSubscriberId = Nothing _
        Or AllBlockSubscribers _
        Then
            sqlFrom = sqlFrom + "	INNER JOIN SubscriberAffiliate SubAfflForBlocks" & line _
                 & "		ON SubAfflForBlocks.ChildSubscriberId = Subscriber.SubscriberId" & line _
                 & "		AND GetDate() BETWEEN SubAfflForBlocks.StartDate AND SubAfflForBlocks.EndDate" & line _
                 & "		INNER JOIN Subscriber SubAfflParentSubscriber" & line _
                 & "		ON SubAfflParentSubscriber.SubscriberId = SubAfflForBlocks.ParentSubscriberId" & line _
                 & "		INNER JOIN CompanyAccount SubAfflParentCompAcct" & line _
                 & "		ON SubAfflParentCompAcct.SubscriberId = SubAfflForBlocks.ParentSubscriberId" & line
        End If
        If AllBlockSubscribers Then
            sqlFrom = sqlFrom + "	    AND SubAfflParentCompAcct.AccountType ='Society'" & line

        End If
        If Not SingleBlockSubscriberId = Nothing Then
            sqlWhere = sqlWhere + " AND SubAfflForBlocks.ParentSubscriberId = " & SingleBlockSubscriberId & line
        End If

        '18/5/23    Julian Gates    SIR5652 - Change CountryId to string and change SQL to In statement for country
        If Not CountryId = Nothing Then
            sqlFrom = sqlFrom + "	INNER JOIN Country CountryCheck" & line _
                 & "		ON CountryCheck.CountryId = Subscriber.PrimaryCountryId" & line _
                 & "		AND CountryCheck.CountryId In (" & CountryId & ")" & line
        End If

        If City <> "" Then
            sqlFrom = sqlFrom + "	INNER JOIN SubscriberAddress CityCheck" & line _
                 & "		ON CityCheck.SubscriberId = Subscriber.SubscriberId" & line _
                 & "		AND CityCheck.AddressType = 'Postal'" & line _
                 & "		AND CityCheck.Town = " & uPage.db.vFQ(City, "S") & line
        End If
        If Not DateInDebt = Nothing Then
            sqlFrom = sqlFrom + "   INNER JOIN vw420SubscriberTransactionsDetails TranA" & line _
                               & "    ON TranA.SubscriberId = Subscriber.SubscriberId" & line _
                               & "    AND TranA.CompanyId = " & CompanyId & line _
                               & "    AND TranA.CurrencyCode = " & uPage.db.vFQ(CurrencyCode, "S") _
                               & "	AND TranA.[Date] <= " & uPage.db.vFQ(DateInDebt, "D") & line _
                               & "	AND 0 <> (SELECT SUM(AmountInNative) " & line _
                & "			  FROM vw420SubscriberTransactionsDetails TranB" & line _
                & "			  WHERE TranB.SubscriberId = TranA.SubscriberId " & line _
                & "			  AND TranB.CompanyId = TranA.CompanyId " & line _
                & "			  AND TranB.[Date] <= " & uPage.db.vFQ(DateInDebt, "D") & line _
                & "			  AND TranB.CurrencyCode = TranA.CurrencyCode" & line _
                & "			  )	" & line
        End If
        If ShowAccounts Or Not DateInDebt = Nothing Then
            'join to account to restrict to just accounts
            sqlFrom = sqlFrom + "   INNER JOIN CompanyAccount" & line _
                               & "    ON CompanyAccount.SubscriberId = Subscriber.SubscriberId" & line _
                               & "    AND CompanyAccount.CompanyId = " & CompanyId & line
        End If
        Dim lngJoinCount As Integer = 1
        If GetSelectedSubscribedProducts.Rows.Count > 0 Then
            For Each row As DataRow In GetSelectedSubscribedProducts.Rows
                sqlFrom += "	INNER JOIN SalesorderLine SOL" & lngJoinCount & line
                sqlFrom += "			INNER JOIN SalesOrder SO" & lngJoinCount & line
                If lngJoinCount = 1 Then
                    sqlFrom += "			    INNER JOIN Subscriber pSub" & line
                    sqlFrom += "			    ON pSub.SubscriberId = SO" & lngJoinCount & ".SubscriberId" & line
                End If
                If AccountType <> "" Then
                    sqlFrom = sqlFrom + "   INNER JOIN CompanyAccount CA" & lngJoinCount & line _
                                       & "    ON CA" & lngJoinCount & ".SubscriberId = SO" & lngJoinCount & ".SubscriberId" & line _
                                       & "    AND CA" & lngJoinCount & ".CompanyId = SO" & lngJoinCount & ".CompanyId" & line _
                                       & "    AND CA" & lngJoinCount & ".AccountType= " & uPage.db.vFQ(AccountType, "S") & line
                End If
                sqlFrom += "			On SO" & lngJoinCount & ".OrderNumber = SOL" & lngJoinCount & ".OrderNumber" & line
                sqlFrom += "			AND SO" & lngJoinCount & ".SalesorderStatus IN ('Confirmed','Complete')" & line
                If Me.IncludeReportingParentFields.Checked Then
                    '21/2/21		James Woosnam	SIR5205 - Add AffiliateRateSubscriberName & AffiliateRateSubscriberType
                    '8/3/21     James Woosnam   SIR5045 - For consistancy get AffiliateRateSubscriberName from vw430SalesDetails
                    '21/3/22	James Woosnam	SIR5463 - Change AffiliateRateSubscriber to ReportingParentSubscriber 
                    sqlFrom += "			Left Join(SELECT so.OrderNumber " & line
                    sqlFrom += "							,ReportingParentSubscriberName = MAX(so.ReportingParentSubscriberName )" & line
                    sqlFrom += "							,ReportingParentType = MAX(so.ReportingParentType )" & line
                    sqlFrom += "						From vw430SalesDetails so" & line
                    sqlFrom += "						Group By so.OrderNumber ) afflSub" & line
                    sqlFrom += "			On afflSub.OrderNumber = sol1.OrderNumber " & line
                End If
                sqlFrom += "		ON SOL" & lngJoinCount & ".SubscriberId = Subscriber.SubscriberId" & line
                '9/8/22 James Woosnam   SIR5546 - Show line for Any pep subscription and filter out non-current products
                If row("ProductCode") = "AnyPEPArchiveProducts" Then
                    sqlFrom += "		AND SOL" & lngJoinCount & ".ProductCode IN ('PEPWeb','PEPWebs','PEPwbb3y')" & line
                Else
                    sqlFrom += "		AND SOL" & lngJoinCount & ".ProductCode = " & uPage.db.vFQ(row("ProductCode"), "S") & line
                End If
                sqlFrom += "		" & line
                If Not SingleBlockSubscriberId = Nothing _
                Or AllBlockSubscribers = True _
                Then
                    sqlWhere += " AND SubAfflForBlocks.ParentSubscriberId = SO" & lngJoinCount & ".SubscriberId" & line
                    sqlWhere += " AND SubAfflParentCompAcct.CompanyId = SO" & lngJoinCount & ".CompanyId" & line

                End If
                lngJoinCount = lngJoinCount + 1

            Next

        Else
            If AccountType <> "" Then
                sqlFrom = sqlFrom + "   INNER JOIN CompanyAccount" & line _
                                   & "    ON CompanyAccount.SubscriberId = Subscriber.SubscriberId" & line _
                                   & "    AND CompanyAccount.AccountType= " & uPage.db.vFQ(AccountType, "S") & line
            End If
        End If
        For Each row As DataRow In GetSelectedNotSubscribedProducts.Rows
            sqlFrom += "	LEFT JOIN SalesorderLine SOL" & lngJoinCount & line
            sqlFrom += "			INNER JOIN SalesOrder SO" & lngJoinCount & line
            sqlFrom += "			On SO" & lngJoinCount & ".OrderNumber = SOL" & lngJoinCount & ".OrderNumber" & line
            sqlFrom += "			AND SO" & lngJoinCount & ".SalesorderStatus IN ('Confirmed','Complete')" & line
            sqlFrom += "		ON SOL" & lngJoinCount & ".SubscriberId = Subscriber.SubscriberId" & line
            '9/8/22 James Woosnam   SIR5546 - Show line for Any pep subscription and filter out non-current products
            If row("ProductCode") = "AnyPEPArchiveProducts" Then
                sqlFrom += "		AND SOL" & lngJoinCount & ".ProductCode IN ('PEPWeb','PEPWebs','PEPwbb3y')" & line
            Else
                sqlFrom += "		AND SOL" & lngJoinCount & ".ProductCode = " & uPage.db.vFQ(row("ProductCode"), "S") & line
            End If
            sqlFrom += "		" & line
            sqlWhere = sqlWhere + " AND SOL" & lngJoinCount & ".SubscriberId Is Null" & line
            lngJoinCount = lngJoinCount + 1
        Next
        sqlGroup = " GROUP BY Subscriber.SubscriberId" & line

        Select Case SQLType
            Case "Check"
                sqlColumns = "SELECT Subscriber.SubscriberId " & line
                Return sqlColumns & sqlFrom & sqlWhere & sqlGroup & sqlOrderBy

            Case "Run"
                '31/3/11    James Woosnam   SIR2401 - Use the company specific address if available else use latest address
                '16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number and Fax fields and associated code
                sqlFrom = sqlFrom _
                       & "	Left JOIN SubscriberAddress" & line _
                       & " 		LEFT JOIN Country" & line _
                       & " 		ON Country.CountryId = SubscriberAddress.CountryId" & line _
                       & " 	ON SubscriberAddress.SubscriberAddressId = (SELECT top 1 sa.SubscriberAddressId" & line _
                       & " 											FROM SubscriberAddress sa" & line _
                       & "                                           WHERE(sa.SubscriberId = Subscriber.SubscriberId)" & line _
                       & "											AND sa.AddressType = 'Postal'" & line _
                       & " 											AND sa.AddressDescription <> 'Redundant'" & line _
                       & " 											Order BY sa.LastUpdatedDateTime desc" & line _
                       & " 											)" & line _
                       & " 	Left JOIN SubscriberAddress Email" & line _
                       & " 	ON Email.SubscriberId = Subscriber.SubscriberID" & line _
                       & " 	AND Email.AddressType = 'Email'" & line _
                       & " 	AND Email.AddressDescription = 'Main'" & line

                sqlColumns = "SELECT  " & line
                If Not SingleBlockSubscriberId = Nothing Then
                    sqlColumns = sqlColumns & "	MIN(SubAfflForBlocks.AffiliateReferenceID) as AffiliateReferenceID" & line
                Else
                    sqlColumns = sqlColumns & "	MIN(Subscriber.SubscriberId) as AffiliateReferenceID" & line
                End If
                sqlColumns = sqlColumns & " ,SubscriberCategory = MIN(SubscriberAffiliate.SubscriberCategory) " & line
                If Not SingleBlockSubscriberId = Nothing Then
                    sqlColumns = sqlColumns & "	,SubAfflParentSubscriber.SubscriberName as ParentSubscriberName" & line
                Else
                    If GetSelectedSubscribedProducts.Rows.Count = 0 Then
                        sqlColumns += "	,'' as ParentSubscriberName" & line 'could be many different parents for all blocks
                    Else
                        sqlColumns += "	,MAX(pSub.SubscriberName) as ParentSubscriberName" & line 'use  order of first selected product
                    End If

                End If
                If IncludeReportingParentFields.Checked And GetSelectedSubscribedProducts.Rows.Count > 0 Then
                    '21/2/21		James Woosnam	SIR5205 - Add AffiliateRateSubscriberName & AffiliateRateSubscriberType
                    sqlColumns += "	,ReportingParentSubscriberName = MAX(afflSub.ReportingParentSubscriberName)" & line
                    sqlColumns += "	,ReportingParentType = MAX(afflSub.ReportingParentType)" & line
                End If
                '03/10/14   Julian Gates    SIR3621 - Add IsReceive Mail field to report
                '16/05/19   Julian Gates    SIR4759 - Removed Home and work telephone number and Fax fields and associated code
                '6'12'19    James Woosnam   SIR4959 - remove webuser name
                '13/1/22    james Woosnam   SIR5388 - Remove IsReceive Mail/EmailOpt Out column

                sqlColumns = sqlColumns _
                  & "		, Subscriber.FirstName AS FirstName" & line _
                  & "		, Subscriber.LastName AS LastName" & line _
                  & "		, SubscriberAddress.Address1 AS Address1" & line _
                  & "		, SubscriberAddress.Address2 AS Address2" & line _
                  & "		, SubscriberAddress.Address3 AS Address3" & line _
                  & "		, SubscriberAddress.Address4 As Address4" & line _
                  & "		, SubscriberAddress.Town AS Town" & line _
                  & "		, SubscriberAddress.County As County" & line _
                  & "		, SubscriberAddress.PostCode AS PostCode" & line _
                  & "		, Country.CountryName As CountryName" & line _
                  & "		, Email.AddressText As EmailAddress" & line
                '6/7/22 James Woosnam   SIR5526 - Add fields to indicate status of subscriptions to PEPWEBS, PEPWeb or Pepweb3y
                sqlColumns += ",PEPHasActiveSubsription=CASE WHEN (SELECT MAX(lP.RecurringSubscriptionEndDate) FROM SalesOrderLine lP INNER JOIN SalesOrder oP ON oP.OrderNumber= lP.OrderNumber And oP.SalesOrderStatus IN ('Confirmed','Complete') WHERE lP.SubscriberId= Subscriber.SubscriberId AND lP.IsCancel<>1 AND lp.ProductCode IN ('PEPWeb','PEPWebs','PEPwbb3y')) > GETDATE() THEN 'Y' ELSE 'N' END" & line
                sqlColumns += ",PEPSubscriptionEndDate=FORMAT((SELECT MAX(lP.RecurringSubscriptionEndDate) FROM SalesOrderLine lP INNER JOIN SalesOrder oP ON oP.OrderNumber= lP.OrderNumber And oP.SalesOrderStatus IN ('Confirmed','Complete') WHERE lP.SubscriberId= Subscriber.SubscriberId AND lP.IsCancel<>1 AND lp.ProductCode IN ('PEPWeb','PEPWebs','PEPwbb3y')),'dd-MMM-yyyy')" & line


                If Not DateInDebt = Nothing Then
                    sqlColumns = sqlColumns & "	,SUM(AmountInNative) AS Debt" & line
                End If

                sqlGroup = "GROUP BY Subscriber.SubscriberId " & line
                If Not SingleBlockSubscriberId = Nothing Then
                    sqlGroup += "	,SubAfflParentSubscriber.SubscriberName" & line
                End If
                '6'12'19    James Woosnam   SIR4959 - remove webuser name
                sqlGroup += "		 ,Subscriber.FirstName" & line _
                  & "		, Subscriber.LastName" & line _
                  & "		, SubscriberAddress.Address1 " & line _
                  & "		, SubscriberAddress.Address2 " & line _
                  & "		, SubscriberAddress.Address3 " & line _
                  & "		, SubscriberAddress.Address4 " & line _
                  & "		, SubscriberAddress.Town " & line _
                  & "		, SubscriberAddress.County " & line _
                  & "		, SubscriberAddress.PostCode " & line _
                  & "		, Country.CountryName " & line _
                  & "		, Email.AddressText " & line
                Return sqlColumns & sqlFrom & sqlWhere & sqlGroup & sqlOrderBy
            Case Else
                Return ""
        End Select
    End Function

    Protected Sub UpdateTimer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles UpdateTimer.Tick
        Try
            If IsNumeric(ViewState("BatchJobId")) Then
                Dim BatchLog As New BusinessLogic.BatchLog(uPage.db)
                Me.BatchLogLines.Text = BatchLog.GetBatchLogLinesHTML(ViewState("BatchJobId"))
                Select Case uPage.db.IsDBNull(uPage.db.DLookup("MAX(BatchLogStatus)", "BatchLog", "BatchJobId=" & ViewState("BatchJobId")), "")
                    Case "Complete", "Failed"
                        Me.UpdateTimer.Enabled = False
                    Case Else
                        Me.UpdateTimer.Enabled = True
                End Select
            Else
                Me.UpdateTimer.Enabled = False
            End If
        Catch ex As Exception
            uPage.PageError = ex.Message
        End Try
    End Sub
End Class
