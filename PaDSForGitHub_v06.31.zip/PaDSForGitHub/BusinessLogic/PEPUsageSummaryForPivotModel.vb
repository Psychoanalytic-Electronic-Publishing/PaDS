Imports System
Imports System.ComponentModel.DataAnnotations.Schema
Imports System.Data.Entity
Imports System.Linq

Partial Public Class PEPUsageSummaryForPivotModel
    Inherits DbContext

    Public Sub New()
        MyBase.New("name=PEPUsageSummaryForPivotModel")
    End Sub

    Public Overridable Property vw458PEPUsageSummaryForPivot As DbSet(Of vw458PEPUsageSummaryForPivot)

    Protected Overrides Sub OnModelCreating(ByVal modelBuilder As DbModelBuilder)
        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.ReportingParentSubscriberName) _
            .IsUnicode(False)

        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.ReportingParentType) _
            .IsUnicode(False)

        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.LoggedInMethod) _
            .IsUnicode(False)

        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.UserName) _
            .IsUnicode(False)

        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.UserFullName) _
            .IsUnicode(False)

        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.UserCountry) _
            .IsUnicode(False)

        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.MediaType) _
            .IsUnicode(False)

        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.PEPCode) _
            .IsUnicode(False)

        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.DocumentVolume) _
            .IsUnicode(False)

        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.DocumentYear) _
            .IsUnicode(False)

        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.documentRef) _
            .IsUnicode(False)

        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.authorMast) _
            .IsUnicode(False)

        modelBuilder.Entity(Of vw458PEPUsageSummaryForPivot)() _
            .Property(Function(e) e.ArchiveOrCurrent) _
            .IsUnicode(False)
    End Sub
End Class
