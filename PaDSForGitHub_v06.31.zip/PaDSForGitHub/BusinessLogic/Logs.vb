﻿'Updates
'======
'22/5/11        James Woosnam   HotFix - Open Logs with UserSession and Log Primary/Seconday Info
'6/11/11    James Woosnam   Hotfix - Set SessionId to "????" if null to avoid error email
'05/12/19	James Woosnam	SIR4769 - WritePEPWebUsageLog SubscriberName is no longer recorded, UserName is only passwd into here for failed logons, otherwise the UserId is passed in
'05/12/19	James Woosnam	SIR4769 - WriteSessionLog no longer record UserName 
Imports Microsoft.Office.Interop
Imports System.Data.SqlClient
Public Class Logs

#Region "Class Properties"
    Public UserSession As UserSession

    Private _db As BusinessLogic.Database = Nothing
    Public Property db() As BusinessLogic.Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As BusinessLogic.Database)
            'For batch log create a new connection so the log remains even if the tans is rolled back
            Me._db = value

        End Set
    End Property
#End Region

    Public Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As UserSession)
        Me.db = db
        Me.UserSession = UserSession
    End Sub

    Public Sub WriteSessionLog(ByVal LogType As String _
                               , ByVal PageId As String _
                               , ByVal PageTitle As String _
                               , ByVal UserId As String _
                               , ByVal UserName As String _
                               , ByVal RemoteIPAddress As String _
                               , ByVal Comment As String _
                               , ByVal IsReadOnlyOnSecondary As Boolean _
                               , ByVal IsDatabaseServerPrimaryOrSecondary As String _
                               , ByVal IsWebServerPrimaryOrSecondary As String)
        '*******************************************************************************************
        'Purpose:   Writes a record to the session log
        'Modification History
        'Who                When        What
        '===                ====        ===============
        'James Woosnam      20/10/04    Initial Version
        'James Woosnam      26/2/11     Moved to Logs
        '*******************************************************************************************
        If UserName = "ZedraCheck" Then
            'don't log for zedra check
            Exit Sub
        End If
        Dim subStartTime As DateTime = Now()
        Dim sql As String = ""
        Dim cmd As New SqlCommand("", Me.db.DBConnection, Me.db.DBTransaction)
        Try
            If UserId Is Nothing Then
                UserId = 0
            End If
            If UserName = Nothing Then
                UserName = "Not Logged On"
            End If
            Try

                sql = "INSERT INTO SessionLog (" _
                        & "  Date" _
                        & " , LogType" _
                        & " , PageId" _
                        & " , PageTitle" _
                        & " , UserId" _
                        & " , UserName" _
                        & " , SessionId" _
                        & " , RemoteIPAddress" _
                        & " , Comment)"

                '05/12/19	James Woosnam	SIR4769 - WriteSessionLog no longer record UserName 
                sql += "VALUES(" _
                        & " GetDate()" _
                        & " ,@LogType" _
                        & " ,@PageId" _
                        & " ,@PageTitle" _
                        & " ,@UserId" _
                        & " ,'No Longer Recorded'" _
                        & " ,@SessionId" _
                        & " ,@RemoteIPAddress" _
                        & " ,@Comment)"

                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LogType", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          LogType))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PageId", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          PageId))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@PageTitle", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          PageTitle))
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserId", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          UserId))
                '22/5/11        James Woosnam   HotFix - Open Logs with UserSession and Log Primary/Seconday Info
                Try
                    '6/11/11    James Woosnam   Hotfix - Set SessionId to "????" if null to avoid error email
                    If UserSession.UserSessionId Is Nothing Then
                        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SessionId", System.Data.SqlDbType.UniqueIdentifier, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                         New Guid("11111111111111111111111111111111")))
                    Else
                        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SessionId", System.Data.SqlDbType.UniqueIdentifier, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                          New Guid(CStr(UserSession.UserSessionId.ToString))))
                    End If
                Catch ex As Exception
                    Try
                        cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SessionId", System.Data.SqlDbType.UniqueIdentifier, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                  New Guid("11111111111111111111111111111111")))
                    Catch ex1 As Exception
                    End Try
                End Try

                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RemoteIPAddress", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          RemoteIPAddress))
                Try
                    Comment = "DB=" & IsDatabaseServerPrimaryOrSecondary & " " & Comment
                Catch ex As Exception
                End Try
                Try
                    Comment = "WEB=" & IsWebServerPrimaryOrSecondary & " " & Comment
                Catch ex As Exception
                End Try
                Try
                    If IsReadOnlyOnSecondary Then
                        Comment = "IsReadOnlyOnSecondary " & Comment
                    End If
                Catch ex As Exception
                End Try
                '4/10/20    James   Comment is varchar(5000) on PaDS_Live so limited to 5000 here
                cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Comment", System.Data.SqlDbType.VarChar, 5000, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                          Left(Comment, 5000)))
                cmd.CommandText = sql
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                Try
                    '14/10/21   James Woosnam   Add additional info to error message
                    Dim message As String = ex.ToString
                    message += Environment.NewLine & "SecondsSinceSubStart:" & (Now - subStartTime).TotalSeconds
                    message += Environment.NewLine & "CommandTimeout:" & cmd.CommandTimeout
                    message += Environment.NewLine & "sql:" & sql
                    message += Environment.NewLine & "@Comment:" & Comment
                    Dim email As New BusinessLogic.Email(Me.db)
                    email.SendErrorEmail("PaDS SessionLog Error", message)
                Catch ex1 As Exception

                End Try
            End Try
        Catch ex As Exception
            Throw ex
            'don't want to cause a problem is there is an error to just carry on
        Finally

        End Try

    End Sub
    Enum ActionTypes
        Authenticate 'When a user tries to logon
        Authorise ' when a user tries to request access to a document
    End Enum
    Public Sub WritePEPWebAuthoriseLog(ByVal LogonLocation As String,
                                 ByVal LogonStatus As String,
                                 ByVal SubscriberId As String,
                                 ByVal OrderNumber As String,
                                 ByVal UserName As String,
                                 ByVal ReasonForCheck As String,
                                 ByVal DocumentId As String,
                                 ByVal AdditionalDetails As String,
                                 ByVal RemoteIPAddress As String
                                )
        Me.WritePEPWebUsageLog(ActionType:=ActionTypes.Authorise,
                            LogonLocation:=LogonLocation,
                            LogonStatus:=LogonStatus,
                            SubscriberId:=SubscriberId,
                            UserName:=UserName,
                            ProductCombinationId:=0,
                            GatewayId:=0,
                            OrderNumber:=OrderNumber,
                            AccessibleContentSets:="",
                            AdditionalDetails:=AdditionalDetails,
                            ReasonForCheck:=ReasonForCheck,
                            DocumentId:=DocumentId,
                            RemoteIPAddress:=RemoteIPAddress)
    End Sub
    Public Sub WritePEPWebAthenticateLog(ByVal LogonLocation As String,
                                 ByVal LogonStatus As String,
                                 ByVal SubscriberId As String,
                                 ByVal SubscriberName As String,
                                 ByVal UserName As String,
                                 ByVal OrderNumber As Integer,
                                 ByVal AccessibleContentSets As String,
                                 ByVal AdditionalDetails As String,
                                 ByVal RemoteIPAddress As String
                                )
        Me.WritePEPWebUsageLog(ActionTypes.Authenticate,
                            LogonLocation,
                            LogonStatus,
                            SubscriberId,
                            UserName,
                            0,
                            0,
                            OrderNumber,
                            AccessibleContentSets,
                            AdditionalDetails,
                            "",
                             "",
                            RemoteIPAddress)
    End Sub
    Public Sub WritePEPWebUsageLog(ByVal LogonLocation As String,
                                 ByVal LogonStatus As String,
                                 ByVal SubscriberId As String,
                                 ByVal SubscriberName As String,
                                 ByVal UserName As String,
                                 ByVal ProductCombinationId As Integer,
                                 ByVal GatewayId As Integer,
                                 ByVal OrderNumber As Integer,
                                 ByVal AdditionalDetails As String
                                )
        'This is to supprot the pre 2021 PEPProduct 
        Me.WritePEPWebUsageLog(ActionTypes.Authenticate,
                            LogonLocation,
                            LogonStatus,
                            SubscriberId,
                            UserName,
                            ProductCombinationId,
                            GatewayId,
                            OrderNumber,
                            "",
                            AdditionalDetails,
                            "",
                             "",
                            "")
    End Sub
    Private Sub WritePEPWebUsageLog(ByVal ActionType As ActionTypes,
                                   ByVal LogonLocation As String,
                                 ByVal LogonStatus As String,
                                 ByVal SubscriberId As String,
                                 ByVal UserName As String,
                                 ByVal ProductCombinationId As Integer,
                                 ByVal GatewayId As Integer,
                                 ByVal OrderNumber As Integer,
                                 ByVal AccessibleContentSets As String,
                                 ByVal AdditionalDetails As String,
                                 ByVal ReasonForCheck As String,
                                 ByVal DocumentId As String,
                                 ByVal RemoteIPAddress As String
                                )
        '05/12/19	James Woosnam	SIR4769 - WritePEPWebUsageLog SubscriberName is no longer recorded, UserName is only passwd into here for failed logons, otherwise the UserId is passed in
        If UserName = "ZedraCheck" Then
            'don't log for zedra check
            Exit Sub
        End If
        Dim sql As String = ""
        Dim cmd As New SqlCommand("", Me.db.DBConnection, Me.db.DBTransaction)
        Try
            sql = "INSERT INTO PEPWebUsageLog"
            sql += " ("
            sql += "	DateTime"
            sql += "	,DatabaseName"
            sql += "	,ActionType"
            sql += "	,LogonLocation"
            sql += "	,LogonStatus"
            sql += "	,SubscriberId"
            sql += "	,UserName"
            sql += "	,ProductCombinationId"
            sql += "	,GatewayId"
            sql += "	,OrderNumber"
            sql += "	,AccessibleContentSets"
            sql += "	,AdditionalDetails"
            sql += "	,ReasonForCheck"
            sql += "	,DocumentId"
            sql += "	,UserSessionId"
            sql += "	,RemoteIPAddress"
            sql += " )"
            sql += " VALUES ("
            sql += "	GETDATE()"
            sql += "	,@DatabaseName"
            sql += "	,@ActionType"
            sql += "	,@LogonLocation"
            sql += "	,@LogonStatus"
            sql += "	,@SubscriberId"
            sql += "	,@UserName"
            sql += "	,@ProductCombinationId"
            sql += "	,@GatewayId"
            sql += "	,@OrderNumber"
            sql += "	,@AccessibleContentSets"
            sql += "	,@AdditionalDetails"
            sql += "	,@ReasonForCheck"
            sql += "	,@DocumentId"
            sql += "	,@UserSessionId"
            sql += "	,@RemoteIPAddress"
            sql += " )"
            'String.Concat used to convert nothing into empty string
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DatabaseName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                             String.Concat(Me.db.DBConnection.Database)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ActionType", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                              String.Concat(ActionType)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LogonLocation", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                               String.Concat(LogonLocation)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@LogonStatus", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                               String.Concat(LogonStatus)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@SubscriberId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                             IIf(SubscriberId = Nothing, 0, SubscriberId)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                              String.Concat(UserName)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProductCombinationId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                             IIf(ProductCombinationId = Nothing, 0, ProductCombinationId)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@GatewayId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                             IIf(GatewayId = Nothing, 0, GatewayId)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OrderNumber", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                              OrderNumber))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AccessibleContentSets", System.Data.SqlDbType.VarChar, 200, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                               String.Concat(AccessibleContentSets)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AdditionalDetails", System.Data.SqlDbType.VarChar, 2000, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                             String.Concat(AdditionalDetails)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ReasonForCheck", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                               String.Concat(ReasonForCheck)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DocumentId", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                             String.Concat(DocumentId)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RemoteIPAddress", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                             String.Concat(RemoteIPAddress)))
            Dim sessId As String = ""
            If UserSession IsNot Nothing Then
                sessId = UserSession.UserSessionId
            End If
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserSessionId", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                             sessId))
            cmd.CommandText = sql
            cmd.ExecuteNonQuery()

        Catch ex As Exception
            Try
                Me.LogErrorMessage(ex)
                Dim email As New BusinessLogic.Email(db)
                email.SendErrorEmail("PEPWebUsageLog was not written", ex.ToString)
            Catch ex1 As Exception
            End Try
            Throw New Exception("PEPWebUsageLog was not written:" & ex.Message)
        End Try


    End Sub

    Public Sub WriteAuditLog(ByVal TableName As String _
                           , ByVal UpdatedRecordKey As String _
                           , ByVal UpdatedByUserId As Integer _
                           , ByVal UpdatedByUserName As String _
                           , ByVal ModificationType As String _
                           , ByVal Description As String)
        '*******************************************************************************************
        'Purpose:   Writes a record to the Audit log
        '*******************************************************************************************
        If UpdatedByUserName = "ZedraCheck" Then
            'don't log for zedra check
            Exit Sub
        End If
        Try
            If Me.db.IsDBNull(TableName) Or TableName = "" Then
                TableName = "Unkown"
            End If
            Dim sql As String = ""
            sql = "	INSERT INTO AuditLog"
            sql += "	( TableName"
            sql += "	, AuditDate"
            sql += "    , UpdatedByUserId"
            sql += "	, UpdatedByUserName"
            sql += "    , UpdatedRecordKey"
            sql += "	, ModificationType"
            sql += "	, Description"
            sql += "	, DatabaseName"
            sql += "	)"
            sql += " VALUES ("
            sql += "	@TableName"
            sql += "	,GETDATE()"
            sql += "	,@UpdatedByUserId"
            sql += "	, 'No Longer Recorded'"
            sql += "    , @UpdatedRecordKey"
            sql += "	, @ModificationType"
            sql += "	, @Description"
            sql += "	, @DatabaseName"
            sql += "	)"


            Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)


            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TableName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                              TableName))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UpdatedByUserId", System.Data.SqlDbType.Int, 0, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      UpdatedByUserId))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UpdatedRecordKey", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      UpdatedRecordKey))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ModificationType", System.Data.SqlDbType.VarChar, 20, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      ModificationType))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Description", System.Data.SqlDbType.VarChar, 4000, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      Left(Description, 4000)))
            cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DatabaseName", System.Data.SqlDbType.VarChar, 50, ParameterDirection.Input, True, CType(0, Byte), CType(0, Byte), "", DataRowVersion.Default,
                                                                      Me.db.DBConnection.Database))

            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Throw New Exception("Failed to write AuditLog record:" & ex.Message)
        End Try
    End Sub


    Public Sub LogErrorMessage(ByVal exToLog As Exception, Optional SendEmailForUnExpected As Boolean = True)
        '13/2/20    James Woosnam   SIR5017 - LogErrorMessage Check querystring for username if there isn't one, write querystring to stacktrace
        Dim sql As String = ""
        sql = "SELECT *"
        sql += " FROM stblErrorMessageLog"
        sql += " WHERE 1=2"
        Dim da As New SqlClient.SqlDataAdapter(sql, db.DBConnection)
        Dim tbl As New DataTable
        da.Fill(tbl)
        da.UpdateCommand = New SqlClient.SqlCommandBuilder(da).GetUpdateCommand()

        Dim row As DataRow = tbl.NewRow
        row("DateTime") = Now()
        Try
            row("UserId") = IIf(Me.UserSession.UserId = Nothing, -1, Me.UserSession.UserId)
        Catch ex As Exception
            row("UserId") = -1
        End Try
        Try
            If Me.UserSession.UserName Is Nothing Then
                row("UserName") = "????"
            Else
                row("UserName") = Me.UserSession.UserName
            End If
        Catch ex As Exception
            row("UserName") = "????"
        End Try
        row("Page") = "????"
        Try
            row("ErrorMessage") = exToLog.Message
            Try
                If (exToLog.InnerException IsNot Nothing) Then
                    row("ErrorMessage") += exToLog.InnerException.ToString()
                End If
            Catch ex As Exception
            End Try
            Try
                If CStr(row("ErrorMessage")).ToLower.Contains("unexpected") And SendEmailForUnExpected Then
                    Try
                        Dim email As New BusinessLogic.Email(db)
                        email.SendErrorEmail("PADS Page Error", row("ErrorMessage"))
                    Catch ex As Exception
                        Me.LogErrorMessage(New Exception("Send Error Email in LogErrorMessage failed:" & ex.Message), False)
                    End Try

                End If
            Catch ex As Exception
            End Try
        Catch ex As Exception
            row("ErrorMessage") = "????"
        End Try
        Try
            If exToLog.Source Is Nothing Then
                row("Source") = "???"
            Else
                row("Source") = exToLog.Source
            End If
        Catch ex As Exception
            row("Source") = "????"
        End Try
        Try
            If exToLog.StackTrace Is Nothing Then
                row("StackTrace") = "???"
            Else
                row("StackTrace") = exToLog.StackTrace
            End If
        Catch ex As Exception
            row("StackTrace") = "????"
        End Try
        Try
            tbl.Rows.Add(row)
            da.Update(tbl)
        Catch ex As Exception
            Me.LogErrorMessage(ex)
            Dim msg As String = ex.ToString
        End Try
    End Sub
End Class








