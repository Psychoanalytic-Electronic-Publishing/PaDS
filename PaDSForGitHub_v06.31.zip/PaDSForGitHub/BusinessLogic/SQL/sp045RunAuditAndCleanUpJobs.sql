if exists (select * from dbo.sysobjects where id = object_id(N'sp045RunAuditAndCleanUpJobs') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp045RunAuditAndCleanUpJobs
GO

CREATE  PROCEDURE sp045RunAuditAndCleanUpJobs (
				@BatchLogId INT
				)
AS
--6/6/23	James Woosnam	Delete all PEPWebUsageLog older than 2 months as duplicated on PaDS02
    DECLARE @RecordCount INT 
    DECLARE @Msg VARCHAR(MAX)=''
    DECLARE @SessioTimeOutMinutes DECIMAL = (SELECT ParameterValue FROM stblParameters WHERE ParameterName = 'SessionTimeout')
    IF ISNULL(@SessioTimeOutMinutes,0) < 10080 SET @SessioTimeOutMinutes = 10080

    --2 years
    DELETE FROM AuditLog WHERE AuditDate < DATEADD(YEAR,-2,GETDATE())
    SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' AuditLog records deleted'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg
    --DELETE FROM PEPWebUsageLog WHERE DateTime < DATEADD(YEAR,-2,GETDATE())
    --SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' PEPWebUsageLog records deleted'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg 

    --1 year
    DELETE FROM BatchJob  WHERE ScheduledStartDateTime  < DATEADD(YEAR,-1,GETDATE())
    SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' BatchJob records deleted'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg ;PRINT @msg

    DELETE FROM BatchLogLine   WHERE BatchLogId in (SELECT BatchLogId FROM BatchLog WHERE DateTime  < DATEADD(YEAR,-1,GETDATE()))
    SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' BatchLogLine records deleted'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg
    DELETE FROM BatchLog   WHERE DateTime  < DATEADD(YEAR,-1,GETDATE())
    SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' BatchLog records deleted'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg

    --Delete not logged on sessions older then session timeout
	SELECT s.UserSessionId,LoggedOn = CASE WHEN s.UserId = -1 THEN 0 ELSE 1 END INTO #Sess FROM UserSession s  With (nolock) WHERE s.LastAccessedDate < dateadd(minute,-1* @SessioTimeOutMinutes,getdate()) ORDER BY s.UserSessionId
	SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' UserSessions to delete as not logged on and older than SessionTimeout days:' + CAST((@SessioTimeOutMinutes / 60 /24) as VARCHAR); exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg

	WHILE EXISTS(SELECT * FROM #Sess )
	BEGIN
		delete FROM UserSessionData WHERE UserSessionId IN (  SELECT TOP 10000 UserSessionId FROM #Sess WHERE LoggedOn=0 ORDER BY 1) 
		SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' unloggedon UserSessionData records deleted'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg
		delete FROM UserSessionData WHERE UserSessionId IN (  SELECT TOP 10000 UserSessionId FROM #Sess WHERE LoggedOn=1 ORDER BY 1) and DataItemName not in ('UserFullName','SubscriberId','SubscriptionOrderNumber','SubscriptionEndDate','LoggedInMethod','UserType')
		SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' Loggedon UserSessionData records deleted'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg

		delete FROM UserSession WHERE UserSessionId IN (  SELECT TOP 10000 UserSessionId FROM #Sess  WHERE LoggedOn=0 ORDER BY 1)
		SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' UserSession records deleted'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg
		DELETE FROM  #Sess WHERE UserSessionId IN (  SELECT TOP 10000 UserSessionId FROM #Sess ORDER BY 1)
	END

	DROP TABLE #Sess
    --22/9/21   James Woosnam   SIR5326 - delete NotLoggedOn SessionLog older than 3 days, delete all session log older then 2 months
    --                          A full archive of this table is beig stored on PaDS02
    DECLARE @DeleteNotLoggedInBeforeDate DATETIME = DATEADD(DAY,-3,CONVERT(DATETIME,FORMAT(GETDATE(),'dd-MMM-yy')))
	--3/2/22	James Woosnam	Only keep 1 month of session log
    DECLARE @DeleteAllBeforeDate DATETIME = DATEADD(MONTH,-1,CONVERT(DATETIME,FORMAT(GETDATE(),'dd-MMM-yy')))

	CREATE TABLE #SessLog ( SessionLogId INT)
   INSERT INTO #SessLog SELECT l.SessionLogId  from SessionLog l  With (nolock) where l.Date <@DeleteNotLoggedInBeforeDate AND l.UserId IN (0,-1) ORDER BY 1
    SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' NotLoggedNo SessionLog records to deleted as before:' + FORMAT(@DeleteNotLoggedInBeforeDate,'dd-MMM-yyyy'); exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg
    INSERT INTO #SessLog SELECT l.SessionLogId from SessionLog l With (nolock) where l.Date <@DeleteAllBeforeDate ORDER BY 1
    SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' ALL SessionLog records to deleted as Before:' + FORMAT(@DeleteAllBeforeDate,'dd-MMM-yyyy'); exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg

    --8/11/21   James Woosnam   Delete all Getuser for now-3 days
    INSERT INTO #SessLog SELECT l.SessionLogId FROM SessionLog l With (nolock) WHERE pageTitle='GetUser' AND l.Date <@DeleteNotLoggedInBeforeDate  ORDER BY 1 --TEMP: delete all GetUserRecs < -3 days, was just not logged on
    SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' Sessionlog records to deleted Getuser for now-3 days'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg
    --8/2/22   James Woosnam   AuthenticateFromIP, Already Logged in for now-3days
    INSERT INTO #SessLog SELECT l.SessionLogId FROM SessionLog l With (nolock) WHERE pageTitle='AuthenticateFromIP' AND l.Comment like '%Already Logged in%' AND l.Date <@DeleteNotLoggedInBeforeDate  ORDER BY 1 
    SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' Sessionlog records to deleted AuthenticateFromIP, Already Logged in for now-3days'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg

	WHILE EXISTS(SELECT * FROM #SessLog )
	BEGIN
		DELETE FROM SessionLog WHERE SessionLogId IN (SELECT TOP 10000 SessionLogId FROM #SessLog  ORDER BY 1 )
		SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' Sessionlog records deleted'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg
		DELETE FROM #SessLog WHERE SessionLogId IN (SELECT TOP 10000 SessionLogId FROM #SessLog  ORDER BY 1 )
	END
	--20/12/21	James Woosnam	DELETE from PEPWebSessionLog
    DECLARE @DeletePEPSessionLogBeforeDate DATETIME = DATEADD(DAY,-3,CONVERT(DATETIME,FORMAT(GETDATE(),'dd-MMM-yy')))
	--only delete if there are pepusage record after 1 day greater than the deletefrom date
	IF EXISTS(SELECT top 10 * FROM PEPUsage p WHERE p.DateTime > DATEADD(DAY,1,@DeletePEPSessionLogBeforeDate) AND p.ActionType IN ('Abstract','Search'))
	BEGIN
		delete PEPWebSessionLog  from PEPWebSessionLog l where l.LastUpdate  <@DeletePEPSessionLogBeforeDate 
		SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' PEPWebSessionLog deleted Before:' + FORMAT(@DeletePEPSessionLogBeforeDate,'dd-MMM-yyyy') + ' Only if PEPUsage table populated'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg

		--6/6/23	James Woosnam	Delete all PEPWebUsageLog older than 2 months as duplicated on PaDS02
		delete PEPWebUsageLog from PEPWebUsageLog l where l.DateTime < dateadd(month,-2,getdate()) AND l.DateTime  <@DeletePEPSessionLogBeforeDate 
		SET @RecordCount = @@ROWCOUNT ;SET @Msg = CAST(@RecordCount AS VARCHAR) + ' PEPWebUsageLog older than 2 months and before:' + FORMAT(@DeletePEPSessionLogBeforeDate,'dd-MMM-yyyy') + ' Only if PEPUsage table populated'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg

	END
	ELSE
	BEGIN
		SET @RecordCount = @@ROWCOUNT ;SET @Msg =  ' PEPWebSessionLog & PEPWebUsageLog NOT deleted as PEPUsage table not recently populated'; exec sp029UpdateBatchLog @BatchLogId=@BatchLogId,@LogMessage=@Msg  ;PRINT @msg
	END
GO