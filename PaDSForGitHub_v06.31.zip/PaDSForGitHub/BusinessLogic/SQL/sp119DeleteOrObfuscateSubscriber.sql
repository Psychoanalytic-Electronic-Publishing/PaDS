if exists (select * from dbo.sysobjects where id = object_id(N'sp119DeleteOrObfuscateSubscriber') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp119DeleteOrObfuscateSubscriber
GO

CREATE PROCEDURE sp119DeleteOrObfuscateSubscriber(
				@SubscriberId INT
				,@RunMode varchar(20) --Test or Delete
				,@RunByUserId INT
				,@BatchLogId INT = NULL
				,@ObfuscateNotDelete BIT = NULL OUTPUT
				,@ReturnMessage VARCHAR(MAX) = '' OUTPUT
				)	
AS				
/*
If the subscriber has never been part of an order, then delete entirely
If it has been part of an order then, obfuscate all subscriber personal data

*/
--Modification History
--May 2019 - James Woosnam - Initial Version
--19/11/19	James Woosnam	SIR4763 - Nullify WebUser fields
--14/5/24	James Woossnam	SIR5743 - Allow to run as batchJob with better logging and delete from more tables
	
DECLARE @Message varchar(8000) = ''
DECLARE @BMsg varchar(MAX) = ''
DECLARE @BCount VARCHAR(10) = ''
DECLARE @Count INT = 0
SET @ReturnMessage=''
 SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg =  ' sp119DeleteOrObfuscateSubscriber Started ';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END


IF EXISTS(SELECT * FROM ProductAffiliateRate p where p.GroupSubscriberId = @SubscriberId )
BEGIN
	SET @Message = 'Remove SubscriberId:' + CAST(@SubscriberId AS VARCHAR) + ' failed as it is used in ProductAffiliateRate'
	RAISERROR (@Message, 16, 1)
END

SET @Count = (SELECT Count(*) FROM  SalesOrder so WHERE so.SubscriberId = @SubscriberId AND so.SalesOrderStatus NOT IN ('Partial','RemotePartial','Rejected') )
IF @COUNT <> 0 SET @ReturnMessage +=FORMAT(@Count,'N0') + ' Orders<BR>'
SET @Count = (SELECT Count(*) FROM  SalesOrderLine sol INNER JOIN Salesorder so ON so.OrderNumber = sol.OrderNumber WHERE sol.SubscriberId = @SubscriberId AND so.SalesOrderStatus NOT IN ('Partial','RemotePartial','Rejected'))
IF @COUNT <> 0 SET @ReturnMessage +=FORMAT(@Count,'N0') + ' Order Lines<BR>'
SET @Count = (SELECT Count(*) FROM  Cashbook c WHERE c.SubscriberId = @SubscriberId AND c.CashbookStatus NOT IN ('Partial') )
IF @COUNT <> 0 SET @ReturnMessage +=FORMAT(@Count,'N0') + ' Cashbook Items<BR>'
DECLARE @LastLoggedOnDate DATETIME = (SELECT MAX(ru.LastLoggedOn ) 
									FROM RemoteUser ru 
										INNER JOIN RemoteUserRights rur
										ON rur.UserId = ru.UserId 
										AND rur.RightsType = 'Subscriber'
										AND rur.RightsToId = @SubscriberId 
										)
IF @LastLoggedOnDate IS NOT NULL AND @LastLoggedOnDate > DATEADD(YEAR,-2,GETDATE()) SET @ReturnMessage += 'Last logon ' + FORMAT(@LastLoggedOnDate,'dd-MMM-yy HH:mm') + ' within 2 years'

IF @ReturnMessage = '' 
BEGIN
	SET @ReturnMessage = 'Subscriber will be deteled' + @ReturnMessage 
	SET @ObfuscateNotDelete=0
END
ELSE
BEGIN
	SET @ReturnMessage = 'Subscriber will be Obfuscated because of the following:<BR>' + @ReturnMessage 
	SET @ObfuscateNotDelete = 1
END



IF @RunMode = 'Test'
BEGIN
	RETURN 
END

BEGIN TRAN
BEGIN TRY

	SELECT rur.UserId  
	INTO #User
	FROM RemoteUser ru 
		INNER JOIN RemoteUserRights rur
		ON rur.UserId = ru.UserId 
		AND rur.RightsType = 'Subscriber'
		AND rur.RightsToId = @SubscriberId 

--Always delete from these 2
	DELETE FROM EmailDistributionLog WHERE SubscriberId = @SubscriberId 
		SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount  + ' rows deleted from EmailDistributionLog';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
	DELETE FROM tmpSubscriberImport WHERE SubscriberId = @SubscriberId OR DuplicateSubscriberIdToUse = @SubscriberId 
			SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount  + ' rows deleted from tmpSubscriberImport';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END

	IF @ObfuscateNotDelete = 0 
	BEGIN
		DELETE FROM EmailDistributionLog WHERE SubscriberId = @SubscriberId 
				SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount  + ' rows deleted from EmailDistributionLog';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		DELETE FROM RemoteUserAutoLogon WHERE UserId In (SELECT UserId FROM #User)
				SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows deleted from RemoteUserAutoLogon';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		DELETE FROM RemoteUserRights WHERE UserId In (SELECT UserId FROM #User)
				SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows deleted from RemoteUserRights';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		DELETE FROM RemoteUser WHERE UserId In (SELECT UserId FROM #User)
				SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows deleted from RemoteUser';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		DELETE FROM CompanyAccount WHERE SubscriberId = @SubscriberId 
				SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows deleted from CompanyAccount';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		DELETE FROM Cashbook WHERE SubscriberId = @SubscriberId 
				SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows deleted from Cashbook';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		DELETE FROM SalesOrderLine WHERE SubscriberId = @SubscriberId 
				SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows deleted from SalesOrderLine';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		DELETE FROM SalesOrder WHERE SubscriberId = @SubscriberId 
				SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows deleted from SalesOrder';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		DELETE FROM SubscriberAffiliate  WHERE ChildSubscriberID = @SubscriberId 
				SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows deleted from SubscriberAffiliate';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		DELETE FROM SubscriberAffiliate  WHERE ParentSubscriberID = @SubscriberId 
				SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows deleted from SubscriberAffiliate';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		DELETE FROM Subscriber WHERE SubscriberID = @SubscriberId 
				SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows deleted from Subscriber';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		SET @ReturnMessage = CAST(@SubscriberId AS VARCHAR) + ' deleted'

	END
	IF @ObfuscateNotDelete = 1
	BEGIN
		UPDATE SalesOrderLinePart 
		SET AddressText = dbo.fn051ObfuscatedText(AddressText)
		FROM SalesOrderLinePart solp
			INNER JOIN SalesOrderLine sol
			On sol.SalesOrderLineID = solp.SalesOrderLineID 
		WHERE  sol.SubscriberId = @SubscriberId 
				SET @BCount=FORMAT(@@ROWCOUNT,'##0');IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows Obfuscated in SalesOrderLinePart';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END

		UPDATE Cashbook 
		SET PaymentCardName = dbo.fn051ObfuscatedText(PaymentCardName)
			,PaymentCardExpiryDate = 'xx/xx'
			,PaymentCardNumber = 'xxxxx'
			,PaymentCardAuthorisationCode = 'xxxx'
			,PaymentCardAuthorisationReturnText = ''
			,CreatedByUserId = dbo.fn051ObfuscatedText(CreatedByUserId)
			,Notes = 'Obfuscated:' + FORMAT(GETDATE(),'dd-MMM-yy HH:mm')
		WHERE SubscriberId = @SubscriberId 
				SET @BCount=FORMAT(@@ROWCOUNT,'##0');IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows Obfuscated in Cashbook';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END

		UPDATE CompanyAccount 
		SET Notes = 'Obfuscated:' + FORMAT(GETDATE(),'dd-MMM-yy HH:mm')
			,LastUpdatedByUserId = @RunByUserId 
			,LastUpdatedDateTime = GETDATE()
		WHERE SubscriberId = @SubscriberId 
				SET @BCount=FORMAT(@@ROWCOUNT,'##0');IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows Obfuscated in CompanyAccount';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		IF PATINDEX('%zedra%',@@SERVERNAME) = 0 DELETE FROM SubscriberAffiliate  WHERE ChildSubscriberID = @SubscriberId AND ParentSubscriberID NOT IN (30000,29001,29002)
		DELETE FROM SubscriberAffiliate  WHERE ParentSubscriberID = @SubscriberId 
				SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount  + ' rows deleted from SubscriberAffiliate';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		UPDATE Cashbook 
		SET PaymentCardName = dbo.fn051ObfuscatedText(PaymentCardName)
			,PaymentCardExpiryDate = 'xx/xx'
			,PaymentCardNumber = 'xxxxx'
			,PaymentCardAuthorisationCode = 'xxxx'
			,PaymentCardAuthorisationReturnText = ''
			,CreatedByUserId = dbo.fn051ObfuscatedText(CreatedByUserId)
			,Notes = 'Obfuscated:' + FORMAT(GETDATE(),'dd-MMM-yy HH:mm')
		WHERE SubscriberId = @SubscriberId 
				SET @BCount=FORMAT(@@ROWCOUNT,'##0');IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows Obfuscated in Cashbook';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		UPDATE RemoteUser 
		SET UserFullName = dbo.fn051ObfuscatedText(UserFullName)
			,UserName = dbo.fn051ObfuscatedText(UserName)
			,EmailAddress = dbo.fn051ObfuscatedText(EmailAddress)
			,OldEmailAddress = dbo.fn051ObfuscatedText(EmailAddress)
			,UserNameBeforeProposed = dbo.fn051ObfuscatedText(EmailAddress)
			,Notes = dbo.fn051ObfuscatedText(EmailAddress)
			,UserStatus  = 'InActive'
		WHERE UserId In (SELECT UserId FROM #User)
				SET @BCount=FORMAT(@@ROWCOUNT,'##0');IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows Obfuscated in RemoteUser';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		UPDATE SubscriberAddress  
		SET Notes = 'Obfuscated:' + FORMAT(GETDATE(),'dd-MMM-yy HH:mm')
			,Address1 =  dbo.fn051ObfuscatedText(Address1)
			,Address2 =  dbo.fn051ObfuscatedText(Address2)
			,Address3 =  dbo.fn051ObfuscatedText(Address3)
			,Address4 =  dbo.fn051ObfuscatedText(Address4)
			,Town =  dbo.fn051ObfuscatedText(Town)
			,County =  dbo.fn051ObfuscatedText(County)
			,PostCode =  dbo.fn051ObfuscatedText(PostCode)
			,AddressText=  dbo.fn051ObfuscatedText(AddressText)

			,LastUpdatedByUserId = @RunByUserId 
			,LastUpdatedDateTime = GETDATE()
		WHERE SubscriberId = @SubscriberId 
				SET @BCount=FORMAT(@@ROWCOUNT,'##0');IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows Obfuscated in SubscriberAddress';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		UPDATE Subscriber
		SET Notes = 'Obfuscated:' + FORMAT(GETDATE(),'dd-MMM-yy HH:mm')
			,SubscriberStatus = CASE WHEN  PATINDEX('%zedra%',@@SERVERNAME) = 0  THEN 'InActive' ELSE SubscriberStatus END
			,SubscriberName =  dbo.fn051ObfuscatedText(SubscriberName)
			,VATNumber =  dbo.fn051ObfuscatedText(VATNumber)
			,ContactName =  dbo.fn051ObfuscatedText(ContactName)
			,FirstName =  dbo.fn051ObfuscatedText(FirstName)
			,LastName =  dbo.fn051ObfuscatedText(LastName)
			,Title =  dbo.fn051ObfuscatedText(Title)
			,Salutation =  dbo.fn051ObfuscatedText(Salutation)
			,Position =  dbo.fn051ObfuscatedText(Position)
			,Qualifications =  dbo.fn051ObfuscatedText(Qualifications)
			,MembershipType =  dbo.fn051ObfuscatedText(MembershipType)
			,Spare1 =  dbo.fn051ObfuscatedText(Spare1)
			,Spare2 =  dbo.fn051ObfuscatedText(Spare2)
			,Spare3 =  dbo.fn051ObfuscatedText(Spare3)
			,LastUpdatedByUserId = @RunByUserId 
			,LastUpdatedDateTime = GETDATE()
		WHERE SubscriberId = @SubscriberId 
				SET @BCount=FORMAT(@@ROWCOUNT,'##0');IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount + ' rows Obfuscated in Subscriber';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END
		SET @ReturnMessage = CAST(@SubscriberId AS VARCHAR) + ' Obfuscated'
	END
	--Has to be done again here
	DELETE FROM AuditTableLog WHERE UpdatedRecordFamily='Subscriber' AND UpdatedRecordFamilyKey=@SubscriberId 
		SET @BCount=@@ROWCOUNT;IF @BatchLogId<>0 BEGIN SET @BMsg = @BCount  + ' rows deleted from AuditTableLog';EXEC sp029UpdateBatchLog @BatchLogId, @BMsg;PRINT @BMsg END

	commit TRAN
	print @ReturnMessage
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SET @Message = 'sp119DeleteOrObfuscateSubscriber Failed - ' + ERROR_MESSAGE()
	RAISERROR (@Message, 16, 1)
END CATCH


GO

Grant EXECUTE ON sp119DeleteOrObfuscateSubscriber to PaDSSQLServerUser



