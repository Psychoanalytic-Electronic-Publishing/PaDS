﻿

DECLARE @NewDBVersion varchar(10)
DECLARE @OldDBVersion varchar(10)
DECLARE @CurrentDBVersion varchar(10)
DECLARE @SQL as varchar(max)
DECLARE @ProcName Varchar(50)
DECLARE @ServerName varchar(100)
DECLARE @DBName varchar(100)= DB_Name()
DECLARE @Message VARCHAR(2000)
DECLARE @RowCount INT
DECLARE @v sql_variant 
DECLARE @IsAtClient BIT = 0
DECLARE @LookupId INT

IF PATINDEX('%zedra%',@@ServerName) = 0
	SET @IsAtClient = 1

SELECT @ServerName = CASE WHEN @IsAtClient = 1 THEN 'PaDS01' ELSE  @@ServerName END

DECLARE @RunningAtClient BIT = ( SELECT CASE WHEN PATINDEX('%zedra%',@ServerName)=0 THEN 1 ELSE 0 END )

SET @OldDBVersion = '2.8'
SET @NewDBVersion = '2.9'
 
IF NOT EXISTS(SELECT * FROM stblParameters WHERE ParameterName = 'DatabaseVersion') INSERT INTO stblParameters(ParameterName,ParameterType,UserID,ParameterValue) SELECT 'DatabaseVersion','System','All','01.00'  
SELECT @CurrentDBVersion = ParameterValue FROM dbo.stblParameters WHERE ParameterName = 'DatabaseVersion'
SELECT 'Current Version: ' + @CurrentDBVersion

IF NOT (@CurrentDBVersion = @OldDBVersion OR  @CurrentDBVersion = @NewDBVersion)
OR @CurrentDBVersion IS NULL
BEGIN
	SELECT 'Current DB Version ' + ISNULL(@CurrentDBVersion,'EMPTY') + ' does not match'
END
ELSE
BEGIN
BEGIN TRANSACTION 
BEGIN TRY
print '1'
--SIR5641 - Add PhoneNumberForCourier to Subscriber and tmpSubscriberImport tables.
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name='Subscriber' and c.name = 'PhoneNumberForCourier')
	BEGIN
		ALTER TABLE Subscriber ADD
			PhoneNumberForCourier VARCHAR(30) NULL
	END

	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name='tmpSubscriberImport' and c.name = 'PhoneNumberForCourier')
	BEGIN
		ALTER TABLE tmpSubscriberImport ADD
			PhoneNumberForCourier VARCHAR(30) NULL
	END

	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name='EmailDistribution' and c.name = 'EnteredSubscriberListText')
	BEGIN
		ALTER TABLE EmailDistribution ADD
			EnteredSubscriberListText NVARCHAR(MAX) NULL
	END
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name='ContentJournals' and c.name = 'publisher')
	BEGIN
		ALTER TABLE ContentJournals ADD
			publisher NVARCHAR(200) NULL
	END
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name='ContentBooks' and c.name = 'publisher')
	BEGIN
		ALTER TABLE ContentBooks ADD
			publisher NVARCHAR(200) NULL
	END

	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name='ContentVideos' and c.name = 'publisher')
	BEGIN
		ALTER TABLE ContentVideos ADD
			publisher NVARCHAR(200) NULL
	END

	IF @IsAtClient = 1 
		SET @SQL = '
	USE PaDS_Logs_UserActionLog'
	ELSE
		SET @SQL = '
	USE PaDS_Logs'

		SET @SQL += '
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name=''UserActionLog'' and c.name = ''publisher'')
	BEGIN
		ALTER TABLE UserActionLog ADD
			publisher NVARCHAR(200) NULL
	END'
	EXECUTE(@SQL)

--SIR5711 - Add BlockSpecificReceiptEmailHTML to Product table.
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name='Product' and c.name = 'BlockSpecificReceiptEmailHTML')
	BEGIN
		ALTER TABLE Product ADD
			BlockSpecificReceiptEmailHTML nvarchar(max) NULL
	END

--SIR5734 - Add SuppressConfirmationEmail to Product table.
	IF NOT EXISTS(SELECT * FROM SYSOBJECTS o INNER JOIN SYSCOLUMNS C ON c.id = o.id where o.name='Product' and c.name = 'SuppressConfirmationEmail')
	BEGIN
		ALTER TABLE Product ADD
			SuppressConfirmationEmail BIT NULL
	END
	
--SIR5735 Supress BCC Emails
	IF EXISTS(SELECT * FROM stblParameters WHERE ParameterName = 'BlindCopyEmailAddress') 
	BEGIN
		Update stblParameters SET ParameterValue = '' WHERE ParameterName = 'BlindCopyEmailAddress'
	END
	IF EXISTS(SELECT * FROM stblParameters WHERE ParameterName = 'PEPRenewalEmailBCCAddress') 
	BEGIN
		Update stblParameters SET ParameterValue = '' WHERE ParameterName = 'PEPRenewalEmailBCCAddress'
	END
	IF EXISTS(SELECT * FROM stblParameters WHERE ParameterName = 'ReceiptBCCEmailAddressForCompanyId:1') 
	BEGIN
		Update stblParameters SET ParameterValue = '' WHERE ParameterName = 'ReceiptBCCEmailAddressForCompanyId:1'
	END
	IF EXISTS(SELECT * FROM stblParameters WHERE ParameterName = 'ReceiptBCCEmailAddressForCompanyId:2') 
	BEGIN
		Update stblParameters SET ParameterValue = '' WHERE ParameterName = 'ReceiptBCCEmailAddressForCompanyId:2'
	END

--SIR5745 Add new DiscountRates
	IF NOT EXISTS(SELECT * from DiscountRate WHERE PercentDiscount = '0.35')
	BEGIN
		INSERT INTO DiscountRate 
		VALUES('0.35','35%',NULL,GETDATE(),NULL,GETDATE(),NULL)
	END
	IF NOT EXISTS(SELECT * from DiscountRate WHERE PercentDiscount = '0.45')
	BEGIN
		INSERT INTO DiscountRate 
		VALUES('0.45','45%',NULL,GETDATE(),NULL,GETDATE(),NULL)
	END
	IF NOT EXISTS(SELECT * from DiscountRate WHERE PercentDiscount = '0.55')
	BEGIN
		INSERT INTO DiscountRate 
		VALUES('0.55','55%',NULL,GETDATE(),NULL,GETDATE(),NULL)
	END
	IF NOT EXISTS(SELECT * from DiscountRate WHERE PercentDiscount = '0.65')
	BEGIN
		INSERT INTO DiscountRate 
		VALUES('0.65','65%',NULL,GETDATE(),NULL,GETDATE(),NULL)
	END
	IF NOT EXISTS(SELECT * from DiscountRate WHERE PercentDiscount = '0.85')
	BEGIN
		INSERT INTO DiscountRate 
		VALUES('0.85','85%',NULL,GETDATE(),NULL,GETDATE(),NULL)
	END	
	IF NOT EXISTS(SELECT * from DiscountRate WHERE PercentDiscount = '0.95')
	BEGIN
		INSERT INTO DiscountRate 
		VALUES('0.95','95%',NULL,GETDATE(),NULL,GETDATE(),NULL)
	END		

	----**************************
	--Set New DB Version
	
	Update stblParameters
	SET ParameterValue =CAST( @NewDBVersion AS VARCHAR)
	WHERE ParameterName = 'DatabaseVersion'
	
--*************   END TRANSACTION *********************
Commit TRAN

SELECT 'Transaction Commited'
END TRY
BEGIN CATCH
	ROLLBACK TRAN
	SELECT 'Transaction Rolled Back'
	SELECT @Message = 'DBUpgrade Failed - Line:' + CONVERT(VARCHAR, ERROR_LINE()) + ' ' + ERROR_MESSAGE()
	
	RAISERROR ('%s', 18, 1,@Message)

END CATCH

END
