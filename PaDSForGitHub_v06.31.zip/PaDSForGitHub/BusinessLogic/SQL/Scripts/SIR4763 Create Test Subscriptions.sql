begin tran
if exists(select * from sysobjects where name ='#orders' and type='u') drop table #orders

select distinct
	so.PrimaryProductCode 
	,so.OrderDate 
	,sol.RecurringSubscriptionStartDate 
	,sol.RecurringSubscriptionEndDate 
	,ProdTerm = datediff(year,sol.RecurringSubscriptionStartDate ,sol.RecurringSubscriptionEndDate )
	,s.SubscriberId 
	,s.zzWebUserName 
	,s.zzWebUserPassword 
into #orders
from Subscriber s
	inner join SalesOrderLine sol
		inner join SalesOrder so
		on so.OrderNumber = sol.OrderNumber 
	on sol.SubscriberId = s.SubscriberId 
where s.SubscriberStatus = 'Current'
and so.SalesOrderStatus in ('complete','confirmed')
and sol.RecurringSubscriptionEndDate > '01-jan-2017'
order by so.OrderDate 
if exists(select * from sysobjects where name ='zTestProductUsers' and type='u') drop table zTestProductUsers
select distinct
o.*
,WebUserName  = s.zzWebUserName 
,WebUserPassword  = s.zzWebUserPassword 
into zTestProductUsers
from (
		select
			o.PrimaryProductCode 
			,ProdTerm
			,subEndYear = year(o.RecurringSubscriptionEndDate )
			,SubscriberId = min(o.SubscriberId )
		from #orders o
		group by
			o.PrimaryProductCode 
			,ProdTerm
			, year(o.RecurringSubscriptionEndDate )
			) o
	inner join #orders s
	on s.SubscriberId = o.SubscriberId 
order by
	o.PrimaryProductCode 
	, o.subEndYear

select * from zTestProductUsers


rollback tran
