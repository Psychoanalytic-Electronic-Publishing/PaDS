DECLARE 
	@SessionId VARCHAR(50)='4d6e5229-2ebf-44a1-907f-89ed3b1fe910 '--0dcb5c15-2880-4cc7-baed-b3c298af884c'--null--FCF81761-8A83-45AD-8058-1A5A861687E8  '--C0BB87C7-C448-476B-9BAF-4978343FF986  '--FFD28925-C2D1-4319-8068-96AC8E195082'--null--d59d47e7-5674-47c6-8266-e1fb6fc17906'--null--'49111e20-3886-471e-870e-ca509f5c2d3f'--null--	12C46733-512E-4B6B-A932-99ED882B6DF8  '45681e9e-1495-464d-8a77-ed460ea5e706'--null--'76731AED-0F71-4792-AEFF-E9D7F1D2D7FD'
	,@FromDateTime as DATETIME = null--'01-oct-20 00:00'
	,@ToDateTime as DATETIME =null--'11-dec-20 20:00:00' --'29-oct-20 09:50:00'
	,@LastSession as bit = 0

IF @LastSession=1  set @SessionId = (SELECT UserSessionId FROM UserSession us where us.LastAccessedDate  = (SELECT MAX(LastAccessedDate) FROM UserSession))

SELECT top 2000
*
--,IPAddress = (SELECT MAX(l.RemoteIPAddress  ) FROM SessionLog l WHERE l.SessionId = CAST(us.UserSessionId as VARCHAR(50) ))
--,SubscriptionEndDate = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='SubscriptionEndDate' AND usd.UserSessionId=us.UserSessionId )
--,Subscriberid = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='Subscriberid' AND usd.UserSessionId=us.UserSessionId )
--,SubscriptionOrders = (SELECT usd.DataItemValue  FROM UserSessionData usd where usd.DataItemName='SubscriptionOrders' AND usd.UserSessionId=us.UserSessionId )
FROM UserSession us with (nolock)
	--left JOIN UserSessionData usd with (nolock)
	--ON usd.UserSessionId = us.UserSessionId  
WHERE 1=1
--AND us.LastAccessedDate = (SELECT MAX(LastAccessedDate) FROM UserSession )
--and us.StartDate > CAST(FORMAT(GETDATE(),'dd-MMM-yy') as DATETIME)
and (us.UserSessionId = @SessionId  OR @SessionId is null)
AND (us.LastAccessedDate  >= @FromDateTime OR @FromDateTime IS NULL)
AND (us.LastAccessedDate  <= @ToDateTime OR @ToDateTime IS NULL)

--68e7bf46-1cdb-4d40-9bc2-20152a85e678  
ORDER BY 
us.LastAccessedDate  desc
--,usd.DataItemName

select top 200
u.UserSessionId 
,u.DataItemName 
,u.DataItemValue  
from UserSessionData u 
	inner join UserSession s
	on s.UserSessionId = u.UserSessionId 
WHERE 1=1
and (u.UserSessionId = @SessionId  OR @SessionId is null)
AND (s.LastAccessedDate  >= @FromDateTime OR @FromDateTime IS NULL)
AND (s.LastAccessedDate  <= @ToDateTime OR @ToDateTime IS NULL)

order by s.LastAccessedDate desc