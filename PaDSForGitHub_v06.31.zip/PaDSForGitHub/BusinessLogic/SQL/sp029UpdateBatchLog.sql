if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp029UpdateBatchLog]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[sp029UpdateBatchLog]
GO

CREATE PROCEDURE sp029UpdateBatchLog(
						@BatchLogId INT 
						,@LogMessage VarChar(7000)
						,@BatchLogStatus Varchar(20) = NULL
										)
AS
/* 	Updates the batch log with a new log messge and optionally status
Oct 2008		James Woosnam	Initial Version
*/
DECLARE @Error INT
SET @Error = 0
IF @Error = 0
BEGIN
	IF NOT Exists(SELECT BatchLogId
				FROM BatchLog
				WHERE BatchLogId = @BatchLogId)
	BEGIN
		  RAISERROR ('Failed. sp029UpdateBatchLog - BatchLog %i does not exist', 16, 1, @BatchLogId)
	END 
END
IF @Error = 0
BEGIN
	INSERT INTO BatchLogLine
			(BatchLogId
			,DateTime
			,BatchLogLineText)
	SELECT @BatchLogID
			,GetDate()
			,LEFT(ISNULL(@LogMessage,''),7000)
	SET @Error =@@Error
	IF @Error <> 0
	BEGIN
	  RAISERROR ('Failed. sp029UpdateBatchLog - Update BatchLogId %i with %s', 16, 1, @BatchLogId,@LogMessage)
	END
END

IF @Error = 0
BEGIN
	IF @BatchLogStatus IS NOT NULL
	BEGIN
		UPDATE BatchLog
		SET BatchLogStatus = @BatchLogStatus
			,EndDateTime = CASE WHEN @BatchLogStatus = 'Complete' THEN GetDate() ELSE EndDateTime END
		WHERE BatchLogId = @BatchLogId
	END
	SET @Error =@@Error
	IF @Error <> 0
	BEGIN
	  RAISERROR ('Failed. sp029UpdateBatchLog - Update BatchLogId %i with status %s', 16, 1, @BatchLogId,@LogMessage)
	END
END

RETURN(@Error)
GO 