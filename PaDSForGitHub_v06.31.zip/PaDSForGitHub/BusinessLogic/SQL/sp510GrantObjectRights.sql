if exists (select * from dbo.sysobjects where id = object_id(N'sp510GrantObjectRights') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure sp510GrantObjectRights
GO

CREATE    PROCEDURE sp510GrantObjectRights(
			@MakeReadOnly BIT = 0
			)
							
AS
/*
Mar 2011	James Woosnam	Security completely rewritten
 --27/7/14    James Woosnam   SIR3577 - Add sp452WebProductStatisticsFromPEPWebUsageLog as adding country upset performance
 --23/9/20	Julian Gates	SIR5043 - Add RemoteUserAutoLogon permissions
 --26/2/21	Julian Gates	SIR5046 - Add UserActionLog permissions
 --17/01/22	Julian Gates	SIR5387 - Add ContentSetAccessClassification
 --17/01/22 Julian Gates	SIR5410 - Remove sp452WebProductStatisticsFromPEPWebUsageLog and sp453PEPWebUsageStatsPost2020
 --30/08/22 Julian Gates	SIR5540 - Add EmailDistribution permissions
*/
DECLARE @SQL as VARCHAR(8000)
DECLARE @DBName VARCHAR(50) = DB_Name()

--Tables
GRANT  SELECT ON BankDeposit TO PaDSSQLServerUser
GRANT  SELECT ON BatchJob TO PaDSSQLServerUser
GRANT  SELECT ON BatchLog TO PaDSSQLServerUser
GRANT  SELECT ON BatchLogLine TO PaDSSQLServerUser
GRANT  SELECT ON Cashbook TO PaDSSQLServerUser
GRANT  SELECT ON Company TO PaDSSQLServerUser
GRANT  SELECT ON CompanyAccount TO PaDSSQLServerUser
GRANT  SELECT ON CompanyBankAccount TO PaDSSQLServerUser
GRANT  SELECT ON Country TO PaDSSQLServerUser
GRANT  SELECT ON Currency TO PaDSSQLServerUser
GRANT  SELECT ON CurrencyConversionRate TO PaDSSQLServerUser
GRANT  SELECT ON DespatchDeliveryArea TO PaDSSQLServerUser
GRANT  SELECT ON DiscountRate TO PaDSSQLServerUser
GRANT  SELECT ON Lookup TO PaDSSQLServerUser
GRANT  SELECT ON Product TO PaDSSQLServerUser
GRANT  SELECT ON ProductAffiliateRate TO PaDSSQLServerUser
GRANT  SELECT ON ProductQualifyingProduct TO PaDSSQLServerUser
GRANT  SELECT ON ProductRate TO PaDSSQLServerUser
GRANT  SELECT ON RemoteUser TO PaDSSQLServerUser
GRANT  SELECT ON RemoteUserRights TO PaDSSQLServerUser
GRANT  SELECT ON RemoteUserAutoLogon TO PaDSSQLServerUser
GRANT  SELECT ON RenewalReminderLog TO PaDSSQLServerUser
GRANT  SELECT ON ReportingCalendar TO PaDSSQLServerUser
GRANT  SELECT ON SalesOrder TO PaDSSQLServerUser
GRANT  SELECT ON SalesOrderLine TO PaDSSQLServerUser
GRANT  SELECT ON SalesOrderLinePart TO PaDSSQLServerUser
GRANT  SELECT ON stblErrorMessageLog TO PaDSSQLServerUser
GRANT  SELECT ON stblParameters TO PaDSSQLServerUser
GRANT  SELECT ON stblTableNumber TO PaDSSQLServerUser
GRANT  SELECT ON Subscriber TO PaDSSQLServerUser
GRANT  SELECT ON SubscriberAddress TO PaDSSQLServerUser
GRANT  SELECT ON SubscriberAffiliate TO PaDSSQLServerUser
GRANT  SELECT ON tmpSubscriberImport TO PaDSSQLServerUser
GRANT  SELECT ON UserSession TO PaDSSQLServerUser
GRANT  SELECT ON UserSessionData TO PaDSSQLServerUser
GRANT  SELECT ON VATRate TO PaDSSQLServerUser
GRANT  SELECT ON SubscriberImportBatch TO PaDSSQLServerUser
GRANT  SELECT ON SubscriberImportBatchLog TO PaDSSQLServerUser
GRANT  SELECT ON FileStore TO PaDSSQLServerUser
GRANT  SELECT ON PEPUsage TO PaDSSQLServerUser
GRANT  SELECT ON PEPUsageSummary TO PaDSSQLServerUser
GRANT  SELECT ON UsageByMonthDocument TO PaDSSQLServerUser
GRANT  SELECT ON LanguageTranslation TO PaDSSQLServerUser
GRANT  SELECT ON EmailDistribution TO PaDSSQLServerUser

--Content tables permissions
GRANT  SELECT ON ContentSet TO PaDSSQLServerUser
GRANT  SELECT ON ContentSetSource TO PaDSSQLServerUser
GRANT  SELECT ON ContentSetSourceItem TO PaDSSQLServerUser
GRANT  SELECT ON ContentSetSourceItem TO PaDSSQLServerUser
GRANT  SELECT ON ContentVideos TO PaDSSQLServerUser
GRANT  SELECT ON ContentVolumes TO PaDSSQLServerUser
GRANT  SELECT ON ContentBooks TO PaDSSQLServerUser
GRANT  SELECT ON ContentJournals TO PaDSSQLServerUser
GRANT  SELECT ON ContentDocuments TO PaDSSQLServerUser
GRANT  SELECT ON ProductContentSet TO PaDSSQLServerUser
GRANT  SELECT ON BankDeposit TO PaDSSQLServerUser
GRANT  SELECT ON CounterReport TO PaDSSQLServerUser
GRANT  SELECT ON EmailDistributionLog TO PaDSSQLServerUser
GRANT  SELECT ON ContentSetAccessClassification TO PaDSSQLServerUser
GRANT  SELECT ON Author TO PaDSSQLServerUser
GRANT  SELECT ON DocumentAuthor TO PaDSSQLServerUser
GRANT  SELECT ON CounterReportInstitution TO PaDSSQLServerUser

--tables that need to be writeable even when db readonly
GRANT INSERT,UPDATE ON			RemoteUser TO PaDSSQLServerUser
GRANT INSERT,UPDATE ON			stblParameters TO PaDSSQLServerUser
GRANT  INSERT,UPDATE ON			BatchJob TO PaDSSQLServerUser
GRANT INSERT,UPDATE ON			BatchLog TO PaDSSQLServerUser
GRANT INSERT,UPDATE ON			BatchLogLine TO PaDSSQLServerUser
GRANT  INSERT,UPDATE,DELETE ON	UserSession TO PaDSSQLServerUser
GRANT INSERT,UPDATE,DELETE ON	UserSessionData TO PaDSSQLServerUser
GRANT UPDATE ON 				Subscriber TO PaDSSQLServerUser
--Views to the audit database 
GRANT  SELECT,INSERT,UPDATE ON AuditLog TO PaDSSQLServerUser
GRANT  SELECT,INSERT,UPDATE,DELETE ON SessionLog TO PaDSSQLServerUser --Also in Views.sql
GRANT  SELECT,INSERT,UPDATE ON PEPWebUsageLog TO PaDSSQLServerUser --Also in Views.sql
GRANT  SELECT,INSERT,UPDATE ON PEPWebSessionLog TO PaDSSQLServerUser
GRANT  SELECT,INSERT,UPDATE ON AuditTableLog TO PaDSSQLServerUser
GRANT  SELECT,INSERT,UPDATE ON UserActionLog to PaDSSQLServerUser
GRANT  SELECT,INSERT,UPDATE ON FederatedFailureLog to PaDSSQLServerUser--SIR5450

DECLARE @Action varchar(200)

IF @MakeReadOnly = 0
BEGIN
	SET @Action = 'GRANT'
END
ELSE
BEGIN
	SET @Action = 'REVOKE'
END

SET @SQL = '
	' + @Action + '  INSERT,UPDATE ON 			BankDeposit TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON 			Cashbook TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON	 		Company TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON			CompanyAccount TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON	CompanyBankAccount TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON 			Country TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON 			Currency TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON 	CurrencyConversionRate TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON 	DespatchDeliveryArea TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON 	DiscountRate TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON 			Lookup TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON 			Product TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON 	ProductAffiliateRate TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON	ProductQualifyingProduct TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON	ProductRate TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON	RemoteUserRights TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON	RemoteUserAutoLogon TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON 			RenewalReminderLog TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON 			ReportingCalendar TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON 			SalesOrder TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON	SalesOrderLine TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON	SalesOrderLinePart TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON 			stblErrorMessageLog TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON 			stblTableNumber TO PaDSSQLServerUser
	' + @Action + '  INSERT ON 					Subscriber TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON	SubscriberAddress TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON 			SubscriberAffiliate TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON	tmpSubscriberImport TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON  			VATRate TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON  			SubscriberImportBatch TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON  			SubscriberImportBatchLog TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE ON  			LanguageTranslation TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	FileStore TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	ContentSet TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	ContentSetSource TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	ContentSetSourceItem TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	ProductContentSet TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	EmailDistributionLog TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	ContentVideos TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	ContentVolumes TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	ContentBooks TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	ContentJournals TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	ContentDocuments TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	ContentSetAccessClassification TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	Author TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON  	DocumentAuthor TO PaDSSQLServerUser
	' + @Action + '  INSERT,UPDATE,DELETE ON 	EmailDistribution TO PaDSSQLServerUser
--2/3/18	James Woosnam	Audit database views are done below
		'
EXECUTE(@SQL)

--Data functions
GRANT  SELECT ON fn495GetGroupProductSubscriptions TO PaDSSQLServerUser
GRANT  SELECT ON f530SecureCompany TO PaDSSQLServerUser
GRANT  EXECUTE ON fn120GetOrderDespatch TO PaDSSQLServerUser
GRANT  EXECUTE ON fn275ContentSetSourceDesc TO PaDSSQLServerUser
GRANT  EXECUTE ON fn508ProductRateDependantsDesc TO PaDSSQLServerUser

--20/05/19	Julian Gates	SIR4759 - Add fn051ObfuscatedText
--21/9/19	James Woosnam	fn051ObfuscatedText does not need object writes

--Read only views
GRANT  SELECT ON vw111SubscriberAffiliate TO PaDSSQLServerUser
GRANT  SELECT ON vw144OrderSummaryBySubscriberCategory TO PaDSSQLServerUser
GRANT  SELECT ON vw400CustomerStatement TO PaDSSQLServerUser
GRANT  SELECT ON vw400InvoiceSummaryAll TO PaDSSQLServerUser
GRANT  SELECT ON vw405InvoiceDetailAll TO PaDSSQLServerUser
GRANT  SELECT ON vw410ReceiptHead TO PaDSSQLServerUser
GRANT  SELECT ON vw420SubscriberTransactionsDetails TO PaDSSQLServerUser
GRANT  SELECT ON vw421SubscriberTransactions1 TO PaDSSQLServerUser
GRANT  SELECT ON vw430SalesDetails TO PaDSSQLServerUser
GRANT  SELECT ON vw440Cashbook TO PaDSSQLServerUser
GRANT  SELECT ON vw550RemoteUser TO PaDSSQLServerUser
GRANT  SELECT ON vwSecureCompany TO PaDSSQLServerUser
GRANT  SELECT ON vw430SalesDetails TO PaDSSQLServerUser
GRANT  SELECT ON vw433SalesOrderReportingParent TO PaDSSQLServerUser
GRANT  SELECT ON vw458PEPUsageSummaryForPivot TO PaDSSQLServerUser

GRANT SELECT , INSERT, UPDATE,ALTER ON UserActionLog2021 to PaDSSQLServerUser
GRANT SELECT , INSERT, UPDATE,ALTER ON UserActionLog2022 to PaDSSQLServerUser
GRANT SELECT , INSERT, UPDATE,ALTER ON UserActionLog2023 to PaDSSQLServerUser
GRANT SELECT , INSERT, UPDATE,ALTER ON UserActionLog2024 to PaDSSQLServerUser


--Select only Functions and stored procedrues
----19/08/20	Julian Gates	SIR5099 - Add fn042GetColumnNames
GRANT  EXECUTE ON fn042GetColumnNames TO PaDSSQLServerUser
GRANT  EXECUTE ON fn017GetParameter TO PaDSSQLServerUser
GRANT  EXECUTE ON f530SubscriberAddressDisplay TO PaDSSQLServerUser
GRANT  EXECUTE ON fn236GetRecurringSubscriptionEndDate TO PaDSSQLServerUser
GRANT  EXECUTE ON sp028InsertBatchLog TO PaDSSQLServerUser
GRANT  EXECUTE ON sp029UpdateBatchLog TO PaDSSQLServerUser
--19/08/20	Julian Gates	SIR5099 - Add sp041AuditLogDisplay
GRANT  EXECUTE ON sp041AuditLogDisplay TO PaDSSQLServerUser
GRANT  EXECUTE ON sp160BatchLogLines TO PaDSSQLServerUser
GRANT  EXECUTE ON sp160BatchLogList TO PaDSSQLServerUser
--21/09/21	Julian Gates	SIR5328 - Add sp163BatchJobDisplay
GRANT  EXECUTE ON sp163BatchJobDisplay TO PaDSSQLServerUser
GRANT  EXECUTE ON sp235WebProducts TO PaDSSQLServerUser
GRANT  EXECUTE ON sp236SubscribersRequiringReminders TO PaDSSQLServerUser
GRANT  EXECUTE ON sp237GetSubscriberPEPWebSubscriptions TO PaDSSQLServerUser
GRANT  EXECUTE ON sp451DebtorsReport TO PaDSSQLServerUser
GRANT  EXECUTE ON sp456PopulatePEPUsage TO PaDSSQLServerUser
GRANT  EXECUTE ON sp457GetPEPUsageView TO PaDSSQLServerUser
GRANT  EXECUTE ON sp491GetSubscriberDetails TO PaDSSQLServerUser
GRANT  EXECUTE ON sp494Getsubscriptions TO PaDSSQLServerUser
GRANT  EXECUTE ON sp500Reseed TO PaDSSQLServerUser
GRANT  EXECUTE ON sp510GrantObjectRights TO PaDSSQLServerUser
--3/9/18	James Woosnam	SIOR4672 - Add sp455ProductSubscriptionsReport
GRANT  EXECUTE ON sp455ProductSubscriptionsReport TO PaDSSQLServerUser
GRANT  EXECUTE ON sp601PopulateActivityLog TO PaDSSQLServerUser
GRANT  EXECUTE ON sp602CorrectStoredUsageAndUserActivityData TO PaDSSQLServerUser

--2/10/12	James Woosnam	SIR2874 - Add AdditionalProducts
GRANT Execute ON TYPE::dbo.AdditionalProducts TO PaDSSQLServerUser

--24/03/20	Julian Gates SIR5049 - Add sp006RebuildIndexes
GRANT Execute ON sp006RebuildIndexes TO PaDSSQLServerUser

GRANT Execute ON sp102GetSubscriberDespatchInfo TO PaDSSQLServerUser

--Action Stored Procedures
--20/05/19	Julian Gates	SIR4759 - Add sp119DeleteOrObfuscateSubscriber
--01/06/20	Julian Gates	Add sp146UpdateSalesOrderSubscribers and sp147SalesOrderSubscriberDropDownSource 
--18/06/20	Julian Gates	Add sp149UpdateSalesOrderProducts and sp148SalesOrderLists
SET @SQL = '
	' + @Action + '   EXECUTE ON sp005GetNextTableNumber TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp009MaskCashbookCreditAndBankFields TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp113MergeSubscribers TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp115RejectSubscriber TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp114MergeSubscriberField TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp118CreateProposedSubscriber TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp119DeleteOrObfuscateSubscriber TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp146UpdateSalesOrderSubscribers TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp147SalesOrderSubscriberDropDownSource TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp148SalesOrderLists TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp149UpdateSalesOrderProducts TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp400AddSalesOrderLines TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp401AddSalesOrderSubscriberLine TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp483SubscriberImport TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp492SubscriberAddUpdate TO PaDSSQLServerUser
	' + @Action + '  EXECUTE ON sp493SubscriberAddressMaint TO PaDSSQLServerUser
'
EXECUTE(@SQL)

--Now the audit database
--'9/2/22     James Woosnam   SIR5432 - SessionLog moved to own DB
SET @SQL = '
USE PaDS_Try_Logs
GRANT SELECT , INSERT, UPDATE,ALTER  ON AuditLog to PaDSSQLServerUser
GRANT SELECT , INSERT, UPDATE,ALTER ON PEPWebUsageLog to PaDSSQLServerUser
GRANT SELECT , INSERT, UPDATE,ALTER ON AuditTableLog to PaDSSQLServerUser
GRANT SELECT , INSERT, UPDATE,ALTER ON PEPWebSessionLog to PaDSSQLServerUser
GRANT SELECT , INSERT, UPDATE,ALTER ON UserActionLog to PaDSSQLServerUser
USE PaDS_SessionLog
GRANT SELECT , INSERT, UPDATE,ALTER ON SessionLog to PaDSSQLServerUser
USE ' + @DBName --2/3/18 - Set back to current DB
EXEC(@sql)


go