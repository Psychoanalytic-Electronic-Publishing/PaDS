/************************************************************************************
Views to build up a picture of total sales for reporting.
	vw431Sales1 - Union of all orders with cancelled orders**
	vw432Sales2 - Join to currency conversion rates
	vw430SalesDetails - Sales records with all appropriate details

23/3/02 - Use the sales order cancelled date rather than the sales order line and use Union All
22/5/03 - Add additional Rate Type and Rate columns to accomadate PEP Requirements
1 Oct 03 - changed vw430SalesDetails to use the Subscriber category from affiliate rather than from 
		subscriber
8/1/04	James Woosnam	Added Distinct to vw430SalesDetails as duplicate affiliate records were causing
						a problem in the report
29/3/11	James Woosnam	Add ParentSubscriberName						
30/11/17	James Woosnam	SIR4527 - Get RateType from ProductRate rather than CompanyAccount
10/1/20		James Woosnam	SIR5006 - Add Affiliate.RateSubscriberName & Affiliate.RateSubscriberType
--18/8/21	James Woosnam	SIR5237 - In vw430SalesDetails if Affiliate.RateSubscriberId on SalesOrderLine is populated use that
--21/10/21	James Woosnam	SIR5341 - SIR5237 corrected 12/10/21
--19/10/21	James Woosmnam	SIR5348 - Affiliate.RateType = 'University' for Product Pwr & Pwi
--21/3/22	James Woosnam	SIR5463 - Change Affiliate.RateSubscriber to ReportingParentSubscriber and get from subquery in vw430SalesDetails
--20/4/22	James Woosnam	SIR5486 - Add vw433SalesOrderReportingParent so it can be used too get reporting parent for orders of all statuses
--25/5/22	James Woosnam	SIR5508 - Excluded zero value cancelled order lines
--18/4/23	James Woosnam	SIR5640 - Set reporting parent to the Block purchaser of the qualifing product.  Allows JV block subscriber to be reporting parent for individual PV order
** 
***********************************************************************************/

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[vw431Sales1]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw431Sales1]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[vw432Sales2]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw432Sales2]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[vw430SalesDetails]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vw430SalesDetails]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'vw433SalesOrderReportingParent') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view vw433SalesOrderReportingParent
GO

CREATE VIEW vw433SalesOrderReportingParent
AS
--20/4/22	James Woosnam	Add Group By to stop duplicate orders in some cases
--20/4/22	James Woosnam	SIR5486 - Add vw433SalesOrderReportingParent so it can be used too get reporting parent for orders of all statuses
--18/4/23	James Woosnam	SIR5640 - Set reporting parent to the Block purchaser of the qualifing product.  Allows JV block subscriber to be reporting parent for individual PV order
	SELECT
		rp.OrderNumber 
		,rp.ReportingParentSubscriberId 
		,ReportingParentSubscriberName = s.SubscriberName 
		,rp.ReportingParentType 
	FROM (
		SELECT DISTINCT  
			so.OrderNumber
			,ReportingParentSubscriberId =MAX( CASE 
									WHEN ISNULL(ParentSubscriber.IsReportingParentOverride,0)=1 THEN ParentSubscriber.SubscriberId
									WHEN ISNULL(Subscriber.IsReportingParentOverride,0)=1 THEN Subscriber.SubscriberId
									WHEN so.OrderType = 'Block' AND ParentSubscriber.EntityType = 'Organisation' AND Subscriber.EntityType = 'Organisation' THEN Subscriber.SubscriberId
									WHEN so.OrderType = 'Block'  OR ParentSubscriber.EntityType = 'Organisation' THEN ParentSubscriber.SubscriberId
									WHEN sol.AffiliateRateSubscriberId IS NOT NULL THEN sol.AffiliateRateSubscriberId 
									--18/4/23	James Woosnam	SIR5640 - Set reporting parent to the Block purchaser of the qualifing product.  Allows JV block subscriber to be reporting parent for individual PV order
									WHEN qso.SubscriberId IS NOT NULL THEN qso.SubscriberId 
									ELSE NULL END)
		--19/10/21	James Woosmnam	SIR5348 - ReportingParentType = 'University' for Product Pwr & Pwi
			,ReportingParentType = MAX(CASE 
									WHEN so.PrimaryProductCode IN ('Pwr','Pwi') THEN 'University'
									WHEN so.OrderType = 'Block'  OR ParentSubscriber.EntityType = 'Organisation' THEN 'Block'
									WHEN sol.AffiliateRateSubscriberId IS NOT NULL THEN 'Individual'
									ELSE 'na' END)
		FROM SalesOrder so
			LEFT JOIN (SELECT sol.OrderNumber 
							,sol.SubscriberId 
							,AffiliateRateSubscriberId = MAX(sol.AffiliateRateSubscriberId )
						FROM SalesOrderLine sol
						GROUP BY sol.OrderNumber
							,sol.SubscriberId 
						) sol
				INNER JOIN Subscriber 
				ON Subscriber.SubscriberId = sol.SubscriberId
			ON sol.OrderNumber = so.OrderNumber
			INNER JOIN Subscriber ParentSubscriber
			ON ParentSubscriber.SubscriberId = so.SubscriberId
			LEFT JOIN ProductQualifyingProduct  pqp
				INNER JOIN Product qp
				ON qp.ProductCode = pqp.ProductCode 
				and qp.CompanyID = 1
			on pqp.ProductCode = so.PrimaryProductCode 
			left JOIN SalesOrderLine qsol
				INNER JOIN SalesOrder qso
				ON qso.OrderNumber = qsol.OrderNumber 
				AND qso.OrderType = 'Block'
			on qsol.SubscriberId = sol.SubscriberId 
			and qsol.ProductCode = pqp.QualifyingProductCode 
		GROUP BY 
			so.OrderNumber) rp
		LEFT JOIN Subscriber s
		ON s.SubscriberId = rp.ReportingParentSubscriberId


GO

CREATE VIEW vw431Sales1
AS
SELECT   SalesOrder.SubscriberId As AccountSubscriberId
	, SalesOrder.CompanyId
	,SalesOrder.CurrencyCode
	,SalesOrder.OrderNumber
	,SalesOrderLine.SubscriberId
	,AffiliateRateSubscriberId = SalesOrderLine.AffiliateRateSubscriberId 
	,ParentSubscriberId = SalesOrder.SubscriberId
	,SalesOrderLine.ProductCode
	,Product.ProductReportName
	, SalesOrder.OrderDate AS [Date]
	, 'Order' AS TransactionType
	, OrderType
	, SalesOrderLine.ProductRate
	, SalesOrderLine.ProductRateId
--30/11/17	James Woosnam	SIR4527 - Get RateType from ProductRate rather than CompanyAccount
	,RateType = (SELECT pr.RateType FROM ProductRate pr WHERE pr.ProductRateId = SalesOrderLine.ProductRateId )
	, SalesOrderLine.Quantity
	, SalesOrderLine.Quantity * Product.ReportProportion AS ProductCodeQuantity
	, SalesOrderLine.AmountProduct * Product.ReportProportion AS AmountBase
	, CASE  IsNull(SalesOrder.AmountNet,0)
		WHEN 0 THEN 0
		ELSE cast(SalesOrderline.AmountProduct as float) / cast(SalesOrder.AmountNet as float) * (SalesOrder.AmountNet - ISNUll(SalesOrder.AmountDiscount,0) ) 
	  END  * Product.ReportProportion As AmountInclDiscount
	, CASE  IsNull(SalesOrder.AmountNet,0)
		WHEN 0 THEN ISNull(Salesorder.AmountCarriage,0) * cast(SalesOrderLine.Quantity as float) / cast(Salesorder.TotalQuantity AS Float)
		ELSE cast(SalesOrderline.AmountProduct as float) / cast(SalesOrder.AmountNet as float) * (SalesOrder.AmountNet - ISNUll(SalesOrder.AmountDiscount,0) + IsNull(SalesOrder.AmountCarriage,0)) 
	  END * Product.ReportProportion As AmountInclDiscAndCarriage
	, CASE  IsNull(SalesOrder.AmountNet,0)
		WHEN 0 THEN (ISNull(Salesorder.AmountGross,0))* SalesOrderLine.Quantity / Salesorder.TotalQuantity
		ELSE cast(SalesOrderline.AmountProduct as float) / cast(SalesOrder.AmountNet as float) * ISNUll(SalesOrder.AmountGROSS,0)
	  END * Product.ReportProportion As AmountGross
FROM SalesOrderLine
	INNER JOIN SalesOrder
	On SalesOrder.OrderNumber = SalesOrderLine.OrderNumber
	INNER JOIN vw520ReportProduct Product
	On Product.ProductCode = SalesOrderLine.ProductCode
WHERE SalesOrder.SalesOrderStatus IN ('Confirmed','Complete','Cancelled')
--25/5/22	James Woosnam	SIR5508 - Excluded zero value cancelled order lines
AND NOT (SalesOrderLine.IsCancel=1 AND SalesOrderLine.AmountProduct=0)
UNION All
SELECT   SalesOrder.SubscriberId As AccountSubscriberId
	, SalesOrder.CompanyId
	,SalesOrder.CurrencyCode
	,SalesOrder.OrderNumber
	,SalesOrderLine.SubscriberId
	,AffiliateRateSubscriberId = SalesOrderLine.AffiliateRateSubscriberId 
	,ParentSubscriberId = SalesOrder.SubscriberId
	,SalesOrderLine.ProductCode
	,Product.ProductReportName
	, Cast(cast(SalesOrder.CancelledDate as Varchar(11)) as DateTime) AS [Date]
	, 'OrderCancelled' AS TransactionType
	, OrderType
	, SalesOrderLine.ProductRate
	, SalesOrderLine.ProductRateId
--30/11/17	James Woosnam	SIR4527 - Get RateType from ProductRate rather than CompanyAccount
	,RateType = (SELECT pr.RateType FROM ProductRate pr WHERE pr.ProductRateId = SalesOrderLine.ProductRateId )
	, SalesOrderLine.Quantity * -1 As Quantity
	, SalesOrderLine.Quantity * Product.ReportProportion * -1  AS ProductCodeQuantity
	, SalesOrderLine.AmountProduct * Product.ReportProportion * -1.00000 AS AmountBase
	, CASE  IsNull(SalesOrder.AmountNet,0)
		WHEN 0 THEN 0
		ELSE cast(SalesOrderline.AmountProduct as float) / cast(SalesOrder.AmountNet as float) * (SalesOrder.AmountNet - ISNUll(SalesOrder.AmountDiscount,0) ) 
	  END  * Product.ReportProportion  * -1.00000 As AmountInclDiscount
	, CASE  IsNull(SalesOrder.AmountNet,0)
		WHEN 0 THEN ISNull(Salesorder.AmountCarriage,0) * cast(SalesOrderLine.Quantity as float) / cast(Salesorder.TotalQuantity AS Float)
		ELSE cast(SalesOrderline.AmountProduct as float) / cast(SalesOrder.AmountNet as float) * (SalesOrder.AmountNet - ISNUll(SalesOrder.AmountDiscount,0) + IsNull(SalesOrder.AmountCarriage,0)) 
	  END * Product.ReportProportion * -1.00000 As AmountInclDiscAndCarriage
	, CASE  IsNull(SalesOrder.AmountNet,0)
		WHEN 0 THEN (ISNull(Salesorder.AmountGross,0))* SalesOrderLine.Quantity / Salesorder.TotalQuantity
		ELSE cast(SalesOrderline.AmountProduct as float) / cast(SalesOrder.AmountNet as float) * ISNUll(SalesOrder.AmountGROSS,0)
	  END * Product.ReportProportion * -1.00000 As AmountGross
FROM SalesOrderLine
	INNER JOIN SalesOrder
	On SalesOrder.OrderNumber = SalesOrderLine.OrderNumber
	INNER JOIN vw520ReportProduct Product
	On Product.ProductCode = SalesOrderLine.ProductCode
WHERE SalesOrder.SalesOrderStatus IN ('Cancelled')
--25/5/22	James Woosnam	SIR5508 - Excluded zero value cancelled order lines
AND NOT (SalesOrderLine.IsCancel=1 AND SalesOrderLine.AmountProduct=0)

Go
CREATE VIEW vw432Sales2
AS
SELECT   t1.*
	,Company.CurrencyCode As BaseCurrencyCode
	,Rate.ConversionRate * t1.AmountBase As AmountBaseInBaseCurrency
	,Rate.ConversionRate * t1.AmountInclDiscount As AmountInclDiscountInBaseCurrency
	,Rate.ConversionRate * t1.AmountInclDiscAndCarriage As AmountInclDiscAndCarriageInBaseCurrency
	,Rate.ConversionRate * t1.AmountGross As AmountGrossInBaseCurrency
FROM vw431Sales1 t1
	INNER JOIN Company
	On t1.CompanyId = Company.CompanyId
	Left Join CurrencyConversionRate Rate
	On Rate.CompanyId = t1.CompanyId
	AND Rate.FromCurrencyCode = t1.CurrencyCode
	AND Rate.ToCurrencyCode = Company.CurrencyCode
	AND t1.[Date] Between Rate.StartDate and Rate.EndDate



Go
CREATE VIEW vw430SalesDetails
AS
SELECT DISTINCT  CompanyName
	, st.CompanyId
	, CountryName
	, CompanyAccount.AccountType
--30/11/17	James Woosnam	SIR4527 - Get RateType from ProductRate rather than CompanyAccount
	, RateType = ISNULL(st.RateType, CompanyAccount.RateType)
	, st.ProductRate
	, AccountSubscriber.SubscriberName + ' (' + cast(AccountSubscriber.SubscriberId  as varchar) + ')' As AccountName
	, SubscriberAffiliate.SubscriberCategory
	, Subscriber.SubscriberName + ' (' + cast(Subscriber.SubscriberId as varchar) + ')' As SubscriberName
	, ParentSubscriber.SubscriberName + ' (' + cast(ParentSubscriber.SubscriberId as varchar) + ')' As ParentSubscriberName
--10/1/20		James Woosnam	SIR5006 - Add Affiliate.RateSubscriberName & Affiliate.RateSubscriberType
--21/3/22	James Woosnam	SIR5463 - Change AffiliateRateSubscriber to ReportingParentSubscriber and get from subquery in vw430SalesDetails
	,ReportingParentSubscriberName = RepParentSub.SubscriberName
	,ReportingParentSubscriberNameAndId = RepParentSub.SubscriberName + '(' + CONVERT(VARCHAR,RepParent.ReportingParentSubscriberId) + ')'
	,ReportingParentSubscriberId = RepParent.ReportingParentSubscriberId
--19/10/21	James Woosmnam	SIR5348 - ReportingParentType = 'University' for Product Pwr & Pwi
	,ReportingParentType = RepParent.ReportingParentType
	, st.CurrencyCode As Currency
	, st.OrderNumber
	, st.ProductReportName As Product
	, st.ProductCode
	, [Year]
	, [Quarter]
	, [Month]
	, st.[Date]
	, st.TransactionType
	, st.Quantity
	, st.ProductCodeQuantity
	, st.AmountGross As AnountInNative
	, st.AmountGrossInBaseCurrency As AmountInBase
FROM vw432Sales2 st
	INNER JOIN Subscriber
	ON Subscriber.SubscriberId = st.SubscriberId
	INNER JOIN Subscriber ParentSubscriber
	ON ParentSubscriber.SubscriberId = st.ParentSubscriberId
	INNER JOIN Subscriber AccountSubscriber
	ON AccountSubscriber.SubscriberId = st.AccountSubscriberId
	INNER JOIN CompanyAccount
	ON CompanyAccount.SubscriberId = st.AccountSubscriberId
	AND CompanyAccount.CompanyId = st.CompanyId
	INNER JOIN Company
	ON Company.CompanyId = st.CompanyId
	LEFT JOIN SubscriberAffiliate
	ON SubscriberAffiliate.parentSubscriberId = Company.GroupParentSubscriberId
	AND SubscriberAffiliate.ChildSubscriberId = st.SubscriberId
	AND st.[Date] BETWEEN SubscriberAffiliate.StartDate AND SubscriberAffiliate.EndDate
	Left Join Country
	On Country.CountryId = Subscriber.PrimaryCountryId
	LEFT JOIN ReportingCalendar
	ON ReportingCalendar.CalendarDate = st.[Date]
--21/3/22	James Woosnam	SIR5463 - Change AffiliateRateSubscriber to ReportingParentSubscriber and get from subquery in vw430SalesDetails
--21/3/22	James Woosnam	SIR5463 - If populated use IsReportingParentOverride to override the parent subscriber
--20/4/22	James Woosnam	SIR5486 - Use vw433SalesOrderReportingParent so it can be used too get reporting parent for orders of all statuses
	LEFT JOIN vw433SalesOrderReportingParent RepParent
		INNER JOIN Subscriber RepParentSub
		ON RepParentSub.SubscriberId = RepParent.ReportingParentSubscriberId
	ON RepParent.OrderNumber = st.OrderNumber

GO
