if exists (select * from dbo.sysobjects where id = object_id(N'fn021RemoveNonAlphanumericCharacters') and xtype in (N'FN', N'IF', N'TF'))
drop function fn021RemoveNonAlphanumericCharacters
GO
Create Function fn021RemoveNonAlphanumericCharacters(@Temp VarChar(MAX))
Returns VarChar(MAX)
AS
Begin

    Declare @KeepValues as varchar(50)
    Set @KeepValues = '%[^a-z0-9]%'
    While PatIndex(@KeepValues, @Temp) > 0
        Set @Temp = Stuff(@Temp, PatIndex(@KeepValues, @Temp), 1, '')

    Return @Temp
END

GO
GRANT  EXECUTE ON fn021RemoveNonAlphanumericCharacters TO PaDSSQLServerUser

 