'********************
' March 2022
' This code has been put in TFS file BusinessLogic\ExcelMacros\CashbookMacro.vb to allow change tracking
'*******************
'Option Explicit 'Commented out as .NET VB adds an On at the end
Dim ButtonLeftStart As Integer
Dim wkb As Excel.Workbook
Sub cmdSetDefault_Click()
    FormatPivot "Default"
    End Sub

Sub cmdByJournal_Click()
    FormatPivot "ByJournal"
    End Sub
Sub AddButton(Name As String, ButtonText As String, ActionSub As String)
    '****Also need a ...Click sub
    On Error Resume Next
    wkb.Sheets("Pivot").Shapes(Name).Select
    If Err() <> 0 Then
        'Assume button not there so add it
        wkb.Sheets("Pivot").Buttons.Add(ButtonLeftStart, 40, 60, 20).Select
        wkb.Parent.Selection.Name = Name
    End If
    wkb.Parent.Selection.OnAction = ActionSub
    wkb.Parent.Selection.Characters.Text = ButtonText
    wkb.Parent.Selection.ShapeRange.Left = ButtonLeftStart
    wkb.Parent.Selection.ShapeRange.Width = 60
    ButtonLeftStart = ButtonLeftStart + 60
    wkb.Parent.Selection.ShapeRange.Top = 40

    wkb.Parent.Selection.ShapeRange.Height = 15

End Sub
Public Function FormatPivot(strFormatType As String)
    '***************************************************
    '2022 - Code in TFS see top
    '******************************************************
    On Error GoTo ProcedureError

    Dim pvt As Excel.PivotTable
    Dim fld As Excel.PivotField

    Dim pi As Excel.PivotItem

        Set wkb = ActiveWorkbook
    
        Set pvt = wkb.Sheets("Pivot").PivotTables("Pivot")
    
        On Error Resume Next

    For Each fld In pvt.PivotFields
        fld.Orientation = xlHidden
    Next
    For Each fld In pvt.DataFields
        fld.Orientation = xlHidden
    Next
    On Error GoTo ProcedureError

    Select Case strFormatType
        Case "Default"
            '***************************************************
            '2022 - Code in TFS see top
            '******************************************************
            pvt.PivotFields("MonthStartDate").Orientation = xlRowField
            pvt.PivotFields("MonthStartDate").AutoGroup

            pvt.PivotFields("DataType").Orientation = xlColumnField

            pvt.AddDataField pvt.PivotFields("TotalHits"), "Hits", xlSum

            For Each fld In pvt.DataFields
                fld.NumberFormat = "#,##0"
            Next
         '   pvt.DataPivotField.Orientation = xlColumnField
          '  pvt.PivotFields("DateTime").NumberFormat = "D-MMM-YY HH:MM:SS"
        Case "ByJournal"
            '***************************************************
            '2022 - Code in TFS see top
            '******************************************************
            pvt.PivotFields("MonthStartDate").Orientation = xlColumnField
            pvt.PivotFields("MonthStartDate").AutoGroup

            pvt.PivotFields("Journal").Orientation = xlRowField

            pvt.AddDataField pvt.PivotFields("TotalHits"), "Hits", xlSum

            For Each fld In pvt.DataFields
                fld.NumberFormat = "#,##0"
            Next
            pvt.DataPivotField.Orientation = xlColumnField
    End Select


    With wkb.Sheets("Pivot").PageSetup
        .PrintTitleRows = ""
        .PrintTitleColumns = ""
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
    End With
    wkb.Sheets("Pivot").Columns("A:X").EntireColumn.AutoFit
    wkb.Sheets("Pivot").Select
    wkb.Sheets("Pivot").Cells(5, 3).Select
    ButtonLeftStart = 1
    AddButton "cmdDefault", "By Year", "cmdSetDefault_Click"
        AddButton "cmdByJournal", "By Journal", "cmdByJournal_Click"

         wkb.Sheets("Pivot").Cells(1, 1).Select
ProcedureExit:
    Exit Function

ProcedureError:
    Select Case Err.Number
        Case Else
            GlobalErr Err.Number, Err.Description, "FormatPivot"
            Resume ProcedureExit
            Resume
    End Select

End Function



Public Function GlobalErr(lngErrNumber As Long, strErrString As String, Optional strErrLocation As Variant)
    '***************************************************
    '2022 - Code in TFS see top
    '******************************************************

    If IsMissing(strErrLocation) Then
        strErrLocation = "In Report Template"
    End If

    Sheets("Criteria").Range("a10").Value = "UNEXPECTED ERROR: " & lngErrNumber _
                    & "-" & strErrString _
                    & "-" & strErrLocation
End Function























