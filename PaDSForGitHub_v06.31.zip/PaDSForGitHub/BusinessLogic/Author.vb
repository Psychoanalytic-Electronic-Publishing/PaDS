﻿'Modification History
'05/09/22   Julian Gates    SIR5553 - Initial Version

Imports Microsoft.VisualBasic
Imports System.Data
Imports System.Data.SqlClient

Public Class Author
#Region "Class Properties"
    Public MainDataset As New DataSet
    Public ReadonlyDataset As New DataSet
    Dim UserSession As BusinessLogic.UserSession

    Dim _AuthorId As String = Nothing
    Public Property AuthorId() As String
        Get
            If Me._AuthorId = Nothing Then
                If Me.MainDataset.Tables.Count > 0 Then
                    Me._AuthorId = Me.AuthorRow("AuthorId")
                End If
            End If
            Return Me._AuthorId
        End Get
        Set(ByVal Value As String)
            _AuthorId = Value
            'initilise dataset
            Me.Initilise()
        End Set
    End Property
    Public ReadOnly Property AuthorName As String
        Get
            Return Me.AuthorRow("AuthorName")
        End Get
    End Property

    Private _db As Database = Nothing
    Public Property db() As Database
        Get
            Return (Me._db)
        End Get
        Set(ByVal value As Database)

            Me._db = value
        End Set
    End Property
    Public Enum AuthorStates
        Active
        Inactive
    End Enum
    Public Property AuthorStatus() As AuthorStates
        Get
            Return [Enum].Parse(GetType(AuthorStates), Me.AuthorRow("AuthorStatus"))
        End Get
        Set(ByVal value As AuthorStates)
            Me.AuthorRow("AuthorStates") = value.ToString
        End Set
    End Property
#End Region

#Region "DependantTables"
    '***********************************************
    'Author
    Public ReadOnly Property Author() As DataTable
        Get
            If Me.MainDataset.Tables("Author") Is Nothing Then
                Me.daAuthor.Fill(Me.MainDataset, "Author")
            End If
            Dim keyFields() As System.Data.DataColumn = {Me.MainDataset.Tables("Author").Columns("AuthorId")}
            Me.MainDataset.Tables("Author").PrimaryKey = keyFields

            Return Me.MainDataset.Tables("Author")
        End Get
    End Property
    Private _daAuthor As SqlDataAdapter
    Private ReadOnly Property daAuthor() As SqlDataAdapter
        Get
            If Me._daAuthor Is Nothing Then
                Dim sql As String
                sql = "SELECT * "
                sql += " FROM Author"
                If Me.AuthorId = "" Then
                    sql += " WHERE 1=2"
                Else
                    sql += " WHERE AuthorId=@AuthorId"
                End If

                Dim cmd As New SqlCommand(sql, Me.db.DBConnection, Me.db.DBTransaction)
                If Me.AuthorId <> "" Then
                    cmd.Parameters.Add(New System.Data.SqlClient.SqlParameter("@AuthorId", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current _
                                                                             , Me.AuthorId))
                End If

                _daAuthor = New SqlDataAdapter(cmd)
                Dim cmdBld As New System.Data.SqlClient.SqlCommandBuilder(_daAuthor)
                _daAuthor.UpdateCommand = cmdBld.GetUpdateCommand()
                _daAuthor.InsertCommand = cmdBld.GetInsertCommand()
                _daAuthor.DeleteCommand = cmdBld.GetDeleteCommand()

            End If
            If Not Me.db.DBTransaction Is Nothing Then
                _daAuthor.InsertCommand.Transaction = Me.db.DBTransaction
                _daAuthor.UpdateCommand.Transaction = Me.db.DBTransaction
                _daAuthor.DeleteCommand.Transaction = Me.db.DBTransaction
            End If
            Return _daAuthor
        End Get
    End Property

    Public ReadOnly Property AuthorRow() As DataRow
        Get
            If Me.Author.Rows.Count = 0 Then
                Me.daAuthor.Fill(Me.MainDataset.Tables("Author"))
                If Me.Author.Rows.Count = 0 Then
                    Throw New Exception("UserError: Author Id can't be found")
                End If
            End If
            Return Me.Author.Rows(0)
        End Get
    End Property

    Private Sub Initilise()
        Dim xx As Integer = 0
        MainDataset.Clear()
        Me._daAuthor = Nothing
        xx = Me.Author.Rows.Count
    End Sub
    '***********************************************
#End Region
    Sub New(ByVal db As Database)
        Me.db = db
    End Sub
    Sub New(ByVal AuthorId As Integer, ByVal db As Database)
        Me.db = db
        Me.AuthorId = AuthorId
        Me.Initilise()
    End Sub
    Sub New(ByVal db As BusinessLogic.Database, ByVal UserSession As BusinessLogic.UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.AuthorId = 0
    End Sub

    Sub New(ByVal AuthorId As String, ByVal db As BusinessLogic.Database, ByVal UserSession As BusinessLogic.UserSession)
        Me.db = db
        Me.UserSession = UserSession
        Me.AuthorId = AuthorId
        Me.Initilise()
    End Sub

#Region "Actions"
    Public Sub Save()
        Dim sql As String = ""
        Dim TranStartedHere As Boolean = False
        If db.DBTransaction Is Nothing Then
            Me.db.BeginTran()
            TranStartedHere = True
        End If
        Try
            Select Case Me.AuthorRow.RowState
                Case DataRowState.Added, DataRowState.Modified
                    AuthorRow("LastUpdatedDateTime") = Now()
                    AuthorRow("LastUpdatedByUserId") = UserSession.UserName20
            End Select
            Me.daAuthor.Update(Me.MainDataset, "Author")

            If TranStartedHere Then
                Me.db.CommitTran()
            End If
        Catch eDBCon As System.Data.DBConcurrencyException
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw eDBCon
        Catch e As Exception
            If TranStartedHere Then
                Me.db.RollbackTran()
            End If
            Throw e
        End Try
    End Sub
#End Region
End Class

