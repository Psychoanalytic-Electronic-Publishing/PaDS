﻿Imports System.Data.SqlClient
Imports System.Data
Public Class Database
    '30/9/10    James Woosnam   Optionally do Injection Check
    '31/5/12    James Woosnam   VersionNumber moved into Database

    Public PaDSVersion As String = "v06.31m (16th May 2024)"
#Region "Class Properties"
    Public Property IsWebServerPrimaryOrSecondary As String = "Unknown"
    Public Property IsDatabaseServerPrimaryOrSecondary As String = "Unknown"
    '6/2/11     James Woosnam   Store conenction string seperatly as if it contains a password DBConnection removes it so it can't be used for passing on
    Dim _DBConnectionString As String = Nothing
    Public Property DBConnectionString As String
        Get
            If Me._DBConnectionString Is Nothing Then
                Throw New Exception("DBConnectionString is not populated, this could be because Database was instantiated via an exisitng DB rather than a connection")

            End If
            Return _DBConnectionString
        End Get
        Set(ByVal Value As String)
            _DBConnectionString = Value
        End Set
    End Property

    Public SecondaryConnectionString As String = Nothing
    Dim _SecondaryDB As Database = Nothing
    Public ReadOnly Property SecondaryDB As Database
        Get
            If _SecondaryDB Is Nothing Then
                If Me.SecondaryConnectionString = Nothing Then
                    Throw New Exception("Secondary Connection String is not populated")
                End If
                Try
                    _SecondaryDB = New Database(Me.SecondaryConnectionString)
                Catch ex As Exception
                    Throw New Exception("Secondary Database can't be opened:" & ex.Message, ex)
                End Try
            End If
            Return _SecondaryDB
        End Get
    End Property

    Dim _DBConnection As SqlConnection = Nothing
    Public Property DBConnection() As SqlConnection
        Get
            Return _DBConnection
        End Get
        Set(ByVal value As SqlConnection)
            Try
                Me._DBConnection = value
                If Me._DBConnection.State = ConnectionState.Closed _
                  Or Me._DBConnection.State = ConnectionState.Broken Then
                    Me._DBConnection.Open()
                End If
                If Me.DBConnection.State <> ConnectionState.Open Then
                    Throw New Exception("DB Connection state is '" & Me._DBConnection.State.ToString & "'")
                End If
            Catch ex As Exception
                Throw New Exception("Can't open DB Connection:'" & value.ConnectionString & vbCrLf & ex.ToString)
            End Try
        End Set
    End Property
    Private _DBTransaction As SqlTransaction
    Public Property DBTransaction() As SqlTransaction
        Get
            Return _DBTransaction
        End Get
        Set(ByVal Value As SqlTransaction)
            _DBTransaction = Value
        End Set
    End Property
    Dim _CommandTimeout As Integer
    Public Property CommandTimeout() As Integer
        Get
            If Me._CommandTimeout = Nothing Then
                Try
                    If IsNumeric(Me.GetParameterValue("DBCommandTimeout")) Then
                        Me._CommandTimeout = Me.GetParameterValue("DBCommandTimeout")
                    End If
                Catch ex As Exception

                End Try

            End If
            Return Me._CommandTimeout
        End Get
        Set(ByVal Value As Integer)
            Me._CommandTimeout = Value
        End Set
    End Property
    Public ReadOnly Property ShowFullError() As Boolean
        Get
            Try
                Return Me.GetParameterValue("ShowFullError")
            Catch ex As Exception
                Return False
            End Try
        End Get
    End Property
    Dim _SQL As String
    Public Property SQL() As String
        Get
            Return Me._SQL
        End Get
        Set(ByVal Value As String)
            Me._SQL = Value
        End Set
    End Property

    Public ReadOnly Property IsOnLiveServer As Boolean
        Get
            Try
                Dim LiveIPAddresses As String = ""
                Try
                    If LiveIPAddresses = "" Then LiveIPAddresses = Me.GetParameterValue("LiveIPAddresses")
                Catch ex As Exception
                    'Parameter might not exists, or the secondary server may not be available
                    If ex.Message.Contains(" does not exist") Then
                        Throw New Exception("To use IsOnLiveServer propoerty of Database class the LiveIPAddresses parameter must be added and should only ever be populated with the live ip addresses of the Amazon servers:" & ex.Message)
                    Else
                        Throw ex
                    End If
                End Try
                For Each addr As Net.IPAddress In Net.Dns.GetHostEntry(Net.Dns.GetHostName).AddressList
                    If LiveIPAddresses.Contains(addr.ToString) Then
                        Return True
                    End If
                Next
            Catch ex As Exception
                Throw New Exception("IsOnLiveServer failed:" & ex.Message, ex)
            End Try
            Return False
        End Get
    End Property
    Public ReadOnly Property SupportEmailLink As String
        '09/10/2017 Julian Gates    SIR4490 - Add pepSupportEmailLink to resend password error text.
        '1/11/2019  James Woosnam   SIR4763 - Moved here to be generic

        Get
            Return "<a href=""mailto:" & Me.GetParameterValue("PepSupportEmailAddress") & """>" & Me.GetParameterValue("PepSupportEmailAddress") & "</a>"
        End Get
    End Property
#End Region

    Public Sub New()

    End Sub
    Public Sub New(ByVal ConectionString As String)
        Try
            Me._DBConnection = New SqlConnection(ConectionString)
            Me.DBConnection.Open()
            Me.DBConnectionString = ConectionString
        Catch ex As Exception
            Throw New Exception("Invalid Connection String:" & ex.Message, ex)
        End Try
    End Sub
    Public Sub New(ByVal DBConection As SqlConnection)

        Me.DBConnection = DBConection
    End Sub
    Public Function GetDataTableFromSQL() As DataTable
        Return GetDataTableFromSQL(Me.SQL)
    End Function
    Public Function GetDataTableFromSQL(ByVal cmd As SqlCommand) As DataTable
        Try
            Me.SQL = cmd.CommandText
            If Me.CommandTimeout <> Nothing Then
                cmd.CommandTimeout = Me.CommandTimeout
            End If
            Me.CommandTimeout = cmd.CommandTimeout
            For Each param As SqlParameter In cmd.Parameters
                Select Case param.DbType
                    Case DbType.String
                        param.Value = param.Value.ToString.Replace("'", "''")
                End Select
            Next
            Dim da As New SqlDataAdapter(cmd)
            Dim tbl As New DataTable
            da.Fill(tbl)
            Return tbl
        Catch ex As Exception
            '26/4/22    James Woosnam   Always put out full message & sql
            Dim message As String = "Failed to build table:" & ex.Message & Environment.NewLine & "SQL:" & SQL
            Throw New Exception(message, ex)
        End Try
    End Function
    Public Function GetDataTableFromSQL(ByVal SQL As String) As DataTable
        Me.SQL = SQL
        If Me.SQL = Nothing Then
            Throw New Exception("SQL not found for GetDataTableFromSQL")
        End If
        Try

            Dim cmd As New SqlCommand(SQL, Me.DBConnection, Me.DBTransaction)
            Return Me.GetDataTableFromSQL(cmd)
        Catch ex As Exception
            Throw ex
        End Try
    End Function
    Public Sub BeginTran()

        'Only open tran is not already running, otherwise we just join the exisitng one
        If Me.DBTransaction Is Nothing Then
            Me.DBTransaction = Me.DBConnection.BeginTransaction
        End If

    End Sub
    Public Sub CommitTran()
        Me.DBTransaction.Commit()
        Me.DBTransaction = Nothing
    End Sub
    Public Sub RollbackTran()
        Me.DBTransaction.Rollback()
        Me.DBTransaction = Nothing
    End Sub
    Sub CheckSQLStringParameterForInjection(ByVal sqlParameter As String)
        Dim blackList As String() = {"--", ";--", ";", "/*", "*/", "@@",
                                        "char ", "nchar ", "varchar ", "nvarchar ", "alter ",
                                       "begin ", "cast ", "create ", "cursor ", "declare ", "delete ",
                                       "drop ", "exec ", "execute ", "fetch ", "insert ",
                                       "kill ", "open ", "select ", "sys", "sysobjects", "syscolumns",
                                       "table ", "update "}
        For i As Integer = 0 To blackList.Length - 1
            If (sqlParameter.IndexOf(blackList(i), StringComparison.OrdinalIgnoreCase) >= 0) Then
                Throw New Exception("SQL Injection Check Fail")
            End If
        Next
    End Sub
    Function DLookup(ByVal ColumnName As String, ByVal TableName As String, ByVal Criteria As String, Optional ByVal DoInjectionCheck As Boolean = False) As Object
        '*******************************************************************************************
        'Purpose:   Replicates the Access DLookup function
        '			Only difference is that the criteria is not optional
        '*******************************************************************************************
        '30/9/10    James Woosnam   Optionally do Injection Check
        If DoInjectionCheck Then
            CheckSQLStringParameterForInjection(ColumnName)
            CheckSQLStringParameterForInjection(TableName)
            CheckSQLStringParameterForInjection(Criteria)
        End If

        Dim sql As String = ""
        sql = "Select " & ColumnName
        If TableName <> "" Then sql += " FROM " & TableName

        If Criteria <> "" Then
            sql += " WHERE " & Criteria
        End If
        Try
            Dim cmd As New SqlCommand(sql, Me.DBConnection, Me.DBTransaction)
            Dim dr As SqlClient.SqlDataReader = cmd.ExecuteReader()
            Try
                If dr.Read() Then
                    Return dr(0)
                Else
                    Return Nothing
                End If
            Catch ex As Exception
                Throw ex
            Finally
                dr.Close()
            End Try
        Catch ex As Exception
            Throw New Exception("Dlookup Failed.", New Exception(ex.Message & " SQL:" & sql))
        End Try

    End Function
    Function vFQ(ByVal InValue As Object, ByVal DataType As String) As String
        '***************************************************************************
        ' Purpose:      Takes in a vartiant and a type and returns a variant
        '               that can be used in a query criteria expresion
        ' Returns:      query expresion number
        'Mods
        '====
        '*****************************************************************
        If IsDBNull(InValue) Then
            Return "NULL"
        End If
        Select Case UCase(DataType)
            Case "NUMBER", "N"
                Return InValue
            Case "DATE", "D"
                Dim dt As Date
                If Not IsDate(InValue) Then
                    Throw New Exception("Value:" & InValue & " is not a date. In vFQ")
                Else
                    dt = CDate(InValue)
                End If
                Return "'" & dt.ToString("dd-MMM-yyyy HH:mm:ss") & "'"
                'Possibley "'" & inDate.ToString("yyyy-MM-dd HH:mm:ss") & "'"
            Case "STRING", "S"
                Return "'" & InValue & "'"
            Case "BOOLEAN", "B"
                If InValue = "False" Then
                    InValue = 0
                Else
                    InValue = 1
                End If
                Return InValue
            Case "DECIMAL", "DEC"
                Return CDbl(InValue)
            Case Else
                Throw New Exception("SYSTEM ERROR: Invalid dataype used in vFQ:" & DataType)
        End Select

    End Function
    Function GetNextNumber(ByVal NumberKey As String) As Long
        '*******************************************************************************************
        'Purpose:   Returns the next number for the passed key
        '			This is looked up in the database table stblTableNumber
        '			As this is usually done as part of a record insert the connection
        '			is passed so it can be in the same transaction
        '*******************************************************************************************

        Dim cmd As New System.Data.SqlClient.SqlCommand("sp005GetNextTableNumber", Me.DBConnection, Me.DBTransaction)
        cmd.CommandType = CommandType.StoredProcedure

        With (cmd.Parameters.Add("RETURN_VALUE", SqlDbType.Int))
            .Direction = ParameterDirection.ReturnValue
        End With

        With (cmd.Parameters.Add("@TableName", SqlDbType.VarChar, 50))
            .Direction() = ParameterDirection.Input
            .Value = NumberKey
        End With
        With cmd.Parameters.Add("@NextNumber", SqlDbType.Int)
            .Direction = ParameterDirection.Output
        End With

        cmd.ExecuteNonQuery()
        If cmd.Parameters("Return_Value").Value <> 0 Then
            Throw New Exception("Error getting next table number for table:" & NumberKey)
        Else
            Return cmd.Parameters("@NextNumber").Value
        End If
    End Function
    Public Function IsDBNull(ByVal Value As Object, ByVal NullReturn As Object) As Object
        If Value Is System.DBNull.Value Then
            Return NullReturn
        Else
            Return Value
        End If
    End Function
    Public Function IsDBNull(ByVal Value As Object) As Boolean
        If Value Is System.DBNull.Value Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Function GetParameterValue(ByVal ParameterName As String) As String
        Dim value As Object = Nothing
        Try
            value = Me.DLookup("ParameterValue", "stblParameters", "ParameterName='" & ParameterName & "'")
            If value = Nothing Then
                Throw New Exception("Parameter '" & ParameterName & "' does not exist")
            Else
                Return value
            End If

        Catch ex As Exception
            Throw New Exception("Error getting Parameter:'" & ParameterName & "'", ex)
        End Try
    End Function
    Public Function GetParameterValue(ByVal ParameterName As String, ValueToCreateIfNone As String) As String
        Dim value As Object = Nothing
        If ParameterName.Length <= 5 Or ParameterName.Length > 50 Then Throw New Exception("ParameterName length (" & ParameterName.Length & ") must be betwen 5 and 50")
        Try
            value = Me.DLookup("ParameterValue", "stblParameters", "ParameterName='" & ParameterName & "'")
            If value = Nothing And ValueToCreateIfNone <> Nothing Then
                Me.SetParameterValue(ParameterName, ValueToCreateIfNone)
            End If
            Return GetParameterValue(ParameterName)
        Catch ex As Exception
            Throw New Exception("Error getting Parameter:'" & ParameterName & "'", ex)
        End Try
    End Function
    Public Sub SetParameterValue(ByVal ParameterName As String, ByVal NewValue As String)
        Dim sql As String = ""
        If ParameterName.Length <= 5 Or ParameterName.Length > 50 Then Throw New Exception("ParameterName length (" & ParameterName.Length & ") must be betwen 5 and 50")
        Dim cmd As New SqlCommand("", Me.DBConnection, Me.DBTransaction)
        Try
            Dim Test As String = Me.DLookup("ParameterName", "stblParameters", "ParameterName='" & ParameterName & "'")
            If Test = Nothing Then
                sql = "INSERT stblParameters ("
                sql += "        ParameterName"
                sql += "        ,ParameterType"
                sql += "        ,UserId"
                sql += "        ,ParameterValue"
                sql += "        )"
                sql += " VALUES('" & ParameterName & "'"
                sql += "        ,'System'"
                sql += "        ,'All'"
                sql += "        ,'" & NewValue & "')"
                cmd.CommandText = sql
                cmd.ExecuteNonQuery()
            Else
                sql = "UPDATE stblParameters "
                sql += " SET ParameterValue ='" & NewValue & "'"
                sql += "  WHERE ParameterName = '" & ParameterName & "'"
                cmd.CommandText = sql
                cmd.ExecuteNonQuery()
            End If

        Catch ex As Exception
            Throw New Exception("Error setting Parameter:'" & ParameterName & "'", ex)
        End Try
    End Sub
    Public Function GetBasicHTMLFromQuery(ByVal sql As String, Optional ByVal MaxRows As Integer = 50) As String

        Dim tbl As DataTable = Me.GetDataTableFromSQL(sql)

        Return GetBasicHTMLFromDatatable(tbl)

    End Function
    Public Function GetBasicHTMLFromDatatable(ByVal tbl As DataTable, Optional ByVal MaxRows As Integer = 50) As String
        Dim html As String = ""
        html += "<table border=1 class='ListTable' cellpadding='0' cellspacing='0'>"
        html += "<tr>"
        For Each col As DataColumn In tbl.Columns
            html += "<th valign=top>"
            html += col.ColumnName
            html += "</th>"
        Next
        html += "</tr>"
        Dim rowNum As Integer = 1
        For Each row As DataRow In tbl.Rows
            If rowNum > MaxRows Then
                Exit For
            End If

            html += "<tr>"
            For Each col As DataColumn In tbl.Columns
                html += "<td valign=top>"
                html += Me.IsDBNull(row(col.ColumnName).ToString.Replace(Environment.NewLine, "<BR>"), "")
                html += "</td>"
            Next
            html += "</tr>"
            rowNum += 1
        Next
        html += "</table>"
        Return html
    End Function

    Public Sub ExecuteSQL(sql As String)
        Try
            Dim cmd As New SqlCommand(sql, Me.DBConnection, Me.DBTransaction)
            cmd.CommandTimeout = Me.CommandTimeout
            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Throw New Exception("ExecuteSQL failed:" & ex.Message & vbCrLf & sql)
        End Try
    End Sub

End Class
